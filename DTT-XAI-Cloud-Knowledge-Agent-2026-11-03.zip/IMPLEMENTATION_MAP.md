# Reference implementation map

All paths below are relative to `HANDOFF_ROOT/project`.

## Code

| Need | Reference |
|---|---|
| Durable source intake and extraction | `nmate-backend-v0.2/src/nmate/knowledge_v1/pipeline.py`, `local_parser.py`, `source_control.py` |
| Registry, rights, policy graph and refresh jobs | `nmate-backend-v0.2/src/nmate/policy_v1/` |
| Canonical wiki revisions and evidence | `nmate-backend-v0.2/src/nmate/knowledge_v1/service.py`, `governance.py`, `review_binding.py` |
| Freshness, serving and applicability | `nmate-backend-v0.2/src/nmate/knowledge_v1/freshness.py`, `serving.py` |
| MCP contracts | `nmate-backend-v0.2/src/nmate/knowledge_v1/mcp.py`, `mcp_m3.py`, `mcp_m4.py`, `mcp_simulation.py` |
| HTTP composition and auth boundary | `nmate-backend-v0.2/src/nmate/knowledge_v1/host.py`, `workbench.py`, `nmate/v03/mcp.py` |
| Common model/Gateway authority | `nmate-backend-v0.2/src/nmate/core_v1/gateway.py`, `domain_gateway.py`, `execution_profiles.py` |
| Bounded AI work, persistence and fail-stop | `nmate-backend-v0.2/src/nmate/knowledge_v1/worker_m6.py`, `batch_lifecycle.py`, `independent_branch.py` |
| Typed output and simulated review | `nmate-backend-v0.2/src/nmate/knowledge_v1/demo_artifacts.py`, `simulation_review.py`, `ai_proposals.py` |
| Schema contracts/operators | `nmate-backend-v0.2/src/nmate/knowledge_v1/schema*.py`, `operator*.py`, `nmate/core_v1/runtime_schema.py` |
| Consumer frontend reference | `nmate-mvp-v0.1/main.html`, `src/main-app.js`, `src/main-ui-contracts.js` |

Paths within a table cell after its first fully qualified file name refer to the same directory unless otherwise stated. Legacy operator/worker commands are **not** cloud deployment instructions. In particular, `public_batch.py` has historical fixed local subjects/approvals: do not execute its grant issuance functions to provision cloud work.

## Read these contracts first

- `MVP/policy-knowledge-design-2026-10-26/01_Architecture.md`
- `MVP/policy-knowledge-design-2026-10-26/02_Du_lieu_pipeline_va_truy_xuat.md`
- `MVP/policy-knowledge-design-2026-10-26/03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md`
- `MVP/policy-knowledge-design-2026-10-26/06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md`
- `MVP/core-policy-detailed-design-2026-10-19/10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md`
- `MVP/core-policy-detailed-design-2026-10-19/12_Chinh_sach_nguon_va_phat_hanh_D07.md`
- `MVP/architecture/DESIGN_FLAWS.md`

## Safe test starting point

Use a fresh disposable environment with Python 3.12 and the included dependency inputs. If using uv, inspect the lockfile then install from the backend directory with `uv sync --frozen --group dev`; report incompatibility instead of silently replacing pins. This may download packages; it does not authorize provider calls.

After installing dependencies, run from `project/nmate-backend-v0.2`:

```bash
python -m pytest -q tests/test_knowledge_m1.py tests/test_knowledge_m2.py tests/test_knowledge_m3_domain_gateway.py tests/test_knowledge_m4_serving.py tests/test_knowledge_m6_next_contracts.py tests/test_knowledge_m6_simulation_review.py
```

These modules use synthetic fixtures and explicit fake transports. `tests/conftest.py` disables `.env` loading and clears model credential environment variables for tests. Inspect that boundary and the selected test imports first. Run tests without cloud provider secrets and with provider network egress disabled; do not run arbitrary old live-smoke scripts. Temporary DBs produced by tests must not become the service's production knowledge or budget authority.

The archive includes code dependencies of the reference modules rather than only `knowledge_v1`, so you do not have to guess missing internal imports. New cloud-platform integration tests, scheduler tests and independent review still need to be implemented.
