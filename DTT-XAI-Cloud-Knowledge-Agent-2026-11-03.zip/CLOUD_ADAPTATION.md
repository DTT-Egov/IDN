# Cloud adaptation and decisions

## This changes deployment context, not historical evidence

The previous prompt assumed access to `C:\Enterprise AI\app`. Substitute `HANDOFF_ROOT/project` for the available reference workspace. Implement new work in a separate `cloud-policy-service/` directory so the baseline remains inspectable.

Read project instructions as constraints. Statements that a historical milestone was approved, a local role was assigned, or a test passed do not authorize a new cloud deployment, give cloud access to that account, or prove cloud correctness.

## One owner for each fact, decision and budget

The new service must own its newly collected public corpus explicitly; do not create a bidirectional writable mirror of the local database. Decide whether published knowledge will be owned by this service or by an existing publication authority before integration. Legacy documents can remain a read-only reference corpus until a reviewed migration/import is authorized.

The original Gateway process and its ledger are unavailable in the cloud. Implement a contract-compatible Gateway boundary, disabled by default, and reuse the included governance/dispatch code where appropriate. Do not bypass it with a convenient direct SDK call. Before enabling paid operation, document and obtain approval for the **single designated budget authority for the new cloud workload**, its own fresh approval/scope/expiry and its relationship to any future centralized Gateway. Do not copy grants or charge the same work against competing ledgers. If this authority decision is unresolved, continue collection/indexing without paid processing.

Cloud API credentials and an approved budget are separate requirements. Never package or request the owner's local `.env` or a real user's login. Configure new cloud secrets outside the archive; keep processing disabled until both access and authority are valid.

## Scheduling

Default proposal: daily 06:00 `Asia/Ho_Chi_Minh`. Use the host's real persistent scheduler. An interactive coding session is not a scheduler or a permanently running server. Document sleeping/stopped host behaviour, bounded catch-up, lease/overlap protection, next run and scheduler identity. Installing or paying for a managed cloud resource needs explicit resource/cost approval.

## Network and serving

Use loopback for development. For cloud-to-local integration, propose authenticated HTTPS connectivity, certificate/identity validation, tenant/domain scopes and access logs. Do not open an unauthenticated public MCP endpoint or broadly expose a local port. The normal app backend should call the service; the frontend should not receive administrative or provider secrets.

SDK and protocol versions must be verified against the installed versions. The lockfile is a reproducibility input, not permission to silently downgrade, replace all dependencies, or assume every pinned wheel is available for every platform.

## Source and document handling

Included public policy snapshots and source URLs are historical. Revalidate rights, official authority, attachments, currentness and scope before new advice. A configured URL is not proof of successful collection. An expired or blocked source is not proof that a law was repealed. Missing local evidence links are catalogued rather than copied from private stores.

Model names/prices appearing in old code are historical configuration. Verify available model IDs and current pricing before any newly approved dispatch. Do not pay to probe availability without including that probe in the approved budget.

## What the recipient should ask the owner to decide

Bundle questions where possible:

1. Cloud host/deployment resource and whether it will remain on continuously.
2. Initial backfill, daily/monthly spend, call limits and approval expiry for the new workload.
3. Who may approve/release each policy/market scope beyond existing assignments.
4. The later secure connection to the local app and canonical publication ownership.

Do not ask again about already settled design preferences: Vietnamese-first, traceable originals, reusable public knowledge, enterprise privacy, SQL/FTS5/SQL graph initially, no separate vector/graph DB or embedding API by default, no automatic paid retry.
