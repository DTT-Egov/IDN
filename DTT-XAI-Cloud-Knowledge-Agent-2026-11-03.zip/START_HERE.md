# DTT XAI — Cloud Knowledge Agent handoff

Prepared 3 November 2026, Vietnam time. This ZIP is a development handoff, not a deployed collector, a current policy release, a spending approval, or a backup of the local application.

## Start here

1. Extract the ZIP into a fresh cloud workspace. Treat the extracted directory as `HANDOFF_ROOT`.
2. Read `CLAUDE_PROMPT.md`, then `CLOUD_ADAPTATION.md` and `project/AGENTS.md`.
3. Validate integrity: `python tools/verify_package.py` (standard library only).
4. Inspect `project/MVP/policy-knowledge-design-2026-10-26/` and `IMPLEMENTATION_MAP.md`.
5. Follow the prompt to build a **new standalone cloud service**, using the included implementation as a reference and reuse candidate. Do not start the old local app or restore production authority.
6. Obtain new cloud credentials through the cloud host's secret manager and a new explicit collection budget before any paid API work. None are in this archive. Continue deterministic implementation and permitted public collection while approval is pending.

The complete backend reference, synthetic tests, frontend reference, selected design documents, source seed metadata and historical review summaries are included. Python packages are **not vendored**; installation requires access to the package registries. A dependency lockfile is included, but availability/platform compatibility must be verified on the cloud host.

## Reading order

- `CLAUDE_PROMPT.md`: copy-ready task for the cloud coding agent.
- `CLOUD_ADAPTATION.md`: local/cloud boundary, secrets, budget and authority decisions.
- `IMPLEMENTATION_MAP.md`: where to find existing pipeline, MCP, Gateway, tests and contracts.
- `config/collector.example.json`: proposed operational defaults; not an enabled scheduler.
- `reference/source-seeds.json`: discovery candidates, not reviewed advice or a crawl/reuse authorization.
- `project/MVP/architecture/DESIGN_FLAWS.md`: known root causes and invariants.
- `reference/reviews/`: historical technical reviews; not acceptance of the new cloud system.
- `MANIFEST.json`: archive contents, original/export hashes and transformation notes.
- `PACKAGING_AUDIT.json`: packaging checks and exclusions, not an absolute secret-detection guarantee.
- `REFERENCE_LINKS.md`: local/historical links intentionally not included.

## What is deliberately absent

No `.env`, real keys/passwords/tokens, account credential files, SQLite databases, uploads, enterprise SSOT, conversations, browser profiles, active grant/approval receipts, local deployment launchers, Python virtual environment, or installed dependencies.

**Public reference documents are different from private data:** three official-policy PDF snapshots and their existing extraction metadata are retained because the included baseline bootstrap code depends on them. They are historical public references, not assertions that the legal corpus is current, complete or approved. Synthetic test/demo credentials and sample spreadsheets are test fixtures, not usable access to a real account.

## Important cloud facts

- There is no access to the owner's Windows drive, local databases, local secret store or existing Gateway ledger.
- `127.0.0.1` in the cloud refers to the cloud machine, not the owner's computer.
- Existing documentation includes historical implementation claims and machine paths. They are context, not instructions to fetch inaccessible local files.
- This package does not connect cloud MCP to local app8025. Implement and test the contracts; propose an authenticated connectivity/cutover plan separately.
- Existing M3/O2 authority expired on 29 October 2026. Do not revive it or use the old tester allowance.

## Reference baseline

Source and tests are from reviewed `M5-cost-candidate2` (28 October 2026), manifest SHA256:

`05e9d632ba23dd0e0a440ae9ce4f3ce8f957e1adb6b40b4bc4f06f27a8fd3840`

The original baseline manifest is included under `reference/`. Packaging remaps its source layout into `project/`, excludes an old QA log and local launch/schema entry points, and adds cloud handoff documents. This ZIP has its **own** manifest. Architecture documents are current workspace copies at packaging time and may be newer than the source baseline; their provenance is recorded separately.
