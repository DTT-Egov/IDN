# Nháp S1 từ Claude — chờ chuyên gia rà

27/10/2026 · Một lượt Sonnet thật; bản xem từ proposal `wiki_proposal_0534bc705b664e32b0cc02a4454a3cfc`. Chưa được chuyên gia duyệt hoặc phát hành, chưa dùng để kết luận doanh nghiệp được hưởng hỗ trợ.

## Đọc bản này như thế nào

Đây là nội dung AI đề xuất, giữ nguyên chữ của đầu ra đã lưu. Cả năm nhận định được trình là **diễn giải chưa kiểm chứng ngữ nghĩa**. Bốn nhận định đầu bị AI gắn nhầm loại trích nguyên văn; hệ thống chỉ hạ mức tin cậy của projection, không sửa kết quả gốc. Chín câu dẫn khớp chữ và vị trí duy nhất trong các trích đoạn được cấp; điều đó chưa chứng minh diễn giải đúng, đủ điều kiện áp dụng hoặc chính sách còn hiệu lực.

Reviewer đặc biệt lưu ý nhận định 5: nguồn Bước 2 bị cắt ở “cán bộ phụ trách”; câu suy ra cán bộ sẽ trao đổi giấy tờ cần chứng minh vẫn chưa được nguồn chứng minh. Người rà cần xem toàn văn trước khi sửa, chấp nhận hoặc loại bỏ.

## Tên đề xuất của AI

Đề xuất chưa duyệt: Quy trình và giấy tờ Phụ lục 3 – Hỗ trợ giá trị hợp đồng tư vấn giải pháp chuyển đổi số (Hà Nội, 2026)

## Nhận định 1 — diễn giải chờ rà

Phụ lục 3 nêu chương trình hỗ trợ cho 200 doanh nghiệp trên địa bàn Hà Nội, gồm 100 doanh nghiệp nhỏ và 100 doanh nghiệp vừa.

Căn cứ AI đã dẫn:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 888–933 trong chunk đã ghim hash.

> - 100 doanh
> nghiệp nhỏ
> - 100 doanh
> nghiệp vừa

## Nhận định 2 — diễn giải chờ rà

Mức hỗ trợ là 50% kinh phí từ ngân sách nhà nước, có mức trần theo loại doanh nghiệp.

Căn cứ AI đã dẫn:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 1056–1091 trong chunk đã ghim hash.

> 50% kinh phí
> từ Ngân sách
> nhà nước,

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 1098–1134 trong chunk đã ghim hash.

> không
> quá 50 triệu
> đồng/hợp
> đồng/năm

## Nhận định 3 — diễn giải chờ rà

Thành phần hồ sơ ghi trong Phụ lục 3 là Tờ khai xác định doanh nghiệp và đề xuất nhu cầu hỗ trợ theo mẫu của Nghị định 80/2021/NĐ-CP. Nghị định 80 còn nêu tài liệu liên quan (nếu có).

Căn cứ AI đã dẫn:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 1209–1266 trong chunk đã ghim hash.

> Tờ khai xác
> định doanh
> nghiệp siêu
> nhỏ, doanh
> nghiệp nhỏ,

[VN-DECREE-80-2021-SCAN](https://datafiles.chinhphu.vn/cpp/files/vbpq/2021/08/80.signed_01.pdf) · đoạn ký tự 569–641 trong chunk đã ghim hash.

> b) Những tài liệu, hồ sơ liên quan đến nội dung đề xuất hỗ trợ (nếu có).

## Nhận định 4 — diễn giải chờ rà

Bước 1: doanh nghiệp có thể nộp trực tiếp, qua bưu chính công ích hoặc trực tuyến qua Cổng dịch vụ công quốc gia.

Căn cứ AI đã dẫn:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 1383–1442 trong chunk đã ghim hash.

> B1: Doanh nghiệp lựa
> chọn nộp hồ sơ theo các
> hình thức sau:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 3022–3073 trong chunk đã ghim hash.

> (iii) Nộp trực tuyến qua
> Cổng dịch vụ công quốc
> gia

## Nhận định 5 — diễn giải chờ rà

Diễn giải: sau khi Trung tâm tiếp nhận hồ sơ, cán bộ sẽ trao đổi về hồ sơ cần chứng minh (nếu có). Trích đoạn bị cắt nên chưa đủ các bước sau B2. Hạn nhận hồ sơ từ 30/03/2026 đến khi đủ chỉ tiêu.

Căn cứ AI đã dẫn:

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 3101–3173 trong chunk đã ghim hash.

> B2: Sau khi Trung tâm
> tiếp nhận hồ sơ của doanh
> nghiệp, cán bộ phụ trách

[HN-NOTICE-2026-14-ATTACHMENT](https://hotrodoanhnghiep.hanoi.gov.vn/FileUploaded/Upload/FILES/document%20(27).pdf) · đoạn ký tự 170–204 trong chunk đã ghim hash.

> Từ 30/03/2026 đến khi đủ
> chỉ tiêu.

## Khoảng trống AI đã ghi nhận

- Trích đoạn B2 bị cắt, chưa có các bước sau B2 như thẩm định, phê duyệt, ký hợp đồng, giải ngân.
- Thông báo trong Phụ lục chưa có số và ngày ban hành; chưa xác nhận hiệu lực.
- Thiếu toàn văn thông báo, điều kiện, ngoại lệ và tiêu chí ưu tiên khi vượt chỉ tiêu.
- Thông tin liên hệ trong bảng có số điện thoại và email lặp giữa các đơn vị, cần đối chiếu nguồn gốc.
- Bản trích Thông tư 06/2022 không đủ để xác định giấy tờ riêng cho tư vấn chuyển đổi số.
- Chưa xác minh tiêu chí doanh nghiệp nhỏ và vừa hay quyền hưởng của doanh nghiệp cụ thể.

## Câu hỏi AI đề nghị chuyên gia xác minh

- Có bản thông báo chính thức đã ban hành, có số và ngày, kèm toàn văn Phụ lục 3 không?
- Các bước sau B2 và thời hạn xử lý của quy trình là gì?
- Doanh nghiệp có phải nộp báo giá, hợp đồng tư vấn hoặc chứng từ thanh toán không?

## Việc cần chuyên gia thực hiện

1. Đối chiếu đúng bản ký, phụ lục, toàn văn và các sửa đổi; xác minh hiệu lực và kỳ tiếp nhận.
2. Rà từng diễn giải với đủ ngữ cảnh, sửa hoặc loại phần suy ra chưa có căn cứ; không lấy quotation-match thay thẩm định.
3. Xác nhận nguồn, ghi quyết định rà đúng revision rồi phát hành bằng lệnh riêng nếu đủ điều kiện. Chưa chuyển thành quy tắc đánh giá điều kiện hưởng ở M3.

Tài khoản được giao: `trung@dtt.vn`. Việc giao bản nháp không có nghĩa người đó đã đăng nhập, rà hoặc phát hành.

## Truy vết và chi phí

- Attempt: `model_attempt_80cd7d69c7184007b0d86174517a0d7a`; model `claude-sonnet-5-5`.
- 6.833 token đầu vào / 1.617 token đầu ra; ước tính 0,029836 USD theo rate đã ghi, chưa phải hóa đơn.
- Phục hồi proposal từ kết quả đã lưu: không gọi model; raw/data/usage, input manifest, nguồn và các bảng bảo vệ giữ nguyên. Không tạo quyết định chuyên gia hoặc ghi SSOT.
- Batch đang pause; không tự dùng năm lượt còn lại. Hạn mức gốc hết lúc 07:40:33 ngày 29/10/2026 (UTC+7), không gia hạn.
- [Biên nhận phục hồi](<../../../REFERENCE_LINKS.md#ref-0084>) · [walkthrough](<02_Walkthrough_M3.md>) · DF-056/059 và DF-005/033.
