# M3 — chuyên gia biên soạn/phát hành và AI xây kho có kiểm soát

27/10/2026 · Người dùng cho tiếp M3 và yêu cầu dùng AI xây kho. Chỉ dẫn mới cho phép đưa lát cắt AI tạo nháp của K2 lên cùng M3; không tự cho M4/M5/deploy hoặc tự cấp ngân sách trả phí.

## Kết quả cần bàn giao

1. Workbench tiếng Việt, mobile first: hàng đợi theo quyền, editor/xem trước Markdown, diff, căn cứ từng nhận định, conflict giữ nháp; hai thao tác rà/phát hành có receipt exact revision/hash và scope riêng.
2. Dùng cùng governance authority hiện có, thêm capability wiki explicit. Không suy scoped reviewer/publisher thành global curator; không tạo người/chuyên gia giả. Chuyên gia đã giao là trung@dtt.vn, trong phạm vi Phụ lục03/N1–N4; chưa có quyết định rà/phát hành thật thì không mở assessment hiện hành.
3. AI nhận tập trích đoạn công khai đã ghim hash và quyền, tạo đề xuất tiếng Việt/typed evidence/gap để chuyên gia rà. Đầu ra AI không tự viết SSOT, nguồn gốc, quyền, approval hoặc release.
4. Mở rộng Subject/Scope có kiểu trong **cùng ModelGateway**, cùng cơ chế giữ tiền, dispatch fence, SDK/manifest/receipt và không tự retry. Schema enterprise cũ không được nhận một doanh nghiệp giả hoặc bị rewrite để hợp thức hóa domain job.
5. Kiểm âm scope/hash/source-change/revoke/concurrency/crash và provider stub trước paid. AI thật chỉ chạy batch đã duyệt số lượt/trần tiền; sau mỗi lỗi không tự sửa bằng lượt mới. Chất lượng nguồn, lời đề xuất AI và quyết định chuyên gia được ghi tách biệt.

## Các cổng

- [D06 batch cụ thể](<../../../REFERENCE_LINKS.md#ref-0059>) đã được người dùng duyệt6lượt/tổng2USD. Sau qualification candidate3 đã cấp và chạy đúng1Sonnet; chi phí tokenước tính0,029836USD. Batch dừng khi admission phát hiện diễn giải gắn nhầm loại trích nguyên văn; xử lý kết quả đã lưu miễn phí, không tự dùng5slot còn lại. Hạn mức được pause riêng, không đổi expiry. Xem [bàn giao](<03_Ban_giao_M3.md>) và [walkthrough](<02_Walkthrough_M3.md>).
- Nguồn pilot từ public source pack đã lưu, không gồm chat/SSOT/tài liệu tài chính/cá nhân doanh nghiệp. Toàn văn/phụ lục/sửa đổi/hiệu lực còn thiếu phải thành gap; AI không được lấp bằng trí nhớ.
- Làm trên môi trường M3 riêng. App8025 và DB MAIN giữ nguyên cho tới gate phát hành M5.
- Dừng sau bàn giao M3. Không mặc định ngân sách20USD tester còn hiệu lực hoặc dùng được cho xây kho.

Truy vết: DF-013/014/021/027/029/030/031/033/034/041/043/044/046/048/055. Những biên đã kiểm M1/M2 phải tiếp tục áp dụng cho capability/adapter mới, không coi inherited method hoặc nguồn công khai là quyền gọi model.
