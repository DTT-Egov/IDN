# M3 — bàn giao kiểm tra tại mốc

27/10/2026 · M3 đạt các kiểm tra kỹ thuật trong phạm vi nêu dưới; nháp nội dung thật chờ chuyên gia. Dừng tại mốc để kiểm tra, chưa chuyển M4/M5.

## Kết quả đã làm

- Bàn chuyên gia tiếng Việt, mobile first: hàng đợi, editor/xem trước, nháp riêng và phục hồi sau tải lại, căn cứ từng nhận định, diff, rà, phát hành và ngừng phát hành riêng biệt.
- SQL là bản chuẩn có revision, causal heads và biên nhận. Markdown là sản phẩm xem/chia sẻ. Chưa thêm vector/graph database hoặc embedding.
- Quyền đọc/biên soạn/rà/phát hành/xác minh nguồn theo phạm vi; không suy một vai chuyên gia thành quyền quản trị mọi nguồn. Thu hồi READ kiểm cả kết quả cũ, EXPORT kiểm trước gửi dữ liệu ra ngoài.
- AI xây kho dùng cùng ModelGateway, không tạo doanh nghiệp giả, SDK/ngân sách thứ hai hoặc retry có phí. Approval duy nhất gắn một DB/instance; copy staging không nhân đôi hạn mức.
- Đầu ra Claude giữ nguyên assertion gốc; projection có phiên bản và cảnh báo ngữ nghĩa chờ chuyên gia. Không tự ghi SSOT, rà hoặc phát hành.

## Build và bằng chứng

Candidate cuối: [frozen5](<../../../REFERENCE_LINKS.md#ref-0073>),364file, manifest SHA256 `9ab2285804908e0d8627642150ca2a5e491214482e87023607f93f3eaba8f3de`.

| Vòng | Kết quả | Giới hạn |
|---|---|---|
| Candidate3 |269ca author,31ca reviewer và1ca directGateway riêng đều đạt | Bản đã cho chạy S1, chưa có admission v2 |
| Candidate3 mobile độc lập | Chuỗi nháp→reload→ghi bản2→rà→phát hành→ngừng→reload đạt;320px,44px,0console error | Dữ liệu và quyết định synthetic; không phải chuyên gia thật/MAIN |
| RED admission trên candidate3 |4fail/4pass đúng cơ chế thiếu projection/pause | Provider stub, không phí |
| Candidate4 |253ca hồi quy root,39ca M3 reviewer,49ca độc lập đạt | Chưa chặn ambiguous subquote |
| RED occurrence trên candidate4 |2ca root fail; reviewer2fail/1pass | `.index` tự chọn vị trí đầu; negative test không được đổi cho xanh |
| Candidate5 targeted root |17/17đạt | Admission/proposal/repeated+overlap |
| Candidate5 M3 do reviewer chạy lại |41/41đạt | Provider stub; đúng364file frozen cuối |
| Candidate5 độc lập |52/52đạt | Phạm vi service/authority/admission/replay/occurrence; không là duyệt ngữ nghĩa chính sách |
| Candidate5 hồi quy mở rộng root |259/259đạt,20file | M1/M2/M3 và Gateway/ACL/tài chính/SSOT/budget/operator; provider stub, không MAIN |

[Walkthrough và ảnh](<02_Walkthrough_M3.md>), [review candidate3](<../../../REFERENCE_LINKS.md#ref-0074>), [review mobile](<../../../REFERENCE_LINKS.md#ref-0075>), [RCA S1](<../../../REFERENCE_LINKS.md#ref-0076>).

[Log hồi quy cuối](<../../../REFERENCE_LINKS.md#ref-0077>) và [biên nhận đúng build/testlist](<../../../REFERENCE_LINKS.md#ref-0078>) xác nhận364file frozen giữ nguyên. Không cộng các lượt chạy hoặc ca supplement thành một bộ full-run giả.

**Kết luận reviewer: SCOPED PASS**, không còn blocker kỹ thuật trong phạm vi M3. [Báo cáo cuối frozen5](<../../../REFERENCE_LINKS.md#ref-0079>) và [signoff](<../../../REFERENCE_LINKS.md#ref-0080>) bao gồm kiểm UI cảnh báo và actual S1 sau phục hồi; không coi đó là phê duyệt nội dung, MAIN deployment hoặc đóng toàn lớp thiết kế.

## AI thật và chi phí

Đã sử dụng **1Sonnet/6lượt được duyệt**, chưa dùng Opus. Usage6833input/1617outputtokens, chi phíước tính **0,029836USD**, chưa phải hóa đơn. Batch dừng ở S1 khi phát hiện4câu diễn giải gắn nhầm loại trích nguyên văn; không gửi lần nữa hoặc dùng slot tiếp để sửa.

Grant riêng ở public-only staging đã pause;5slot còn lại không tự sử dụng. Expiry gốc **07:40:33 ngày29/10/2026(UTC+7)**, không gia hạn. Quỹ tester không bị dùng. [Stop receipt](<../../../REFERENCE_LINKS.md#ref-0081>).

Đã phục hồi proposal `wiki_proposal_0534bc705b664e32b0cc02a4454a3cfc` từ S1 bằng frozen5, **không gọi lại model**. Recovery dùng Gateway disabled và request function bị cấm; mọi bảng bảo vệ gồm raw/data/usage/source/request/manifest giữ nguyên. Chỉ tạo nháp proposal; grant vẫn paused, không tạo review/release/SSOT event. [Biên nhận](<../../../REFERENCE_LINKS.md#ref-0082>), [nháp cho chuyên gia](<04_Nhap_AI_S1_cho_chuyen_gia.md>).

[Reviewer đối soát sau phục hồi bằng kết nối chỉ đọc](<../../../REFERENCE_LINKS.md#ref-0083>) xác nhận1attempt/1proposal/0wiki pages/0review/0release, raw/data/usage khớp trước phục hồi, phí29836micro-USD và grant vẫn paused. UI cảnh báo frozen5 cũng được thử riêng ở320px bằng dữ liệu synthetic, không tràn và control44px; xem ảnh bổ sung trong walkthrough.

## Phần chưa phát hành và thiết kế còn mở

Nguồn thật vẫn thiếu xác minh toàn văn, chữ ký/định danh, sửa đổi, hiệu lực và kỳ tiếp nhận. AI không được suy ra quyền hưởng. Chuyên gia `trung@dtt.vn` chưa thực hiện quyết định rà/phát hành thật; metadata assignee ở staging không phải đăng nhập hoặc phê duyệt của người đó.

M3 chưa đưa tri thức vào trả lời doanh nghiệp hoặc assessment. M4 thiết kế/kiểm consumer và tách tri thức đã phát hành khỏi nháp; M5 mới tích hợp host auth/capability và deploy app chính theo gate. Không tự đi tiếp M4/M5, không đổi8025 hoặc SSOT doanh nghiệp.

Ba UX polish không chặn bàn giao kỹ thuật: bỏ từ MCP khỏi hướng dẫn thao tác; tách dirty khác bản chuẩn với trạng thái chưa giữ nháp server; làm rõ bản đã phát hành và tránh nút phát hành lặp vẫn sáng. Chưa kiểm screen reader bằng âm thanh/điện thoại vật lý hoặc concurrent editor UI thực tế. Partial admission khi một claim có quote sai vẫn là backlog; raw vẫn được giữ nhưng chưa có quarantine riêng từng claim.

Đã ghi mới **DF-059**, cập nhật **DF-056**, **DF-005/033**; vòng M3 còn có **DF-057/058**, các biên029/048/049/053/054. [Sổ thiết kế](<../architecture/DESIGN_FLAWS.md>) giữ toàn lớp ởD1, không nâng D2 từ vài ca đạt. Chống rollback toàn máy/operator thay cả DB/registry chưa thuộc bảo đảm.
