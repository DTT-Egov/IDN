# M3 — implementation và biên thẩm quyền

27/10/2026 · Candidate2 đang kiểm; chưa gọi Claude thật tại thời điểm viết mục này. Kết quả cuối xem walkthrough/bàn giao, không dùng tài liệu thiết kế thay bằng chứng chạy.

## Một kho chuẩn, các sản phẩm có nguồn gốc

```mermaid
flowchart TD
  P[Public pack đã lưu: bản gốc và trích chữ] --> I[Operator nhập có biên nhận và kiểm quyền nguồn]
  I --> S[(SQL: rendition, extraction, chunks, quyền)]
  S --> G[ModelGateway chung: account + public domain + corpus ghim]
  G --> A[4 đề xuất Sonnet]
  A --> O[2 bản rà Opus dùng đúng đề xuất đã lưu]
  O --> Q[(Proposal chưa duyệt)]
  A --> Q
  Q --> H[Chuyên gia thật chuyển thành wiki nháp]
  H --> W[(Body/revision/claim/evidence chuẩn trong SQL)]
  W --> R[Rà exact revision và manifest nguồn]
  R --> L[Phát hành bằng quyết định riêng]
  L --> M[Markdown/index qua outbox, không là authority]
```

M1/M2 giữ SQL là bản chuẩn; không thêm graph/vector database hoặc embedding. M3 không thay SSOT doanh nghiệp, hội thoại hay tài liệu riêng. Tri thức domain khác với khẳng định của một doanh nghiệp. Bản wiki phát hành cũng chưa tự thành quy tắc điều kiện hưởng; phần phục vụ/assessment thuộc M4 và cửa phát hành M5.

## Các hợp đồng chính

| Thành phần | Trách nhiệm | Điều bị chặn |
|---|---|---|
| `WikiGovernance` | Body/claim có nguồn; nháp cá nhân; diff; quyết định xác minh nguồn, rà, phát hành và ngừng phát hành | Không đọc nguồn ngoài quyền; không dùng review của bản/căn cứ cũ cho lệnh phát hành mới |
| Quyền wiki | Capability explicit theo account, policy và toàn bộ nguồn; review/publish/attest còn kiểm authority catalog hiện có | Scoped expert không thành global curator; role duyệt rule không tự là capability wiki |
| `ModelGateway._execute_once` | Một kernel reservation, dispatch fence, transport/SDK, usage, validation và receipt | Không fake enterprise, không transport/budget thứ hai, không retry/fallback có phí |
| `DomainAuthority` | Account subject thật trong realm operator riêng, `public_domain:hanoi_policy`, exact corpus và slot S1–O2 | Caller không thay canonical resolver, gửi SSOT/tài chính hay mở nguồn/slot/model ngoài grant |
| `public_batch` | Prepare offline, kiểm fixed D06, execute có giới hạn, record proposal | File không cấp thêm quyền; restart sau lỗi/handoff thiếu không được gửi slot tiếp theo |
| Workbench/MCP | Cùng authenticated `call` và host session/CSRF validator; hàng đợi, editor/xem trước, căn cứ, diff, review/release | Không có tool cấp ngân sách hoặc gọi AI trong UI M3; đọc/recovery không dispatch |

Capability `read`, `author`, `review`, `publish`, `attest` là riêng biệt. Việc cùng người nhận hai vai reviewer/publisher vẫn để lại hai quyết định riêng. Receipt đã commit kiểm identity và READ hiện hành; không áp new-WRITE/CAS cho replay. Ngừng phát hành/cất không mặc định thu hồi READ lịch sử. Thu hồi nguồn READ chặn mọi dẫn xuất, kể cả cached receipt. Chỉ thu hồi EXPORT chặn egress mới, giữ đọc nội bộ nếu READ còn.

## Dữ liệu và tính nhất quán

- Review ghim page/revision/body/content/binding hashes, nguồn/rendition/extraction/rights/attestation và section IDs. Sửa body, thay nguồn hoặc mất quyền khiến quyết định cũ không đủ cho phát hành mới.
- Attestation, review, release có immutable record/hash và causal head; không chọn bản thắng theo timestamp hay UUID. Head/event/receipt/outbox trong cùng giao dịch. Fault trước receipt rollback toàn lệnh.
- Nháp cá nhân gắn account/page/base revision/UI revision. Bản cũ giữ để đối chiếu; xung đột không tự ghi đè canonical. Workbench chỉ có một trạng thái governance, không hiển thị placeholder “chưa phát hành” từ reader M2 cạnh release M3.
- AI proposal ghi attempt, input manifest, invocation operator, assignee; `reviewed_by`/`published_by` rỗng. Chuyển proposal thành nháp là command riêng, atomic với application receipt; batch không thực hiện thay chuyên gia.
- Managed runtime chỉ mở DB/schema đã kiểm. Operator M3 reconcile original plan/receipt trước dry-run; runtime không dùng constructor bootstrap để tự chữa schema.

## Batch đã được duyệt

Approval `D06-M3-public-knowledge-20261027-6calls-2usd`: tối đa6lượt, tổng2USD, tối đa48giờ từ cấp. S1–S4 dùng Sonnet5.5, trần0,25USD/lượt; O1–O2 dùng Opus5.5, trần0,50USD/lượt. O1 nhận S1/S2 đã lưu; O2 nhận S3/S4 đã lưu. Per-call output thực cấu hình2048/3072tokens, không vượt đề nghị4096; kernel giữ tiền theo upper bound trước gửi.

Chỉ nguồn public pack đã có: Phụ lục03 của thông báo Hà Nội, các đoạn Nghị định80/2021 và Thông tư06/2022. Bản gốc vẫn ở catalog; transcript là dẫn xuất có hash và trang, không giả thành toàn văn đã thẩm định. Hiệu lực, chữ ký/định danh và bối cảnh/sửa đổi còn thiếu giữ thành gap. Không gửi PDF gốc, tài khoản/mật khẩu, SSOT, chat hoặc chỉ tiêu tài chính.

Public staging chỉ lấy metadata account hiện có bằng kết nối read-only, không lấy password/session/membership/doanh nghiệp. Realm là `isolated_M3_public_operator_batch`, không phải đăng nhập chuyên gia và không live-sync RBAC. Operator import có principal không đăng nhập riêng; assignee không bị giả thành người ra quyết định. Không mở grant/capability reviewer/publisher thật ở MAIN.

## Giới hạn nghiệm thu

Workbench được kiểm trên namespace synthetic, provider tắt, trước khi đưa vào app chính. Callback phiên của host phải dùng auth/CSRF hiện có khi M5 tích hợp; callback fixture cố định chỉ dùng dữ liệu synthetic qua loopback. Không nhận đây là đăng nhập chuyên gia thật hoặc triển khai production.

M3 không kiểm A/B30 câu, hai doanh nghiệp cùng public release hay quy tắc hưởng chính sách; đó là M4/M5/M6 theo dependency. Chưa tự cập nhật Internet hằng ngày, không mở iHanoi, framework worker hoặc embedding.

Truy vết: DF-013/014/017/021/027/029/030/031/033/034/041/043/044/046/048/049/053/054/055/056/057; tất cả lớp liên quan còn D1. [Sổ RCA](<../architecture/DESIGN_FLAWS.md>), [review candidate1](<../../../REFERENCE_LINKS.md#ref-0060>), [D06](<../../../REFERENCE_LINKS.md#ref-0061>).

## Bổ sung sau qualification và S1 thật

Candidate3 qua269ca author,31ca độc lập và một ca directGateway bổ sung; mobile độc lập320px đã chạy được bằng Playwright CLI. Đây là nghiệm thu hữu hạn, không là xác nhận pháp lý hay MAIN deployment. [Review](<../../../REFERENCE_LINKS.md#ref-0062>) giữ cả lịch sử giới hạn và đính chính.

**DF-058:** một approval phải gắn đúng một DB path+instance UUID ngoài mọi candidate directory. Registry chỉ sealed delegation, không giữ counter hay có SDK; giữ tiền/đếm lượt/dispatch vẫn qua Gateway SQL. Copy DB sang staging khác không tạo quyền mới. Không claim chống rollback toàn máy hoặc operator thay cả DB/registry.

**DF-059:** đầu ra model là assertion, không tự xác định loại bằng chứng. Sau exact verification quote/ID/span/READ, adapter `proposal-admission/2` chỉ có thể hạ `source_excerpt` không literal thành `interpretation`; giữ modelkind/output/raw nguyên gốc và cảnh báo mọi diễn giải chưa kiểm ngữ nghĩa. Không nâng diễn giải thành trích nguồn; không cứu quote sai hoặc schema rejected. Bản projection chờ chuyên gia, không auto-apply/review/publish. Proposal v1 đã commit được trả theo bản gốc trước khi derive recipe mới.

**DF-056:** lỗi/handoff chưa xong dừng trên lifecycle grant, không chỉ `break` hay existence của proposal. Operator append event `batch_paused_admission`, active→paused; không ghi đè revoked/needs_reconciliation. READ/free recovery không unpause. Restart hoặc directGateway vẫn bị authority chung chặn trước paid; không tạo service phí thứ hai.

Lượt S1 thật dùng6833input/1617outputtokens, ước tính0,029836USD, có5nhận định và9câu trích khớp corpus. Bốn câu tổng hợp bị model gắn nhầm source_excerpt; cả5nhận định còn cần chuyên gia kiểm ngữ nghĩa và đủ nguồn. Batch dừng, không dùng Sonnet/Opus còn lại làm lượt sửa. Grant gốc có expiry07:40:33 ngày29/10/2026(UTC+7); pause không gia hạn.

[Bàn giao](<03_Ban_giao_M3.md>) ghi candidate cuối, bằng chứng recovery và phần còn mở. M3 không thay app8025, chưa tự thực hiện M4/M5.
