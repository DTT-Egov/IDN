# M3 — từ nguồn công khai đến nháp tri thức chờ chuyên gia

27/10/2026. Workbench là bàn biên soạn của chuyên gia; chưa thay app doanh nghiệp8025. Ảnh bên dưới là dữ liệu thử riêng, không giả thành quyết định của chuyên gia Trung. Kết quả Claude thật được trình riêng ở cuối.

## 1. Mở đúng bản, đọc căn cứ và sửa

Hàng đợi chỉ trả trang trong quyền được giao. Mở trang thấy số bản, trạng thái rà/phát hành, nội dung và căn cứ. Editor/xem trước trên cùng cột; control tối thiểu44px, không tràn ngang ở320px.

![Editor mobile320px — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0063>)

## 2. Giữ nháp, tải lại mà không ghi đè bản chuẩn

Đổi tiêu đề rồi giữ nháp riêng. Tải lại mở đúng trang và nháp của người đó; bản chuẩn vẫnBản1. Ghi bản wiki là lệnh riêng có kiểm phiên bản. Nếu ai đã sửa bản chuẩn, không tự gộp hoặc bỏ nháp cũ.

![Nháp trở lại sau tải lại — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0064>)

Giới hạn UX còn mở: dấu nháp khác bản chuẩn đang dùng chung với cảnh báo rời trang, nên đôi khi đã giữ nháp server vẫn có cảnh báo. Dữ liệu không mất; cần tách hai trạng thái khi tích hợp app chính.

## 3. Rà bản cụ thể, rồi mới phát hành

Người có quyền nhập căn cứ rà. Quyết định gắn đúng nội dung, bản và phiên bản nguồn. “Đã duyệt” chưa có nghĩa là đã phát hành. Nút phát hành tạo quyết định riêng, kể cả reviewer/publisher là cùng người.

![Đã duyệt nhưng chưa phát hành — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0065>)

![Phát hành riêng — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0066>)

Nguồn chưa đủ toàn văn/hiệu lực hoặc thiếu xác minh thì không được vượt cửa này. Ảnh là fixture có điều kiện giả lập đủ để kiểm giao dịch; nguồn Hà Nội thật hiện chưa được reviewer thật duyệt.

## 4. Ngừng phát hành, giữ lịch sử

Ghi lý do rồi ngừng phát hành; tải lại vẫn hiển thị đã ngừng và số bản. Không xóa nội dung hoặc quyết định cũ. Thu hồi READ nguồn vẫn chặn xem dẫn xuất; chỉ cất/ngừng phát hành không mặc định xóa quyền lịch sử.

![Ngừng phát hành sau tải lại — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0067>)

## 5. Lỗi dễ nhận biết

Thiếu lý do rà hiển thị lỗi tiếng Việt bằng vùng cảnh báo; bản chuẩn giữ nguyên. Thông báo có vùng đọc cho trình đọc màn hình. Đã kiểm thuộc tính và DOM, chưa kiểm âm thanh bằng thiết bị đọc thật.

![Lỗi xác nhận — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0068>)

Reviewer độc lập thực hiện toàn chuỗi trên320×740, console0lỗi/0cảnh báo và model attempts0. [Báo cáo mobile](<../../../REFERENCE_LINKS.md#ref-0069>) nêu đúng build và các giới hạn; không dùng ảnh này làm bằng chứng app8025 đã tích hợp.

## 6. Claude thật tạo nháp Phụ lục03

Người dùng duyệt batch6lượt/tổng2USD. Đã gửi **đúng1Sonnet**, chỉ các trích đoạn public đã lưu: Phụ lục03, Nghị định80/2021 và Thông tư06/2022. Không gửi hồ sơ doanh nghiệp hoặc tài chính.

S1 trả5nhận định/9câu dẫn khớp chữ. Bốn nhận định tổng hợp bị model tự gắn nhãn “trích nguyên văn”, khiến admission ban đầu từ chối. Batch dừng ở đây: chưa dùng Opus hoặc5slot còn lại. Phí tokenước tính **0,029836USD**, không phải hóa đơn.

Bản sửa giữ nguyên raw/data/usage và modelkind. Chỉ phần projection chờ chuyên gia được hạ thành “diễn giải”; không sửa câu trích, nguồn, vị trí hoặc quyền để làm cho qua. Cả5diễn giải cần kiểm ngữ nghĩa; đặc biệt câu suy ra công việc của cán bộ từ Bước2 bị cắt chưa đủ căn cứ. Quote khớp không chứng minh suy luận đúng hoặc chính sách còn hiệu lực.

Hạn mức đã pause bền vững. Đã phục hồi proposal từ S1 bằng bản sửa cuối, không mở batch hoặc gọi AI. Raw/data/usage, nguồn và input manifest giữ nguyên, không ghi SSOT hoặc tạo quyết định chuyên gia. [Bàn giao](<03_Ban_giao_M3.md>), [nháp cho chuyên gia](<04_Nhap_AI_S1_cho_chuyen_gia.md>) và [biên nhận phục hồi](<../../../REFERENCE_LINKS.md#ref-0070>).

Reviewer thử riêng giao diện cảnh báo trên frozen5 bằng dữ liệu synthetic: cả nhãn AI sai lẫn diễn giải nguyên gốc đều ghi rõ chưa kiểm chứng. Chuyển vào wiki chỉ tạo bản nháp, chưa duyệt/phát hành. Ảnh này kiểm UI cảnh báo, không phải ảnh S1 thật hay hành động của chuyên gia Trung.

![Cảnh báo diễn giải trên frozen5,320px — dữ liệu thử](<../../../REFERENCE_LINKS.md#ref-0071>)

[Đối soát S1 sau phục hồi độc lập](<../../../REFERENCE_LINKS.md#ref-0072>):1attempt,1proposal,0wiki page,0review/release, raw/data/usage hashes giữ nguyên và grant vẫn paused. Reviewer chỉ đọc, không gọi AI hoặc ghi dữ liệu.

## 7. Dừng ở mốc M3

SQL giữ bản chuẩn; Markdown là tài liệu xem/chia sẻ có truy vết. Chưa phát hành chính sách thật, chưa bật tư vấn điều kiện hưởng, chưa tự lên lịch Internet, chưa thay app8025. M4–M5 cần kiểm tiếp trước khi doanh nghiệp dùng tri thức này.

Thiết kế truy vết: DF-005/033(câu trích/vị trí), DF-049(schema/operator), DF-056(dừng batch), DF-057/058(phê duyệt), DF-059(model assertion/projection). [Sổ nguyên nhân](<../architecture/DESIGN_FLAWS.md>).
