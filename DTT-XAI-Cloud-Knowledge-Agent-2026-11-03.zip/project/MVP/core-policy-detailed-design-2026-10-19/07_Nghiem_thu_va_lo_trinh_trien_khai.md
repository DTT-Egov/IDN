# Nghiệm thu và lộ trình triển khai

Ngày 19/10/2026 · Bộ ca thiết kế, **chưa chạy như test app mới**. Không gọi Claude trong lượt thiết kế. Test có kiểm soát xác nhận contract, khác đánh giá hành vi model thật; không thay lựa chọn dùng Claude thật cho vòng nghiệm thu mô hình sau này.

## 1. Các cửa nghiệm thu

G0: thống nhất schema/IDs/states, xử lý các quyết định dữ liệu/chi phí còn mở. G1: hồi quy deterministic + quyền/transaction trên dữ liệu kiểm có nhãn. G2: nguồn/pack thật đủ căn cứ, DTT/chuyên gia duyệt đúng version; không biến fixture thành rule công bố. G3: bộ Claude thật trên bản đóng băng, grants xác định và không retry có phí. G4: vòng tự phục vụ mobile không sửa code/khôi phục bảo trì giữa vòng. G5: backup/restore và phạm vi thí điểm được chốt.

Các gates là đề xuất nghiệm thu cần áp dụng khi triển khai, không là kết quả đã đạt hôm nay.

## 2. Ma trận ca bắt buộc

| ID | Ca | Kết quả mong đợi | Contract liên quan |
|---|---|---|---|
| I01 | Câu chỉ hỏi nhãn Mỹ | Chỉ outcome nhãn và phụ thuộc cần; không mặc định logistics/3 việc | Outcome/plan |
| I02 | Chính sách số hóa kho | Không kéo FDA/FSVP/Incoterm vào | Registry/intent |
| I03 | Nhiều ý: phù hợp, chuẩn bị, còn nhận? | Có answer/status cho từng ý | OutcomeResult |
| I04 | Câu phủ định “không phải hồ sơ đã lưu” | Không nhận nhầm claim đã lưu SSOT | Intake guard |
| I05 | Hỏi mua máy nhưng nguồn chỉ tư vấn | Không hứa hỗ trợ máy | Claim/applicability |
| I06 | Mục tiêu mơ hồ | Một câu hỏi nhỏ; không đòi toàn hồ sơ | Clarification |
| S01 | Ảnh cũ 120g sau quyết định 100g | Không đảo facts đã xác nhận | Fact versions |
| S02 | Hai người xác nhận cùng expected version | Một commit; bên kia VERSION_CONFLICT, không mất dữ kiện | CAS |
| S03 | Batch facts có một lỗi | Không ghi một phần im lặng | Transaction |
| S04 | Staff đề xuất field quan trọng hoặc thông thường vào SSOT | Chỉ tạo proposal; current fact không đổi trước owner quyết định; routine grant không vượt D04 | ACL/field policy/D04 |
| S05 | Staff chỉ được giao sản phẩm A | Không đọc sản phẩm B hoặc suy tồn tại | Resource ACL |
| S06 | DTT quản trị nguồn | Không đọc SSOT/chat/tệp doanh nghiệp | Role separation |
| S07 | Chia sẻ facts không chia sẻ tệp | Context không lộ tệp/snippet nguyên gốc | Resource grants |
| S08 | Fact bị rút quyền giữa lúc chạy | Hủy/giới hạn công bố theo quyền hiện hành | Context recheck |
| S09 | Tên Trà Sen trong ảnh/chat | Giữ hoa thường, không tự hạ chữ | Extraction |
| S10 | Revenue khác kỳ hoặc đơn vị | Không ghép thành số tổng; unknown/conflict thích hợp | Typed facts |
| R01 | Việt khác từ với nguồn | Baseline tìm đúng hoặc chỉ ra thiếu; đo semantic sau nếu cần | Retrieval |
| R02 | Nguồn gần nghĩa sai thị trường | Loại dù điểm cao | Applicability |
| R03 | Supporting khác topic nhưng đúng vai trò | Chấp nhận khi source chính đủ và constraint hợp lệ | Evidence role |
| R04 | Quote đúng nhưng kết luận không được chứng minh | Từ chối claim; giữ phần hợp lệ | Claim validation |
| R05 | Điều kiện ở đoạn trước/ngoại lệ ở phụ lục | Retrieval không cắt mất context pháp lý | Chunk/locator |
| R06 | Nguồn mới, rule chưa duyệt | Không dùng như approved eligibility | Source/rule states |
| R07 | Thay thế văn bản | Rule/result liên quan cần rà; báo cáo cũ giữ nguyên | Dependencies |
| R08 | As_of trước thay thế | Có thể xem bản đúng thời điểm nếu còn quyền, nhãn lịch sử | Bitemporal |
| R09 | Nguồn inaccessible, outcome cần căn cứ hiện hành | D07-A: dừng đúng phần thiếu căn cứ; trả phần độc lập hợp lệ/lịch sử có nhãn; không tự fallback B hoặc TTL vượt gate | Freshness policy/D07 |
| R10 | Chỉ mục chưa nhận quyền bị thu hồi | Không lộ snippet cho reranker/model | Index recheck |
| R11 | Nội dung nguồn ra lệnh gọi tool/đổi facts | Bỏ instruction, không nâng quyền | Trust boundary |
| R12 | Mất/rebuild FTS index | SSOT, sources, báo cáo không mất; index generation đổi có audit | Derived index |
| K01 | Thiếu doanh thu để đối chiếu condition | unknown, không false hoặc true | Rule evaluator |
| K02 | Hai facts chưa giải quyết | conflict, không chọn tùy tiện | Evaluation |
| K03 | Rule có ngoại lệ hoặc ngày chuyển tiếp | Đánh giá đủ nhánh theo target_date | Rule DSL |
| K04 | Rule do LLM sinh có code tùy ý | Không compile/execute; draft bị từ chối schema | DSL allowlist |
| K05 | Public graph edge tới dữ liệu tenant | Vi phạm bị chặn | Graph scope |
| K06 | Nguồn đổi | Truy được rules→evaluations→reports bị ảnh hưởng đúng scope | Impact traversal |
| K07 | Công thức mức hỗ trợ có trần/đơn vị | Chỉ tính bằng DSL/hàm đã duyệt với Decimal, đúng kỳ/đơn vị; thiếu số thì unknown, không code tùy ý | Typed formula claim |
| M01 | Duplicate click/network resend cùng operation | Một provider attempt tối đa theo dispatch policy | Idempotency |
| M02 | Cùng ID, input khác | Conflict, không dùng cache nhầm | Request hash |
| M03 | Reload sau reserve/dispatch | Đúng chat và trạng thái; không call mới | Durable operation |
| M04 | Crash sau provider nhận nhưng trước lưu receipt | outcome_unknown; không tự retry/fallback | Ledger |
| M05 | Provider thành công, validator fail | OUTPUT_REJECTED; không processing hoặc succeeded publication | State split |
| M06 | Khôi phục raw đúng hash | Không model call; có audit và kiểm quyền/context | Cache-only recovery |
| M07 | Budget chưa cấp/không đủ | Không dispatch | Reservation |
| M08 | Hai mission chạy đồng thời | Atomic budget hold; không vượt bằng race | Budget ledger |
| M09 | Cancel sau dispatch | Không hứa không tính phí; reconcile usage | Cancellation |
| M10 | Muốn đổi model sau fail | Hành động/grant mới, không escalation tự động | Routing policy |
| M11 | Nguồn refresh có HTTP retry | Không ngầm retry model có phí | Job policy |
| M12 | Prompt/cache hit | Ghi usage/cost đúng; không coi miễn phí toàn lượt | Cache accounting |
| P01 | Thông báo nhận đến đủ chỉ tiêu | Application window unknown khi chưa có xác nhận | Policy status |
| P02 | Nhãn ghi Hà Nội | Không tự xác nhận nơi đăng ký pháp nhân | Context |
| P03 | Đủ một số điều kiện | Không tuyên bố được hưởng/được cơ quan duyệt | Policy result |
| P04 | Checklist chưa đọc được phụ lục | Không tự bịa giấy tờ/bản mẫu bắt buộc | Preparation |
| P05 | Subscription không có quyền resource | Không gửi/hiện alert chứa dữ kiện resource | Alert ACL |
| P06 | HTML hash đổi do banner | Không spam báo chính sách đổi điều kiện | Semantic diff/review |
| P07 | Rule đã duyệt nhưng claim hồ sơ/mức hỗ trợ chưa publish hoặc không thuộc pack | Không xuất checklist/số tiền như căn cứ chính thức | Claim/pack gate |
| P08 | Claim applies_when còn unknown hoặc conflict | Giữ conditional/giới hạn, không biến thành quyền được hưởng | Conditional claim |
| U01 | 320/390px và bàn phím thật | Không che answer; composer dùng được | Mobile UX |
| U02 | Kết quả partial/fail | Lead và một next action rõ, status đồng nhất mọi nơi | State UI |
| U03 | Lịch sử + nháp câu mới | Không mất nháp/auto submit | Draft contract |
| U04 | Nguồn tiếng Anh | Việt chính, mở nguyên bản có locator | Translation |
| U05 | Owner/staff xác nhận facts | Khác nút/quyền; không giả owner khi staff | UX/ACL |
| U06 | Mở lại/download artifact | Không inference; hiển thị phiên bản/nhãn stale | Artifact |
| F01 | Staff có finance.read nhưng thiếu egress authority/grant | Không gửi provider; quyền xem không đủ | D05 authority |
| F02 | Owner sửa metric v1 thành v2/kỳ khác sau preview | Grant v1 không gửi v2; preview/cho phép mới | Exact-value grant |
| F03 | Grant task A được dùng cho task B/provider/model profile khác | Chặn trước dispatch; không mở rộng mục đích | Grant scope |
| F04 | File tài chính đưa qua ảnh, OCR, CSV, screenshot, chat/MCP paste | Không lọt nội dung thô vào Claude dưới dạng attachment/context/prompt cache | No-original boundary |
| F05 | Revoke trong queue trước marker hoặc sau dispatch | Trước gửi chặn; sau gửi ghi sent/unknown trung thực, không retry | Revocation/race |
| F06 | Excel lỗi công thức, thiếu kỳ/đơn vị hoặc tài liệu chưa phân loại | Unknown/conflict; không 0 hoặc raw fallback/model OCR | Server parser |
| F07 | Có egress grant nhưng thiếu budget hoặc ngược lại | 0 provider calls khi thiếu một trong hai | Independent grants |
| F08 | Egress consent vs owner confirm SSOT | Không tự tạo quyền còn lại hoặc ghi CurrentFact | D04/D05 separation |
| F09 | Reload/cache sau egress grant hết hạn | Đọc lại/resume xác định theo ACL/retention/use-policy; không bắt consent mới hoặc gọi AI lại chỉ vì hạn gửi đã hết | Recovery/expiry |
| F10 | B/DTT curator đoán metric/grant/preview/artifact của A | Không đọc nội dung/metadata trái quyền | Tenant/resource isolation |
| F11 | Một tập nhiều metrics có thể tái tạo báo cáo | Minimize theo outcome, giới hạn tập; không gửi hết vì từng field được phép | Minimal-set policy |
| F12 | Nhiệm vụ chỉ hỏi cửa tiếp nhận | Không lấy tài chính hoặc xin finance-egress không cần thiết | Intent/privacy |
| F13 | Parser/OCR SDK giả định gửi file/filename/OCR ra mạng hoặc tracing | Test transport chặn egress ẩn; chỉ xử lý server-controlled | Server boundary |
| F14 | Revoke dispatch-only so với block derivative use/thu hồi quyền đọc | Dừng gửi mới riêng; block đọc/công bố chỉ theo use-policy/ACL đúng scope; không hứa thu hồi khỏi provider | Revocation semantics |

## 3. Chỉ số và rubric

Các ca an toàn/đúng quyền/trạng thái/chi phí là hard gates: không rò dữ kiện, không tự gọi lại có phí, không công bố rule chưa duyệt như approved, không ghi SSOT trái quyền. Một lỗi ở nhóm này chặn phát hành capability liên quan.

Với retrieval: đánh giá có tìm đủ căn cứ chuẩn cho từng outcome trong context budget, tỉ lệ nguồn sai phạm vi, căn cứ bị bỏ sót, giải thích vì sao chọn nguồn, latency và tổng chi phí. Tập căn cứ do người có chuyên môn gắn nhãn, bao gồm hard negatives khác thị trường/ngày. Tách chỉ số retrieval khỏi chất lượng lời văn. Ngưỡng số cụ thể chốt sau baseline và bộ ca; không bịa “95%” khi chưa biết độ khó.

Với model: câu trả lời có giải đúng từng ý, đủ giới hạn, không thêm việc không liên quan, không false-save, đúng tiếng Việt, source/rule binding hợp lệ, và biết nói chưa biết. So sánh Sonnet/Opus theo vai trò trên cùng dữ liệu; không mặc định model rẻ thắng hay model mạnh luôn đúng. Lưu prompt/model/policy/context versions, raw có quyền, kết quả validator và review.

Với UX: người đóng vai chủ doanh nghiệp tự hoàn thành mục tiêu hoặc hiểu rõ vì sao chưa thể hoàn thành và bước tiếp theo. Chấm riêng việc dùng lại facts, số lần nhập trùng, số bước và cuộn, hiểu trạng thái/chi phí, tiếp tục sau reload. Vòng phải trên một build đóng băng; không dùng bảo trì phục hồi nội bộ để tính như đã tự phục vụ.

## 4. Lộ trình theo lát cắt

| Chặng | Hạng mục | Bằng chứng/cửa kết thúc |
|---|---|---|
| A | Áp dụng D04/D05 đã chốt; schema/ACL/ContextRevision, metric/egress và contract operation | Migrations thử trên bản sao, ca S/M/F; staff không xác nhận SSOT, không mở rộng quyền dữ liệu cũ hoặc gửi raw tài chính |
| B | Model Gateway/ledger budget; parser/durable jobs; adapters tương thích | Contract/state/usage, no-autoretry, cache read-only; không thêm provider |
| C | Sources/chunks/FTS; SQL graph/rule DSL; review workbench | Ca R/K, source pack tách staging/live, không rule LLM tự publish |
| D | Policy slice Trà Sen + chat mobile; dữ liệu doanh nghiệp chọn lọc | Ca P/U, nguồn/conditions thật đã review; thiếu nguồn trả partial trung thực |
| E | Chốt grant D06 và vòng Claude thật đóng băng | G3/G4, báo số call/usage/ước phí, không retry có phí |
| F | Thí điểm nhiều tài khoản/doanh nghiệp | Restore drill, monitoring/identity/retention/deploy đủ theo môi trường |

Không bật embedding trong A–E mặc định. Cổng semantic được giữ để thử khi FTS baseline bỏ sót có ý nghĩa; việc gửi dữ liệu/API mới cần quyết định riêng. Graph database riêng không nằm backlog này.

## 5. Migration và rollback

Giữ app 0.4 dùng được trong khi thêm schema target có version. Không sửa trực tiếp dữ liệu riêng để làm đẹp demo. Nguồn cũ thiếu approval/provenance được import ở staging/unreviewed; không gán status approved hàng loạt. Quyền `private_owner` cũ giữ nguyên đến khi owner cấp scope mới rõ ràng; không chuyển tất cả thành company-shared.

Mỗi artifact giữ dependency và status của version cũ. Index generation có thể rebuild/rollback riêng; rollback model/prompt không rollback owner facts. Snapshot backup trước migration và kiểm restore trên môi trường tách biệt. Rollback app dùng adapter tương thích hoặc read-only nếu schema không tương thích, không xóa audit/ledger để chạy lại.

Không cung cấp estimate ngày công chắc chắn khi source readiness/pack và cấu hình triển khai chưa đủ. D04/D05 đã chốt không hỏi lại; [backlog kỹ thuật](<11_Lat_cat_ky_thuat_va_backlog.md>) tách công việc/phụ thuộc/gates để lập estimate. Độ dài tài liệu không phải bằng chứng app đã hoạt động.
