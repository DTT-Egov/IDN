# Lát cắt kỹ thuật và backlog từ thiết kế

Ngày 19/10/2026 · Thiết kế triển khai để review; **chưa thực thi backlog**. D04/D05 đã chốt. Không thêm graph/vector DB, provider hay embedding; mọi call thật sau này vẫn cần ngân sách cụ thể D06.

## 1. Bản cắt nhỏ đầu tiên

Một doanh nghiệp dùng chung SSOT theo quyền; nhân viên đưa ảnh sản phẩm/Excel được hỗ trợ vào và đề xuất; owner xác nhận facts. Trong cùng chat, câu hỏi chính sách Hà Nội dùng context tối thiểu và nguồn/rule/claim được duyệt/phát hành. Nếu cần chỉ tiêu tài chính, server xử lý theo D05 và chỉ gửi tập được cho phép. Nếu thiếu nguồn/rule, trả gap thay vì đòi toàn bộ hồ sơ hoặc dùng dữ liệu mẫu như thật.

Lát cắt đầu **không cần đọc mọi dạng báo cáo tài chính**. Intake tài chính `.xlsx` bắt đầu với cấu trúc bảng được nhận diện/mapping được người có quyền kiểm: metric, value, unit/currency, reporting period, entity scope. Alias headers theo registry, không đoán bằng model. Parser/OCR server không có đường upload/telemetry nội dung ra ngoài; SDK cloud gọi từ server không đáp ứng D05. File khác/scan/công thức không đủ căn cứ báo khoảng trống; nhập chỉ tiêu có kiểu tại server là đường bổ sung, không gửi file để AI giải mã.

## 2. Module và ranh giới ghi

| Module đích | Trách nhiệm | Không tự làm |
|---|---|---|
| `core/contracts` | DTO/version/errors, operation/outcome/task/brief/result | Cấp quyền từ JSON client/model |
| `core/authorization` | Membership, resource/field scopes, quyền egress/spend riêng | Mở tài nguyên cũ vì vừa có vai staff |
| `core/ssot` | Observation/proposal/resolution, owner CAS, bitemporal/context | Dùng model để ghi facts đã chọn |
| `core/operations` | Conversation linkage, outbox/lease/fence/checkpoint/status | Replay provider call sau marker |
| `knowledge/sources` | Registry/snapshot/chunk/translation/observation/diff | Tự phát hành rule từ nguồn mới |
| `knowledge/retrieval` | FTS/alias/gates/coverage/evidence và ContextBundle | Dùng topic/score thay applicability |
| `knowledge/rules` | DSL hữu hạn, typed claims, review/publish/pack manifest | Thực thi code tùy ý từ LLM |
| `finance/metrics` | Parser, Decimal, quality flags, lineage/minimization | Claude vision/OCR hoặc gửi raw-equivalent |
| `finance/egress` | Preview, authority, exact-value grant, seal/revoke | Suy consent từ SSOT/budget hoặc sửa facts |
| `models/gateway` | Registry/route/estimate/budget/once-dispatch/receipt | Retry/fallback/repair có phí tự động |
| `capabilities/hanoi_policy` | Outcomes, plan, match/evaluation/preparation/window | Tạo hồ sơ doanh nghiệp thứ hai |
| `presentation` | Lead Việt, one next action, sources/draft/history | Ghép các biến trạng thái khác nhau thành spinner giả |

Đây là tổ chức đề xuất trong modular monolith; không bắt buộc tạo mọi thư mục mới hoặc tách service. Adapter các API hiện có có thể gọi các repository mới theo từng chặng, không rewrite toàn app một lần.

## 3. Các work package và cửa kiểm

| ID | Việc cụ thể | Phụ thuộc | Bàn giao để review | Cửa kiểm |
|---|---|---|---|---|
| B01 | Khóa DTO/error/status IDs, scope keys và mapping legacy | D04/D05 | Contracts/version matrix | JSON/type/compatibility; không đổi nghĩa cache |
| B02 | Thêm ACL/resources và SSOT/CAS/context snapshot | B01 | Additive migration + repository + owner/staff UI | S01–S10; không mở sharing cũ, routine staff bị khóa |
| B03 | Operation/outbox/ledger/fence và budget | B01 | Worker và unified status endpoints | M01–M12; crash/reload không orphan/paid replay |
| B04 | Source canonical/chunk/FTS và query/result | B01/B02 | Index generation, gates, trace và coverage | R01–R12; source scope/date/ACL đúng |
| B05 | Rule DSL/typed claims/review/publish/pack | B04 | Review workbench, manifests, SQL graph queries | K/P và release constraints; chuyên gia thật chịu trách nhiệm |
| B06 | Financial metrics và exact egress grant | B02/B03 | Parser mapping, lineage/preview/authority/serializer | F01–F14; không raw-equivalent/egress ẩn, không consent ngầm |
| B07 | Policy capability + chat integration | B03/B04/B05 | Flow Trà Sen với partial/gap honest, sources Việt | I/P/U; D07-A đã chốt, chặn phần thiếu căn cứ hiện hành, không tự fallback B |
| B08 | Chuyển adapter/shadow/migration rehearsal | B02–B07 theo phạm vi | Mapping/backfill report, rollback/read-only plan | Không mất IDs/facts/owner decisions/dispatch markers |
| B09 | Frozen-build real acceptance và thí điểm | Pack review, D06 và cấu hình dữ liệu/deploy; D07-A đã chốt | Walkthrough + số call/usage/chi phí và review độc lập | Tự phục vụ không sửa giữa vòng; không retry có phí |

Không định số ngày công chắc chắn hoặc trần USD khi chưa có workload/nguồn đủ và cấu hình triển khai. B01–B08 không tự cho phép bắt đầu gọi Claude cho tests. Các ca contract bằng dữ liệu kiểm có nhãn không được báo thành đánh giá mô hình thật.

## 4. MCP tài chính trong cùng lõi

| Tool thiết kế | Phía server kiểm | Tác dụng |
|---|---|---|
| `finance_v1.prepare_metrics` | Read resource/format/classification, parse limits; không LLM | Tạo operation liên kết chat và metric observations/proposals, quality gaps |
| `finance_v1.get_metric_preview` | Finance/resource/field read và mục đích/task | Preview đúng tập typed metrics, không tài liệu gốc; không provider call |
| `finance_v1.authorize_metric_egress` | Read + explicit egress authority, expected metric/preview versions, purpose/profile | Ghi grant và receipt exact manifest; không SSOT write/dispatch |
| `finance_v1.revoke_metric_egress` | Authority hiện hành đúng grant/resource, expected version | Dừng dispatch tương lai; không tự xóa/chặn lịch sử chỉ vì hết hạn/thu hồi quyền gửi. Block sử dụng dẫn xuất/quyền đọc là action riêng có scope/audit |
| `core_v1.confirm_facts` | Owner D04 + resource scopes/CAS | Ghi SSOT theo proposals; không tự cấp egress grant |
| `core_v1.start_mission` | Plan/context version + exact egress refs nếu có + budget riêng | Enqueue các bước đã cấp; no-retry và recheck trước dispatch |

Không xuất tools tùy ý “gửi tài liệu tài chính cho model”. Tool tài chính không nhận provider request body hoặc consent do model tự kê. Server lấy principal từ auth, xây manifest, giữ hash và scope của payload; arguments là refs để xác thực. Tạo chat–operation–metric refs nguyên tử hoặc qua job/outbox có idempotency; không để frontend gọi riêng “tạo ca” và “gắn ca”.

`start_mission` có thể nhận `financial_metric_egress_grant_ids` như tham chiếu, không nhận quyền tự khai hoặc inline financial DTO để bỏ qua preview. ID hợp lệ nhưng khác operation/task/value version trả lỗi trước dispatch. Các trạng thái read/list/get đều không enqueue model.

## 5. Hai sequence cần kiểm

**Dữ kiện tài chính thiếu:** capability xác định metric cần → server đọc/tính nếu có quyền → unknown khi thiếu kỳ/đơn vị → hỏi một nhóm nhỏ → owner xác nhận SSOT nếu dùng như fact chuẩn → preview chỉ tiêu/phân loại tối thiểu → người có quyền cho egress → budget → Gateway dispatch → validate/publish. Những bước local không tạo model call ẩn.

**Chỉ hỏi cửa tiếp nhận:** intent/window → retrieval nguồn hiện hành → open/closed/unknown có căn cứ/ngày kiểm → trả lời. Không đọc tài chính, không xin egress finance hoặc yêu cầu điền bảng DNNVV khi outcome không cần. Nếu có tổng hợp model thì vẫn budget/once-dispatch; có thể dùng template xác định cho trạng thái ngắn.

## 6. Gate để chuyển sang viết app

Contracts/DDL logic/retrieval/Gateway đã có baseline; D04/D05/D07-A đã được chốt và áp dụng vào policy/ca kiểm. D06 chỉ trình khi có bộ ca/giá/token/call counts thật. Retention và danh tính review/publisher là cấu hình thí điểm bắt buộc, không tự điền người hoặc thời hạn giả. Việc khóa quyết định sản phẩm không tự tạo ngân sách hoặc approval cho pack thật.

Trước viết migration production phải lập schema inventory/diff cụ thể với app hiện tại; các bảng trong tài liệu là thiết kế đích, không được chạy thẳng như script migration. Việc người dùng chốt thiết kế không tự tạo grant xem dữ liệu thật, chia sẻ file cũ, chi tiêu hoặc gửi thông báo ra ngoài.
