# Agent chính sách Hà Nội — thiết kế nghiệp vụ và lát cắt demo

Ngày 19/10/2026 · Thiết kế, chưa triển khai/duyệt bộ quy tắc thật. Nguồn Internet được khảo sát để chọn hướng demo; không phải kết luận doanh nghiệp được hỗ trợ.

## 1. Việc agent giúp doanh nghiệp làm

Từ mục tiêu kinh doanh và SSOT có quyền, tìm hướng hỗ trợ để xem xét, giải thích điều kiện nào đã có căn cứ/thiếu/chưa xác nhận, chuẩn bị danh sách hồ sơ và bước kiểm tra tiếp theo. Không tự nộp, tự đại diện, cam kết được duyệt hoặc biến thông báo chương trình thành quyền được nhận tiền.

Lát cắt đề xuất: **Trà Sen muốn số hóa quản lý kho và chuẩn bị mở rộng thị trường**. Tìm chương trình tư vấn liên quan, đối chiếu thông tin doanh nghiệp, hỏi ít dữ kiện cần thiết và tạo bản chuẩn bị. Đây là hướng demo được đề xuất; không bật subscription/cảnh báo hay gọi AI trong lượt thiết kế.

## 2. Khảo sát nguồn chính thức và giới hạn

| ID khảo sát | Nguồn | Đã xác nhận trong lượt khảo sát | Việc còn phải làm trước phát hành rule |
|---|---|---|---|
| HN-NOTICE-2026-14 | [Thông báo chương trình tư vấn 2026](https://hotrodoanhnghiep.hanoi.gov.vn/TinTuc/_ChiTietBaiViet?Id=118908&type=tintuc) | Trang chính thức nêu chương trình tư vấn giải pháp chuyển đổi số; nhận đăng ký phụ thuộc chỉ tiêu | Lấy bản ký/phụ lục; xác minh thủ tục/điều kiện và tình trạng tiếp nhận hiện tại; chưa gán approved |
| HN-SME-SCHEME-5418 | [Đề án theo Quyết định 5418](https://datafiles.hanoi.gov.vn/gov-hni/6244/VanBan/2025/11/3/De%20an%20QD-5418-2025.pdf) | Có bản được chỉ mục và được thông báo trên viện dẫn | Tải/đọc toàn văn: công cụ duyệt web timeout ở lượt này; không dùng nội dung chỉ mục làm exact evidence |
| VN-SME-80 | [Trang Nghị định 80/2021/NĐ-CP](https://vanban.chinhphu.vn/default.aspx?docid=203941&pageid=27160) và [PDF ký](https://datafiles.chinhphu.vn/cpp/files/vbpq/2021/08/80.signed_01.pdf) | Xác nhận metadata và tài liệu kèm trên cổng Chính phủ | Rà toàn văn, sửa đổi/hợp nhất/hiệu lực theo ngày mục tiêu; đọc được metadata không có nghĩa mọi điều khoản còn nguyên |
| HN-DIGITAL-PLAN-232 | [Kế hoạch chuyển đổi số DNNVV 2026–2030](https://hanoi.gov.vn/chi-dao-cua-ubnd-thanh-pho-ha-noi/ke-hoach-chuyen-doi-so-cac-doanh-nghiep-nho-va-vua-giai-doan-2026-2030-4260619080730298.htm) | Có kết quả chỉ mục trên cổng Thành phố | Trang/PDF timeout khi mở; chỉ là đầu mối khảo sát, không dùng để khẳng định mức hỗ trợ/đủ điều kiện |

Ngày kiểm: 19/10/2026. Với HN-NOTICE-2026-14, ngày văn bản và ngày đăng trang là hai metadata khác nhau. Thông báo “đến khi đủ chỉ tiêu” không xác nhận cửa tiếp nhận còn mở vào ngày hỏi. Phụ lục chưa đọc được không được suy ra từ thông lệ. Thiết kế không sao chép mức tiền hay thủ tục từ kết quả tìm kiếm làm rule thật.

Đề xuất ưu tiên nguồn thông báo + phụ lục chương trình tư vấn để làm pack đầu; các văn bản nền và chương trình khác bổ sung khi đã đủ nguồn/duyệt. Không gán chương trình tư vấn thành hỗ trợ mua máy đóng gói. Những nhóm chuyển giao công nghệ, sở hữu trí tuệ, xúc tiến thị trường là hướng khảo sát tiếp, chưa là capability đã có rule.

## 3. Ba trạng thái phải tách

1. **Căn cứ:** nguồn nào, phiên bản nào, ngày hiệu lực nào, thay đổi/chờ rà hay đã duyệt quy tắc.
2. **Doanh nghiệp:** mỗi điều kiện đạt/không đạt/chưa biết/xung đột, trên facts nào; tự khai khác đã kiểm chứng độc lập.
3. **Chương trình:** còn nhận, chưa mở, đã đóng, chưa xác minh; ngân sách/chỉ tiêu là dữ kiện biến động, có ngày kiểm riêng.

Kết quả `potential_match` không bằng `eligible` và không bằng `application_open`. V1 không phát hành nhãn “được hưởng”; chỉ có “hướng cần xem xét”, “chưa đủ dữ kiện”, “chưa đủ nguồn/quy tắc”, “không phù hợp theo điều kiện đã kiểm” hoặc “cần chuyên gia/cơ quan xác nhận”.

## 4. Intent và outcome

Câu tham chiếu: “Tôi muốn số hóa quản lý kho Trà Sen. Có chương trình Hà Nội nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?”

| Outcome | Đầu ra | Yêu cầu căn cứ |
|---|---|---|
| O1 policy_discovery | Hướng chương trình liên quan, lý do và giới hạn | Đúng mục tiêu, địa bàn, nguồn công bố có provenance; nếu chưa rule duyệt chỉ giới thiệu có nhãn |
| O2 eligibility_and_preparation | Bảng điều kiện + facts + thiếu gì; checklist tài liệu được chứng minh | Rule đã duyệt với nguồn chính; không biến checklist chung thành yêu cầu chính thức |
| O3 application_window | Trạng thái tiếp nhận và mốc kiểm | Nguồn cập nhật/thông báo có thẩm quyền; “đến đủ chỉ tiêu” chưa đủ để khẳng định còn mở |

Nếu câu chỉ hỏi “còn nhận hồ sơ không”, không tự yêu cầu cả doanh thu, lao động và nhãn Mỹ. Nếu không nêu mục tiêu, hỏi một câu để phân biệt tư vấn công nghệ, số hóa hay thị trường; không đưa form đầy đủ ngay.

## 5. Context và thu thập dữ kiện

Các facts sản phẩm đã xác nhận được dùng lại, gồm tên giữ nguyên hoa thường, thành phần, lượng tịnh. Có nhãn ghi Hà Nội không tự chứng minh pháp nhân đăng ký tại Hà Nội. Không suy ra DNNVV từ chữ “cơ sở”, “nhỏ” hay từ số dòng Excel.

Theo đúng rule cần đánh giá, lấy hoặc hỏi: loại hình pháp lý, nơi đăng ký/hoạt động, ngành/lĩnh vực, mục tiêu hỗ trợ; tiếp theo mới tới kỳ tài chính, doanh thu/nguồn vốn/lao động, nội dung hợp đồng tư vấn hoặc lịch sử nhận hỗ trợ nếu điều khoản thật yêu cầu. Không hỏi số liệu nhạy cảm chỉ để làm đầy hồ sơ. Mỗi facts cần legal period, unit, provenance và trạng thái xác nhận.

Tài chính là nhóm hạn chế, chỉ owner hoặc người được cấp quyền rõ; staff có quyền xem vẫn chỉ đề xuất, owner xác nhận facts nghiệp vụ theo D04. D05 đã chốt: parser/tính toán tại server; chỉ typed metrics/phân loại tối thiểu có egress grant được gửi Claude, không workbook/ảnh tài chính/OCR hoặc raw-equivalent. Câu hỏi chỉ cần địa bàn/tình trạng tiếp nhận không đọc hoặc xin tài chính. [Hợp đồng D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>) quy định authority, preview và value version; không đủ parser/kỳ/đơn vị thì hỏi chỉ tiêu, không model đọc bản gốc.

## 6. Plan và tác nhân có giới hạn

| Capability/task | Loại thực thi | Input | Output |
|---|---|---|---|
| resolve_context | SQL/hàm | Auth + selected resources + outcomes | ContextRevision có quyền và các khoảng trống |
| understand_intent | LLM nếu cần | Câu hỏi + context tối thiểu | OutcomeSpec được kiểm với nguyên văn |
| discover_policy_candidates | Retrieval | Intent, VN-HN, target_date | Nguồn/chương trình ứng viên và trạng thái |
| select_reviewed_rules | SQL | Candidates + as_of + review state | RuleVersion hoặc lý do chờ |
| evaluate_conditions | DSL/hàm xác định | RuleVersion + confirmed facts | Bốn trạng thái và dependency bindings |
| verify_application_window | Retrieval/nguồn manual đã xác minh | ProgramID + ngày mục tiêu | open/closed/not_yet_open/unknown + nguồn/ngày kiểm |
| prepare_response | LLM tùy nhu cầu | Findings đã kiểm, không cấp quyền mới | Kết luận Việt, giới hạn, next actions |
| publish | Hàm + giao dịch | Validated result + revisions | Answer/artifact và audit |

Đây là các task, không phải tám call Claude. V1 có thể dùng một lượt hiểu intent và một lượt tổng hợp có grant riêng; câu hỏi rõ/tác vụ đọc lại có thể không cần lượt hiểu mới. Routing và số call dự kiến được quyết trước dispatch, không biến đánh giá chất lượng thành vòng lặp có phí.

## 7. Contract kết quả minh họa

```json
{
  "schema_version": "hanoi-policy-result/1",
  "mission_id": "mission_example",
  "context_revision_id": "ctx_example",
  "context_snapshot_id": "ctx_snapshot_example",
  "target_date": "2026-10-19",
  "status": "partially_answered",
  "lead_vi": "Có hướng tư vấn số hóa cần xem xét; chưa đủ căn cứ xác nhận phù hợp và còn nhận hồ sơ.",
  "policy_candidates": [{
    "policy_id": "program_example",
    "policy_version_id": "policy_example_v1",
    "pack_version_id": "pack_example_draft",
    "pack_release_event_id": null,
    "claim_version_ids": [],
    "match_status": "potential_match",
    "rule_status": "awaiting_review",
    "eligibility_status": "not_assessed",
    "application_status": "unknown",
    "application_checked_at": null,
    "source_refs": ["source_snapshot_example"],
    "condition_results": []
  }],
  "outcomes": [
    {"outcome_id": "o_match", "status": "partially_answered", "claim_ids": ["claim_example"]},
    {"outcome_id": "o_prepare", "status": "awaiting_rule_review", "missing_inputs": []},
    {"outcome_id": "o_window", "status": "needs_source", "reason_code": "QUOTA_STATUS_UNCONFIRMED"}
  ],
  "next_actions": [{"action_id": "check_window", "outcome_ids": ["o_window"], "kind": "verify_official_source", "label_vi": "Xem cách kiểm tra tình trạng tiếp nhận"}],
  "automatic_submission": false
}
```

Tất cả IDs là minh họa; không lưu như bản chính sách thật. Response chỉ công bố phần đã qua kiểm. `condition_results` cho rule đã duyệt chứa `condition_id`, `state=met|not_met|unknown|conflict`, `fact_version_refs`, `evidence_refs`, `explanation_vi`, `missing_fact_keys`. Owner xác nhận không tự biến fact thành đã xác minh bởi cơ quan.

## 8. Cập nhật, duyệt và cảnh báo

Jobs đọc nguồn chính thức đã đăng ký có lịch theo từng loại nguồn; HTTP có retry giới hạn, không tự gọi model có phí. Snapshot mới → diff/đánh giá ảnh hưởng → rule draft → reviewer DTT/chuyên gia → publisher phát hành pack version. Nếu nguồn có dấu hiệu thay đổi điều kiện, rule bị ảnh hưởng chuyển cần rà; không giữ tư vấn hiện hành chỉ vì version cũ từng được duyệt.

Thông tin công bố mới có thể hiển thị dưới nhãn chưa duyệt, nhưng không dùng như kết luận đủ điều kiện. Nếu nguồn hết hiệu lực, không dùng làm căn cứ hiện hành; lịch sử/as_of vẫn đọc được nếu còn quyền. D07-A đã chốt 19/10/2026: dừng riêng outcome/claim thiếu căn cứ hiện hành, vẫn trả phần độc lập hợp lệ và lịch sử có nhãn. Mất kết nối khác hết hiệu lực; không tự dùng TTL hay phương án B để khuyên mới từ bản lưu chưa đạt yêu cầu kiểm. Xem [ma trận D07](<12_Chinh_sach_nguon_va_phat_hanh_D07.md>).

Cảnh báo thiết kế V1 chỉ trong app, theo subscription/outcome/resource và quyền hiện hành; không hiện nhóm dữ liệu nhạy cảm trên thông báo chung. Dedupe theo enterprise + subscription + event + policy version; không phát hàng loạt chỉ vì hash HTML thay đổi. Các kênh gửi ngoài và mức chủ động còn chờ người dùng chốt; không gửi email/Zalo hoặc tạo automation trong đợt này.

## 9. Demo và kiểm chứng

Fixture hợp đồng phải có watermark “dữ liệu kiểm thử”; nguồn/rule giả chỉ ở môi trường kiểm, không lẫn catalog thật. Với nguồn thật chưa duyệt, demo trung thực trạng thái chờ và phần thiếu; không thay bằng rule giả để tạo vẻ đủ điều kiện.

Vòng Claude thật chỉ sau khi có bộ rules/nguồn đủ, quyền dữ liệu và grant chi phí cụ thể. Không gọi AI để hoàn thành tài liệu này. Các ca bắt buộc: intent số hóa khác logistics; hỏi mua máy không tự thành tư vấn; công bố chương trình nhưng quota unknown; legal place unknown; hai nhân viên khác scope; owner thay facts; nguồn thay thế; rule chờ duyệt; outcome có phần không trả được; đọc lại không phí.
