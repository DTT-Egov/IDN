# 03 — Retrieval và vòng đời tri thức

Ngày thiết kế: 19/10/2026. Trạng thái: **thiết kế đích, chưa triển khai**. Tài liệu này đặc tả cách tìm và cấp căn cứ cho các agent nMate, dùng SQL/SQLite và FTS5 làm nền. Chưa bật embedding API, reranker AI, vector database hoặc graph database riêng.

Tài liệu đi cùng [SSOT và knowledge graph trên SQL](<02_SSOT_va_SQL_Knowledge_Graph.md>), [Model Gateway](<04_Model_Gateway_va_van_hanh.md>) và [agent chính sách Hà Nội](<05_Agent_chinh_sach_Ha_Noi.md>). Nếu tên vật lý hoặc trường legacy khác, lớp chuyển đổi phải giữ nguyên ID và provenance; không suy ra dữ liệu hiện tại đã được chuyển sang schema này.

## 1. Kết quả hệ thống phải cung cấp

Retrieval trả về một **gói căn cứ theo từng outcome**, không trả một đống đoạn văn gần nghĩa rồi để mô hình tự chọn điều kiện. Gói này phải trả lời được:

1. Căn cứ nào liên quan đến ý người dùng đang hỏi?
2. Đúng doanh nghiệp, domain, thị trường, thẩm quyền và ngày mục tiêu không?
3. Đây là nguồn gốc đã tiếp nhận, quy tắc đã được duyệt hay nguồn mới còn chờ duyệt?
4. Có điều kiện, ngoại lệ, phụ lục hay văn bản sửa đổi nào cần đọc kèm?
5. Agent được dùng căn cứ này để khẳng định điều gì và chưa được khẳng định điều gì?
6. Bản trả lời sử dụng đúng phiên bản nào, có thể tái dựng và kiểm lại không?

Một câu hỏi có thể có một hoặc nhiều outcome. Không cố định ba việc; không gắn IOR/FSVP, Incoterm hoặc xuất khẩu vào câu hỏi chính sách chỉ vì doanh nghiệp đã từng làm tác vụ xuất khẩu.

Ví dụ thiết kế, **không phải kết luận về chính sách đang có hiệu lực**: chủ cơ sở Trà Sen muốn tìm hỗ trợ mua thiết bị và chuẩn bị hồ sơ. Hai outcome có thể là `identify_support_to_consider` và `prepare_application_checklist`. Retrieval phải tìm căn cứ về đối tượng, điều kiện, phạm vi chi, mức hỗ trợ, thời điểm, cách nộp và hồ sơ tương ứng. Nếu mới tìm được mức hỗ trợ nhưng chưa có căn cứ về đối tượng, kết quả là thiếu căn cứ; không suy ra doanh nghiệp thuộc đối tượng.

## 2. Quyết định kiến trúc

| Quyết định | Thiết kế |
|---|---|
| Kho chuẩn | SQL lưu nguồn, phiên bản, trích đoạn, điều kiện áp dụng, review, quyền và phụ thuộc |
| Facts doanh nghiệp | Lấy có cấu trúc từ SSOT bằng ID/phạm vi, không tìm gần nghĩa để quyết định facts chuẩn |
| Baseline retrieval | Metadata + quan hệ SQL + FTS5 + alias có phiên bản |
| Embedding | Chỉ có port hợp đồng; adapter mặc định `disabled`, không tạo vector hay gửi nội dung ra ngoài |
| Graph | Quan hệ điều khoản–quy tắc–điều kiện–fact–kết luận trên SQL; retrieval dùng các quan hệ được cho phép |
| Tính thẩm quyền | Chỉ mục là dẫn xuất; kết quả được nạp lại và kiểm qua SQL chuẩn |
| Cập nhật | Nguồn tự cập nhật theo lịch/trigger đã cấu hình; quy tắc tư vấn mới hoặc thay đổi phải qua DTT/chuyên gia duyệt |
| Quyền | Kiểm trước tìm, khi cấp context và trước công bố; `as_of` không khôi phục quyền đã bị thu hồi |
| Tính phí | Baseline local không gọi mô hình; dịch, OCR AI, embedding, rerank AI hoặc tìm kiếm API có phí phải qua Model Gateway và grant riêng |

FTS5 là cơ chế tìm toàn văn của SQLite, có hỗ trợ phrase, prefix và xếp hạng. Đây là nền kỹ thuật để dựng baseline, không tự giải quyết hiểu tiếng Việt/Đức/Nhật hoặc kiểm chứng pháp lý. Khi triển khai phải kiểm build SQLite thực tế có FTS5; không cài extension tùy ý theo nội dung tài liệu. [Tài liệu SQLite FTS5](https://www.sqlite.org/fts5.html)

```mermaid
flowchart TB
    Q["Outcome + ngày mục tiêu"] --> A["Quyền hiện hành + Context Resolver"]
    A --> P["Kế hoạch truy xuất có phiên bản"]
    P --> F["Facts chuẩn theo ID"]
    P --> R["Lọc nguồn/rules theo scope và thời gian"]
    R --> K["FTS + alias + quan hệ SQL"]
    K --> V["Nạp lại dữ liệu chuẩn\nkiểm quyền, phiên bản và applicability"]
    F --> E["Gói căn cứ theo outcome"]
    V --> E
    E --> G["Agent nghiên cứu / đối chiếu điều kiện"]
    G --> C["Kiểm trích dẫn, quyền và context trước công bố"]
```

## 3. Nguồn, snapshot và quy tắc là các đối tượng khác nhau

### 3.1. Mô hình dữ liệu logic

| Bảng | Khóa và nội dung tối thiểu | Bất biến |
|---|---|---|
| `source_registry` | `source_id`, tên nguồn/cơ quan, URL hoặc định danh manual/MCP, loại nguồn, domain, thẩm quyền, thị trường, ngôn ngữ, scope sử dụng, cấu hình cập nhật | Một định danh nguồn có thể có nhiều snapshot; URL không phải định danh phiên bản |
| `source_snapshots` | `source_snapshot_id`, `source_id`, `resource_id`, `enterprise_id` nếu riêng, bytes gốc/tham chiếu blob, MIME, `raw_sha256`, text đã trích, `extraction_version`, `text_sha256`, trạng thái, thời gian và provenance | Bất biến sau tiếp nhận; sửa lỗi extraction tạo phiên bản dẫn xuất mới, không đổi bytes gốc |
| `source_chunks` | `chunk_id`, `source_snapshot_id`, thứ tự, title/section path, original text/span, locator, `span_hash`, language, parent/neighbor refs, metadata áp dụng | Chỉ phục vụ một snapshot và extraction version; không ghép câu từ nhiều phiên bản vào một chunk |
| `source_translations` | `translation_id`, `source_snapshot_id`, `chunk_id` nếu dịch từng chunk, language pair, text dịch, alignment, hash, method/model profile, review state | Dẫn xuất từ nguyên bản cụ thể; không tự mang trạng thái nguồn pháp lý hoặc quy tắc đã duyệt |
| `source_observations` | `observation_id`, source/snapshot, trigger, fetch/check result, previous hash, candidate hash, diff summary, actor/service, thời gian | Mọi lần kiểm có kết quả riêng, kể cả không truy cập được; không sửa thời gian công bố của nguồn |
| `source_supersessions` | cạnh từ source/snapshot cũ sang nguồn thay thế, relation type, căn cứ, thời gian áp dụng, reviewer/status | Redirect hoặc trang biến mất chưa chứng minh văn bản hết hiệu lực |
| `knowledge_rule_versions` | `rule_version_id`, `policy_version_id`, scope, conditions, `review_state`, `publication_state`, usage gate và validity states | Được đặc tả ở tài liệu SSOT/SQL graph; chỉ quy tắc approved + published + usable, đúng hiệu lực được dùng đối chiếu hiện hành |
| `knowledge_evidence_bindings` | `rule_version_id`, mệnh đề/điều kiện, snapshot/chunk/span, vai trò, giới hạn sử dụng | Có source hợp lệ chưa đủ; binding phải chứng minh mệnh đề đang xét |
| `knowledge_claim_versions` | `claim_version_id`, `policy_version_id`, `claim_type`, payload schema/hash, `applies_when`, rule/condition refs nếu có, review/publication/availability states, valid time | Amount/formula/preparation/procedure có cấu trúc; không ép thành field SSOT để đọc được thủ tục hoặc quyền lợi |
| `knowledge_claim_evidence_bindings` | `claim_version_id`, snapshot/chunk/locator/quote/hash, evidence/argument roles | Mỗi mệnh đề hoặc checklist item có căn cứ riêng; không lấy citation chung để bịa danh sách giấy tờ |
| `knowledge_pack_versions` và member/release tables | `pack_version_id`, members policy/rule/claim, publication event refs, `pack_release_event_id`, manifest hash, publication/availability states | Policy assessment chỉ dùng pack đã published + usable, release và member/hash khớp; quy tắc/claim vẫn qua gate riêng |
| `knowledge_index_generations` | `index_generation_id`, analyzer/alias/extraction versions, loại chỉ mục, trạng thái, watermark | Có thể hủy và dựng lại từ dữ liệu chuẩn |
| `knowledge_index_entries` | `index_entry_id`, generation, chunk, indexed hash, partition key, sync state | Một entry không tự cấp quyền đọc chunk |
| `retrieval_runs` | `retrieval_run_id`, mission/task/outcome, `context_revision_id`, `context_snapshot_id`, request/plan hash, policy/pack/index versions, timing và trạng thái | Trace thuộc phạm vi nhiệm vụ; không biến câu hỏi riêng thành dữ liệu công cộng |
| `retrieval_candidates` | run, candidate refs, thứ hạng, lý do nhận/loại, gate results, evidence role, hashes | Nội dung và lý do chứa dữ kiện riêng phải giữ quyền riêng; không lộ ID tài nguyên không có quyền trong UI/log chung |

Trường lớn có thể lưu blob tại chỗ hoặc vùng file được kiểm quyền; quyết định vật lý không thay đổi hợp đồng. `resource_id` là điểm gắn ACL với kho tài nguyên dùng chung. Nguồn công khai không có `enterprise_id`; điều này **không có nghĩa** mọi tài liệu có URL đều được phép đưa vào kho công khai.

`policy_version_id` định danh một phiên bản chính sách được quy tắc tham chiếu. `pack_version_id` định danh bộ phát hành có thể chứa nhiều policy/rule versions nếu cần; không thay ID của từng chính sách. `retrieval_policy_version` là phiên bản cấu hình thuật toán và các gate của retrieval. Ba trường không được dùng thay nhau.

`context_revision_id` là revision hồ sơ doanh nghiệp. `context_snapshot_id` là bộ dữ kiện/refs tối thiểu bất biến đã giải quyền cho mission/task cụ thể. Cùng revision có thể có nhiều snapshot khác scope/quyền; retrieval không nhận riêng revision rồi tự coi đó là toàn bộ prompt snapshot.

Các quan hệ FK quan trọng: `source_chunks → source_snapshots → source_registry`; translation → snapshot/chunk; evidence binding → exact chunk + rule version; retrieval candidate → snapshot/chunk/rule; artifact dependency → retrieval run và context revision. Quan hệ nguồn có phạm vi riêng không được trỏ thành binding công cộng nếu chưa có quy trình phát hành và quyền sử dụng độc lập.

### 3.2. Phân biệt các loại thời gian

| Trường | Ý nghĩa |
|---|---|
| `published_at` | Ngày nguồn được cơ quan công bố, có thể chưa biết |
| `effective_from`, `effective_until` | Khoảng hiệu lực đã được xác định bằng căn cứ; không suy từ ngày đăng bài |
| `application_window_from/until` | Thời gian nhận hồ sơ hoặc đợt chương trình, nếu khác hiệu lực văn bản |
| `retrieved_at` | Lúc hệ thống lấy bytes |
| `checked_at` | Lần kiểm nguồn; không tự gia hạn hiệu lực pháp lý |
| `reviewed_at`, `review_due_at` | Duyệt quy tắc và hạn cần rà theo loại nguồn/rủi ro |
| `recorded_at` | Lúc hệ thống ghi nhận một thông tin về hiệu lực hoặc thay thế |
| `as_of` | Ngày nghiệp vụ người dùng cần xét |
| `known_at` | Mốc dùng để tái dựng hệ thống biết gì khi lập báo cáo, mặc định hiện tại |

Khoảng thời gian nội bộ dùng quy ước `[from, until)` và kiểu rõ ràng. Văn bản ghi “đến hết ngày” được chuyển đổi bởi quy tắc ngày đã duyệt, giữ nguyên biểu đạt gốc. Ngày chưa biết là `null/unknown`, không thay bằng ngày lấy dữ liệu. Hạn nộp hồ sơ còn cần giờ và múi giờ địa phương khi nguồn quy định; UI dùng thống nhất `dd/mm/yyyy` và hiển thị múi giờ nếu cần.

Truy vấn lịch sử có thể chọn hiệu lực cũ, nhưng quyền truy cập luôn là quyền hiện tại. `known_at` phục vụ audit, không cho phép cố tình bỏ qua thông tin hết hiệu lực đã biết để tư vấn hiện tại. Báo cáo gốc giữ nguyên kết luận tại thời điểm công bố; phần cảnh báo hiện hành là lớp bổ sung, không viết đè lịch sử.

## 4. Tiếp nhận và chia đoạn có thể kiểm chứng

### 4.1. Ba đường tiếp nhận

| Đường | Provenance phải giữ | Hạn chế |
|---|---|---|
| Internet trong danh mục nguồn | URL gốc/cuối, redirect chain, HTTP result, hash, thời gian, service trigger, tên cơ quan, link văn bản gốc nếu có | Allowlist domain/đường dẫn; kiểm redirect/IP/MIME/dung lượng; trang web là dữ liệu không tin cậy |
| Manual | Người tải lên, doanh nghiệp hoặc kho domain đích, thời gian, bytes gốc, tên file gốc, mô tả nguồn, quyền sử dụng được khai, phiên bản tham chiếu | Nhãn “chuyên gia tải lên” không tự chứng minh tính đúng hoặc công khai; không chạy macro/script |
| MCP | Connector/tool/version, principal của kết nối, thời gian, resource ID từ hệ nguồn, scope/grant, payload hash, URL gốc nếu hệ nguồn cung cấp | Kết quả tool không được tự đổi quyền/consent; quyền của connector không thay quyền người dùng trong nMate |

Pipeline: tiếp nhận vào staging → quét/kiểm định dạng → lưu bytes bất biến → extract có phiên bản → nhận diện cấu trúc/metadata → kiểm phạm vi và chất lượng → chia đoạn → lập chỉ mục dẫn xuất → đối chiếu quan hệ/rule phụ thuộc → đưa phần cần thiết vào hàng đợi review. Mọi bước có trạng thái bền vững; cùng bytes và cấu hình đã xử lý không tạo lại lượt dịch AI có phí.

Nếu connector cần credential, registry chỉ giữ secret reference, không giữ khóa trong URL/mô tả nguồn hoặc chunk. URL đưa vào UI/log được loại thông tin xác thực và token nhạy cảm; request headers/connector grant không trở thành nội dung truy xuất. Secret storage và rotation thuộc Model Gateway/lớp tích hợp.

Không OCR/dịch bằng mô hình như tác dụng phụ mặc định của refresh. Nếu không đọc được tài liệu, ghi `extraction_required` hoặc `unreadable`; chờ phương án parser/chi phí đã duyệt. Không báo nguồn đã được nghiên cứu chỉ vì download thành công.

### 4.2. Chunk theo ý nghĩa cấu trúc

- Với văn bản chính sách: giữ điều/khoản/điểm, tiêu đề, phần định nghĩa, ngoại lệ, tham chiếu và phụ lục. Không cắt giữa điều kiện và chữ phủ định hoặc ngoại lệ. Chunk lớn được chia tiếp nhưng có `parent_chunk_id` và danh sách đoạn bắt buộc đọc kèm.
- Với bài hướng dẫn: giữ đoạn, đề mục và liên kết văn bản được viện dẫn. Bài hướng dẫn không thay thế văn bản gốc khi kết luận điều kiện cần căn cứ gốc.
- Với bảng: giữ tiêu đề bảng, tên cột, đơn vị, dòng và chú thích. Ô “10” không có cột/đơn vị không được cấp làm chứng cứ mức hỗ trợ.
- Với PDF/ảnh: locator có trang, bbox nếu parser hỗ trợ, thứ tự đoạn và extraction version. OCR không rõ dấu/giá trị phải đánh dấu, không tự tạo chính xác giả.
- Với Excel riêng: chunk phải giữ sheet, range, header, đơn vị, công thức/giá trị quan sát và quyền tài liệu. Đây là dữ liệu của doanh nghiệp; không dùng như nguồn chính sách công khai.

Locator ví dụ: `{ "type": "section_span", "section_path": ["Điều X", "Khoản Y"], "start": 231, "end": 674, "text_version": "extract-v1" }`. Offset là trong bản text canonical đã lưu; page/section giúp người đọc đối chiếu với nguyên bản. Không tuyên bố offset ký tự trong text trích xuất là offset byte trong PDF.

### 4.3. Hash và hợp đồng trích dẫn

Giữ các lớp riêng: `raw_sha256` cho bytes gốc; `text_sha256` cho text extraction cụ thể; `quote_original_hash` cho UTF-8 của exact quote; `span_hash` niêm phong cả snapshot ID, extraction version, locator và exact quote bằng canonical encoding đã version hóa. Các hash dùng SHA-256 trong bản đầu. Quy tắc normalize để index không được áp lên quote gốc. `quote_original` phải khớp chính xác span của text version đã lưu, bao gồm phạm vi được chọn. Nếu cần bỏ đoạn giữa để trình bày, lưu danh sách span, không tạo một quote giả liền mạch.

Một evidence binding đủ gồm:

```json
{
  "source_snapshot_id": "demo-source-A-v1",
  "chunk_id": "demo-chunk-A-04",
  "locator": {"section_path": ["Điều X", "Khoản Y"], "start": 231, "end": 674},
  "extraction_version": "extract-v1",
  "quote_original": "Đoạn mẫu dùng kiểm hợp đồng; không phải nội dung chính sách thật.",
  "quote_original_hash": "<sha256-of-exact-original-quote>",
  "span_hash": "<sha256-of-versioned-span-manifest>",
  "translation_id": null,
  "supports_claim_id": "condition-enterprise-scope",
  "evidence_role": "primary",
  "argument_role": "supports",
  "rule_version_id": "demo-rule-A-v1"
}
```

`evidence_role=primary|supporting` thể hiện vai trò căn cứ; `argument_role=supports|exception|definition|context` thể hiện vai trò trong lập luận. Hai trục theo mệnh đề, không phải giấy phép bỏ kiểm. `supersession` là quan hệ/version metadata có căn cứ và review riêng, không phải evidence role thứ ba. Nguồn bổ trợ chỉ được dùng cho vai trò đã duyệt, với điều kiện có căn cứ chính cần thiết. Một điều về trách nhiệm thông tin có thể bổ trợ câu trả lời nhãn; không tự chứng minh nghĩa vụ đăng ký. Không chặn đúng bằng chứng chỉ vì topic label khác; cũng không chấp nhận trích dẫn chỉ vì ID/hash đúng.

### 4.4. Tiếng Việt trước, xem nguyên bản khi cần

Tìm kiếm có thể dùng cả nguyên bản và bản dịch đã gắn alignment. Context phải phân biệt rõ `quote_original` với `rendered_vi`. UI trả lời tiếng Việt; nút “Xem nguyên bản” mở đúng đoạn/nguồn có quyền, không mở toàn bộ tệp riêng ngoài phạm vi.

Bản dịch có method, version, hash và review state. Dịch máy chưa duyệt được gắn nhãn tương ứng, không trở thành nguyên văn pháp lý. Nếu khác biệt dịch ảnh hưởng điều kiện, số tiền, hạn, chữ phủ định hoặc ngoại lệ, dừng kết luận phần đó để rà. Không tự phát sinh lượt dịch mới có phí. Với nguồn tiếng Việt không cần dịch, `translation_id=null`; không chế tạo bản tiếng Anh.

## 5. Lọc phạm vi trước tìm và kiểm lại trước sử dụng

### 5.1. Predicate bắt buộc

Server dựng `RetrievalPolicy` từ danh tính đã xác thực, membership/ACL hiện hành, capability, MissionSpec và ContextRevision. Nội dung câu hỏi hay agent không được tự đặt `enterprise_id`, quyền đọc hoặc trạng thái quy tắc.

| Nhóm | Ví dụ predicate |
|---|---|
| Quyền | tài nguyên công cộng hợp lệ hoặc resource có grant hiện hành; domain curator không có quyền đọc tệp doanh nghiệp chỉ vì phụ trách review |
| Domain | export, Hanoi policy; cross-domain chỉ khi mệnh đề cần và capability cho phép |
| Thị trường/thẩm quyền | US khác DE/JP; chính sách Hà Nội cần scope Hà Nội và thẩm quyền/cơ quan thực hiện thích hợp |
| Thời gian | hiệu lực và cửa nhận hồ sơ đúng `as_of`; unknown không mặc định hiện hành |
| Duyệt/phát hành | nguồn được tiếp nhận khác với rule/claim được duyệt; đánh giá bằng `hanoi_policy.assess` bắt buộc pack published + usable, release manifest đúng và member rule/claim approved + published + usable |
| Trạng thái | không quarantine, revoked, blocked hoặc confirmed superseded cho tư vấn hiện hành |
| Quyền sử dụng nội dung | không vượt giới hạn manual/license/connector hoặc purpose được cấp |

Facts doanh nghiệp được cấp từ `context_snapshot_id`, gắn `context_revision_id` và nhóm facts liên quan; không đưa toàn bộ hồ sơ, tài chính, tên nhân viên hay chat vào tìm toàn văn chỉ để tìm chính sách. Quan hệ với huyện/xã, quy mô hoặc loại hình doanh nghiệp chỉ dùng khi cần xác định phạm vi. Chưa biết phạm vi thì trả gap hoặc hỏi lại; không fallback sang Mỹ hoặc sang chính sách cấp khác.

`source_discovery` có thể tìm nguồn/chương trình thô chưa có pack, để giới thiệu đầu mối và phần cần review. Chế độ này không được tạo evaluation đủ điều kiện, khẳng định quyền lợi cá nhân hóa hoặc checklist chính thức. `reviewed_policy_assessment` bắt buộc server giải được pack/release/manifest đủ chuẩn; thiếu pack trả `RULE_REVIEW_REQUIRED`/gap, không tự hạ sang discovery rồi giữ nhãn đã đánh giá.

### 5.2. ACL và chỉ mục

Kho public có partition riêng. Chỉ mục private được tách theo enterprise; tài nguyên riêng owner/team vẫn bị lọc theo ACL trong enterprise. Không dùng BM25 hoặc autocomplete trên corpus gộp nhiều doanh nghiệp. Với baseline nhỏ, server tạo tập `eligible_chunk_id` trước, chấm điểm deterministic chỉ trên tập có quyền; FTS chỉ tạo ứng viên nội bộ, không xuất count/title/snippet/score của tài nguyên không có quyền. Nếu dùng thống kê xếp hạng của partition enterprise thì không lộ score thô, vocabulary hoặc tổng số hit cho người chỉ có quyền một phần. Trường hợp yêu cầu chống side channel mạnh hơn cần partition theo security scope hoặc bộ rank trong eligible set; không dựa vào `WHERE enterprise_id` đơn thuần rồi tuyên bố cách ly hoàn toàn.

Payload gửi tới LLM chỉ được nạp từ eligible canonical rows sau kiểm ACL. Cùng quy tắc áp dụng semantic adapter về sau: tenant filter trong vector request chỉ là lớp đầu, không thay canonical authorization.

Các cổng kiểm:

1. **Trước retrieval:** kiểm quyền và scope; truy vấn chỉ chạy với eligible IDs/partition đã cấp.
2. **Trước ContextBundle:** nạp lại source/rule/fact từ SQL; kiểm ACL, hash, state và version; giảm dữ liệu theo nhiệm vụ.
3. **Trước publication:** recheck ACL/context dependencies và rule/source state hiện hành. Quyền bị thu hồi hoặc source bị chặn giữa lúc Claude đang chạy thì kết quả tương ứng không được công bố.
4. **Khi mở lại/download:** quyền hiện hành, không chỉ quyền tại lúc tạo artifact. Báo cáo cũ có thể còn lịch sử nhưng người đã bị thu hồi quyền không đọc được.

Đổi membership/ACL tạo invalidation event. Không để kết quả cache hoặc browser nháp cấp lại quyền cũ. Trace chi tiết không được chia sẻ rộng hơn nguồn mà trace chứa.

## 6. Pipeline retrieval không cần embedding

### 6.1. Kế hoạch theo outcome

`RetrievalPlan` có các nhánh nhỏ, mỗi nhánh phục vụ mệnh đề hoặc nhóm điều kiện cụ thể. Agent có thể đề xuất từ khóa, nhưng server compiler kiểm phạm vi, mức chi tiết, query count, thời gian và tool. Không để prompt tự cung cấp SQL hoặc FTS expression tùy ý.

Trình tự:

1. Đọc OutcomeSpec, target date và entities đã chọn; phân biệt câu hỏi về chính sách với câu hỏi áp dụng vào doanh nghiệp.
2. Resolver lấy facts chuẩn cần dùng theo ID; thiếu fact thì ghi unknown, không dùng từ ngữ trong câu hỏi thay cho xác nhận.
3. Tạo bộ mệnh đề cần bằng chứng: đối tượng, điều kiện/ngoại lệ, mức hỗ trợ, hồ sơ, nơi/thời hạn nộp… chỉ lấy phần outcome yêu cầu.
4. Lấy các rule versions và nguồn đủ quyền/phạm vi từ SQL; mở rộng quan hệ định nghĩa/ngoại lệ/sửa đổi đã đăng ký.
5. Tìm exact ID/tên văn bản/điều khoản trước; tiếp theo phrase/keyword và alias; nạp nguyên bản/bản dịch đã được phép.
6. Xếp hạng theo relevance có giải thích; ưu tiên căn cứ chính cho mệnh đề, không mặc định bài mới hơn hay đoạn dài hơn là đúng hơn.
7. Nạp các đoạn bắt buộc đọc kèm, kiểm applicability và binding; loại duplicate theo snapshot + span, giữ đủ phiên bản để giải thích xung đột.
8. Tạo coverage matrix theo outcome; nếu thiếu điều kiện thì trả gap. Mô hình tổng hợp không được tự điền từ trí nhớ như căn cứ đã truy xuất.

Khi outcome hỏi quyền lợi, công thức, hồ sơ hoặc thủ tục, bước 4 lấy thêm `knowledge_claim_versions` và `knowledge_claim_evidence_bindings`, đúng `claim_type=amount|formula|preparation|procedure`. Claim phải thuộc pack đang dùng, cùng policy version đã khai; review/publication event phải đúng claim hash + evidence-set hash, release phải đúng manifest/member hashes. Không đủ một gate thì không cấp claim như nội dung đã duyệt.

`applies_when_mode=policy_scope` chỉ cho giải thích chung trong scope với nhãn tham khảo. `rule_met` chỉ cá nhân hóa khi root eligibility đạt và mọi loại trừ cần kiểm đã xác định không áp dụng; loại trừ còn unknown/conflict chưa cho phép cá nhân hóa quyền lợi. `condition_met` cần condition chỉ định đạt cùng gate rule, không vượt ngoại lệ/loại trừ. Unknown/conflict giữ giới hạn, không chuyển thành quyền lợi chắc chắn. Formula dùng AST đã duyệt và hàm xác định, thiếu input/đơn vị/kỳ trả `not_calculable`; retrieval không chạy code do nguồn hoặc mô hình đề xuất. Preparation/procedure chỉ có item/step được payload và evidence chứng minh; nguồn thiếu người nộp, hạn hay giấy tờ thì ghi thiếu, không tự dựng checklist.

### 6.2. Alias và đa ngôn ngữ

`alias_set_version` chứa alias được quản trị theo domain/language: cách nói đời thường, tên viết tắt, thuật ngữ và từ không dấu. Giữ nguyên tên sản phẩm “Trà Sen” khi hiển thị; normalization chỉ áp dụng cột index. Không lower-case facts hoặc text UI.

Ví dụ alias phục vụ tìm, **không phải tương đương pháp lý**: “hỗ trợ mua máy” → nhóm truy vấn “thiết bị”, “máy móc”, “đổi mới công nghệ”; kết quả vẫn phải kiểm phạm vi chi được hỗ trợ. “Doanh thu” khác “lợi nhuận”; “chứng nhận” khác “đăng ký”; mở rộng alias không được gộp các khái niệm này để kết luận.

Tiếng Việt có dấu/không dấu dùng hai đường query được kiểm; tiếng Anh dùng thuật ngữ/nguyên văn; tiếng Đức và Nhật dùng alias curated và đoạn dịch có nguồn. Không giả định cùng một tokenizer xử lý mọi ngôn ngữ tốt. Khi coverage thấp, ghi `language_coverage_gap`; có thể đề xuất nghiên cứu/dịch bổ sung, chưa tự bật embedding. Punctuation và ký hiệu pháp lý được compiler quote/escape; dùng bind parameters, giới hạn độ dài/số term và số lần truy vấn.

### 6.3. Ranking và độ đầy đủ

Baseline dùng thứ tự ưu tiên có phiên bản: exact source/section match → binding đã duyệt cho claim → phrase/alias relevance → keyword relevance → giới hạn số đoạn trùng. Freshness, authority và applicability là gate/metadata, không cộng điểm để hợp thức hóa nguồn sai scope.

Các score không được diễn giải là “độ đúng 90%”. `retrieval_confidence` nếu có chỉ mô tả khả năng tìm đúng ứng viên trong bộ đánh giá, không xác suất được hưởng chính sách. Không công bố “không có chính sách” chỉ vì top-k không có hit; diễn đạt “chưa tìm thấy trong phạm vi nguồn đã kiểm” và liệt kê phạm vi/gap.

Một gói có thể có nhiều primary evidence cho nhiều điều kiện và supporting evidence có giới hạn. Coverage hoàn thành đòi tất cả nhóm căn cứ bắt buộc của outcome, không chỉ số chunk đạt một ngưỡng. Ngoại lệ và văn bản sửa đổi có thể cần ưu tiên hơn việc tăng top-k.

## 7. Hợp đồng truy vấn và kết quả

### 7.1. `RetrievalQuery.v1`

Request phía agent chỉ mang đề xuất phạm vi. Envelope quyền, enterprise và resource scope do server chèn sau xác thực. JSON sau là **hợp đồng nội bộ minh họa**, không phải MCP tool hiện đã có:

```json
{
  "schema_version": "RetrievalQuery.v1",
  "operation_id": "demo-op-01",
  "mission_id": "demo-mission-01",
  "task_id": "demo-task-01",
  "context_revision_id": "demo-context-12",
  "context_snapshot_id": "demo-task-context-snapshot-01",
  "capability_id": "hanoi_policy.assess",
  "as_of": "2026-10-19",
  "known_at": "2026-10-19T09:00:00+07:00",
  "purpose": "policy_support_to_consider",
  "outcomes": [
    {
      "outcome_id": "demo-outcome-support",
      "question_vi": "Có hỗ trợ nào phù hợp để xem xét cho mục tiêu mua máy đóng gói?",
      "required_claim_groups": ["beneficiary_scope", "supported_expense", "conditions", "application_window"],
      "requested_evidence_roles": ["primary", "supporting"],
      "requested_argument_roles": ["supports", "definition", "exception", "context"],
      "requested_claim_types": ["amount", "formula"]
    }
  ],
  "scope_proposal": {"domain": "hanoi_policy", "jurisdiction": ["VN-HN"], "market": null},
  "query_terms": {"vi": ["máy đóng gói", "hỗ trợ thiết bị"], "en": []},
  "private_context_refs": ["demo-fact-product", "demo-fact-facility"],
  "constraints": {
    "mode": "reviewed_policy_assessment",
    "max_candidates": 30,
    "max_context_chars": 18000,
    "external_discovery": false,
    "semantic": "disabled"
  }
}
```

Giới hạn số lượng trên là cấu hình khởi đầu **đề xuất để benchmark**, không phải cam kết chất lượng hay chi phí đã chốt. Context size cuối phải phù hợp profile model và budget. Server loại fields vượt quyền, ghi lý do giảm scope, hoặc từ chối; không âm thầm mở rộng nguồn chỉ để trả đủ.

`requested_claim_types` là enum `amount|formula|preparation|procedure`, chỉ khai loại mà outcome thực cần. Server resolve `pack_version_id`, `pack_release_event_id` và manifest sau kiểm quyền/capability, không tin pack do agent/browser tự chọn. Nếu nguồn mới còn staging hoặc chưa pack, request phải dùng rõ `mode=source_discovery` và result có `assessment_allowed=false`; không dùng mode này để vượt gate đánh giá.

Envelope không được nhận từ trình duyệt: `principal_id`, `enterprise_id`, resource grants, current membership version, capability allowlist, `retrieval_policy_version`, `budget_grant_id` nếu có paid adapter, request trace. `as_of` không được dùng để chọn membership cũ.

### 7.2. `RetrievalResult.v1`

```json
{
  "schema_version": "RetrievalResult.v1",
  "retrieval_run_id": "demo-retrieval-01",
  "context_revision_id": "demo-context-12",
  "context_snapshot_id": "demo-task-context-snapshot-01",
  "mode": "reviewed_policy_assessment",
  "assessment_allowed": true,
  "knowledge_release": {
    "pack_version_id": "demo-pack-A-v1",
    "pack_release_event_id": "demo-pack-release-A-v1",
    "manifest_hash": "<sha256-of-exact-release-manifest>",
    "publication_state": "published",
    "availability_state": "usable"
  },
  "retrieval_policy_version": "demo-retrieval-policy-v1",
  "index_generation_id": "demo-fts-generation-01",
  "status": "partial",
  "scope_used": {"domain": "hanoi_policy", "jurisdiction": ["VN-HN"], "as_of": "2026-10-19"},
  "outcomes": [
    {
      "outcome_id": "demo-outcome-support",
      "coverage": {"beneficiary_scope": "covered", "supported_expense": "covered", "conditions": "partial", "application_window": "missing"},
      "evidence": [
        {
          "evidence_id": "demo-evidence-01",
          "source_snapshot_id": "demo-source-A-v1",
          "chunk_id": "demo-chunk-A-04",
          "rule_version_id": "demo-rule-A-v1",
          "policy_version_id": "demo-policy-A-v1",
          "pack_version_id": "demo-pack-A-v1",
          "claim_group": "beneficiary_scope",
          "evidence_role": "primary",
          "argument_role": "supports",
          "quote_original_ref": "demo-span-A-04",
          "quote_original_hash": "<sha256>",
          "rendered_vi_ref": "demo-span-A-04",
          "translation_id": null,
          "applicability": "in_scope",
          "rule_review_state": "approved",
          "rule_publication_state": "published",
          "rule_usage_gate": "usable",
          "source_availability": "live_checked",
          "allowed_use": ["explain_scope"],
          "required_companions": ["demo-exception-A-02"]
        }
      ],
      "retrieved_claims": [
        {
          "claim_version_id": "demo-claim-amount-A-v1",
          "claim_type": "amount",
          "policy_version_id": "demo-policy-A-v1",
          "pack_version_id": "demo-pack-A-v1",
          "claim_review_event_id": "demo-claim-review-A-v1",
          "claim_publication_event_id": "demo-claim-publication-A-v1",
          "claim_hash": "<sha256-of-exact-claim-payload>",
          "evidence_set_hash": "<sha256-of-exact-claim-evidence-set>",
          "review_state": "approved",
          "publication_state": "published",
          "availability_state": "usable",
          "applies_when_mode": "policy_scope",
          "applies_when_result": "general_information_only",
          "payload_ref": "demo-amount-payload-A-v1",
          "claim_evidence_binding_refs": ["demo-claim-evidence-A-v1"],
          "allowed_use": ["explain_general_limit"],
          "personalized_benefit_allowed": false
        }
      ],
      "gaps": [{"code": "APPLICATION_WINDOW_NOT_VERIFIED", "next_step": "review_source"}],
      "answer_constraints": ["Không kết luận doanh nghiệp đủ điều kiện", "Không khẳng định đang nhận hồ sơ"]
    }
  ],
  "egress": {"provider_calls": 0, "external_query_sent": false},
  "recheck_required_at_publication": true
}
```

Nội dung đầy đủ cấp cho agent được hydrate theo evidence refs sau authorization; UI nhận bản được lọc theo người đọc. Không trả raw private refs, rejected candidate IDs hoặc quy mô nguồn của doanh nghiệp khác. `coverage=covered` nói về tìm đủ loại căn cứ, không nói facts doanh nghiệp đã đạt điều kiện. Kết quả đối chiếu điều kiện là output riêng của rule evaluator.

`assessment_allowed=true` chỉ nói bundle đủ gate để được evaluator sử dụng, không phải kết luận doanh nghiệp đạt. Với `source_discovery`, `knowledge_release=null`, `assessment_allowed=false`, `retrieved_claims` không chứa claim chưa duyệt dưới nhãn approved. Claims được hydrate kèm typed payload theo schema trong tài liệu 02; nếu không có claim đã duyệt đúng loại thì trả gap, không tự chế tạo payload từ đoạn tìm gần nghĩa. Mọi `retrieved_claims` phải kiểm lại member, applies_when/dependencies, thời gian và release hash khi cấp context và khi công bố.

Trạng thái cấp run: `complete`, `partial`, `no_match_in_scope`, `blocked`, `unavailable`, `index_unavailable`, `context_changed`. Không gộp `no_match_in_scope` với `not_eligible`. Mã lỗi ổn định cho frontend gồm `SOURCE_PENDING_REVIEW`, `SOURCE_CHANGED`, `SOURCE_REVOKED`, `PERMISSION_CHANGED`, `RULE_NOT_CURRENT`, `TRANSLATION_UNREVIEWED`, `INDEX_GENERATION_STALE`, `EXTRACTION_UNCERTAIN`. Text UI tiếng Việt và tên cơ quan/nguồn cụ thể được render riêng; mã nội bộ không thành câu trả lời của AI.

### 7.3. API nội bộ và MCP

- `retrieve_evidence(query, execution_context)`: read-only theo quyền; không trực tiếp công bố hay ghi SSOT.
- `get_evidence_bundle(retrieval_run_id, context_revision_id, context_snapshot_id)`: hydrate, recheck và trả Bundle có hash; kiểm snapshot đúng task/scope, không dùng revision thay snapshot.
- `check_source_status(source_snapshot_ids)`: kiểm metadata hiện hành, không tự refresh có phí.
- `refresh_registered_source(source_id, trigger)`: chỉ service/role được cấp, đưa job vào hàng đợi; không tự gọi mô hình.
- `propose_rule_from_source(...)`: tạo nháp nếu capability/budget cho phép; không phê duyệt.
- `review_rule_version(...)`: công cụ vai trò reviewer, tách khỏi agent tools. Reviewer grant chỉ áp dụng domain/pack được giao.

Tên tool cuối được chốt cùng capability/MCP registry. Frontend tiếp tục nói chuyện với trợ lý, không yêu cầu người dùng tự chọn `top_k`, source hash hay database. Tác vụ retrieval không thể tự cấp consent, retry paid provider, publish rule hoặc nâng quyền đọc resource.

## 8. Hai vòng đời: cập nhật nguồn và phát hành quy tắc

```mermaid
flowchart LR
    S["Nguồn đã đăng ký"] --> F["Kiểm/lấy snapshot"]
    F --> U["Không đổi / không truy cập / thay đổi"]
    U --> ST["Staging + diff + trạng thái nguồn"]
    ST --> I["Đánh dấu phụ thuộc cần rà"]
    ST --> D["Quy tắc nháp / sửa đổi"]
    D --> R["DTT/chuyên gia duyệt đúng version/hash"]
    R --> P["Phát hành rule pack version"]
    P --> C["Được dùng đối chiếu hiện hành"]
    I --> H["Giữ nguyên báo cáo cũ\nhiện cảnh báo trạng thái hiện tại"]
```

### 8.1. State độc lập

| Đối tượng | State chính | Hệ quả |
|---|---|---|
| Snapshot | `staged → extracted → accepted` hoặc `quarantined/rejected` | `accepted` cho biết đã tiếp nhận đạt chuẩn, không có nghĩa mọi điều khoản đã được duyệt |
| Availability | `live_checked`, `temporarily_unavailable`, `blocked`, `unknown` | Không trộn với hiệu lực pháp lý |
| Legal/current applicability | `current`, `future`, `expired`, `superseded`, `unknown`, `disputed` | Cần căn cứ và phạm vi; trạng thái không thể suy từ một HTTP status |
| Rule review | `draft → in_review → approved`, hoặc `rejected/withdrawn` | Approval gắn hash, evidence bindings, scope và reviewer; sửa nội dung mất hiệu lực approval cũ |
| Rule publication | `staged → published → withdrawn` | Độc lập review; chỉ publisher có quyền phát hành bản approved; withdrawal không xóa lịch sử duyệt |
| Rule usage gate | `usable`, `needs_review`, `blocked` | Quy tắc đã từng duyệt vẫn có thể bị block do nguồn mới, thu hồi hoặc mâu thuẫn |
| Report | `published_snapshot` + current warning layer | Không âm thầm sửa nội dung hoặc xóa dấu vết đã tư vấn |

Nguồn công khai mới có thể xuất hiện trong danh sách “cần chuyên gia rà” mà chưa được dùng để khuyên doanh nghiệp đủ điều kiện. Nếu người dùng hỏi “nguồn này vừa cập nhật gì”, có thể mô tả thay đổi như thông tin chưa duyệt với nhãn rõ ràng; không biến thông tin đó thành kết quả eligibility.

### 8.2. Phát hiện thay đổi và invalidation

Không chỉ tìm xem quote cũ còn xuất hiện. Cần so sánh full normalized extraction, section structure, metadata hiệu lực, link văn bản sửa đổi/thay thế và các companion documents đã đăng ký. Header HTTP/ETag chỉ giúp tối ưu lấy dữ liệu, không chứng minh nội dung pháp lý vẫn hiện hành.

Khi thấy thay đổi: lưu snapshot candidate + diff → xác định loại thay đổi → tìm binding/rules/artifacts phụ thuộc → đặt usage gate thích hợp → đưa review queue. Thay đổi cosmetic được phân loại bằng quy tắc an toàn có audit; không dùng heuristic bỏ mọi thay đổi số/ký tự vì có thể làm sai ngưỡng hoặc phủ định.

Căn cứ chính thức về hết hiệu lực/thay thế phải làm quy tắc liên quan ngừng được coi là hiện hành ngay khi được xác định theo workflow đã duyệt. Không tiếp tục dùng rule cũ chỉ vì rule mới còn chờ duyệt. Với nguồn thay đổi đáng ngờ/chưa rõ tính thật, chọn `needs_review/blocked` cho phần rủi ro và không tự khẳng định văn bản đã bị bãi bỏ. Reviewer xác nhận quan hệ thay thế; không tự khôi phục rule chỉ vì trang cũ truy cập được trở lại.

Invalidation bám cạnh phụ thuộc cụ thể, không báo mọi báo cáo lỗi khi một trang khác trong domain thay đổi. Nếu chưa xác định hết ảnh hưởng, block phạm vi nghi ngờ và ghi mức bao phủ; không công bố “không ảnh hưởng” khi chưa kiểm.

D07-A yêu cầu kiểm pack/release integrity và **tập member cần cho từng outcome**. Member bị chặn không tự làm mọi outcome trong pack bị chặn: phần độc lập chỉ tiếp tục khi dependency closure chứng minh đủ nguồn/rules/claims hợp lệ. Cờ tổng hợp “pack có member cần rà” phục vụ hiển thị, không tự là global deny. Nếu manifest/release bị sai hoặc toàn pack bị thu hồi/cannot-isolate thì chặn phạm vi rộng tương ứng; không bỏ qua một lệnh block thật ở cấp pack.

Đường phụ thuộc bao gồm cả snapshot/chunk → claim evidence binding → claim version → pack release/evaluation/artifact, cùng các facts/rules mà applies_when hoặc formula dùng. Checklist/procedure cũng cần rà khi claim/căn cứ bị thay đổi; không chỉ invalidation các rule điều kiện.

### 8.3. Nguồn không truy cập được

Hiển thị tên cơ quan, tên nguồn, thời gian kiểm, trạng thái và snapshot đã dùng. Ví dụ UI: “Chưa truy cập lại được nguồn [tên cơ quan] lúc …; bản lưu ngày …; chưa xác minh thay đổi sau thời điểm đó.” Không chỉ nói “nguồn bị chặn” hoặc `network_error`.

Không có một TTL chung cho mọi chính sách. Profile nguồn quy định review cadence/rủi ro và cách xác định phần nào cần kiểm hiện hành; không dùng TTL để tự vượt source gate. **D07-A đã chốt ngày 19/10/2026:** dừng riêng phần cần căn cứ hiện hành chưa xác minh, vẫn trả phần độc lập đủ căn cứ và cho xem lịch sử/bản lưu có nhãn theo quyền. Không phát hành kết luận mới về điều kiện/cửa tiếp nhận của phần chưa qua gate hoặc tự bật phương án B dùng bản lưu thay xác minh. Hiển thị gap và bước kiểm chứng tiếp theo; D-R02 tham chiếu D07 đã chốt, không là câu hỏi phê duyệt mới.

### 8.4. Scheduler và trigger

Thiết kế có trigger theo lịch nguồn, manual và MCP event, cùng durable job/outbox, idempotency key `(source_id, target_check_window, extractor_version)` và lease. Refresh đang chạy được đọc lại sau restart; không chạy hai lượt dịch/OCR AI vì scheduler phát lại. Refresh mạng local có thể retry hữu hạn với backoff nếu không có phí, theo policy; **mọi paid API đều không tự retry**. Giới hạn concurrency, tổng bytes, miền truy cập, thời gian, ledger và circuit breaker riêng.

Đây là thiết kế scheduler của sản phẩm; tài liệu này không tạo lịch Codex, không bật job hằng ngày và không phát sinh phí nền. Cảnh báo chỉ được tạo sau đánh giá tác động đúng doanh nghiệp/quyền; kênh gửi ngoài, tần suất và grant ngân sách chưa được mặc định chấp thuận.

## 9. Tìm Internet, nội dung riêng và chỉ dẫn độc hại

Baseline truy xuất trong kho nguồn đã đăng ký. Khám phá Internet mở là capability riêng, chưa bật. Nếu cần tìm nguồn mới, server tạo query tối thiểu theo chủ đề/cơ quan/phạm vi, không gửi tên doanh nghiệp, mã số thuế, báo cáo tài chính, toàn văn chat, file hoặc số liệu riêng trừ khi thực sự cần và có quyết định dữ liệu phù hợp.

Ví dụ query công khai được đề xuất: “hỗ trợ thiết bị doanh nghiệp nhỏ Hà Nội văn bản điều kiện hồ sơ”. Không cần chèn “Công ty X, doanh thu Y, lợi nhuận Z, tệp nội bộ…”. Tối thiểu hóa vẫn có thể tiết lộ ý định kinh doanh; nếu bật dịch vụ tìm kiếm bên ngoài phải đưa nhà cung cấp và loại dữ liệu gửi vào quyết định dữ liệu/chi phí.

Boundary bắt buộc:

- Internet/manual/MCP/Excel là data, không phải system instruction. Nội dung “bỏ qua kiểm chứng”, “gọi tool này”, “gửi API key”, “xác nhận SSOT” hoặc “chuyển tiền” chỉ là text trong nguồn.
- Parser không thực thi macro, JavaScript nguồn, liên kết lệnh hoặc template code. Không cho URL trong nguồn vượt allowlist/SSRF controls qua redirect hoặc trỏ local/metadata endpoint.
- Agent nhận quote trong vùng có nhãn untrusted và có tool allowlist; renderer escape HTML/Markdown link nguy hiểm. Không cho nguồn sửa prompt, model routing, budget, ACL hay trạng thái reviewed.
- Prompt injection detection là tín hiệu phụ, không phải hàng rào duy nhất. Dù không phát hiện được câu độc hại, các tool vẫn kiểm quyền và schema.
- Nguồn công khai chứa tên/case doanh nghiệp không tự cấp phép tái sử dụng dữ liệu cá nhân hoặc biến thành facts của doanh nghiệp đang hỏi.

## 10. Cache, index và embedding port tương lai

### 10.1. Cache có phạm vi

Cache retrieval key bao gồm normalized query/plan hash, outcome schema, scope/as_of, nguồn/rule/policy/pack versions, index/alias/analyzer versions, context snapshot hash/dependencies và authorization partition. Cache chứa dữ liệu riêng không chia giữa doanh nghiệp/người dùng không cùng quyền. Quyền hiện hành được recheck kể cả key khớp; không xem hash ACL cũ là đủ.

Claim payload/evidence versions, review/publication event refs, applies_when dependencies, pack release và manifest hash cũng nằm trong cache lineage. Đổi claim, rút release hoặc thay member làm cache cần revalidation; không chỉ kiểm source text chưa đổi.

Public evidence candidates có thể dùng chung theo source/rule/index version; câu trả lời cá nhân hóa và facts của doanh nghiệp vẫn riêng. Không reuse “doanh nghiệp A được hưởng” cho B. Cache không làm phản hồi bị lỗi thành nội dung được duyệt. Retrieval cache khác provider raw cache và khác prompt cache; việc đọc lại không tự sinh provider call.

### 10.2. Dựng và chuyển generation

Canonical write + outbox trong một giao dịch → index worker upsert theo chunk/hash → kiểm coverage/integrity → đánh dấu generation ready → đổi active pointer nguyên tử. Không cấp một gói context trộn generation cũ/mới mà không ghi trace. Nếu index thiếu hoặc stale, fallback deterministic SQL/keyword có giới hạn và nhãn coverage; nếu không đạt thì trả `index_unavailable` hoặc gap, không bỏ qua ACL để lấy kết quả.

Xóa/thu hồi quyền tác động ngay canonical access gate; index cleanup chạy tiếp và có audit. Không chờ xóa vector/FTS xong mới thu hồi quyền. Chính sách lưu bytes, cache, trace, backup và xóa vật lý cần chốt retention; không hứa “đã xóa mọi bản sao” chỉ vì entry biến mất trong search.

### 10.3. Port chưa bật

```text
SemanticRetriever.search(query, eligible_partition, constraints, execution_context)
  -> candidate_refs + scores + embedding_profile_version + usage

EmbeddingAdapter.embed(texts, model_profile_version, budget_grant_id)
  -> vectors + dimensions + model_revision + usage
```

Adapter mặc định trả `FEATURE_DISABLED`, không tự chọn nhà cung cấp hoặc model. Port không cho semantic service tự hydrate SSOT. Khi được bật, lưu model/revision/dimension, preprocessing/chunk/translation versions, vector hash/index generation và lineage đến exact snapshot. Đổi embedding model cần reindex/version migration; không trộn vector khác không gian để so score.

Trước khi bật phải có phép dùng nội dung theo data policy, danh sách public/private text gửi ra, retention của nhà cung cấp, dự toán initial/reindex/update/query cost và giới hạn grant. Có thể bắt đầu chỉ với corpus công khai nếu được duyệt; vẫn không tự mặc định được phép dùng provider mới. Semantic retrieval/reranker chỉ tìm ứng viên, canonical gates và approved rule evaluator giữ nguyên.

Chỉ bổ sung khi benchmark chứng minh tăng tìm đủ căn cứ theo outcome, đặc biệt từ đồng nghĩa/đa ngôn ngữ, với độ trễ/chi phí chấp nhận được và không tăng sai scope. Chưa cần một vector DB riêng; không lấy lựa chọn sản phẩm database làm tiêu chí thành công.

## 11. Bộ nghiệm thu

| Mã | Ca kiểm | Tiêu chí đạt |
|---|---|---|
| R01 | Trà Sen hỏi hỗ trợ thiết bị, không hỏi xuất khẩu | Query/outcome/căn cứ đúng intent; không áp IOR/Incoterm hoặc ba task cố định |
| R02 | Hỏi hai ý: điều kiện và hồ sơ | Coverage tách hai ý; thiếu hồ sơ thì nói thiếu, không dùng điều kiện làm câu trả lời thay |
| R03 | Mỹ/Đức/Nhật và Hà Nội trong kho cùng lúc | Không lấy gần nghĩa sai market/thẩm quyền; unknown không fallback sang Mỹ |
| R04 | Ngày công bố trước hiệu lực, cửa hồ sơ đã đóng | Kết luận thời điểm đúng theo từng trường; không coi checked hôm nay là đang mở |
| R05 | Nguồn mới đã accepted nhưng rule chưa duyệt | Có thể vào review queue; không dùng để khẳng định eligibility |
| R06 | Rule đã duyệt nhưng nguồn có căn cứ thay thế | Usage gate block/needs_review; không tiếp tục dùng rule cũ vì rule mới chưa duyệt |
| R07 | Quote cũ còn nhưng ngoại lệ mới thêm | Full-source/companion diff phát hiện, invalidation đúng phụ thuộc |
| R08 | Primary đúng ID/hash nhưng không chứng minh claim | Bị loại hoặc đổi allowed use; không vượt kiểm bằng exact quote |
| R09 | Supporting khác topic nhưng đúng role và điều kiện | Được dùng đúng giới hạn với primary cần thiết; không mở rộng thành căn cứ chung |
| R10 | Người A/B hoặc hai nhân viên khác quyền | Không lộ title/snippet/content/ref/count của nguồn không có quyền; cache/rank/autocomplete không lộ corpus khác |
| R11 | Thu hồi quyền trong lúc retrieval/Claude đang chạy | Context/publication gate chặn; mở/download lại cũng kiểm quyền hiện hành |
| R12 | Tài liệu tiếng Anh, dịch sai “không” hoặc con số | Bản dịch không thay exact original; phần mâu thuẫn bị block để rà; UI tiếng Việt có nguyên bản |
| R13 | “mua máy”, cách nói khác, không dấu, ngôn ngữ khác | Đo recall trên gold set theo claim, không lower-case tên Trà Sen; có language gap khi chưa hỗ trợ |
| R14 | Trang bị chặn/404/redirect | Tên cơ quan + thời điểm + snapshot rõ; không suy 404 là hết hiệu lực hoặc không có chính sách |
| R15 | Tài liệu có prompt injection/macro/link local | Không thực thi, không sửa quyền/consent/model/budget, không fetch local trái phép |
| R16 | Index mất, generation dở, worker restart | SSOT/snapshot không mất; index dựng lại; lỗi có thể hiểu; không tạo paid call |
| R17 | Refresh cùng bytes/trigger trùng | Idempotent; không tạo lại dịch AI hoặc duplicate snapshot hữu nghĩa |
| R18 | Xóa/thu hồi nguồn riêng | Không search/hydrate lại; cleanup và audit theo retention; backup không bị tuyên bố đã xóa giả |
| R19 | Không có hit trong top-k | Không kết luận không có chính sách hoặc không đủ điều kiện; báo phạm vi/gap |
| R20 | Dữ liệu cũ/current report | Report nguyên bản giữ nguyên; cảnh báo hiện tại riêng; quyền hiện hành vẫn áp dụng |
| R21 | Rule đã duyệt/phát hành nhưng thiếu pack release hoặc sai manifest/member | `hanoi_policy.assess` không được tạo evaluation; source discovery chỉ trả đầu mối với assessment_allowed=false |
| R22 | Claim preparation/procedure/amount/formula bị rút, sai evidence hash hoặc applies_when chưa đạt | Không cấp như claim usable/cá nhân hóa quyền lợi; không tự bịa checklist, deadline hay số tiền; dependencies khiến kết quả cũ cần rà |

Bộ gold set gắn `question → outcome → expected claim groups → eligible source/rule versions → required evidence roles → forbidden evidence`. Không đánh giá retrieval chỉ bằng việc AI trả lời nghe hợp lý. Đo coverage/recall theo claim, precision scope, tỷ lệ bỏ sót ngoại lệ, nguồn không có quyền và stale rule leakage, latency, số query và chi phí. Hard gate: không có leakage quan sát được trong bộ test, không dùng rule blocked/unreviewed như đã duyệt, không phát sinh paid call ngoài grant.

Mức recall/latency mục tiêu được chốt sau đo baseline trên corpus và thiết bị triển khai; không đặt tỷ lệ tùy ý rồi coi là chứng nhận pháp lý. So sánh FTS+alias với semantic trên cùng gold set khi có đề xuất bật. Controlled tests là đủ để kiểm contract; vòng Claude thật kiểm tổng hợp và sử dụng căn cứ phải theo kế hoạch/cost cap được duyệt, không tự retry.

## 12. Chuyển từ app 0.4 hiện tại

1. **Inventory schema và nguồn hiện có:** map PublicSource/DomainReference/SourceObservation/Pack sang registry/snapshot/chunk, giữ nguyên ID legacy và raw quote/hash. Không đọc hoặc xuất hàng loạt tệp riêng chỉ để thiết kế.
2. **Bổ sung lineage dạng additive:** snapshot/extraction/locator/date fields chưa biết mang `unknown` hoặc `legacy_locator`; không chế tạo ngày hiệu lực hoặc reviewer. Giữ adapter legacy cho xuất khẩu trong giai đoạn chuyển.
3. **Chuyển evidence bindings:** giữ nguyên chính sách primary/supporting hiện có; không biến ngoại lệ hẹp thành rule chung. Rule chưa được review theo governance mới mang trạng thái legacy/needs_review thích hợp, không tự ghi DTT đã duyệt.
4. **Dựng FTS shadow generation:** có feature flag, benchmark gold set, không thay kết quả người dùng ngay. Corpus private tách scope và ACL được kiểm trước khi index.
5. **Bật đọc cho corpus/capability đã đạt:** retrieval run và ContextBundle có version; rollback active pointer chỉ thay index/adapter, không rollback quyền hoặc trạng thái pháp lý canonical.
6. **Mở policy pack đã review:** nguồn thật được chọn và rule được DTT/chuyên gia duyệt; corpus mẫu chỉ dùng để kiểm contract, không gắn nhãn tư vấn thật.
7. **Vận hành refresh:** bật sau khi chốt source profiles, ngân sách, review owner, retention và trường hợp dùng bản lưu. Theo dõi backlog review, invalidation chưa xử lý và nguồn không đọc được.

Không chuyển SSOT sang vector hoặc Markdown. Không cần tách microservice, graph/vector DB hay pipeline trả phí trong bước này. SQL tables/index modules có thể nằm trong backend hiện tại; queue/outbox và quyền vẫn phải có contract bền vững.

## 13. Các quyết định dữ liệu/chi phí cần dừng trao đổi

Bảng này gồm cả quyết định đã chốt và cấu hình/mở rộng còn cần chuẩn bị trước kích hoạt. D-R02 tham chiếu D07-A đã được người dùng chốt; D04/D05 cũng đã chốt, không hỏi lại. Các provider/indexing/retention/ngân sách mới ngoài phạm vi đó vẫn cần cửa dữ liệu/vận hành riêng:

| Mã | Phương án đề xuất cụ thể để trình | Cần chốt trước hành động nào |
|---|---|---|
| D-R01 | Đầu tiên chỉ index corpus domain công khai đã có quyền; tệp doanh nghiệp index riêng theo quyền, không dùng nội dung riêng để bổ sung kho công cộng | Bật private indexing diện rộng hoặc chia sẻ dataset/corpus ra ngoài |
| D-R02 → D07-A đã chốt | Dừng phần thiếu căn cứ hiện hành; trả phần độc lập hợp lệ và lịch sử có nhãn. Không bật ngoại lệ B dùng bản lưu để kết luận mới | Áp dụng policy A; profile/cadence và người chịu trách nhiệm phải được cấu hình trước release, không hỏi lại lựa chọn A |
| D-R03 | Retention tách bytes gốc/ảnh tài chính, chunks, trace, cache và backup; public rule history giữ audit theo quyền sử dụng | Thu thập/lưu thật lâu dài, hứa xóa hoặc dùng dữ liệu để đánh giá/học lại |
| D-R04 | Embedding/dịch/rerank/search provider mới chỉ bật sau benchmark, data egress manifest và cost cap | Gửi corpus hoặc query ra nhà cung cấp mới; tạo embedding/reindex/dịch tự động có phí |
| D-R05 | Nguồn tự cập nhật nhưng không tự nộp hồ sơ/gửi ngoài; alert trong app có scope và service budget riêng | Bật tác vụ nền trả phí hoặc gửi thông báo ngoài app |

Quyết định đã chốt không hỏi lại: D04 staff xem/đề xuất trong phạm vi được giao, owner xác nhận mọi facts nghiệp vụ SSOT; D05 tài chính server-only, chỉ gửi Claude chỉ tiêu tối thiểu được cho phép, không bản gốc. Nguồn tự cập nhật/rules DTT duyệt; chưa graph/vector DB hoặc embedding mới; không tự retry có phí. Retrieval không được cấp chunks/OCR/CSV/tên file tài chính vào model context dưới tên evidence; dùng FinancialMetricVersion và egress grant theo [hợp đồng D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>). Các nguồn/chính sách demo theo tài liệu agent chính sách sau khảo sát.
