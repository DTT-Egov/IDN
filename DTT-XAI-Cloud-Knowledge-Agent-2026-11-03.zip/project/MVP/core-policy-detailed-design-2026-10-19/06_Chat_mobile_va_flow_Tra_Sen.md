# Chat mobile và flow Trà Sen

Ngày 19/10/2026 · UX specification, chưa triển khai. Một chat liên tục cho nhập tài liệu, facts và chính sách; prototype định hướng vẫn là trợ lý làm trung tâm. Các câu trả lời dưới đây minh họa thiết kế, không phải kết quả chạy Claude hoặc kết luận chính sách thật.

## 1. Khung màn hình

Viewport chuẩn 390 × 844 và biên 320 × 568; nghiệm thu thêm trên điện thoại thật khi triển khai. Header tối đa hai dòng: tên trợ lý + doanh nghiệp/phạm vi đang làm. Vùng hội thoại tự cuộn, composer co giãn tối đa ba dòng rồi cuộn nội bộ. Không đặt cả menu tác vụ, giải nghĩa và banner trạng thái cố định quanh composer. Mục Hồ sơ/Lịch sử là điều hướng phụ thu gọn.

Touch target tối thiểu 44px. Một hành động chính ở mỗi thẻ; liên kết chi tiết thu gọn. Sticky chỉ cho composer; không có nút nổi che câu trả lời ở 320px. Bàn phím thật, safe-area và xoay màn hình phải kiểm trên thiết bị, không suy từ viewport test.

## 2. Các màn/trạng thái tối thiểu

| Mã | Khi nào | Nội dung chính | Hành động |
|---|---|---|---|
| M01 | Chat mới | Lời mời nêu mục tiêu/đính kèm; ba tác vụ cũ vẫn có; chính sách là lựa chọn bổ sung | Nhập câu hỏi hoặc chọn Chính sách Hà Nội |
| M02 | Nhận ảnh/Excel | Tệp đã nhận, đang đọc bằng công cụ nào, thao tác có model phải có quyền trước gửi | Đọc tài liệu theo grant đã cấp; không phát sinh lại khi reload |
| M03 | Có đề xuất facts | Chỉ hiển thị thay đổi mới/mâu thuẫn; nhóm dữ kiện, giá trị hiện tại → đề xuất và nguồn | Owner “Xác nhận N dữ kiện”; staff “Gửi đề xuất cho chủ doanh nghiệp” |
| M04 | Intent rõ, thiếu ít facts | Tóm tắt mục tiêu một dòng, facts đã biết thu gọn, một câu hỏi nhỏ | Trả lời; có thể “Chưa có thông tin” |
| M05 | Sẵn sàng nghiên cứu | Nội dung sẽ giải, phần không có nguồn/quy tắc, số lượt và giới hạn phí được cấp | “Bắt đầu nghiên cứu”; không dùng chữ “thử lại” cho lượt phí mới |
| M06 | Đang thực hiện | Một thẻ tiến độ có trạng thái thật và mốc cập nhật; không tự tạo nhiều bubble | Đọc trạng thái sau reload; hủy nếu còn có thể |
| M07 | Kết quả | Kết luận và giới hạn trước, mỗi ý hỏi có status; điều kiện/checklist/nguồn thu gọn | Một bước tiếp theo phù hợp |
| M08 | Cần nguồn/rule review | Nêu phần trả được và phần đang thiếu; không thẻ “đang xử lý” khi operation đã kết thúc | Xem nguồn hoặc lưu câu hỏi theo dõi; không tự hứa có chuyên gia đang xử lý |
| M09 | Lỗi sau dispatch | Giải thích thường, lượt đã gửi/chưa rõ kết quả/không qua kiểm; giữ nháp | Đọc trạng thái hoặc xem phần hợp lệ; lượt mới có phí ghi rõ |
| M10 | Xem lại | Báo cáo snapshot, ngày/phiên bản, label cần rà nếu có; câu hỏi mới vẫn giữ nháp | Tiếp tục trong chat; đọc lại không inference |
| M11 | Source/rule review của DTT | Hàng chờ, diff, căn cứ/ảnh hưởng và quyết định theo version | Duyệt/từ chối/phát hành theo quyền; không lộ hồ sơ doanh nghiệp |

Không có màn bắt buộc nhập đủ form doanh nghiệp trước mọi câu hỏi. M11 thuộc giao diện quản trị riêng theo vai trò, không chen vào flow chủ doanh nghiệp.

## 3. Walkthrough thiết kế — Trà Sen

### Bước 1 — Từ tài liệu tới hồ sơ

Người dùng: “Đây là ảnh và bảng hàng Trà Sen. Tôi muốn số hóa quản lý kho và tìm chương trình hỗ trợ ở Hà Nội.”

Trợ lý sau kết quả được kiểm: “Mình đã đọc được tên Trà Sen và lượng tịnh trong tài liệu. Có một dữ kiện khác hồ sơ đang lưu; xem phần thay đổi trước khi dùng cho tư vấn.”

Thẻ facts chỉ hiển thị trường mới/xung đột; owner xác nhận một batch có expected version, staff chỉ đề xuất. Quyết định cũ được giữ, không bắt tick lại khi xem lại. Dữ kiện không liên quan mục tiêu có thể để nháp và không chặn mọi bước.

### Bước 2 — Dùng SSOT, hỏi đúng thiếu

Hệ thống thấy sản phẩm nhưng chưa có nơi đăng ký pháp nhân. Không suy ra Hà Nội từ nhãn. Trợ lý: “Sản phẩm đã có trong hồ sơ. Để tìm đúng chương trình địa phương, doanh nghiệp đăng ký tại Hà Nội hay địa phương khác?”

Chọn Hà Nội tạo đề xuất/confirmation thích hợp, không tự sửa từ lời suy đoán của model. Nếu user chỉ hỏi tình trạng tiếp nhận của một chương trình đã chỉ rõ, không yêu cầu doanh thu/lao động trước khi đọc thông báo.

### Bước 3 — Kế hoạch trong chat

```text
Mình sẽ kiểm tra:
• Chương trình tư vấn liên quan tới số hóa quản lý kho.
• Điều kiện và thông tin còn thiếu của doanh nghiệp.
• Tình trạng tiếp nhận hồ sơ, nếu nguồn xác nhận được.

Thông tin đã có: Trà Sen · hồ sơ được chọn [Xem]
Quy tắc chưa được duyệt sẽ ghi rõ, không kết luận đủ điều kiện.

[Bắt đầu nghiên cứu — theo hạn mức đã hiển thị]
```

Ví dụ xưng hô bên trên phải được chuẩn hóa theo lựa chọn UX trước triển khai: người dùng giữ nguyên nguyên văn, trợ lý dùng “mình”; tránh tự đổi “Tôi” trong tin của người dùng thành “Mình”. Khi chưa biết cách gọi, dùng câu không cần đại từ đối với người dùng. Nút thực phải hiển thị số lượt/phí hoặc giới hạn cụ thể từ grant, không dùng placeholder trên bản nghiệm thu.

### Bước 4 — Kết luận trước

```text
Có hướng tư vấn số hóa cần xem xét.
Chưa đủ căn cứ xác nhận doanh nghiệp phù hợp và chương trình
còn nhận hồ sơ tại thời điểm này.

Vì sao: nguồn thông báo có chương trình liên quan; điều kiện
trong phụ lục/quy tắc và tình trạng chỉ tiêu còn cần xác minh.

[Xem phần còn thiếu]
Điều kiện đã đối chiếu  ▸
Chuẩn bị hồ sơ         ▸
Nguồn và ngày kiểm     ▸
```

Đây là mẫu khi pack chưa đủ/nguồn chưa xác nhận, không thay cho câu trả lời từ pack đã duyệt. Nếu có rule hợp lệ và facts đủ, hiển thị từng điều kiện có căn cứ; vẫn không cam kết cơ quan phê duyệt. Không chèn giải nghĩa FSVP/Incoterm hay checklist xuất khẩu vào câu chính sách.

### Bước 5 — Hành động có ích

Nếu thiếu nơi đăng ký, hành động chính là bổ sung đúng dữ kiện. Nếu đủ facts nhưng quota unknown, hành động chính là xem thông tin/cách xác minh chính thức. Nếu rule đang chờ duyệt, nêu trạng thái này; không giả một chuyên gia đang nhận xử lý. Chỉ tạo yêu cầu review khi có cơ chế và người nhận thực đã cấu hình.

User có thể lưu “Danh sách chuẩn bị” vào cùng mission/artifact, không tạo doanh nghiệp hay sản phẩm mới. Chủ có thể chia sẻ artifact theo resource scope; không tự chia sẻ toàn bộ chat hay ảnh tài chính. Mở lại ở Lịch sử hiển thị status giống trong chat.

## 4. Quy tắc hiển thị

D07-A đã chốt 19/10/2026: kết quả có phần thiếu căn cứ vẫn hiển thị phần độc lập hợp lệ, nêu rõ phần đang dừng và lý do; lịch sử có nhãn/ngày theo quyền. Không thẻ “đang xử lý” giả, không tự chuyển bản lưu thành kết luận hiện hành. Nếu O3 chưa xác minh cửa tiếp nhận, không bắt người dùng nhập tài chính để giải một khoảng trống nguồn.

- Tiếng Việt là nội dung chính; nguyên bản nguồn ở mục mở rộng. Ngày UI `dd/MM/yyyy`, thời gian thêm `HH:mm` khi cần; API ISO-8601, lưu UTC, hiển thị Asia/Bangkok.
- Trạng thái phiên bản facts, rule và tình trạng nhận hồ sơ không gộp thành một “đã duyệt”. Dữ kiện “đã xác nhận bởi doanh nghiệp” khác “đã xác minh độc lập”.
- Trạng thái một operation lấy một state payload thống nhất. Header/thẻ/lịch sử không tự suy từ các biến khác nhau.
- Bubble tiến độ thay nội dung, không append lặp; lỗi terminal bỏ thẻ processing. Streaming chỉ là bản đang tạo, chưa phải báo cáo được công bố.
- Draft giữ theo tenant/actor/chat; receipt operation giúp reload đọc lại. Hành động mới sau lỗi cần ID mới và grant mới nếu có phí.
- Không hiện số tiến độ mơ hồ: ghi “Đã có 2/9 dữ kiện cần đối chiếu”, không “đạt 2/9” nếu chưa đánh giá điều kiện.
- Nhãn “Nguồn chưa truy cập được: [tên cơ quan]”; không biến lỗi HTTP thành không tồn tại chương trình.

## 5. Nghiệm thu UX

Với tài chính theo D05 đã chốt, thêm một thẻ preview tối thiểu ở bước cần dữ kiện: “Claude sẽ nhận N chỉ tiêu để …”, mở đúng giá trị/kỳ/đơn vị. “Cho phép gửi chỉ tiêu” và “Xác nhận hồ sơ” là hai receipt/quyền riêng, dù có thể trình bày trong cùng chat. Không hiển thị nguyên tài liệu cho người chỉ được xem facts; không xin gửi file tài chính gốc. Khi parser không đọc đủ, hỏi đúng chỉ tiêu thiếu và giữ unknown; không gửi ảnh/file cho model để cứu ca. Chi tiết ở [hợp đồng D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>).

Chủ doanh nghiệp đi từ câu hỏi đến kết quả/giới hạn và bước tiếp theo trong cùng chat. Mỗi lần chỉ hỏi nhóm nhỏ cần cho bước hiện tại; facts đã xác nhận không hỏi lại. 320px không overflow/che chữ; composer/nav không chiếm vùng đọc lớn khi chưa mở bàn phím. Kiểm riêng viewport và thiết bị thật, tải lại giữa chừng, mất mạng, owner/staff, xem lịch sử và nháp mới khi mở báo cáo cũ.
