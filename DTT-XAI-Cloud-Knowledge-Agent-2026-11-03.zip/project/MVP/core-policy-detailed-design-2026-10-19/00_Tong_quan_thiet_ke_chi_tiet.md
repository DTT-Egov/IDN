# nMate — thiết kế chi tiết lõi và agent chính sách Hà Nội

[Sổ lỗi thiết kế và backlog sau RCA](<../architecture/DESIGN_FLAWS.md>) liên kết các finding của bộ thiết kế này với sự cố, biện pháp đã làm và điều kiện kiểm chứng còn mở. Một finding đã sửa trong tài liệu không tự được coi là đã áp dụng trên runtime.

Ngày 19/10/2026 · Bản thiết kế đích `core-policy/1.1-draft`. **Đã có bản triển khai lát cắt lõi và chính sách Hà Nội**, kèm kiểm thử mobile và hai lượt Claude theo D06. Phạm vi thực có, giới hạn và bằng chứng ở [bản triển khai](<../../../REFERENCE_LINKS.md#ref-0012>) và [walkthrough](<../../../REFERENCE_LINKS.md#ref-0013>). Các DDL/hợp đồng minh họa trong bộ này vẫn là thiết kế đích, không thay cho migration runtime hoặc chứng cứ nghiệm thu.

## 1. Đề xuất kiến trúc

Một trợ lý chung tiếp nhận mục tiêu/tài liệu, dùng hồ sơ doanh nghiệp theo quyền, chia mục tiêu thành các ý cần giải, chọn capability và căn cứ, đối chiếu điều kiện, rồi trả kết luận và bước tiếp theo trong chat. Các agent dùng cùng hợp đồng và dữ liệu chuẩn, không tự giữ những “hồ sơ doanh nghiệp” khác nhau.

Giữ backend theo mô-đun, SQL làm kho có thẩm quyền, LangGraph điều phối. Knowledge graph là quan hệ có kiểu trên SQL. Retrieval bắt đầu bằng metadata/FTS/alias; embedding là cổng tắt. Model Gateway tiếp tục native Claude, định tuyến theo vai trò Sonnet/Opus đã kiểm trước gửi. Không có graph/vector database hoặc nhà cung cấp mới trong lát cắt này.

Thiết kế dựa trên [hiện trạng 0.4](<../../../REFERENCE_LINKS.md#ref-0014>), [kế hoạch đã chốt phạm vi](<../../../REFERENCE_LINKS.md#ref-0015>) và các bài học từ [review/walkthrough mới nhất](<../../../REFERENCE_LINKS.md#ref-0016>). Thư mục backend/frontend mang tên lịch sử 0.2/0.1 không bị đổi hoặc ghi đè trong lượt thiết kế.

## 2. Đọc bộ tài liệu

| Tài liệu | Dùng để chốt/triển khai gì |
|---|---|
| [01 — Hợp đồng lõi và điều phối](<01_Hop_dong_loi_va_dieu_phoi.md>) | Intent → outcome → task → answer/artifact; IDs, AgentBrief/Result, MCP, evidence, lỗi và ranh giới quyền |
| [02 — SSOT và SQL Knowledge Graph](<02_SSOT_va_SQL_Knowledge_Graph.md>) | DDL đích, facts/owner decisions/CAS, temporal, ACL, context tối thiểu, rules/conditions/lineage và impact traversal |
| [03 — Retrieval và vòng đời tri thức](<03_Retrieval_va_vong_doi_tri_thuc.md>) | Sources/chunks/nguyên bản–dịch Việt, FTS/aliases, quyền/as_of, review/refresh, index và embedding port |
| [04 — Model Gateway và vận hành](<04_Model_Gateway_va_van_hanh.md>) | Registry/routing, request/result, durable jobs/dispatch fence, ledger/ngân sách, cache, recovery và vận hành khóa |
| [05 — Agent chính sách Hà Nội](<05_Agent_chinh_sach_Ha_Noi.md>) | PRD/capability/plan, khảo sát nguồn thật, condition vs hồ sơ vs cửa tiếp nhận, lát cắt Trà Sen |
| [06 — Chat mobile và flow Trà Sen](<06_Chat_mobile_va_flow_Tra_Sen.md>) | Trạng thái màn, wireframe nội dung, một chat liên tục, owner/staff và tiếp tục sau lỗi/reload |
| [07 — Nghiệm thu và lộ trình](<07_Nghiem_thu_va_lo_trinh_trien_khai.md>) | Ma trận kiểm, hard gates, baseline/eval Claude thật có grant, migration/rollback và các chặng triển khai |
| [08 — Quyết định cần chốt](<08_Quyet_dinh_can_chot.md>) | Phương án cụ thể về staff, dữ liệu tài chính, chi phí và fallback nguồn; phân biệt approved/pending |
| [10 — Dữ liệu tài chính và quyền gửi chỉ tiêu](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>) | Ranh giới server, metric versions, exact egress grant, DTO/preview, no-original và thu hồi |
| [11 — Lát cắt kỹ thuật và backlog](<11_Lat_cat_ky_thuat_va_backlog.md>) | Module/write boundaries, tools tài chính, work packages/phụ thuộc và cửa chuyển sang viết app |
| [12 — Chính sách nguồn D07](<12_Chinh_sach_nguon_va_phat_hanh_D07.md>) | Phương án A đã chốt: dừng phần thiếu căn cứ hiện hành, giữ phần hợp lệ/lịch sử; release gates và phương án B không áp dụng |

Tài liệu 06 là UX specification/wireframe nội dung, chưa là ảnh màn hình của app mới. Báo cáo kiểm tài liệu và review resolution nằm trong cùng thư mục; chúng không thay thế test hệ thống sau triển khai.

Xem [review và các điểm đã sửa](<09_Review_va_kiem_tra_thiet_ke.md>) cùng [kết quả kiểm cấu trúc tài liệu](<../../../REFERENCE_LINKS.md#ref-0017>).

## 3. Lát cắt Trà Sen

1. Người dùng đưa ảnh/Excel hoặc hỏi trực tiếp. Parser/vision có giới hạn, provenance rõ; chỉ facts mới/xung đột hiện ra để quyết định.
2. Chủ xác nhận SSOT bằng giao dịch CAS; staff theo ma trận được chốt. Facts sản phẩm dùng chung, market profiles riêng; địa chỉ trên nhãn không tự xác nhận nơi đăng ký doanh nghiệp.
3. Câu hỏi chính sách tạo outcomes đúng câu hỏi. Những gì đã biết không hỏi lại; chỉ lấy nhóm facts mà mục tiêu/rule cần.
4. Retrieval lấy đúng nguồn/ngày/quyền, rules đã duyệt và phát hành. SQL graph giải thích điều kiện–facts–căn cứ; missing là unknown, mâu thuẫn là conflict.
5. Gateway chỉ gửi context tối thiểu tới model đã route và có grant. Không tự retry/fallback/escalation có phí; reload chỉ đọc trạng thái.
6. Kết luận đứng đầu chat, có giới hạn và một bước chính. Chương trình được công bố, doanh nghiệp có phù hợp và còn nhận hồ sơ là ba trạng thái riêng.
7. Lưu answer/artifact cùng fact/source/rule/context versions. Nguồn/fact thay đổi đánh dấu phần phụ thuộc cần rà; giữ lịch sử và quyền đọc hiện hành.

Nguồn đã khảo sát gợi ý lát cắt tư vấn số hóa quản lý kho, nhưng phụ lục/hiệu lực và tình trạng chỉ tiêu phải xác minh trước phát hành pack. Thiết kế không khẳng định đang có một chương trình hỗ trợ mua máy hoặc cam kết quyền lợi cho Trà Sen.

## 4. Cách tích lũy tri thức

**Doanh nghiệp:** observation → proposal → quyết định có quyền → fact version → context snapshot theo nhiệm vụ. Bộ nhớ tốt hơn qua các lần xác nhận và nguồn gốc, không qua việc nối toàn bộ chat vào mọi prompt. Không tự ghi suy đoán của model thành facts; thay đổi quan trọng không bị ảnh cũ đảo lại.

**Domain:** source registry → snapshot/extraction/chunk → claim/rule nháp → review → pack phát hành. Dùng lại nguồn/rule công cộng đúng điều kiện cho nhiều doanh nghiệp. Mỗi kết quả áp dụng vào doanh nghiệp vẫn riêng; xóa tên khỏi báo cáo không tự biến thành tri thức công cộng.

**Graph:** projection từ các bảng có kiểu và relation được duyệt. Dùng để giải thích, kiểm điều kiện và truy tác động; index/graph mất có thể dựng lại. Markdown là bản xuất có version, không là nơi model tự sửa chân lý vận hành.

## 5. Các hợp đồng đã khóa ở mức kỹ thuật

- Khóa operation là `(enterprise_id, operation_id)`; actor là audit + authorization. Model step có khóa không NULL `(enterprise_id, operation_id, task_id, step_key)` và tối đa một dispatch; tổng steps bị plan/grant giới hạn.
- `context_revision_id` là watermark doanh nghiệp; `context_snapshot_id`/hash là bộ ngữ cảnh tối thiểu được cấp cho task. Quyền luôn hiện hành, dù xem `as_of/known_at` lịch sử.
- `policy_version_id` là một policy/văn bản; `pack_version_id` là bản phát hành tập policy/rule/claim. Các config retrieval/routing có version riêng.
- `evidence_role` là primary/supporting, `argument_role` là supports/exception/definition/context. Supersession là relation, không enum chứng cứ dùng lẫn.
- Duyệt rule, phát hành pack và gate sử dụng là các trạng thái riêng. Approved chưa publish hoặc blocked không được dùng cho eligibility hiện hành.
- Eligibility dùng predicates có kiểu; benefit/checklist/procedure dùng claims có kiểu/căn cứ riêng. Không tạo facts SSOT giả để chứa giấy tờ hoặc mức hỗ trợ.

## 6. Điểm dừng và trạng thái quyền

D01–D03 đã được người dùng chốt: lõi + agent Hà Nội, owner/staff theo quyền với owner duyệt facts quan trọng, nguồn tự cập nhật và DTT/chuyên gia duyệt rules. Không xin chốt lại.

D04 và D05 đã được người dùng chốt ngày 19/10/2026: nhân viên chỉ xem/đề xuất trong phạm vi được giao, owner xác nhận mọi thay đổi nghiệp vụ SSOT; tài liệu tài chính xử lý tại server và Claude chỉ nhận chỉ tiêu tối thiểu được người có quyền cho phép, không nhận bản gốc. Chat/tệp riêng không tự chia sẻ. Quyền đọc, xác nhận SSOT, cho phép egress chỉ tiêu và ngân sách là bốn quyền riêng; runtime phải có manifest/grants cụ thể, không tự mở tài nguyên cũ hoặc chạy migration.

D07 đã được người dùng chốt ngày 19/10/2026 theo phương án A: dừng riêng phần chưa đủ căn cứ hiện hành; vẫn trả phần hợp lệ và lịch sử có nhãn, theo quyền. Không tự dùng phương án B để tiếp tục kết luận mới từ bản lưu chưa đạt yêu cầu hiện hành. Việc chọn A không tự gán reviewer/publisher hoặc phát hành pack thật.

Chưa cấp ngân sách D06. Thiết kế không cần lượt Claude/embedding nào; trước nghiệm thu thực sẽ trình bộ ca, số call/token và trần phí theo giá đã kiểm. Danh tính/quyền reviewer/publisher, retention và môi trường triển khai phải đủ trước phát hành/thí điểm; không hỏi lại D04/D05/D07.

## 7. Từ thiết kế đến thực thi

| Chặng | Thứ tự ưu tiên |
|---|---|
| Lõi an toàn và cộng tác | Contracts, SSOT/ACL/context, operation/ledger; giữ dữ liệu cũ private đến khi được cấp quyền |
| Tri thức có nguồn | Source lifecycle, FTS, SQL graph/rules/typed claims và review/publish workflow |
| Agent Hà Nội | Pack đủ nguồn/duyệt, flow Trà Sen và chat mobile; không làm một app riêng |
| Nghiệm thu | Hồi quy xác định, isolation/crash/reload; rồi Claude thật và tự phục vụ trên bản đóng băng trong grant |

T01–T11 trong kế hoạch được bao phủ ở các tài liệu trên. T06 mới được đặc tả ở mức nội dung và hành vi; mockup triển khai và walkthrough thực thuộc chặng làm app. Không chạy deployment hoặc sửa app đang dùng trong lượt này.
