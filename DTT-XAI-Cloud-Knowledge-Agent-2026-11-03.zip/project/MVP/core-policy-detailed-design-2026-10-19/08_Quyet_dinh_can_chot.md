# Quyết định dữ liệu, chi phí và quản trị

Ngày 19/10/2026. Phân biệt đã được người dùng chốt, phương án đề xuất và cấu hình chưa được cấp quyền. Việc mô tả schema/contract không tự cấp quyền đọc dữ liệu hoặc chi tiêu.

## 1. Đã chốt — không hỏi lại

| ID | Quyết định |
|---|---|
| D01 | Hoàn thiện lõi + thiết kế agent chính sách Hà Nội |
| D02 | Chủ doanh nghiệp và nhân viên được phân quyền dùng SSOT; chủ duyệt dữ kiện quan trọng |
| D03 | Nguồn tự cập nhật; DTT/chuyên gia duyệt quy tắc tư vấn |
| D04 | Chốt ngày 19/10/2026: nhân viên xem/đề xuất SSOT trong phạm vi được giao; chủ doanh nghiệp xác nhận mọi thay đổi nghiệp vụ vào SSOT; chat/tệp riêng không tự chia sẻ |
| D05 | Chốt ngày 19/10/2026: xử lý tài liệu tài chính tại server; chỉ gửi Claude chỉ tiêu tối thiểu được người có quyền cho phép; không gửi tài liệu gốc |
| D07 | Chốt ngày 19/10/2026, phương án A: dừng riêng phần chưa đủ căn cứ hiện hành; vẫn trả phần hợp lệ và cho xem lịch sử theo quyền |
| D-TECH | SQL cho SSOT/knowledge graph; chưa graph/vector DB riêng; cổng embedding chưa bật |
| D-COST | Không tự retry/fallback/escalation có phí; không gọi Claude để hoàn thành lượt thiết kế này |

## 2. Chi tiết quyết định và những lựa chọn còn mở

### D04 — Phạm vi staff và xác nhận SSOT · đã chốt 19/10/2026

**Quyết định của người dùng:** “Nhân viên đề xuất, chủ xác nhận SSOT (đề xuất)”. Staff chỉ xem/đề xuất facts thuộc hồ sơ và nhóm dữ kiện được giao. Trong MVP, owner xác nhận mọi facts nghiệp vụ đi vào SSOT; staff tự sửa nháp/ghi chú được giao nhưng không thay current facts. Quy tắc áp dụng cả fields thông thường, không chỉ các nhóm quan trọng như pháp lý, sản phẩm, giấy phép, thị trường và tài chính.

Ảnh/tệp/chat không tự chia sẻ theo quyền xem SSOT. Tài chính hạn chế riêng; DTT quản trị domain không mặc định xem hồ sơ doanh nghiệp. Owner có quyền quản lý SSOT không mặc định được xem mọi chat/tệp riêng chưa chia sẻ của nhân viên. Việc chuyển tài nguyên riêng sang dùng chung cần quyết định rõ của chủ tài nguyên theo quy chế doanh nghiệp được chốt.

**Các mở rộng không thuộc quyết định MVP:** nhân viên xác nhận facts thông thường hoặc mọi nhân viên cùng xem toàn bộ SSOT. Chỉ xem xét khi có thay đổi phạm vi được chốt riêng; không bật qua một grant routine để vượt D04.

**Hệ quả triển khai:** D04 đã đủ để khóa ma trận quyền ở mức sản phẩm; vẫn không tự chuyển `private_owner` thành shared hoặc cấp staff quyền đọc mọi tài nguyên cũ. Chủ tài nguyên/cơ chế quản trị được chốt phải cấp từng phạm vi rõ ràng. Lượt này cập nhật tài liệu, chưa chạy migration hoặc thay quyền app. Quyền xác nhận SSOT và quyền gửi chỉ tiêu theo D05 là hai quyền riêng.

### D05 — Dữ liệu tài chính gửi Claude · đã chốt 19/10/2026

**Quyết định của người dùng:** “xử lý tài liệu tài chính tại server, chỉ gửi Claude các chỉ tiêu tối thiểu được người có quyền cho phép; không gửi tài liệu gốc”. Parser/tính toán ở server; không gửi workbook, ảnh trang tài chính hoặc nội dung thô tương đương qua OCR/CSV/chat. Chỉ gửi typed metrics/phân loại tối thiểu đã cho phép cho đúng mục đích, value versions và provider. Ảnh sản phẩm/phần tài liệu không tài chính theo quyền đã có, nhưng không dùng tác vụ đó để vượt D05.

**Không thuộc quyền đã cấp:** gửi phần tài liệu tài chính gốc dù đã chọn trang hoặc crop; dùng Claude vision/OCR đọc tài chính; gửi dữ liệu sang provider/embedding/tracing mới; tự cấp ngân sách hoặc tự retry có phí. Người có quyền đọc chưa mặc định có quyền cho egress. Owner hoặc người được ủy quyền egress rõ mới cấp phép phần họ được xem/cho phép; staff không tự xác nhận facts SSOT.

**Hệ quả thiết kế:** [hợp đồng tài chính D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>) đặc tả chỉ tiêu có provenance, egress grant/preview/manifest riêng và kiểm trước dispatch. D05 không cần hỏi lại. Chưa gọi API hoặc thay app; một lượt thực vẫn cần grant dữ liệu cụ thể và ngân sách D06. Các cấu hình retention/triển khai vẫn chốt trước thí điểm.

### D06 — Hạn mức gọi model cho vòng nghiệm thu · đã duyệt và hoàn tất một đợt giới hạn

**Cập nhật triển khai 19/10/2026:** người dùng duyệt đúng 1 Sonnet 5.5 (trần 0,20 USD) và 1 Opus 5.5 (trần 0,40 USD), tổng 0,60 USD cho Trà Sen QA/policy. Đã chạy đúng hai lượt, không retry; usage ước tính tổng 0,074886 USD. Hai grant đã đóng. [Phạm vi, phê duyệt và đối soát](<../../../REFERENCE_LINKS.md#ref-0028>). Không có hạn mức thường xuyên, không cấp cho tác vụ khác hoặc doanh nghiệp thực tế từ phê duyệt này.

Đợt thiết kế hiện tại không cần call. Runtime grant/budget schema và UI được đặc tả, nhưng không điền một mức tiền tùy ý như đã được đồng ý. Khi bản triển khai và bộ ca đã sẵn sàng, trình số lượt tối đa theo từng model, giới hạn input/output, bảng giá đã kiểm, ngân sách dự phòng cho lượt chưa rõ kết quả và trần tổng.

**Hai phương án khi đến mốc đó:** (A) mỗi đợt nhỏ có một trần tổng và số call cụ thể, hết thì dừng; (B) xác nhận từng nhiệm vụ với phí dự kiến trước gửi. Trong cả hai, lỗi/unknown không tự gọi lượt mới. Ngân sách đợt thử không tự biến thành ngân sách chạy nền hằng ngày.

**Dừng ở đâu:** chưa có grant thì không dispatch. Đây chưa phải lời xin cấp một số tiền ngay trong đợt thiết kế, vì chưa có workload và ước lượng cụ thể để xem.

### D07 — Xử lý phần thiếu căn cứ hiện hành · phương án A đã chốt 19/10/2026

**Quyết định của người dùng:** “Dừng riêng phần chưa đủ căn cứ; vẫn trả phần hợp lệ và lịch sử (đề xuất)”. Áp dụng phương án A: dừng kết luận mới của phần cần căn cứ hiện hành chưa xác minh; các outcome độc lập còn đủ căn cứ vẫn trả. Nguồn có dấu hiệu thay đổi điều kiện/hết hiệu lực làm phần phụ thuộc cần rà/chặn theo workflow; vẫn xem báo cáo lịch sử có nhãn và quyền hiện hành. Lỗi mạng không tự chứng minh văn bản đã hết hiệu lực.

[Ma trận D07](<12_Chinh_sach_nguon_va_phat_hanh_D07.md>) là căn cứ đặc tả các gate này. Phương án B dùng bản lưu để tiếp tục tư vấn mới khi chưa đạt yêu cầu hiện hành **không được chọn cho MVP**; không tự bật ngoại lệ B bằng TTL hoặc source profile. Nguồn thiếu toàn văn/rule chưa duyệt/blocked không được dùng cho assessment. Bản lưu được xem như lịch sử/tham khảo có nhãn, không giả là kết luận hiện hành.

V1 không tự kết luận được hưởng. DTT curator chuẩn bị rule; chuyên gia đúng scope review; publisher phát hành pack. Có thể một người giữ nhiều vai ở MVP nếu user chốt quy chế, nhưng bản kiểm soát phải ghi rõ vai, quyết định và version. Chưa gán tên người hoặc thời hạn xử lý giả.

**Hệ quả triển khai:** D07 fallback đã chốt, không hỏi lại. Cần cấu hình danh tính/quyền reviewer/publisher và phê duyệt version thật trước publish pack; đây là cửa vận hành riêng, không được suy từ việc chọn A. Không gán người, mở job hay phát hành pack trong lượt cập nhật tài liệu này.

## 3. Cấu hình để sau, không biến thành câu hỏi kỹ thuật cho người dùng

- SQLite/FTS5, foreign keys/indices, outbox/worker, contract version và schema DSL: nhóm kỹ thuật tự xử lý theo đặc tả.
- Chọn vendor embedding/vector/graph: chưa cần quyết định hoặc mua; có benchmark và dữ liệu gửi ra ngoài rồi mới đề xuất.
- Cảnh báo ngoài app: chưa triển khai. Nếu cần email/Zalo, chốt kênh, người nhận, subscription và quyền gửi trước.
- Retention/backup/địa điểm hosting: cần chính sách trước thí điểm nhiều doanh nghiệp thực. Thiết kế tách retention của raw tài liệu/chat/ledger/facts; không tự đặt một thời hạn duy nhất rồi xóa mất hồ sơ chuẩn hoặc giữ mọi tài liệu nhạy cảm vô hạn.
- Bộ chính sách demo: đề xuất tư vấn số hóa theo nguồn đã khảo sát. Mức hỗ trợ/giấy tờ/thủ tục phải lấy từ full text/phụ lục đã review, không từ search snippet.

## 4. Cách xử lý khi người dùng chưa trả lời

Các mã phụ ở tài liệu chuyên đề được đối chiếu về sổ này: D-R01 → D04/D05 (phạm vi index/quyền), D-R02 → D07 (fallback nguồn), D-R03 → chính sách retention trước thí điểm, D-R04 → D05/D06 và phê duyệt provider mới, D-R05 → D06/D07/kênh cảnh báo. Không coi đây là những lần xin phê duyệt lại cùng một quyết định.

Chỉ các quyết định chưa có trả lời còn pending; D04, D05 và D07 đã chốt ngày 19/10/2026. D06 có một đợt giới hạn đã chạy và đóng như ghi trên; chưa có ngân sách thường xuyên. Cấu hình reviewer/publisher, retention và triển khai phải đủ trước các hành động liên quan. Không coi im lặng/hết thời gian là đồng ý. Khi có trả lời mới, ghi ngày/quyết định và cập nhật policy/schema test; không sửa lịch sử như thể lựa chọn đó đã được chốt từ trước.
