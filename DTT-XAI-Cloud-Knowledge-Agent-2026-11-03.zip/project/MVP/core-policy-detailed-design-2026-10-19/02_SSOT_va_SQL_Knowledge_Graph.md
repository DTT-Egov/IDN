# SSOT cộng tác và Knowledge Graph trên SQL

Ngày: **19/10/2026**. Trạng thái: **thiết kế đích để review và triển khai; chưa phải chức năng đã chạy**. Không đọc nội dung hồ sơ doanh nghiệp, không chuyển dữ liệu, không thay đổi app hoặc gọi API mô hình trong đợt lập tài liệu.

Tài liệu gốc: [hiện trạng 0.4](<../../../REFERENCE_LINKS.md#ref-0019>), [kế hoạch T03/T05/T11](<../../../REFERENCE_LINKS.md#ref-0020>). Đây là một phần của bộ thiết kế lõi và agent chính sách Hà Nội; schema dưới đây là schema đích đề xuất, không là bản migration có thể chạy ngay trên DB hiện hành.

## 1. Quyết định nền và ranh giới

Đã chốt: chủ doanh nghiệp và nhân viên được phân quyền dùng chung SSOT. D04 được người dùng xác nhận ngày 19/10/2026: staff chỉ xem/đề xuất trong phạm vi được giao, chủ doanh nghiệp xác nhận mọi thay đổi nghiệp vụ vào SSOT trong MVP. Chat/tệp riêng không tự chia sẻ. Nguồn chính sách có thể tự cập nhật, nhưng DTT/chuyên gia duyệt quy tắc tư vấn. Giữ SQL làm kho có thẩm quyền; chưa dùng graph/vector database riêng.

SSOT trả lời “doanh nghiệp hiện đã xác nhận điều gì, ai xác nhận, áp dụng cho đối tượng và thời kỳ nào”. Knowledge graph trả lời “quy tắc nào phụ thuộc điều khoản nào; điều kiện nào cần dữ kiện nào; báo cáo nào cần rà khi căn cứ đổi”. Không dùng lịch sử chat làm bộ nhớ chuẩn và không coi một quan sát do AI bóc tách là sự thật đã được doanh nghiệp duyệt.

| Nhóm | Kho có thẩm quyền | Dùng lại |
|---|---|---|
| Hồ sơ doanh nghiệp | Facts có kiểu, quyết định, phiên bản và quyền tài nguyên | Trong doanh nghiệp, đúng quyền và mục tiêu |
| Tệp/chat/nháp | Tài nguyên riêng với ACL riêng | Không tự chia sẻ vì người đọc có quyền SSOT |
| Tri thức domain | Snapshot nguồn, quy tắc/điều kiện và lần duyệt | Nhiều doanh nghiệp nếu quyền sử dụng, phạm vi và hiệu lực phù hợp |
| Kết quả đối chiếu chính sách | Kết quả riêng gắn facts/rules/context snapshot | Chỉ trong tài nguyên được phép của doanh nghiệp đó |
| Graph/FTS/chỉ mục | Projection từ dữ liệu chuẩn | Dựng lại được; không có quyền rộng hơn nguồn |

Không đưa kết luận riêng của doanh nghiệp A vào kho chung bằng cách chỉ xóa tên. Không có đường ghi từ agent trực tiếp vào bảng dữ kiện hiện hành hoặc phát hành quy tắc công cộng.

## 2. Phạm vi dữ kiện và định danh

`enterprise_id` là biên cách ly doanh nghiệp trong lõi. `tenant_id` hiện có có thể tiếp tục dùng để chỉ phân vùng triển khai; không được dùng giá trị `local-v03` chung làm biên bảo mật thay cho enterprise. Mọi bản ghi riêng có `enterprise_id`; mọi truy vấn và FK riêng dùng khóa kép doanh nghiệp–ID. ID ngẫu nhiên không thay thế kiểm quyền.

| Entity type | Ví dụ | Dữ kiện thuộc phạm vi |
|---|---|---|
| `enterprise` | Công ty Trà Sen | Tên pháp lý, mã đăng ký, phân loại doanh nghiệp |
| `facility` | Cơ sở sản xuất A | Địa điểm, hoạt động, năng lực, giấy phép |
| `product` | Trà Sen | Tên giữ nguyên hoa thường, thành phần, lượng tịnh |
| `market_profile` | Trà Sen / Mỹ, Đức, Nhật | Tên trên nhãn, đơn vị chịu trách nhiệm, yêu cầu riêng |
| `financial_period` | Báo cáo năm cụ thể | Doanh thu, lao động, tài sản theo kỳ; có tài liệu hạn chế |
| `enterprise_goal` | Đổi mới máy đóng gói | Mục tiêu, phạm vi, giai đoạn, nhu cầu hỗ trợ |

`market_profile` phải có đúng một product cha và một `market_code`; không kế thừa tên nhãn Mỹ sang Đức/Nhật. `facility` tách khỏi product để chỉ hỏi địa chỉ cơ sở một lần khi nhiều sản phẩm cùng dùng. Quan hệ `produced_at` có hiệu lực thời gian; không suy từ một chat cũ rằng mọi sản phẩm đều làm ở cùng cơ sở.

Sở thích giao tiếp, model preference, nhiệm vụ và bản nháp có phạm vi riêng; không trộn vào facts đăng ký doanh nghiệp. Khóa hiển thị tìm kiếm được chuẩn hóa riêng, còn `display_name` và giá trị đã xác nhận giữ nguyên Unicode/hoa thường. Không dùng tên sản phẩm làm khóa định danh duy nhất và không tự hợp nhất hai sản phẩm gần tên.

Các định danh liên thông: `operation_id`, `mission_id`, `task_id`, `outcome_id`, `context_revision_id`, `context_snapshot_id`, `source_snapshot_id`, `chunk_id`, `rule_version_id`, `claim_version_id`, `policy_version_id`, `pack_version_id`. `context_revision_id` là phiên bản enterprise; `context_snapshot_id` là tập ngữ cảnh tối thiểu bất biến cho task. `policy_version_id` chỉ một phiên bản chính sách, còn `pack_version_id` là bundle phát hành gồm nhiều policy/rule/claim versions; không dùng hai ID này thay nhau. `actor_id` và enterprise đang hoạt động lấy từ phiên/cấp quyền phía server; dữ liệu từ mô hình không được chọn actor hoặc tenant.

## 3. Phân quyền cộng tác: D04 đã chốt

Quyền là phép giao của **membership hiện hành ∩ quyền tài nguyên ∩ quyền nhóm trường ∩ quyền hành động**. Owner của doanh nghiệp không mặc nhiên đọc mọi chat hoặc tài liệu riêng của nhân viên. Quyền quản trị kho tri thức của DTT không mặc nhiên là membership doanh nghiệp.

### 3.1. Ma trận quyền theo D04

| Tài nguyên/hành động | Chủ doanh nghiệp | Nhân viên được cấp đúng phạm vi | DTT/chuyên gia domain | Agent |
|---|---|---|---|---|
| SSOT chung cơ bản | Xem, đề xuất, xác nhận | Xem/đề xuất theo grant | Không có mặc định | Chỉ đọc context được cấp |
| Facts quan trọng | Xác nhận/thay thế/rút lại | Đề xuất, không tự xác nhận | Không có mặc định | Chỉ đề xuất |
| Facts nghiệp vụ ít rủi ro | Xác nhận | Chỉ đề xuất trong MVP, không có quyền xác nhận routine | Không có mặc định | Không tự xác nhận |
| Doanh thu/tài chính | Xem theo quyền hồ sơ chủ doanh nghiệp | Chỉ nhóm được cấp `finance.read` | Không có mặc định | Chỉ phần cần thiết nếu được cấp |
| Chat/tệp riêng | Chỉ của mình hoặc được chia sẻ | Chỉ của mình hoặc được chia sẻ | Không có mặc định | Chỉ tài nguyên task được cấp |
| Mission/báo cáo dùng chung | Theo ACL mission | Theo ACL mission, không suy từ quyền đọc SSOT | Không có mặc định | Ghi kết quả vào task được cấp |
| Chia sẻ, thu hồi, cấp quyền | Owner quản trị trong doanh nghiệp | Không được tự mở rộng quyền | Không có mặc định | Không được cấp quyền |
| Xem nguồn công cộng | Có | Có | Có | Theo tool/source allowlist |
| Duyệt/phát hành rule domain | Không theo vai trò owner doanh nghiệp | Không | Theo vai trò review đã cấp riêng | Chỉ tạo nháp |

**D04 đã được người dùng chốt ngày 19/10/2026.** Owner xác nhận mọi facts nghiệp vụ đi vào SSOT; staff chỉ sửa nháp/đề xuất trong phạm vi được giao. Quyền routine trong schema là điểm mở rộng tương lai, không được bật ở MVP. Tài nguyên hiện có giữ `private_owner` đến khi có chia sẻ/cấp phạm vi rõ; chốt ma trận không tự cấp grants hoặc chạy migration.

### 3.2. Trường nào quan trọng?

| Nhóm/trường mẫu | Đề xuất mức duyệt | Lý do |
|---|---|---|
| Tên pháp lý, mã đăng ký/mã số thuế, loại hình, địa chỉ đăng ký | Owner | Xác định đúng đối tượng chính sách |
| Địa chỉ và hoạt động cơ sở, giấy phép, chứng nhận | Owner | Có thể quyết định phạm vi và điều kiện |
| Doanh thu, lao động, tài sản, nợ và kỳ báo cáo | Owner; quyền đọc hạn chế | Dữ liệu nhạy cảm, ảnh hưởng phân loại/điều kiện |
| Thành phần, chất gây dị ứng, lượng tịnh, xuất xứ | Owner | Ảnh hưởng kết luận và tài liệu xuất khẩu |
| Tên sản phẩm dùng pháp lý/nhãn, đơn vị chịu trách nhiệm theo thị trường | Owner | Tránh dùng sai thị trường/tên |
| Số tiền, vốn đối ứng và cam kết trong hồ sơ chính sách | Owner | Có trách nhiệm và tác động tài chính |
| Tên gọi nội bộ, mô tả marketing nháp, ghi chú vận hành | Staff được sửa nháp/ghi chú trong phạm vi; nếu lên facts SSOT phải owner xác nhận | Không dùng bản nháp làm bằng chứng đủ điều kiện |
| Sở thích giao tiếp cá nhân | Người sở hữu sở thích | Không sửa SSOT doanh nghiệp |
| Giá trị đo/đếm theo ngày trong Excel | Ngữ cảnh làm việc trước; chỉ lên SSOT bằng field định nghĩa rõ | Không biến số tồn trong file thành sổ kho chuẩn |

Quy tắc an toàn đề xuất: field mới chưa phân loại cần owner duyệt. Field đang là “ít rủi ro” nhưng được một rule đã duyệt dùng làm điều kiện trọng yếu phải được xem lại chính sách xác nhận, không âm thầm nâng quyền nhân viên. Khai báo danh sách này trong registry có phiên bản, không hardcode rải rác vào prompt.

Policy MVP theo D04 bắt buộc `owner_required` cho mọi field nghiệp vụ SSOT; không tạo/bật field policy `granted_routine` hoặc grant `resolve_routine_fact` cho staff. Các enum đó chỉ dành cho mở rộng sau quyết định mới. Repository và tool xác nhận vẫn kiểm owner hiện hành ngay trong giao dịch, kể cả khi gặp grant/metadata legacy sai; không cho registry rời rạc vượt D04.

### 3.3. Không làm lộ qua provenance hoặc kết quả dẫn xuất

Nếu facts đã được chia sẻ nhưng tệp nguồn vẫn riêng, người được cấp facts có thể xem giá trị và trạng thái “nguồn chi tiết bị hạn chế”; không được xem tên tệp, đoạn văn, ảnh thu nhỏ hoặc URL tải khi thiếu quyền. Để owner xác nhận một đề xuất quan trọng từ tệp riêng, người đề xuất chia sẻ riêng **thẻ bằng chứng tối thiểu** chứa đúng phần cần xác nhận, hoặc owner chỉ xác nhận là dữ kiện tự khai và trạng thái xác minh giữ nguyên. Không tự mở toàn bộ file.

ACL của câu trả lời/artifact không rộng hơn phần dữ liệu riêng được dùng để tạo nó. Muốn chia sẻ báo cáo rộng hơn phải tạo bản lược bỏ riêng và kiểm lại căn cứ; không chỉ sửa cờ ACL. Thu hồi quyền chặn đọc context snapshot, artifact, file và cache tương ứng ngay ở lần đọc sau; không chỉ lọc danh sách bên ngoài.

## 4. Dữ kiện: quan sát → đề xuất → quyết định → phiên bản

```mermaid
flowchart LR
  D["Ảnh / Excel / câu người dùng"] --> O["Observation bất biến\nlocator + raw hash + độ chắc"]
  O --> P["Proposal có kiểu\nđối tượng + field + giá trị + thời kỳ"]
  P --> V["Kiểm schema, quyền và xung đột"]
  V --> R["Quyết định người có quyền\nCAS + lý do + policy version"]
  R --> F["Fact version có hiệu lực\nvalid time + system time"]
  F --> C["Context revision bất biến"]
  C --> E["Đối chiếu rule / nhiệm vụ"]
```

### 4.1. Hợp đồng giá trị

Mỗi field định nghĩa `value_kind`, đơn vị, enum/schema, sensitivity, scope và confirmation policy. Registry tối thiểu có các kiểu: `string`, `integer`, `decimal`, `boolean`, `date`, `money`, `quantity`, `enum`, `string_set`, `entity_ref`.

Số tiền và số đo dùng chuỗi thập phân chuẩn + đơn vị/mã tiền tệ; tính toán bằng Decimal/hàm xác định, không dùng float để so ngưỡng. Địa chỉ có cấu trúc, giữ nguyên chuỗi người dùng; không tự suy mã địa bàn từ chuỗi nếu chưa kiểm. Tên và mã sản phẩm không ép chữ thường. `certifications=null` là chưa biết; `[]` chỉ là “xác nhận không có mục nào” khi người dùng đã khai rõ, không là fallback parse.

| `value_state` | Giá trị | Cách dùng |
|---|---|---|
| `known` | Có payload hợp lệ, có thể là `false`, `0` hoặc tập rỗng được khai rõ | Được đối chiếu khi còn hiệu lực, đúng scope/quyền |
| `unknown` | Không có payload | Thiếu thông tin; không biến thành false hoặc không có |
| `explicit_absent` | Không có payload, có quyết định phủ nhận rõ | Ví dụ xác nhận chưa có một giấy phép cụ thể |
| `disputed` | Không có giá trị chuẩn để dùng; giữ các candidate trong proposal | Cần giải quyết xung đột |

`verification_status` riêng: `self_declared`, `document_supported`, `externally_verified`. Đọc thấy số trong file không tự thành `externally_verified`; người xác nhận owner cũng không tự nâng mức xác minh. Chuỗi “không phải hồ sơ đã lưu” trong chat không phải lệnh xóa/thay facts; thay facts cần action có schema và xác nhận.

### 4.2. Thời gian nghiệp vụ và thời gian hệ thống

- `valid_from`/`valid_to`: khoảng thời gian nghiệp vụ mà người xác nhận khẳng định giá trị áp dụng; khoảng nửa mở `[from,to)`. Kỳ doanh thu và ngày hiệu lực giấy phép phải được lưu riêng chính xác.
- `system_from`/`system_to`: khoảng thời gian hệ thống đã coi bản fact đó là phiên bản chuẩn; thời gian UTC do server ghi.
- `target_date`/`as_of`: ngày/ngữ cảnh cần đánh giá; `known_at`: thời điểm tri thức hệ thống được dùng để tái dựng lịch sử. Mặc định `known_at=now`.
- **Quyền đọc luôn kiểm ở hiện tại**, không dùng membership/ACL lịch sử để khôi phục quyền đã thu hồi.

Không biết ngày áp dụng phải ghi `temporal_basis=current_only`, không giả định có hiệu lực vô hạn từ quá khứ. Dữ kiện kiểu này dùng cho hiện trạng theo chính sách freshness của field; truy vấn một thời kỳ quá khứ trả `unknown_for_target_date`, không lấy bừa giá trị hiện nay. Với `interval`, cận rỗng chỉ mang nghĩa vô hạn nếu người/nguồn có thẩm quyền đã xác nhận như vậy. `asserted_at`, `recorded_at`, ngày ảnh và ngày tạo file không thay thế `valid_from`.

Sửa sai hồi tố tạo quyết định mới: phiên bản cũ đóng `system_to`; tạo các segment valid-time mới, giữ đoạn không bị sửa. Không ghi đè giá trị cũ. Hai segment còn hiệu lực hệ thống của cùng entity/field không được chồng valid-time khi `temporal_basis=interval`. Fact được hẹn hiệu lực tương lai không thay giá trị đang dùng hôm nay.

### 4.3. CAS và giao dịch xác nhận

Yêu cầu `resolve_fact_proposals` gồm operation/idempotency key, danh sách proposal ID, `expected_field_version` cho từng field và `expected_context_revision_id`. Server lấy actor/enterprise từ auth, không nhận từ mô hình. Quan trọng: người dùng xác nhận đúng giá trị/scope/thời kỳ/bằng chứng đã xem, không xác nhận một nội dung mà AI được phép thay sau đó.

Trong một giao dịch `BEGIN IMMEDIATE`: kiểm membership/ACL hiện hành → kiểm field policy và quyền owner → kiểm proposal hash còn đúng → kiểm head version/CAS → kiểm không chồng thời kỳ → ghi resolution và fact segments → tăng head/context revision → ghi dependency invalidation + outbox → lưu operation result → commit. Một yêu cầu nhiều field hoặc thành công nguyên bộ, hoặc trả xung đột với field cụ thể; không cập nhật lưng chừng.

CAS đổi head chỉ thành công nếu `WHERE version=:expected`; `rowcount != 1` trả `409 fact_version_conflict`, kèm giá trị mới được phép xem và proposal cũ để so sánh. Không cho AI tự chọn người thắng. `expected_context_revision_id` xác định ngữ cảnh người dùng đã xem: nếu revision toàn doanh nghiệp thay đổi nhưng các field/dependency liên quan và quyền vẫn nguyên thì có thể tiếp tục, ghi rõ revision thực tế; không buộc nhập lại vì một field không liên quan đổi. Thay đổi liên quan phải trả xung đột, không tự chấp nhận. Cùng operation + cùng request hash trả nguyên kết quả; cùng operation khác payload trả `409 idempotency_conflict`. Không có cuộc gọi LLM trong giao dịch.

`withdraw` nghĩa rút quyết định cho phạm vi thời gian được khai rõ, đóng/split segment đang áp dụng và để phần không có fact chuẩn thành unknown; không tự quay lại proposal cũ. Muốn xác nhận không có giá trị cần proposal mới `explicit_absent`; muốn xóa dữ liệu cá nhân phải qua quy trình dữ liệu, không giả dạng action withdraw.

## 5. Schema lõi đề xuất trên SQL

Các đoạn DDL mô tả ràng buộc chuẩn của thiết kế; tên identity hiện hữu được giữ để thấy đường migration. Dùng `PRAGMA foreign_keys=ON` ở mỗi connection, FK composite cho mọi liên kết riêng. Trước khi tạo bảng mới phải bổ sung unique key tương ứng cho bảng hiện hữu nếu cần. JSON chỉ giữ payload có schema; state, scope, time, ACL và FK không giấu trong JSON.

```sql
CREATE TABLE ssot_resources (
  enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
  resource_id TEXT NOT NULL,
  resource_type TEXT NOT NULL CHECK (resource_type IN
    ('ssot_entity','conversation','attachment','evidence_card','mission','artifact','context')),
  created_by_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  sharing_state TEXT NOT NULL CHECK (sharing_state IN ('private','explicit_shared','enterprise_ssot')),
  acl_revision INTEGER NOT NULL DEFAULT 1 CHECK (acl_revision > 0),
  created_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,resource_id)
);
CREATE TABLE ssot_resource_grants (
  enterprise_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  grantee_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  capability TEXT NOT NULL CHECK (capability IN
    ('read','propose_fact','resolve_routine_fact','share','read_finance')),
  granted_by_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  granted_at TEXT NOT NULL,
  revoked_at TEXT,
  PRIMARY KEY (enterprise_id,resource_id,grantee_account_id,capability),
  FOREIGN KEY (enterprise_id,resource_id)
    REFERENCES ssot_resources(enterprise_id,resource_id),
  CHECK (revoked_at IS NULL OR revoked_at >= granted_at)
);
CREATE TABLE ssot_entities (
  enterprise_id TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  entity_type TEXT NOT NULL CHECK (entity_type IN
    ('enterprise','facility','product','market_profile','financial_period','enterprise_goal')),
  display_name TEXT NOT NULL,
  parent_entity_id TEXT,
  market_code TEXT,
  lifecycle_state TEXT NOT NULL CHECK (lifecycle_state IN ('active','archived')),
  entity_version INTEGER NOT NULL DEFAULT 1 CHECK (entity_version > 0),
  PRIMARY KEY (enterprise_id,entity_id),
  UNIQUE (enterprise_id,resource_id),
  FOREIGN KEY (enterprise_id,resource_id)
    REFERENCES ssot_resources(enterprise_id,resource_id),
  FOREIGN KEY (enterprise_id,parent_entity_id)
    REFERENCES ssot_entities(enterprise_id,entity_id),
  CHECK ((entity_type='market_profile' AND parent_entity_id IS NOT NULL AND market_code IS NOT NULL)
    OR (entity_type<>'market_profile' AND market_code IS NULL))
);
CREATE UNIQUE INDEX ssot_market_identity ON ssot_entities
  (enterprise_id,parent_entity_id,market_code) WHERE entity_type='market_profile';

CREATE TABLE ssot_field_definitions (
  field_key TEXT NOT NULL,
  schema_version INTEGER NOT NULL CHECK (schema_version > 0),
  entity_type TEXT NOT NULL,
  value_kind TEXT NOT NULL CHECK (value_kind IN
    ('string','integer','decimal','boolean','date','money','quantity','enum','string_set','entity_ref')),
  value_schema_json TEXT NOT NULL CHECK (json_valid(value_schema_json)),
  sensitivity TEXT NOT NULL CHECK (sensitivity IN ('business','restricted','personal')),
  confirmation_policy TEXT NOT NULL CHECK (confirmation_policy IN ('owner_required','granted_routine')),
  freshness_policy_id TEXT NOT NULL,
  PRIMARY KEY (field_key,schema_version)
);
CREATE TABLE ssot_observations (
  enterprise_id TEXT NOT NULL,
  observation_id TEXT NOT NULL,
  source_resource_id TEXT NOT NULL,
  source_locator_json TEXT NOT NULL CHECK (json_valid(source_locator_json)),
  raw_excerpt_hash TEXT NOT NULL,
  observed_payload_json TEXT NOT NULL CHECK (json_valid(observed_payload_json)),
  extractor_version TEXT NOT NULL,
  operation_id TEXT,
  observed_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,observation_id),
  FOREIGN KEY (enterprise_id,source_resource_id)
    REFERENCES ssot_resources(enterprise_id,resource_id)
);
CREATE TABLE ssot_fact_proposals (
  enterprise_id TEXT NOT NULL,
  proposal_id TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  field_key TEXT NOT NULL,
  schema_version INTEGER NOT NULL,
  value_state TEXT NOT NULL CHECK (value_state IN ('known','unknown','explicit_absent','disputed')),
  value_json TEXT CHECK (value_json IS NULL OR json_valid(value_json)),
  temporal_basis TEXT NOT NULL CHECK (temporal_basis IN ('interval','current_only')),
  valid_from TEXT,
  valid_to TEXT,
  verification_status TEXT NOT NULL CHECK (verification_status IN
    ('self_declared','document_supported','externally_verified')),
  proposed_by_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  origin TEXT NOT NULL CHECK (origin IN ('human','ai_suggestion','migration')),
  proposal_hash TEXT NOT NULL,
  proposed_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,proposal_id),
  FOREIGN KEY (enterprise_id,entity_id) REFERENCES ssot_entities(enterprise_id,entity_id),
  FOREIGN KEY (field_key,schema_version) REFERENCES ssot_field_definitions(field_key,schema_version),
  CHECK ((value_state='known' AND value_json IS NOT NULL AND json_type(value_json)<>'null')
    OR (value_state<>'known' AND value_json IS NULL)),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from),
  CHECK (temporal_basis='interval' OR (valid_from IS NULL AND valid_to IS NULL))
);
CREATE TABLE ssot_proposal_observations (
  enterprise_id TEXT NOT NULL,
  proposal_id TEXT NOT NULL,
  observation_id TEXT NOT NULL,
  evidence_role TEXT NOT NULL CHECK (evidence_role IN ('supports','contradicts','context')),
  PRIMARY KEY (enterprise_id,proposal_id,observation_id,evidence_role),
  FOREIGN KEY (enterprise_id,proposal_id) REFERENCES ssot_fact_proposals(enterprise_id,proposal_id),
  FOREIGN KEY (enterprise_id,observation_id) REFERENCES ssot_observations(enterprise_id,observation_id)
);
CREATE TABLE ssot_fact_resolutions (
  enterprise_id TEXT NOT NULL,
  resolution_id TEXT NOT NULL,
  proposal_id TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('accept','reject','withdraw','correct')),
  actor_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  expected_field_version INTEGER NOT NULL CHECK (expected_field_version >= 0),
  confirmation_policy_version TEXT NOT NULL,
  operation_id TEXT NOT NULL,
  reason TEXT,
  recorded_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,resolution_id),
  FOREIGN KEY (enterprise_id,proposal_id) REFERENCES ssot_fact_proposals(enterprise_id,proposal_id)
);
CREATE TABLE ssot_fact_heads (
  enterprise_id TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  field_key TEXT NOT NULL,
  field_version INTEGER NOT NULL CHECK (field_version >= 0),
  PRIMARY KEY (enterprise_id,entity_id,field_key),
  FOREIGN KEY (enterprise_id,entity_id) REFERENCES ssot_entities(enterprise_id,entity_id)
);
CREATE TABLE ssot_fact_versions (
  enterprise_id TEXT NOT NULL,
  fact_version_id TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  field_key TEXT NOT NULL,
  proposal_id TEXT NOT NULL,
  resolution_id TEXT NOT NULL,
  field_version INTEGER NOT NULL CHECK (field_version > 0),
  temporal_basis TEXT NOT NULL CHECK (temporal_basis IN ('interval','current_only')),
  valid_from TEXT,
  valid_to TEXT,
  system_from TEXT NOT NULL,
  system_to TEXT,
  PRIMARY KEY (enterprise_id,fact_version_id),
  FOREIGN KEY (enterprise_id,entity_id) REFERENCES ssot_entities(enterprise_id,entity_id),
  FOREIGN KEY (enterprise_id,proposal_id) REFERENCES ssot_fact_proposals(enterprise_id,proposal_id),
  FOREIGN KEY (enterprise_id,resolution_id) REFERENCES ssot_fact_resolutions(enterprise_id,resolution_id),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from),
  CHECK (system_to IS NULL OR system_to > system_from),
  CHECK (temporal_basis='interval' OR (valid_from IS NULL AND valid_to IS NULL))
);
CREATE INDEX ssot_fact_asof ON ssot_fact_versions
  (enterprise_id,entity_id,field_key,system_to,valid_from,valid_to);
CREATE TABLE ssot_context_revisions (
  enterprise_id TEXT NOT NULL,
  context_revision_id TEXT NOT NULL,
  enterprise_revision INTEGER NOT NULL CHECK (enterprise_revision > 0),
  actor_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  operation_id TEXT NOT NULL,
  changed_fields_json TEXT NOT NULL CHECK (json_valid(changed_fields_json)),
  recorded_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,context_revision_id),
  UNIQUE (enterprise_id,enterprise_revision)
);
CREATE TABLE ssot_context_snapshots (
  enterprise_id TEXT NOT NULL,
  context_snapshot_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  context_revision_id TEXT NOT NULL,
  mission_id TEXT,
  task_id TEXT,
  requester_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  target_date TEXT NOT NULL,
  known_at TEXT NOT NULL,
  resolver_version TEXT NOT NULL,
  authorization_fingerprint TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  payload_json TEXT NOT NULL CHECK (json_valid(payload_json)),
  created_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,context_snapshot_id),
  UNIQUE (enterprise_id,context_snapshot_id,context_revision_id),
  FOREIGN KEY (enterprise_id,resource_id)
    REFERENCES ssot_resources(enterprise_id,resource_id),
  FOREIGN KEY (enterprise_id,context_revision_id)
    REFERENCES ssot_context_revisions(enterprise_id,context_revision_id)
);
CREATE TABLE ssot_context_snapshot_facts (
  enterprise_id TEXT NOT NULL,
  context_snapshot_id TEXT NOT NULL,
  fact_version_id TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,context_snapshot_id,fact_version_id),
  FOREIGN KEY (enterprise_id,context_snapshot_id)
    REFERENCES ssot_context_snapshots(enterprise_id,context_snapshot_id),
  FOREIGN KEY (enterprise_id,fact_version_id)
    REFERENCES ssot_fact_versions(enterprise_id,fact_version_id)
);
```

Ràng buộc ngoài CHECK cần thực thi bởi một repository ghi duy nhất và trigger bảo vệ tương ứng trong migration:

1. Membership của người được cấp grant và người cấp phải active trong cùng enterprise; `share` không cho phép tự cấp quyền rộng hơn quyền quản trị đang có. Owner-required kiểm owner đang active ngay trong giao dịch.
2. Parent của market profile phải là product cùng enterprise; quan hệ parent không được tạo vòng. Mọi entity resource phải có type `ssot_entity`. `entity_ref` bắt buộc FK kiểm trong repository; không chấp nhận ID ngoài enterprise.
3. Registry field phải khớp entity type, JSON type/unit/enum, schema version. Boolean `false`, số `0` và tập rỗng khai rõ không được bị kiểm kiểu truthiness loại bỏ.
4. Fact version chỉ tham chiếu proposal cùng entity/field và resolution chấp nhận/correct đúng proposal. Trigger/repository từ chối resolution kiểu reject làm current fact. Payload observation/proposal/resolution không sửa/xóa sau ghi; chỉ được đóng `system_to` một lần theo action có audit.
5. Kiểm overlap interval cho cùng entity/field tại `system_to IS NULL`, kể cả khoảng vô hạn; đóng/split phiên bản trong cùng giao dịch. Với current_only chỉ một bản active; chuyển sang interval phải đóng bản current_only trong cùng giao dịch. Không để hai đường cùng trả giá trị chuẩn.
6. Grant có lịch sử sự kiện riêng để audit việc cấp/thu hồi/cấp lại; bảng trên là head hiện hành của grant. Không bật lại grant chỉ bằng xóa `revoked_at` mà không có event mới.
7. Bảng operation, immutable context snapshot, audit/outbox dùng contract điều phối chung của bộ thiết kế. Context revision là con trỏ phiên bản doanh nghiệp, **không** chứa toàn bộ dữ liệu doanh nghiệp để gửi model. Artifact/mission lưu FK tới resource và snapshot riêng, không kế thừa quyền toàn enterprise.

`ssot_entity_relations` là bảng quan hệ riêng có cột `enterprise_id, relation_id, source_entity_id, target_entity_id, relation_type, valid_from, valid_to, system_from, system_to, resolution_id`; FK kép tới hai entity và resolution. Registry cho phép ban đầu `produced_at(product→facility)`, `operates_at(enterprise→facility)`, `goal_for(enterprise_goal→enterprise/product/facility)`; kiểm đúng cặp type, no duplicate active và no self-edge. Không có quan hệ do mô hình tự đặt tên hoặc quyền lấy giá trị từ entity lân cận ngoài brief.

## 6. Knowledge graph công cộng: nguồn, quy tắc và điều kiện

Graph logic là một tập quan hệ có kiểu trên SQL. Nguồn canonical dùng chung với retrieval: `source_registry(source_id)`, `source_snapshots(source_snapshot_id)`, `source_chunks(chunk_id,source_snapshot_id)`. Không tạo kho nguồn thứ hai. Mỗi snapshot/chunk có hash và locator bất biến; bản dịch chỉ hỗ trợ đọc, citation vẫn giữ nguyên bản.

### 6.1. Các bảng chuẩn

```sql
CREATE TABLE knowledge_policies (
  policy_id TEXT PRIMARY KEY,
  policy_key TEXT NOT NULL UNIQUE,
  jurisdiction_code TEXT NOT NULL,
  title_vi TEXT NOT NULL
);
CREATE TABLE knowledge_policy_versions (
  policy_version_id TEXT PRIMARY KEY,
  policy_id TEXT NOT NULL REFERENCES knowledge_policies(policy_id),
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  source_snapshot_id TEXT NOT NULL REFERENCES source_snapshots(source_snapshot_id),
  published_on TEXT,
  legal_effective_from TEXT,
  legal_effective_to TEXT,
  effective_state TEXT NOT NULL CHECK (effective_state IN
    ('unverified','not_yet_effective','effective','suspended','repealed','superseded')),
  content_hash TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  UNIQUE (policy_id,revision_no),
  CHECK (legal_effective_to IS NULL OR legal_effective_from IS NULL
    OR legal_effective_to > legal_effective_from)
);
CREATE TABLE knowledge_rule_versions (
  rule_version_id TEXT PRIMARY KEY,
  rule_key TEXT NOT NULL,
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  policy_version_id TEXT NOT NULL REFERENCES knowledge_policy_versions(policy_version_id),
  purpose_code TEXT NOT NULL,
  jurisdiction_code TEXT NOT NULL,
  target_entity_type TEXT NOT NULL,
  valid_from TEXT,
  valid_to TEXT,
  review_state TEXT NOT NULL CHECK (review_state IN
    ('draft','in_review','approved','rejected','withdrawn')),
  publication_state TEXT NOT NULL CHECK (publication_state IN ('staged','published','withdrawn')),
  availability_state TEXT NOT NULL CHECK (availability_state IN
    ('usable','needs_review','blocked')),
  rule_hash TEXT NOT NULL,
  condition_schema_version TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (rule_key,revision_no),
  UNIQUE (policy_version_id,rule_version_id),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from)
);
CREATE TABLE knowledge_conditions (
  condition_id TEXT PRIMARY KEY,
  rule_version_id TEXT NOT NULL REFERENCES knowledge_rule_versions(rule_version_id),
  parent_condition_id TEXT,
  child_order INTEGER NOT NULL CHECK (child_order >= 0),
  node_type TEXT NOT NULL CHECK (node_type IN ('all','any','not','predicate')),
  condition_role TEXT NOT NULL CHECK (condition_role IN
    ('eligibility','exclusion','exception')),
  field_key TEXT,
  field_schema_version INTEGER,
  subject_selector TEXT,
  operator_code TEXT,
  expected_json TEXT CHECK (expected_json IS NULL OR json_valid(expected_json)),
  missing_behavior TEXT NOT NULL DEFAULT 'unknown' CHECK (missing_behavior='unknown'),
  label_vi TEXT NOT NULL,
  UNIQUE (rule_version_id,condition_id),
  FOREIGN KEY (rule_version_id,parent_condition_id)
    REFERENCES knowledge_conditions(rule_version_id,condition_id),
  FOREIGN KEY (field_key,field_schema_version)
    REFERENCES ssot_field_definitions(field_key,schema_version),
  CHECK ((node_type='predicate' AND field_key IS NOT NULL AND field_schema_version IS NOT NULL
      AND subject_selector IS NOT NULL AND operator_code IS NOT NULL)
    OR (node_type<>'predicate' AND field_key IS NULL AND field_schema_version IS NULL
      AND subject_selector IS NULL AND operator_code IS NULL AND expected_json IS NULL))
);
CREATE TABLE knowledge_evidence_bindings (
  evidence_binding_id TEXT PRIMARY KEY,
  rule_version_id TEXT NOT NULL,
  condition_id TEXT NOT NULL,
  source_snapshot_id TEXT NOT NULL REFERENCES source_snapshots(source_snapshot_id),
  chunk_id TEXT NOT NULL REFERENCES source_chunks(chunk_id),
  evidence_role TEXT NOT NULL CHECK (evidence_role IN ('primary','supporting')),
  argument_role TEXT NOT NULL CHECK (argument_role IN ('supports','exception','definition','context')),
  locator_json TEXT NOT NULL CHECK (json_valid(locator_json)),
  quote_original TEXT NOT NULL,
  quote_original_hash TEXT NOT NULL,
  span_hash TEXT NOT NULL,
  span_encoding_version TEXT NOT NULL,
  FOREIGN KEY (rule_version_id,condition_id)
    REFERENCES knowledge_conditions(rule_version_id,condition_id)
);
CREATE TABLE knowledge_review_events (
  review_event_id TEXT PRIMARY KEY,
  rule_version_id TEXT NOT NULL REFERENCES knowledge_rule_versions(rule_version_id),
  reviewer_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  action TEXT NOT NULL CHECK (action IN ('submit','approve','reject','withdraw','block','request_review')),
  reviewed_rule_hash TEXT NOT NULL,
  reviewed_evidence_set_hash TEXT NOT NULL,
  reviewer_role_version TEXT NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TEXT NOT NULL
);
CREATE TABLE knowledge_policy_relations (
  relation_id TEXT PRIMARY KEY,
  source_policy_version_id TEXT NOT NULL REFERENCES knowledge_policy_versions(policy_version_id),
  target_policy_version_id TEXT NOT NULL REFERENCES knowledge_policy_versions(policy_version_id),
  relation_type TEXT NOT NULL CHECK (relation_type IN ('amends','repeals','replaces','implements','supplements')),
  evidence_binding_id TEXT NOT NULL REFERENCES knowledge_evidence_bindings(evidence_binding_id),
  review_event_id TEXT NOT NULL REFERENCES knowledge_review_events(review_event_id),
  recorded_at TEXT NOT NULL,
  CHECK (source_policy_version_id <> target_policy_version_id),
  UNIQUE (source_policy_version_id,target_policy_version_id,relation_type)
);
```

`jurisdiction_code` là mã nội bộ có registry; ví dụ `VN-HN` không tự chứng minh một chính sách áp dụng cho mọi doanh nghiệp ở Hà Nội. Phạm vi lãnh thổ, ngành, loại hình, giai đoạn và thời kỳ phải là điều kiện đã duyệt. `published_on`, `legal_effective_from`, ngày lấy nguồn và ngày duyệt là các khái niệm khác nhau.

Ràng buộc khi submit/approve một rule:

- Cây điều kiện hữu hạn, không vòng, có các root được đặt tên cho eligibility/exclusion/exception; `not` có đúng một con, all/any không rỗng. `parent_condition_id` cùng rule; cặp field/schema và selector/operator thuộc registry. Giới hạn độ sâu/node count theo capability, không chạy SQL/Python do mô hình sinh. Mức hỗ trợ, công thức, thủ tục và tài liệu chuẩn bị là typed claims ở mục 6.2, không giả thành predicate cần field SSOT.
- Predicate có schema operator cụ thể: `eq`, `in_set`, `contains_all`, `contains_any`, `gte_decimal`, `lte_decimal`, `date_in_interval`, `exists`, `explicitly_absent`. Null/missing luôn unknown. So ngưỡng có unit/currency/period khớp, không tự đổi tiền/tính năm thiếu căn cứ.
- `subject_selector` là enum đăng ký như `enterprise`, `selected_product`, `selected_facility`, `financial_period_for_target_date`; không là SQL hay đường dẫn truy vấn tùy ý. Nhiều cơ sở/sản phẩm đòi chọn đúng đối tượng hoặc scope rõ, không tự gộp.
- Mỗi mệnh đề pháp lý cần binding chứng minh; ngoại lệ/định nghĩa được gắn vai trò cụ thể. `chunk_id` phải thuộc `source_snapshot_id` đã khai; quote/locator/hash phải khớp. Review gắn toàn bộ hash rule + evidence set. Đổi condition, source hoặc quote tạo rule version mới và mất trạng thái approved cho bản mới.
- `quote_original_hash` là SHA-256 của exact quote UTF-8; `span_hash` là SHA-256 manifest chuẩn gồm snapshot, extraction version, locator và quote. Lưu phiên bản canonical encoding với evidence schema để phát lại đúng; không dùng hash của bản dịch thay nguyên bản. `evidence_role=primary/supporting` và `argument_role` là hai trục riêng; supporting không được bù thiếu một căn cứ primary bắt buộc.
- Ba trục tách biệt: `review_state=draft/in_review/approved/rejected/withdrawn`; `publication_state=staged/published/withdrawn`; `availability_state=usable/needs_review/blocked`. Sử dụng cho tư vấn mới cần **approved + published + usable + đúng target_date/as_of**, và pack chứa bản đó cũng đã phát hành còn usable. Approved chưa published không được phục vụ doanh nghiệp. Nguồn bị bãi bỏ/thay thế hoặc evidence không còn đảm bảo sẽ block/needs_review dù đã từng duyệt/phát hành. Một lần lấy nguồn HTTP thành công không tự khôi phục usable; đọc lại kết quả lịch sử không có nghĩa được dùng lại rule đã rút để tư vấn hiện tại.
- Người duyệt phải có role domain hiện hành, riêng với role enterprise. Cơ chế bắt buộc người soạn khác người duyệt chưa được chốt; hệ thống lưu đủ actor để có thể thực thi. Chưa tự mặc định quyền phát hành cho mọi tài khoản DTT.

### 6.2. Typed claims cho quyền lợi, công thức, hồ sơ và thủ tục

`knowledge_conditions` chỉ đánh giá dữ kiện doanh nghiệp. Các nội dung “mức tối đa”, “cách tính”, “cần chuẩn bị giấy tờ gì”, “nộp cho ai/theo bước nào” có dữ liệu, bằng chứng, review và publication riêng; không yêu cầu doanh nghiệp phải có một fact SSOT tương ứng chỉ để đọc được thủ tục.

```sql
CREATE TABLE knowledge_claim_versions (
  claim_version_id TEXT PRIMARY KEY,
  claim_key TEXT NOT NULL,
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  policy_version_id TEXT NOT NULL REFERENCES knowledge_policy_versions(policy_version_id),
  rule_version_id TEXT,
  claim_type TEXT NOT NULL CHECK (claim_type IN ('amount','formula','preparation','procedure')),
  payload_schema_version TEXT NOT NULL,
  payload_json TEXT NOT NULL CHECK (json_valid(payload_json)),
  applies_when_mode TEXT NOT NULL CHECK (applies_when_mode IN
    ('policy_scope','rule_met','condition_met')),
  applies_when_condition_id TEXT,
  valid_from TEXT,
  valid_to TEXT,
  review_state TEXT NOT NULL CHECK (review_state IN
    ('draft','in_review','approved','rejected','withdrawn')),
  publication_state TEXT NOT NULL CHECK (publication_state IN ('staged','published','withdrawn')),
  availability_state TEXT NOT NULL CHECK (availability_state IN ('usable','needs_review','blocked')),
  claim_hash TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (claim_key,revision_no),
  UNIQUE (policy_version_id,claim_version_id),
  FOREIGN KEY (policy_version_id,rule_version_id)
    REFERENCES knowledge_rule_versions(policy_version_id,rule_version_id),
  FOREIGN KEY (rule_version_id,applies_when_condition_id)
    REFERENCES knowledge_conditions(rule_version_id,condition_id),
  CHECK ((applies_when_mode='policy_scope' AND rule_version_id IS NULL AND applies_when_condition_id IS NULL)
    OR (applies_when_mode='rule_met' AND rule_version_id IS NOT NULL AND applies_when_condition_id IS NULL)
    OR (applies_when_mode='condition_met' AND rule_version_id IS NOT NULL AND applies_when_condition_id IS NOT NULL)),
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to > valid_from)
);
CREATE TABLE knowledge_claim_evidence_bindings (
  claim_evidence_binding_id TEXT PRIMARY KEY,
  claim_version_id TEXT NOT NULL REFERENCES knowledge_claim_versions(claim_version_id),
  source_snapshot_id TEXT NOT NULL REFERENCES source_snapshots(source_snapshot_id),
  chunk_id TEXT NOT NULL REFERENCES source_chunks(chunk_id),
  evidence_role TEXT NOT NULL CHECK (evidence_role IN ('primary','supporting')),
  argument_role TEXT NOT NULL CHECK (argument_role IN ('supports','exception','definition','context')),
  locator_json TEXT NOT NULL CHECK (json_valid(locator_json)),
  quote_original TEXT NOT NULL,
  quote_original_hash TEXT NOT NULL,
  span_hash TEXT NOT NULL,
  span_encoding_version TEXT NOT NULL
);
CREATE TABLE knowledge_claim_review_events (
  claim_review_event_id TEXT PRIMARY KEY,
  claim_version_id TEXT NOT NULL REFERENCES knowledge_claim_versions(claim_version_id),
  reviewer_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  action TEXT NOT NULL CHECK (action IN ('submit','approve','reject','withdraw','block','request_review')),
  reviewed_claim_hash TEXT NOT NULL,
  reviewed_evidence_set_hash TEXT NOT NULL,
  reviewer_role_version TEXT NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TEXT NOT NULL
);
```

| `claim_type` | Payload có kiểu bắt buộc | Cách sử dụng |
|---|---|---|
| `amount` | `amount_decimal`, `currency`, `amount_kind` (fixed/cap/percentage), `basis`, `period`, nhãn giới hạn | Mức trong chính sách, không mặc định là tiền doanh nghiệp sẽ nhận; percentage không mang currency và có schema giới hạn riêng |
| `formula` | DSL version, AST allowlist, typed input references, currency/unit/period output, giới hạn/ràng buộc làm tròn | Thiếu input → không tính; trình công thức và phần thiếu, không điền 0 |
| `preparation` | Item ID, tên Việt, loại tài liệu, bắt buộc/có điều kiện, issuer/acceptance refs nếu nguồn nêu, thứ tự | Tạo checklist có source; không tự khẳng định doanh nghiệp đã có file |
| `procedure` | Step ID, thứ tự/phụ thuộc, hành động, chủ thể/cơ quan nhận, kênh được nguồn nêu, thời điểm/công thức deadline, output | Nguồn không nêu rõ chủ thể/khi nào → trường unknown có lý do, không tự bịa |

Payload dùng JSON Schema theo claim type/version; mệnh đề “bắt buộc” hoặc deadline cũng cần evidence tương ứng. Một claim không gom nhiều mệnh đề độc lập mà chỉ có citation chung: tách claim hoặc item có binding riêng trong schema. Amount/công thức mẫu trong fixture không là chính sách thật.

`applies_when_mode=policy_scope` cho phép giải thích thủ tục chung khi chưa biết doanh nghiệp đủ điều kiện; output ghi rõ tính tham khảo. `rule_met` chỉ cá nhân hóa khi root eligibility đạt và không có exclusion áp dụng/chưa rõ. `condition_met` cần condition chỉ định đạt **và** gate rule tương ứng; condition không vượt qua ngoại lệ/loại trừ. Unknown/conflict trả nội dung có điều kiện hoặc thiếu dữ kiện; không chuyển thành quyền lợi chắc chắn.

DSL công thức chỉ cho phép literal thập phân, field input đã đăng ký và các phép `add/subtract/multiply/divide/min/max` có schema/currency/unit; không `eval`, SQL, Python, network hoặc tham chiếu tùy ý. Giới hạn độ sâu/số node, Decimal và quy tắc làm tròn đã duyệt; chia 0, khác đơn vị/kỳ, missing hoặc disputed input trả not_calculable với lý do. Model chỉ đề xuất AST, expert duyệt hash trước phát hành. Model không được tự chạy công thức mới do nguồn nhúng vào.

Claim dùng cùng cổng approved + published + usable + as_of và policy effectiveness như rule. Đổi payload, applies_when, căn cứ hoặc schema làm claim version mới cần review/publication mới. Fact/rule/source thay đổi làm claim result liên quan needs_revalidation; không sửa kết quả cũ.

### 6.3. Publication và pack release có phiên bản

Review là xác nhận nội dung; publication là phát hành bản đã duyệt để phục vụ. Các state cột trên là projection/head để đọc nhanh; sự kiện review/publication/availability append-only giữ lịch sử. Không sửa payload/condition/membership của một bản đã published. Rút bản có sự kiện, không xóa dấu vết.

```sql
CREATE TABLE knowledge_rule_publication_events (
  publication_event_id TEXT PRIMARY KEY,
  rule_version_id TEXT NOT NULL REFERENCES knowledge_rule_versions(rule_version_id),
  review_event_id TEXT REFERENCES knowledge_review_events(review_event_id),
  action TEXT NOT NULL CHECK (action IN ('publish','withdraw')),
  published_hash TEXT NOT NULL,
  evidence_set_hash TEXT NOT NULL,
  publisher_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  publication_policy_version TEXT NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  CHECK (action<>'publish' OR review_event_id IS NOT NULL)
);
CREATE TABLE knowledge_claim_publication_events (
  publication_event_id TEXT PRIMARY KEY,
  claim_version_id TEXT NOT NULL REFERENCES knowledge_claim_versions(claim_version_id),
  claim_review_event_id TEXT REFERENCES knowledge_claim_review_events(claim_review_event_id),
  action TEXT NOT NULL CHECK (action IN ('publish','withdraw')),
  published_hash TEXT NOT NULL,
  evidence_set_hash TEXT NOT NULL,
  publisher_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  publication_policy_version TEXT NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  CHECK (action<>'publish' OR claim_review_event_id IS NOT NULL)
);
CREATE TABLE knowledge_pack_versions (
  pack_version_id TEXT PRIMARY KEY,
  pack_key TEXT NOT NULL,
  revision_no INTEGER NOT NULL CHECK (revision_no > 0),
  purpose_code TEXT NOT NULL,
  jurisdiction_code TEXT NOT NULL,
  manifest_schema_version TEXT NOT NULL,
  manifest_hash TEXT NOT NULL,
  publication_state TEXT NOT NULL CHECK (publication_state IN ('staged','published','withdrawn')),
  availability_state TEXT NOT NULL CHECK (availability_state IN ('usable','needs_review','blocked')),
  created_at TEXT NOT NULL,
  UNIQUE (pack_key,revision_no)
);
CREATE TABLE knowledge_pack_policy_members (
  pack_version_id TEXT NOT NULL REFERENCES knowledge_pack_versions(pack_version_id),
  policy_version_id TEXT NOT NULL REFERENCES knowledge_policy_versions(policy_version_id),
  PRIMARY KEY (pack_version_id,policy_version_id)
);
CREATE TABLE knowledge_pack_rule_members (
  pack_version_id TEXT NOT NULL,
  policy_version_id TEXT NOT NULL,
  rule_version_id TEXT NOT NULL,
  rule_publication_event_id TEXT NOT NULL REFERENCES knowledge_rule_publication_events(publication_event_id),
  PRIMARY KEY (pack_version_id,rule_version_id),
  FOREIGN KEY (pack_version_id,policy_version_id)
    REFERENCES knowledge_pack_policy_members(pack_version_id,policy_version_id),
  FOREIGN KEY (policy_version_id,rule_version_id)
    REFERENCES knowledge_rule_versions(policy_version_id,rule_version_id)
);
CREATE TABLE knowledge_pack_claim_members (
  pack_version_id TEXT NOT NULL,
  policy_version_id TEXT NOT NULL,
  claim_version_id TEXT NOT NULL,
  claim_publication_event_id TEXT NOT NULL REFERENCES knowledge_claim_publication_events(publication_event_id),
  PRIMARY KEY (pack_version_id,claim_version_id),
  FOREIGN KEY (pack_version_id,policy_version_id)
    REFERENCES knowledge_pack_policy_members(pack_version_id,policy_version_id),
  FOREIGN KEY (policy_version_id,claim_version_id)
    REFERENCES knowledge_claim_versions(policy_version_id,claim_version_id)
);
CREATE TABLE knowledge_pack_release_events (
  pack_release_event_id TEXT PRIMARY KEY,
  pack_version_id TEXT NOT NULL REFERENCES knowledge_pack_versions(pack_version_id),
  action TEXT NOT NULL CHECK (action IN ('publish','withdraw')),
  released_manifest_hash TEXT NOT NULL,
  publisher_account_id TEXT NOT NULL REFERENCES v03_accounts(id),
  publication_policy_version TEXT NOT NULL,
  reason TEXT NOT NULL,
  recorded_at TEXT NOT NULL
);
```

Gate publish là giao dịch kiểm role phát hành hiện hành đã được quản trị có thẩm quyền cấp; approver hash/rule/claim/evidence đúng version và action approve; publisher không được viện review của bản khác. Membership pack phải cùng policy đã khai, publication event đúng member và action publish, không bị withdraw; mọi dependencies/applies_when rule/condition cũng có trong manifest hoặc dependency manifest cố định. Pack có ít nhất một rule hoặc claim; policy-only chưa là pack tư vấn hoàn chỉnh. Manifest hash gồm các ID/version/hash, review/publication event refs và schema versions, không chỉ danh sách tên. Sau publish, thay member tạo pack_version_id mới và release event mới. Chưa mặc định mọi tài khoản DTT có quyền phát hành hoặc tự chọn danh sách người phát hành.

Publish không tự vượt availability: pack còn published nhưng member bị block thì truy vấn nội dung liên quan vẫn dừng/needs_review; không tiếp tục dùng nhờ pack cũ. Candidate staging hoặc review approve đơn lẻ không được retrieval gắn nhãn “đã phát hành”. Khi `as_of` quá khứ, có thể tái dựng đúng manifest để giải thích báo cáo đã lưu; tư vấn mới vẫn kiểm quyền/availability hiện hành và hiển thị rõ giới hạn.

### 6.4. Projection graph và quan hệ có kiểu

Public graph chỉ có các loại node `pack_version`, `policy_version`, `rule_version`, `claim_version`, `condition`, `field_definition`, `source_snapshot`, `chunk`. Các cạnh tạo từ FK và binding: `contains_version`, `has_rule`, `has_claim`, `has_condition`, `child_of`, `applies_when`, `requires_field`, `supported_by`, `has_chunk`; cạnh pháp lý liên văn bản chỉ từ `knowledge_policy_relations` đã có review. `requires_field` trỏ registry field và schema version, không trỏ fact của doanh nghiệp.

Các view `knowledge_nodes` và `knowledge_relations` được UNION từ bảng chuẩn; không có API cho agent chèn triple tùy ý. Node ID có namespace `rule:`, `condition:`, `snapshot:` để tránh trùng. Không lưu giá trị facts doanh nghiệp vào public graph hoặc FTS public.

Private graph là projection **theo enterprise và quyền người đọc** của entities, fact versions, context snapshots, evaluations và artifacts. Cạnh `has_fact`, `uses_fact`, `evaluates_rule`, `result_for`, `produced_at` có nguồn gốc từ các FK riêng. Cạnh private → rule/source công cộng được phép; không tạo cạnh public → enterprise để người đọc public có thể lần ngược ra doanh nghiệp. Truy vấn ảnh hưởng global chạy bởi worker có quyền hệ thống tối thiểu và chỉ phát sự kiện tới đúng tenant, không trả danh sách doanh nghiệp ra tool công cộng.

SQL graph ở đây là mô hình quan hệ và projection; không là graph database mới, không là LangGraph và không là vector index. Recursive CTE chỉ chạy trên quan hệ allowlist có giới hạn độ sâu; endpoint truy vấn trả loại câu hỏi hỗ trợ, không nhận Cypher/SQL từ browser hay mô hình.

## 7. Đối chiếu điều kiện và giải thích

### 7.1. Bốn trạng thái điều kiện

| Trạng thái | Nghĩa | Ví dụ minh họa tổng hợp, không phải điều kiện pháp lý thật |
|---|---|---|
| `met` | Dữ kiện đủ, đúng phạm vi/thời kỳ và thỏa predicate | Địa bàn cơ sở đã xác nhận phù hợp điều kiện mẫu |
| `not_met` | Dữ kiện đủ để khẳng định không thỏa | Loại hình đã xác nhận nằm ngoài danh sách mẫu |
| `unknown` | Thiếu/không được phép dùng dữ kiện hoặc chưa rõ nguồn | Chưa có doanh thu đúng kỳ |
| `conflict` | Các dữ kiện hiện hành/căn cứ cần thiết mâu thuẫn chưa giải quyết | Hai proposal quan trọng chưa có quyết định chọn |

Không có chứng nhận trong ảnh không chứng minh doanh nghiệp không có. Không được đọc dữ kiện do thiếu quyền trả `unknown` với lý do người dùng được phép thấy; không tiết lộ “có dữ liệu tài chính nhưng bị giấu” nếu điều đó lộ metadata riêng. Các proposal cũ đã bị owner bác không tiếp tục biến field thành conflict; chỉ candidate chưa giải quyết và liên quan mới tạo warning/conflict theo policy field.

Phép gộp xác định, giữ thêm danh sách diagnostics:

| Node | Quy tắc |
|---|---|
| `all` | Có `not_met` → not_met; nếu không có, conflict → conflict; rồi unknown → unknown; còn lại met |
| `any` | Có `met` → met; nếu không có, conflict → conflict; rồi unknown → unknown; còn lại not_met |
| `not` | Đổi met ↔ not_met; giữ unknown/conflict |

Một nhánh any đã đạt có thể cho kết quả met dù nhánh không cần thiết còn unknown; diagnostics vẫn giữ. Điều kiện loại trừ được đánh giá thành root riêng: chỉ khi đủ điều kiện yêu cầu **và** loại trừ được chứng minh không áp dụng thì mới kết luận “thỏa các điều kiện đã đối chiếu”. Không bỏ unknown của loại trừ. Loại trừ đã thỏa → không phù hợp theo rule đó. Mọi kết luận vẫn khác quyết định chính thức chấp thuận/hỗ trợ của cơ quan có thẩm quyền.

Tổng hợp trả `may_match`, `not_matched`, `needs_information`, `conflicting_information`, `not_assessable` hoặc `needs_revalidation`, kèm condition results. Chưa duyệt rule, hiệu lực không rõ, nguồn bị thay thế hoặc quyền không đủ thì không hiển thị chắc chắn “đủ điều kiện”. Benefit/procedure không trộn thành eligibility; số điều kiện đạt không là % khả năng được cấp hỗ trợ.

### 7.2. Bảng kết quả và lineage riêng

| Bảng | Khóa và cột bắt buộc | Ràng buộc |
|---|---|---|
| `policy_evaluations` | `(enterprise_id,evaluation_id)`, `resource_id`, `mission_id`, `outcome_id`, **`context_snapshot_id`**, `context_revision_id`, `pack_version_id`, `pack_release_event_id`, `target_date`, `known_at`, `rule_set_hash`, `evaluator_version`, `overall_state`, `created_at` | FK kép resource và FK ba cột snapshot/revision; khóa bộ context thật và pack manifest, không chỉ revision enterprise; evaluator deterministic có version; không chia sẻ qua public graph |
| `policy_condition_evaluations` | `(enterprise_id,evaluation_id,condition_id)`, `rule_version_id`, `state`, `reason_code`, `reason_vi`, `result_hash` | FK evaluation; condition cùng rule; reason không làm lộ dữ kiện bị hạn chế |
| `evaluation_fact_bindings` | `(enterprise_id,evaluation_id,condition_id,fact_version_id)`, `entity_id`, `field_key`, `binding_role` | FK condition result/fact version trong enterprise; hash/version được khóa tại thời điểm đánh giá |
| `evaluation_rule_bindings` | `(enterprise_id,evaluation_id,rule_version_id)`, `policy_version_id`, `review_event_id`, `source_snapshot_id`, `rule_hash`, `evidence_set_hash` | FK public rule/policy/review/source; bộ hash phải đúng bản đã duyệt |
| `evaluation_claim_bindings` | `(enterprise_id,evaluation_id,claim_version_id)`, `policy_version_id`, `claim_review_event_id`, `claim_publication_event_id`, `claim_hash`, `evidence_set_hash` | Claim phải là member của pack evaluation và qua publication gate; FK thật tới claim/review/publication đúng phiên bản |
| `policy_claim_results` | `(enterprise_id,evaluation_id,claim_version_id)`, `applies_when_state`, `result_state`, `result_payload_json`, `calculation_schema_version`, `input_refs_hash`, `result_hash` | `result_state=provided/conditional/not_applicable/needs_information/conflict/needs_revalidation`; payload theo claim type, không ghi về SSOT |
| `evaluation_dependencies` | `(enterprise_id,dependency_id)`, `evaluation_id`, đúng một trong `fact_version_id`/`rule_version_id`/`claim_version_id`/`source_snapshot_id`, `dependency_kind` | CHECK đúng một target; FK thật cho từng target, không dùng target ID vô kiểu |
| `evaluation_invalidation_events` | `(enterprise_id,event_id)`, `evaluation_id`, `cause_event_id`, `reason_code`, `recorded_at` | Append-only; không viết lại kết quả lịch sử |

Context snapshot riêng ghi danh sách fact IDs/version/hash, grants/ACL revision tại thời điểm tạo, rules/evidence refs, resolver version và task scope. Nó đủ tái dựng câu trả lời lịch sử nhưng **đọc lại vẫn kiểm quyền hiện hành**. Trace chi tiết có thể bị hạn chế theo resource; UI chỉ nhận phần cho phép.

Bảng `ssot_context_snapshots` có PK `(enterprise_id,context_snapshot_id)`, FK kép `resource_id` và `context_revision_id`, cùng `mission_id`, `task_id` tùy scope, `requester_account_id`, `target_date`, `known_at`, `resolver_version`, `authorization_fingerprint`, `payload_hash`, `payload_json`, `created_at`. `payload_json` có schema chỉ chứa tập refs/giá trị được chọn cho task; không là bản dump enterprise. `ssot_context_snapshot_facts` nối `(enterprise_id,context_snapshot_id,fact_version_id)` bằng FK kép; bảng snapshot rules nối rule version công cộng. `context_revision_id` là phiên bản enterprise, `context_snapshot_id` là bộ ngữ cảnh tối thiểu của lần xử lý; hai loại không đồng nghĩa. Chỉ nội bộ tạo snapshot sau auth; snapshot ID không là bearer cấp quyền.

DDL cho khóa context thực và pack đã dùng; các bảng result/binding còn lại tuân theo hợp đồng typed columns/FK ở trên khi viết migration đầy đủ:

```sql
CREATE TABLE policy_evaluations (
  enterprise_id TEXT NOT NULL,
  evaluation_id TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  mission_id TEXT NOT NULL,
  outcome_id TEXT NOT NULL,
  context_snapshot_id TEXT NOT NULL,
  context_revision_id TEXT NOT NULL,
  pack_version_id TEXT NOT NULL REFERENCES knowledge_pack_versions(pack_version_id),
  pack_release_event_id TEXT NOT NULL REFERENCES knowledge_pack_release_events(pack_release_event_id),
  target_date TEXT NOT NULL,
  known_at TEXT NOT NULL,
  context_payload_hash TEXT NOT NULL,
  rule_set_hash TEXT NOT NULL,
  evaluator_version TEXT NOT NULL,
  overall_state TEXT NOT NULL CHECK (overall_state IN
    ('may_match','not_matched','needs_information','conflicting_information','not_assessable','needs_revalidation')),
  created_at TEXT NOT NULL,
  PRIMARY KEY (enterprise_id,evaluation_id),
  FOREIGN KEY (enterprise_id,resource_id)
    REFERENCES ssot_resources(enterprise_id,resource_id),
  FOREIGN KEY (enterprise_id,context_snapshot_id,context_revision_id)
    REFERENCES ssot_context_snapshots(enterprise_id,context_snapshot_id,context_revision_id)
);
```

Repository còn kiểm mission/outcome thuộc enterprise/resource được cấp, snapshot đúng task và cùng target_date/known_at/hash; không dùng FK tới một enterprise revision bất kỳ thay cho kiểm snapshot. `pack_release_event_id` phải là publish event của chính `pack_version_id` với manifest hash khớp; member/rule/claim/hash phải khớp manifest. Khi tích hợp migration, gắn FK composite mission/outcome vào bảng orchestration chuẩn, không bỏ kiểm liên kết vì ID chưa có trong DDL minh họa. Bảng snapshot public references phải lưu rule/claim/pack versions đã chọn, không chỉ “latest”.

### 7.3. Ví dụ giải thích Trà Sen

Ví dụ dưới đây là **fixture thiết kế**, chưa khẳng định chính sách cụ thể hoặc quyền lợi thật:

1. Product Trà Sen giữ facts đã xác nhận từ ảnh/Excel: tên, thành phần, 100 g. Market profiles Mỹ/Đức/Nhật giữ riêng, không cần tải lại khi hỏi chính sách Hà Nội.
2. Intent “tôi muốn đổi máy đóng gói, có chương trình nào phù hợp và cần chuẩn bị gì?” tạo outcomes tìm chương trình để xem xét, đối chiếu điều kiện và danh sách chuẩn bị. Không ép IOR/FSVP/logistics vào câu trả lời.
3. Resolver lấy enterprise identity, cơ sở liên quan và mục tiêu đổi máy. Nếu thiếu cơ sở/địa bàn hay quy mô cần cho rule đã chọn, hỏi một nhóm nhỏ, không hỏi lại lượng tịnh của Trà Sen khi điều kiện không dùng đến.
4. Rule mẫu R1 đã duyệt dùng địa bàn, loại hình và quy mô đúng kỳ. Có địa bàn/type nhưng chưa có số đúng kỳ → hai condition met, một unknown. Trợ lý nói “Có thể xem xét chương trình này; chưa đủ dữ kiện để đối chiếu quy mô. Cần bổ sung …”, không nói đủ điều kiện.
5. Nhân viên đề xuất doanh thu từ Excel tài chính; owner xem thẻ tối thiểu và xác nhận. Giao dịch tạo context revision mới. Hàm đối chiếu chạy lại miễn phí nếu chỉ dùng facts/rules và template; việc gọi model để viết lại là một operation có quyền/budget riêng, không tự xảy ra.
6. Nguồn mới cho thấy điều kiện thay đổi. Rule cũ bị block/needs_review theo loại thay đổi; evaluation cũ giữ nguyên với nhãn cần rà. Sau expert duyệt rule mới, tạo evaluation mới; không tự sửa báo cáo cũ hoặc suy doanh nghiệp nay được hưởng.

## 8. Context Resolver: đúng ít dữ kiện, đúng quyền

Request của orchestrator cung cấp mission/outcome, capability, entities đã chọn, `target_date`, requested field schemas và nguồn/rules dự kiến; không cung cấp quyền tự khai. Resolver xác thực principal, scope brief và khả năng đọc ở server trước khi lấy payload. Trình tự:

1. Xác định entity IDs đã chọn; nếu tên mơ hồ, yêu cầu chọn, không hợp nhất. Chọn enterprise/facility/product/market đúng outcome.
2. Lấy facts theo field keys mà capability/rule thực cần; lọc ACL và sensitivity **trước khi** cấp context cho model. Không đọc mọi entity rồi gửi toàn bộ vào prompt.
3. Chọn phiên bản theo `target_date` và `known_at`; loại expired/stale theo field policy; giữ reason thiếu, không bịa default. Không dùng current_only cho đánh giá lịch sử.
4. Phân lớp `confirmed_facts`, `owner_decisions`, `working_draft`, `unresolved_proposals`, `historical_observations`; ngăn nháp/ảnh cũ override confirmed. Dữ kiện nháp chỉ dùng tính giả định nếu người dùng thấy nhãn rõ và kết quả không mang nghĩa fact chuẩn.
5. Tạo snapshot bất biến tối thiểu và hash; trả mỗi fact kèm provenance cho phép, trạng thái thời gian/xác minh, source refs, missing fields. Không trả tên tệp riêng nếu thiếu quyền.
6. Trước publication kiểm lại membership/ACL/context dependencies. Nếu đã thay facts liên quan hoặc bị thu hồi quyền, trả needs_revalidation và chặn xuất bản cũ; đổi sở thích giao tiếp không cần làm hết hạn mọi báo cáo.

Snapshot ID có thể tồn tại giữa nhiều task; view model context là projection theo task. Không cache dùng chung giữa doanh nghiệp; cache key bao gồm enterprise, requester/authorization fingerprint, resource ACL revisions, selected entity/field versions, target date, resolver/policy versions và rule set. Thu hồi quyền không chờ cache TTL.

Truy vấn temporal mẫu sau chỉ là phần chọn dữ kiện **sau khi resource đã vượt authorization**; không phải endpoint nhận SQL từ caller:

```sql
SELECT fv.fact_version_id, fv.entity_id, fv.field_key,
       p.value_state, p.value_json, p.verification_status
FROM ssot_fact_versions fv
JOIN ssot_fact_proposals p
  ON p.enterprise_id=fv.enterprise_id AND p.proposal_id=fv.proposal_id
WHERE fv.enterprise_id=:authorized_enterprise_id
  AND fv.entity_id=:authorized_entity_id
  AND fv.field_key=:allowed_field_key
  AND fv.system_from<=:known_at
  AND (fv.system_to IS NULL OR :known_at<fv.system_to)
  AND fv.temporal_basis='interval'
  AND (fv.valid_from IS NULL OR fv.valid_from<=:target_instant)
  AND (fv.valid_to IS NULL OR :target_instant<fv.valid_to);
```

Ngày luật/giấy phép là date theo jurisdiction; kỳ tài chính có time basis riêng. Parser chuyển về normalized instant hoặc date comparison đúng field, không biến một ngày hiệu lực thành 00:00 UTC tùy tiện. Nếu temporal query trả hơn một row chuẩn thì báo integrity_conflict, không `LIMIT 1` để che lỗi.

## 9. Refresh, ảnh hưởng và truy vấn graph

Theo D07-A đã chốt, phạm vi chặn theo dependency closure từng outcome. Release/manifest phải còn hợp lệ, các member được outcome đó dùng phải usable; member khác bị ảnh hưởng không tự biến cờ tổng hợp pack thành lệnh chặn toàn bộ. Nếu có block/withdraw thật ở cấp pack hoặc lỗi integrity không thể cô lập thì phạm vi rộng đó vẫn bị chặn. Graph phải lưu đủ bindings để chứng minh phần nào độc lập; chưa đủ trace thì không tự kết luận không ảnh hưởng.

Worker nguồn tạo snapshot/observation, không tự viết facts hoặc approved rule. Nội dung tải về, file manual và MCP đều là dữ liệu không đáng tin về chỉ dẫn; không được thay system prompt, quyền công cụ, consent hoặc ACL.

Sự kiện thay đổi có `event_id`, `source_snapshot_id` hoặc `rule_version_id`, loại thay đổi, hash cũ/mới và thời điểm; outbox giao dịch xử lý at-least-once với consumer idempotent. Hash trang đổi do bố cục chỉ tạo review candidate; dấu hiệu bãi bỏ/thay thế có căn cứ phải ngừng coi rule là hiện hành dù rule mới chưa duyệt. Lấy nguồn thất bại là trạng thái availability, không tự suy văn bản hết hiệu lực. D07-A đã chốt: chặn phần thiếu căn cứ hiện hành, giữ phần độc lập hợp lệ/lịch sử có nhãn; bản lưu không tự mở lại gate cho kết luận mới.

Đường tác động: snapshot → evidence binding → condition/rule version → evaluation dependency → mission/artifact. Đổi fact: fact version/field → evaluation dependency → mission/artifact; chỉ invalidation bên dùng đúng fact/field đó. Giữ bản lịch sử, đánh dấu cần rà và tạo revision mới khi có thao tác hợp lệ. Refresh tính lại predicate không gọi LLM; việc diễn giải bằng model hay alert có phí phải qua Gateway/grant riêng.

Ví dụ tìm rule trực tiếp phụ thuộc một snapshot:

```sql
SELECT DISTINCT r.rule_version_id, r.rule_key, r.review_state, r.availability_state
FROM knowledge_evidence_bindings b
JOIN knowledge_rule_versions r ON r.rule_version_id=b.rule_version_id
WHERE b.source_snapshot_id=:changed_source_snapshot_id;
```

Ví dụ lấy trace giải thích cho **một evaluation riêng đã kiểm quyền**:

```sql
SELECT ce.condition_id, ce.state, ce.reason_vi, rb.rule_version_id,
       eb.source_snapshot_id, eb.chunk_id, eb.locator_json, eb.quote_original
FROM policy_condition_evaluations ce
JOIN evaluation_rule_bindings rb
  ON rb.enterprise_id=ce.enterprise_id AND rb.evaluation_id=ce.evaluation_id
 AND rb.rule_version_id=ce.rule_version_id
JOIN knowledge_evidence_bindings eb
  ON eb.rule_version_id=ce.rule_version_id AND eb.condition_id=ce.condition_id
WHERE ce.enterprise_id=:authorized_enterprise_id
  AND ce.evaluation_id=:authorized_evaluation_id;
```

Không mở tool “xem mọi doanh nghiệp bị ảnh hưởng”. Worker lấy danh sách nội bộ; UI/MCP chỉ thấy tác động trong enterprise/resource được cấp. Bản dịch/đoạn ngữ nghĩa không thay thế edge supported_by đúng nguyên văn đã kiểm.

## 10. Chuyển từ hiện trạng 0.4 mà không mở quyền ngầm

Hiện trạng có `v03_entities`, `v03_fact_assertions`, `v03_fact_resolutions`, `v03_current_facts`, `v03_context_revisions`; ACL `private_owner` và kiểm owner đang là biên thực. Mở cộng tác là một thay đổi quyền dữ liệu cần migration có kế hoạch, không chỉ bỏ dòng kiểm owner.

| Bước | Chuyển đổi | Cửa kiểm |
|---|---|---|
| M0 | Inventory schema/reference, backup và diễn tập restore trên bản kiểm thử được phép | Không đọc dữ liệu thật trong đợt thiết kế; đếm/hash kỹ thuật ở đợt migration |
| M1 | Additive tables/keys/constraints; feature flag đọc cũ | FK check, schema version và rollback khả dụng |
| M2 | Backfill mỗi entity một resource private theo owner hiện tại; giữ mọi ID hoặc bảng mapping bất biến | Không tạo staff grants hoặc enterprise-wide share tự động |
| M3 | Assertion → observation/proposal giữ raw/source/actor; resolution → fact version chỉ nếu hợp lệ | Không biến assertion chưa được chọn thành fact; không tự nâng document_supported |
| M4 | Phân loại field và temporal basis; thiếu ngày thì current_only; không tạo ngày quá khứ giả | Báo ngoại lệ cần xem; không lấy ngày migration làm ngày hiệu lực |
| M5 | Xây context revision IDs và dependencies; graph views/FTS dựng lại | So sánh giá trị/type/market/owner/provenance; không nhân đôi product |
| M6 | Shadow read cho phép so sánh trên dữ liệu kiểm soát; production vẫn old read | Đạt isolation/temporal/CAS/compatibility |
| M7 | Chuyển write adapter một lần trong maintenance window; new read bật có rollback | Không dual-write không nguyên tử; zero inference và zero implicit grant |
| M8 | Chỉ bật cộng tác sau khi ma trận quyền/important fields được chủ sản phẩm chốt | Người dùng review tài nguyên cụ thể trước chia sẻ; audit đầy đủ |

Mọi mapping `value_json=null` phải phân loại unknown theo ngữ cảnh, không tự thành explicit_absent. Dữ kiện cũ không đủ lineage được đánh dấu legacy/self_declared và hiển thị giới hạn, không xóa bằng chứng. Dữ kiện hiện đã có valid_from/to giữ nguyên nếu xác định đúng nghĩa. Backfill không được tăng xác minh hoặc “hợp thức hóa” fact xung đột.

Rollback: giữ backup được thử phục hồi, schema revision, code flag và bảng mapping; không rollback bằng xóa hàng loạt bảng mới. Sau khi có ghi mới mà schema cũ không biểu diễn được cộng tác/bitemporal, rollback cần chế độ read-only hoặc forward-fix; không quay app cũ để làm mất quyền/phiên bản. Lộ trình production DB/hosting được quyết riêng theo quy mô thí điểm; thiết kế này không yêu cầu thêm dịch vụ.

## 11. Bộ nghiệm thu bắt buộc

Các ca dưới đây dùng fixture có kiểm soát và hàm xác định; không cần gọi Claude để chứng minh ràng buộc dữ liệu. Vòng Claude thực sau này đánh giá hành vi hiểu/đề xuất, không thay thế các ca integrity này.

| Mã | Ca kiểm | Kết quả bắt buộc |
|---|---|---|
| S01 | Enterprise B đoán entity/proposal/context/evaluation ID của A | Denied/not found nhất quán; không lộ payload hoặc metadata qua graph/history |
| S02 | Staff có quyền product nhưng không finance | Chỉ facts product; model context, nguồn trích và artifact không chứa finance |
| S03 | DTT reviewer không có membership enterprise | Duyệt nguồn/rule được cấp; không đọc SSOT/chat/tệp doanh nghiệp |
| S04 | Staff đề xuất field owner_required | Tạo proposal; current facts chưa đổi; owner phải xác nhận đúng hash |
| S05 | Hai người cùng sửa dựa trên field version N | Một giao dịch thắng, giao dịch sau 409; không mất nháp, không ghi đè |
| S06 | Gửi lại cùng operation hoặc payload khác với ID cũ | Cùng payload trả kết quả cũ; khác payload 409; không tạo resolution hai lần |
| S07 | Ảnh cũ ghi 120 g, owner đã chọn 100 g | 100 g vẫn chuẩn; proposal cũ không tự đảo và không hỏi lại quyết định đã giải |
| S08 | Null/false/0/tập rỗng và sai schema/unit | Unknown không thành false; false/0 giữ đúng; known null và unit sai bị từ chối |
| S09 | Sửa hồi tố, hẹn tương lai, expired và current_only | as_of/known_at trả đúng lịch sử; current_only không dùng cho quá khứ; không overlap |
| S10 | Facts chung và ba market profile | Tên/đơn vị Mỹ không xuất hiện ở Đức/Nhật; giữ hoa thường tên Trà Sen |
| S11 | Thu hồi quyền sau khi tạo context/cache/artifact | Lần đọc và publication sau bị chặn; không khôi phục quyền bằng known_at cũ |
| S12 | Facts chia sẻ nhưng file nguồn private | Chỉ giá trị/provenance cho phép; không lộ filename/preview/đường tải |
| S13 | Rule nháp, rule vừa đổi hash, review trên bản cũ | Không được dùng như approved/usable; cần review bản mới |
| S14 | Rule approved nhưng văn bản bị thay thế/bãi bỏ | Block/needs_review, kết quả cũ cần rà; rule mới chưa duyệt không tự cho phép rule cũ |
| S15 | Nguồn không truy cập được | Giữ trạng thái và snapshot rõ; không suy hết hiệu lực, không tự kết luận hiện hành |
| S16 | Chunk/snapshot/quote đúng riêng nhưng binding chéo sai | Từ chối; citation đúng tên/hash thôi chưa đủ chứng minh condition |
| S17 | all/any/not + loại trừ unknown/conflict | Kết quả bảng chân trị đúng; không “đủ điều kiện” khi loại trừ chưa rõ |
| S18 | Mô hình tạo operator mới, SQL hoặc cây vòng/quá sâu | Chặn trước lưu/duyệt/thực thi; không thực thi code tự sinh |
| S19 | Nguồn/file chứa chỉ dẫn mở quyền hoặc tự duyệt | Chỉ giữ như dữ liệu; không đổi ACL, consent hoặc fact/rule state |
| S20 | Rule chung dùng ở A và B | Chia sẻ căn cứ công khai; kết quả/facts/trace riêng không đi chéo |
| S21 | Đổi fact không được nhiệm vụ dùng | Không vô hiệu hóa toàn bộ lịch sử; chỉ dependency liên quan cần rà |
| S22 | Graph/index mất, rebuild hoặc lệch bản | SSOT/lineage vẫn còn; projection dựng lại; stale projection không được cấp context |
| S23 | Migration + rollback trên bộ dữ liệu kiểm soát | Không tăng quyền, không nhân đôi, không đổi giá trị/thời kỳ, restore khớp |
| S24 | Trà Sen chuyển từ xuất khẩu sang chính sách | Dùng facts đúng mục tiêu; không hỏi lại thành phần nếu rule không cần; thiếu gì hỏi nhóm nhỏ |
| S25 | Evaluation gắn snapshot của revision khác hoặc thay payload cùng ID | FK ba cột/hash guard từ chối; enterprise revision đúng riêng chưa đủ |
| S26 | Rule/claim approved nhưng staged; pack dùng publication event của member khác | Không phục vụ; publish transaction từ chối event/manifest sai |
| S27 | Mức hỗ trợ/thủ tục thiếu facts doanh nghiệp hoặc nguồn chỉ nêu cap | Giải thích typed claim đúng giới hạn; không đòi fact giả, không cam kết số tiền sẽ nhận |
| S28 | Claim formula có input unknown, divide by zero, code lạ; applies_when conflict | Không tính số giả hoặc thực thi code; trả thiếu/conflict/not_calculable; dữ kiện SSOT không đổi |

## 12. Những điểm thực sự cần dừng trao đổi

Thiết kế phần kỹ thuật có thể tiếp tục, nhưng **không bật chia sẻ hoặc gửi dữ liệu mới** trước khi chốt những quyết định sau bằng phương án cụ thể:

1. **Dữ kiện và quyền:** D04/D05 đã chốt, không hỏi lại. Staff chỉ đề xuất, owner xác nhận facts; tài chính xử lý tại server, chỉ chỉ tiêu tối thiểu được cho phép gửi Claude. Khi triển khai phải cấp resource/field và egress authority rõ; finance.read/membership không tự cho phép gửi dữ liệu hoặc xác nhận SSOT.
2. **Bằng chứng riêng:** chốt cơ chế thẻ bằng chứng tối thiểu và ai được xem; owner SSOT không tự đọc chat/file riêng. Retention, xóa tài liệu và ngoại lệ lưu audit cần chính sách dữ liệu riêng trước production; tài liệu này không tự chọn số ngày lưu.
3. **Duyệt domain:** danh tính/quyền phát hành và cơ chế người soạn–người duyệt phải được cấu hình trước release; không tự cấp quyền phát hành rộng. D07-A về phần nguồn thiếu căn cứ đã chốt, không hỏi lại: dừng phần đó, trả phần độc lập hợp lệ và lịch sử theo quyền. Quyết định nguồn không tự bổ nhiệm reviewer/publisher.

Không có chi phí API hoặc hạ tầng mới phát sinh từ schema/SQL graph này. Embedding/provider mới, dữ liệu gửi ra ngoài, vòng kiểm Claude thật và tác vụ nền có phí phải qua cổng quyết định riêng của Model Gateway. Chưa triển khai lịch tự động hay chia sẻ dữ liệu trong đợt thiết kế.

Sổ quyết định chung [08 — Quyết định cần chốt](<08_Quyet_dinh_can_chot.md>) có thẩm quyền cho trạng thái approval: **D04/D05 đã chốt 19/10/2026**. [Hợp đồng chỉ tiêu tài chính](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>) bổ sung FinancialMetricVersion có kỳ/đơn vị/phạm vi/provenance và exact-value egress grant riêng; không thay bảng SSOT. Các bảng tài chính ở tài liệu 10 là schema logic chưa có trong DDL minh họa của tài liệu này. Chưa chạy migration/mở grants thật hoặc gọi model; quyền đọc không tự là quyền egress/spend, xác nhận SSOT không tự cấp consent gửi.
