# Review và kiểm tra bộ thiết kế

Ngày 19/10/2026. Phạm vi là tài liệu thiết kế, không phải review kết quả app đã triển khai. Không đọc DB doanh nghiệp, API keys hoặc gọi model trả phí để lập/kiểm bộ tài liệu.

## 1. Cách review

Ba nhánh chuyên môn soạn SSOT/SQL graph, retrieval và Model Gateway song song; sau đó review chéo contracts và flow do root tích hợp. Review tìm mâu thuẫn về ID, quyền, phiên bản, trạng thái và chi phí. Không coi việc agent báo xong là đủ; có kiểm cấu trúc JSON, liên kết và DDL minh họa riêng.

## 2. Các phát hiện cần sửa trước khi khóa bản

| ID | Mức | Phát hiện | Cách xử lý |
|---|---|---|---|
| F01 | P1 | Operation key có chỗ gồm actor, có chỗ không | Chuẩn hóa unique enterprise + operation; actor giữ audit/quyền |
| F02 | P1 | Attempt unique thiếu enterprise, có thể conflict giữa hai tenant dùng cùng client IDs | Khóa đủ enterprise + operation + task + step, các trường không NULL; FK riêng theo enterprise |
| F03 | P1 | Enterprise revision bị dùng như toàn bộ context task | Tách context_revision_id và context_snapshot_id/hash tối thiểu, đưa vào manifests/recovery/evaluations |
| F04 | P1 | Policy version bị dùng lẫn cho văn bản và bộ phát hành | policy_version_id cho một policy, pack_version_id cho bộ nhiều policy/rule/claim |
| F05 | P1 | Evidence role trộn primary/supporting với definition/exception | Hai trục evidence_role và argument_role; supersession là relation |
| F06 | P1 | Approved chưa có gate phát hành SQL tương thích retrieval | Tách review/publication/usage gate và thêm release/membership contract |
| F07 | P1 | Mức hỗ trợ/checklist/procedure bị nhét vào predicate cần field SSOT | Typed claims riêng, evidence/approval/version và applies_when; không sinh facts giả |
| F08 | P1 | Retrieval chưa bắt buộc release/manifest cho assessment và chưa truy xuất typed claims | Assessment khóa pack/release, discovery chưa pack không đánh giá; claims có căn cứ/version/applicability trong query/result/cache/invalidation |
| F09 | P0 thiết kế | D05 mới ở mức chính sách chung, thiếu hợp đồng metric/egress cụ thể | Tài liệu 10 tách bốn quyền, exact versions/preview/manifest, chặn raw-equivalent và parser egress ẩn; tài liệu 04/11 nối vào dispatch |
| F10 | P1 | Kiểm egress trước khi resolve model profile, chưa niêm phong payload cuối | Route rồi seal, kiểm exact profile/purpose/payload hash trước reserve và commit marker |
| F11 | P1 | Hết hạn egress bị lẫn với quyền đọc báo cáo đã tạo hợp lệ | Expiry chỉ chặn dispatch mới; ACL/retention/derivative-use policy quản lý đọc và công bố; không re-consent/gọi AI để đọc lịch sử |

F01–F08 đã được sửa trong bản tài liệu cuối, đối chiếu chéo giữa các phần. File 02 bổ sung schema publication/claim/pack; file 03 đã cập nhật đường retrieval và gates tương ứng. Báo cáo cấu trúc ghi rõ kết quả kiểm; không coi source pack là đã được chuyên gia duyệt.

Sau khi người dùng chốt D05, review độc lập bổ sung hợp đồng và phát hiện F09–F11. Các điểm này đã được sửa vào baseline 1.1; 14 ca F01–F14 tại tài liệu 07 đặc tả kiểm tài chính. Đây là kiểm hợp đồng, chưa phải chứng minh app hiện tại đã áp dụng D05.

## 3. Giới hạn của kiểm tra

- JSON parse/không duplicate keys chứng minh cấu trúc hợp lệ, không chứng minh model sẽ trả đúng hoặc dữ kiện ví dụ có thật.
- DDL chạy trên SQLite trong bộ nhớ với stub identity/source tables chỉ kiểm cú pháp/ràng buộc có thể khai báo, không phải migration đã chạy trên app hoặc kiểm đủ mọi repository/trigger.
- Mermaid được kiểm khối/fence ở mức tài liệu; chưa có kiểm render pixel hoặc ảnh mockup của app mới.
- 75 ca ở file 07 là đặc tả nghiệm thu, chưa phải 75 ca đã pass. Tài liệu 12 có thêm 8 ca nguồn theo phương án D07-A đã chốt; phương án B không được bật trong MVP. Viewport khác điện thoại thật; không suy ra đã kiểm bàn phím/mạng yếu.
- Nguồn chính sách được khảo sát có mục chỉ đọc metadata hoặc timeout toàn văn. Không có bộ rule Hà Nội đã review/publish trong đợt này; không tuyên bố quyền hưởng hoặc đang còn nhận hồ sơ.
- D04/D05/D07-A đã chốt ngày 19/10/2026: staff đề xuất/owner xác nhận SSOT; tài chính server và chỉ tiêu tối thiểu có phép; dừng phần thiếu căn cứ hiện hành, giữ phần hợp lệ/lịch sử. D06 chưa có grant; reviewer/publisher và cấu hình thí điểm vẫn phải đủ trước release thật. Không có paid calls, deployment hoặc bật scheduler/embedding mới.

## 4. Trạng thái bàn giao

Bộ tài liệu là baseline để chốt quyết định dữ liệu và lập backlog triển khai. Các quyền/phí chưa được chốt phải giữ gate đóng; không được biến số liệu/IDs mẫu hoặc đề xuất schema thành cấu hình production.
