# 04 — Model Gateway và vận hành bền vững

Ngày thiết kế: **19/10/2026** · Trạng thái: **thiết kế đích, chưa triển khai**.

Phạm vi: lõi nMate dùng chung cho đọc ảnh/Excel, nghiên cứu xuất khẩu và agent chính sách Hà Nội. Gateway ban đầu là một mô-đun trong backend, dùng **một adapter Claude native**; chưa thêm provider, embedding API, reranker API hoặc dịch vụ gateway riêng. Không có lượt AI trả phí nào được gọi để soạn tài liệu này.

## 1. Mục tiêu và những giới hạn bắt buộc

Gateway biến yêu cầu đã có quyền thành **một lần thực thi có thể giải thích và đối soát**, thay vì để mỗi agent tự chọn SDK, model, prompt, retry hoặc khóa API.

Các bất biến:

1. Model không cấp quyền cho chính nó, không duyệt SSOT, không cấp ngân sách, không tự chọn công cụ ngoài danh mục.
2. Router xác định model **trước dispatch** bằng chính sách đã đánh giá. Không tốn một lượt LLM chỉ để chọn LLM.
3. Mỗi bước được đồng ý có tối đa một lần dispatch có phí. **Không tự retry, fallback, nâng model, gọi LLM sửa JSON hoặc “tự phê bình” sau lượt đã gửi.** Một bước nghiệp vụ mới có phí cần quyền phù hợp, không được đặt tên khác để lách nguyên tắc này.
4. HTTP refresh nguồn công khai là I/O riêng, có thể retry hữu hạn theo chính sách an toàn. Nó không cho phép retry Claude hoặc một API AI có phí.
5. `provider thành công`, `đầu ra hợp lệ`, `đã công bố` và `đã biết phí` là bốn việc khác nhau.
6. Reload, xem lịch sử, đọc nguyên kết quả, xác nhận facts, xuất artifact và kiểm lại bằng code trên kết quả đã lưu không tạo lượt Claude mới.
7. Phiên bản model, prompt, schema, context, nguồn và chính sách quyền được ghi trước khi gửi; đổi chúng không được sửa ngược lịch sử.
8. Chưa có `budget_grant_id` phù hợp thì **không dispatch**. Trần tiền, thời gian lưu dữ liệu, quyền nhân viên dùng ngân sách và ngân sách tác vụ nền còn chờ chốt; tài liệu không tự phê duyệt một giá trị.

## 2. Hiện trạng đã đối chiếu và khoảng trống

Đối chiếu source code, không mở `.env`, không đọc hàng dữ liệu doanh nghiệp:

| Hiện trạng 0.4 | Thiết kế đích bổ sung |
|---|---|
| `MainProvider` chọn simple/complex theo complexity và số outcome | Registry có phiên bản, yêu cầu năng lực, lý do route và điều kiện sử dụng dữ liệu |
| Native `AsyncAnthropic`, `max_retries=0`, endpoint cố định | Giữ adapter này; thêm contract và dispatch fence dùng chung mọi capability |
| `v03_live_attempts` lưu hash, model, trạng thái, request ID, usage, phản hồi parse được | Tách operation, raw response, validation/publication, token/cost reservation và billing reconciliation |
| Giới hạn theo số reservation/ngày, hoặc số lượt toàn đợt review | Giới hạn nhiều cấp: operation/mission, doanh nghiệp, tác vụ nền và môi trường; token + tiền khi có bảng giá hợp lệ |
| Có reservation hội thoại trước dispatch, idempotency, cache-only maintenance và lock một process/DB | Durable job/outbox và lease/fence; xử lý crash/reload không phụ thuộc bộ nhớ process |
| Giá ước tính đang hardcode trong harness | Bảng giá có nguồn, ngày kiểm, đơn vị và phiên bản; không dùng số hardcode làm giá hiện hành |
| `state=succeeded` hiện có thể đứng trước validator nghiệp vụ | State machine trực giao, không coi SDK trả lời là báo cáo đã đạt kiểm |

Hai ID đang có trong code là `claude-sonnet-5-5` và `claude-opus-5-5`: [config.py](<../../../REFERENCE_LINKS.md#ref-0021>), [main/local.py](<../../../REFERENCE_LINKS.md#ref-0022>). Đây là **binding đã quan sát trong cấu hình hiện có**, không phải khẳng định hãng duy trì ID này mãi mãi. Không tra hoặc đoán ID mới trong thiết kế này. Khi triển khai phải đối chiếu quyền truy cập model và bộ kiểm của chính môi trường đích trước khi active binding mới; lượt kiểm có phí cần grant.

Nguồn hiện trạng khác: [main/provider.py](<../../../REFERENCE_LINKS.md#ref-0023>), [v03/live_provider.py](<../../../REFERENCE_LINKS.md#ref-0024>), [v04/live_review.py](<../../../REFERENCE_LINKS.md#ref-0025>), [main/conversations.py](<../../../REFERENCE_LINKS.md#ref-0026>), [runtime_lock.py](<../../../REFERENCE_LINKS.md#ref-0027>). Một số docstring lịch sử còn nói “review-only”; đường app chính hiện đã dùng lớp này, vì vậy sơ đồ hiện trạng dựa trên composition và lời gọi thực tế.

## 3. Ranh giới thành phần

```mermaid
flowchart TD
    C["Chat mobile / MCP client"] --> API["Service nghiệp vụ\nquyền · intent · operation"]
    API --> TX["SQL transaction\nconversation + operation + job"]
    TX --> W["Worker bền vững\nlease + fencing token"]
    W --> CTX["Context Resolver + Retrieval\nmanifest có quyền và phiên bản"]
    CTX --> G["Model Gateway\nroute · token · budget · dispatch fence"]
    G --> A["Claude native adapter\nkhông retry/fallback"]
    A --> RAW["Kho phản hồi gốc có quyền"]
    RAW --> V["Schema + căn cứ + nghiệp vụ\nvalidator có phiên bản"]
    V --> PUB["Kiểm quyền/phiên bản lần cuối\ncông bố kết quả + dependencies"]
    PUB --> C
    G --> L["Ledger reservation / usage / chi phí"]
    RAW --> R["Cache-only revalidation\nkhông được import adapter"]
    R --> V
```

Gateway không tự mở Internet, không tự chọn luật chính sách Hà Nội và không quản lý chân lý của SSOT. Agent/orchestrator yêu cầu một capability đã đăng ký; Context Resolver tạo tập dữ liệu tối thiểu; Retrieval trả căn cứ theo quyền và hiệu lực; gateway kiểm manifest rồi thực thi model. Validator nghiệp vụ vẫn nằm ở capability tương ứng, với một lớp kiểm cổng chung.

Không gửi MCP token, cookie, API key hoặc toàn bộ lịch sử doanh nghiệp vào prompt. Tác vụ nền chỉ đọc nguồn công khai dùng một service identity riêng; không “mượn” tài khoản chủ doanh nghiệp hay ngân sách chat.

## 4. Registry và định tuyến theo vai trò

### 4.1. Model profile có phiên bản

`model_profile_version` bất biến gồm:

- `profile_id`, `version`, `provider`, API model ID được cấu hình, alias được phép và trạng thái `candidate/active/retired/disabled`.
- Khả năng đã kiểm: text, ảnh, structured output, giới hạn input/output, các kiểu tệp được adapter hỗ trợ; ngôn ngữ được đánh giá trên bộ ca thực tế.
- `adapter_version`, cấu hình output/thinking đã kiểm, timeout và allowlist endpoint. Không suy ra capability chỉ từ tên “Opus” hoặc “Sonnet”.
- `data_policy_ref`: nhóm dữ liệu được phép gửi, điều kiện hợp đồng tài khoản, cách xử lý/lưu tại provider đã được xác minh. Không tự tuyên bố zero retention hay không dùng để huấn luyện.
- `price_catalog_version`, ngày/nguồn kiểm, các nhóm token/chi phí được hỗ trợ; null nghĩa chưa có căn cứ ước tính tiền.
- Kết quả qualification/eval, thời điểm active và người chịu trách nhiệm. Bản active không bị sửa tại chỗ; alias trỏ bản mới qua sự kiện release.

| Alias nội bộ | Binding ban đầu từ code | Dùng khi |
|---|---|---|
| `reasoning.standard` | `claude-sonnet-5-5` | Intent rõ, trích xuất text đơn giản, giải thích ít căn cứ sau khi qua bộ kiểm |
| `reasoning.complex` | `claude-opus-5-5` | Ảnh khó, nhiều outcome/căn cứ hoặc mâu thuẫn cần tổng hợp; capability tương ứng phải đã kiểm |
| `embedding.multilingual` | Chưa có, **disabled** | Chỉ thiết kế cổng; chưa gửi query/chunk cho API mới |
| `ranking.evidence` | Chưa có, **disabled** | Xếp hạng xác định trước; model reranker chưa được bật |

`model_profile_version` là phiên bản registry của nMate, khác API model ID hãng. Nếu API ID là alias không ghim revision cố định, ghi rõ `provider_revision_pin=null`; lưu `response.model` thực trả về và kết quả drift checks, không bịa revision. Phản hồi có định danh bất ngờ không được âm thầm công nhận hoặc gọi lại model khác.

### 4.2. Ma trận việc–công cụ

| Công việc | Thực hiện chính | LLM có được gọi? |
|---|---|---|
| Parse ô Excel, số học, tổng hợp tồn kho | Parser + hàm tính xác định, lưu ô/công thức và cảnh báo lỗi | Không cần cho tính toán; chỉ cần nếu giải thích/intent vượt khả năng code và có quyền |
| Đọc/tính tài liệu tài chính theo D05 | Parser/công cụ server được phép; thiếu extractor/đơn vị/kỳ thì gap | Không gửi file/ảnh/OCR/CSV thô cho Claude; chỉ giải thích từ chỉ tiêu tối thiểu đã có egress grant |
| Đọc facts theo ID, quyền, lọc market/as-of | SQL + Context Resolver | Không |
| FTS, hợp nhất/xếp hạng ứng viên theo cấu hình | Retrieval xác định | Không ở baseline |
| Đối chiếu rule đã duyệt với facts đúng kiểu | Bộ đánh giá quy tắc, bốn trạng thái | Không cho việc quyết định điều kiện |
| Hiểu câu hỏi/nêu đề xuất từ text đơn giản | `reasoning.standard` | Một lần dispatch trong grant |
| Vision khó hoặc tổng hợp nghiên cứu nhiều ý | `reasoning.complex` | Một lần dispatch trong grant |
| Viết lời giải thích chính sách từ kết quả đối chiếu | Role phù hợp độ phức tạp đã biết trước | Không được thay kết quả rule hoặc bổ sung quyền lợi không có căn cứ |
| Gợi ý rule mới từ nguồn mới | Role đã qua bộ kiểm, nếu tác vụ nền được duyệt ngân sách | Chỉ tạo draft cho DTT/chuyên gia; không tự publish |

Router lần lượt xét `capability → data policy → năng lực → độ phức tạp → limit → budget → binding active`. Model nhỏ hơn chỉ được chọn nếu đạt chất lượng cho capability; không mặc định chọn rẻ nhất. Nếu không có binding thỏa mãn, trả lỗi trước gửi, không dùng giả lập làm kết quả thật.

Các đặc trưng route lấy từ schema nhiệm vụ, loại file, số outcome, số căn cứ và yêu cầu ngôn ngữ. Nếu chưa hiểu intent đủ để lập plan, lượt intake được định tuyến theo đặc trưng đã biết; không bắt trả phí hai lượt chỉ để route lại cùng câu hỏi. Cần nâng cấp sau kết quả không đạt thì trình thành lượt AI mới, có lý do và quyền riêng.

## 5. Hợp đồng gọi: typed request, result và lỗi

### 5.1. Dữ liệu server xây dựng

Browser chỉ gửi nội dung, attachment refs, tác vụ gợi ý và operation id. Những trường quyền/nguồn/giá/model dưới đây do server tạo sau kiểm tra, không tin bản khách tự kê.

| Nhóm | Trường bắt buộc / ý nghĩa |
|---|---|
| Lineage | `enterprise_id`, `resource_id`, `operation_id`, `mission_id`, `task_id`, `outcome_ids`, `trace_id`; `outcome_ids` liệt kê các ý task phục vụ, `outcome_id` chỉ là ý chính tùy chọn; đối tượng chưa hình thành có thể null theo schema |
| Identity/quyền | `actor_id`, `membership_version`, `acl_revision`, mục đích, nhóm dữ liệu và quyền resource hiện hành |
| Input | `context_revision_id` là watermark phiên bản enterprise; `context_snapshot_id` và snapshot/manifest hash định danh tập context tối thiểu của task đã kiểm quyền; input hash, attachment hashes, manifest item refs; giữ nguyên hoa/thường và ngôn ngữ gốc |
| Tri thức | `source_snapshot_id`, `chunk_id`, `rule_version_id`, `claim_version_id`, `policy_version_id` và dependencies tương ứng; `pack_version_id` + `pack_release_event_id` khóa đúng manifest phát hành, không thay thế các khóa thành phần |
| Model | `model_profile_version`, `route_policy_version`, route reason, prompt/schema/validator versions |
| Phí | `budget_grant_id`, price catalog, token estimate/limit, reservation id, `max_paid_dispatches=1` |
| Vận hành | deadline, request hash, trạng thái output, giới hạn bytes và endpoint profile |

JSON minh họa **trước chốt ngân sách**, dùng ID minh họa; null không được xem là quyền vô hạn:

```json
{
  "contract": "nmate.model.request.v1",
  "operation_id": "op_demo_policy_01",
  "enterprise_id": "ent_demo_tra_sen",
  "resource_id": "conversation_demo_01",
  "mission_id": "mission_demo_01",
  "task_id": "task_explain_conditions",
  "outcome_id": "outcome_support_options",
  "outcome_ids": ["outcome_support_options"],
  "purpose": "policy_condition_explanation",
  "context_revision_id": "ctx_demo_07",
  "context_snapshot_id": "ctx_snapshot_demo_task_01",
  "knowledge_refs": {
    "source_snapshot_ids": ["snapshot_demo_03"],
    "chunk_ids": ["chunk_demo_article_02"],
    "rule_version_ids": ["rule_demo_02_v1"],
    "claim_version_ids": ["claim_demo_preparation_v1"],
    "policy_version_ids": ["policy_demo_v1"],
    "pack_version_id": "pack_demo_bundle_v1",
    "pack_release_event_id": "release_demo_v1"
  },
  "model_selection": {
    "role": "reasoning.standard",
    "model_profile_version": "claude_standard_profile_v1",
    "configured_api_model_id": "claude-sonnet-5-5",
    "route_policy_version": "route_policy_v1",
    "reason_codes": ["TEXT_ONLY", "BOUNDED_RULE_EXPLANATION"]
  },
  "versions": {
    "prompt": "policy_explain_vi_v1",
    "response_schema": "policy_answer_v1",
    "validator": "policy_evidence_v1",
    "acl_revision": "acl_demo_12"
  },
  "execution_policy": {
    "max_paid_dispatches": 1,
    "automatic_retry": false,
    "automatic_fallback": false,
    "automatic_escalation": false
  },
  "budget_grant_id": null,
  "price_catalog_version": null,
  "cost_reservation_id": null,
  "state": "blocked_before_dispatch",
  "blocked_reason": "BUDGET_GRANT_REQUIRED"
}
```

Trong request sẵn sàng thực thi, server phải có đủ giới hạn token/deadline cụ thể đã tính, `budget_grant_id` còn hiệu lực, reservation đã ghi bền vững và hash manifest đã niêm phong. Không được thay null bằng mặc định tiền trong code để lách cổng. Cùng một `context_revision_id` có thể có nhiều context snapshots khác nhau theo task/người đọc/quyền; không dùng revision để tự hydrate toàn bộ enterprise. `policy_version_ids` trong manifest là tập khóa thành phần, còn từng evidence/rule binding luôn trỏ đúng một `policy_version_id` tương ứng.

Nếu có dữ kiện tài chính, request còn bắt buộc `financial_metric_egress_grant_ids`, exact metric versions/value hashes, authority revision và provider payload hash đúng preview. Đây là manifest nội bộ; serializer chỉ cấp DTO chỉ tiêu cho adapter, không gửi tên file/locator/ảnh/OCR/bảng gốc hoặc metadata nội bộ không cần thiết. Quyền đọc/SSOT/budget không thay quyền egress, và egress grant không cho phép gửi bản gốc. Xem [D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>).

### 5.2. Kết quả tách ba lớp

`ProviderResult`: response ID/model/stop reason, usage chuẩn hóa, raw response reference và checksum. Giữ phản hồi text trước parse JSON, kể cả lỗi format hoặc bị cắt. Nội dung raw là dữ liệu riêng có quyền, không phải log ứng dụng.

`ValidationResult`: schema, citations/quotes/hash/locator, scope, sự đủ ý theo outcome, điều kiện và các giới hạn. Structured output của provider không thay validator nghiệp vụ. Dữ liệu raw chứa lời nói “đã lưu” không tạo quyền ghi SSOT.

`PublicationResult`: answer/artifact version, dependencies, trạng thái stale, ACL hiện hành. Chỉ kết quả đạt chính sách công bố mới vào câu trả lời chính. Phần đạt độc lập có thể xuất bản `completed_partial` khi contract quy định; không “cứu” một kết luận thiếu căn cứ bằng cách bỏ cảnh báo.

Ví dụ response tổng hợp khi có raw nhưng bị kiểm chứng từ chối:

```json
{
  "contract": "nmate.operation.result.v1",
  "operation_id": "op_demo_policy_01",
  "operation_state": "stopped",
  "provider_state": "response_received",
  "validation_state": "rejected",
  "publication_state": "not_published",
  "billing_state": "usage_recorded_unpriced",
  "provider_attempt_id": "attempt_demo_01",
  "provider_request_id": "request_demo_redacted",
  "raw_response_ref": "private_raw_demo_01",
  "answer_ref": null,
  "error": {
    "code": "EVIDENCE_CONTRACT_FAILED",
    "message_vi": "Mình đã nhận phản hồi nhưng phần tư vấn chưa đủ căn cứ để hiển thị.",
    "automatic_retry_allowed": false,
    "actions": ["read_status", "request_cache_only_review", "start_explicit_new_paid_operation"]
  },
  "cost": {
    "estimate_amount": null,
    "usage_recorded": true,
    "invoice_reconciled": false,
    "note_vi": "Lượt trước có thể đã tính phí. Kiểm lại nguyên phản hồi đã lưu không gọi AI mới."
  }
}
```

Browser không nhận `private_raw_demo_01` như một URL công khai. `get_operation` chỉ trả view đã kiểm quyền; cấp raw cho nhân sự hỗ trợ là quyền riêng, có lý do và audit.

### 5.3. Phân loại lỗi và hành động

| Lỗi | Đã gửi? | Hành vi |
|---|---|---|
| `UNAUTHORIZED`, `CONTEXT_CHANGED`, `DATA_POLICY_BLOCKED` | Chưa | Không gọi; giữ nháp; yêu cầu đúng việc cần giải quyết |
| `MODEL_BINDING_UNAVAILABLE`, `INPUT_LIMIT`, `BUDGET_GRANT_REQUIRED`, `BUDGET_EXHAUSTED` | Chưa | Nêu lý do; không tự đổi model/provider hoặc bớt câu hỏi âm thầm |
| `IDEMPOTENCY_CONFLICT` | Không gửi mới | Trả 409; không ghi đè operation cũ bằng câu hỏi khác |
| `PROVIDER_AUTH`, `PROVIDER_PERMISSION`, `PROVIDER_RATE_LIMIT` | Có dispatch marker | Ghi receipt/error và trạng thái phí chưa được đối soát; không suy ra phí bằng 0 |
| `PROVIDER_OUTCOME_UNKNOWN`, timeout sau marker, process crash | Có thể | Dừng chờ đối soát; giữ hold; không tự gửi lại |
| `OUTPUT_TRUNCATED`, `INVALID_JSON`, `EVIDENCE_CONTRACT_FAILED` | Có | Raw giữ nguyên; công bố theo contract; có thể kiểm lại bằng code, không LLM repair |
| `CONTEXT_STALE_AT_PUBLICATION`, quyền bị thu hồi | Có | Không công bố như hiện hành; chặn quyền đọc; giữ lịch sử theo chính sách lưu đã chốt |

“Chưa gửi” chỉ được khẳng định khi không có dispatch marker và mọi code path đến adapter đã bị loại trừ. Có marker nhưng không có request ID vẫn có thể đã xử lý tại provider. Không có cờ `retryable=true` chung mà client/worker có thể hiểu thành cho phép gọi Claude lần nữa.

## 6. Durable operation: state machine và giao dịch

### 6.1. Năm trục trạng thái

| Trục | Giá trị thiết kế |
|---|---|
| Operation | `draft`, `blocked_before_dispatch`, `ready`, `queued`, `running`, `waiting_review`, `completed`, `completed_partial`, `stopped`, `outcome_unknown`, `cancelled_before_dispatch` |
| Provider attempt | `reserved`, `dispatch_committed`, `response_received`, `error_received`, `outcome_unknown` |
| Validation | `not_started`, `validating`, `accepted`, `accepted_partial`, `rejected` |
| Publication | `not_published`, `published`, `stale`, `access_revoked` |
| Billing | `reserved`, `usage_recorded_unpriced`, `provisionally_priced`, `pending_reconciliation`, `reconciled`, `released_no_dispatch` |

Một lượt nhận response nhưng validation fail là `provider=response_received`, `validation=rejected`, `operation=stopped`; UI không hiện đồng thời “đang xử lý”. `waiting_review` chỉ xuất hiện khi có review work item thực, người/nhóm được giao và lý do; không tạo trạng thái chuyên gia giả để che lỗi model.

### 6.2. Tạo và gắn ca bằng một transaction phía server

```text
BEGIN IMMEDIATE
  kiểm membership, quyền resource, version và quyền dùng grant
  nếu operation key đã tồn tại:
      cùng hash -> trả snapshot hiện tại, không tạo job mới
      khác hash -> 409, không gọi provider
  tạo hoặc lấy conversation có quyền
  lưu user message và nháp theo version
  tạo operation gắn conversation ngay trong cùng transaction
  ghi manifest/context refs và job/outbox khi đủ quyền thực thi
COMMIT
trả conversation_id + operation_id + status_url cho client
```

Đóng tab trước khi nhận response không tạo “ca mồ côi”: transaction rollback toàn bộ, hoặc tất cả liên kết đã bền vững. Client có thể gọi `get_operation`/tìm theo idempotency key, không gọi tách rời “tạo ca” rồi “gắn ca”. Nếu conversation đang có lượt hoạt động, từ chối hoặc xếp hàng rõ ràng theo policy; không trộn hai câu hỏi vào một context.

Idempotency target là `UNIQUE(enterprise_id, operation_id)` với `actor_id` và ACL được kiểm mỗi lần; không dùng khóa chỉ theo actor vì nhân viên/owner có thể cùng quan sát một operation dùng chung. Request hash bao gồm mục đích, input gốc, attachment refs/hash, continuation/resource target và yêu cầu thị trường, không bao gồm key hoặc cookie. Operation của chat riêng không được lộ cho người khác chỉ vì cùng doanh nghiệp.

### 6.3. Boundary gửi có phí

```text
1. Worker claim job bằng CAS + fencing token; chưa giữ transaction trong lúc HTTP.
2. Resolve context tối thiểu; kiểm nguồn/quyền/phiên bản và niêm phong manifest.
3. Route model; tính token/chi phí bảo thủ; kiểm grant và hạn mức.
4. SQL transaction: tạo attempt + giữ ngân sách nguyên tử; chưa gọi SDK.
5. SQL transaction: kiểm lại quyền, grant, manifest hash, lease/fence;
   CAS reserved -> dispatch_committed; commit trước khi gọi mạng.
6. Chỉ code đã CAS thành công mới được gọi Claude đúng một lần.
7. Lưu raw + usage + request ID trước parse/validator; sau đó xác thực/công bố.
8. Đối soát reservation; phát trạng thái và thông báo có quyền.
```

`dispatch_committed` là dấu mốc **không quay lại**. Mất process giữa bước 5 và 6 vẫn bị coi là chưa rõ, dù thực tế có thể chưa rời máy. Đây là lựa chọn bảo thủ để tránh tính phí trùng; không tuyên bố “exactly once” xuyên qua hệ thống bên ngoài khi provider chưa có bảo đảm tương ứng đã xác minh.

### 6.4. Pseudocode worker

```python
async def execute_model_step(job_id):
    job, fence = claim_job(job_id)  # durable lease, CAS
    op = read_operation_authorized(job.operation_id)
    if op.attempt_state in {"dispatch_committed", "outcome_unknown"}:
        return mark_reconciliation_required(op)  # NEVER dispatch
    if op.raw_response_ref is not None:
        return validate_and_publish_from_recorded(op)  # no adapter available

    context = resolve_minimal_context(op)
    candidate = compile_provider_manifest_under_data_policy(context, op)
    # D05: typed metrics only, never finance originals/raw-equivalent.
    model_profile = route_before_dispatch(op.capability, candidate)
    manifest = seal_manifest(candidate, model_profile, op.purpose)
    verify_exact_financial_metric_egress_grants(
        op, manifest, resolved_model_profile=model_profile,
        purpose=op.purpose, provider_payload_hash=manifest.provider_payload_hash
    )
    limits, estimate = preflight_tokens_and_cost(model_profile, manifest)
    attempt = reserve_atomically(op, model_profile, manifest, limits, estimate)
    # reserve checks grant scope, current ACL, limit and request hash.

    # Commit rechecks authority/grant/expiry/revocation, exact metric versions,
    # resolved profile/purpose/payload hash + current ACL and budget.
    if not commit_dispatch_once(attempt.id, fence, manifest.hash):
        return read_status(op.id)
    try:
        response = await claude_adapter.call_once(
            model_profile, manifest.provider_payload, limits, max_retries=0
        )
        persist_raw_receipt_once(attempt.id, response)
    except BaseException as exc:
        persist_transport_outcome_without_replay(attempt.id, exc)
        return terminal_or_unknown_view(op.id)

    # Failure below this point cannot invoke claude_adapter.
    result = validate_recorded_response(attempt.id, op.validator_version)
    # Expired egress grant blocks new dispatch, not historical reads.
    publish_with_acl_version_and_derivative_use_recheck(op, result)
    reconcile_usage_reservation_without_assuming_invoice_final(attempt.id)
    return read_status(op.id)
```

Pseudocode thể hiện ranh giới, không phải code chạy. Adapter phải được inject vào nhánh dispatch duy nhất; cache-only service dùng type/interface không có `call_once`, không chỉ đặt một cờ rồi hy vọng không rẽ nhầm.

## 7. Reload, recovery, hủy và concurrency

| Tình huống | Hành vi sau khởi động lại hoặc reload |
|---|---|
| Nháp chưa gửi | Mở đúng chat và nháp phiên bản mới nhất có quyền; không tạo operation |
| Operation đã commit, client mất response | GET theo ID; trả operation cũ, không gửi lại từ UI |
| Job queued, **chứng minh chưa có marker** | Có thể thực hiện dispatch đầu tiên trong grant gốc còn hiệu lực; không gọi đó là retry. Nếu context/grant đổi thì chặn và trình lại |
| Marker đã commit, chưa có receipt | `outcome_unknown`, dừng spinner, giữ hold và nêu rõ chưa biết phí; worker khác không được dispatch |
| Raw đã lưu, chưa kiểm/công bố | Resume các bước xác định trên raw và đúng context snapshot/manifest đã niêm phong, ghi validator version và audit |
| Validator cũ sai, cần sửa code | Kiểm lại nguyên raw/hash/context snapshot bằng cache-only; lưu validation/publication version mới, không sửa ledger hay raw, không lấy revision enterprise để nạp thêm facts hiện tại |
| Quyền bị thu hồi giữa chừng | Chặn đọc/công bố; cancel trước dispatch khi có thể; sau dispatch không hứa thu hồi dữ liệu đã gửi provider |
| Hủy trước dispatch | CAS hủy; gỡ job; release hold khi chắc chưa gửi |
| Hủy sau dispatch | Chỉ dừng theo dõi/công bố hoặc yêu cầu ngắt nếu adapter hỗ trợ đã kiểm; không hứa miễn phí, hoàn tiền hoặc model đã dừng |

Các quy tắc concurrency:

- Mỗi operation/model-step chỉ có một attempt được gửi; `UNIQUE(enterprise_id, operation_id, task_id, step_key)` và transaction/fence bảo vệ. Bốn thành phần khóa attempt đều `NOT NULL`; intake trước khi có mission vẫn được server cấp một `task_id`/`step_key` nội bộ ổn định, không dùng NULL làm khóa chống trùng. `operation_id` không unique toàn hệ thống; không bỏ enterprise khỏi unique/index hoặc điều kiện CAS/read của operation/attempt. Lock Python là tối ưu cục bộ, không phải ràng buộc cuối.
- Lease hết hạn không đồng nghĩa request provider đã dừng. Worker nhận lại job có marker chỉ đối soát, không dùng lease mới để gửi lại.
- Worker cũ mất lease không được publish/write mutable state; CAS kiểm fencing token. Raw receipt gắn đúng attempt có thể lưu qua đường idempotent append-once để không làm mất chứng cứ; không được viết thành receipt của worker mới.
- Một grant có thể bị nhiều job tranh chấp: reserve nguyên tử theo cùng currency/window, không “check tiền rồi reserve” ở hai transaction tách rời.
- SSR/GET/list/history/download không enqueue provider job. Browser polling/SSE chỉ là đọc; tab đóng không làm restart model call.
- Thời hạn job không mở rộng quyền của grant. Thông báo muộn chỉ chứa liên kết/status tối thiểu, kiểm quyền khi mở.

Lộ trình MVP giữ SQL + một worker local để dễ kiểm soát; outbox/jobs trong SQL đủ ở giai đoạn này. Giữ runtime lock một process trên một SQLite DB khi còn kiến trúc local. Nếu tách worker process/nhiều máy, phải có thiết kế claim/fence và DB concurrency tương ứng; **không chỉ bỏ runtime lock rồi chạy nhiều instance**. Chưa cần message broker riêng.

## 8. Token, reservation và đối soát chi phí

### 8.1. Ba lớp phải phân biệt

1. **Dự trù trước gửi:** token estimate, max output/thinking, loại ảnh và bảng giá; mức dự trù có thể lớn hơn thực dùng.
2. **Chi phí tạm tính từ usage:** sau receipt, áp dụng đúng bảng giá/loại token đã ghi. Không thay estimate bằng “phí thực thu”.
3. **Đối soát thanh toán:** chỉ khi có dữ liệu hóa đơn/billing chính thức tương ứng; không có thì giữ `pending_reconciliation`.

Không dùng `provider_attempts` làm đồng nghĩa `paid_calls` đã xác nhận. Các metric riêng là `dispatches_committed`, `provider_responses_received`, `usage_known`, `billable_outcome_unknown`, `estimated_cost`, `invoice_reconciled_cost`.

### 8.2. Grant và hạn mức

`BudgetGrant` được người/quy trình có thẩm quyền cấp, gồm: doanh nghiệp/service identity; mục đích; người được dùng; model roles/provider/data classes; `valid_from/expires_at`; trần số dispatch, input/output/token và trần tiền/currency khi đã có giá; scope operation/mission/window; quy tắc hủy/revoke; việc có cho tác vụ nền hay không.

Đợt hiện tại chưa chốt các giá trị số. Bản thiết kế không mặc định “40 lượt/ngày” của launcher hiện tại là chính sách cho pilot, không tự tăng grant cũ và không cho staff kế thừa quyền tiêu tiền của owner từ quyền đọc SSOT.

- Mọi limit có thể cùng áp dụng; phải qua tất cả. Ngân sách doanh nghiệp không làm mất trần nhiệm vụ.
- Trần daily dùng ngày nghiệp vụ `Asia/Bangkok` (UTC+7), timestamps lưu UTC; currency không tự chuyển đổi khi chưa có policy tỷ giá.
- Reservation tiền dùng integer đơn vị nhỏ hoặc decimal cố định có currency, không dùng float cho sổ hạn mức.
- Nếu bảng giá chưa được kiểm hoặc không đủ loại token, hiển thị “chưa ước tính được”. Không giả định 0; dispatch chỉ khi grant đã có cách giới hạn thay thế rõ ràng được chấp thuận, nếu không thì chặn.
- Count-token endpoint của provider, nếu sau này dùng, phải khai báo đây là một egress dữ liệu riêng và xác minh giá/điều kiện. Baseline dùng cách ước lượng nội bộ bảo thủ và giới hạn bytes/tokens, không phát sinh một request ẩn.
- Output cap và reservation không phải bảo đảm hóa đơn hãng không bao giờ vượt ước tính. Nếu usage vượt dự trù, ghi overrun, chặn lượt tiếp theo theo policy và trình rõ, không làm mất usage hoặc tự nới trần.

### 8.3. Quy tắc hold và settle

| Trạng thái | Reservation |
|---|---|
| Reserved, chưa có marker; canceled/rejected trước gửi | Release có audit, không xóa lịch sử |
| Marker có, chưa rõ response/phí | Giữ hold bảo thủ, `pending_reconciliation`; không tự expire để lấy tiền cho lượt mới |
| Có usage đủ và bảng giá đúng version | Chuyển phần phù hợp sang tạm tính, giải phóng phần dư theo policy; ghi chưa phải hóa đơn |
| Có error HTTP/timeout nhưng thiếu usage | Không suy ra miễn phí; giữ phần chưa rõ cho đối soát |
| Có hóa đơn/credit/refund xác minh | Ghi adjustment append-only gắn chứng cứ; không sửa ngược event ban đầu |

Usage chuẩn hóa giữ loại token theo thông tin provider trả. Cache-read/cache-creation/input/output/thinking không được cộng hai lần; adapter và price catalog định nghĩa phân loại/đơn vị. Loại usage không hiểu được giữ vào metadata hạn chế quyền và gắn `unpriced_usage`; không lặng lẽ bỏ qua để báo phí thấp.

Chi phí nền (dịch, đề xuất rule, embedding/rerank nếu bật sau này) dùng ledger cùng chuẩn nhưng grant/service identity riêng. Refresh HTTP thông thường có thể không mất phí LLM nhưng vẫn có tài nguyên/giới hạn và audit; không gọi nó “miễn mọi chi phí”.

## 9. Cache: tiết kiệm mà không lẫn quyền hoặc phiên bản

| Cache | Khóa và cách dùng | Không được làm |
|---|---|---|
| Raw response đúng operation | Tenant/resource ACL + attempt ID + request hash + raw checksum; immutable, private | Phát response của A cho B, sửa raw cho khớp validator mới hoặc dùng làm căn cứ current SSOT |
| Derived validation/artifact | Raw checksum + validator/schema/prompt interpretation version + `context_snapshot_id`/manifest hash + dependency versions | Ghi đè kết quả cũ hoặc gọi LLM dưới tên “kiểm lại miễn phí” |
| Retrieval result | Corpus/scope + query normalization + ACL/membership revision + as-of + index/config/source/rule versions | Chỉ khóa theo câu hỏi; trả snippets private trước kiểm quyền hiện hành |
| Exact task output reuse | Input/capability/model/prompt/schema/context/knowledge versions + scope; kiểm quyền và freshness lại | Semantic answer cache mặc định cho tư vấn chính sách hoặc private facts |
| Provider prompt cache | Cấu hình được kiểm theo adapter; dùng prefix phù hợp phạm vi và usage thực trả | Coi là SSOT, cache nguyên câu trả lời hoặc bảo đảm lượt sinh tiếp theo không có phí |

Raw/cache metadata cũng có thể tiết lộ bí mật (tên file, tên sản phẩm, nhà máy, doanh thu, câu hỏi). Tất cả có ACL; cache hit không bỏ qua authorization. Public source chunk có thể dùng chung nếu thật sự public và giấy phép phù hợp; câu hỏi chứa private facts, score phù hợp doanh nghiệp và kết quả tư vấn vẫn thuộc scope riêng.

Thu hồi quyền có hiệu lực tại đường đọc kho chuẩn ngay; chờ xóa cache/index không được tạo cửa truy cập tiếp. Nếu ACL hoặc source/fact đổi sau retrieval, resolve lại/revalidate trước dispatch và publication. Xem lịch sử dùng snapshot/as-of đúng quyền hiện hành, không làm sống lại quyền cũ.

Không mặc định bật provider prompt cache trong release đầu; thiết kế điểm mở rộng và phép đo lợi ích. Tách cache chung của nguồn công khai khỏi prefix/tài liệu riêng; không suy ra cơ chế cache của provider là phân quyền doanh nghiệp cho ứng dụng.

## 10. SQL schema logic cho vận hành

Schema dưới đây là mức contract: tên bảng/cột có thể điều chỉnh trong migration; FK, CHECK, index và transaction phải được đưa vào implementation spec. Các định danh dùng chung là `enterprise_id/resource_id`, `operation_id/mission_id/task_id/outcome_id`, `context_revision_id/context_snapshot_id`, `source_snapshot_id/chunk_id/rule_version_id/policy_version_id`, `pack_version_id`, `model_profile_version`, `budget_grant_id`. Quan hệ task–outcome là nhiều-nhiều; danh sách `outcome_ids` không bị rút còn một ý khi ghi trace.

| Bảng | Trường chính và ràng buộc |
|---|---|
| `model_profiles` | PK `(profile_id, version)`; provider/API ID/capabilities/data-policy/price-catalog/config-hash/status/eval refs; version bất biến |
| `model_alias_bindings` | alias + binding version → profile; activation/revocation audit; operation lưu resolved profile, không chỉ alias |
| `route_policies` | version, capability matrix, complexity rules, reviewed_by, activated_at; không chứa code do model tự viết |
| `operations` | PK `(enterprise_id, operation_id)`; resource/actor/hash/context revision/grant/state; optimistic `version`; FK kép `(enterprise_id, resource_id)` và các conversation/mission/context refs cùng tenant; snapshots theo từng task có FK riêng |
| `operation_events` | append-only sequence theo `(enterprise_id, operation_id)` với FK kép tới operation; from/to/reason/actor/trace/time/fence; không ghi prompt plaintext vào event |
| `operation_jobs` | FK kép operation; enterprise/operation/task/step, state, lease owner/until/fence, checkpoint; unique active job của `(enterprise_id, operation_id, task_id, step_key)` |
| `operation_outbox` | FK kép operation; tx-bound event và delivery state; delivery có thể lặp, consumer idempotent theo tenant + event |
| `model_attempts` | PK attempt ID ngẫu nhiên toàn hệ thống; thêm UNIQUE `(enterprise_id, attempt_id)` cho FK kép, UNIQUE `(enterprise_id, operation_id, task_id, step_key)` và FK kép tới operation; profile/context snapshot/manifest/request hash, outcome bindings, dispatch marker/receipt refs/usage/error/state; không xóa marker |
| `model_raw_responses` | attempt, bytes/text locator, checksum/media/version, access policy; append-once; có thể lưu receipt error/truncation mà chưa parse được |
| `model_validations` | attempt + validator version + result sequence, schema/evidence/outcome checks, error refs; không ghi lại raw |
| `model_publications` | result version, validation ref, answer/artifact refs, ACL/currentness check, dependencies; có thể đánh dấu stale |
| `budget_grants` | authority/scope/limits/validity/version/revocation; null-limit không là vô hạn |
| `budget_reservations` | attempt/grant/currency/estimate/max hold/state; unique attempt; atomic totals/locking theo window |
| `usage_records` | attempt/provider request ID/usage categories/raw usage ref/recorded_at; dedup receipt |
| `cost_entries` | reserve/provisional/adjustment/release/reconcile event, currency/rate-card/source proof; append-only |
| `application_recoveries` | original attempt/hash/raw checksum, old/new validator, operator/reason/result; `provider_dispatches=0` |

Một enterprise có nhiều authorized actors nhưng không đồng nghĩa mọi resource đều dùng chung. FK doanh nghiệp chống gắn chéo; truy vấn luôn join current membership + resource ACL. Các bảng raw/validation/publication/recovery/reservation/usage/cost dẫn xuất tham chiếu operation bằng `(enterprise_id, operation_id)` và attempt bằng `(enterprise_id, attempt_id)`, kể cả khi attempt ID ngẫu nhiên đã unique toàn hệ thống. Grant/context/resource refs riêng doanh nghiệp dùng FK kép tương ứng; ID không thay authorization. Hai doanh nghiệp dùng trùng client `operation_id`/`task_id`/`step_key` là hợp lệ và không được conflict hoặc nhìn thấy nhau. Các claim public của policy không nằm chung raw private store chỉ vì cùng task.

`operation_events` và `cost_entries` append-only về logic không có nghĩa lưu PII vĩnh viễn. Sau khi chốt retention/xóa, có thể giữ tombstone và số liệu audit tối thiểu với căn cứ hợp lệ; nội dung private/raw có vòng đời riêng. Không dùng ledger để lách yêu cầu xóa dữ liệu.

## 11. Bảo vệ dữ liệu, log và vòng đời khóa

### 11.1. Trước khi gửi

- Manifest ghi các trường/đoạn/ảnh thực gửi, nguồn gốc, mục đích và classification. D05 đã chốt: tài chính chỉ DTO chỉ tiêu tối thiểu có grant exact-value; original, ảnh trang, OCR/bảng dump hoặc message copy/paste không đi Claude. Quét/allowlist ở serializer và trước dispatch, không chỉ dựa nhãn file hay heuristic.
- Tách instruction hệ thống với dữ liệu người dùng/Internet/Excel/ảnh. Chỉ dẫn trong tài liệu là dữ liệu không tin cậy; không được đổi model, cấp tool, mở URL ngoài allowlist hoặc ghi SSOT từ nội dung đó.
- Retrieval query ra nguồn công khai dùng từ khóa mục tiêu tối thiểu; bỏ tên/doanh thu doanh nghiệp nếu không cần. Tải URL qua fetcher riêng kiểm SSRF, redirect, content type/size; provider adapter chỉ tới endpoint đã cấu hình server.
- Kết quả trích xuất là observation/proposal. Theo D04 đã chốt 19/10/2026, chỉ owner xác nhận mọi thay đổi nghiệp vụ SSOT trong MVP; staff chỉ xem/đề xuất trong phạm vi được giao. Model không thay được quyết định cũ của owner; quyền xem/đề xuất không cấp quyền dùng ngân sách hoặc gửi dữ liệu ra ngoài.

### 11.2. Log và trace

Trace vận hành thông thường ghi ID, hash, version, latency, route reason, counts, lỗi chuẩn hóa và usage. Không log key, authorization header, cookie, payload ảnh/base64, văn bản Excel, prompt/response đầy đủ hoặc query SQL có giá trị private.

Raw/debug replay nằm kho riêng có quyền, không gửi tự động lên dịch vụ tracing bên ngoài. Tracing bên thứ ba hiện không là dependency; bật sau này là quyết định dữ liệu cần duyệt. Hỗ trợ DTT không được đọc tài liệu doanh nghiệp chỉ nhờ vai trò curate policy; quyền hỗ trợ dữ liệu riêng phải tách, có mục đích và audit.

Dashboard có thể tổng hợp số lượt và chi phí theo doanh nghiệp được quyền; không trả model raw cho mọi thành viên. Giá/latency metrics toàn hệ thống cần tổng hợp phù hợp, tránh lộ nội dung hỏi hoặc hoạt động kinh doanh của đơn vị khác.

### 11.3. Khóa API

Khóa server-only, inject lúc khởi động qua cơ chế secret phù hợp môi trường; local tiếp tục dùng cấu hình riêng đã có, không đưa vào repo/browser/MCP result/ledger. Config registry chỉ giữ `credential_ref`, không giữ giá trị khóa. Không truyền key qua URL hoặc tool argument cho model.

Tách môi trường phát triển/thử nghiệm/pilot, tách scope và hạn mức phía tài khoản provider khi có. Rotation: tạo secret mới → kiểm cấu hình không gọi phí khi có thể → đổi ref/deploy → kiểm chức năng trong grant đã duyệt → revoke khóa cũ → audit; không reset attempts/budget để làm như ngày mới. Nếu rò rỉ, disable dispatch, revoke/rotate, kiểm ledger/request IDs và điều tra; không tự gửi thử hàng loạt để chẩn đoán.

Backup mã hóa và quyền vận hành phụ thuộc môi trường triển khai. Phải kiểm restore giữ nguyên operation markers, grant balances và raw checksums; restore snapshot cũ không cho phép replay những lượt provider đã gửi sau snapshot. Phần log dispatch đối soát ngoài bản backup cần được nhập/đánh dấu unknown trước mở dispatch lại.

## 12. Áp dụng vào agent chính sách Hà Nội

Ví dụ kiến trúc, **không khẳng định chính sách cụ thể đang có hiệu lực**:

1. Chủ doanh nghiệp hỏi hỗ trợ nâng cấp máy đóng gói Trà Sen. Intake xác định outcome “tìm chính sách phù hợp”, không tái dùng ba việc IOR/FSVP/Incoterm.
2. Context Resolver lấy loại hình doanh nghiệp, cơ sở ở đâu và facts có liên quan đúng kỳ/phạm vi; chưa có thì hỏi ít câu thiết yếu hoặc giữ `unknown`, không gửi toàn bộ báo cáo tài chính.
3. Retrieval lấy nguồn/rules đã duyệt theo ngày mục tiêu. Đối chiếu điều kiện bằng code: đạt/không đạt/chưa biết/xung đột, giữ fact/rule refs.
4. Nếu chỉ cần mở lại kết quả còn hợp lệ, trả cache có quyền. Nếu cần lời giải thích mới, gateway chọn standard/complex theo scope đã biết, trình phí và grant tương ứng; không có grant thì dừng trước gửi.
5. Claude giải thích đúng kết quả đối chiếu và căn cứ. Validator kiểm không biến “chưa biết” thành “được hưởng”; conclusion đứng đầu chat, việc tiếp theo bám điều kiện còn thiếu.
6. Owner sửa/xác nhận dữ kiện quan trọng bằng giao dịch SSOT, không cần gọi Claude để ghi một giá trị đã chọn. Kết quả cũ đánh dấu cần rà lại; việc chạy giải thích mới vẫn tuân policy phí.
7. Refresh nguồn hàng ngày chỉ là khả năng được thiết kế. Khi nguồn đổi, fetch/parse xác định có thể tạo snapshot/invalidate; dùng model đề xuất rule mới chỉ trong grant nền đã chốt. Rule draft chờ DTT/chuyên gia; không tự phát hành hoặc tự gửi thông báo tư vấn khi rule chưa được duyệt.

Mỗi output phải chỉ ra: câu hỏi và các outcome được phục vụ, context revision + context snapshot/hash, các policy/source/rule versions và pack phát hành nếu có, điều kiện đã đối chiếu và giới hạn. Không lấy việc model trả lời trôi chảy làm chứng cứ chính sách đủ điều kiện.

## 13. Nghiệm thu và thay đổi model/prompt

### 13.1. Kiểm xác định trước, không tốn API

- Contract/type tests cho request/result/error; null/default giới hạn phải fail closed.
- Ma trận state + crash injection ở trước/sau reservation, dispatch marker, raw write, validation, publication; sau restart mỗi step có **0 hoặc 1 dispatch**, không tăng do reload.
- Race hai tab/hai worker/two authorized actors: idempotency conflict, cùng hash, lease hết, fence cũ, grant tranh chấp, revoke quyền giữa chừng.
- Cache-only recovery được chạy với adapter giả “nếu gọi thì test fail”; kiểm raw/hash/context không đổi và `provider_dispatches=0`.
- Budget: giữ hold unknown, usage cache/token không double count, thiếu price không là 0, vượt estimate, ngày UTC+7, precision/currency, duplicate receipt.
- ACL: owner/staff/resource riêng; raw/retrieval hit không lộ chéo; thu hồi quyền tác động ngay; DTT curator không đọc private SSOT mặc định.
- Không có nguồn/không có rule, prompt injection, JSON sai/null/truncation, citation sai, source stale, facts conflict và claim “đã lưu” trái quyền.
- Khôi phục backup cũ không tạo paid replay. Job scheduling/retry của worker phân biệt các bước đọc/xác định với bước đã dispatch.

Fixtures/recorded raw thật chỉ dùng trong quyền cho phép và được khử định danh phù hợp. Replay raw không đo được chất lượng model mới; không báo thành “đã kiểm Claude thật” nếu chỉ replay.

### 13.2. Kiểm Claude thật ở giai đoạn triển khai sau

Chỉ sau khi chốt bộ ca, dữ liệu được phép gửi, model bindings, số dispatch và trần phí. So sánh kết quả theo intent coverage, grounded citations, rule consistency, giữ SSOT/owner decisions, chất lượng tiếng Việt, khả năng tự phục vụ, latency và usage; không chỉ API success rate.

Giữ build/prompt/schema/model policy cố định trong một vòng nghiệm thu. Nếu phải sửa validator hoặc dùng recovery nội bộ, ghi rõ và tính vào tỷ lệ không tự phục vụ; không gọi thêm một lượt có phí để che ca thất bại. Chỉ rerun khi có quyền cho vòng mới.

### 13.3. Đổi profile/prompt/schema

Candidate → kiểm contract/recorded regression → kiểm Claude thật trong grant riêng nếu cần → review chất lượng/chi phí/dữ liệu → active profile version mới. Không bật model mới chỉ vì tên mới hơn. Rollback alias chỉ ảnh hưởng operation mới; operation đã reserve/dispatch giữ binding cũ. Profile cũ disabled vì rủi ro thì chặn tiếp tục dispatch, nêu lý do; không tự migrate operation sang model khác.

## 14. Lộ trình chuyển từ hiện trạng, không làm mất lịch sử

| Chặng | Việc triển khai sau khi duyệt | Tiêu chí ra khỏi chặng |
|---|---|---|
| A | Thêm registry/contracts và status view trực giao quanh provider hiện có | API hiện có tương thích; main/mobile không còn trạng thái lỗi–đang chạy mâu thuẫn |
| B | Operation+job/outbox transaction, durable marker/fence/raw-before-parse | Crash/race/reload không gây orphan hoặc paid replay |
| C | Grant, token/cost reservation và usage categories | Không dispatch khi thiếu quyền/giá-policy cần thiết; không mất unknown hold |
| D | Cache-only validator/publication versioning và privacy/retention thực thi | Phục hồi miễn lượt AI có trace; không lộ private raw; thu hồi quyền có hiệu lực |
| E | Agent policy slice và frozen-build real acceptance trong grant | Kết quả bám intent, rules, nguồn; owner tự hoàn thành trên mobile |

Backfill `v03_live_attempts`/`main_operations` giữ nguyên operation IDs, raw đang có, request hash, usage và original state. Lượt cũ thiếu raw đầy đủ không được dựng lại raw từ diễn giải; ghi `legacy_raw_unavailable`. Giá cũ là `legacy_estimate`, không nâng thành giá/hóa đơn đã xác minh. State cũ ambiguous map bảo thủ sang unknown; không enqueue paid replay. Số dư chưa đối soát không tự reset về 0 khi migration. Giữ mapping legacy→new và kiểm số hàng/checksum trong staging trước thay app chính.

Rollback schema cần migration plan rõ; rollback code không được bỏ qua cột marker mới và gửi lại. Chưa thay hạ tầng local đang chạy trong đợt thiết kế này.

## 15. Những quyết định dữ liệu/chi phí cần dừng để chốt

Các lựa chọn đã chốt không hỏi lại: Claude hiện tại, Sonnet đơn giản/Opus phức tạp, không tự retry có phí; D04 owner xác nhận mọi facts nghiệp vụ, staff chỉ xem/đề xuất theo scope; D05 tài chính server-only và chỉ tiêu tối thiểu có quyền egress, không bản gốc; nguồn tự cập nhật/rules DTT duyệt; chưa graph/vector DB riêng. Ngân sách D06 vẫn riêng, chưa được cấp từ D04/D05.

| Quyết định/cấu hình | Trạng thái hoặc phương án cụ thể | Điều kiện trước khi bật |
|---|---|---|
| Dữ liệu được gửi Claude | D05 đã chốt, không hỏi lại: tài chính chỉ chỉ tiêu tối thiểu có exact egress grant; tài liệu gốc/raw-equivalent bị cấm | Mỗi lượt kiểm resource/field read + egress authority/preview/version/purpose/profile/grant; không suy từ membership, SSOT hoặc spend |
| Quyền nhân viên dùng ngân sách | Tách quyền xem SSOT, đề xuất facts và quyền tạo lượt có phí; owner cấp vai trò/hạn mức | Có ma trận staff cụ thể; không suy từ membership sang spend permission |
| Trần chat/nghiên cứu thật | Một grant theo nhiệm vụ hoặc nhóm tác vụ có giới hạn rõ; số dispatch và trần tiền trình cùng bộ ca | Chốt số cụ thể sau khi có bảng giá được kiểm và workload; không tự kế thừa 40 lượt/ngày |
| Lượt nền cập nhật chính sách | HTTP refresh nguồn công khai không gọi model trước; nếu cần AI dự thảo rule, cấp grant/service identity riêng | Chốt tần suất, nguồn, quyền dữ liệu và trần phí AI nền trước tạo lịch |
| Giữ raw, chat, ảnh/Excel, log, backup | Tách retention theo loại; raw chỉ phục vụ kiểm chứng/hỗ trợ có quyền; có xóa/tombstone và restore policy | Chốt thời hạn, quyền hỗ trợ và yêu cầu lưu theo bối cảnh thí điểm; không tự đặt số ngày |
| Cache provider/tracing mới | Chưa bật; chỉ chọn sau khi xác minh dữ liệu ra ngoài và lợi ích đo được | Duyệt điều kiện dữ liệu và chi phí nếu mở phạm vi hiện tại |
| Embedding/rerank/provider khác | Interface có sẵn, binding disabled | Trình corpus/query sẽ gửi, chính sách lưu, chất lượng và tổng chi phí trước bật |

Việc chưa chốt các giá trị này **không ngăn hoàn thiện schema, flow, mockup và bộ kiểm bằng fixtures**. Nó ngăn dispatch, tạo lịch AI nền hoặc mở dữ liệu vượt phạm vi đã có. Khi dừng trao đổi, phải mang ma trận/bộ ca/ước tính cụ thể, không yêu cầu người dùng tự chọn một công nghệ hoặc ngân sách trong khoảng trống.
