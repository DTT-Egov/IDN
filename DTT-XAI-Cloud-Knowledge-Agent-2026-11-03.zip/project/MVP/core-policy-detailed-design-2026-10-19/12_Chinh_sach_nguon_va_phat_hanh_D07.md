# 12 — Chính sách nguồn và phát hành tri thức: D07 đã chốt

Ngày 19/10/2026 · **D07 phương án A đã được người dùng chốt; thiết kế, chưa phát hành pack/rule thật.**

Đi cùng [retrieval](<03_Retrieval_va_vong_doi_tri_thuc.md>), [SQL knowledge graph](<02_SSOT_va_SQL_Knowledge_Graph.md>), [agent Hà Nội](<05_Agent_chinh_sach_Ha_Noi.md>) và [sổ quyết định](<08_Quyet_dinh_can_chot.md>). Đây là chính sách thiết kế đã chốt về cách dùng nguồn, không tạo lịch cập nhật, gọi API hay gán người duyệt thật.

## 1. Quyết định đã khóa và điều kiện vận hành còn phải có

**Bất biến kỹ thuật:** nguồn tự cập nhật không tự duyệt quy tắc; metadata/search snippet không thay toàn văn; hash khớp không chứng minh claim; quyền hiện hành áp dụng cả lịch sử; không tự retry/fallback model có phí. D04 đã chốt: nhân viên đề xuất, chủ xác nhận SSOT. D05 đã chốt: tài liệu tài chính xử lý tại server, chỉ chỉ tiêu tối thiểu được người có quyền cho phép gửi Claude; không gửi tài liệu gốc.

**Quyết định D07 của người dùng ngày 19/10/2026:** “Dừng riêng phần chưa đủ căn cứ; vẫn trả phần hợp lệ và lịch sử (đề xuất)”. Phương án A là chính sách hiện hành của thiết kế MVP; không hỏi lại lựa chọn A/B. Phương án B không được chọn, không được bật hoặc dùng làm fallback tự động.

**A — dừng riêng phần chưa đủ căn cứ hoặc độ hiện hành chưa xác minh**, vẫn trả phần còn hợp lệ, lịch sử có nhãn và hướng kiểm tiếp theo. Không ngừng toàn bộ chat khi chỉ một outcome bị chặn. Quyết định này không đồng thời cấp ai quyền publish; tên người, phạm vi, người thay thế và lịch rà phải có trước phát hành thật. Tài liệu không điền người chịu trách nhiệm giả.

## 2. Ma trận quyết định nguồn — phương án A đã chốt

`assessment_allowed` là cổng quyết định cho từng outcome, không phải nhãn pháp lý mới. Lỗi mạng ghi ở source observation; không tự chuyển văn bản thành hết hiệu lực hoặc sửa review approval.

| Tình huống kiểm được | Tư vấn mới/đối chiếu | Nguồn/rule/claim và hành động | Hiển thị cho doanh nghiệp |
|---|---|---|---|
| Toàn văn/nguồn phụ thuộc được kiểm, không đổi đáng kể; rule/claim đã approved + published + usable, đúng ngày mục tiêu và profile kiểm còn đạt | Cho phần vượt đủ gate; kết quả vẫn là đối chiếu có điều kiện, không bảo đảm được duyệt | Giữ version/approval; ghi observation mới, không tạo approval mới chỉ vì HTTP 200 | Căn cứ/phiên bản, ngày kiểm, facts đã dùng và phần chưa biết |
| Timeout/403/429/5xx hoặc mất mạng; có snapshot cũ nhưng không đạt yêu cầu hiện hành của outcome | Dừng kết luận mới của phần cần kiểm; phần độc lập vẫn trả | Ghi fetch failure; runtime gate `source_currentness_unconfirmed`; không tự suy bãi bỏ hoặc withdraw rule | Tên nguồn/cơ quan, lần kiểm thất bại, ngày bản lưu; cho xem lịch sử và cách xác minh |
| Chỉ có metadata/snippet; toàn văn/phụ lục thiết yếu chưa từng đọc được hoặc extraction không đủ | Chỉ discovery đầu mối; không checklist chính thức, số tiền hay eligibility | `unreadable/extraction_required`; chưa tạo evidence binding/approval dựa trên đoạn chưa đọc | “Đã tìm thấy đầu mối; chưa đọc được … nên chưa đối chiếu phần …” |
| Có snapshot mới với thay đổi điều kiện, ngoại lệ, phạm vi, hạn hoặc dấu hiệu chưa phân loại được | Chặn phần phụ thuộc thay đổi; giữ phần chứng minh độc lập không bị ảnh hưởng | Lưu diff; rule/claim liên quan `needs_review` hoặc `blocked` theo rủi ro; impact closure qua graph | Nêu phần cần rà; không khẳng định văn bản đã bãi bỏ khi chưa có căn cứ |
| Có căn cứ đã xác định văn bản bị bãi bỏ/thay thế hoặc hết hiệu lực đối với ngày hỏi | Không dùng bản cũ cho tư vấn hiện hành; bản mới chưa duyệt vẫn chưa được dùng | Block phần không còn áp dụng; ghi quan hệ thay thế có review; lịch sử không bị xóa | Nêu trạng thái và căn cứ; kết quả trước đây giữ nguyên kèm cảnh báo hiện tại |
| Thông báo “đến khi đủ chỉ tiêu”, chưa xác minh quota/tình trạng nhận | O3 cửa tiếp nhận = `unknown`; O1/O2 chỉ chạy nếu gate riêng đủ | Không suy `open` từ HTTP 200, ngày đăng hoặc điều kiện doanh nghiệp; nguồn trạng thái có ngày kiểm riêng | “Chưa xác minh còn nhận hồ sơ”; bước kiểm chính thức, không nút nộp như đang mở |
| Người dùng mở báo cáo lịch sử/as_of | Đọc lại snapshot theo quyền; không coi là đánh giá mới | Giữ `as_of`, `known_at`, manifest/facts/evidence cũ; thêm lớp cảnh báo hiện tại | “Báo cáo tại ngày …”; tách cảnh báo mới và quyền truy cập hiện hành |
| Người dùng muốn lập đánh giá mới cho một ngày quá khứ | Có thể tái dựng nếu đủ nguồn/facts lịch sử và gate được phép; khác đọc lại báo cáo | Kiểm quyền hiện tại, lịch sử hiệu lực và thông tin đã biết; không dùng `known_at` cũ để lách block hiện hành | Nêu ngày đang xét và giới hạn dữ liệu lịch sử; thiếu thì trả gap |

“Không đổi đáng kể” phải kiểm toàn phần liên quan và companion documents đã đăng ký; quote cũ còn tồn tại chưa đủ. Chỉ thay trình bày được nhận diện an toàn, có audit, mới giữ gate cũ. Profile/cadence được duyệt theo loại claim; chưa đặt một TTL chung hay số giờ tùy ý.

## 3. Các cổng rule, claim và pack

| Cổng | Điều kiện phải đủ | Không được làm |
|---|---|---|
| Source acceptance | Provenance, bytes/extraction/locator/hash, phạm vi và quyền, chất lượng đọc đủ | Lấy được file đồng nghĩa đã hiểu/đã duyệt |
| Evidence binding | Exact span và phiên bản, vai trò chứng minh từng mệnh đề, ngoại lệ/định nghĩa đủ | Dùng citation trang chung cho danh sách hồ sơ tự sinh |
| Rule review | Conditions/DSL hữu hạn, thời gian/phạm vi, evidence/dependencies khớp hash; reviewer đúng scope có approval event | AI tự approve; curator upload đồng nghĩa expert approve |
| Typed claim review | Payload amount/formula/preparation/procedure, từng item có căn cứ; applies_when và giới hạn rõ | Rule eligibility được duyệt kéo theo mọi checklist/mức tiền được duyệt |
| Member publication | Đúng approved version/hash và review event; publisher hiện có quyền, không withdrawn | Phát hành version khác bản reviewer đã duyệt |
| Pack release | Transaction kiểm manifest/member/dependencies/schema/release event và availability; audit người phát hành | Pack cũ vượt member blocked hoặc dùng draft như đã publish |
| Mission assessment | ACL/context snapshot hiện hành, đúng target_date; pack/member usable; gate nguồn theo D07; rule/claim áp dụng | Discovery nguồn mới tự mở eligibility; owner consent vượt governance nguồn |
| Answer/artifact | Outcome coverage, citations và giới hạn đúng; recheck ACL/revision/release trước publish | Một phần thiếu làm bịa phần còn lại hoặc âm thầm sửa báo cáo cũ |

Review, publication và availability là các trục độc lập. Nguồn mới có thể được tiếp nhận tự động; kết luận eligibility vẫn chỉ dùng bản đã duyệt và phát hành. `potential_match` không bằng được hưởng, và không bằng còn nhận hồ sơ.

Nếu chỉ một member bị ảnh hưởng, pack release có thể giữ lịch sử published nhưng phần tư vấn phụ thuộc bị chặn. Phần không liên quan chỉ tiếp tục khi dependency coverage chứng minh độc lập; chưa biết hết phạm vi thì chặn phạm vi nghi ngờ, không tuyên bố “không ảnh hưởng”.

## 4. Phục hồi và phát hành lại — không phát sinh paid call

1. Worker/job hoặc người vận hành ghi observation và kiểm trạng thái hiện tại; retry HTTP không phí hữu hạn theo policy được duyệt, không chạy OCR/dịch/model trả phí như tác dụng phụ.
2. Mạng trở lại: lấy bytes/snapshot, diff và kiểm companion; HTTP thành công không tự bỏ block do thay đổi nội dung/bãi bỏ đã biết.
3. Nếu chỉ lỗi kết nối, nguồn/version không đổi và profile hiện hành đủ: kết quả kiểm kỹ thuật có audit được gỡ cổng chặn tạm thời do lỗi mạng theo D07-A; không tạo approval giả hoặc vượt cổng khác còn thiếu.
4. Nếu nội dung/rule/claim đổi: curator chuẩn bị version mới → expert review đúng scope → publisher release pack mới. Chưa có danh tính/quyền thật thì dừng ở hàng chờ.
5. Revalidation deterministic dùng exact snapshot, manifest, facts và evaluator version. Báo cáo cũ không viết đè; tạo event cảnh báo hoặc kết quả kiểm mới theo quyền. Nếu cần tổng hợp Claude mới, lập operation/grant mới và chờ quyền chi phí, không tự dispatch.
6. Refresh/restart trùng dùng idempotency/outbox; một event không tạo nhiều cảnh báo. Thu hồi quyền áp dụng ngay trước render/download, không chờ index cleanup.

Số dư budget, raw response đã lưu hoặc API key có sẵn không phải quyền cho một lượt AI mới. Đọc lại, xem nguồn, xem cảnh báo và tải artifact hiện có không tự gọi model.

## 5. Ví dụ Hà Nội và dấu vết lựa chọn

Nguồn tham chiếu từ khảo sát đã có: **HN-NOTICE-2026-14**, [Thông báo chương trình tư vấn 2026](https://hotrodoanhnghiep.hanoi.gov.vn/TinTuc/_ChiTietBaiViet?Id=118908&type=tintuc). Tài liệu 05 ghi trang công bố chương trình tư vấn giải pháp chuyển đổi số, tiếp nhận phụ thuộc chỉ tiêu; bản ký/phụ lục và trạng thái nhận hiện tại còn cần xác minh. Ví dụ sau dùng metadata đó, **không xác nhận hiệu lực hoặc cửa tiếp nhận tại ngày đọc**.

Trà Sen hỏi: “Có hỗ trợ tư vấn số hóa kho phù hợp không, cần gì và còn nhận không?”

**Tình trạng hiện có:** chưa có rule/pack được duyệt thật trong đợt thiết kế; theo A, chỉ giới thiệu đầu mối có nhãn, không đối chiếu eligibility/chốt hồ sơ chính thức. Phần hợp lệ độc lập và lịch sử có nhãn vẫn được trả. Không dùng B để hợp thức hóa phụ lục chưa từng đọc được.

| Lựa chọn D07 | Khi sau này đã có pack thật được duyệt, rồi trang tạm không truy cập được | Trạng thái |
|---|---|---|
| **A — Dừng riêng phần chưa đủ căn cứ/độ hiện hành** | Cho đọc bản lưu/báo cáo, giải thích chương trình từng được ghi nhận và dữ kiện còn thiếu; tạm dừng đối chiếu mới của phần nguồn cần kiểm. Tình trạng quota vẫn unknown; phần hợp lệ độc lập vẫn trả | **Đã chốt 19/10/2026**, áp dụng trong thiết kế MVP |
| B — Cho đối chiếu có điều kiện bằng bản lưu đã duyệt | Phương án từng được cân nhắc: tiếp tục một số phần bằng bản lưu trong profile được duyệt; không là quyền đã cấp | **Không được chọn, không bật, không tự fallback**; chỉ thay đổi sau quyết định mới rõ ràng |

B được giữ trong dấu vết thiết kế, không là nhánh runtime khả dụng. Cache/bản lưu không vượt gate về toàn văn, review, publication, withdrawal, hiệu lực hoặc độ hiện hành. Không đặt ngưỡng ngày/tên reviewer giả để khiến thiết kế có vẻ đã vận hành. D07-A không cam kết doanh nghiệp đủ điều kiện pháp lý hoặc được cơ quan duyệt.

**Điều kiện trước phát hành thật:** DTT cần phân công danh tính reviewer/publisher, phạm vi được duyệt và cơ chế thay thế; việc đó không mở lại quyết định D03/D07-A. Cơ chế kiêm nhiệm vẫn chưa được gán/chấp thuận mặc định; nếu cho phép phải ghi rõ vai, trách nhiệm và các sự kiện riêng, không mặc định hai người hoặc một người. Chốt D07-A không đồng nghĩa rule/pack đã được duyệt hoặc phát hành.

## 6. Ca nghiệm thu bổ sung

| Mã | Kịch bản | Kết quả đạt |
|---|---|---|
| D07-01 | Nguồn chỉ mất mạng, không có căn cứ hết hiệu lực | Không báo bãi bỏ; A chặn đúng outcome, còn lịch sử có nhãn |
| D07-02 | Quote còn nguyên nhưng thêm ngoại lệ/phụ lục | Rule/claim phụ thuộc needs_review/blocked; không trả checklist cũ như hiện hành |
| D07-03 | Pack published nhưng member bị withdraw/hash sai | Assessment bị chặn; discovery nguồn công khai có thể tiếp tục có nhãn |
| D07-04 | “Đến đủ chỉ tiêu”, nguồn truy cập được | Không suy đang mở; O3 unknown, không hỏi tài chính không cần thiết |
| D07-05 | Nguồn phục hồi sau block vì sửa điều kiện | Không tự khôi phục approval/usable; cần version/review/release đúng |
| D07-06 | Đọc báo cáo cũ sau thu hồi quyền | Không lộ nội dung; as_of không khôi phục ACL cũ |
| D07-07 | Revalidation/cache/refresh/restart | Không call provider, không trả phí; không sửa báo cáo nguyên bản |
| D07-08 | Hệ thống thử dùng cache/bản lưu để vượt phần đang bị chặn theo A, hoặc phụ lục chưa từng đọc/rule còn draft | Từ chối fallback cho assessment; vẫn trả phần hợp lệ độc lập và lịch sử có nhãn, không chuyển sang B |

**Trạng thái kết thúc tài liệu:** D07-A đã chốt ngày 19/10/2026; B không được chọn. Chưa có rule/claim/pack thật được phát hành, người duyệt/publisher hay cơ chế kiêm nhiệm được gán, job được bật hoặc cuộc gọi model nào từ tài liệu này. Tám ca ở mục 6 là bổ sung cho bộ nghiệm thu lõi, không đổi số ca lõi tại đây.
