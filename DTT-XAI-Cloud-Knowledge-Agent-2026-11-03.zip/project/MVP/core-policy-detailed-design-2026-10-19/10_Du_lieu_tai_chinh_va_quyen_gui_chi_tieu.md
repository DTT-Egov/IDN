# D05 — xử lý tài chính tại server và quyền gửi chỉ tiêu

Ngày 19/10/2026 · D05 **đã được người dùng chốt**. Đây là đặc tả thiết kế, chưa triển khai hoặc gửi dữ liệu tài chính thật. D04 vẫn áp dụng: nhân viên đề xuất, chủ doanh nghiệp xác nhận mọi facts nghiệp vụ SSOT.

## 1. Quyết định và bốn quyền độc lập

Tài liệu tài chính được xử lý tại server; Claude chỉ nhận chỉ tiêu tối thiểu mà người có quyền cho phép; **không gửi tài liệu gốc**. Không hỏi lại D05. Quyền này không cấp ngân sách D06, provider mới, embedding hay lưu dữ liệu vô thời hạn.

| Quyền | Cho phép | Không tự cho phép |
|---|---|---|
| `finance.read` theo resource/field | Đọc số liệu/tài liệu được giao tại server | Gửi dữ liệu cho Claude hoặc đọc tài nguyên khác |
| `finance.authorize_metric_egress` theo resource/field | Cho phép một manifest chỉ tiêu cụ thể đi Claude cho đúng nhiệm vụ | Gửi bản gốc, sửa SSOT, mở rộng mục đích/provider hoặc chi phí |
| Owner xác nhận SSOT | Ghi facts nghiệp vụ đã xem, có CAS và provenance | Tự gửi ra ngoài |
| `budget_grant_id` | Chi tiêu trong mục đích/giới hạn được cấp | Vượt ACL hoặc tự gửi tài chính |

Owner hoặc nhân sự được owner ủy quyền rõ cho egress chỉ được cấp phép phần họ có quyền đọc và quyền quyết định gửi. Mặc định không cấp quyền egress cho staff chỉ vì membership hoặc `finance.read`. Owner của doanh nghiệp không tự đọc/gửi tệp riêng của nhân viên chưa được chia sẻ hợp lệ. Quyền chia sẻ nguồn và quyền gửi chỉ tiêu được kiểm riêng; người chỉ có facts đã chia sẻ có thể cho phép facts đó nếu có thẩm quyền, không cần được mở toàn bộ tệp nguồn.

## 2. Ranh giới đầu vào

Pipeline server: kiểm file/phân loại → parse bằng công cụ server → chuẩn hóa kỳ/đơn vị/phạm vi → tính toán xác định → cảnh báo/mâu thuẫn → đề xuất chỉ tiêu → owner xác nhận nếu đưa vào SSOT → chọn tập tối thiểu → preview/cho phép → Gateway kiểm trước dispatch.

“Công cụ server” là xử lý trong process/môi trường server được kiểm soát, không upload nội dung/filename/telemetry ra dịch vụ ngoài. Parser/OCR SDK gọi từ server nhưng gửi file ra cloud không đáp ứng D05. Network egress của bước parse bị chặn theo allowlist/chính sách; test transport giả phải fail nếu có đường gửi bản gốc. OCR/dịch/tracing hoặc provider mới vẫn disabled đến khi có quyết định riêng; D05 chỉ cho chỉ tiêu tối thiểu được phép đi Claude.

Không dùng Claude vision/OCR để đọc ban đầu tài liệu tài chính. Cấm đi vòng qua ảnh chụp trang, screenshot, base64, OCR nguyên văn, dump sheet/CSV, hàng loạt dòng hoặc câu chat copy/paste để gửi nội dung tương đương bản gốc. Đổi đuôi file hoặc đưa qua MCP không thay classification. Tên file/đường dẫn, sheet/range, khách hàng/nhân viên và các ghi chú tài chính không cần thiết không nằm trong provider payload.

Tác vụ tài chính khiến các attachment của tác vụ đi qua policy tài chính. File hỗn hợp hoặc chưa phân loại rõ được giữ tại server đến khi có thể tách/kiểm phần được phép bằng công cụ nội bộ và preview đúng phạm vi; không gọi model để xác định xem có nhạy cảm hay không. Nhãn file do người dùng chọn và heuristic chỉ hỗ trợ, không là bằng chứng duy nhất để bỏ rào chắn. Đường gửi ảnh sản phẩm phải từ chối ảnh tài chính/hỗn hợp chưa được xử lý, kể cả khi chọn nhầm tác vụ sản phẩm.

Phạm vi `.xlsx` hiện có tiếp tục qua parser được kiểm; PDF/ảnh tài chính chỉ xử lý nếu có extractor server phù hợp được triển khai. Chưa hỗ trợ thì báo không đọc được và xin người có quyền nhập/xác nhận chỉ tiêu; không fallback sang API AI. Không execute macro, external links hoặc code nhúng.

## 3. FinancialMetricVersion

| Trường/nhóm | Quy định |
|---|---|
| Định danh | `enterprise_id`, `resource_id`, `metric_version_id`, `metric_key`, schema/version |
| Giá trị | `value_state`, typed decimal/integer/enum, currency/unit, rounding; không free text tùy ý |
| Phạm vi | reporting period, pháp nhân/cơ sở, consolidated hay standalone, accounting/time basis nếu cần |
| Nguồn nội bộ | document version/hash, sheet/range/page, input metric refs, parser/formula versions; không tự gửi model |
| Chất lượng | validation warnings, reconciliation result, `observation|proposed|owner_confirmed`, verification status |
| Quyền/thời gian | resource/field ACL, recorded time, owner resolution/fact version refs, superseded-by |

Số tiền dùng Decimal. Doanh thu khác lợi nhuận; dòng tiền khác thu nhập; số lao động theo đúng kỳ/cách tính. Ô trống không thành 0. Formula có cache cũ, external dependency, lỗi hoặc thiếu kỳ/đơn vị trả `unknown/conflict` thích hợp. Tính lại chỉ bằng công cụ/hàm được cho phép, không nhờ model đoán số.

Chỉ tiêu tính từ tài liệu là dữ kiện riêng, không tự thành SSOT hay `externally_verified`. Bản làm việc có thể được phân tích với nhãn chưa xác nhận nếu người có quyền cho phép, nhưng không dùng như confirmed fact để kết luận điều kiện chính sách. Kết quả phân loại từ chỉ tiêu cũng là tài chính hạn chế, có lineage và cần egress authorization nếu gửi Claude.

## 4. Chọn tập tối thiểu theo outcome

Nếu outcome chỉ hỏi nơi tiếp nhận hồ sơ, không lấy doanh thu. Nếu code đã đối chiếu điều kiện, model có thể chỉ cần `unknown` hoặc kết quả phân loại thay số chính xác; vẫn phải có quyền gửi kết quả đó. Không gửi toàn bộ chỉ tiêu vì một field đã được cho phép.

Registry chỉ tiêu có allowlist loại giá trị, đơn vị, phạm vi và mục đích. Giới hạn cả tập chỉ tiêu theo plan/context budget để tránh tái tạo một báo cáo từ nhiều field rời. Không chấp nhận `metric_key=entire_statement`, payload JSON tùy ý, ghi chú nguyên văn hoặc chuỗi được model yêu cầu thêm. Chỉ tiêu mới cần schema và mapping nguồn rõ, không tự mở free text.

## 5. FinancialMetricEgressGrant và manifest

Grant do server tạo sau preview/cho phép của người có thẩm quyền. Ràng buộc enterprise/resource, metric **versions và giá trị/hash chính xác**, operation/task/outcomes, mục đích, provider/model profile, prompt/serialization policy, preview/payload hashes, authority/delegation revision, thời hạn, giới hạn dispatch và trạng thái thu hồi. Không chỉ cấp phép tên field “doanh thu” rồi gửi mọi giá trị mới sau đó.

Thời hạn cụ thể theo profile triển khai được cấu hình/duyệt, không tự đặt số ngày trong thiết kế. Grant chỉ áp dụng tập bước đã nêu trong một nhiệm vụ; chat mới/nhiệm vụ mới không kế thừa ngầm. `expires_at` chỉ chặn dispatch mới; không làm mất quyền đọc kết quả đã tạo hợp lệ. Resume bước xác định/cache đọc lại không cần cấp egress lại, kể cả grant gửi đã hết hạn, nếu ACL/retention/quyền sử dụng dẫn xuất hiện hành còn cho phép. Sửa giá trị/kỳ/mục đích/provider/model profile ngoài danh sách cần preview/cho phép mới trước dispatch, không suy tương đương hoặc tạo call mới sau marker.

```json
{
  "schema_version": "FinancialMetricEgressGrant.v1",
  "egress_grant_id": "egress_demo_01",
  "enterprise_id": "enterprise_demo",
  "resource_id": "finance_resource_demo",
  "operation_id": "operation_demo",
  "task_ids": ["explain_condition_demo"],
  "outcome_ids": ["policy_condition_demo"],
  "purpose": "explain_reviewed_condition",
  "provider": "anthropic",
  "model_profile_versions": ["standard_profile_demo_v1"],
  "metric_items": [{
    "metric_version_id": "metric_demo_v1",
    "metric_key": "reviewed_condition_state",
    "value_hash": "<sha256-of-typed-value-and-scope>"
  }],
  "context_snapshot_id": "context_snapshot_demo",
  "preview_hash": "<sha256-of-preview>",
  "provider_payload_hash": "<sha256-of-canonical-payload>",
  "authorization_revision": "authority_demo_v1",
  "expires_at": null,
  "state": "draft",
  "raw_document_allowed": false,
  "budget_grant_id": null
}
```

Đây là JSON minh họa chưa kích hoạt; `expires_at=null` và chưa có budget không là quyền vô hạn. Danh tính người cấp lấy từ phiên, không từ model/client JSON. Server lưu receipt gồm người cấp, các quyền hiện hành đã kiểm, preview/value versions và timestamp; grant active phải đủ thời hạn/authority/manifest.

Provider DTO chỉ chứa aliases/labels từ registry, typed values hoặc kết quả phân loại, kỳ/đơn vị thực cần, cùng context nghiệp vụ/căn cứ công khai được phép. Grant/snapshot/document IDs, hash, locator và tên file giữ trong manifest server; không dump nguyên manifest cho Claude. Đầu vào chat/tài liệu được chuyển thành intent tối thiểu; không forward nguyên message có bảng tài chính. Tool context, ảnh, prompt cache, token-count API và tracing cùng chịu D05, không là đường gửi phụ.

## 6. Enforcement tại Gateway

```text
prepare task -> resolve authorized financial metric versions
minimize by outcome -> typed DTO allowlist -> local preview
authorize exact manifest -> persist egress grant/receipt
pre-dispatch transaction:
  check current actor/resource/field/egress authority
  check metric versions + typed scope + sealed payload hash
  check purpose/task/model-profile + active grant/expiry/revocation
  reject raw-equivalent content; check global minimal-set policy
  check budget separately; CAS dispatch marker
call_once only for that sealed payload; no paid retry/fallback
store restricted response -> validate -> recheck authority/ACL -> publish
```

Chuẩn hóa/serialize từ dữ liệu có kiểu, không để LLM tự nạp thêm facts/file sau preview. Không chỉ dùng bộ dò PII để tuyên bố an toàn. Nếu không xác định được tập chỉ tiêu hợp lệ, chặn trước dispatch và trả `FINANCE_METRIC_EGRESS_BLOCKED`; chưa có ngân sách trả lỗi ngân sách riêng.

Thu hồi quyền gửi trước marker → không gửi. Sau marker vẫn chặn các dispatch tương lai và ghi trung thực đã gửi hoặc chưa rõ; không hứa thu hồi dữ liệu đã tới provider. Không thể bảo đảm giao dịch nguyên tử xuyên SQL/provider; recheck sát marker giảm race, audit thứ tự và giữ no-retry. Publication kiểm chứng dispatch lúc đó hợp lệ và kiểm ACL/context/quyền sử dụng dẫn xuất hiện hành, không bắt egress grant còn hạn để công bố phản hồi của một lượt đã gửi hợp lệ.

Tách rõ hai hành động: **“Dừng gửi chỉ tiêu từ bây giờ”** thu hồi dispatch grant; **“Chặn tiếp tục sử dụng kết quả dẫn xuất trong app”** ghi use-policy event riêng khi người yêu cầu có quyền. Trạng thái `derivative_use_state=allowed|blocked` cùng resource ACL kiểm ở publication/read/cache. Hết hạn hoặc thu hồi quyền gửi đơn thuần không tự xóa báo cáo cũ; thu hồi quyền đọc hoặc block sử dụng dẫn xuất thì chặn đúng phần bị ảnh hưởng. Xóa dữ liệu/retention là workflow khác, không dùng consent hết hạn để giả vờ đã xóa mọi bản sao.

## 7. SQL logic, cache và dữ liệu dẫn xuất

| Bảng/hợp đồng bổ sung | Khóa và bất biến |
|---|---|
| `financial_metric_versions` | PK kép enterprise/metric version; typed value, report scope, source/calculation refs, immutable payload/hash; không thay bảng SSOT |
| `financial_metric_inputs` | Nối metric version tới tài liệu/metric đầu vào trong cùng enterprise, composite FK; không public graph |
| `financial_metric_egress_grants` | PK enterprise/grant; operation/task/purpose/model/expiry/state/preview/payload hashes; authority refs; không có allow_raw override |
| `financial_metric_egress_items` | Exact metric version/value hash + grant; không wildcard các field tương lai |
| `financial_metric_egress_events` | Append-only receipt cấp/thu hồi/dispatch-use; actor, authority revision, reason; không metric values trong log thường |
| `financial_derivative_use_events` | Sự kiện cho/chặn sử dụng dẫn xuất đúng resource/metric/result và quyền hiện hành; tách hạn dispatch, đọc lịch sử và quy trình xóa |

Đây là schema logic bổ sung, không phải migration đã chạy hoặc toàn bộ DDL. Adapter SSOT nối metric đã owner xác nhận vào fact version có provenance; egress grant không ghi fact và owner-confirm không tự tạo egress grant. Budget reservations vẫn do Gateway quản lý.

Cache/query/response/artifact suy ra từ chỉ tiêu giữ sensitivity tài chính và quyền nguồn; không đưa lên kho domain công cộng sau khi chỉ xóa tên. Canonical ACL/derivative-use policy kiểm lại dù cache hit; grant hết hạn chỉ chặn gửi mới. Raw app log/tracing chỉ IDs/hash/count; payload/preview trong kho riêng có quyền. Không dùng chuỗi lỗi/filename để lộ nội dung tài chính. Provider retention, server raw retention/backup/xóa vẫn cần cấu hình trước thí điểm; D05 không tự cấp quyền training, telemetry ngoài hoặc embedding/rerank/search provider mới.

## 8. Chat mobile và ca kiểm

Một thẻ ngắn: “Claude sẽ nhận [N chỉ tiêu] để [mục đích]”; mở xem đúng giá trị/kỳ/đơn vị, không hiển thị tài liệu cho người thiếu quyền. Nút “Cho phép gửi các chỉ tiêu này” tạo egress receipt; “Xác nhận hồ sơ” tạo SSOT receipt khác. Có thể đặt trong cùng màn/batch trình bày nhưng không gộp thành một consent mơ hồ. Nếu chỉ xử lý local, ghi rõ không có model call; không xin phép gửi tài liệu gốc.

Các ca F01–F14 tại [bộ nghiệm thu](<07_Nghiem_thu_va_lo_trinh_trien_khai.md>) kiểm tài liệu thô/ảnh/CSV/chat, grant exact versions, quyền staff, thay đổi/thu hồi, parser errors/egress ẩn, budget, cache/quyền dẫn xuất và cách ly doanh nghiệp. Các ca là đặc tả, chưa phải kết quả chạy app mới. Không gọi Claude trong lượt hoàn thiện thiết kế này.
