# Lõi nMate — hợp đồng và điều phối

Ngày 19/10/2026 · Đặc tả thiết kế đích `core-policy/1.1-draft`. Chưa phải mô tả tính năng đã triển khai. Đối chiếu hiện trạng tại [kiến trúc 0.4](<../../../REFERENCE_LINKS.md#ref-0018>).

## 1. Nguyên tắc và phạm vi

Một trợ lý chung, các capability phía sau, cùng danh tính, SSOT, nguồn, trạng thái, quyền và ngân sách. Giữ ba tác vụ hiện có; chính sách Hà Nội là capability mới, không thành app hoặc bộ hồ sơ doanh nghiệp thứ hai. Không dựng graph/vector database riêng, không bật embedding/provider mới trong đợt thiết kế.

Người dùng đã chốt: chủ doanh nghiệp và nhân viên phân quyền dùng SSOT; nguồn tự cập nhật nhưng DTT/chuyên gia duyệt quy tắc tư vấn. D04 ngày 19/10/2026: staff xem/đề xuất trong phạm vi được giao, owner xác nhận mọi facts nghiệp vụ SSOT. D05 cùng ngày: tài chính xử lý tại server, chỉ gửi Claude chỉ tiêu tối thiểu được cho phép, không tài liệu gốc hoặc raw-equivalent. Chat/tệp riêng không tự chia sẻ; grants tài nguyên cũ không được tự mở khi migration.

## 2. Thành phần

```mermaid
flowchart TB
    UI["Chat mobile · Hồ sơ · Lịch sử"] --> BFF["Phiên · CSRF · idempotency"]
    BFF --> MCP["MCP tools có schema/quyền"]
    MCP --> O["Mission Orchestrator"]
    O --> C["Context Resolver · SSOT"]
    O --> R["Knowledge Retrieval"]
    O --> E["Capability Registry · LangGraph DAG"]
    E --> G["Model Gateway · ngân sách"]
    R --> SQL["SQL: facts · nguồn · rules · quan hệ"]
    C --> SQL
    G --> M["Claude theo vai trò đã cấu hình"]
    E --> V["Kiểm từng outcome · căn cứ · quyền"]
    V --> P["Công bố kết quả · artifact · dependencies"]
    P --> SQL
    P --> UI
    J["Jobs cập nhật nguồn"] --> SQL
    J --> D["DTT/chuyên gia duyệt rule version"]
    D --> SQL
```

Các khối là mô-đun; không tương ứng mỗi khối một dịch vụ hoặc một lượt AI. Registry không cho mô hình tự tạo tool, quyền hay vòng lặp. Model Gateway được gọi khi một capability được cấp quyền cần model; parser, SQL, tính toán và đối chiếu quy tắc rõ dùng hàm xác định.

## 3. ID, phiên bản và ranh giới tin cậy

| Trường | Quy định |
|---|---|
| enterprise_id / actor_id | Server suy từ phiên và membership; JSON do model hoặc browser khai không cấp quyền |
| resource_id | Tham chiếu có scope; resource được đọc/ghi phải kiểm quyền hiện hành |
| operation_id | Một hành động người dùng; duy nhất theo enterprise + operation ID; actor gốc giữ trong audit, người đọc khác vẫn phải có quyền |
| mission_id / task_id / outcome_id | Nhiệm vụ, bước thực thi và ý cần giải; mọi task phục vụ ít nhất một outcome |
| context_revision_id | Mốc phiên bản SSOT doanh nghiệp, không là bản dump để gửi model |
| context_snapshot_id | Snapshot bất biến của tập facts/decisions/draft tối thiểu đã giải quyền cho task, có payload hash |
| source_snapshot_id / chunk_id | Phiên bản nguồn và vị trí trích đoạn bất biến |
| rule_version_id | Quy tắc đúng version, trạng thái duyệt và điều kiện áp dụng |
| claim_version_id | Thông tin mức hỗ trợ/hồ sơ/thủ tục có kiểu và căn cứ, khác fact doanh nghiệp |
| policy_version_id | Phiên bản một chính sách/văn bản nghiệp vụ, không phải routing policy |
| pack_version_id | Bản phát hành tập policy/rule/claim versions; không thay ID của từng văn bản |
| pack_release_event_id | Sự kiện phát hành đúng manifest/hash và thẩm quyền; không chỉ tên pack |
| model_profile_version | Cấu hình provider/model/capabilities đã kiểm |
| budget_grant_id | Quyền chi tiêu do server cấp, có mục đích, hạn mức và thời hạn |
| target_date / as_of | Thời điểm nghiệp vụ cần tư vấn; không khôi phục quyền truy cập cũ |
| known_at | Mốc kiến thức hệ thống biết; chỉ dùng khi tái hiện lịch sử, không tráo với ngày hiệu lực |

Nội dung tài liệu, trang web và MCP nhập vào là dữ liệu không tin cậy. Chỉ dẫn nhúng không được thay instruction, tool allowlist, quyền xác nhận SSOT hoặc hạn mức. Domain rules là dữ liệu theo DSL được duyệt, không là Python/SQL tùy ý do LLM sinh.

## 4. Hợp đồng Goal → Outcome → Task → Answer → Artifact

```json
{
  "schema_version": "mission-spec/1",
  "mission_id": "mission_example",
  "operation_id": "op_example",
  "conversation_id": "chat_example",
  "capability_id": "hanoi_policy.assess",
  "context_revision_id": "ctx_example",
  "context_snapshot_id": "ctx_snapshot_example",
  "target_date": "2026-10-19",
  "intent": {
    "goal": "Tìm hướng hỗ trợ số hóa quản lý kho cho cơ sở Trà Sen",
    "user_span": {"message_id": "msg_example", "start": 0, "end": 62},
    "entities": [{"resource_id": "product_example", "role": "product"}],
    "jurisdiction": "VN-HN",
    "uncertainties": []
  },
  "outcomes": [
    {"outcome_id": "o_match", "kind": "policy_discovery", "question": "Có hướng hỗ trợ nào cần xem xét?", "required": true},
    {"outcome_id": "o_prepare", "kind": "preparation", "question": "Cần chuẩn bị gì?", "required": true},
    {"outcome_id": "o_window", "kind": "application_window", "question": "Còn tiếp nhận hồ sơ không?", "required": true}
  ],
  "constraints": {
    "language": "vi",
    "private_data_to_public_search": false,
    "new_paid_attempt_requires_user_action": true,
    "automatic_application_submission": false
  }
}
```

ID và offset trên là minh họa contract; validator phải đối chiếu `user_span` với đúng chuỗi gốc và giữ hoa thường, không dùng mẫu này làm dữ kiện doanh nghiệp thật. Hợp đồng sản xuất ghi `user_span` cho từng outcome, không chỉ goal. Ý suy ra chỉ được ghi `inferred_dependency` kèm lý do và không biến thành yêu cầu mới của người dùng.

Outcome có `kind`, `question`, `user_span`, `completion_criteria`, `missing_facts`, `evidence_requirements`, `artifact_type?`, `status`. Trạng thái kết quả: `answered`, `partially_answered`, `needs_user_data`, `needs_source`, `awaiting_rule_review`, `unsupported`, `failed`. Chưa biết mục tiêu dùng `needs_clarification` ở mission, khác thiếu facts hoặc thiếu nguồn.

Task có `capability_id/version`, `outcome_ids`, `depends_on`, `context_refs`, `permitted_tools`, `required_evidence_roles`, `execution_kind`, `model_role?`, `budget_grant_id?`, `idempotency_key`, `deadline`, `output_schema`, `completion_checks`. `execution_kind` là `deterministic|retrieval|llm|human_review`. Planner chỉ chọn capability đã đăng ký; kiểm DAG không vòng lặp và tổng hạn mức trước thực thi.

AgentBrief chỉ chứa context refs và dữ liệu tối thiểu đã giải quyền. Envelope mang cả context revision và context snapshot ID/hash. AgentResult chứa `task_id`, `outcome_ids`, `status`, `findings`, `claim_bindings`, `missing_inputs`, `proposed_actions`, `ssot_proposals`, `artifact_refs`, `usage_refs`. Nó không có quyền tự sửa facts chuẩn, duyệt rules hoặc cấp grant mới.

Answer gồm phần kết luận ngắn, mỗi outcome có answer/giới hạn/lý do chưa giải, claim bindings và hành động. Số việc tiếp theo bằng nhu cầu thực; không ép ba việc. Artifact là phiên bản dẫn xuất có dependency refs/hash, giữ nguyên báo cáo cũ khi context thay đổi.

## 5. Hợp đồng căn cứ

Một claim binding gồm `claim_id`, `outcome_id`, `source_snapshot_id`, `chunk_id`, `locator`, `original_quote_span`, `quote_original_hash`, `span_hash`, `span_encoding_version`, `evidence_role=primary|supporting`, `argument_role=supports|exception|definition|context`, `supports_which_condition?`, `rule_version_id?`, `claim_version_id?`, `translation_ref?`. Quan hệ văn bản sửa đổi/thay thế là graph relation riêng, không lẫn vào enum evidence role.

Điều kiện đối tượng/eligibility dùng predicates có kiểu. Mức hỗ trợ, công thức được duyệt, yêu cầu tài liệu và trình tự là typed claims riêng với evidence/publish gate; không tạo field SSOT giả để nhét checklist vào cây điều kiện. Claim có thể có `applies_when` tham chiếu kết quả condition, nhưng số tiền/checklist không tự thành kết luận được hưởng.

Với `hanoi_policy.assess`, kết quả đối chiếu phải khóa pack_version_id + pack_release_event_id và manifest chứa đúng policy/rule/claim versions. Tất cả thành phần cần approved + published + usable và đúng ngày mục tiêu. Raw discovery có thể chưa có pack; chỉ được giới thiệu nguồn/chương trình có nhãn và phần thiếu, không giả là evaluation đã duyệt.

Các kiểm độc lập:

1. ID/hash/quote/locator tồn tại và khớp bản gốc.
2. Actor có quyền hiện hành; nguồn và rule đúng domain/jurisdiction/date.
3. Nguồn thật sự chứng minh mệnh đề, có đủ định nghĩa/ngoại lệ/liên kết cần đọc.
4. Supporting evidence chỉ bổ trợ vai trò được khai; không thay căn cứ chính của một kết luận điều kiện.
5. Mâu thuẫn, khoảng trống hay nguồn mới chưa duyệt không được lấp bằng nội suy.

Kiểm nguyên văn không đồng nghĩa suy luận đúng. Phân loại topic hỗ trợ retrieval, không là điều kiện duy nhất cho việc chấp nhận trích dẫn. Một điều khoản khác topic có thể bổ trợ hợp lệ nếu vai trò rõ và phạm vi đúng.

## 6. Luồng thực thi đích

```mermaid
flowchart LR
    A["Reserve operation + gắn chat"] --> B["Resolve context/quyền"]
    B --> C["Hiểu intent nếu cần"]
    C --> D["Lập plan có outcome"]
    D --> E["Kiểm quyền/ngân sách trước gửi"]
    E --> F["Retrieve · evaluate · synthesize"]
    F --> G["Validate từng outcome"]
    G --> H["Recheck context/quyền/source"]
    H --> I["Publish + artifact + dependencies"]
```

Conversation–operation được tạo/gắn trong cùng giao dịch server trước bất kỳ model call. Outbox/worker có lease và checkpoint; không bảo đảm exactly-once với mạng ngoài bằng lời hứa. Giữ ledger trước dispatch và reconcile trạng thái chưa rõ; resume không tự phát lại lượt có phí. Xem state machine ở [Model Gateway](<04_Model_Gateway_va_van_hanh.md>).

Nếu người dùng hỏi tiếp cùng chủ đề, hệ thống dùng cùng chat và facts snapshot mới, tạo mission revision/operation mới khi có việc mới. Không nói “cùng hồ sơ” nếu thực chất tạo entity khác. Mở lại kết quả chỉ đọc, không inference. Thay đổi facts giữa chừng làm `needs_revalidation`; không công bố như đã dùng facts mới.

## 7. MCP và API

Giữ tools hiện hành cho app 0.4. Thêm namespace có phiên bản `core_v1.*`, `policy_v1.*`, `knowledge_admin_v1.*` qua adapter; frontend không tự gọi provider. Tool admin không xuất hiện trong danh sách công cụ của chủ/nhân viên doanh nghiệp.

| Tool đích | Hành vi và quyền |
|---|---|
| core_v1.prepare_mission | Reserve operation, gắn chat, resolve context và chuẩn bị plan; nếu cần lượt hiểu intent có phí phải có grant đã xem trước |
| core_v1.start_mission | Khóa plan/context version, nhận grant phù hợp rồi enqueue; trả handle, không giữ HTTP tới hết nghiên cứu |
| core_v1.get_operation | Đọc trạng thái/usage/next action có quyền; không gọi model |
| core_v1.get_result | Đọc snapshot/artifact có quyền và nhãn stale; không inference |
| core_v1.propose_facts | Lưu đề xuất và provenance, không ghi CurrentFact |
| core_v1.confirm_facts | Chủ có quyền xác nhận theo expected version; atomic batch |
| finance_v1.prepare_metrics / get_metric_preview | Parser/preview tài chính có quyền ở server, không LLM; không gửi bản gốc |
| finance_v1.authorize_metric_egress / revoke_metric_egress | Quyền egress riêng, exact metric/value versions/purpose/profile; không ghi SSOT hoặc tự dispatch |
| policy_v1.prepare / policy_v1.start | Adapter sang hai tool chuẩn với capability `hanoi_policy.assess`; không pipeline dữ liệu riêng |
| knowledge_admin_v1.propose_rule / review_rule / publish_pack | Chỉ curator/reviewer/publisher theo scope; không cấp quyền đọc tenant |

Mẫu ghi cần `client_request_id`, `expected_*_version` và hash input; ID trùng payload khác trả `IDEMPOTENCY_CONFLICT`. Với tool đọc không yêu cầu grant. Server luôn giải actor/enterprise từ auth; các ID trong arguments chỉ là tham chiếu để kiểm quyền.

Tool errors có `code`, `message_vi`, `operation_id?`, `state`, `allowed_actions`, `new_paid_call_required`, `details_ref`. Mã chuẩn: `AUTH_REQUIRED`, `RESOURCE_UNAVAILABLE`, `VERSION_CONFLICT`, `CONTEXT_CHANGED`, `SOURCE_NOT_READY`, `RULE_REVIEW_REQUIRED`, `DATA_EGRESS_BLOCKED`, `BUDGET_NOT_GRANTED`, `BUDGET_EXCEEDED`, `PROVIDER_UNAVAILABLE`, `OUTCOME_UNKNOWN`, `OUTPUT_REJECTED`, `IDEMPOTENCY_CONFLICT`, `UNSUPPORTED_INTENT`. `FINANCE_METRIC_EGRESS_BLOCKED` nội bộ ánh xạ `DATA_EGRESS_BLOCKED`, bị chặn trước dispatch không phải lỗi provider cần thử lại. Lỗi tài nguyên khác tenant không tiết lộ nó có tồn tại. Messages/log không chứa key hoặc tệp riêng không được phép.

Các mã ở Gateway là nguyên nhân nội bộ; API/tool adapter ánh xạ về mã chuẩn, đồng thời giữ `internal_reason_code` trong trace có quyền. Ví dụ `BUDGET_GRANT_REQUIRED → BUDGET_NOT_GRANTED`, `BUDGET_EXHAUSTED → BUDGET_EXCEEDED`, `EVIDENCE_CONTRACT_FAILED/INVALID_JSON/OUTPUT_TRUNCATED → OUTPUT_REJECTED`, `PROVIDER_OUTCOME_UNKNOWN → OUTCOME_UNKNOWN`, `MODEL_BINDING_UNAVAILABLE → PROVIDER_UNAVAILABLE`. Không có client flag `retryable` cho phép tự gọi model. HTTP/tool read-status vẫn an toàn vì không dispatch.

Operation có thể có các bước nghiệp vụ khác nhau đã được cấp quyền rõ. Mỗi `(enterprise_id, operation_id, task_id, step_key)` chỉ có tối đa một dispatch; tổng bước/call cũng bị chặn bởi plan và grant. Không tạo step mới cho cùng việc bị lỗi để lách no-retry. Flow đề xuất tách hành động gửi để hiểu intent và hành động bắt đầu nghiên cứu; UI phải nói rõ từng lượt dự kiến trước gửi.

## 8. Mở rộng capability

Registry entry phải có chủ sở hữu nghiệp vụ, version, intent kinds, input schema, allowed scopes/tools, evidence policy, model roles, output schema, budget class, test refs và release status. Các adapter hiện có: `document_intake`, `export_research`, `sales_inventory`; mới: `hanoi_policy.assess`.

Không dùng bốn “agent tự do” cho mọi câu. Mỗi bước độc lập chỉ khi cần input/output, quyền, lỗi hoặc ngân sách riêng. Với câu đơn giản đủ dữ kiện, một retrieval + đối chiếu + một lần tổng hợp có thể đủ; nhiều node LangGraph không mặc định nhiều call. Đề xuất thiết kế tách capability để sau này thêm chiến lược doanh nghiệp mà không viết lại SSOT/retrieval/gateway.

## 9. Phụ thuộc quyết định và tiêu chí hoàn thành

- Áp dụng D04/D05 đã chốt: staff đề xuất/owner xác nhận SSOT; tài chính server-only, Claude chỉ nhận chỉ tiêu tối thiểu đã được cho phép. Grants tài nguyên/egress không tự mở khi migration; [hợp đồng D05](<10_Du_lieu_tai_chinh_va_quyen_gui_chi_tieu.md>) ràng buộc exact manifest, authority, no-original và budget riêng.
- Grant chưa được cấp không dispatch; xem quyết định [D04–D07](<08_Quyet_dinh_can_chot.md>).
- Không coi source shortlist là pack đã được chuyên gia duyệt.
- D07 phương án A đã chốt 19/10/2026: source gate áp dụng theo từng outcome/claim và phụ thuộc; dừng phần thiếu căn cứ hiện hành, trả phần độc lập hợp lệ và lịch sử có nhãn. Không cho một lỗi nguồn làm hỏng toàn báo cáo hoặc tự chuyển sang dùng bản lưu để kết luận mới. Quyền reviewer/publisher và approval version thật vẫn bắt buộc trước release.
- Chỉ bắt đầu triển khai khi các phần P0 có schema/contracts tương thích và acceptance pack không còn mâu thuẫn; quyết định chưa chốt có thể giữ capability bị khóa thay vì chặn mọi tính năng hiện có.
