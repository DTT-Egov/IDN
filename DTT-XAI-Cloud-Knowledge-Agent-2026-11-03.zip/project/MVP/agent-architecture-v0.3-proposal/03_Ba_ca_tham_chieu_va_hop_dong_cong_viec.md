# Ba ca tham chiếu và hợp đồng giao việc cho Agent

**Thiết kế minh họa 0.3 · 18/10/2026 · chưa thực thi.** Các kế hoạch dưới đây lấy từ câu hỏi và lỗi quan sát được; không phải các báo cáo nghiên cứu pháp lý mới. Không có nguồn/bằng chứng nào được tạo giả để làm ví dụ. Số task nội bộ và số việc doanh nghiệp thấy có thể khác nhau.

Đọc cùng [thiết kế tổng quan](<01_Thiet_ke_kien_truc_Agent.md>) và [đặc tả triển khai](<02_Dac_ta_MVP_0_3_va_lo_trinh.md>).

Tất cả ca còn áp dụng [04 — Enterprise SSOT và domain knowledge](<04_SSOT_doanh_nghiep_va_tri_thuc_domain.md>): lấy context của đúng doanh nghiệp/entity, giữ phiên bản đã dùng; tri thức chung dùng lại qua gate, finding riêng không tự chia sẻ.

## 1. Trà Sen Tây Hồ: hai mục tiêu, hai loại đầu ra

**Câu hỏi:** “Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.”

### Intent và tiêu chí hoàn thành

| Outcome | Người dùng cần | Được tính hoàn thành trong phạm vi nào? |
|---|---|---|
| T1 — tìm hiểu đăng ký | Quy tắc chung, điều kiện/diện chưa kiểm, dữ kiện cần để xem xét cơ sở | Hướng dẫn chung có căn cứ trả lời được phạm vi kiến thức đã hỏi; điều kiện riêng giữ rõ. Nếu chỉ có gap thì outcome còn blocked_source/waiting_facts, không tự kết luận cơ sở phải/không phải đăng ký |
| T2 — chuẩn bị nhãn | Khung nội dung tiếng Anh dùng để điền/rà đúng sản phẩm | Tạo đúng loại artifact, có trường/placeholder và companion Việt; nêu mục chưa đủ nguồn. Không hứa đây là nhãn đã duyệt/in được |

Dữ kiện có thật trong câu: tên sản phẩm, New York, mục tiêu. Chưa có: công thức, hoạt động/loại hình cơ sở, lượng tịnh, bao gói, thông tin đơn vị chịu trách nhiệm. Không biến tên sản phẩm thành thành phần hoặc tên thương hiệu đã xác minh.

### Kế hoạch và phân công

```mermaid
flowchart LR
    I[Intent và snapshot] --> R1[Tra cứu phạm vi đăng ký]
    I --> R2[Tra cứu nội dung và điều kiện nhãn]
    R1 --> A1[Bảng dữ kiện để xem áp dụng]
    R2 --> A2[Khung nhãn với ô thiếu]
    A1 --> V[Kiểm đủ T1 và T2, nguồn và giới hạn]
    A2 --> V
```

| Task nội bộ | Năng lực | Giao việc cụ thể | Đầu ra kiểm được |
|---|---|---|---|
| T-R1 | `export_us.facility_registration` | Lấy nhận định và ngoại lệ đúng scope; chỉ rõ dữ kiện còn thiếu để áp vào cơ sở | Claim có trích đoạn hoặc gap, bảng điều kiện/dữ kiện |
| T-R2 | `export_us.food_label` | Lấy các mục nội dung/ngoại lệ phù hợp; không dùng nguồn đăng ký để chứng minh đủ nhãn | Claim theo từng mục, evidence refs/limitations |
| T-A1 | `artifact.applicability_sheet` | Biến T-R1 thành bảng người dùng có thể bổ sung dữ kiện | Field có value/provenance hoặc null với câu hỏi hữu ích |
| T-A2 | `artifact.food_label_workbook` | Tạo khung tiếng Anh từ T-R2, giữ tên sản phẩm ở phần tham chiếu, không tự điền dữ kiện thiếu | Artifact có schema trường và bản đọc MD, chưa duyệt |
| T-V | `validation.outcome_contract` | Kiểm từng ý, căn cứ và loại vật phẩm; giữ phần đạt nếu một nhánh thiếu | Coverage theo T1/T2; trạng thái riêng, không gộp thành “đã tuân thủ” |

T-R1/T-R2 chỉ song song nếu không có phụ thuộc và ngân sách cho phép. Cùng một tài liệu nguồn dùng chung một snapshot, không fetch hai lần. Trong 0.3 đây có thể là hai hàm nghiên cứu giới hạn nguồn dùng cùng một lượt tổng hợp, không nhất thiết hai LLM agents.

### Bản giao việc ví dụ cho T-A2

```text
Mục tiêu: T2; đầu ra: food_label_workbook, schema v1.
Đầu vào: snapshot đúng Trà Sen Tây Hồ + kết quả T-R2 đã kiểm.
Được làm: dựng khung, giải thích Việt, nối field→claim/evidence, ghi ô thiếu.
Chưa được làm: bịa thành phần/lượng/dị nguyên; suy ra miễn; duyệt để in; gửi ngoài.
Hoàn thành: mọi field có trạng thái + value hoặc câu hỏi; mọi yêu cầu có nguồn
hoặc trạng thái chưa đủ; xuất bản draft nhất quán với data có phiên bản.
Dừng/partial: thiếu căn cứ cho field thì đánh dấu field đó; không xóa cả khung.
Mô hình: chỉ gọi trong execution grant còn hiệu lực; không tự retry.
```

### Hình dạng vật phẩm cần tạo — không chỉ lời nhờ

```markdown
# Khung nhãn tiếng Anh — bản nháp cần dữ kiện và rà chuyên môn
Product reference supplied by user: Trà Sen Tây Hồ

| Label field | Draft value | Field state | Basis / next input |
|---|---|---|---|
| Statement of identity | [Not yet established] | needs_input | Tên thực phẩm tiếng Anh cần rà |
| Net quantity | [Not supplied] | needs_input | Lượng tịnh và đơn vị |
| Ingredients | [Not supplied] | needs_input | Công thức và thứ tự theo căn cứ |
| Responsible business | [Not supplied] | needs_input | Tên/địa chỉ/vai trò cần xác nhận |
| Nutrition information | [Applicability not established] | needs_scope_check | Căn cứ và điều kiện |
| Allergen information | [Not established] | needs_input_and_scope_check | Thành phần/quy trình và căn cứ |

## Giải thích tiếng Việt và nguồn
Từng dòng nối tới claim/evidence đã có; chưa có thì ghi chưa đủ nguồn.
Trạng thái: chưa duyệt. Không phải nhãn sẵn để in.
```

Đây chỉ là ví dụ cấu trúc artifact cần có, không xác nhận danh sách trên đủ cho nhãn thực tế. Render trong chat từng phần, không bắt người dùng xử lý bảng rộng trên mobile. Khi họ điền, lưu ArtifactRevision mới; lần bấm lại mở đúng bản đã sửa.

**Reuse:** dùng lại các claim/rule/template phù hợp thị trường/loại hàng/thời điểm; không dùng lại công thức của một sản phẩm khác. Nếu câu tiếp là “phần nhãn còn thiếu gì?”, chỉ tra đúng artifact/lineage; không chạy lại nghiên cứu đăng ký nếu chưa có lý do.

## 2. Mứt Sen: câu trả lời ai/khi nào trước, phiếu điền sau

**Câu hỏi:** “Em có Mứt Sen gửi New York. Thông báo trước lô hàng do ai nộp và nộp khi nào?”

### Intent và phạm vi

M1 trả lời ai có thể nộp; M2 trả lời cách xác định thời điểm theo điều kiện. **M3 — phiếu hạn riêng** là đầu ra hỗ trợ được đề xuất, không mặc định người dùng đã yêu cầu hệ thống nộp thật. Không cần ETA để trả lời quy tắc chung; cần ETA/phương thức khi người dùng muốn xác định một mốc cụ thể.

Kế hoạch: tra kho theo hai ý → kiểm claim/rule có nguồn và phạm vi → trả lời trực tiếp → tạo worksheet nếu được chọn → tính hạn khi đủ input → kiểm từng kết quả. Bước IOR/FSVP chỉ xuất hiện khi có dependency cụ thể cần giải thích; không dùng để lấp vị trí việc 2.

### Hợp đồng worker nghiên cứu thời điểm

```text
Capability: export_us.prior_notice.timing
Question: Với scope được hỗ trợ, các điều kiện nào quyết định cửa sổ nộp?
Input: jurisdiction/type scope; không cần tên hoặc dữ kiện riêng để query công khai.
Output: conditional_rules[] gồm điều kiện, mốc/công thức, ngoại lệ, source refs,
effective/retrieved metadata và phạm vi chưa kiểm; gaps[] nếu thiếu.
Không tự giả định phương thức, ETA, timezone, người nộp hoặc kênh khai.
Không tính deadline riêng nếu điều kiện rule/input chưa đủ.
Acceptance: mỗi rule có evidence đúng ý; lỗi fetch không thành “không cần nộp”.
```

Trong proposal này không chép các con số pháp lý từ báo cáo cũ thành rule còn hiệu lực. Rule được nạp và kiểm riêng khi triển khai capability.

### Worksheet dùng được

| Trường | Giá trị ban đầu | Trạng thái / cách tiếp tục |
|---|---|---|
| Sản phẩm, thị trường | Mứt Sen, New York | Người dùng cung cấp, chưa kiểm |
| Người dự kiến nộp | Trống | Tên/vai trò/đầu mối cụ thể hoặc chưa biết; không lấy “Em” làm tên nhân sự |
| Có đủ dữ kiện để nộp? | Chưa xác nhận | Danh sách mục dữ liệu theo căn cứ và nguồn |
| Phương thức vận chuyển | Trống | Chọn/nhập; có lựa chọn chưa biết |
| Điểm đến đầu tiên và thời điểm dự kiến | Trống | Ngày giờ + timezone, nguồn xác nhận |
| Kênh nộp dự kiến | Trống | Điều kiện theo rule đã kiểm |
| Rule version và căn cứ | Trống cho tới khi lookup hợp lệ | Không viết số giờ vào công thức nếu không có trace |
| Hạn riêng tính được | Null | Chỉ tính bằng mã khi đủ điều kiện; giữ input/rule version |
| Người kiểm và xác nhận | Trống | Thao tác thật hoặc chưa xác nhận |
| Trạng thái nộp | Chưa nộp | Không tạo số xác nhận giả |

Thay ETA/phương thức tạo input revision mới và đánh dấu mốc cũ cần tính lại. Khung phiếu có thể hoàn thành trong khi hạn riêng còn `waiting_facts`. Chỉ coi M1/M2 được đáp ứng trong phạm vi câu hỏi khi mỗi ý có câu trả lời phù hợp có căn cứ. Gap nói rõ chứng minh đã phản hồi minh bạch, không khiến outcome thành satisfied; tạo worksheet không tự xóa gap.

**Reuse:** claim ai nộp/rule thời điểm có thể dùng ở nhiệm vụ khác qua cổng scope/freshness; người nộp, ETA, timezone, nơi đến và confirmation là dữ kiện riêng của lô. Đọc worksheet cũ không gọi AI.

## 3. Bột Sen: giữ câu hỏi mở, tạo tiến bộ thật khi chưa đủ căn cứ

**Câu hỏi:** “Tôi có Bột Sen gửi New York. Sản phẩm cần chứng nhận gì?”

### Intent và giới hạn hoàn thành

**B1 — outcome người dùng yêu cầu:** tìm hiểu yêu cầu nào áp dụng với sản phẩm và hướng bán. Nếu thiếu nguồn hoặc dữ kiện thì B1 vẫn chưa được giải trọn vẹn.

**B2 — outcome hỗ trợ:** có hồ sơ sản phẩm và bản đồ câu hỏi để nghiên cứu tiếp. B2 hữu ích nhưng không được dùng để âm thầm đổi B1 thành một nhiệm vụ dễ hơn rồi báo hoàn thành.

Đầu vào làm rõ nên là điều doanh nghiệp biết: “Bột dùng để ăn/uống hay mục đích khác?”, “Người mua đã gửi yêu cầu giấy tờ nào chưa? Nếu chưa có, cứ để trống.” Không hỏi bắt buộc “Anh cần chứng nhận nào?”. Câu tiếp theo dựa phần đã biết và câu trả lời làm thay đổi phạm vi.

### Kế hoạch

| Bước | Công việc | Kết quả |
|---|---|---|
| B-I | Nhận diện phạm vi sản phẩm/cách dùng và tài liệu đang có | Context + ambiguity/input gaps; không bịa thành phần |
| B-K | Lookup nguồn/claim đúng câu hỏi, không chỉ số tổng FDA | CoverageRecord: phần nào có căn cứ, phần nào chưa tìm thấy trong phạm vi đã kiểm |
| B-D | Dựng dossier/checklist, dùng template có phiên bản | Hồ sơ có thể điền và biết cần lấy dữ liệu từ ai |
| B-R | Khi phạm vi cho phép, nghiên cứu các câu hỏi hẹp do B-I/B-K xác định | Supported/conditional claims hoặc source gaps; không cam kết tìm đủ mọi chứng nhận |
| B-A | Lập ma trận yêu cầu/câu hỏi còn mở | Phân biệt căn cứ, điều kiện, dữ kiện thiếu, bước xác minh |
| B-V | Kiểm B1 và B2 riêng | B2 có thể có artifact sẵn; B1 vẫn chưa được đáp ứng trọn vẹn, ở waiting_facts/blocked_source theo gap nếu chưa đủ |

Số bước và thứ tự phụ thuộc thông tin sẵn có. Nếu B-K đã biết catalog không phủ câu hỏi, không tải lại cùng tám trang rồi lặp kết quả “chưa đủ”. Trước mắt trả dossier và gap map rõ; nghiên cứu thêm cần có nguồn/capability/grant phù hợp.

### Dossier và ma trận đầu ra

Checklist gồm tên sản phẩm; thành phần; chế biến/bảo quản; cách dùng và công dụng được công bố; bao gói/ảnh nhãn; hạn dùng và căn cứ; thị trường/kênh/người mua; giấy tờ hiện có. Mỗi mục có value hoặc chưa biết, nguồn người dùng, người có thể cung cấp và liên hệ với câu hỏi cần giải.

| Nhóm cần tìm hiểu | Nhận định đã có căn cứ | Điều kiện/dữ kiện còn thiếu | Bước tiếp |
|---|---|---|---|
| Yêu cầu pháp lý đối với sản phẩm trong scope | Chưa kết luận nếu chưa có source phù hợp | Loại/cách dùng/quy trình và phạm vi cần kiểm | Thu dữ kiện hoặc giao câu hỏi nghiên cứu hẹp |
| Đăng ký/hồ sơ hoạt động cơ sở | Không đồng nhất với chứng nhận sản phẩm | Hoạt động/địa điểm/loại hình và nguồn áp dụng | Rà riêng khi liên quan |
| Yêu cầu của người mua | Chưa có tài liệu nếu người dùng chưa cung cấp | Bản yêu cầu, bên phát hành và thời điểm | Cho phép chưa có; soạn bảng hỏi nếu cần |
| Chứng nhận tự nguyện/claim thương mại | Không tự liệt kê thành bắt buộc | Mục tiêu claim, thị trường, bằng chứng | Nghiên cứu khi người dùng chọn mục tiêu |

Đây là khung phân tích, không khẳng định bốn hàng đã bao trùm đầy đủ quy định cho Bột Sen. Mọi tên chứng nhận cụ thể phải có nguồn/điều kiện; không tự thêm FDA/HACCP/ISO để trông có câu trả lời.

**Câu hiển thị ngắn đề xuất:** “Trong bộ nguồn hiện có, mình chưa đủ căn cứ xác định giấy tờ áp dụng riêng cho Bột Sen. Mình có thể giúp anh lập hồ sơ sản phẩm và chỉ ra câu hỏi cần kiểm tiếp. Trước hết, bột dùng để ăn/uống hay mục đích khác?” Ngôn ngữ xưng hô thực tế theo preference, không suy giới tính từ tên.

**Reuse:** dùng lại template dossier và cách phân loại gap; dùng claim chỉ khi qua gate. Không lấy kết luận hoặc nguyên liệu Trà Sen/Mứt Sen. Thêm nguồn mới chỉ làm lại phần B1 bị ảnh hưởng, giữ B2 và bản người dùng đã điền nếu không bị thay đổi.

## 4. Tiêu chí chung cho ba ca và use case kế tiếp

### Mẫu AgentBrief để server giao nhiệm vụ

Ví dụ dữ liệu thiết kế, **không chạy được và không có grant**. Input là các reference đã kiểm quyền; nguồn và công cụ do registry giải quyết, không do model truyền URL tùy ý.

```json
{
  "example_only": true,
  "execution_allowed": false,
  "task_id": "example:research-label",
  "outcome_refs": ["T2"],
  "capability_id": "export_us.food_label",
  "capability_version": "proposal-v1",
  "question_to_answer": "Những mục nào cần xem xét khi chuẩn bị nội dung nhãn trong phạm vi được hỗ trợ?",
  "context_refs": ["example:context-revision-1"],
  "known_unknowns": ["ingredients", "net_quantity", "responsible_business"],
  "source_policy": "approved_catalog_only",
  "allowed_tools": ["authorized_knowledge_lookup", "bounded_catalog_fetch"],
  "expected_output": {
    "schema": "supported_findings-v1",
    "required_sections": ["claims", "evidence_refs", "scope_conditions", "gaps"]
  },
  "acceptance_checks": ["exact_source_binding", "scope_not_overstated", "no_invented_product_fact"],
  "limits_from": "server_pack_and_execution_grant",
  "stop_on": ["source_gap", "budget_exhausted", "operation_outcome_unknown"],
  "grant_id": null
}
```

Worker trả `TaskResult` gồm task/attempt/input hash, output refs, claims và gaps, nguồn đã đọc/lỗi, thời gian/usage nếu có. Orchestrator kiểm và commit; worker không tự cấp grant, đổi schema, duyệt claim hay đánh dấu Mission complete. `source_gap` dừng phần nghiên cứu không đủ căn cứ; phần tạo checklist độc lập vẫn có thể tiếp tục nếu đúng contract.

### Các cửa nghiệm thu

1. Truy vết nguyên văn → từng outcome → task → claim/evidence hoặc gap → artifact. Không mất ý thứ hai của câu hỏi.
2. Một task không tạo giá trị cho outcome/dependency thì không được coi là việc cần làm. Có thể có 0/1/2/n việc.
3. Input gap, source gap, artifact gap và ambiguity có trạng thái khác nhau. Không thiếu source thành “không cần”; không thiếu dữ kiện thành đã biết.
4. Mở lại artifact đúng phiên bản đã sửa; đổi facts/rule thì nêu phần cần rà, không xóa lịch sử.
5. Mở/lưu/lookup không tự dispatch paid model. Bất kỳ lần gọi mô hình nào cũng chịu grant/attempt ledger.
6. Run hoàn tất không chứng minh mục tiêu doanh nghiệp đã xong hoặc giấy tờ đã được duyệt/nộp.

**Ca mở rộng giả định:** so sánh hai báo giá máy đóng gói và soạn bảng hỏi nhà cung cấp. Cùng core biểu diễn được các outcome/nguồn báo giá/task so sánh/decision matrix, không cần field FDA, Incoterm hay nấc xuất khẩu trong kernel. Đây là phép thử thiết kế, không phải khuyến nghị mua máy hoặc cam kết MVP mới. Còn hai gói phù hợp roadmap hiện tại là nghiên cứu thị trường và đối tác; mỗi gói cần nguồn và artifact riêng.

## 5. Tích lũy qua các ca, cá nhân hóa và refresh

Chỉ khi có liên kết doanh nghiệp/sản phẩm/cơ sở được xác nhận mới dùng chung dữ kiện giữa ca. Ba conversation giả lập cũ không tự được xem là cùng doanh nghiệp. Ví dụ minh họa cùng DN: Trà Sen bổ sung cơ sở và công thức đúng product revision; Mứt Sen có thể dùng thông tin DN/cơ sở có quan hệ thật, nhưng không lấy công thức Trà Sen; Bột Sen kế thừa hồ sơ DN và lấy dossier riêng, chỉ hỏi công dụng/quy trình còn thiếu.

DN khác có thể dùng cùng public rule/template Prior Notice còn phù hợp; ETA/người nộp/thành phần và finding riêng không chuyển qua. Nếu source version hoặc dữ kiện thay đổi, tạo phiên bản mới và đánh dấu đúng phần deadline/nhãn/kết luận cần rà. Mở bản cũ vẫn thấy snapshot cũ và trạng thái đối chiếu, không tự gọi lại AI. Mỗi nhiệm vụ mới phải ghi cả EnterpriseContextRevision và DomainKnowledgeVersion refs để biết việc cá nhân hóa và dùng lại đã dựa trên gì.
