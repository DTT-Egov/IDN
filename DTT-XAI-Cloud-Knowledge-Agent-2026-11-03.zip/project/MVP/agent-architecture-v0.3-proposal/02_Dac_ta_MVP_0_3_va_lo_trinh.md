# Đặc tả kiến trúc và phân kỳ MVP 0.3

**Đề xuất, chưa có code triển khai · 18/10/2026.** Đi cùng [thiết kế tổng quan](<01_Thiet_ke_kien_truc_Agent.md>) và [ba ca tham chiếu](<03_Ba_ca_tham_chieu_va_hop_dong_cong_viec.md>). Nguồn hiện trạng được truy vết trong [rà mã nguồn](<research/current-state.md>); quyết định lưu trữ được phân tích trong [memory và contracts](<research/memory-and-contracts.md>).

Bổ sung theo yêu cầu người dùng: [04 — SSOT doanh nghiệp và tri thức domain](<04_SSOT_doanh_nghiep_va_tri_thuc_domain.md>) là đặc tả chuẩn cho tích lũy facts, cá nhân hóa, quyền dùng lại và refresh. Browser identity hiện có chưa phải enterprise membership đã triển khai.

## 1. Ranh giới hiện trạng và đích

| Hiện trạng đã thấy | Đích 0.3 |
|---|---|
| Intake trả facts có provenance, câu hỏi và readiness; topic nghiên cứu dựa năm nhóm regex | Thêm IntentSpec tách mục tiêu/đầu ra/ràng buộc; vẫn giữ grounding dữ kiện |
| Shipment graph tuyến tính; nguồn lấy cả catalog, policy chọn canonical next_steps | Planner chọn mẫu theo outcome; nghiên cứu đúng task; UserAction tách ResearchTask |
| Case có thể cập nhật version; snapshot trong run và artifact mới bất biến | Bổ sung mission/context/plan revision append-only; không đổi nghĩa case API cũ |
| Source text/hash, excerpt/dịch gắn run; chưa có thư viện nhận định dùng lại | Knowledge records + quan hệ phụ thuộc + quyết định reuse có lý do |
| Lưu việc/nháp ở frontend localStorage | Vật phẩm và UserAction của luồng mới có server ID/version/quyền; local là cache |
| Conversation kiểm tenant+owner; case/run/artifact chủ yếu tenant, profile local tách tenant | Chính sách resource ACL rõ trước khi nhiều người chung tenant; không suy tenant membership đủ mọi quyền |
| Năm MCP tools, mới Shipment khả dụng | Giữ tools cũ; thêm mission facade khi luồng mới đạt nghiệm thu |

Không công bố market/partner khả dụng khi registry vẫn planned. Không coi tài liệu thiết kế cũ là quyết định còn hiệu lực nếu trái lựa chọn mới của người dùng. Các model ID tiếp tục cấu hình server và khóa theo run; Sonnet cho công việc thường, Opus cho công việc phức tạp theo policy được duyệt. Tài liệu này không xác nhận model ID nào đang khả dụng, không tự nâng mức hoặc thử provider.

## 2. Đối tượng dữ liệu chuẩn

| Đối tượng | Trường cốt lõi | Bất biến cần giữ |
|---|---|---|
| Enterprise/Entity | enterprise_id, principal membership/role, entity IDs, resource ACL | Không gộp theo tên/profile; xác định đúng sản phẩm/cơ sở/lô và người có quyền |
| EnterpriseFact | assertions/provenance, field authority policy, resolution, CurrentFact projection, valid/recorded time | Lời khai khác dữ kiện hiện hành; self_declared khác externally_verified; conflict/null/known_absent không nhập nhằng |
| Mission | id, tenant_id, enterprise_id, owner/resource ACL, product/project ref, current_revision | Enterprise được server xác lập qua membership; không rebind theo UI hiện tại; quyền không lấy từ câu model/argument tenant_id |
| IntentSpec | request_mode, raw_message_refs, outcomes, constraints, ambiguities | Tách điều user nói, điều hệ thống suy ra và dữ kiện xác minh được |
| ContextSnapshot | enterprise_id/context revision, facts/resolution refs, provenance, unknowns, decisions/preferences, source versions, effective ACL/use refs | Khóa refs/hash nhất quán; dẫn xuất không mở rộng quyền input; không lấy dữ kiện DN khác hoặc preference đè yêu cầu mới |
| OutcomeContract | question_part, origin=requested/supporting, output_types, acceptance_template_id, missing_conditions | Criteria lấy từ pack đã kiểm; model chỉ chọn/điền slot được phép; hỗ trợ không thay kết quả gốc |
| PlanRevision | intent/context refs, pack versions, tasks, dependencies, limits, hash | Append-only; plan mới có delta và lý do; không ghi đè bản đã chạy |
| ResearchTask | outcome_ids, capability_id/version, input_refs, output_schema, checks, dependencies | Task phải đóng góp outcome hoặc gỡ dependency, không task mồ côi cho đủ số lượng |
| TaskAttempt | task+plan revision, state, timestamps, output_refs, error/reuse decision | Retry là attempt mới; kết quả thành công không bị callback muộn ghi đè |
| ProviderAttempt | operation key, grant/model refs, request hash, dispatch/result state, usage nếu có | Một ý định đã dispatch không tự phát lại khi kết quả chưa rõ |
| Evidence/Claim | source snapshot, exact locator/hash, scope, applicability conditions, review status | Đọc được nguồn khác với nhận định đã được duyệt hoặc áp dụng được |
| ArtifactRevision | kind, schema version, data/field states, lineage, content hash | Nhãn/phiếu/checklist khác lời nhờ; bản sửa không tự quay về mẫu gốc |
| UserAction | outcome refs, owner identity, due date, actual progress, completion evidence | “Đã lưu” không đồng nghĩa “đã giao/đã làm”; không dùng đại từ làm tên nhân sự |

Đây là mô hình logic, không yêu cầu mỗi dòng thành một dịch vụ. Physical storage có thể bắt đầu với các bảng mission/revisions, task_attempts, provider_attempts, knowledge_records/edges và action_items; dùng lại runs/artifacts và primitive transaction hiện có. Payload JSON phải qua schema typed; các cột quyền, revision, trạng thái và ID được index/ràng buộc riêng. DDL và migration cần thiết kế trong bước triển khai, không được coi bảng generic JSON là lý do bỏ kiểm quan hệ.

SSOT bổ sung entity/fact assertions/resolutions và current projection, có thể bắt đầu bằng repository typed gọn cho một số field sản phẩm/cơ sở. Không cần ontology/CRM toàn diện, nhưng bắt buộc kiểm concurrency/field authority; không lưu SSOT chỉ ở prompt summary hoặc localStorage.

## 3. Hợp đồng lập kế hoạch và giao việc

Ví dụ rút gọn, **chỉ minh họa, không phải request có thể thực thi**:

```json
{
  "example_only": true,
  "execution_allowed": false,
  "mission": "mut-sen-prior-notice",
  "revision": 1,
  "intent": {
    "request_mode": "understand_and_prepare",
    "outcomes": [
      {"id": "who", "question": "Ai có thể nộp thông báo trước?"},
      {"id": "when", "question": "Khi nào phải nộp, và cần gì để xác định hạn riêng?"}
    ],
    "constraints": {"language": "vi", "external_submission": false}
  },
  "tasks": [
    {"id": "research-who", "capability": "export_us.prior_notice.who", "outcomes": ["who"], "depends_on": [], "output": "supported_claims"},
    {"id": "research-when", "capability": "export_us.prior_notice.when", "outcomes": ["when"], "depends_on": [], "output": "conditional_rules"},
    {"id": "build-worksheet", "capability": "artifact.prior_notice_worksheet", "outcomes": ["who", "when"], "depends_on": ["research-who", "research-when"], "output": "worksheet_draft"}
  ],
  "acceptance": ["Hai ý có câu trả lời hoặc gap rõ", "Phiếu có trường điền và căn cứ", "Không chốt deadline khi thiếu input"],
  "grant_id": null
}
```

Task capability là ID được đăng ký, không phải tên hàm hoặc URL do model tự sáng tác. Server kiểm schema, cycle, dependency, scope, output kind, quyền và limits. Nếu một worker không có source phù hợp, trả `gap=no_supporting_source`; task soạn phiếu vẫn có thể tạo khung trống có trạng thái. Nếu parser ra plan không hợp lệ, dừng/hiển thị phần diễn giải đã có; không âm thầm gọi model lần nữa.

Preflight dùng metadata catalog/capability và coverage đã biết để hiển thị giới hạn trước execution grant, không gọi thêm agent. Nếu toàn bộ bước nghiên cứu dự kiến chỉ lặp lại khoảng trống đã biết và không có capability/source bổ sung, không dispatch paid research; trả gap và phương án hỗ trợ hợp lệ. Metadata này không chứng minh nguồn live vẫn còn nguyên; refresh thật chỉ diễn ra trong phạm vi được phép.

Bản giao việc đầy đủ gồm: mục tiêu và task ID, câu hỏi hẹp, input snapshot/ref, phạm vi nghiệp vụ, nguồn/tool được phép, quy tắc suy luận, output schema, tiêu chí kiểm, hạn tài nguyên, các trạng thái cần dừng. Lệnh “nghiên cứu giúp tôi” không đủ làm contract.

## 4. Thực thi LangGraph có giới hạn

Top-level workflow đề xuất:

`resolve_enterprise_and_membership → load_minimal_authorized_SSOT_context → check_prepare_grant_if_model_needed → interpret_and_propose → validate_intent → resolve_outcome_specific_context → choose_template → validate_plan → check_execution_grant → execute_ready_tasks → validate_outcomes → publish_projection_and_fact_candidates`

Mỗi research task đi qua:

`authorized_lookup → applicability_gate → selective_fetch_if_allowed → extract_and_bind → create_findings → task_output_checks → save_result`

- 0.3 dựng DAG từ template/slots đã kiểm. Các nhánh độc lập có thể chạy đồng thời; cùng URL/source version chỉ fetch một lần. Không tạo một agent riêng cho mỗi trích đoạn.
- Dữ liệu lớn nằm ở repository; graph state giữ IDs, revision, trạng thái và kết quả ngắn. Worker không nạp mọi cuộc chat hay mọi tài liệu vào prompt.
- Bộ kiểm quyết định có thể tiếp tục phần nào, thiếu input hay source nào. Không để model tự tuyên bố case đạt yêu cầu.
- Parse/schema là cổng cấu trúc toàn response. Chỉ khi cổng này đạt mới partition và kiểm semantic/căn cứ theo outcome; response hỏng cấu trúc không được salvage bằng đoán chuỗi. Các kết quả độc lập đã kiểm bằng mã/nguồn có thể xuất fallback với origin rõ, không gán công cho response lỗi.
- `thread_id` tiếp tục là execution ID; Mission giữ các execution/revision liên quan ở DB nghiệp vụ. LangGraph checkpoint và mission record không là hai bản ghi cùng quyền quyết định trạng thái.
- Bản ghi tác nghiệp là chuẩn cho dispatch, UI và audit; checkpoint phục vụ tiếp tục tính toán. Side effect phải idempotent và kiểm ledger trước khi chạy.

LangGraph có interrupt/checkpoint để chờ input; node bị interrupt có thể chạy lại từ đầu khi resume. Vì thế không đặt paid call hoặc ghi không idempotent trước một điểm interrupt rồi cho rằng checkpoint tự bảo đảm không lặp. Thiết kế này dùng node boundary và ledger để kiểm điều đó. [LangGraph interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts).

### Trạng thái nhiều tầng

| Lớp | Trạng thái đề nghị |
|---|---|
| Task | planned, waiting_dependency, waiting_input, ready, running, succeeded, partial, blocked_source, failed, cancelled |
| Outcome | unanswered, answered_general, waiting_facts, blocked_source, artifact_ready, satisfied_for_requested_scope |
| Execution | queued, running, waiting_user, completed, completed_partial, failed, cancelled, needs_reconciliation |
| Artifact | draft, needs_input, ready_for_review, reviewed, superseded |
| UserAction | saved, assigned, in_progress, completed; trạng thái gửi/tiếp nhận riêng nếu có thao tác thật |

Các enum cần chốt trong schema triển khai. Không suy trạng thái lớp này từ một trạng thái lớp khác. Report có thể xuất `completed_partial` với một ý tốt và một ý thiếu nguồn; câu trả lời tốt không bị mất vì phần còn lại chưa đủ.

`gap` là một phản hồi minh bạch, không phải điều kiện để outcome requested thành satisfied. Hướng dẫn chung có căn cứ có thể đáp ứng câu hỏi kiến thức chung; câu hỏi áp dụng riêng vẫn `waiting_facts` hoặc `blocked_source` khi thiếu điều kiện. Outcome hỗ trợ hoàn tất không thay trạng thái của câu hỏi gốc.

## 5. Ngân sách, chống chạy lại và khôi phục

**Mức cơ sở đề xuất:** với ba ca đã có mẫu và nguồn, gộp hiểu intent + facts + đề xuất scope trong lượt intake; tận dụng lượt tổng hợp hiện có. Research/lookup/validation/khung trống có thể bằng mã. Mục tiêu là không thêm paid call chỉ để tách vai logic. Đây không phải cam kết mọi yêu cầu luôn chỉ cần hai call: câu hỏi làm rõ, OCR hay nghiên cứu phức tạp phải được đo và có quyền tương ứng.

Có **hai loại grant**, tránh vòng tròn phải có plan mới được hiểu câu hỏi:

- **Prepare grant** có trước lượt interpret dùng mô hình: gắn principal + enterprise_id đã kiểm membership + conversation/message/request/context refs hash + model policy đã chọn bằng luật + ceiling attempt/tokens + thời hạn. Không đòi mission/plan đã tồn tại. Bấm Gửi với thông báo phí cấp quyền cho đúng lượt này; idempotency trả kết quả cũ nếu mất phản hồi.
- **Execution grant** có sau validate plan: gắn principal + enterprise_id + mission/plan/context hash + model policy + số attempt/tokens/nguồn tối đa + thời hạn. Bấm xác nhận nghiên cứu cấp quyền cho kế hoạch này. Worker dùng trong giới hạn đã cấp, không hỏi lại ở mỗi node.

Tổng chi phí hiển thị phải tính cả hai loại; gọi “lập kế hoạch” không khiến nó miễn phí. Quyền gửi dữ liệu được nhớ theo phạm vi khác với quyền chi phí. `no_paid_calls` chặn cả prepare và execution dùng model; lookup/mẫu có sẵn vẫn dùng được. Không tự tạo prepare grant chỉ vì người dùng mở lại trang.

Quy trình cho một paid call:

1. Transaction tạo reservation/ProviderAttempt ở `prepared`, kiểm ngân sách và revision; commit. Mọi đường gọi provider bị cấm khi attempt còn prepared.
2. Compare-and-set sang `dispatching` và commit bền vững **trước network**; sau đó mới gửi một lần, ghi provider request ID nếu có. Crash ở cửa sổ dispatching, dù chưa chứng minh request đã rời máy, phải coi kết quả chưa rõ; không suy record prepared nghĩa là chưa gửi nếu implementation không bảo đảm biên này. SDK retry mặc định phải tắt theo policy không retry có phí. Không giữ khóa DB khi chờ model.
3. Ghi raw result theo chính sách dữ liệu, parse và kiểm; publish output hợp lệ trong transaction. Callback cũ phải khớp operation/attempt/revision.
4. Timeout/restart sau dispatch mà chưa biết kết quả: `outcome_unknown/needs_reconciliation`. Đọc lại trạng thái hoặc đối chiếu được, **không phát lại provider call**.
5. Retry có phí là attempt mới sau thao tác rõ của người dùng và quyền/ngân sách mới phù hợp. Cancel không chứng minh upstream chưa tính phí.

Không thể hứa exactly-once billing nếu provider không có bảo đảm tương ứng. Ledger chỉ giúp hệ thống không tự gửi trùng và minh bạch phần chưa rõ. HTTP retry an toàn cho GET khác với retry gọi mô hình. Browser reload, mở lịch sử và khôi phục UI chỉ đọc; không tự tạo lượt mới.

Mission revision + task rows + queue intent + liên kết conversation phải commit nguyên tử. Nếu start mất phản hồi, cùng idempotency key trả execution cũ; thay key không được biến thành cơ chế tự thử lại. Ràng buộc một active execution cho cùng approved plan revision; cùng task có nhiều attempt chỉ khi policy cho phép.

Idempotency scope gồm tenant/enterprise/principal/operation; payload hash khóa refs/revisions và quyền tương ứng. Trước dispatch/publish kiểm cả fact/source/policy dependency và consent/ACL/membership hiện tại. Correction khi run đang chạy làm phần bị ảnh hưởng needs_revalidation/as-of, không publish như current và không auto paid rerun. Snapshot/artifact dẫn xuất giữ giới hạn quyền của input; materialize/read recheck thu hồi quyền, kể cả trong cùng DN. Chi tiết ở 04.

## 6. Bộ nhớ và reuse

**Hai kho chuẩn:** Enterprise SSOT giữ hiểu biết riêng xuyên nhiệm vụ; Domain Knowledge Library giữ nguồn/claim/rule/template dùng lại trong scope được phép. Finding là bản áp dụng riêng, không được tự promote sang domain. Context resolver đọc dữ kiện hiện hành và lưu snapshot cho mission; fact writer nhận đề xuất, kiểm quyền/provenance/mâu thuẫn rồi resolve theo policy. Thiết kế field states, membership, promotion và refresh ba trục ở 04.

### Sáu cổng trước khi tái sử dụng

1. **Quyền:** record có nằm trong workspace/resource scope được phép không? Lọc trước khi retrieval; kiểm lại khi materialize/read, không chỉ ẩn ở UI.
2. **Ý nghĩa:** nhận định giải đúng outcome nào? Cùng từ “sen” hay cùng thị trường chưa đủ.
3. **Điều kiện áp dụng:** jurisdiction, loại hàng, hoạt động, kênh, thời điểm và ngoại lệ có khớp không? Unknown giữ nguyên là unknown.
4. **Nguồn và phiên bản:** excerpt/hash/locator còn hợp lệ; bản nguồn có đổi hoặc bị thu hồi không? Ngày truy xuất khác ngày hiệu lực.
5. **Mức kiểm:** retrieved/extracted/model-grounded/human-reviewed là các trục khác nhau. Bản candidate không tự thành approved.
6. **Đầu vào/pack:** facts, rule, template và policy có thay đổi không? Nếu có, xác định task/outcome/artifact nào cần tính hoặc đối chiếu lại.

Lưu `ReuseDecision` gồm candidate IDs, accepted/rejected/needs_refresh, lý do và phiên bản context. Exact open bản cũ không gọi AI; dùng claim cho ngữ cảnh mới có thể cần tổng hợp riêng và phải hiển thị chi phí nếu có. Không lấy toàn bộ report cũ làm câu trả lời cho câu mới.

Gate bằng mã chỉ xác nhận predicate/rule/support assertion đã được mô hình hóa và nguồn gốc còn hợp lệ. Không thể dùng similarity, URL chính thức hay hash để tự chứng minh entailment của một nhận định mới. Claim chưa có rule/diễn giải được duyệt phải ở candidate/needs_review hoặc gap; task có thể đề xuất cho người rà, không tự nâng thành approved. `CoverageRecord.no_support_found` luôn có scope/query/source versions, không mang nghĩa không tồn tại yêu cầu.

Lookup 0.3 bắt đầu bằng metadata/ID/từ khóa và SQLite FTS khi phù hợp. Embeddings có thể thêm sau như bước tìm ứng viên; không được thay cổng applicability. Chưa cần vector DB hoặc graph DB riêng. Graph DB chỉ xem xét khi truy vấn nhiều chặng, quy mô, concurrency và vận hành thực tế cho thấy SQLite/Postgres không còn phù hợp; không đặt một ngưỡng số node tùy ý.

### Markdown và graph view

Canonical record là typed data có phiên bản; một exporter tạo các bản đọc:

```text
mission-<id>/rev-<n>/
  mission.md       # người dùng muốn gì, đang chờ gì
  plan.md          # mục tiêu, công việc và phụ thuộc
  answer.vi.md     # trả lời ngắn từng ý, phần chưa đủ
  artifacts/*.md   # khung nhãn, phiếu, checklist có phiên bản
  evidence.json    # refs/locator/hash, không thay bản nguồn
  lineage.json     # nodes/edges đủ để dựng graph view
  manifest.json   # schema/policy/context/claim versions và hash
```

Private export không nằm trong thư mục static công khai. Mở bằng resource API có kiểm quyền. MD sửa tay được nhập như đề xuất revision mới, có diff, provenance và kiểm dữ kiện; không tự ghi ngược vào knowledge record. Một file JSON graph chỉ là projection, không phải lý do bỏ kiểm schema/ACL khi import.

Nếu nguồn đổi: đánh dấu phụ thuộc cần rà, không xóa lịch sử; refresh chỉ các nguồn/task bị ảnh hưởng. Thu hồi quyền phải chặn cả lookup, list, download, graph và bản dịch/cache trong hệ thống. Không tự đưa nhận định có dữ kiện riêng sang thư viện công cộng. Promotion tạo record dùng chung mới, phải chứng minh nó đứng độc lập bằng nguồn được phép và được duyệt; không chỉ xóa private edges để mất dấu nguồn gốc. Lineage gốc vẫn giữ dưới ACL; nếu còn phụ thuộc dữ kiện riêng thì không promote.

Bản export đã tải xuống thiết bị không thể thu hồi vật lý bằng ACL server. Cần ghi scope, version/as-of và cách tra trạng thái hiện tại; chính sách chia sẻ không được hứa kiểm soát được bản sao offline.

Source change chỉ được biết sau khi refetch/so sánh hoặc sự kiện thu hồi được ghi nhận. TTL cache không là bằng chứng nguồn còn hiệu lực; graph không tự theo dõi web. `ReviewEvent` phải bind đúng record version/hash/phạm vi. Review cũ không tự áp vào source/claim vừa đổi.

Nguồn Internet và tài liệu tải lên là dữ liệu không đáng tin về chỉ dẫn: nội dung “hãy bỏ quy tắc/gọi tool khác” không được điều khiển worker. Giữ HTTPS/host/DNS/redirect/size/time guards hiện có; policy cấp tool cụ thể. Query công khai dùng ngữ cảnh tối thiểu, không gửi tên/doanh số/hồ sơ riêng nếu không cần và chưa được phép.

## 7. Hợp đồng MCP đề xuất

Tên và schema sau là thiết kế; tools cũ vẫn giữ nghĩa cho v0.2. MCP là giao diện cho frontend/client, không là bộ điều phối và không cần biến mọi cạnh worker thành một server MCP.

Luồng tích hợp: **Web mobile → BFF cùng origin → MCP facade → MissionService/LangGraph → các capability nội bộ và repositories**. Browser không giữ provider key/MCP bearer nội bộ. Không tạo thêm một hop MCP cho từng hàm worker nếu không có nhu cầu tích hợp thật.

| Tool đề xuất | Đầu vào chính | Đầu ra/chi phí |
|---|---|---|
| `nmate_mission_prepare` | conversation/message ref hoặc message có scope; expected_version; idempotency_key; processing preference; grant nếu cần model | Intent/plan preview hoặc một câu làm rõ; có thể gọi model nên không được coi là free |
| `nmate_mission_start` | mission_id, plan_revision, expected_version, execution_grant_id, idempotency_key | execution_id và trạng thái bền vững; tạo toàn bộ queue/task/link trong server transaction |
| `nmate_mission_get` | mission_id, revision tùy chọn | Projection câu trả lời/outcome/task/artifact và phần thiếu; không gọi model |
| `nmate_mission_supply_input` | mission_id, expected_revision, typed changes/provenance, idempotency_key | Revision mới và phần bị ảnh hưởng; không tự dispatch paid task; text cần model parse đi qua prepare có grant |
| `nmate_mission_cancel` | execution_id, idempotency_key | cancel requested và trạng thái thực, không hứa hoàn phí |
| `nmate_artifact_get` | artifact_id/version | Dùng lại tool đọc; thêm versioned result cho artifact mới, kiểm quyền và lineage |

Khi client cần thao tác SSOT, có thể bổ sung `nmate_enterprise_context_get` (đọc scope/entity được phép), `nmate_enterprise_fact_propose` (thay đổi typed có provenance) và `nmate_enterprise_fact_resolve` (resolution có role/policy/expected version và bằng chứng xác nhận nếu policy yêu cầu). Đây là contracts đề xuất, không tools hiện có. Model không tự resolve để gắn nhãn “doanh nghiệp đã xác nhận”; preference không sửa consent/ngân sách. Các thao tác typed không tự gọi model; text/OCR cần parse bằng model phải qua prepare grant.

Lookup knowledge ban đầu là service nội bộ được ủy quyền. Chỉ công bố `nmate_knowledge_search` ra MCP khi có nhu cầu client thật và đã có ACL/filter contract. Các thao tác expert review/submit ngoài hệ thống chưa nằm trong 0.3; không quảng bá tool chưa có implementation.

Resource có thể cung cấp bản mission JSON/MD, artifact Việt, nguồn gốc và graph projection theo ID. URI là opaque resource reference, không nhận filesystem path tùy ý. Tools trả structured data theo outputSchema, error có mã và phần có thể tiếp tục. MCP phân biệt tools và resources, nhưng quyền/ngân sách nghiệp vụ vẫn do server kiểm; annotation không thay authorization. [MCP tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools), [MCP resources](https://modelcontextprotocol.io/specification/2026-07-28/server/resources).

## 8. Bộ đánh giá cần xây trước khi mở rộng

| Nhóm | Ca kiểm hữu ích và cửa đạt |
|---|---|
| SSOT/personalization | Cùng doanh nghiệp/thành viên ở chat/thiết bị mới dùng đúng facts sau xác thực; không hỏi lại field còn hiệu lực; xung đột/concurrent edit có resolution; đổi DN không rò facts; cập nhật không sửa snapshot cũ |
| Intent | Ba câu gốc và paraphrase giữ đủ từng ý; hỏi nhãn không tự thêm logistics; câu chứng nhận chưa biết tên vẫn có hướng đi; đổi sản phẩm không mang literal “Trà Sen” sang sản phẩm khác |
| Plan | Mọi task trace về outcome/dependency; 0/1/2/n việc hợp lệ; cycle, tool giả, budget vượt, thiếu capability bị từ chối; không thêm chuyên gia chỉ để đủ số |
| Facts | Null/estimate/provenance đúng; tên/hoa thường nguyên vẹn; xóa/đổi field tạo revision; callback cũ không gắn nhầm nhiệm vụ |
| Evidence | Đúng URL/hash/locator chưa đủ nếu nội dung sai ý; nguồn unrelated không tăng outcome coverage; nguồn 403/stale/thiếu/đối nghịch có trạng thái riêng; chưa thấy nguồn không bị diễn giải thành miễn nghĩa vụ |
| Artifact | Khung nhãn có field states/placeholder và companion Việt; worksheet có trường nhập/nguồn, deadline thiếu input thì null; sửa/lưu/mở lại đúng revision; không tự “đã nộp” |
| Reuse | Mở bản cũ 0 call; cùng rule đúng scope dùng lại được; US→EU, facts khác, source/rule đổi phải bị chặn hoặc cần rà; private record không lộ qua search/list/graph/export |
| Lifecycle/chi phí | Hai start trùng trả cùng execution; đóng kết nối trước/sau commit; restart trước/sau dispatch/result; timeout unknown; không auto paid retry từ UI, SDK hoặc graph replay |
| UI | Câu trả lời từng ý nhìn thấy trước CTA; trạng thái nhất quán; mở history về câu trả lời; nháp mở đúng bản; flow 320/390 px không che nội dung, quyền/chi phí đọc được |

Thử bằng fixture deterministic trước. Điều này kiểm hệ thống tuân contract, **không xác nhận** mô hình thật hiểu paraphrase. Batch đánh giá mô hình thật nhỏ, có ngân sách và quyền riêng, chỉ cân nhắc sau khi phần này được triển khai. Chưa có paid evaluation trong lần đề xuất này.

Metrics sản phẩm nên đo: số ý được trả lời/được nói rõ chưa đủ; task liên hệ outcome; vật phẩm dùng được; người dùng tìm lại đúng bản; phần dùng lại qua đủ cổng; số call/chi phí và trợ giúp cần thiết để đạt mục tiêu. Thu baseline thật rồi chốt ngưỡng; không dùng số lượng nguồn hoặc điểm do LLM tự chấm làm chất lượng.

## 9. Phân kỳ và ranh giới thay đổi

| Mốc đề xuất | Gói việc | Điều kiện kết thúc |
|---|---|---|
| **0.3A — SSOT tối thiểu và một lát cắt** | Enterprise identity/membership, entity/fact resolver có provenance/version; Trà Sen hai outcome; IntentSpec, template plan, task ledger, câu trả lời trước; khung nhãn; link SSOT context/mission/artifact | Đúng doanh nghiệp, facts dùng lại được và cập nhật có kiểm; giữ hai ý; nháp đúng hợp đồng và mở lại được; không lặp model khi reload; regression cũ còn đạt |
| **0.3B — đủ ba ca, domain reuse và refresh** | Prior Notice worksheet + rules có nguồn; Bột Sen certification_answer/gap riêng cùng dossier hỗ trợ; domain knowledge records/edges; reuse decisions; source/claim/applicability checks; refresh on-use; MD export | Ba plan khác nhau đúng outcome; không bịa chứng nhận; reuse giữa DN qua đúng scope/rights, không lộ facts/finding; cập nhật nguồn đánh dấu đúng phụ thuộc, không tự paid refresh |
| **0.3C — nghiệm thu với người dùng** | Mobile projection, quyền/trạng thái, failure injection, rubric và test người dùng; tài liệu đồng bộ contract | Người dùng đọc được đáp án, lấy được vật phẩm, biết phần chưa làm và tìm lại đúng bản; cost/recovery rõ; ghi gap còn lại |
| **0.4 — mở sâu nghiên cứu khi có nhu cầu** | Source discovery giới hạn, trích đoạn dài/PDF khi cần, revalidation; worker dùng model độc lập nếu tăng giá trị; review/promotion knowledge | Nguồn mới có provenance và gate; call fan-out trong budget; chất lượng tốt hơn baseline, không chỉ tăng số agent |
| **0.5 — kiểm lõi bằng use case kế tiếp** | Chọn market research hoặc partner discovery, pack mới và artifact riêng; ca giả định ngoài xuất khẩu để thử tách lõi | Thêm domain bằng pack/capability mới; không phải đổi mission/task/storage kernel; không lẫn facts/rules Shipment |

Đây là thứ tự và cổng nghiệm thu, chưa phải cam kết lịch/nhân sự. Không gom cả multi-agent mở, graph DB, tìm web tự do và ba agent sản phẩm vào một lần phát hành.

### Migration giữ được kết quả v0.2

1. Giữ renderer/schema/version các artifact cũ; không tính lại `next_steps` đã lưu. Tạo adapter hiển thị legacy thành kết quả chỉ đọc, không giả có plan/task lịch sử chưa tồn tại.
2. Thêm repository/migration phía sau feature flag. Luồng mới bắt đầu bằng một outcome template Shipment, chưa thay endpoint v0.2 đang chạy.
3. Tái dùng transaction/idempotency/source/translation/worker primitives; tách dần domain khỏi service thay vì viết lại mọi module.
4. Nhập nháp/việc local cũ chỉ qua thao tác có chủ đích và kiểm artifact ownership/version. Không tạo trạng thái “đã giao” hay bổ sung provenance giả cho bản cũ.
5. Đồng bộ FRONTEND/ARCHITECTURE/tool schemas với hành vi mới. Hiện FRONTEND còn chỗ ghi policy 0.2.2 trong khi code là 0.2.3; không mang sai lệch đó vào đặc tả mới.
6. Rollback feature flag dừng start mới, giữ bản đã tạo và đường đọc. Không hủy/xóa knowledge hay artifact để quay về phiên bản trước.

7. Enterprise onboarding/membership và liên kết dữ liệu legacy cần kiểm quyền rõ; không tự nhập các profile/hội thoại cùng tên vào một SSOT. Việc đưa hồ sơ vào SSOT không biến mức xác minh của facts thành cao hơn nguồn thực tế.

8. Central resource authorization phải áp dụng cả đường đọc/list/tool legacy khi triển khai enterprise dùng chung. Không để endpoint v0.2 chỉ kiểm tenant trở thành lối vòng qua enterprise/resource/field ACL mới; dữ liệu legacy chưa ánh xạ quyền giữ scope cũ hoặc bị chặn chia sẻ, không mặc định ai trong tenant cũng đọc được.

Các boundary đề nghị: `intent/`, `planning/`, `orchestration/`, `knowledge/`, `artifacts/`; capability và quy tắc Shipment vẫn ở pack nghiệp vụ. Tên module chỉ là đề xuất; chỉ trích primitive chung khi use case thứ hai thực sự cần.
