# nMate — thiết kế Agent từ mục tiêu đến kết quả có thể sử dụng

**Bản đề xuất 0.3 · 18/10/2026 · chưa triển khai vào ứng dụng.** Tài liệu học từ các vòng review và ba flow giả lập thực tế; không dùng chúng để kết luận chất lượng Claude thật hoặc tính đầy đủ của quy định. Lượt thiết kế này không gọi API mô hình của ứng dụng.

**Quyết định đề xuất:** giữ nền Python, LangGraph, MCP và lưu trữ hiện có; bổ sung một bộ điều phối theo mục tiêu, kế hoạch công việc có kiểu dữ liệu, hợp đồng đầu ra và hai lớp tri thức tích lũy: **Enterprise SSOT** để cá nhân hóa xuyên hội thoại và **Domain Knowledge Library** để dùng lại cho nhiều doanh nghiệp, làm mới khi cần. Giao diện vẫn là một trợ lý; các năng lực chuyên biệt chạy ở phía sau. Số công việc phụ thuộc nhu cầu, không cố định là ba.

## 1. Điều các vòng review đã chỉ ra

| Biểu hiện lặp lại | Nguyên nhân kiến trúc | Thay đổi cần có |
|---|---|---|
| Đổi câu hỏi nhưng vẫn ra IOR/FSVP, Incoterm, chuyên gia; bản mới vẫn còn việc phụ chung | Hệ thống chọn việc từ một checklist chuẩn bị lô hàng, chưa ràng buộc việc với mục tiêu cụ thể | Mỗi việc phải chỉ ra đang giải ý nào, vì sao cần, tạo đầu ra gì; không đủ liên hệ thì loại |
| Có trả lời phần nhãn nhưng người dùng không thấy ngay | Báo cáo đầy đủ và thẻ việc là trung tâm dữ liệu; câu trả lời trực tiếp chưa là đối tượng hạng nhất | Lưu các phần câu trả lời độc lập, render ngắn theo từng ý trước các hành động |
| Nút hứa có nhãn/phiếu, mở ra chỉ là lời nhờ cung cấp thông tin | Chưa có hợp đồng và bộ kiểm riêng cho vật phẩm được tạo | Khung nhãn/phiếu phải có trường, chỗ trống, nguồn và tiêu chí đủ; lời nhờ phải mang tên lời nhờ |
| Bột Sen có nhiều nguồn toàn báo cáo nhưng không có căn cứ về chứng nhận | Đếm tài liệu thay cho đo độ bao phủ của câu hỏi | Liên kết câu hỏi → nhận định → trích đoạn; nêu nguồn phù hợp cho từng ý |
| Phải hỏi lại, lưu riêng, tìm lại lệch vị trí; sửa UI nhiều lần | Trạng thái tác nghiệp, tri thức dùng lại và cách trình bày chưa tách rõ | Một nhiệm vụ bền vững với các phiên bản, việc con và vật phẩm; UI chỉ là một cách đọc trạng thái |
| Lỗi kiểm đầu ra, đứt kết nối, lo chạy AI lần hai | Chưa đủ mô hình trạng thái cho từng công việc và lần gọi mô hình | Lưu trước ý định thực thi; theo dõi từng lần gọi; giữ kết quả hợp lệ một phần và dừng khi chi phí chưa rõ |

Căn cứ chính: [review độc lập ba flow](<../../../REFERENCE_LINKS.md#ref-0405>), [review chủ doanh nghiệp](<../../../REFERENCE_LINKS.md#ref-0406>), [review UX nghiêm khắc](<../../../REFERENCE_LINKS.md#ref-0407>) và [walkthrough mới nhất](<../../../REFERENCE_LINKS.md#ref-0408>). Phân tích nhiều vòng nằm trong [hồ sơ bài học](<research/lessons-and-scenarios.md>).

## 2. Trung tâm là nhiệm vụ của doanh nghiệp

Một **Mission — nhiệm vụ** diễn tả điều người dùng muốn biết, quyết định hoặc tạo ra. Hội thoại là kênh làm rõ và theo dõi nhiệm vụ. Case là ảnh chụp dữ kiện; run là một lượt thực thi; report là một kết quả. Bốn thứ này không thay thế cho Mission.

Các mission cùng dựa vào **SSOT của đúng doanh nghiệp**: hồ sơ, sản phẩm/cơ sở, dữ kiện có nguồn, tài liệu, quyết định và preference có phạm vi. SSOT tồn tại xuyên mission; context snapshot chỉ ghi phiên bản đã dùng cho một lượt. Không lấy một cuộc chat hoặc bản tóm tắt model làm hồ sơ chuẩn duy nhất. Thiết kế chi tiết nằm ở [04 — SSOT doanh nghiệp và tri thức domain](<04_SSOT_doanh_nghiep_va_tri_thuc_domain.md>).

Ví dụ: “Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.”

- **Đối tượng:** đúng sản phẩm và thị trường người dùng nêu; giữ nguyên tên và nguồn gốc dữ kiện.
- **Mục tiêu 1:** hiểu đăng ký cơ sở áp dụng trong những điều kiện nào; biết dữ kiện nào còn thiếu để xem xét riêng cơ sở.
- **Mục tiêu 2:** biết nội dung cần có trên nhãn và có khung nhãn tiếng Anh để điền. Câu gốc đã yêu cầu chuẩn bị, nên đây là đầu ra requested trong kế hoạch, không bắt chọn lại.
- **Chưa được suy ra:** công thức, quy trình, cơ sở được miễn, sản phẩm đã đủ điều kiện xuất hàng.
- **Đầu ra chấp nhận được:** trả lời đủ hai ý, có căn cứ/giới hạn; khung nhãn ghi rõ ô thiếu. Không cần phải có đủ dữ kiện để đưa hướng dẫn chung.

Phải phân biệt bốn tình huống: **chưa rõ người dùng muốn gì**, **thiếu dữ kiện của doanh nghiệp**, **thiếu nguồn**, **chưa tạo được vật phẩm yêu cầu**. Chúng dẫn đến các bước tiếp khác nhau, không cùng chuyển thành “nhờ chuyên gia”.

Outcome người dùng yêu cầu và outcome hỗ trợ phải ghi riêng. Ví dụ dossier Bột Sen giúp nghiên cứu tiếp, nhưng không thay đáp án chứng nhận; tạo dossier xong không khiến câu hỏi chứng nhận được đánh dấu đã giải.

## 3. Kiến trúc đề xuất

```mermaid
flowchart TD
    U[Chủ doanh nghiệp trong chat] --> I[Hiểu mục tiêu và dữ kiện]
    E[Enterprise SSOT có quyền và phiên bản] --> I
    I --> Q{Cần hỏi một điều làm rõ?}
    Q -->|Có, làm thay đổi hướng xử lý| U
    Q -->|Không hoặc có thể trả lời một phần| P[Lập kế hoạch từ năng lực đã đăng ký]
    P --> G[Kiểm phạm vi, phụ thuộc và ngân sách]
    G --> O[Bộ điều phối LangGraph]
    O --> K[Tra kho và kiểm điều kiện dùng lại]
    D[Tri thức domain dùng chung được phép] --> K
    K -->|Còn thiếu| R[Nghiên cứu nguồn phù hợp]
    K -->|Dùng được| V[Kiểm căn cứ và phạm vi áp dụng]
    R --> V
    V --> A[Tạo câu trả lời và vật phẩm]
    A --> C[Kiểm từng mục tiêu và hợp đồng đầu ra]
    C --> M[Lưu phiên bản, nguồn và kết quả]
    M --> UI[Câu trả lời ngắn, việc tiếp theo trong chat]
    UI --> U
    M -.->|Dùng lại ở lượt sau| K
```

Đây là **một bộ điều phối, nhiều năng lực có giới hạn**. Một năng lực có thể là hàm thuần, bộ truy xuất nguồn, mẫu tài liệu hoặc agent dùng mô hình. Không mặc định mỗi ô trong sơ đồ là một lần gọi AI hay một tiến trình độc lập. LangGraph hỗ trợ cả workflow cố định và điều phối worker; lựa chọn áp dụng ở đây là thiết kế cho nMate, dựa trên mức kiểm soát cần giữ. [LangGraph workflows and agents](https://docs.langchain.com/oss/python/langgraph/workflows-agents).

Mọi lần gọi mô hình đều qua quyền và ngân sách: prepare grant giới hạn cho lượt hiểu yêu cầu, rồi execution grant gắn kế hoạch đã kiểm. Không chờ tới sau khi lập kế hoạch mới kiểm quyền cho lượt AI đã dùng để lập kế hoạch. Chi tiết nằm ở đặc tả 02.

### 3.1. Hiểu intent: không chỉ nhận diện từ khóa

Đầu vào gồm lời hiện tại, ngữ cảnh liên quan từ Enterprise SSOT, phạm vi hội thoại đã được phép dùng, dữ kiện có nguồn và nhiệm vụ đang mở. Context resolver chọn đúng doanh nghiệp/entity và các field cần cho mục tiêu; không nạp toàn bộ lịch sử. Đầu ra có cấu trúc:

| Thành phần | Ví dụ / mục đích |
|---|---|
| `request_mode` | tìm hiểu, so sánh, chuẩn bị tài liệu, giải thích bản lưu, cập nhật dữ kiện, yêu cầu hành động ngoài hệ thống |
| `outcomes[]` | các câu hỏi cần giải hoặc vật phẩm cần tạo, giữ liên hệ tới nguyên văn |
| `context_snapshot` | sản phẩm, thị trường, dữ kiện đã biết và dữ kiện chưa biết |
| `constraints` | tiếng Việt, mobile, chỉ nguồn chính thức nếu cần, giới hạn phí, không gửi ra ngoài |
| `ambiguities[]` | điều chưa rõ, tác động nếu hiểu sai, câu hỏi làm rõ có ích |
| `proposed_scope` | điều sẽ làm, điều không có đủ cơ sở để chốt |

Mô hình có thể đề xuất diễn giải ý định; không được tự biến suy luận thành dữ kiện doanh nghiệp. Trường dữ kiện tiếp tục cần nguyên văn/provenance như v0.2. Độ tin cậy do mô hình tự chấm chỉ là tín hiệu điều phối, không phải bằng chứng xác minh.

**Chính sách hỏi lại:** chỉ hỏi khi câu trả lời làm thay đổi đáng kể phạm vi, công cụ hoặc đầu ra. Hỏi một điều quan trọng tại một thời điểm; cho phép “chưa biết”. Không hỏi tên chứng nhận nếu đó chính là điều doanh nghiệp đang tìm hiểu. Có thể trả lời phần đã có căn cứ và đưa mẫu có ô trống trước khi thu thập mọi dữ kiện.

Với câu hỏi rõ, trợ lý phản chiếu ngắn ngay trong chat: “Mình sẽ làm rõ đăng ký cơ sở và chuẩn bị khung nhãn; phần chưa biết sẽ để trống.” Người dùng sửa khi cần, không phải điền một bảng phân tích intent.

### 3.2. Lập kế hoạch bằng hợp đồng kết quả

Mỗi mục tiêu có `done_when` và danh sách đầu ra. Mỗi task phải có `outcome_ids`, năng lực được chọn, đầu vào, phụ thuộc, phạm vi nguồn, giới hạn tài nguyên, cách kiểm kết quả và điều kiện dừng.

Trong 0.3, planner **chọn và điền các mẫu kế hoạch đã kiểm**, server dựng và kiểm DAG không chu trình. Chưa cho mô hình tự tạo mã, thêm tool hoặc sinh một đồ thị thực thi bất kỳ. Khi bài toán ổn định hơn mới mở thêm khả năng phân rã động.

Plan preview phải nói giới hạn nguồn/capability đã biết trước khi người dùng cấp quyền chạy. Nếu kho không phủ câu hỏi và không có đường nghiên cứu bổ sung, không chạy một lượt có phí chỉ để báo lại khoảng trống đã biết; cung cấp phần hỗ trợ được và giữ câu hỏi gốc chưa giải. Lượt dùng mô hình để hiểu câu hỏi, nếu có, vẫn được tính riêng và hiển thị rõ.

Phân biệt **công việc nội bộ** với **việc doanh nghiệp nhìn thấy**. Bên trong có thể có tám bước đọc/kiểm/soạn; bên ngoài chỉ cần một việc rõ nhất để đi tiếp. Một câu hỏi đã được trả lời đầy đủ có thể không cần sinh thêm việc.

### 3.3. Giao nghiên cứu bằng bản giao việc có cấu trúc

Ví dụ giao cho năng lực nhãn:

> Nghiên cứu các mục nội dung nhãn cho phạm vi thực phẩm và thị trường đã xác định; lấy nguồn đúng điều khoản và ngoại lệ. Tạo khung nhãn tiếng Anh với ô thiếu, gắn bản giải thích Việt. Không bịa thành phần/dị nguyên/lượng tịnh, không kết luận nhãn đã được duyệt. Hoàn thành khi từng trường có dữ liệu có nguồn hoặc trạng thái cần bổ sung, và từng hướng dẫn có căn cứ hoặc được đánh dấu chưa đủ nguồn.

Bản giao việc máy đọc được còn chứa phiên bản snapshot/pack, ID mục tiêu/task, danh sách tool được phép, ngân sách, lược đồ kết quả và điều kiện chuyển trả. Worker nhận phần ngữ cảnh cần thiết, không nhận toàn bộ lịch sử hoặc dữ liệu của khách hàng khác. Worker trả kết quả có cấu trúc; không tự ghi “nhiệm vụ đã hoàn tất” hay chuyển công việc cho agent bất kỳ.

Các vai trò logic gồm: **hiểu và lập kế hoạch**, **nghiên cứu**, **đối chiếu khả năng áp dụng**, **tạo vật phẩm**, **kiểm kết quả**. Trong 0.3 nhiều vai được thực hiện bằng mã và dùng chung một lượt mô hình; không dựng năm agent có phí chỉ để đủ vai. Cách chọn độ phức tạp này phù hợp khuyến nghị bắt đầu từ cấu trúc đơn giản trong [Anthropic — Building effective agents](https://www.anthropic.com/engineering/building-effective-agents).

### 3.4. Kiểm chứng và trạng thái hoàn tất

Kiểm theo từng mục tiêu, không chặn toàn bộ báo cáo chỉ vì một phần chưa đạt:

1. Đã trả lời đủ các ý người dùng hỏi chưa?
2. Nhận định có đúng trích đoạn, phiên bản nguồn và phạm vi không? Nguồn chung không đủ để chốt trường hợp riêng.
3. Vật phẩm có đúng loại và trường cần có không? Một lời nhờ không được tính là khung nhãn.
4. Việc tiếp theo giải một thiếu hụt cụ thể hay chỉ lặp lại câu hỏi?
5. Ngôn ngữ và cách trình bày có phù hợp để đọc ngay trong chat không?

Phải parse và kiểm schema toàn response trước khi kiểm riêng từng outcome. Response hỏng cấu trúc không được cứu bằng cách đoán chuỗi hoặc nhặt vài đoạn có vẻ đúng. Chỉ sau khi parse/partition hợp lệ mới lưu phần đạt và ghi gap cho phần thiếu. Kết quả rule-based độc lập đã kiểm có thể giữ như fallback với nguồn gốc rõ, không giả là model đã trả đúng. Không tự gọi mô hình viết lại hoặc nghiên cứu lại sau lỗi. Trong tương lai, vòng sửa có phí chỉ chạy trong quyền thực thi/ngân sách đã được cấp rõ.

**Run thành công ≠ nghiên cứu đủ ≠ vật phẩm đã được duyệt ≠ doanh nghiệp đã làm xong.** Đây phải là các trạng thái độc lập. “Cần chuyên gia” là một điều kiện có lý do; “đang chờ chuyên gia” chỉ xuất hiện khi đã có một lần chuyển ca thật.

## 4. Áp dụng lại đúng ba ca

| Ca | Kế hoạch phù hợp | Đầu ra hữu ích | Điều kiện còn thiếu |
|---|---|---|---|
| **Trà Sen: FDA + nhãn** | Hai nhánh nghiên cứu có thể dùng chung nguồn; đối chiếu từng ý; tạo khung nhãn trong phạm vi requested đã cấp quyền | Hai câu trả lời ngắn; bảng dữ kiện để xem phạm vi đăng ký; khung nhãn tiếng Anh có ô trống và giải thích Việt | Hoạt động/loại hình cơ sở, thành phần, lượng tịnh, thông tin chịu trách nhiệm và dữ kiện nhãn khác |
| **Mứt Sen: ai nộp, khi nào** | Nghiên cứu đúng hai câu hỏi; phiếu người nộp + phương thức + lịch đến + kênh; tính hạn chỉ khi có đủ dữ kiện và rule có nguồn | Câu trả lời ai/khi nào; phiếu điền được; mốc dự kiến có timezone/căn cứ nếu đủ dữ kiện | Người nộp thực tế, phương thức, lịch đến và điều kiện áp dụng; không tự thêm IOR/FSVP thành việc bắt buộc |
| **Bột Sen: chứng nhận gì** | Phân biệt nghĩa vụ pháp lý/yêu cầu người mua/chứng nhận tự nguyện; lập hồ sơ sản phẩm; tìm đúng nguồn nếu phạm vi cho phép | `certification_answer/gap` riêng cho câu hỏi gốc; dossier và ma trận là đầu ra hỗ trợ, chỉ điền nhận định có căn cứ | Công dụng, thành phần/quy trình, claim, kênh/người mua; không bắt biết tên chứng nhận trước |

Đây là kế hoạch sản phẩm, không phải kết luận pháp lý mới. Có thể xem [ba kế hoạch và bản giao việc cụ thể](<03_Ba_ca_tham_chieu_va_hop_dong_cong_viec.md>).

## 5. Lưu Markdown hay graph?

**Dùng đồng thời, với vai trò khác nhau.** Đề xuất 0.3: SQLite giữ bản ghi có kiểu và quan hệ; JSON giữ snapshot có phiên bản; Markdown là bản đọc/xuất từ dữ liệu đó. Chưa cần máy chủ graph riêng.

| Lớp lưu | Nội dung | Dùng lại thế nào |
|---|---|---|
| Nhiệm vụ/tác nghiệp | Intent, kế hoạch, task, lượt chạy, quyết định người dùng, ngân sách | Tiếp tục công việc, không hỏi lại điều đã biết, không chạy lại bước đã hoàn tất |
| Enterprise SSOT | Dữ kiện hiện hành và lịch sử doanh nghiệp/sản phẩm/cơ sở/lô hàng, tài liệu, quyết định, preference có phạm vi | Đọc đúng enterprise/entity và thời điểm; tránh hỏi lại; sửa qua resolver/version, không để model tự ghi đè |
| Domain Knowledge Library | Claim/rule/template/playbook và nguồn được phép dùng chung hoặc theo entitlement | Dùng cho nhiều doanh nghiệp sau kiểm quyền, scope, freshness và khả năng áp dụng; không sao chép finding riêng |
| Nguồn | URL, bản chụp, thời điểm, ngày hiệu lực nếu xác định được, hash, trích đoạn, dịch | Đọc lại và đối chiếu, không phải tải/lấy dịch lại mọi lần |
| Nhận định có điều kiện | Nội dung, phạm vi, nguồn hỗ trợ/phản bác, trạng thái duyệt và hiệu lực | Tái sử dụng sau kiểm quyền, độ mới, phạm vi và điều kiện áp dụng |
| Vật phẩm | Nhãn/phiếu/checklist/trả lời; trường có dữ liệu và ô thiếu | Tiếp tục đúng bản, xuất MD và các định dạng khác, kiểm phụ thuộc khi dữ kiện thay đổi |
| Bài học vận hành | Lỗi đã quan sát, quy tắc/mẫu sửa, ca kiểm thử và phiên bản pack | Cải thiện hệ thống có kiểm soát, không tự biến câu trả lời cũ thành sự thật |

SSOT cần enterprise identity/membership thực sự; profile trình duyệt của v0.2 chưa đáp ứng xuyên thiết bị/người dùng. Tách assertion, resolution và giá trị hiện hành theo từng field, giữ valid-time/provenance; dữ kiện doanh nghiệp xác nhận không tự thành dữ kiện đã xác minh bên ngoài. Thông tin một lô hoặc một SKU không tự áp cho lô/SKU khác.

Refresh có ba phép kiểm riêng: đã kiểm lại **nguồn**, nhận định còn được **review trong scope/thời gian**, và có **áp dụng với doanh nghiệp/ngày mục tiêu** hay không. Refresh on-use hoặc theo sự kiện được quan sát; nếu cần model có phí phải có grant. Khi thay đổi, chỉ đánh dấu các phụ thuộc bị ảnh hưởng, giữ snapshot báo cáo cũ. Chi tiết và cửa nghiệm thu ở tài liệu 04.

Cần phân biệt **execution graph** — bước nào chạy trước/sau — với **knowledge graph** — nhận định nào dựa nguồn nào và áp dụng trong điều kiện nào. LangGraph checkpoint phục vụ trạng thái thực thi; kho tri thức dùng lại phải được thiết kế thêm. Tài liệu LangGraph cũng phân biệt [checkpointer theo thread và store xuyên thread](https://docs.langchain.com/oss/python/langgraph/persistence).

Ví dụ quan hệ tri thức:

```mermaid
flowchart LR
    Q[Ý hỏi: ai nộp thông báo trước] --> F[Nhận định có điều kiện]
    F --> E[Trích đoạn nguồn đúng phiên bản]
    F --> S[Phạm vi và điều kiện áp dụng]
    F --> A[Phiếu thông báo của lô hàng]
    A --> D[Snapshot dữ kiện riêng]
    E --> V[URL, hash, thời điểm và bản gốc]
```

Một quy tắc chung có thể dùng cho Trà Sen và Mứt Sen khi cùng phạm vi; người nộp, lịch đến, công thức hay kết luận riêng không được sao chép sang sản phẩm khác. Similarity hoặc cùng tên mặt hàng chỉ giúp tìm ứng viên; không cho phép tự áp dụng.

Khi nguồn/dữ kiện/pack thay đổi, đánh dấu **cần đối chiếu lại** các kết quả phụ thuộc. Giữ bản cũ để giải thích lịch sử; không âm thầm sửa báo cáo cũ. Một bản Markdown sửa tay là bản góp ý hoặc phiên bản tài liệu mới, không tự ghi đè tri thức đã kiểm.

Việc đánh dấu thay đổi chỉ xảy ra sau khi hệ thống quan sát được phiên bản nguồn mới hoặc nhận sự kiện thu hồi; graph không tự biết Internet đã đổi. Gate bằng mã kiểm được điều kiện/rule/claim đã mô hình hóa, không tự xác nhận một diễn giải pháp lý mới chỉ từ metadata và hash.

## 6. Trải nghiệm trợ lý được tạo từ kiến trúc này

Mỗi kết quả trong chat có bốn lớp: **trả lời ngắn theo từng ý → phần chưa rõ → việc hữu ích nhất → tài liệu/nguồn chi tiết mở khi cần**. Không giấu câu trả lời chính. Không đưa toàn bộ DAG, worker, model routing hay biểu mẫu kỹ thuật ra trước người dùng.

Khi thiếu dữ kiện, hiện một câu hỏi hoặc một khung điền gọn ngay trong chat; có lựa chọn chưa biết. Nút phải diễn tả đầu ra thật: “Mở khung nhãn”, “Điền phiếu thông báo”, “Bổ sung hồ sơ sản phẩm”. Lưu việc và mở lịch sử không gọi AI; giải thích lại bằng mô hình, nếu có, là thao tác khác có hiển thị phí.

Thẻ hiển thị lấy từ cùng trạng thái server với nhiệm vụ và artifact, tránh báo cáo đã lỗi mà UI vẫn ghi đang chạy. Mở lại về câu trả lời hoặc vật phẩm được chọn, không về cuối thread. Nội dung Việt trước, bản gốc nguồn mở theo lựa chọn.

## 7. Học và mở rộng cho MVP tiếp theo

Một **gói nghiệp vụ có phiên bản** gồm phạm vi, schema dữ kiện, các loại mục tiêu/task, mẫu kế hoạch, nguồn/rule, hợp đồng artifact, từ điển Việt và bộ đánh giá. Bộ điều phối, lưu trữ, ngân sách, quyền và MCP dùng chung.

Registry hiện đã dự kiến `shipment_readiness`, `market_research`, `partner_discovery`. Gói thị trường phải tạo bảng so sánh có tiêu chí/số liệu/phạm vi thời gian; gói đối tác phải tạo shortlist có nguồn, vai trò, mức kiểm chứng và bước xác minh. Không mặc định tái sử dụng checklist FDA cho hai bài toán đó. Thử thêm một use case ngoài xuất khẩu để kiểm lõi có thật sự tách nghiệp vụ; đây là ca đánh giá thiết kế, chưa phải cam kết phạm vi sản phẩm.

Ba flow Trà Sen/Mứt Sen/Bột Sen đều là các nhiệm vụ trong gói Shipment, không phải ba agent sản phẩm mới. Nhiều vai nghiên cứu bên dưới có thể cùng phục vụ một nhiệm vụ; số agent/worker là lựa chọn thực thi, không phải cấu trúc điều hướng người dùng.

Vòng học: **review thật → phân loại lỗi → sửa schema/pack/template/rule → thêm ca hồi quy → kiểm và phát hành phiên bản**. Không tự fine-tune, sửa system prompt hay đưa dữ liệu riêng sang kho chung chỉ vì một agent nói đã học được.

Tách bốn loại bộ nhớ: **trải nghiệm** (đã làm gì trong nhiệm vụ), **tri thức** (nhận định/nguồn có điều kiện), **quy trình** (mẫu kế hoạch và hợp đồng đã kiểm), **tùy chọn người dùng** (ngôn ngữ/quyền/giới hạn). Phản hồi “nháp không dùng được” tạo một đề xuất sửa quy trình và ca kiểm; nó không tự biến thành một quy định mới trong kho tri thức.

## 8. Phạm vi nên chốt cho 0.3

1. Enterprise identity/membership và SSOT tối thiểu; Mission/Outcome/Plan/Task có kiểu đọc đúng context revision; chọn mẫu kế hoạch thay cho checklist ba việc cố định.
2. Ba đầu ra dùng được: khung nhãn, phiếu thông báo trước, checklist/ma trận câu hỏi chứng nhận chưa kết luận.
3. Kho domain nguồn/nhận định/template có điều kiện, lưu quan hệ phụ thuộc; xuất MD; lookup/reuse/refresh có kiểm quyền và điều kiện áp dụng; không tự đưa facts/finding riêng lên kho chung.
4. Trạng thái từng mục tiêu, sổ lần gọi có phí và khôi phục không tự gọi lại.
5. Chat đọc được ngay và mở lại đúng phần; kiểm các biến thể câu hỏi và hành vi dùng lại.

Phân kỳ và tiêu chí nghiệm thu trong [đặc tả 0.3](<02_Dac_ta_MVP_0_3_va_lo_trinh.md>). Đây là đề xuất refactor từng phần trên nền hiện có; không yêu cầu thay toàn bộ app hoặc dựng một hệ thống multi-agent mở trước khi ba ca này tạo được kết quả hữu ích.
