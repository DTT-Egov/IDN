# Rà hiện trạng kiến trúc nMate cho đề xuất agent v0.3

Ngày rà: 18/10/2026. Đây là rà mã nguồn tĩnh và đề xuất, không phải kết quả chạy hệ thống hay xác nhận chất lượng nghiệp vụ.

Phạm vi: `nmate-backend-v0.2/src/nmate`, `ARCHITECTURE.txt`, `FRONTEND.md`, các phần liên quan của `nmate-mvp-v0.1/src/assistant.js`, `live-research.js`, `app.js`. Đã tìm `AGENTS.md` tại các thư mục tổ tiên và trong workspace bằng danh sách tên file; không tìm thấy. Không đọc `.env`, khóa, DB, checkpoint, phiên hoặc dữ liệu runtime; không gọi provider, model, MCP, nguồn ngoài; không sửa source hay server.

## Kết luận kiến trúc

Nền hiện có đã giải quyết tốt một vấn đề hẹp: thu thập dữ kiện có nguồn gốc từ lời người dùng, xác nhận một lần, tạo snapshot nghiên cứu Shipment, chạy pipeline có giới hạn và xuất báo cáo nháp bất biến. Không nên viết lại nền này chỉ vì muốn “có agent”. Điểm thiếu là lớp **hiểu mục tiêu → lập kế hoạch có phiên bản → chia nhiệm vụ nghiên cứu → kiểm bằng chứng → tái sử dụng tri thức** phía trên nó.

LangGraph hiện là graph thực thi của một lượt Shipment; chưa phải graph tri thức hay hệ điều phối nhiều research agent. “Việc tiếp theo” là các hành động chuẩn bị cho con người được tính bằng policy, chưa phải task của research agents. Các khác biệt này thấy trực tiếp trong state và cạnh graph [S01], schema `NextStep` [S02], và registry chỉ có một agent khả dụng [S03].

## Những gì đang thực sự hoạt động

### Intake là trình tích lũy dữ kiện, chưa là bộ lập kế hoạch

- Mỗi message dùng mode do server chọn: `intake` hoặc `artifact_answer`; model trả structured output một lần, không có quyền chọn tool. Intake có `reply`, `fact_patch`, `next_question`, readiness gợi ý và phạm vi [S04].
- Đề xuất được cộng dồn từ `pending_proposal` hoặc `draft`, kiểm trích dẫn nguyên văn trong message mới, kiểm giá trị literal và kiểu số. Trường có `message_id`, `source_quote`, `certainty`, `confirmed`; xác nhận lưu không biến `estimate` thành dữ kiện đã kiểm chứng [S05].
- Có tối đa hai lần làm rõ; readiness thực do server tính từ tên sản phẩm + câu hỏi + không còn đề xuất chờ + phạm vi được hỗ trợ. `confirm` chỉ áp pending thành draft, không khởi chạy nghiên cứu [S06].
- `research_case` tạo case và liên kết vào hội thoại trong cùng transaction, giữ `pending_research_launch` và replay response cũ. Frontend sau đó mới gọi MCP start. Đây là nền tốt cho thao tác nhiều bước có thể bị mất phản hồi [S07].
- Mode giải thích báo cáo lấy đúng artifact, case/version và snapshot của run, loại draft hiện tại khỏi context. Nó phân biệt nguồn quy định (`evidence_ids`) với dữ kiện tự khai (`fact_fields`) và việc đã có (`canonical_step_ids`) [S08].

**Hệ quả:** giữ cơ chế intake này làm ranh giới dữ kiện. Bổ sung `IntentSpec` riêng cho mục tiêu, phạm vi, đầu ra mong muốn, ràng buộc và tiêu chí hoàn thành; không nhét kế hoạch công việc vào `question` hay `fact_patch`.

### Graph, checkpoint và worker

State Shipment chỉ chứa `case`, `question`, `unsupported_reason`, `source_batch`, `report`, `model_input_audit`. Graph có nhánh ngoài phạm vi và chuỗi `fetch_sources → assess_preparation → summarize_with_model? → validate_report`; không có task graph, dependency, child run hay cơ chế phân công researcher [S01].

Worker đã có factory dispatch theo `agent_kind`, guard, heartbeat lease, timeout và progress theo node. `run_id` làm LangGraph `thread_id`, lấy lại state từ checkpoint, và chỉ `Store.finish` xuất artifact [S09]. Checkpoint SQLite tách DB nghiệp vụ; startup đánh dấu lượt dở dang gián đoạn, không tự chạy lại AI có thể đã tính phí [S10].

**Hệ quả:** tái sử dụng run lifecycle; thêm parent plan và child task lifecycle. Khi bổ sung thực thi song song, phải định nghĩa rõ task nào đã nhận kết quả, task nào chưa dispatch, và task nào có model call không rõ kết quả. Checkpoint không thay sổ nhiệm vụ hay sổ chi phí.

### Câu hỏi, policy và danh sách hành động

`_ordered_question_topics` dò regex năm nhóm: đăng ký FDA, nhãn, thông báo trước, chứng nhận, hỏi cước; thứ tự là vị trí xuất hiện trong câu hỏi. `_tasks` dùng danh mục action tĩnh, ưu tiên tối đa ba topic/action. Không có suy luận dependency, nhóm nhiệm vụ theo kỹ năng hay chiến lược nghiên cứu [S11].

Điểm tốt là policy `0.2.3` gắn với báo cáo; schema kiểm topic và câu trả lời cùng thứ tự, action ID thuộc danh mục, `owner_role` và `done_when` có nội dung, evidence ID thuộc report. Báo cáo `0.2.2` giữ luật cũ thay vì bị tính lại [S12]. Model chỉ được tổng hợp từ danh sách chuẩn, không được tự thêm việc; summary thiếu topic hoặc tạo danh sách cạnh tranh dùng nhận định rule đã kiểm, có `summary_origin` rõ [S13].

**Hệ quả:** canonical actions nên tiếp tục là policy trình bày/chuẩn bị cho người dùng. Research task graph là một cấu trúc riêng, có thể có nhiều task bên dưới một action và nhiều task dùng chung một nguồn.

### Bằng chứng, nguồn và bản dịch

Provider hiện fetch toàn bộ chín URL trong catalog cố định; URL bị ràng buộc HTTPS/host/port, DNS phải public, redirect/bytes/time/connections có giới hạn, guard chạy trước request và trong lúc đọc. Đây là adapter nguồn hữu ích, chưa phải capability web research mở hoặc nguồn được chọn theo task [S14].

`SourceDocument` giữ text snapshot và hash; `Evidence` có URL, cơ quan, thời điểm lấy, trích đoạn, locator, hash và trạng thái `candidate`. Bản dịch phải khớp hash của đúng excerpt; model không được sửa bản gốc. Sidecar cho báo cáo cũ chỉ thêm view dịch theo artifact/hash, không viết lại report [S15]. Các câu trả lời theo topic được gate bằng passage thực có trong nguồn, dùng `available/partial/unavailable`; đây là cơ chế nên nhân rộng [S16].

**Hệ quả:** đưa primitive nguồn/bằng chứng/bản dịch ra lớp dùng chung sau khi có agent thứ hai thật sự cần chúng. Tri thức tái sử dụng phải có lineage về source snapshot và phạm vi áp dụng; không lấy summary cũ làm sự thật hoặc coi `candidate` là đã duyệt.

### Lưu bền, idempotency, lịch sử và tenant

- Store dùng SQLite WAL, transaction `BEGIN IMMEDIATE`; start bind idempotency với payload hash, một active run mỗi case, lưu snapshot + question + routing decision tại thời điểm tạo [S17].
- `finish` kiểm lại cancel, consent và case version trong cùng transaction với ghi artifact, hash và terminal state; artifact có unique `run_id`. Đọc artifact chỉ thêm cờ `stale` từ version hiện tại [S18].
- Chat reserve ghi trước network call và commit kết quả + dữ kiện sau validation; replay request đã hoàn tất trả response cũ; version conflict ngăn ghi đè; không giữ transaction trong lúc model chạy [S19].
- Conversation đọc theo `(id, tenant, owner)`. Case/run/artifact đọc theo tenant; local profile tạo tenant và subject riêng qua cookie thiết bị được ký, console có principal riêng [S20]. Đây là cách ly phù hợp mô hình local hiện tại, **chưa đủ đặc tả** cho tổ chức có nhiều subject chung tenant: cần policy quyền theo workspace/project/resource trước khi mở rộng chia sẻ.
- Lịch sử có `research_links` gắn sản phẩm, case/version, câu hỏi, run/artifact; frontend render đúng artifact. “Lưu việc” và “lưu bản nháp” hiện là localStorage theo profile, có tham chiếu artifact/hash và `not_sent`; chưa là backend task execution hay expert review [S21].

**Lưu ý về “immutable case”:** endpoint thay case vẫn cập nhật body/version hiện tại; snapshot đã dùng nằm trong run, artifact không bị viết lại [S22]. Nếu v0.3 cần kho revision độc lập trước cả khi chạy, phải thêm `CaseRevision` append-only; không mô tả bảng `cases` hiện tại là toàn bộ lịch sử revision.

## Năm khoảng trống cấu trúc cần giải quyết

| Phát hiện đã thấy trong mã | Nguyên nhân cấu trúc | Kiến trúc đích có giới hạn | Phần cần giữ |
|---|---|---|---|
| Intake trích facts, một câu hỏi; readiness chỉ tên + question; topic dựa năm regex [S04][S06][S11]. | Chưa có hợp đồng mục tiêu/đầu ra/tiêu chí hoàn thành độc lập. | `IntentSpec` có version, `goal`, `deliverable`, `constraints`, `unknowns`, `acceptance_criteria`; server chọn capability và hỏi khi thiếu dữ kiện ảnh hưởng kế hoạch. | Typed facts, nguyên văn provenance, pending/confirm. |
| Một graph Shipment tuyến tính; registry có market/partner planned [S01][S03]. | Worker nhận run của một loại; chưa có parent plan và child tasks. | `ResearchPlan` + `ResearchTask` có dependency, input refs, expected output, budget, source policy, status và attempt record; executor gọi adapter chuyên biệt. | Queue, lease, cancellation, checkpoint, terminal publication. |
| `next_steps` là tối đa ba canonical actions; tác vụ lưu UI chỉ ở thiết bị [S02][S11][S21]. | Một khái niệm “việc” đang phục vụ trình bày, chưa mô hình hóa công việc nghiên cứu và việc con người theo dõi. | Tách `ResearchTask` thực thi, `ActionRecommendation` trong report, và `UserTask` có bằng chứng hoàn thành/review. Mọi quan hệ dùng ID có nguồn. | Action IDs, owner role, done_when, bảo toàn policy lịch sử. |
| Mỗi run fetch cả catalog; source snapshot ở graph/report; không thấy kho tri thức/retrieval dùng chung trong module đã rà [S01][S14][S17]. | Lưu chứng cứ để audit một run khác với index để tìm và tái dùng theo phạm vi/freshness. | `SourceSnapshot`, `EvidenceRecord`, `ResearchNote` versioned; retrieval lọc quyền, market/product/topic, source freshness và policy version; ghi lý do reuse/refetch. MD là view/export có manifest IDs/hash, index có thể bắt đầu bằng SQLite. | Hash, passage locator, source failure, candidate status, dịch bám nguyên bản. |
| `Store.start`, scope check, artifact type và factory mặc định còn gắn Shipment; MCP chỉ năm tools [S03][S17][S18][S23]. | Điểm mở rộng đã có nhưng metadata, policy và lifecycle còn cùng nơi. | `AgentCapability`/workflow definition gồm input/output schema, scope validator, source policy, budget policy, factory và artifact type. Tool mới gọi service chung qua hợp đồng có version. | BFF/MCP adapter mỏng; quyền không lấy từ arguments; tool Shipment cũ giữ nghĩa. |

Các dòng trên là hạn chế so với mục tiêu mới, không chứng minh các cơ chế hẹp hiện tại “sai”. Không có dữ liệu pilot hoặc replay trong lần rà này để kết luận chất lượng intent, luật nguồn hay chi phí thực tế.

Có một dấu vết refactor cụ thể cần đưa vào bộ ca hồi quy: câu trả lời rule cho topic đăng ký đang chứa literal “tên trà sen hoặc quy mô lô thử không đủ để kết luận”, trong khi hàm chỉ nhận `question` và `evidence`, không nhận sản phẩm. Vì vậy câu này có thể xuất hiện cho sản phẩm khác. Đây là ví dụ dữ kiện từ một ca được đưa vào template dùng chung, cần tách ví dụ minh họa khỏi domain policy, không phải lý do viết lại graph. Xem [graph.py:366](<../../../../REFERENCE_LINKS.md#ref-0409>).

## Năm thứ nên tái sử dụng nguyên tắc và kiểm thử hiện có

1. **Reservation + idempotency + optimistic versioning:** dùng lại cho plan creation, task dispatch và review mutation; payload hash phải chứa cả plan/task revision và policy đã chọn [S17][S19].
2. **Snapshot bất biến và publication có guard:** child task đọc input refs đã khóa; publish report chỉ khi các kết quả hợp lệ gắn đúng revision; không sửa artifact cũ [S18].
3. **Provenance của dữ kiện:** giữ nguồn từ người dùng riêng với evidence bên ngoài, uncertainty không bị xác nhận lưu xóa mất [S05][S08].
4. **Source/evidence/translation binding:** dùng hash + locator + trạng thái coverage; giữ nguồn lỗi và không dịch bù nội dung chưa có [S14][S15][S16].
5. **Worker lifecycle và transport mỏng:** progress thật, timeout/cancel, không dispatch AI khi đọc lịch sử, BFF/MCP giữ credential ở server [S07][S09][S23].

## Ranh giới module đề xuất

Đây là tên và trách nhiệm đề nghị, chưa tạo module hoặc thay source.

| Ranh giới | Thay đổi đề nghị | Điểm tiếp giáp hiện tại | Điều không được nhập nhằng |
|---|---|---|---|
| `conversations/` | Giữ facts; adapter gọi intent service, trả DTO plan preview khi có. | `ConversationService.message`, `research_case`. | Chat reply không là lệnh gọi tool; xác nhận fact khác cấp quyền thực thi. |
| `intent/` mới | Chuẩn hóa mục tiêu và tiêu chí hoàn thành; phát hiện mâu thuẫn/thiếu dữ kiện; capability match. | `IntakeSynthesis`, registry. | Không dùng model ID như năng lực agent; confidence không thay bằng chứng. |
| `planning/` mới | Plan revision, task DAG, constraints/budget, policy validation, review/replan có delta. | Trước `ResearchService.start`. | Plan cho researcher khác `next_steps` cho doanh nghiệp. |
| `orchestration/` mới hoặc tách dần từ `service.py` | Parent/child run, scheduling, attempts, cancellation fan-out, aggregation gate. | Worker/factory/guard hiện có. | DB task ledger quyết định đã dispatch; checkpoint không tự chứng minh side effect an toàn để lặp. |
| `knowledge/` mới | Snapshot/evidence/note catalog, quyền/freshness/applicability, reuse decision, MD export/import có manifest. | SourceBatch, Evidence, artifact hash. | Không đưa private case facts vào thư viện chia sẻ mặc định; note không tự thành nguồn đã duyệt. |
| `agents/shipment/` | Giữ domain scope, assessment và canonical policy; triển khai researcher adapter đầu tiên. | `build_graph`, `_tasks`, `_topic_answers`. | Không tổng quát hóa quy tắc Shipment thành luật chung cho market/partner. |
| `agents/registry.py` | Nâng metadata thành capability definitions khi cần agent thứ hai. | `graph_factories`, hardcoded start/finish. | Planned không công bố như tool khả dụng. |
| `store.py` + repositories mới | Giữ transactional primitives; thêm plan/task/evidence tables/revisions qua migration có kiểm. | `start`, `finish`, conversations store. | Quyền tenant/subject/resource tập trung; facts, knowledge và attempt state có retention riêng. |
| `mcp_server.py` / `app.py` | Giữ adapter; thêm các read tools cho plan/task/knowledge và start tool có input rõ khi workflow sẵn sàng. | Năm tools và REST/BFF hiện tại. | Không mở generic shell/web/write tool cho model chỉ để có tính “agent”. |
| Frontend assistant/live | View plan ngắn, task progress thật, reuse/source freshness, review lineage; render report lịch sử như cũ. | `startResearch`, `watchRun`, `renderArtifact`. | Local “đã lưu việc” không hiển thị như backend “đã giao/đã làm”. |

Ưu tiên xây dọc một luồng Shipment có `IntentSpec → PlanRevision → 2–3 ResearchTask → Evidence → Report`, dùng lại lifecycle cũ. Chỉ thêm market/partner sau khi chúng có input/output và source policy riêng. Bắt đầu index tri thức bằng storage hiện tại đủ để kiểm reuse; chỉ thêm graph database khi quan hệ và truy vấn thực tế chứng minh cần. LangGraph, MD và knowledge graph có ba vai trò khác nhau: điều phối thực thi, nội dung có thể đọc/xuất, quan hệ tri thức có provenance.

## Điểm tài liệu lệch mã cần xử lý khi viết spec v0.3

`FRONTEND.md` vẫn mô tả policy mới là `0.2.2` và expert review luôn cuối ở phần live research; mã hiện đặt `NEXT_STEPS_POLICY_VERSION = "0.2.3"`, ưu tiên topic và có thể ba topic actions không có review. Tài liệu cũng chưa liệt kê `/research-case` trong bảng REST ban đầu, dù endpoint và frontend đã dùng. Khi thiết kế dựa hiện trạng, lấy contract/source đã kiểm làm mốc rồi cập nhật tài liệu, không giả định hành vi `0.2.2` còn là duy nhất [S12][S24].

## Nguồn mã đã kiểm, đường dẫn tuyệt đối và dòng bắt đầu

Các link trỏ đúng dòng đã đọc; mô tả bên cạnh ghi phạm vi phần liên quan. Không link tới DB/runtime.

- [S01 — ShipmentState và graph thực thi](<../../../../REFERENCE_LINKS.md#ref-0410>): state 48–54, topology 864–882.
- [S02 — NextStep](<../../../../REFERENCE_LINKS.md#ref-0411>): 94–111; không có task status/dependency/attempt.
- [S03 — registry](<../../../../REFERENCE_LINKS.md#ref-0412>): 14–18; factory chỉ Shipment tại `service.py:31`.
- [S04 — schema intake](<../../../../REFERENCE_LINKS.md#ref-0413>): 171–189; server chọn mode/schema ở `conversations/service.py:466` và 495–505.
- [S05 — proposal grounding](<../../../../REFERENCE_LINKS.md#ref-0414>): 343–378; metadata trường tại `conversations/models.py:22`.
- [S06 — readiness server](<../../../../REFERENCE_LINKS.md#ref-0415>): 40–42, xác nhận 260–289; giới hạn làm rõ `conversations/service.py:464`.
- [S07 — atomic launch intent](<../../../../REFERENCE_LINKS.md#ref-0416>): 354–411; frontend dispatch tại `assistant.js:110` (110–134).
- [S08 — đúng artifact và phân biệt căn cứ](<../../../../REFERENCE_LINKS.md#ref-0417>): 444–489, guards 514–531.
- [S09 — worker và checkpoint](<../../../../REFERENCE_LINKS.md#ref-0418>): 77–144.
- [S10 — startup/checkpointer](<../../../../REFERENCE_LINKS.md#ref-0419>): 47–53; interruption tại `store.py:167`.
- [S11 — topic regex và action policy](<../../../../REFERENCE_LINKS.md#ref-0420>): 205–220, `_tasks` 227–334.
- [S12 — policy version và report guards](<../../../../REFERENCE_LINKS.md#ref-0421>): 13–20, 280–327.
- [S13 — model synthesis không tạo plan mới](<../../../../REFERENCE_LINKS.md#ref-0422>): 736–775, kiểm/fallback summary 782–850.
- [S14 — source policy](<../../../../REFERENCE_LINKS.md#ref-0423>): 195–222, provider bounds 272–289, fetch 292–358; catalog bắt đầu dòng 40.
- [S15 — hashes và dịch](<../../../../REFERENCE_LINKS.md#ref-0424>): 145–213; binding/sidecar tại `translations.py:256` (256–315); API sidecar `app.py:224`.
- [S16 — source-gated topic answers](<../../../../REFERENCE_LINKS.md#ref-0425>): 346–436; schema coverage `models.py:103`.
- [S17 — transaction và start](<../../../../REFERENCE_LINKS.md#ref-0426>): 59–74; start 226–269; tables 34–51.
- [S18 — atomic publish và stale](<../../../../REFERENCE_LINKS.md#ref-0427>): 343–392.
- [S19 — chat reservation/replay/commit](<../../../../REFERENCE_LINKS.md#ref-0428>): 182–218, 243–258.
- [S20 — owner isolation](<../../../../REFERENCE_LINKS.md#ref-0429>): 74–78; case tenant scope `store.py:76`, profile principal `auth.py:45`, console principal `auth.py:19`.
- [S21 — local task/draft](<../../../../REFERENCE_LINKS.md#ref-0430>): 99–124; artifact link render `assistant.js:140`; UI task form `assistant.js:148`.
- [S22 — current case replace](<../../../../REFERENCE_LINKS.md#ref-0431>): 203–215; snapshot lưu run 255–262.
- [S23 — năm MCP tools](<../../../../REFERENCE_LINKS.md#ref-0432>): 12–15, 38–79; không có plan/task/knowledge tool.
- [S24 — tài liệu policy live cũ](<../../../../REFERENCE_LINKS.md#ref-0433>): 80, 95; endpoint thực `app.py:219`, frontend `assistant.js:127`.
- [S25 — mô tả kiến trúc và giới hạn được công bố](<../../../../REFERENCE_LINKS.md#ref-0434>): 47–61.

[S01]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:48>
[S02]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/models.py:94>
[S03]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/registry.py:14>
[S04]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/models.py:171>
[S05]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/service.py:343>
[S06]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/store.py:40>
[S07]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/store.py:354>
[S08]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/service.py:444>
[S09]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/service.py:77>
[S10]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/app.py:47>
[S11]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:205>
[S12]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/models.py:13>
[S13]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:736>
[S14]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/sources.py:195>
[S15]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/models.py:145>
[S16]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:346>
[S17]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/store.py:59>
[S18]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/store.py:343>
[S19]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/store.py:182>
[S20]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/conversations/store.py:74>
[S21]: <C:/Enterprise AI/app/nmate-mvp-v0.1/src/app.js:99>
[S22]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/store.py:203>
[S23]: <C:/Enterprise AI/app/nmate-backend-v0.2/src/nmate/mcp_server.py:12>
[S24]: <C:/Enterprise AI/app/nmate-backend-v0.2/FRONTEND.md:80>
[S25]: <C:/Enterprise AI/app/nmate-backend-v0.2/ARCHITECTURE.txt:47>
