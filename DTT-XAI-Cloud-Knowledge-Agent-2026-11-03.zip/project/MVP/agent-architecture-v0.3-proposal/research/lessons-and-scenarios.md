# Bài học nhiều vòng review và ca tham chiếu cho agent v0.3

Ngày tổng hợp: 18/10/2026. Phạm vi: phân tích sản phẩm từ tài liệu đã có; không thử app, không gọi mô hình/provider, không nghiên cứu pháp luật mới. Các quy tắc FDA/Prior Notice được nhắc dưới đây chỉ là nội dung các lượt kiểm đã ghi nhận, chưa được kiểm lại tính hiện hành. Đề xuất kiến trúc và tiêu chí nghiệm thu là suy luận thiết kế, không phải bằng chứng sản phẩm hiện tại đã đạt.

## 1. Kết luận để quyết định kiến trúc

Vấn đề lặp lại không chỉ là người dùng phải cuộn nhiều. Hệ thống nhiều lần hoàn tất một **run nghiên cứu**, lưu được một **báo cáo**, sinh được **việc**, nhưng chưa định nghĩa và kiểm tra được **kết quả hữu ích mà người dùng đang cần**. Vì thế có thể sửa thống nhất danh sách việc, nút gửi, dữ kiện `null`, khôi phục lịch sử và bố cục mà vẫn chưa trả lời đúng việc hoặc chưa tạo đúng vật phẩm đã hứa.

Đơn vị điều phối nên là một mục tiêu có hợp đồng đầu ra: câu hỏi nào cần trả lời, quyết định nào cần hỗ trợ, vật phẩm nào cần có, dữ kiện nào thực sự làm thay đổi kết quả, và điều gì chứng minh hoàn thành. Số task là hệ quả của các đầu ra và phụ thuộc, có thể là 0, 1, 2 hoặc nhiều hơn; không phải một hằng số của renderer/schema.

Hợp đồng phải cho phép **kết quả hữu ích có giới hạn** khi thiếu nguồn hoặc dữ kiện, nhưng không tự đổi mục tiêu. Ví dụ, khung nhãn tiếng Anh có chỗ trống là vật phẩm khác với lời nhắn nhờ ai đó cung cấp dữ liệu nhãn. Nếu chỉ làm được vật phẩm thứ hai, hệ thống phải đổi lời hứa rõ ràng trước khi người dùng bỏ công vào bước đó.

## 2. Chuỗi bằng chứng: sửa gì đã có ích, điều gì vẫn lặp

| Vòng | Điều quan sát được trong tài liệu | Bài học kiến trúc |
|---|---|---|
| Mobile 17/10, trước sửa | Tổng hợp và thẻ đưa hai danh sách ba việc khác nhau; phiếu chỉ ở local nhưng báo “Chờ tiếp nhận”; form/hồ sơ chiếm đầu luồng. | Cần một kế hoạch canonical và trạng thái dựa trên bằng chứng hành động. Chat là lớp trình bày, chưa tự tạo thành trí nhớ hay workflow. |
| Mobile 17/10, sau sửa | Giữ đúng một danh sách; thấy đầu vào/kết quả sớm hơn; nháp ghi chưa gửi. Review chỉ đóng ba ưu tiên trong phạm vi ảnh, chưa đóng toàn bộ UX. | Các sửa cục bộ có hiệu quả thật. Một acceptance pass phải ghi scope; không nâng thành đạt mục tiêu sản phẩm rộng hơn. |
| Phương án frontend AI-native và lượt Trà Sen tiếp theo | Đã dự kiến hỏi ít, trả lời FDA/nhãn trước, không ép logistics. Thực tế independent review ghi 3 lượt thu thập thành công, hỏi lại 100 g, nhiều xác nhận; kết quả vẫn thiếu căn cứ FDA/nhãn. | Intent và dependency cần là đối tượng máy kiểm được. Ý định trong tài liệu không đủ nếu pipeline vẫn tổ chức quanh schema hồ sơ và menu việc cố định. |
| Review-fixes | Đã tái hiện rồi sửa phản hồi cũ ghi đè identity mới; reconcile một run mất phản hồi từng đổi idempotency key khi đã có artifact cũ. | Mọi callback/task/result phải gắn identity, ngữ cảnh, snapshot/version, run và operation key. “Có báo cáo” không chứng minh đó là run đang đối chiếu. |
| Certifications-null-fix | `null → null` từng làm hỏng cả intake. Sửa bỏ qua no-op nhưng giữ quote/type/duplicate/transaction guards; live walkthrough mới thành công. | “Chưa biết”, “xóa giá trị đã biết”, “không đổi” là ba thao tác khác nhau. Cần state semantics, không dùng truthiness hoặc prompt nới lỏng thay cho kiểm tra. |
| Strict review 18/10 | Lượt 839 ký tự đã tự khai gần đủ hồ sơ, mục chưa biết và yêu cầu đúng ba việc; không chứng minh người mới được dẫn từ một câu tự nhiên. Các thẻ vẫn thiên về lưu tên việc. | Bộ đánh giá phải có câu thô ngắn, người dùng không biết thuật ngữ, nhiều ý và ý định đổi giữa chừng. Không để fixture viết hộ phần khó nhất của planner. |
| Owner audit 18/10 | Câu ngắn đi qua được; nháp sửa và reload còn. Quay cùng CTA “Chuẩn bị” lại mở mẫu ban đầu; lần hoàn tất mới dẫn xuống cuối báo cáo. | “Tiếp tục việc” phải mở instance artifact hiện hữu, có quan hệ task→draft. Một task không chỉ là nhãn dẫn tới template. Trạng thái tiếp tục phải được dựng từ checkpoint. |
| Question-relevance và review độc lập ba flow cuối | Trà Sen trả lời hai ý; Mứt Sen trả lời ai/khi nào; Bột Sen công khai chưa đủ nguồn. Tuy nhiên chỉ 2/3 và 1/3 việc trực tiếp ở hai flow đầu; nháp nhãn chưa phải khung nhãn; flow chứng nhận hỏi ngược tên chứng nhận. | Tách coverage của câu hỏi, relevance của task và acceptance của artifact. Đổi tiêu đề ba thẻ theo câu hỏi chưa đủ tạo kế hoạch đúng. |

Nguồn lịch sử: [review mobile trước sửa](<../../../../REFERENCE_LINKS.md#ref-0435>), [review sau sửa](<../../../../REFERENCE_LINKS.md#ref-0436>), [phương án frontend](<../../../../REFERENCE_LINKS.md#ref-0437>), [independent review 17/10](<../../../../REFERENCE_LINKS.md#ref-0438>), [review-fixes](<../../../../REFERENCE_LINKS.md#ref-0439>), [null semantics](<../../../../REFERENCE_LINKS.md#ref-0440>), [strict review 18/10](<../../../../REFERENCE_LINKS.md#ref-0441>), [owner audit](<../../../../REFERENCE_LINKS.md#ref-0442>), [walkthrough ba câu hỏi](<../../../../REFERENCE_LINKS.md#ref-0443>), [review độc lập ba flow](<../../../../REFERENCE_LINKS.md#ref-0444>).

Các file này mô tả các phiên và mức chứng minh khác nhau: ảnh, source, fixture, test tập trung hoặc Claude thật. Không cộng số test thành điểm UX; không lấy kết quả fixture cuối để chứng minh khả năng hiểu tự do của mô hình thật. Lỗi cũ đã có xác nhận sửa chỉ dùng để rút bài học, không gán là lỗi hiện tại.

## 3. Phân biệt bốn khoảng trống trước khi chọn bước tiếp

| Loại | Dấu hiệu và ví dụ | Cách xử lý đúng | Điều không được suy ra |
|---|---|---|---|
| Thiếu nguồn phù hợp | Kho cũ chưa có điều khoản nhãn; Bột Sen không có căn cứ chứng nhận phù hợp dù toàn bản có 14 đoạn/8 trang. | Tạo research question cụ thể, tìm trong nguồn đã lưu trước; nếu chưa có, ghi `evidence_missing` hoặc `retrieval_failed`, chỉ rõ phần trả lời bị ảnh hưởng. Nếu được phép nghiên cứu mới thì lập task đọc nguồn; nếu không, bàn giao gói giới hạn. | Đếm tổng nguồn không chứng minh đủ coverage; CBP 403 không đồng nghĩa nội dung không tồn tại hoặc không áp dụng. |
| Thiếu dữ kiện áp dụng | Chưa biết hoạt động/loại cơ sở; thiếu thành phần; chưa có phương thức/ETA để ra hạn riêng. | Gắn mỗi input với quyết định hoặc trường output mà nó chặn. Trả lời phần quy tắc chung có căn cứ; hỏi dữ kiện cần cho phần cụ thể. Cho phép unknown và chỉ rõ ai/cách lấy. | Không suy từ tên Trà Sen/Bột Sen ra công thức, chứng nhận hay nghĩa vụ. Không biến lượng thùng/cân nặng thành bắt buộc cho câu hỏi nhãn nếu chúng chưa ảnh hưởng output. |
| Thiếu deliverable | Thẻ hứa “Có bản nhãn tiếng Anh” nhưng nháp là lời nhờ bằng tiếng Việt; phiếu Prior Notice thiếu trường điền. | Artifact có loại, cấu trúc, phần đã điền/chưa có và acceptance riêng. Builder tạo vật phẩm thật; verifier đối chiếu lời hứa với nội dung. | Lưu được một draft hoặc có đúng tên sản phẩm không chứng minh đã tạo đúng deliverable. |
| Câu hỏi mơ hồ | “Cần chứng nhận gì?” chưa nói rõ người hỏi muốn hiểu yêu cầu bắt buộc, yêu cầu buyer hay chuẩn tự chọn. | Giữ câu gốc; diễn giải các khả năng bằng lời thường, đề xuất phạm vi làm việc và cho “chưa biết”. Có thể bắt đầu bằng hồ sơ sản phẩm và gap map; không bắt người mới nêu tên chứng nhận. | Mơ hồ không phải lý do tự đổi sang ba việc nhập khẩu chung; cũng không được dùng như cách che thiếu nguồn. |

Có thể cùng lúc có nhiều loại. Bột Sen hiện có ít nhất `scope_ambiguous + input_missing + evidence_missing`; nháp chưa dùng được còn là `deliverable_incomplete`. Mỗi blocker cần object riêng, không ép vào một nhãn “chưa đủ thông tin”.

## 4. Symptom → nguyên nhân cấu trúc → yêu cầu kiến trúc

| Symptom lặp | Nguyên nhân suy ra từ nhiều vòng | Hệ quả thiết kế |
|---|---|---|
| FDA/nhãn nhưng đẩy IOR, Incoterm và chuyên gia; câu hỏi Prior Notice vẫn có hai việc rộng | Planner chọn từ workflow/shipment template trước khi xác định outcome; tối ưu đủ số thẻ | `intent_aspects[]` và `outcomes[]` đứng trước `tasks[]`; mỗi task có `contributes_to` và/hoặc `unblocks`. Không có liên hệ thì loại hoặc đưa thành gợi ý tùy chọn có lý do. |
| Có câu trả lời đúng nhưng ẩn dưới việc; hai ý chỉ tóm tắt một ý | Không có coverage ledger cấp từng câu hỏi; summary không được kiểm đủ ý | Mỗi aspect có câu trả lời ngắn, trạng thái, evidence, điều kiện áp dụng và việc còn thiếu. Renderer dùng cùng dữ liệu; không dựng một summary khác có thể bỏ ý. |
| Hỏi nhiều rồi mới báo kho nguồn không đáp ứng | Khả năng công cụ/nguồn không được xét trước thu thập | Preflight so hợp đồng đầu ra với capabilities và metadata nguồn. Báo phần biết là thiếu trước bước tốn công; không hứa kiểm đủ chỉ từ tên danh mục FDA/CBP. |
| “Nhờ chuyên gia” luôn là task; “làm rõ chứng nhận” nhắc lại câu hỏi | Không có kiểm task phải thu được thông tin/vật phẩm mới | Task có input, owner dự kiến, action thực, output và bằng chứng done. Handoff chỉ hợp lệ khi có gói bàn giao cụ thể; gửi/chờ tiếp nhận chỉ khi có bằng chứng bên nhận. |
| Nháp hứa lớn hơn nội dung; CTA quay lại tạo mẫu cũ | Template function được coi như task execution; thiếu identity/lifecycle artifact | Artifact instance có `task_id`, `contract_outcome_id`, phiên bản, edit provenance, `supersedes` và trạng thái. “Mở tiếp” và “tạo mới từ mẫu” là hai operation riêng. |
| Dữ kiện chưa biết làm lỗi; hỏi lại 100 g; sửa mà kết quả cũ có vẻ mới | Trích xuất patch, fact state và snapshot chưa có semantics xuyên pipeline | Fact giữ value + status + source + observed_at; patch phân biệt assert/retract/no-op. Snapshot bất biến; thay đổi input đánh dấu các output phụ thuộc cần xem lại. |
| Tìm đúng sản phẩm nhưng sai nghiên cứu; async cũ ghi đè; reconcile đổi key | Identity của context/run/artifact không đi xuyên mọi bước | Trace mọi event với principal/context/snapshot/contract/task/run/operation. Reopen chỉ đọc checkpoint; retry/reconcile không tự tạo lượt mới; callback lệch context không được commit. |
| Report success, số test hoặc số nguồn được dùng làm dấu “đã xong” | Một trạng thái completion cho nhiều tầng | Tách `run_terminal`, `answer_coverage`, `artifact_ready` và `user_outcome`. Chứng cứ một tầng không tự nâng tầng khác. |

Đây là các suy luận thiết kế có thể kiểm bằng những ca trên, chưa phải kết luận mọi module hiện tại đều thiếu các cấu trúc này. Những guard tốt đã có — provenance, phiên bản, isolation, idempotency, giữ bản cũ — là nền để giữ và mở rộng.

## 5. Ba reference plan

Các plan dưới đây là mô hình đích, không phải lời khuyên pháp lý. Số bước được ghi để diễn tả phụ thuộc; số task thực do planner co/tách theo dữ kiện, nguồn và đầu ra đã chọn. Không tự thêm chuyên gia cho đủ ba việc.

### A. Trà Sen Tây Hồ — FDA và khung nhãn tiếng Anh

**Câu gốc:** “Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.”

**Intent thực:** hai mục tiêu đồng thời: hiểu nhánh đăng ký áp dụng thế nào; có thứ cụ thể để bắt đầu làm nhãn. Chưa có căn cứ suy ra người dùng muốn nộp đăng ký, in nhãn, thuê chuyên gia hoặc chuẩn bị cước.

**Hiện trạng trong bộ cuối:** trả lời hai ý bằng nguồn đã lưu; chưa kết luận đăng ký/miễn cho cơ sở này. Hai việc trực tiếp, một việc hỗ trợ chung. Nháp nhãn giữ sản phẩm nhưng chỉ nhờ tập hợp dữ liệu, chưa có khung nhãn như lời hứa. Các vòng trước từng chưa có nguồn nhãn chi tiết và chuyển sang IOR/Incoterm.

**Outcome contract:** O1 — bảng điều kiện đăng ký, căn cứ, dữ kiện cơ sở còn thiếu và kết luận điều kiện; O2 — khung nhãn tiếng Anh điền được, phân biệt dữ kiện đã khai, trường còn trống và phần cần kiểm. `draft` không có nghĩa được duyệt in. Nếu nguồn chỉ đủ hướng dẫn chung, O1 có trạng thái giới hạn và không kết luận riêng; nếu chỉ tạo được lời nhờ thì đổi tên O2 thành “yêu cầu cung cấp dữ liệu nhãn”, không đánh dấu khung nhãn đã sẵn sàng.

**Luồng và orchestration:** (a) giữ nguyên hai aspect, kiểm nguồn/capability đã có; (b) có thể chạy song song research đăng ký và research nhãn từ kho, mỗi nhánh trả evidence và gap theo câu hỏi; (c) hỏi hoạt động/loại hình cơ sở cho quyết định đăng ký, và thành phần/quy cách/đơn vị chịu trách nhiệm cùng dữ liệu nhãn đã có cho artifact; chỉ hỏi trường thực sự chặn phần sắp làm; (d) tổng hợp câu trả lời từng ý, giữ ngoại lệ chưa giải; (e) builder tạo bảng điều kiện và khung nhãn; verifier đối chiếu O1/O2 trước khi báo sẵn sàng.

**Missing inputs:** cơ sở làm hoạt động gì, ở đâu/loại nào; công thức và dữ liệu nhãn hiện có; thông số nào đã được người dùng xác nhận. Đây là input cần xác minh tùy phạm vi, không tự mặc định mọi trường là yêu cầu pháp luật. Không yêu cầu người dùng đã biết IOR/Incoterm để bắt đầu.

**Research outputs:** claim→excerpt→nguồn→ngày truy xuất→điều kiện áp dụng; ghi riêng chưa đọc được, không có đoạn liên quan, và chưa đủ dữ kiện áp dụng. Nhánh nhãn và đăng ký không dùng chung “coverage đủ” chỉ vì cùng cơ quan FDA.

**Artifacts:** `registration-applicability.md` + `english-label-draft.md` (hoặc một gói gồm hai phần), field map và checklist dữ liệu còn thiếu. Khung có nhãn trường tiếng Anh và chỗ điền rõ; không bịa công thức, claims hay Nutrition Facts. Mỗi phần có trạng thái và liên kết nguồn riêng.

**Reuse:** dùng lại trích đoạn/khung điều kiện theo phạm vi; dùng lại facts đúng sản phẩm đã xác nhận. Không tái dùng kết luận áp dụng của cơ sở khác. Khung nhãn là template tái dùng, bản điền là artifact của đúng sản phẩm/snapshot.

**Minimum useful done và acceptance:** cả hai aspect có câu trả lời ngắn hoặc lý do chưa trả lời; O1 ghi các điều kiện còn mở; O2 mở được như khung tiếng Anh thực có các placeholder, không chỉ là tin nhắn nhờ người khác. Mọi placeholder có trạng thái và cách lấy. Reopen cùng CTA mở đúng bản sửa đã lưu. Chỉ khi người dùng yêu cầu và có đủ thông tin/căn cứ mới mở outcome nộp đăng ký/in nhãn riêng.

### B. Mứt Sen — ai nộp Prior Notice và khi nào

**Câu gốc:** “Em có Mứt Sen gửi New York. Thông báo trước lô hàng do ai nộp và nộp khi nào?”

**Intent thực:** xác định người cần đảm nhiệm và thời điểm cần làm để không bỏ mốc. Không mặc định người dùng đang nhờ app nộp hoặc đã biết ETA/phương thức.

**Hiện trạng trong bộ cuối:** đã trả lời ai/khi nào từ nguồn đã lưu, có các mốc theo phương thức; không chốt hạn riêng khi chưa có ETA/phương thức. Chỉ việc chuẩn bị thông báo trước trực tiếp; IOR/FSVP và chuyên gia chưa nối rõ vào câu hỏi. Nháp chưa có worksheet đủ trường.

**Outcome contract:** O1 — câu trả lời người có thể nộp và quy tắc thời điểm theo nguồn; O2 chỉ khi muốn áp dụng cho lô — phiếu phối hợp có người dự kiến nộp, thông tin còn thiếu, kênh/phương thức, ETA/múi giờ, cách tính mốc và trạng thái xác nhận. O2 có thể đang chờ dữ kiện; O1 vẫn hoàn thành được. “Đã chuẩn bị phiếu” khác “đã nộp/đã nhận xác nhận”.

**Luồng và orchestration:** (a) tách `who` và `when`; (b) truy lại nguồn phù hợp từ kho, nhánh ai và thời hạn có thể song song nếu tách được; (c) trả O1 ngay khi có căn cứ; (d) nếu người dùng muốn hạn lô cụ thể, hỏi phương thức, ETA/múi giờ, người dự kiến nộp và dữ kiện xác định phạm vi liên quan; (e) builder tạo worksheet; phép tính hạn, nếu có, dùng rule đã xác minh và input rõ ràng; (f) verifier kiểm quy tắc, đơn vị thời gian, input và trách nhiệm chưa được xác nhận.

**Missing inputs:** không có ETA/phương thức thì không ra deadline riêng. Không có người nhận việc thì ghi “chưa xác nhận”, không biến “Em” thành một nhân sự tên Em. Những input chỉ phục vụ nộp thật được thu khi outcome đó được yêu cầu.

**Research outputs:** nguồn trả lời ai, nguồn cho từng nhánh thời gian, ngoại lệ/chỗ chưa kiểm và nguồn lỗi. Các mốc được báo cáo lịch sử không được coi là luật hiện hành trong proposal này.

**Artifacts:** `prior-notice-answer.md`; nếu cần `prior-notice-worksheet.md` với giá trị/chỗ trống, trách nhiệm dự kiến, mốc theo điều kiện, liên kết nguồn và mục bằng chứng xác nhận. Không thêm công việc IOR/FSVP nếu chưa chỉ được dependency cụ thể với outcome đang giải.

**Reuse:** quy tắc có phiên bản/ngày/điều kiện dùng lại được; ETA, người nộp và xác nhận là dữ kiện lô riêng. Đổi ETA/phương thức đánh dấu deadline cũ cần tính lại, không sửa âm thầm report cũ.

**Minimum useful done và acceptance:** người đọc tìm được hai đáp án ai/khi nào; mọi deadline riêng có đủ input và rule trace, hoặc hiển thị chưa tính được kèm đúng dữ kiện thiếu. Worksheet có ô điền và người/cách xác nhận, không chỉ lời nhờ chung. Không có trạng thái “đã nộp” trước chứng cứ submission/confirmation. Không cần tạo đủ ba task để đóng O1.

### C. Bột Sen — chưa biết mình cần chứng nhận gì

**Câu gốc:** “Tôi có Bột Sen gửi New York. Sản phẩm cần chứng nhận gì?”

**Intent thực:** người mới muốn hệ thống chỉ ra cần tìm hiểu/chuẩn bị điều gì cho đúng sản phẩm và hướng bán; họ có thể chưa biết phân biệt tên giấy tờ. Không được suy từ câu hỏi thành “đã biết chứng nhận nào cần kiểm”.

**Hiện trạng trong bộ cuối:** trung thực chưa đủ nguồn, không đặt chứng nhận bắt buộc. Nhưng việc đầu hỏi lại “chứng nhận nào” tạo vòng lặp; checklist hồ sơ ở việc 2 hữu ích hơn; số tổng nguồn không phản ánh căn cứ chứng nhận bằng 0 trong bộ này.

**Outcome contract:** O1 — xác định phạm vi cần tìm bằng lời thường, cho “chưa biết”; O2 — hồ sơ sản phẩm tối thiểu và gap map phân biệt câu hỏi nghiên cứu, dữ kiện sản phẩm và yêu cầu bên mua; O3 chỉ khi đủ căn cứ — danh sách yêu cầu đã kiểm, điều kiện áp dụng và điều còn mở. Không hứa danh sách chứng nhận đầy đủ khi thiếu nguồn. Một gói chuẩn bị nghiên cứu hữu ích có thể hoàn thành trong khi O3 vẫn blocked.

**Luồng và orchestration:** (a) phản hồi không bắt nêu tên chứng nhận, nêu có thể cần xem yêu cầu pháp lý và yêu cầu buyer, hỏi người dùng có yêu cầu buyer/tài liệu sẵn không; (b) thu công thức, quy trình, công dụng/cách dùng, dạng đóng gói và hướng giao dịch theo mức thực sự cần; (c) tạo gap map trước khi điều phối research, lookup kho theo câu hỏi cụ thể; (d) research agents tìm căn cứ theo nhóm vấn đề đã xác định, mỗi agent có câu hỏi và phạm vi riêng, không tự kết luận áp dụng từ tên sản phẩm; (e) tổng hợp tách yêu cầu có căn cứ với câu hỏi chưa giải; (f) tạo dossier/checklist bàn giao và xác định bước thu dữ kiện/source tiếp theo.

**Missing inputs:** thành phần, quy trình, công dụng, yêu cầu bên mua, hồ sơ đang có; mỗi mục có lựa chọn chưa biết. Mơ hồ về từ “chứng nhận” là việc hệ thống giúp diễn giải, không phải field bắt buộc người dùng phải biết.

**Research outputs:** bảng các câu hỏi cần kiểm và lý do liên quan; evidence phù hợp hoặc tình trạng thiếu. Không dùng tám trang FDA về chủ đề khác làm chứng minh đủ cho O3. Những phân nhóm pháp lý/buyer/tự nguyện là khung phân tích sản phẩm, không xác nhận quy định cụ thể cho Bột Sen.

**Artifacts:** `product-dossier.md`, `requirements-gap-map.md`, checklist thu dữ liệu có thể điền. Nếu cần người thật, gói bàn giao gồm đúng câu hỏi, facts, source gap và việc cần xác nhận; trạng thái chưa gửi cho tới khi có operation gửi thật.

**Reuse:** tái dùng cấu trúc dossier, từ điển lời thường và câu hỏi nghiên cứu đã kiểm; dữ kiện Bột Sen không lấy từ Trà/Mứt Sen. Khi thêm nguồn mới, chỉ chạy lại các outcome đang thiếu căn cứ hoặc bị ảnh hưởng; giữ snapshot cũ.

**Minimum useful done và acceptance:** không có câu hỏi bắt buộc nhập tên chứng nhận; người dùng có checklist hồ sơ thực dùng được và biết mục nào lấy từ ai; source gap và input gap hiện riêng; không có kết luận bắt buộc/miễn thiếu căn cứ. O3 chưa được đánh dấu đủ dù dossier đã lưu. Nếu người dùng cần kết luận ngay mà chưa thể đáp ứng, hệ thống nói đúng outcome nào chưa hoàn thành và cung cấp artifact bàn giao thay vì lặp nghiên cứu cùng nguồn.

## 6. Các cửa nghiệm thu đo được, không chấm điểm cảm tính

| Cửa | Phép kiểm và điều kiện đạt |
|---|---|
| Bảo toàn intent | Với câu gốc Trà Sen, contract có cả đăng ký và nhãn; Mứt Sen có ai và khi nào; Bột Sen giữ câu hỏi rộng mà không yêu cầu user biết tên chứng nhận. Không có aspect nào biến mất qua plan→answer→artifact. |
| Truy vết task | Mỗi task trong plan có `contributes_to` một outcome hoặc `unblocks` một dependency được nêu. Task không có liên hệ bị loại khỏi kế hoạch cần làm; task tùy chọn được ghi riêng với lý do. Thay đổi số task không làm schema/renderer fail. |
| Phân loại gap | Fixture cố ý thiếu nguồn, thiếu ETA, thiếu artifact và câu hỏi mơ hồ được trả bốn loại khác nhau; có thể cùng tồn tại. Lỗi fetch giữ trạng thái retrieval, không bị đổi thành “không có quy định”. |
| Coverage thực | Từng aspect có answer/status/evidence/gap. Bộ Bột Sen hiển thị không có căn cứ phù hợp nếu đúng như fixture, dù toàn package có 14 đoạn. Coverage không tăng chỉ vì thêm tài liệu không liên quan. |
| Tên vật phẩm đúng | CTA hứa khung nhãn thì output có cấu trúc nhãn tiếng Anh và placeholder; hứa phiếu thì có trường điền. Nếu output là lời nhờ, tên/contract phản ánh lời nhờ. Verifier kiểm nội dung, không chỉ kiểm `artifact_created=true`. |
| Hỏi có mục đích | Mỗi câu hỏi bổ sung khai báo outcome/decision nào bị chặn và điều gì thay đổi theo câu trả lời. Không hỏi lại fact nguyên vẹn đã có nguồn người dùng; không hỏi logistics ở Trà Sen trừ khi dependency được chỉ rõ. |
| Unknown có nghĩa | `null→null` không đổi provenance/certainty; known→null cần yêu cầu xóa hợp lệ; `[]` không tự đồng nghĩa unknown. Snapshot cũ không bị sửa khi input mới thay đổi. |
| Tiếp tục đúng bản | Sửa/lưu draft, reload, bấm lại CTA mở đúng artifact version đã sửa. Tạo mới từ mẫu là lựa chọn riêng. Đọc/lịch sử/reconcile không tạo provider call mới. |
| Run đúng ngữ cảnh | Sequence identity đổi, callback cũ tới muộn và run mất phản hồi sau artifact cũ không ghi vào ngữ cảnh mới; operation key của reconcile không đổi. |
| Completion trung thực | Run kết thúc không tự đánh dấu outcome hoàn thành. Bản nháp chưa gửi không có “chờ tiếp nhận”; O3 Bột Sen không complete chỉ vì dossier đã lưu. Mọi outcome complete kèm đường dẫn artifact/bằng chứng đạt hợp đồng. |

Đánh giá có người dùng nên giao mục tiêu thật, không cho script hay đầu vào viết sẵn 839 ký tự. Ghi riêng việc họ có nêu đúng đáp án, lấy đúng vật phẩm, tìm lại đúng bản, hiểu đúng phần chưa làm và cần bao nhiêu lần trợ giúp. Thu thời gian/lần chạm/chi phí thực để lập baseline rồi mới quyết ngưỡng; không dùng điểm 5/10–7/10 hoặc một tỷ lệ completion tùy đặt để chứng minh kiến trúc đúng. Bài kiểm deterministic trên fixture đo conformance của hệ thống; không thay cho kiểm khả năng hiểu của người thật.

## 7. Bài học từ các phương án g2/g3/g4

Các tài liệu trước đã có tư tưởng đúng: kho có trích dẫn, tách luật/LLM, từ điển lời thường, tái dùng hồ sơ, phê duyệt khi gửi ngoài, chuyển người thật và nhật ký. G3 đổi từ một doanh nghiệp có kinh nghiệm sang SME chưa xuất khẩu; g4 cắt AI đọc ảnh khỏi MVP và đưa chuyên gia làm tay. Đó là lịch sử quyết định sản phẩm, không phải yêu cầu mặc định của kiến trúc tổng quát.

G2 tổ chức quanh một SME, một SKU và mục tiêu một đơn đã thanh toán ở thị trường/kênh mới; yêu cầu dữ liệu được gắn từng tính năng, và `ChannelPack` tách phần theo thị trường. Điểm tái dùng tốt là ranh giới package và input dependencies; điểm không nên mang sang mọi MVP là chuỗi F1→F4→F2→F3 hoặc mặc định Amazon. G3/g4 tiếp tục đổi đối tượng, phạm vi và human operations trong hai ngày. Vì vậy core cần lưu cả phiên bản quyết định và lý do thay đổi, đồng thời xác định policy/domain pack nào đang có hiệu lực cho từng contract. Không trộn quy định lịch sử với policy hiện hành của một lượt. [Kiến trúc g2](<../../../../REFERENCE_LINKS.md#ref-0445>) · [ADR g2](<../../../../REFERENCE_LINKS.md#ref-0446>).

Các con số từng dùng — đúng một bước, kế hoạch tối thiểu ba việc, 80% checklist, bộ 12 câu, workflow theo nấc — không nên đóng cứng vào agent kernel. Từ ba flow mới, có thể thấy áp đặt số việc làm loãng mục tiêu. Domain pack có thể đề xuất journey, glossary, policy, template và điều kiện nghiệp vụ; core giữ hợp đồng, task DAG, provenance, artifact lifecycle, execution và evidence completion. [Kiến trúc g3](<../../../../REFERENCE_LINKS.md#ref-0447>) · [nhu cầu g3](<../../../../REFERENCE_LINKS.md#ref-0448>) · [đặc tả g4](<../../../../REFERENCE_LINKS.md#ref-0449>).

## 8. Ca thứ tư ngoài xuất khẩu — giả định để thử tính tổng quát

**[GIẢ ĐỊNH kiểm thiết kế, chưa có case quan sát]** Một chủ xưởng hỏi: “Tôi có hai báo giá máy đóng gói, giúp chọn phương án phù hợp ngân sách 300 triệu và chuẩn bị bảng hỏi nhà cung cấp trước khi quyết.”

Contract gồm bảng so sánh từ hai báo giá và nhu cầu xưởng, recommendation có điều kiện, cùng bảng hỏi thu phần thiếu. Nếu chưa có công suất/sản phẩm/chi phí vận hành thì tách input gap; nếu báo giá thiếu bảo hành thì là vendor evidence gap; nếu chưa tạo bảng hỏi là deliverable gap. Các nhánh đọc hai báo giá độc lập có thể song song, đối chiếu tổng chi phí phụ thuộc các input chung. Artifacts: `decision-matrix.md`, `vendor-questions.md`, bản ghi lựa chọn chưa chốt. Không mua/đặt cọc thay người dùng; “đã đề xuất” không đồng nghĩa “đã mua”.

Phép thử: cùng core phải biểu diễn được cả hai output, nguồn là báo giá và facts xưởng, task count thay đổi, reuse template so sánh nhưng không trộn dữ kiện nhà cung cấp; không cần field FDA, SKU xuất khẩu, nấc sẵn sàng hay chuyên gia nhập khẩu. Nếu phải sửa core để hiểu các field đó, sự tổng quát chưa đạt. Đây là kiểm cấu trúc và khả năng tạo artifact, chưa là khuyến nghị mua máy thực tế.
