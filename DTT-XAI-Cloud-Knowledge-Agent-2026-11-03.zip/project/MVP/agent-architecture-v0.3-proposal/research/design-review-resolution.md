# Ghi nhận phản biện bản thiết kế 0.3

**18/10/2026 · rà tài liệu, không phải nghiệm thu phần mềm.** Ba agent được phân công độc lập: hiện trạng mã, bài học sản phẩm nhiều vòng và dữ liệu/reuse. Bản tổng hợp 01–03 đã được rà lại; các thay đổi dưới đây chỉ ở tài liệu mới.

| Phát hiện | Cách xử lý trong bản tổng hợp |
|---|---|
| P1: grant gắn plan không thể cấp cho lượt AI cần để tạo plan | Prepare grant gắn request/principal trước interpret; execution grant gắn plan sau validate |
| P2: giữ phần tốt có thể bị hiểu là nhặt chuỗi từ response hỏng | Whole-response structural parse/schema trước partition; không salvage chuỗi; fallback độc lập có origin |
| P2: dossier thay mất mục tiêu biết chứng nhận gì | Outcome requested riêng; dossier supporting không chuyển câu hỏi gốc thành satisfied |
| P2: gap có thể bị tính là outcome hoàn tất | Gap là phản hồi minh bạch; mục tiêu còn blocked_source/waiting_facts; trả lời kiến thức chung có căn cứ khác chốt ca riêng |
| P2: bắt chọn thêm khung nhãn dù câu gốc đã yêu cầu chuẩn bị | Khung nhãn là requested output trong plan đã cấp quyền; mở khung là đọc, không tạo lại |
| Giới hạn catalog biết trước nhưng vẫn có thể chạy một lượt không thêm thông tin | Preflight metadata trước execution grant; không dispatch paid research chỉ để lặp gap đã biết |
| Cửa sổ crash giữa reservation và network chưa đủ rõ | Commit dispatching trước network; unknown dừng tự replay; không hứa exactly-once billing |
| Promote public có thể bị hiểu là xóa private lineage | Record chung mới cần chứng minh độc lập bằng nguồn được phép; lineage riêng giữ dưới ACL; còn phụ thuộc private thì không promote |
| Graph/TTL có thể bị hiểu là tự biết nguồn web đổi | Chỉ invalidation sau refetch/sự kiện được quan sát; TTL không là legal validity |
| ACL có thể bị hiểu là thu hồi được bản MD đã tải | Ghi rõ không thu hồi vật lý bản offline; version/as-of/cách đối chiếu vẫn cần |

Hai lượt rà cuối xác nhận không còn blocker đã nêu về bootstrap quyền, partial publish, outcome thay thế và data/reuse. Đây không phải chứng minh các enum/API/DDL đã triển khai đúng; việc đó nằm trong cổng nghiệm thu 0.3. Tài liệu vẫn cần được xem xét khi chốt phạm vi triển khai.

Hồ sơ phân tích gốc: [hiện trạng](<current-state.md>), [bài học](<lessons-and-scenarios.md>), [memory và contracts](<memory-and-contracts.md>).

## Bổ sung SSOT/domain theo yêu cầu người dùng

Hai agent rà riêng [Enterprise SSOT](<enterprise-ssot-review.md>) và [domain refresh](<domain-refresh-review.md>); sau khi tạo tài liệu 04, các finding sau đã được sửa và chính reviewer kiểm lại:

| Finding | Cách chốt trong 04 và đồng bộ 02 |
|---|---|
| P1: tenant có nhiều DN nhưng mission/grant chưa bind enterprise | Enterprise ID được server xác lập; mission/context/prepare/execution/idempotency bind cùng scope; đổi DN không rebind grant cũ |
| P1: output cùng DN có thể mở quyền rộng hơn field đầu vào | Snapshot/finding/artifact giữ giới hạn input; recheck khi materialize/read, share rộng cần quyền hoặc redacted revision đã kiểm |
| P2: sửa fact trong lúc run nhưng output cũ vẫn publish current | Gate fact/source/consent/ACL trước dispatch/publish; needs_revalidation/as-of, không auto paid rerun |
| P1: chờ claim mới publish mới đánh dấu dependency cũ | Observation và invalidation anchor bền vững trước extract/review; pending review vẫn chặn current reuse đúng phần |
| P2: public dedupe có thể trộn quyền/ngân sách DN khác | Chỉ deterministic source checks trong auth/rights/read/service budget phù hợp; paid attempts/grants không gộp chéo DN |

Reviewer xác nhận đóng các finding được giao rà; đây vẫn là rà tài liệu, chưa phải test runtime hay kiểm ACL đã triển khai. Không có refresh job/lịch monitor hoặc paid model call được tạo.
