# Rà kiến trúc: domain knowledge, SSOT và làm mới có kiểm soát

**Ghi chú thiết kế · 18/10/2026 · chưa triển khai.** Đã đọc [01 — kiến trúc](<../01_Thiet_ke_kien_truc_Agent.md>), [02 — đặc tả](<../02_Dac_ta_MVP_0_3_va_lo_trinh.md>), [03 — ba ca](<../03_Ba_ca_tham_chieu_va_hop_dong_cong_viec.md>) và [memory/contracts](<memory-and-contracts.md>). Phạm vi ghi chú là đề xuất cho tài liệu SSOT 04; không thay ứng dụng, không kiểm Internet, không gọi mô hình, không tạo lịch hay chạy refresh thật. Các ví dụ bên dưới minh họa hợp đồng hệ thống, không xác nhận quy định áp dụng cho ba sản phẩm.

## 1. Ba điểm quan trọng cần khóa trong 04

| Vấn đề | Nếu chỉ dùng thiết kế hiện tại theo cách diễn giải đơn giản | Hợp đồng cần bổ sung |
|---|---|---|
| **Domain knowledge không đồng nghĩa dữ liệu công khai** | Gắn `public_library` cho mọi nguồn Internet; gắn `tenant_library` nhưng chưa rõ các doanh nghiệp nào có quyền tài liệu được cấp phép; bỏ `org_id` để tái dùng kết luận riêng | Tách loại tri thức, đối tượng được truy cập và quyền sử dụng nội dung. Nguồn công khai, nguồn có giấy phép trong nhóm được quyền và finding của một doanh nghiệp là ba trường hợp khác nhau. Promotion cần claim mới đứng được bằng bằng chứng được phép chia sẻ, có duyệt; lineage gốc giữ riêng. |
| **“Mới” có ba nghĩa độc lập** | HTTP 200/304, hash không đổi hoặc TTL chưa hết bị dùng để cho rằng nhận định đúng và áp dụng được | Có `SourceCheck`, `ClaimReview` và `ApplicabilityEvaluation` riêng. Bản nguồn đã kiểm không chứng minh diễn giải còn được duyệt; claim đã duyệt không chứng minh đúng cho case/ngày mục tiêu. |
| **Refresh không phải đọc cache hay quyền chạy AI mặc định** | Mở báo cáo tự fetch, cache hết hạn tự gọi mô hình, hai doanh nghiệp cùng làm lại một nguồn, hoặc refresh thành công tự sửa báo cáo đã phát hành | Catalog lookup/read thuần; refresh là task có loại thao tác, grant, quota, idempotency và ledger riêng. Dedupe công việc nguồn công khai được phép; private job/cache theo ACL. Invalidation thay trạng thái hiện tại, không sửa nội dung báo cáo cũ hoặc tự duyệt/phát hành bản mới. |

Nền 01/02/03 đã nêu đúng nhiều nguyên tắc này. Rủi ro còn lại nằm ở việc biến nguyên tắc thành trạng thái và trường dữ liệu đủ cụ thể để implementation không gom chúng thành một boolean `fresh/verified`.

## 2. Phân lớp dùng chung và cá nhân hóa

Không dùng một trục `public/private` để thay tất cả các quyết định. Một record tối thiểu cần ba trục độc lập:

| Trục | Giá trị/ý nghĩa đề xuất |
|---|---|
| `knowledge_kind` | `source`, `domain_claim`, `template`, `org_fact`, `case_finding`, `coverage_record`. Không coi report hoàn chỉnh là domain claim. |
| `access_scope` | `public_library`, `entitled_library` có tập principal/nhóm được quyền rõ ràng, `org_private`, hoặc ACL hẹp hơn. `tenant_library` chỉ dùng nếu đã định nghĩa một tenant có bao nhiêu doanh nghiệp và ai được đọc. |
| `use_rights` | Quyền giữ snapshot, trích dẫn, xử lý, gửi đến model/provider, tái dùng nội bộ, chia sẻ và xuất. Có chủ quyền/quyền cấp phép, căn cứ, thời hạn hoặc trạng thái chưa xác định. Đọc được URL không tự cấp mọi quyền này. |

**Domain claim dùng chung:** phát biểu có điều kiện, dựa trên nguồn được phép dùng trong phạm vi thư viện đó, không chứa facts hay kết luận của doanh nghiệp. **Org domain library:** doanh nghiệp có thể tích lũy quy trình, buyer requirements, tài liệu có giấy phép, cách phân loại ngành riêng; hữu ích qua nhiều case nhưng vẫn private hoặc chỉ chia sẻ đúng nhóm được quyền. **Case finding:** kết quả áp claim vào snapshot doanh nghiệp/sản phẩm/lô hàng, mặc định private.

Một doanh nghiệp mới chỉ thừa hưởng domain claim/template đủ điều kiện. Hồ sơ, thành phần, người mua, giá, ETA, nhân sự và finding của doanh nghiệp trước không được đi cùng “kinh nghiệm ngành”. Dữ kiện suy ra từ nguồn private mặc định vẫn private, kể cả đã xóa tên hoặc đổi cách diễn đạt.

### Promotion có căn cứ độc lập

Luồng đề xuất: ghi nhận nhu cầu tri thức từ ca riêng → tạo câu hỏi nghiên cứu không chứa dữ kiện riêng → thu bằng chứng trong phạm vi được phép dùng chung → tạo claim candidate mới → kiểm scope, support, quyền tái dùng và review → phát hành version cụ thể vào thư viện tương ứng. Đây là một quy trình có kiểm soát; 0.3 có thể tuyển tay, chưa cần automation.

Nếu claim chỉ đúng khi còn biết công thức, yêu cầu người mua hoặc điều kiện thương mại của ca gốc thì nó chưa phải claim chung. Việc ẩn danh, xóa cạnh private hoặc bỏ `org_id` không thay thế được bằng chứng độc lập. Việc “đã từng gặp vấn đề này ở khách hàng khác” chỉ là gợi ý nghiên cứu nội bộ có quyền, không phải support cho câu trả lời mới.

Lineage của candidate có thể có lịch sử private; chỉ reviewer được cấp quyền mới xem phần đó. Public graph, badge “được học từ N doanh nghiệp”, source count, related-case count, snippet, citation manifest và thông báo refresh không được tiết lộ sự tồn tại hay thuộc tính của ca private. Không xuất một cạnh private rồi chỉ che tên node. Với record chung đã đứng độc lập, bản đọc chung chỉ hiện provenance có quyền dùng chung; audit lineage gốc được giữ dưới ACL riêng, không giả mạo lịch sử rằng chưa từng có ca khởi phát.

## 3. Các trường dữ liệu tối thiểu nên thêm vào hợp đồng

Không đòi mỗi dòng thành một bảng mới; có thể là typed records trên kho và relation tables đã đề xuất. Các ID/version/hash quan trọng phải là refs có kiểm, không chỉ là mô tả tự do trong Markdown.

| Record | Trường cần chốt |
|---|---|
| `KnowledgeRecord` | `id`, `version`, `knowledge_kind`, `access_scope`, `acl_policy_ref/version`, `rights_policy_ref/version`, `owner/steward_ref`, `provenance_refs`, `created_at`, `classification_reason`. Principal/scope do server xác lập. |
| `SourceSnapshot` | `source_id`, `snapshot_id/version`, `canonical_uri`, `raw_hash`, `text_hash`, `retrieved_at`, `retrieval_result`, `parser_version`, `storage_ref` nếu được phép; `published_at/effective_from/until` có thể unknown. Quyền lưu raw và trích đoạn phải kiểm riêng. |
| `SourceCheck` | `check_id`, `source_id`, `checked_at`, `checked_by`, `check_policy_version`, `trigger`, `prior_snapshot_ref`, `observed_snapshot_ref`, `observed_change=unchanged/changed/unknown`, `access_result`, `error_reason`, `next_check_hint`. HTTP result là dữ kiện quan sát, không là verdict về claim. |
| `ClaimRevision/ClaimReview` | Phát biểu và qualifiers/scope; refs chính xác đến passage/snapshot; support/contradict assertions; `review_event_ref`, `reviewed_version/hash`, `review_scope`, `review_state`, `review_due_at` nếu có, `effective_interval` được xác định bằng căn cứ. Không suy ngày hiệu lực từ ngày fetch. |
| `ApplicabilityEvaluation` | `claim_revision_ref`, `case_snapshot_ref`, `intent/outcome_ref`, `target_as_of`, `pack/rule/policy_versions`, `predicate_results`, `missing_fact_refs`, `verdict`, `reason_codes`, `evaluated_at`. `unknown` khác `any` đã được duyệt. |
| `CoverageRecord` | `question/topic_fingerprint`, `context_scope_fingerprint`, `query/plan/capability_versions`, `source_pack_id/version/member_hash`, danh sách snapshot/check refs đã kiểm, `as_of`, `supported/partial/no_support_found`, failures và gaps. `reusable_until_condition` diễn tả điều kiện mất khả năng dùng lại; không biến gap thành claim phủ định. |
| `RefreshRequest/Job` | `operation_kind=source_check/extract/review_proposal/recompute`, `authorization_domain`, `principal/service_principal_ref`, `grant_ref`, `source/claim/dependency_refs`, `trigger/reason`, `dedupe_key`, `idempotency_key`, `input/policy_hash`, budget refs, state, attempts/lease, result refs, error và `outcome_unknown` khi thích hợp. |
| `InvalidationEvent` | `cause_type`, subject version/hash, observed event ref, `observed_at`, affected refs hoặc bounded traversal, `required_action`, policy version; ghi việc cần rà, không ghi đè nội dung lịch sử. |
| `Publication/ReuseDecision` | Snapshot các refs/version/hash đã dùng, gate policy và verdict/reasons; approval bind đúng payload/version/scope, principal và thời điểm. Bản draft mới không kế thừa approval bản cũ. |

`review_due_at` và `next_check_hint` là thời điểm cần xem xét theo policy. Chúng không tự khẳng định luật hết hiệu lực khi đến hạn hoặc còn hiệu lực trước hạn. Cổng dùng lại quyết định có được tiếp tục, cần kiểm nguồn, cần review hoặc cần facts dựa trên mục đích và mức rủi ro đã cấu hình.

### Các trường hợp chứng minh ba trục độc lập

| Quan sát | Kết luận được phép |
|---|---|
| Nguồn trả 304, claim review đã bị thu hồi | Biết nguồn được kiểm không đổi theo cơ chế quan sát đó; claim không đủ điều kiện dùng mới. |
| Nguồn đổi hash chỉ vì bố cục | Có snapshot mới; chưa kết luận claim sai hoặc đúng. 0.3 có thể đánh dấu toàn bộ descendants cần review để tránh bỏ sót. |
| Claim đã duyệt cho scope A, case B thiếu công dụng/actor | Giữ claim; finding B là `needs_case_facts` hoặc `requires_review`, không mượn dữ kiện từ A. |
| Fetch 403/timeout | Lưu lỗi và bản biết gần nhất; không kết luận nguồn bị bãi bỏ hay coi snapshot cũ là xác nhận hiện hành. |
| Ngày mục tiêu đi qua mốc hiệu lực đã biết | Gate lại theo ngày mục tiêu dù không phát hiện hash mới; có thể cần rule/review khác, không nhất thiết fetch lại mọi nguồn. |
| Nguồn không đổi nhưng pack diễn giải/rule thay đổi | Re-evaluate phần phụ thuộc pack/rule; không đợi một lần đổi hash web để nhận ra thay đổi nội bộ. |

## 4. Refresh theo nhu cầu, có giới hạn

Các trigger đề xuất gồm sự kiện nguồn/claim được quan sát, nhu cầu dùng claim trong nhiệm vụ mới, admin yêu cầu kiểm, mốc hiệu lực đã biết, review đến hạn, hoặc source pack/context/capability mới. Trước tiên chỉ ghi `refresh_needed` hoặc tính `ReuseDecision`; không đồng nghĩa tạo một tiến trình chạy nền. Mở lịch sử và các API GET/search/read vẫn thuần đọc, không tự fetch Internet hoặc gọi AI.

Khi có task thực thi được cấp quyền, luồng tối thiểu là: kiểm ACL/quyền dùng và refs hiện tại → chọn thao tác cần làm → reserve ngân sách/quota và ghi attempt bền vững → kiểm nguồn hoặc chạy thao tác trong grant → lưu observation/snapshot mới → xác định dependencies bị ảnh hưởng → đưa về gate/review → tạo draft revision khi có quyền → duyệt/phát hành riêng theo chính sách. Người dùng không phải xác nhận lại mỗi fetch đã nằm trong grant hợp lệ; grant cũng không tự mở rộng vì cache cũ.

- **Đọc nguồn không dùng mô hình:** vẫn cần read permission và trần URL/byte/time/retry/concurrency. Có thể chạy bằng service read grant có phạm vi rõ hoặc grant tác vụ còn hiệu lực. Hết quota thì ghi trạng thái chờ; không đổi sang model/provider để vượt giới hạn.
- **Trích/so sánh có thể làm bằng mã:** version parser/rule và input hash phải vào result/cache key. “Extract” không mặc định miễn phí; nếu implementation cần mô hình thì nó là model operation.
- **Diễn giải lại, dịch bằng mô hình, soạn draft hoặc paid review proposal:** cần prepare/execution grant phù hợp trước lần gọi, theo hai giai đoạn của 02. Refresh không tạo quyền tiêu tiền mới. `no_paid_calls` chặn cả hai; không có grant thì trả `needs_grant` và giữ phần đọc hợp lệ đã có.
- **Kết quả gọi trả phí chưa rõ:** giữ spent/reserved/unknown riêng, đi `outcome_unknown`, chặn tự replay/fallback/restart. Retry chỉ trong loại lỗi và ngân sách đã cấp; checkpoint không là quyền chạy lại.
- **Publication:** kiểm lại quyền, consent, case/claim/pack versions, cancellation và approval policy trước commit. Claim/source refresh xong không tự phát hành câu trả lời mới và không sửa báo cáo cũ.

### Dedupe mà không dùng lẫn quyền doanh nghiệp

Có thể gộp một lần kiểm **nguồn chung được phép** cho nhiều yêu cầu đang đợi. Dedupe key cần source identity + target/check window theo policy + retrieval/parser policy version + authorization/rights domain phù hợp. Sau đó mỗi mission có subscription/reuse decision riêng và vẫn gate bằng context riêng. Không dùng tên, facts hay query riêng của một doanh nghiệp làm payload cho job chung.

0.3 nên chỉ dedupe nguồn công khai được hệ thống tuyển và trả chi phí đọc bằng ngân sách service rõ ràng. Nguồn có đăng nhập/giấy phép và private source giữ job/cache trong org hoặc authorization domain được xác định; chưa gộp chéo doanh nghiệp. Một execution grant của A không được dùng để trả tiền cho xử lý hồ sơ B. Dedupe một paid request có grant khác nhau không mặc nhiên hợp lệ chỉ vì prompt giống nhau.

Cache key tác vụ phải gồm loại task, input refs/hash, outcome, source/claim/pack/policy/schema/parser versions và authorization domain. Quyền hiện tại vẫn kiểm lại khi lấy cache; cache hit không thay kiểm revocation. Blob hash nội bộ không là API dò sự tồn tại. Job status, subscriber count, refresh reason, error/snippet và graph chỉ hiện phần caller được phép đọc. Một invalidation của nguồn chung có thể đánh dấu các finding private qua logic hệ thống, nhưng thông báo cho từng doanh nghiệp chỉ chứa refs/nội dung của chính phạm vi đó.

### Lịch sử và negative knowledge

Artifact revision đã phát hành bất biến. Khi dependency đổi, người đọc nhận bản lịch sử cùng envelope hiện tại như “cần đối chiếu vì nguồn/đầu vào đã đổi”; không bị dẫn tới nội dung mới có cùng version. Nếu có nhu cầu cập nhật, tạo task/draft revision, ghi delta và áp review policy mới. Việc duyệt bản cũ không tự chuyển sang bản mới, kể cả thay đổi chỉ một trường.

`CoverageRecord.no_support_found` chỉ giúp tránh tìm lại y hệt trong cùng môi trường bằng chứng. New context facts, source pack membership/version, nguồn mới, capability nghiên cứu mới, query policy mới hoặc ngày mục tiêu đổi có thể làm record cũ không đủ để chặn nghiên cứu. Muốn nghiên cứu tiếp vẫn cần đường nguồn/capability và grant phù hợp; việc hết khả năng dùng gap cũ không tự cấp quyền gọi AI. Kết quả luôn là “chưa tìm thấy trong phạm vi X đã kiểm”, không là “không có nghĩa vụ”.

## 5. Kiểm qua ba ca tham chiếu

**Trà Sen và Mứt Sen:** nếu cả hai có outcome liên quan thông báo trước trong cùng scope, claim chung về người có thể nộp và rule xác định thời điểm có thể được lookup từ cùng thư viện sau gate. Trà Sen ở câu hỏi gốc chỉ hỏi đăng ký cơ sở và nhãn; cache có Prior Notice không phải lý do tự thêm outcome đó. Khi một ca cần thông báo trước, chỉ dùng lại claim/rule/template phù hợp; ingredient, công dụng, người nộp, ETA, timezone, cửa đến, confirmation và kết luận lô vẫn là dữ kiện/finding riêng. Đổi ETA có thể chỉ làm lại phép tính hạn riêng; đổi rule nguồn có thể ảnh hưởng cả hai ca nhưng mỗi finding cần đánh giá riêng. Ví dụ không chép số giờ hay kết luận pháp lý từ report cũ thành rule mới.

**Bột Sen:** tám nguồn overview không đủ để trả câu chứng nhận cụ thể nếu không hỗ trợ đúng ý. Lưu gap có source pack/context snapshot để không lặp lượt nghiên cứu vô ích. Khi người dùng thêm công dụng hoặc hệ thống được cấp bộ nguồn mới, đánh dấu coverage cần xem lại; không kéo dài “chưa tìm được” vô hạn. Dossier hỗ trợ có thể dùng lại template, nhưng gap không thành “không cần giấy tờ”, và B1 không thành satisfied chỉ vì B2 đã có mẫu.

## 6. Acceptance cần có và phạm vi 0.3 gọn

Đây là test cases đề xuất cho bước triển khai, chưa viết hoặc chạy test trong ghi chú này.

| Tình huống | Kết quả bắt buộc |
|---|---|
| Public URL nhưng policy chỉ cho trích, không cho lưu raw/xuất nguyên văn | Lookup/ingest/export tuân quyền riêng; không coi public access là toàn quyền tái dùng. |
| A có tài liệu ngành theo giấy phép, B không nằm trong entitlement | B không thấy result, snippet, source count, related edges, badge hay job/subscriber metadata của A; copy cache ref không vượt ACL. |
| Candidate được viết lại từ private case nhưng chưa có evidence độc lập | Không promote dù đã bỏ tên/org_id; giữ private lineage; public view không lộ nguồn khởi phát. |
| Source check unchanged nhưng claim revoked hoặc case thiếu điều kiện | Reuse bị chặn đúng reason; không gộp `unchanged` thành `eligible`. |
| Hash thay đổi hoặc reviewer đổi support/rule | Tạo version/event mới; descendants cần gate/review; bản report cũ giữ nguyên hash/payload, mở không gọi AI. |
| Hai mission cùng cần kiểm một nguồn chung | Có một bounded read job nếu cùng authorization/policy domain; hai reuse decisions riêng; không trộn case context hoặc lấy grant A cho B. |
| Cache hit sau khi quyền đọc/consent bị thu hồi | Read/materialize/export bị chặn; index, translation và graph không trở thành đường vòng. |
| `next_check_hint` tới hạn, không có paid grant | Có thể báo cần kiểm theo policy; không tự dispatch model hoặc tạo automation. |
| Paid refresh timeout/crash sau dispatch | `outcome_unknown`, chi phí unknown/reserved, không tự replay/fallback/restart; không ghi phí 0 vì thiếu usage. |
| Thêm source pack member hoặc facts mới sau `no_support_found` | Gap cũ không chặn gate mới chỉ vì cùng câu chữ; không biến gap thành miễn nghĩa vụ. |
| Cập nhật ETA Mứt Sen, Trà Sen không đổi | Tính lại task phụ thuộc ETA của Mứt Sen; không copy ETA/ingredients và không tải lại toàn bộ nguồn vô cớ. |
| Draft mới dùng source mới; approval chỉ bind bản trước | Chặn auto publication; cần đúng approval policy/version/scope cho bản mới. |

**Nên làm ở 0.3:** thư viện domain nhỏ do người tuyển, org-private facts/findings, quyền/rights tường minh, SourceCheck được kích trong tác vụ có grant, gate ba trục, source/claim/pack version refs, coverage có fingerprint, invalidation rộng nhưng đầy đủ, source read dedupe chỉ cho thư viện công khai, báo cáo lịch sử bất biến và draft cập nhật được duyệt riêng. Metadata/ID/FTS và relation tables đủ cho các hợp đồng này; chưa cần graph DB, embeddings hay thêm nhiều worker model.

**Để sau khi có nhu cầu và policy:** promotion automation, chia sẻ thư viện có giấy phép giữa nhiều doanh nghiệp, gộp paid processing chéo tổ chức, discovery mở rộng, refresh liên tục và monitors. Trong đề xuất 04 chỉ mô tả trigger/owner/điều kiện dừng của monitor tương lai; không tạo lịch, không gắn lời hứa “luôn cập nhật”, không có lịch nền mặc định. Phần hữu ích nhất trước mắt là biết cái gì được phép dùng lại, dựa vào bản nào, khi nào cần đối chiếu và ai có quyền cho bước tiếp theo.
