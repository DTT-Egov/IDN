# Bộ nhớ, dữ liệu và hợp đồng agent v0.3 — đề xuất để duyệt

Ngày rà soát: 18/10/2026. Vai trò: phản biện độc lập về dữ liệu, tái sử dụng tri thức và hợp đồng thực thi. **Chưa triển khai**; chỉ đọc mã nguồn và tài liệu, không đọc `.env`, thông tin đăng nhập, DB chạy thật hay phiên người dùng; không gọi ứng dụng MCP hoặc API mô hình trả phí.

Tài liệu này là ghi chú nghiên cứu bổ trợ. Bản thiết kế tích hợp để duyệt là [01 — thiết kế Agent](<../01_Thiet_ke_kien_truc_Agent.md>), [02 — đặc tả và lộ trình](<../02_Dac_ta_MVP_0_3_va_lo_trinh.md>) và [03 — ba ca tham chiếu](<../03_Ba_ca_tham_chieu_va_hop_dong_cong_viec.md>). Khi cách chia object hoặc tên hợp đồng khác nhau, lấy 02 làm chuẩn triển khai dự kiến; DDL/schema cụ thể vẫn phải thiết kế khi triển khai. Các tên IntentRevision, TaskDAG, InvocationLedger, ClaimRevision, EvidencePassage trong ghi chú là **tên logic đích được đề xuất**, không phải class/table/API hiện đã có. Trong 02, chúng tương ứng với IntentSpec + Mission/Context revision, PlanRevision + ResearchTask dependencies, ProviderAttempt + budget records và Evidence/Claim có version.

## 1. Khuyến nghị chính

Giữ **SQLite + bản ghi JSON có schema** làm nguồn dữ liệu chuẩn của MVP local. Dùng Markdown làm bản đọc, bản bàn giao và nội dung tuyển chọn có kiểm soát. Dùng bảng quan hệ có kiểu và xuất JSON/Mermaid để quan sát tri thức; chưa thêm Neo4j hay vector DB.

Điểm phải bổ sung trước database mới là: diễn đạt đúng kết quả người dùng cần; lưu kế hoạch có tiêu chí hoàn thành; phân biệt dữ kiện doanh nghiệp, bằng chứng, phát biểu có căn cứ và kết luận áp dụng cho một ca; kiểm quyền và điều kiện áp dụng trước mỗi lần dùng lại. Nhiều agent, nhiều đoạn trích hoặc đồ thị đẹp không tự tạo ra những điều đó.

**Hai đồ thị khác nhau:** TaskDAG biểu diễn việc nào chờ việc nào trong một lần làm; knowledge graph biểu diễn một phát biểu được bằng chứng nào hỗ trợ, áp dụng ở đâu và bị thay thế bởi phiên bản nào. Không dùng trạng thái hoàn thành task làm chứng nhận đúng của tri thức.

## 2. Hiện trạng đã kiểm trong mã nguồn

| Đã có trong v0.2 | Hệ quả cho v0.3 |
|---|---|
| `CaseCreate`/`CaseReplace`, version hồ sơ và provenance từ message, certainty `provided`/`estimate` | Giữ cơ chế người dùng xác nhận; việc được người dùng cung cấp vẫn không biến thành dữ kiện bên ngoài đã kiểm chứng. |
| Run khóa `snapshot`, `question`, provider/model và routing tại thời điểm start | Kế thừa; thêm intent/plan/skill/source-policy version để tái hiện quyết định. |
| SQLite business state; giao dịch khi start/finish; lease, cancel, idempotency và payload hash | Dùng lại nền này; bổ sung attempt ledger và budget reservation thay vì viết runtime mới ngay. |
| SourceDocument lưu extracted text và SHA-256; Evidence có locator/excerpt, translation gắn hash nguyên văn | Đây là nền tốt cho trích dẫn đúng phiên bản. Thêm raw snapshot khi có quyền lưu và metadata ngày hiệu lực/phạm vi. |
| Finding, Unknown, Responsibility, NextStep, TopicAnswer; reference validation | Mở rộng schema theo intent/outcome, không đổi mọi output thành một bài Markdown không kiểm được. |
| Artifact immutable, `review_status=draft`; nguồn luôn `candidate`; stale khi case version đổi | Không coi `run succeeded` là đã duyệt. Hiện chưa có kho claim đã duyệt và kiểm điều kiện tái dùng. |
| Khởi động lại làm queued/running thành interrupted và không tự gọi AI lại | Giữ nguyên nguyên tắc. Checkpoint giúp kiểm tra tiến độ, không cấp quyền tiêu thêm tiền. |
| 5 MCP tool cho Shipment; scope thực tế là 1 SKU thực phẩm khô VN → US qua importer | Không tuyên bố đã có Mission runtime, task write, generic multi-agent hay knowledge resources. Market/partner trong registry vẫn là kế hoạch. |

Tài liệu G2 từng đề xuất TypeScript/Postgres; triển khai v0.2 thực tế là Python/SQLite. Đề xuất này bám mã đang có; không biến lựa chọn cũ trong tài liệu thành yêu cầu di chuyển công nghệ.

Nguồn nội bộ: `nmate-backend-v0.2/ARCHITECTURE.txt`; `src/nmate/models.py`; `src/nmate/store.py`; `src/nmate/conversations/models.py`; `src/nmate/agents/shipment/models.py`; `src/nmate/mcp_server.py`. Nghiên cứu: `_research/nmate/g1/du-lieu-tri-thuc.md`, `g2/adr.md`, `g2/kien-truc-v1.md`, `g3/kien-truc-v2.md`, `g4/dac-ta-nac-0-2.md`. Tình trạng nguồn trong G1 là ghi nhận ngày 16/10/2026, không phải bằng chứng rằng mọi URL hay quy định vẫn hiện hành hôm nay.

## 3. Ba ca cho thấy phải lưu gì để dùng lại có ích

Các nhận xét dưới đây dựa trên tóm tắt review ba ca do điều phối cung cấp. Không phải kết luận pháp lý về từng sản phẩm.

| Ca đã review | Đơn vị cần lưu lại | Dùng lại được | Không được suy ra từ cache |
|---|---|---|---|
| Trà Sen Tây Hồ → New York, hỏi đăng ký cơ sở FDA và nhãn tiếng Anh | Intent có **hai outcome**; task tạo checklist xác định vai trò cơ sở và task tạo nháp cấu trúc nhãn; các trường còn thiếu gắn đúng vị trí | Taxonomy vai trò, nguồn chính thức, cấu trúc nháp nhãn đã duyệt, tiêu chí thông tin tối thiểu | Có hai đoạn trả lời đúng không đồng nghĩa đã tạo nháp nhãn. Không dùng một lời nhờ bổ sung dữ kiện thay cho artifact được yêu cầu. Không điền thành phần/dinh dưỡng/chủ thể chịu trách nhiệm bằng phỏng đoán. |
| Mứt Sen → New York, hỏi ai/khi nào nộp Prior Notice | Claim về người nộp/thời điểm có scope; task thu phương thức vận chuyển, ETA và chủ thể; artifact có trường người nộp, mode, ETA, hạn cần xác định | Form chuẩn và phương pháp xác định hạn từ nguồn/phiên bản đã duyệt | Không gắn một hạn chung khi thiếu mode/ETA. Task IOR/FSVP hay gặp chuyên gia chỉ xuất hiện nếu giúp giải một khoảng trống có thật của câu hỏi này. |
| Bột Sen → New York, hỏi chứng nhận | Question coverage record: đã tìm gì, nguồn nào, còn thiếu căn cứ gì; taxonomy nghĩa vụ pháp lý/yêu cầu người mua/tự nguyện; dossier checklist | Nguồn chung, cấu trúc dossier, câu hỏi về thành phần/công dụng/claim/kênh và loại yêu cầu người mua | 14 passages từ 8 trang FDA không chứng minh một chứng nhận cụ thể. `unavailable` không có nghĩa là không cần chứng nhận. Không bắt người chưa biết phải tự nêu đúng tên certificate mới được giúp tiếp. |

Mỗi outcome phải có `done_when` và `artifact_type` cụ thể. Nếu thiếu dữ kiện, kết quả có thể là **mẫu nháp hữu ích có ô trống và lý do**, hoặc `pending_clarification`; không tự kết luận đã hoàn thành.

Bộ nhớ có ba lớp tái dùng khác nhau:

1. **Quy trình/mẫu:** cách lập nháp nhãn, form Prior Notice, dossier checklist. Có version và review riêng; không phải bằng chứng pháp lý.
2. **Tri thức có căn cứ:** phát biểu gắn nguồn, locator, thời gian và điều kiện áp dụng. Chỉ tái dùng sau applicability gate.
3. **Kết quả một doanh nghiệp:** kết luận và nội dung cá nhân hóa, luôn gắn case snapshot và quyền đọc. Không tự đưa vào kho chung.

## 4. Mô hình dữ liệu chuẩn tối thiểu

Các tên sau là hợp đồng đề xuất, chưa phải bảng đã có. Tất cả bản ghi có `id`, `schema_version`, `created_at`; bản ghi sửa được có `version` và optimistic concurrency. Mọi liên kết private mang khóa scope tương thích, có ràng buộc tenant/org tại tầng store. Không chỉ kiểm tenant ở màn hình.

| Đối tượng | Trường cần có | Vai trò |
|---|---|---|
| **IntentRevision** | `mission_id`, nguyên văn yêu cầu và message refs; `desired_outcomes[]`; điều kiện/ràng buộc; thị trường/kênh/product refs; knowns/unknowns; `as_of`; tiêu chí hoàn thành; điều không làm | Giữ nghĩa của câu hỏi qua nhiều lượt chat. Bản trích xuất của LLM là đề xuất đến khi được xác nhận hoặc nằm trong quyền đã cấp rõ ràng. |
| **Mission** | chủ thể/tenant/org; `active_intent_revision`; `case_snapshot_ref`; trạng thái; `execution_grant_ref`; outcome state | Một mục đích công việc có thể có nhiều plan revision và run, không đồng nhất với chat thread. |
| **PlanRevision / TaskDAG** | intent revision; các task `type`, `input_refs`, output schema, `done_when`, phụ thuộc; version skill/source policy; trần tài nguyên; `plan_hash` | Hợp đồng thực thi có thể kiểm bằng mã. MVP nên chọn từ template có slot, chưa cho planner tạo graph tùy ý. |
| **Task / TaskAttempt** | logical task và input hash; attempt số; lease; state; model/source invocation refs; output refs; lỗi có kiểu; timestamps; `attempt_of` | Phân biệt công việc logic với lần thử cụ thể; không ghi đè lần thử cũ. |
| **InvocationLedger** | request hash; idempotency key; stage; provider/request id nếu có; `prepared/dispatched/succeeded/known_failed/outcome_unknown`; usage; cost estimate/reserved/actual; pricing policy; grant ref | Kiểm chi phí và tình huống crash; không giả định timeout tức là chưa bị tính phí. |
| **Source / SourceSnapshot** | canonical URL, publisher, source kind; raw/text hashes; storage refs; `retrieved_at`, `published_at`, `effective_from/until` nếu biết; jurisdiction; parser version; HTTP/retrieval result; quyền lưu/tái dùng | Source là danh tính tài liệu; snapshot là nội dung đã đọc. Một URL có thể có nhiều snapshot. `retrieved_at` khác ngày hiệu lực. |
| **EvidencePassage** | snapshot ref; locator điều/mục/trang; offsets nếu parser ổn định; exact excerpt và excerpt hash; source language; translation ref/provenance | Trích đúng câu từ đúng snapshot; bản dịch không thay thế nguồn gốc. |
| **ClaimRevision** | phát biểu chuẩn; subject/predicate/object nếu có ích; qualifiers; scope; effective interval; evidence refs với quan hệ support/contradict; review state | Đơn vị tri thức tái dùng. Không tạo claim đã kiểm chỉ từ câu LLM viết nghe hợp lý. |
| **Finding** | case snapshot + intent outcome; claim/evidence refs; applicability verdict; lý do/field còn thiếu; basis; review state | Kết luận dành cho ca cụ thể. Claim đúng ở một bối cảnh chưa chắc áp dụng được cho ca này. |
| **CoverageRecord** | câu hỏi/topic; plan/query/source policy version; tập nguồn đã kiểm; `supported/partial/no_support_found`; gaps; thời điểm; source failures | Ghi cả việc chưa tìm được bằng chứng để tránh lặp nghiên cứu mù. `no_support_found` bị giới hạn trong nguồn và phạm vi đã kiểm. |
| **ArtifactRevision** | structured payload; mission/run/case/intent/plan refs; evidence manifest; snapshot hashes; review state; render policy version; content hash | Đầu ra hữu ích: nháp nhãn, form, checklist hoặc kế hoạch. Markdown/PDF là cách trình bày. |
| **ReviewEvent / InvalidationEvent** | subject id+version+hash; actor+role; decision/reason; scope; thời điểm; supersedes/revokes refs | Approval là sự kiện gắn đúng nội dung và phạm vi. Sửa artifact/claim tạo version mới, không kế thừa approval ngầm. |
| **Relation** | `from_id/type/version`, `relation_type`, `to_id/type/version`, scope; source event | Biểu diễn provenance và invalidation; tách bảng/namespace execution edges khỏi knowledge edges. |

Scope của claim/finding ít nhất gồm `jurisdiction`, market, origin, product family + đặc tính liên quan, route/channel, actor role, mục đích sử dụng, ngày áp dụng. Không có field không đồng nghĩa mọi giá trị đều phù hợp: `unknown` phải khác `any` đã được người có trách nhiệm xác nhận.

Giữ ba loại trạng thái riêng:

- Thực thi: task/run đã chạy xong hay chưa.
- Bằng chứng: dữ kiện người dùng cung cấp, nguồn đã tải được, phát biểu có hỗ trợ, còn thiếu hoặc mâu thuẫn.
- Duyệt/phát hành: draft/candidate, approved với scope/version, rejected, superseded, revoked.

Tránh một boolean `verified=true` vừa có nghĩa đã tải URL, vừa có nghĩa đúng pháp lý, vừa có nghĩa chuyên gia đã duyệt. Mức tự tin của mô hình không thay được bất kỳ sự kiện kiểm chứng nào.

### Quan hệ tối thiểu

`Task DEPENDS_ON Task` thuộc TaskDAG; phải không chu trình. `Claim SUPPORTED_BY EvidencePassage`, `Claim CONTRADICTED_BY EvidencePassage`, `Finding APPLIES_CLAIM ClaimRevision`, `Finding USES_CASE CaseSnapshot`, `Artifact DERIVED_FROM Finding/TaskOutput`, `Revision SUPERSEDES Revision`, `Review APPROVES Revision` thuộc provenance/knowledge. Không ép mọi từ trong văn bản thành node.

Task chỉ đọc các input refs được cấp. Worker không có quyền chỉnh hồ sơ xác nhận, đổi acceptance criteria hoặc tự phê duyệt output.

## 5. Markdown, SQLite, document store và property graph

| Lựa chọn | Khi dùng | Giới hạn/chọn khác khi nào |
|---|---|---|
| **Markdown** | Brief, hồ sơ tóm tắt, ghi chú nghiên cứu, bản bàn giao; skill/source packs do người tuyển có manifest. Dễ đọc, diff và chuyển đi. | Không đủ làm queue/ledger/ACL transaction. Không dùng chỉnh trực tiếp một file Markdown để đồng thời đổi task state, approval, cost và evidence. |
| **SQLite + typed JSON** | Nguồn chuẩn cho MVP một máy: entity có schema, version, quan hệ, state transitions, budget và idempotency. Cột định danh/scope/status/index; JSON giữ payload theo domain. | Khi thực sự cần nhiều máy ghi, phân quyền production, vận hành/HA hoặc workload đồng thời vượt mức đo được thì đánh giá Postgres. WAL không biến SQLite thành database nhiều host; docs SQLite nêu các process WAL phải cùng host. [SQLite WAL](https://www.sqlite.org/wal.html), kiểm 18/10/2026. |
| **Object/file snapshot store** | Raw PDF/HTML/ảnh và extracted text được phép lưu, bất biến theo hash, metadata/ACL trong SQLite. File là blob, không chứa trạng thái chuẩn khác. | DB phải ghi manifest và xuất bản reference sau khi blob đã ghi bền; có dọn orphan an toàn. Không giữ transaction mở suốt network call. |
| **Document store riêng** | Chỉ cân nhắc khi workload schema biến đổi/truy cập tài liệu chứng minh typed JSON trong DB hiện tại thành nút thắt, có nhu cầu vận hành rõ ràng. | Chưa thấy lợi ích buộc phải có trong ba ca. Thêm một kho không tự giải được provenance, ACL hoặc trạng thái duyệt. |
| **Relation tables + graph export** | MVP: query căn cứ, tìm output bị ảnh hưởng khi nguồn/case đổi; xuất JSON node/edge và Mermaid để review. | Giữ ID/version/type/scope; mọi export đi qua ACL. Không xuất cạnh tới private node rồi chỉ giấu nhãn node. |
| **Property graph DB** | Chỉ sau khi có truy vấn đa bước lặp lại mà relational joins/recursive traversal không đạt yêu cầu đã đo, team đủ vận hành/migration/ACL, và có bộ kiểm tương đương. | Chưa có lý do chọn Neo4j chỉ vì đối tượng có quan hệ. Graph không tự chứng minh claim đúng hoặc còn hiệu lực. |

**Một nguồn dữ liệu chuẩn:** render Markdown từ typed artifact, kèm `artifact_id`, version, payload hash, review state, as-of và evidence manifest. Muốn sửa Markdown thành dữ liệu mới thì nhập như **draft revision**, validate và review; không có sync hai chiều âm thầm. Không chạy lệnh hay cấp quyền từ nội dung Markdown/nguồn web.

Nội dung tuyển tay có thể bắt đầu từ Markdown+front matter trong thư mục pack: import/compile thành records có schema và hash. Quy định rõ pack manifest là đầu vào tác giả, DB compilation là bản dùng trong run; khi pack đổi phải tạo version mới. Không để hai nơi cùng được coi là bản mới nhất.

## 6. Truy xuất trước, kiểm điều kiện áp dụng sau

MVP bắt đầu bằng filter có cấu trúc + từ khóa/taxonomy/synonym Việt–Anh. SQLite có FTS5 cho full-text search; đây là lựa chọn candidate retrieval, không phải bộ kiểm đúng. [SQLite FTS5](https://www.sqlite.org/fts5.html), kiểm 18/10/2026. Trước khi bật FTS phải kiểm runtime có extension và eval truy vấn có/không dấu, tên sản phẩm, thuật ngữ FDA và từ đồng nghĩa; không hứa chất lượng đa ngôn ngữ chỉ vì có FTS.

Luồng tái dùng:

1. **Xác lập quyền và snapshot:** principal, org, mission, confirmed case version, intent revision, as-of. Scope lấy từ server, không tin `tenant_id` do LLM/client gửi.
2. **Lọc quyền trước khi tìm:** chỉ public approved library và các vùng private được phép. Filter cả search index, snippet, count, graph traversal và source manifest.
3. **Tìm candidates có giới hạn:** theo outcome/topic, market, source type, review state; giữ khác biệt `template`, `claim`, `historical finding`, `coverage gap`. Lưu lý do match.
4. **Applicability gate bằng mã + thông tin đã duyệt:** kiểm scope, thời gian, nguồn bị thay thế/thu hồi, evidence còn truy cập được theo policy, missing fields, conflicts và review scope. Kết quả `eligible`, `needs_refresh`, `needs_case_facts`, `requires_review`, `inapplicable` cùng reason codes.
5. **Chỉ truyền phần đủ điều kiện vào tác vụ phù hợp:** có thể xem draft để nghiên cứu nhưng không dùng draft làm claim approved. LLM được diễn giải và đề xuất; không tự đổi verdict thành verified.
6. **Nếu có khoảng trống:** tạo task thu dữ kiện, đọc nguồn cho phép hoặc chuyển review. Không lấy passage gần nghĩa nhất để lấp chỗ trống.
7. **Lưu ReuseDecision:** candidate version, gate/policy version, quyết định và lý do, input snapshot. Người xem biết phần nào được kế thừa và phần nào nghiên cứu mới.

Applicability gate không tự tạo sự thật từ metadata. Mã chỉ kiểm được predicates đã định nghĩa, tình trạng review và quan hệ support đã được xác nhận. Nếu cần diễn giải luật hoặc kiểm một quan hệ support mới mà chưa có rule/claim đã duyệt, trả `requires_review` hoặc coverage gap; LLM có thể đề xuất đối chiếu nhưng không tự biến nó thành verified. Việc trích dẫn phải kiểm exact excerpt thật sự thuộc snapshot/locator đã lưu, không chỉ kiểm hash có đúng định dạng hay ID tồn tại.

Embedding chỉ thêm khi eval cho thấy recall từ taxonomy/FTS chưa đủ và chi phí/lợi ích rõ. Nếu thêm, nó vẫn chỉ xếp hạng candidates; phải giữ ACL, model/index version, xóa/thu hồi và cùng applicability gate. Không đưa toàn bộ hồ sơ private vào vector DB hoặc embedding API ngoài hệ thống theo mặc định.

### Dedupe đúng đơn vị

- Cùng canonical URL + cùng content hash giúp nhận ra cùng snapshot. URL giống mà nội dung khác là version mới.
- Cùng passage hash ở nhiều URL có thể là bản sao; không đếm thành nhiều nguồn độc lập.
- Claim chỉ gộp khi cùng nghĩa **và cùng qualifiers/phạm vi/thời gian**; nội dung giống chữ nhưng Mỹ/EU, food/cosmetic, người sản xuất/người nhập khẩu khác nhau phải tách. LLM có thể đề xuất trùng, không tự merge toàn kho.
- Question fingerprint dùng cho gợi ý tái dùng, không thay idempotency. Cùng chữ hỏi trên case version/intent outcome khác nhau không phải cùng công việc.
- Task cache key bao gồm task type + input refs/hashes + intent outcome + skill/rule/source policy/schema versions; cache key thiếu những phần này dễ trả lại một kết quả cũ nhưng nghe đúng.

## 7. Ngày, phiên bản, thu hồi và refresh

Dùng tối thiểu hai trục thời gian: **khi nào hệ thống biết/kiểm** (`observed/retrieved/reviewed_at`) và **khi nào nội dung áp dụng** (`effective_from/until`, nếu xác định được). Không tự điền ngày hiệu lực từ ngày tải trang. Có thể giữ trường `unknown`; không cần dựng toàn bộ event sourcing/bitemporal DB ngay.

Một nguồn tải thành công hôm nay không đảm bảo đúng cho ngày vận chuyển tương lai. Một trang FDA overview chính thức có thể không hỗ trợ certificate cụ thể. HTTP 200 và domain chính thức là kiểm tra nguồn, chưa phải kiểm entailment hoặc applicability.

| Sự kiện | Xử lý đề xuất |
|---|---|
| Case đổi thành phần, công dụng, nhãn, market, route hoặc actor liên quan | Giữ artifact lịch sử; mark findings/tasks phụ thuộc `case_changed`; chạy lại gate. Đổi trường không liên quan không buộc fetch lại mọi nguồn. |
| Nội dung nguồn đổi hash hoặc có văn bản thay thế | Lưu snapshot mới; phát invalidation event tới claims/findings/artifacts phụ thuộc; review phạm vi bị ảnh hưởng. Không sửa âm thầm kết quả đã phát hành. |
| Source tạm lỗi/403 | Lưu lỗi truy cập và last known snapshot; không coi nội dung đã biến mất, cũng không coi last snapshot là xác nhận hiện hành. Tác vụ rủi ro có thể cần refresh/review trước khi dùng. |
| Đến ngày bắt đầu/hết hiệu lực, thay đổi policy hoặc có notice | Gate theo as-of và ngày mục tiêu; enqueue `refresh_needed` hoặc review task. TTL chỉ là tín hiệu kiểm lại, không là căn cứ legal validity. |
| Reviewer thu hồi/sửa một claim hoặc bản dịch | Revocation gắn version/hash; tìm các descendants; khóa phát hành mới dựa vào version đó; hiển thị lịch sử và lý do. |
| Doanh nghiệp rút quyền dùng dữ liệu | Chặn đọc/tác vụ mới ngay theo consent/ACL hiện tại; xử lý xóa/redact ở blob, index, artifacts và bản export theo retention policy đã thống nhất. Nhật ký không được trở thành bản sao giữ nguyên private content. |

Invalidation chỉ lan truyền được sau khi hệ thống thực sự quan sát một thay đổi qua lần kiểm nguồn, notice được nhập hoặc review event. Đồ thị không tự phát hiện web hay luật đã đổi; giao diện phải nói rõ lần kiểm gần nhất và phạm vi đã kiểm.

Nguồn/loại claim có refresh policy riêng: theo event/thời điểm dùng/quy mô rủi ro, kèm `last_checked_at`, `next_check_hint`, refresh reason và người phụ trách. Không có một TTL 30 ngày dùng cho mọi luật, giá cước và mẫu nội dung. Kết quả `no_support_found` cũng hết khả năng tái dùng nếu scope/source policy hoặc dữ kiện mới đổi.

Refresh nguồn đọc thuần có thể nằm trong grant đọc đã cấp và quota. **Refresh cần mô hình trả phí, provider khác hoặc phạm vi dữ liệu khác không tự được cấp quyền** bởi việc cache hết hạn. Không có automatic paid resume từ checkpoint hay lịch refresh.

## 8. Tenant, quyền riêng tư và kho tri thức chung

Đề xuất scope rõ ràng: `public_library`, `tenant_library`, `org_private`, và quyền hạn chế hơn cho tài liệu nhạy cảm nếu cần. `public_library` là tài nguyên đã được người có quyền tuyển/phát hành và được phép tái dùng; không phải mọi thứ tải từ web đều được phép sao chép không giới hạn.

- Bằng chứng công khai có thể chia sẻ; cấu hình sản phẩm, giá, buyer/importer, đơn hàng, upload và kết luận của doanh nghiệp là private. Tri thức suy ra từ hồ sơ private mặc định vẫn private.
- Muốn lấy kinh nghiệm một ca làm knowledge chung phải tạo bản ứng viên đã loại dữ liệu nhận diện, giữ provenance có quyền kiểm tra riêng, và có phê duyệt về mục đích tái dùng. Không chỉ xóa `org_id` hoặc private dependency edges để biến private thành public. Claim được promote phải đứng độc lập bằng căn cứ được phép chia sẻ; nếu vẫn cần facts private để đúng thì không promote như claim chung. Giữ lineage kiểm toán riêng dưới ACL, không tạo một lịch sử công khai giả như chưa từng phụ thuộc dữ liệu riêng.
- Dedupe private theo tenant/org ở MVP. Nếu sau này dùng chung content-addressed blob, ACL áp trên mọi reference/read và không lộ hash/existence/counters giữa tenants. Lợi ích tiết kiệm blob chưa đáng đổi lấy side channel trong MVP.
- Quyền đọc artifact không mặc nhiên là quyền đọc mọi nguồn đính kèm hoặc hồ sơ được trích; export cần kiểm cả chuỗi dependency và phần được phép hiển thị.
- Worker nhận context tối thiểu đã lọc, không nhận lịch sử chat đầy đủ hoặc thông tin đăng nhập. Dữ liệu của doanh nghiệp khác không vào prompt để “học” cách trả lời.
- Consent lưu theo mục đích: lưu trữ, nghiên cứu, gửi mô hình, chia sẻ chuyên gia/đơn vị ngoài, dùng cho eval. Có version, chủ thể cấp, thời điểm và revoke. Không biến một boolean đồng ý xử lý thành quyền gửi mọi nơi.

Các nguyên tắc này là đề xuất kiểm soát kỹ thuật; không phải kết luận rằng hệ thống đã đáp ứng nghĩa vụ pháp lý hiện hành. Chính sách retention/chuyển dữ liệu cần người phụ trách chốt theo dữ liệu triển khai thật.

## 9. Vòng đời task, retry, chi phí và idempotency

Luồng task: `planned → ready → running → succeeded/partial/failed/cancelled`; nhánh `waiting_for_facts`, `waiting_for_review`, `budget_exhausted`, `outcome_unknown` được biểu diễn rõ. `partial` không thỏa tiêu chí hoàn thành của toàn Mission nếu outcome bắt buộc còn thiếu.

MVP nên dùng DAG template theo outcome; LLM chọn task types, slots và gaps. Mã kiểm: graph không chu trình, dependency tồn tại, giới hạn số node/fan-out, input/output schema, quyền tool, allowed source IDs, budget, và mọi outcome có task/artifact hoặc lý do chưa làm. Một orchestrator với các worker đọc nguồn/quy tắc/soạn nháp có giới hạn là đủ; các nhánh chỉ cần gọi LLM riêng khi có lý do và budget.

Hai call mục tiêu (intake+intent/plan; report) là envelope triển khai hợp lý, **không phải hứa mọi câu hỏi luôn giải xong trong hai call**. Nếu schema intake quá lớn hoặc dữ kiện thiếu, trả pending clarification/partial. Không âm thầm thêm vòng tự sửa, fan-out hoặc provider fallback để đạt cảm giác hoàn tất.

### Hai giai đoạn cấp quyền, không vòng tròn bootstrap

Theo [02 §5 — ngân sách và khôi phục](<../02_Dac_ta_MVP_0_3_va_lo_trinh.md#5-ngân-sách-chống-chạy-lại-và-khôi-phục>), **prepare grant** có trước lượt intake/interpret có phí, bind principal + conversation/message/request hash + model policy + attempt/token ceiling + thời hạn; không đòi mission/plan đã tồn tại. **Execution grant** có sau validate plan, bind mission/plan hash và limits thực thi. Hai loại cùng vào ledger và tổng chi phí; consent xử lý dữ liệu khác quyền chi phí. `no_paid_calls` chặn cả hai. Mở trang, lookup hay đọc lịch sử không tự cấp prepare grant. Vì vậy mọi nhắc tới execution grant ở ghi chú này chỉ áp cho giai đoạn chạy plan, không được dùng để cho phép intake chưa được cấp quyền hoặc đòi plan trước khi hiểu yêu cầu.

### Biên giao dịch đề xuất

1. `start`: kiểm quyền/consent/case version/plan hash; tạo run bằng idempotency và reserve quota/cost trong một transaction. Cùng key+cùng payload trả run cũ; cùng key+payload khác trả conflict.
2. `claim task`: cấp lease, recheck grant, ghi attempt và request hash trước network call. Không giữ transaction DB trong lúc gọi nguồn/provider.
3. `before dispatch`: kiểm cancel/revoke/version và trần input/output/call/time còn lại; ghi ledger `dispatching` bền vững trước network để biết một lần gọi có thể đã được gửi. Crash trong khoảng không xác định trước/sau request luôn đi vào outcome_unknown; không suy một nhãn prepared hoặc thiếu request ID là bằng chứng provider chưa nhận.
4. `after result`: lưu kết quả/usage và output được validate; cập nhật attempt/task trong transaction. Raw provider reply chỉ lưu nếu có quyền và retention phù hợp.
5. `publish`: kiểm lại consent, scope, case/plan version, cancellation, dependency hashes và review requirement trong cùng transaction xuất artifact + terminal run state.

**Không thể hứa exactly-once billing chỉ bằng SQLite/idempotency nội bộ.** Nếu process chết sau khi provider nhận request nhưng trước khi lưu kết quả, hệ thống có thể không biết lần gọi đã bị tính phí hay đã thành công. Ghi `outcome_unknown`, giữ reservation/cost unknown và chặn replay tự động. Reconcile bằng provider request id/usage khi có cơ chế đáng tin cậy; nếu không có, người có quyền quyết định tạo attempt mới trong budget mới hoặc dừng. Đừng ghi phí bằng 0 vì chưa nhận usage.

SDK/model client retry phải tắt hoặc được cấu hình và hạch toán tường minh trong ledger. Idempotency key nội bộ không có nghĩa provider hỗ trợ idempotency. Không fallback sang model/provider khác sau timeout nếu chưa có grant cho sự thay đổi đó.

Retry đọc nguồn chỉ dành cho lỗi tạm thời có phân loại, backoff và số lần/trần tổng rõ ràng; không retry vô hạn 403, không tự vượt login/paywall. Parser/schema failure phải báo rõ; nếu muốn LLM repair thì đây là paid task riêng được reserve, không “free retry”. Tác vụ deterministic đã hoàn tất với input/version giống hệt có thể dùng output cũ. Tác vụ đã dispatch nhưng chưa rõ kết quả phải đi qua reconciliation.

Budget gồm max model calls, allowed model tier/provider, max input/output, số URL/byte/time, max concurrency và cost cap theo pricing policy đã khóa; không chỉ đếm run mỗi ngày. Reservations cho các worker phải cùng giao dịch để không cùng tiêu phần ngân sách cuối. Hiển thị spent/reserved/unknown riêng; estimated cost phải ghi rõ ước tính.

Cancel ngăn gọi mới và publication sau thời điểm kiểm hợp lệ; không đảm bảo hủy được tiền của request đã gửi. Client đóng kết nối không đồng nghĩa hủy Mission. Restart không tự tiếp tục paid work; có thể khôi phục UI, đọc checkpoint và gọi các bước deterministic an toàn.

## 10. MCP: hợp đồng đọc và hợp đồng có thể tiêu tiền

MCP là biên tích hợp, không là model của toàn bộ domain. Giữ logic trong service/store. Không cần đưa mọi bảng thành CRUD tool. Giữ tool Shipment cũ đúng nghĩa; thêm Mission start có version/schema riêng khi backend đã đủ năng lực, không mở rộng âm thầm tool cũ thành agent tùy ý.

### Bề mặt đề xuất tối thiểu

| Bề mặt | Input/return chính | Điều phải cưỡng chế |
|---|---|---|
| `nmate_mission_start` (mới, tương lai) | `mission_id`, `expected_version`, `plan_id/hash`, `execution_grant_id`, `idempotency_key`; trả durable `run_id`, frozen refs, budget reservation | Chỉ chạy plan đã lưu/validate; server lấy principal và scope. Không nhận arbitrary shell, file path, model ID hay URL tùy ý. |
| `nmate_research_get` / `cancel` | run id; thêm cursor/max events bounded khi cần; return task/outcome/progress/cost states | GET không gọi LLM, không refresh nguồn. Cancel có hiệu lực theo trạng thái, không giả báo đã dừng provider. |
| `nmate_artifact_get` | artifact id+version cụ thể; trả immutable payload + current review/applicability envelope riêng | Metadata hiện tại không thay nội dung lịch sử. Người đọc biết artifact đã stale/revoked dù có bản cũ trong tay. |
| `nmate_knowledge_search` (tùy chọn tương lai; 02 để lookup nội bộ trước) | typed query theo topic/scope/as-of, `limit` nhỏ; trả candidate IDs+versions+review/gate reasons | Chỉ tìm trong ACL, không trả answer chắc chắn từ similarity score; không giấu paid work trong search. |
| MCP resources | URI đúng version cho mission/plan/artifact/passage đã được phép đọc | Read thuần; không đổi task state, không mở quyền, không tự đi lấy nội dung mới từ Internet. |
| Review trong UI/service có role | subject version+hash, decision, reason, scope | LLM không tự gọi một tool để biến chính draft của nó thành approved. Việc phát hành cho bên ngoài cần grant riêng về target/payload. |

Ví dụ URI: `nmate://artifacts/{id}/versions/{v}`, `nmate://sources/{snapshot_id}/passages/{passage_id}`. URI là định danh, không phải bearer capability hoặc đường dẫn file tùy ý. Response có `schema_version`, IDs/versions/hashes, trạng thái, as-of và errors có kiểu (`VERSION_CONFLICT`, `GRANT_REVOKED`, `BUDGET_EXHAUSTED`, `OUTCOME_UNKNOWN`, `NEEDS_FACTS`). Không lộ sự tồn tại của tài nguyên private cho caller không có quyền.

**Execution grant** là quyền nghiệp vụ: mission/plan hash, allowed task/tool/source/model scope, data categories được gửi, cap, expiry và chủ thể cấp/revoke. Không bắt người dùng duyệt lại mỗi lần đọc đã nằm trong grant, nhưng cũng không coi grant đã nghiên cứu là quyền gửi email, nộp hồ sơ, đăng listing hoặc mở rộng sang paid fan-out. Grants/consent và authentication token là các lớp khác nhau.

Theo MCP 2026-07-28, resources là cơ chế cung cấp context qua URI; list có thể lọc theo authorization của từng request. nMate nên dùng principal từng request, không coi transport connection là người dùng/cuộc hội thoại. [MCP Resources](https://modelcontextprotocol.io/specification/2026-07-28/server/resources), [MCP Overview](https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2026-07-28/basic/index.mdx), kiểm 18/10/2026.

MCP tool schema/structured output và annotations hỗ trợ tích hợp; annotations vẫn không phải bộ cưỡng chế quyền. Dùng JSON Schema chặt, input/output limits và validation trong server. [MCP Tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools), kiểm 18/10/2026. Với HTTP production, thực hiện authorization flow phù hợp, kiểm token audience và không chuyển tiếp nguyên token nhận từ client sang upstream. [MCP Authorization](https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization), [MCP Security Best Practices](https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/security_best_practices), kiểm 18/10/2026.

Revision hiện hành có `ttlMs`/`cacheScope` cho resources/list/read. Với private hoặc revocable data phải scope cache theo principal và chọn TTL ngắn/không cache theo chính sách; **TTL transport không chứng minh nội dung pháp lý còn đúng**. Cần recheck quyền/revocation khi đọc và trước thực thi; bản export offline không thể tự bị thu hồi nên phải hiển thị version/as-of và có cách tra trạng thái hiện tại. [MCP Resources](https://modelcontextprotocol.io/specification/2026-07-28/server/resources), kiểm 18/10/2026.

## 11. Những đánh đổi không nên che đi

1. **Draft mới có ích so với kho đã duyệt chậm:** cho phép research đọc candidates với nhãn rõ; chỉ claim approved mới vào chế độ reuse đã duyệt. Đặt hàng đợi review theo rủi ro và nhu cầu, không hứa duyệt hết web.
2. **Giữ snapshot để kiểm toán so với quyền lưu/chi phí:** lưu phần được phép, excerpt/locator/hash đủ dùng; nếu không có quyền giữ raw, ghi rõ giới hạn tái hiện. Hash không tự cho biết nội dung nếu không còn snapshot.
3. **Granular invalidation so với phát triển nhanh:** MVP có thể invalidate rộng theo source/case version trước, an toàn nhưng tốn refresh; chuyển sang dependency field/passage khi có số liệu lãng phí. Đừng invalidate hẹp mà thiếu quan hệ.
4. **Một call intake+plan so với độ đúng:** schema gọn và templates có thể đủ; sự tự do planner quá lớn khiến một call khó kiểm, output bị cắt hoặc task lạc ý. Acceptance criteria quan trọng hơn số call đẹp.
5. **Public KB so với private learning:** có thể chia sẻ nguồn chung và mẫu đã duyệt; chưa cần “học từ toàn bộ khách hàng”. Nếu chưa có quyền tái dùng dữ liệu, bỏ việc cross-tenant reuse.
6. **Đồ thị so với MVP:** cần quan hệ rõ để trace và invalidate; chưa cần graph DB. Nếu export chỉ để trang trí và không trả được “kết luận này dựa vào đâu / đổi gì thì phải làm lại” thì chưa đạt.
7. **Automated freshness so với tiền và quyền:** muốn luôn hiện hành cần hoạt động kiểm lại. Có thể thông báo “cần kiểm lại” và chờ grant; không thể vừa hứa luôn mới vừa hứa không phát sinh call.

## 12. Tiêu chí kiểm thử cần có trước triển khai

Đây là bộ acceptance đề xuất; chưa viết hoặc chạy test trong lần nghiên cứu này.

| Nhóm | Tình huống bắt buộc | Kết quả cần thấy |
|---|---|---|
| Bám intent | Trà Sen yêu cầu FDA + English label | Hai outcome, nháp cấu trúc nhãn có placeholders chính xác; task generic không thay deliverable. |
| Bám intent | Mứt Sen hỏi ai/khi nào Prior Notice nhưng thiếu mode/ETA | Thu đúng field; form thể hiện unknown; không tự đưa deadline hoặc IOR/FSVP vào action nếu chưa có căn cứ liên quan. |
| Coverage | Bột Sen không có nguồn cert-specific | `no_support_found` giới hạn phạm vi; dossier hữu ích; câu hỏi tiếp theo về đặc tính/công dụng/kênh, không loop đòi tên cert. |
| Entailment | Nhiều nguồn official nhưng không hỗ trợ claim được hỏi | Gate từ chối claim; không dùng số passages, domain hay model confidence thay support. |
| Phiên bản | Cùng URL đổi nội dung; nguồn bị supersede/revoke | Snapshot mới, descendants được đánh dấu, artifact cũ giữ nguyên với trạng thái hiện tại rõ. |
| Applicability | Cùng wording khác market, actor, route, ngày hiệu lực hoặc product use | Không merge/reuse nhầm; thiếu điều kiện đưa về needs facts/review. |
| Trích dẫn | Thay excerpt hoặc bản dịch nhưng giữ source hash cũ | Validation fail; citation phải trỏ đúng snapshot/passage/hash được dùng. |
| Privacy | Caller tenant A thử ID/search/snippet/count/graph/export của B | Không trả nội dung hay existence/count private; private-derived claim không tự lên public. |
| Duyệt | Draft hoặc output vừa sửa được dùng làm approved | Từ chối phát hành; review gắn version/hash/scope cụ thể. |
| Chi phí | Hai worker cùng dùng phần budget cuối | Reservation transaction ngăn vượt cap đã cấu hình; spent/reserved/unknown tách rõ. |
| Crash | Kill sau dispatch paid request, trước khi lưu output | `outcome_unknown`, không tự SDK retry/restart/replay; không ghi cost=0. |
| Idempotency | Gửi start hai lần hoặc cùng key khác payload | Một run cho cùng request; conflict với payload khác. |
| Race | Revoke consent/cancel/case update ngay trước publish | Recheck transaction chặn artifact mới; run có lý do rõ. |
| Bounded planner | Task cycle, node quá nhiều, URL/model/tool lạ, output schema lệch | Validator chặn trước dispatch; không “cố chạy cho xong”. |
| Untrusted content | Source/Markdown có chỉ thị gửi dữ liệu hoặc tự approve | Nội dung được coi là dữ liệu; grant/tool không mở rộng. |
| Hồi quy reuse | Chạy cùng intent cùng input/version, rồi thay một dependency | Cache hit lần đầu có provenance; lần sau miss/gate lại đúng dependency. |
| Khả năng đọc | Markdown form/report render từ typed payload rồi người sửa file | Không âm thầm đổi DB/approval; muốn nhập lại tạo draft revision. |

## 13. Phạm vi nên làm ở v0.3 và nên để sau

**v0.3:** IntentRevision/Mission gọn; plan templates và bounded TaskDAG; execution grant và invocation ledger; SourceSnapshot/Evidence giữ exact provenance; reusable templates + kho claim tuyển tay nhỏ; applicability gate; Markdown read model; relation table và graph JSON/Mermaid; review/invalidation events; kiểm ba ca theo outcome.

**Sau khi có bằng chứng nhu cầu:** multi-LLM fan-out, embedding retrieval, property graph DB, generic docstore, deployment nhiều worker/host, tự động refresh trả phí hoặc trao đổi tác vụ với agent bên ngoài. Mỗi thứ cần một bottleneck/benefit đo được và quyền rõ ràng, không chỉ một tên công nghệ trong kiến trúc.


## 14. Rà lại bản tích hợp 01/02/03

Đã đọc lại ba tài liệu chính ngày 18/10/2026. Không còn blocker về ranh giới typed data/Markdown/graph, applicability/reuse, coverage gap hoặc hai loại grant. 02 đã nêu parse toàn schema trước khi chia phần hợp lệ, review gắn version/hash/scope, source invalidation chỉ sau khi quan sát, và dossier không thay đáp án chứng nhận. Khi triển khai cần giữ thêm ba chi tiết: dispatch marker bền vững trước network; promotion không được đơn thuần xóa private lineage; export đã tải ra máy người dùng không thể bị thu hồi vật lý nên phải có as-of/version và cách tra trạng thái hiện tại. Những nhận xét này không làm thay đổi ứng dụng hoặc cho phép paid call.

