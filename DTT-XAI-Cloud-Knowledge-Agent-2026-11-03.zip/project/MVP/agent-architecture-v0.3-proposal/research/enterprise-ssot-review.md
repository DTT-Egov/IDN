# Review bổ sung: SSOT doanh nghiệp và cá nhân hóa xuyên hội thoại

**Đề xuất thiết kế · 18/10/2026 · chưa triển khai.** Phạm vi là đọc 01/02/03 và đề xuất cho kiến trúc 0.3; không gọi provider, không sửa ứng dụng, không tạo lịch refresh. Theo ranh giới hiện trạng của lượt review này, ứng dụng local 0.2 mới có identity theo browser profile; không được mô tả nó như tài khoản, membership hoặc SSOT doanh nghiệp đã hoạt động.

## Ba rủi ro thiết kế cần xử lý trước

1. **Nhầm nơi chứa dữ liệu với danh tính doanh nghiệp.** `tenant`, browser profile, conversation owner và doanh nghiệp không đồng nghĩa. Nếu profile trên máy khác tạo tenant khác, dữ kiện không nối được; nếu chỉ gom nhiều người vào tenant mà thiếu membership/ACL, dữ kiện riêng có thể bị lộ. SSOT xuyên hội thoại phải bắt đầu từ `enterprise_id` bền vững và principal đã xác thực, không bắt đầu từ tìm kiếm toàn bộ chat.
2. **Có snapshot nhưng thiếu dữ kiện hiện hành theo entity/field.** Snapshot giải thích một run đã dùng gì; nó không giải quyết được công thức nào đang có hiệu lực, ai sửa ETA, tài liệu nào có quyền quyết định trường đó, hoặc hai người đang khai khác nhau. Không được chọn tin nhắn mới nhất, câu model chắc nhất hay báo cáo gần nhất làm sự thật mặc định.
3. **Trộn bộ nhớ doanh nghiệp với tri thức nghiệp vụ dùng chung.** Dữ kiện riêng, quyết định, sở thích và claim/rule công khai có cơ chế tin cậy/refresh khác nhau. “Agent đã học” không cho phép biến công thức, người mua hay kết luận của doanh nghiệp A thành kiến thức cho doanh nghiệp B. Xóa tên doanh nghiệp cũng chưa chứng minh một record đủ độc lập để chia sẻ.

## SSOT có nghĩa cụ thể gì?

SSOT là một đường đọc/ghi có thẩm quyền cho **dữ kiện hiện hành trong đúng phạm vi và thời điểm**, có thể truy về các lời khai và chứng cứ. Nó không có nghĩa chỉ tồn tại một tài liệu hoặc mọi giá trị lưu đều đúng khách quan. Một giá trị doanh nghiệp đã xác nhận vẫn phải phân biệt với giá trị đã đối chiếu tài liệu hay xác minh độc lập.

Ba lớp riêng:

| Lớp | Nội dung | Nơi có quyền quyết định |
|---|---|---|
| Hồ sơ doanh nghiệp hiện hành | Entity, trường hiện hành, phiên bản, phạm vi hiệu lực, nguồn, quyết định phân giải | Repository dữ kiện typed + policy từng trường |
| Lịch sử công việc | Mission, lời trao đổi, snapshot, artifact, quyết định khi đó | Bản revision đã lưu; không âm thầm cập nhật theo hồ sơ mới |
| Tri thức nghiệp vụ dùng lại | Nguồn/claim/rule/template có scope, nguồn gốc và phiên bản | Kho nghiệp vụ có review/release và reuse gate |

Thêm sở thích người dùng như một lớp riêng phục vụ cá nhân hóa. Không dùng sở thích để thay giá trị pháp lý, công thức sản phẩm hoặc quyền thực thi.

## Đối tượng tối thiểu đề nghị

Tên đối tượng là mô hình logic; chưa phải DDL hay cam kết mỗi dòng thành một service.

| Đối tượng | Trường/quan hệ cần có | Ràng buộc |
|---|---|---|
| `Principal`, `Enterprise`, `Membership` | Account ID; enterprise ID; vai trò, trạng thái và giới hạn quyền | Server xác thực và resolve membership. `current_enterprise` chỉ là lựa chọn giao diện, không là bằng chứng quyền. Browser profile chỉ có thể là cache/demo identity |
| `EnterpriseEntity` | ID ổn định, enterprise ID, loại, alias, revision, ACL | Loại đầu tiên: doanh nghiệp, sản phẩm/biến thể, cơ sở, lô hàng. Cùng tên không đủ để merge; quan hệ sản phẩm–cơ sở–lô hàng phải có ref tường minh |
| `FactAssertion` | Entity/field/value, trạng thái hiểu biết, đơn vị/ngôn ngữ nếu cần, source refs, actor, observed/recorded time, valid interval, sensitivity | Lưu điều được khai và chứng cứ; không phải mọi assertion đều thành giá trị hiện hành. Lời user, tài liệu và inference có origin khác nhau |
| `FieldAuthorityPolicy` | Entity type/field, ai được cập nhật, loại nguồn ưu tiên, điều kiện xác nhận, freshness, conflict rule | Không có thứ tự “tài liệu luôn thắng chat” cho tất cả trường. ETA có thể theo bản xác nhận chuyến; công thức theo revision có thẩm quyền; cách xưng hô theo người dùng |
| `FactResolution` / `CurrentFact` | Assertion được chọn, trạng thái, revision, valid interval, lý do/policy và người quyết định | Một projection hiện hành trên tập assertion. Unique trong cùng enterprise + entity + field + scope + thời điểm; cập nhật có compare-and-set, không last-write-wins mù |
| `Preference` | Subject user/enterprise, key/value, explicit/inferred, phạm vi, nguồn, hiệu lực và thao tác undo | Ưu tiên ràng buộc của lời hiện tại; preference theo mission → user → doanh nghiệp theo policy. Inference không có quyền ghi đè preference explicit |
| `DecisionRecord` | Quyết định, người có quyền, lựa chọn, lý do, phạm vi, refs input/version, hiệu lực/điều kiện xét lại | “Chọn đại lý A cho lô X” không thành “đại lý A là đối tác duy nhất của doanh nghiệp”. Quyết định không tự là sự thật về thế giới |
| `ContextSnapshot` + `ContextSelection` | Enterprise/principal/entity refs; fact/preference/decision revisions; missing/conflict states; query purpose; as-of/version | Bất biến sau khi plan/run sử dụng. Giữ tập input nhỏ đủ giải outcome, không đưa cả lịch sử vào prompt |
| `Dependency` + `ChangeEvent` | Input field/claim/rule revision → outcome/task/artifact; thời điểm, lý do, phạm vi ảnh hưởng | Phát hiện phần cần rà/tính lại, không sửa bản cũ hoặc tự chạy model |
| `DomainKnowledgeRecord` | Claim/rule/template, scope/điều kiện, nguồn công khai được phép, review/release, hiệu lực/refresh | Không mang fact/preference/decision riêng trong record dùng chung hoặc trong embeddings/index dùng chung |

Các trạng thái trường cần tách: `unknown` (chưa có dữ kiện), `known_absent` (đã khai là không có), `not_applicable` (có căn cứ điều kiện không áp dụng), `withheld` (không cung cấp), `conflicted`, `expired`. Không dùng một `null` để biểu diễn tất cả. Mỗi trạng thái khẳng định vẫn cần nguồn/actor và scope; model không tự chuyển unknown sang known-absent.

Giữ hai trục thời gian: **được ghi nhận khi nào** và **đúng cho khoảng thời gian nào**. Tài liệu tải lên hôm nay có thể mô tả công thức đã ngừng dùng; một thay đổi có thể chỉ có hiệu lực từ lô sản xuất tháng sau. Bản sửa hồi tố ghi rõ là correction, không viết lại lịch sử cũ.

## Luồng cập nhật dữ kiện doanh nghiệp

`capture → candidate → resolve/confirm khi cần → promote current fact → chốt snapshot cho công việc → đánh dấu phần phụ thuộc khi thay đổi`

1. **Capture:** gắn lời hiện tại/tài liệu với đúng enterprise, entity và actor đã được kiểm quyền. Câu “đổi sang 250g” phải biết đang sửa biến thể/bao gói hay chỉ một nhãn nháp. Nếu chưa rõ, chỉ giữ candidate trong mission và hỏi một câu có ảnh hưởng.
2. **Candidate:** trích field + value + nguồn nguyên văn; giữ `inferred` riêng. Nội dung tài liệu là dữ liệu, không có quyền ra lệnh đổi policy/ACL hoặc ghi đè hồ sơ.
3. **Resolve/confirm:** áp policy từng trường. Tuyên bố explicit, đúng quyền, rõ scope, rủi ro thấp có thể cập nhật ngay và báo ngắn. Trường trọng yếu, sửa ngược tài liệu chuẩn, nhập hàng loạt hay có xung đột cần xác nhận phù hợp. Không bắt người dùng duyệt mọi sở thích nhỏ.
4. **Promote:** transaction thêm assertion/resolution/revision và change event; kiểm revision gốc. Hai cập nhật đồng thời phải báo xung đột hoặc rebase theo policy, không âm thầm mất một thay đổi. Quyền promote lấy từ server; worker chỉ đề xuất candidate.
5. **Snapshot:** trước lập/duyệt kế hoạch, query các trường cần cho outcome và chốt refs/version. Fact `conflicted/expired` không được nạp như một giá trị chắc chắn. Nếu correction ảnh hưởng input sau khi plan đã duyệt nhưng chưa dispatch, revalidate và báo delta cần thiết; không âm thầm chạy plan cũ như thể dùng dữ kiện mới.
6. **Invalidate:** field đổi chỉ đánh dấu các output có dependency liên quan. Output cũ giữ nguyên nội dung/as-of, thêm trạng thái “cần rà theo dữ kiện mới”. Lượt tính lại tạo revision mới trong quyền/ngân sách phù hợp. Mở bản cũ không chạy AI.

Ví dụ: người dùng sửa lượng tịnh Trà Sen từ 200g thành 250g trong chat mới. Hệ thống xác định đúng biến thể, ghi nguồn user/correction và revision mới; nhãn mới lấy 250g. Bản nhãn/run cũ vẫn giữ 200g và lineage cũ, đồng thời hiện chỉ báo có thay đổi. Không tự sửa lượng tịnh Mứt Sen hay lô hàng đã chốt 200g.

## Cá nhân hóa phải giúp giảm thao tác

Ở chat mới, bộ chọn ngữ cảnh resolve đúng doanh nghiệp và entity, rồi lấy ít dữ kiện nhất để giải các outcome. Ví dụ hỏi nhãn chỉ cần hồ sơ nhãn/sản phẩm và cơ sở liên quan theo quyền; không cần giá mua, danh sách mọi khách hàng hay toàn bộ hội thoại. Query/retrieval lọc quyền trước; model không nhận record trái quyền dù sau đó UI có ẩn.

Ngữ cảnh có thể trả cả fact và khoảng trống: “Đã có lượng tịnh 250g; công thức hiện có hai bản đang chờ chốt.” Có thể tiếp tục hướng dẫn chung hoặc tạo mẫu với ô thiếu; không buộc chốt cả hồ sơ doanh nghiệp trước khi trả lời.

“Từ nay trả lời ngắn bằng tiếng Việt” là preference explicit, rủi ro thấp: lưu đúng user/scope và phản hồi một dòng có sửa/hoàn tác. Thường xuyên chọn bản ngắn là tín hiệu inferred: dùng có giới hạn và cho đổi; không biến thành consent, người có quyền ký, giới hạn tiền hoặc lệnh gửi ngoài. Yêu cầu hiện tại “giải thích kỹ lần này” thắng preference ngắn, không nhất thiết sửa preference lâu dài.

Giao diện mobile giữ trả lời chính trước. Chỉ hỏi về xung đột đang làm thay đổi câu trả lời/hành động; phần “Hồ sơ đang dùng” có thể mở để xem nguồn, sửa, ngừng dùng hoặc chọn scope. Không biến mỗi tin nhắn thành màn hình duyệt bộ nhớ.

## Identity, quyền và xóa dữ liệu

- `enterprise_id` không nhận theo lời model hoặc tin tưởng raw request. Principal → membership → resource/field ACL quyết định quyền cho chat, entity, snapshot, search/index, artifact, export và worker brief. Một thành viên doanh nghiệp chưa chắc đọc được mọi lô hàng hoặc dữ liệu cá nhân của thành viên khác.
- Mặc định private theo enterprise; dữ liệu cá nhân có scope hẹp hơn. Cache và index mang enterprise + quyền + revision; không chỉ key theo tên sản phẩm. Thu hồi membership phải chặn cả materialize/read và dùng lại qua job đang chờ.
- Liên kết browser profile local sang account/doanh nghiệp tương lai cần flow migration xác định ownership và chọn dữ liệu muốn nhập. Không tự merge hai profile vì cùng tên/email trong nội dung chat; không giả provenance/membership cho dữ liệu cũ.
- Tách quyền ghi nhớ, quyền đọc của đồng nghiệp, quyền chia sẻ và quyền gửi dữ liệu cho provider. Cho phép chỉ dùng trong mission, lưu lâu dài, sửa, ngừng dùng và yêu cầu xóa; preference tiện lợi không mở rộng consent hoặc quyền thực thi.
- Xóa/ngừng dùng phải xử lý cả fact resolution, candidate, index, cache, snapshot/artifact dẫn xuất và export do server quản lý theo policy lưu giữ được nêu rõ. Lưu tombstone/audit tối thiểu khi được phép; không hứa snapshot bất biến là lý do giữ mọi nội dung riêng mãi mãi. Không hứa thu hồi được bản tải offline hay xóa phía provider khi chưa có cơ chế tương ứng.

## Dùng lại nghiệp vụ cho doanh nghiệp khác và refresh

Giữ các reuse gate đã có ở 02, thêm gate phân loại kho. Nguồn/claim/rule dùng chung phải đứng độc lập bằng nguồn được phép, được rà và phát hành version. Học từ ca riêng có thể sinh **đề xuất** sửa template/quy trình hoặc ca kiểm tổng hợp an toàn; không đưa nguyên nội dung cuộc chat vào kho chung. Kết luận phù hợp doanh nghiệp A phải được đánh giá lại với dữ kiện B.

Refresh có hai dòng khác nhau:

| Loại thay đổi | Trigger đề nghị | Kết quả |
|---|---|---|
| Dữ kiện doanh nghiệp | User correction, tài liệu mới, người có quyền cập nhật, hết hạn trường | Tạo assertion/resolution mới hoặc đánh dấu stale/conflict; hỏi đúng người khi cần |
| Tri thức nghiệp vụ | Đến hạn kiểm, phát hiện nguồn/phiên bản mới, thu hồi, nhu cầu reuse ngoài scope/hiệu lực đã có | `needs_refresh`/`needs_review`; tìm lại phần nguồn bị ảnh hưởng trong capability/quyền/ngân sách cho phép |

TTL chỉ cho biết đã đến lúc kiểm, không chứng minh nguồn đổi hoặc vẫn đúng. Fetch mới có hash khác chưa chứng minh diễn giải mới đã đúng. Giữ snapshot nguồn, diff và trạng thái review; code chỉ tái dùng rule đã mô hình hóa khi các predicate còn thỏa. Nếu không refresh được, nêu rõ as-of/gap và tránh kết luận riêng cần nguồn hiện hành.

Với 0.3, refresh có thể diễn ra khi query hoặc khi người dùng yêu cầu trong phạm vi được phép. Chưa cần cam kết theo dõi Internet liên tục; thiết kế này không tạo automation hoặc tự cấp quyền gọi có phí.

## Cửa nghiệm thu bổ sung

1. **Xuyên phiên thật:** cùng account + enterprise trong chat khác/thiết bị khác đọc lại field đã xác nhận theo quyền; tài khoản khác hoặc doanh nghiệp khác không nhận được. Test này cần membership thật, không được coi đổi tab cùng browser profile là đủ.
2. **Sửa đúng thực thể:** đổi lượng tịnh một biến thể tạo revision mới; mission mới nhận giá trị mới. Bản cũ giữ value/input refs/as-of; sản phẩm/lô khác không thay theo.
3. **Concurrent edit:** hai thành viên có quyền sửa cùng field từ cùng revision; hệ thống không mất thay đổi, hiển thị xung đột và nguồn. Nếu một người không có quyền promote thì chỉ tạo candidate hoặc bị từ chối theo policy.
4. **Known-null và thời gian:** chưa khai thành phần không thành “không có dị nguyên”; declared absent khác unknown; công thức hiệu lực tháng sau không áp vào lô tháng trước; thông tin expired không được coi là current chỉ vì tin nhắn mới mở lại.
5. **Ngữ cảnh tối thiểu:** hỏi nhãn chỉ nạp field/claim cần thiết và quyền tương ứng; tên sản phẩm giống nhau giữa hai doanh nghiệp không khiến entity bị merge hoặc rò rỉ qua retrieval/cache.
6. **Cá nhân hóa nhẹ:** explicit preference được dùng ở phiên sau với scope đúng; chỉ dẫn hiện tại thắng; inferred preference không sửa consent/ngân sách/quyền; không hiện câu hỏi xác nhận sau mọi tin nhắn.
7. **Reuse nghiệp vụ:** hai doanh nghiệp dùng cùng rule/version khi gate thỏa; formula, ETA, người mua, preference và kết luận riêng không đi theo. Candidate/private-derived claim không tự được promote vào thư viện chung.
8. **Refresh có giới hạn:** nguồn mới làm stale đúng dependency; failed refresh không thành “không có yêu cầu”; không sửa bản report cũ hoặc tự gọi model khi mở lịch sử. Chi phí và quyền tiếp tục theo ledger/grant của 02.
9. **Thu hồi/xóa:** revoke membership hoặc xóa trường chặn lookup/worker/export/cache liên quan; nội dung snapshot được xử lý theo policy lưu giữ/xóa, không rò qua bản render cũ do server còn phục vụ.

## Đưa vào 0.3 ở mức nào?

Chốt enterprise/principal/membership và giới hạn ACL trước khi tuyên bố SSOT nhiều người. Bắt đầu với entity + assertion + current resolution + source refs + context snapshot + dependency; dùng kho quan hệ hiện có với migration/ràng buộc typed. Chưa cần vector DB, graph DB hay một agent chuyên ghi bộ nhớ.

MVP có thể chỉ hỗ trợ một số trường của ba ca và preference explicit; mọi field chưa có policy vẫn candidate/mission-only. Thêm đường nhập/sửa/xem hồ sơ có nguồn và các ca nghiệm thu trên. Nếu identity vẫn local, ghi rõ đây là bản thử cá nhân theo profile, chưa đạt SSOT doanh nghiệp xuyên tài khoản.
