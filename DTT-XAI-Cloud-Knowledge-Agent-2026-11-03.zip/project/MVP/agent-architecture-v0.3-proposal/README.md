# Đề xuất kiến trúc Agent nMate 0.3

**18/10/2026 · hồ sơ thiết kế để thảo luận, chưa triển khai.** Học từ review nhiều vòng, rà mã v0.2 và ba ca mobile giả lập. Chỉ tạo tài liệu; không sửa app, khởi động server hoặc gọi API mô hình của ứng dụng.

Đọc [01 — Thiết kế tổng quan](<01_Thiet_ke_kien_truc_Agent.md>) trước. Hai tài liệu còn lại dành cho chốt triển khai và kiểm đầu ra:

1. [02 — Đặc tả 0.3 và lộ trình](<02_Dac_ta_MVP_0_3_va_lo_trinh.md>): objects/state, grant/ledger, reuse, MCP, migration và nghiệm thu.
2. [03 — Ba ca tham chiếu và hợp đồng giao việc](<03_Ba_ca_tham_chieu_va_hop_dong_cong_viec.md>): Trà Sen, Mứt Sen, Bột Sen; mẫu nhãn/phiếu/dossier và AgentBrief.
3. **[04 — SSOT doanh nghiệp và tri thức domain](<04_SSOT_doanh_nghiep_va_tri_thuc_domain.md>)**: bổ sung yêu cầu tích lũy hiểu biết để cá nhân hóa, dùng lại giữa doanh nghiệp và refresh có điều kiện. Là bản chuẩn cho phần memory/personalization được làm rõ sau 01–03.

## Các quyết định đề xuất

| Quyết định | Lý do thực tế |
|---|---|
| Một mission orchestrator + capability/domain packs có giới hạn | Người dùng chỉ gặp một trợ lý; thêm ngành/use case không cần nhân bản toàn bộ app |
| Outcome contract trước task plan; task count biến đổi | Ba việc cố định làm loãng câu hỏi; worker task khác việc con người nhìn thấy |
| 0.3 chọn template DAG đã kiểm, chưa planner tự sinh graph bất kỳ | Đủ linh hoạt cho ba ca, vẫn kiểm được nguồn, budget và dependency |
| SQLite + typed JSON chuẩn; Markdown/graph JSON là projections | Đọc/bàn giao được và vẫn giữ schema, version, quyền, truy vết; chưa cần graph DB riêng |
| Enterprise SSOT riêng + Domain Knowledge dùng lại theo quyền | Không hỏi lại điều đã biết; dữ kiện riêng có resolver/phiên bản; claim chung áp lại cho đúng DN và refresh khi cần |
| Tái dùng claim có điều kiện, không sao chép cả report | Quy tắc chung có thể dùng lại; dữ kiện/kết luận riêng không tự chuyển sang ca khác |
| Kiểm prepare grant trước intent call; execution grant sau plan | Không phí ngầm, không vòng tròn quyền; ledger giữ outcome_unknown, không tự retry paid |
| Giữ snapshot/idempotency/evidence guards hiện có | Refactor từng phần; không viết lại nền tốt hoặc sửa report cũ |
| Completion nhiều tầng và answer-first | Artifact đúng loại, từng ý có câu trả lời/gap; dossier không thay đáp án chứng nhận |

## Hồ sơ phân tích làm căn cứ

- [Rà hiện trạng và nguồn mã](<research/current-state.md>).
- [Bài học nhiều vòng review và kịch bản](<research/lessons-and-scenarios.md>).
- [Bộ nhớ, quan hệ và hợp đồng dữ liệu](<research/memory-and-contracts.md>).
- [Phản biện Enterprise SSOT](<research/enterprise-ssot-review.md>) và [domain refresh](<research/domain-refresh-review.md>).

Các file research là ghi chú phân tích/nguồn; tên schema/tool đề nghị có thể khác nhau ở mức phác thảo. Tài liệu 01–04 là bản tổng hợp ưu tiên nếu có cách gọi khác; 04 làm rõ phần SSOT/domain/refresh. Các API/module mới trong đó đều là đề xuất, không phải khả năng hiện đã triển khai.

## Nguồn kỹ thuật chính thức đã đối chiếu

Kiểm đọc ngày **18/10/2026**; không gọi API model. Phần quyết định riêng cho nMate là đề xuất từ các ca thực tế, không phải khẳng định các tài liệu sau bắt buộc một kiến trúc duy nhất.

- [LangGraph workflows and agents](https://docs.langchain.com/oss/python/langgraph/workflows-agents): khái niệm workflow/agent và orchestrator-worker.
- [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence): phân biệt checkpoint theo thread và store xuyên thread.
- [LangGraph interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts): pause/resume và việc node có thể chạy lại từ đầu.
- [Anthropic — Building effective agents](https://www.anthropic.com/engineering/building-effective-agents): cơ sở cân nhắc đơn giản/phức tạp.
- [MCP tools](https://modelcontextprotocol.io/specification/2026-07-28/server/tools), [MCP resources](https://modelcontextprotocol.io/specification/2026-07-28/server/resources): structured contract và resource access. Quyền/chi phí nghiệp vụ vẫn phải cưỡng chế trong server.

Chưa chạy benchmark, kiểm mô hình thật, triển khai schema mới hay đánh giá hiệu quả reuse trên dữ liệu thật. Ba ca hiện chứng minh vấn đề và giúp thiết kế bộ nghiệm thu; chúng chưa chứng minh kiến trúc 0.3 đã hoạt động.
