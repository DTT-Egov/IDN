# Hai lớp tri thức tích lũy: SSOT doanh nghiệp và tri thức domain

**Bổ sung thiết kế 0.3 theo yêu cầu người dùng · 18/10/2026 · chưa triển khai.** Tài liệu này làm rõ các phần memory trong 01–03. Mục tiêu là mỗi lần phục vụ đều sử dụng hiểu biết phù hợp đã tích lũy, bổ sung phần mới và làm mới phần cần thiết. Không có thao tác cập nhật dữ liệu thật, gọi API mô hình hoặc tạo lịch refresh trong lượt thiết kế này.

## 1. Hai lớp tri thức, một lớp áp dụng riêng

| Lớp | Giữ gì | Phạm vi sử dụng |
|---|---|---|
| **Enterprise SSOT** | Hồ sơ, sản phẩm/phiên bản, cơ sở, năng lực, tài liệu, quyết định, quan hệ, dữ kiện và tùy chọn của đúng doanh nghiệp | Xuyên hội thoại/nhiệm vụ/thiết bị của thành viên được phép; không chia sẻ sang doanh nghiệp khác |
| **Domain Knowledge Library** | Nguồn, nhận định có điều kiện, quy tắc, thuật ngữ, template và bài học nghiệp vụ đã được kiểm/phân quyền | Dùng lại cho nhiều doanh nghiệp trong đúng scope và quyền tái sử dụng |
| **Case/Mission Findings** | Kết quả áp dụng domain knowledge vào một phiên bản dữ kiện của một doanh nghiệp | Vẫn riêng tư; không tự biến thành tri thức chung |

**SSOT là nơi giải quyết có thẩm quyền dữ kiện nào đang được dùng, với nguồn và trạng thái rõ; không phải mọi câu đã nói đều trở thành sự thật đã xác minh.** Một doanh nghiệp xác nhận công thức để soạn nháp có thể là `self_declared`; không vì thế được coi đã có kiểm nghiệm hay xác minh bên ngoài.

```mermaid
flowchart TD
    U[Hội thoại, tài liệu và cập nhật được phép] --> A[Lời khai và đề xuất dữ kiện]
    A --> F[Kiểm entity, quyền, nguồn và mâu thuẫn]
    F --> E[Enterprise SSOT có phiên bản]
    E --> X[Chọn ngữ cảnh phù hợp với mục tiêu]
    D[Domain Knowledge có phạm vi và nguồn] --> R[Kiểm quyền, độ mới và khả năng áp dụng]
    X --> R
    R --> P[Kế hoạch, nghiên cứu phần thiếu và đầu ra cá nhân hóa]
    P --> C[Finding và artifact riêng của doanh nghiệp]
    C --> A
    S[Nguồn dùng chung được phép] --> Q[Kiểm nhận định và điều kiện tái sử dụng]
    Q --> D
    D --> H[Refresh khi cần và được phép]
    H --> Q
```

Nhánh C→A chỉ tạo cập nhật có nguồn và trạng thái; không ghi đè SSOT tự động bằng kết luận của model. Một trường hợp cụ thể có thể gợi ý vấn đề nghiên cứu chung; bản ghi dùng chung mới vẫn cần chứng minh độc lập bằng nguồn được phép, không lấy dữ kiện riêng làm bằng chứng chung.

## 2. SSOT phải thuộc doanh nghiệp, không thuộc một cuộc chat

Định danh tối thiểu gồm `enterprise_id`, `principal_id`, `membership/role` và quyền resource. Một tenant có thể chứa nhiều doanh nghiệp; một người có thể làm việc với nhiều doanh nghiệp. Chủ thể đang phục vụ phải được xác định rõ. Tên công ty hoặc tên sản phẩm giống nhau không đủ để gộp dữ liệu.

Mission, context snapshot, prepare/execution grant và idempotency namespace phải bind `enterprise_id` ổn định được server xác lập qua membership. Chuyển doanh nghiệp trên UI không rebind mission/grant cũ. Private entity/source/finding refs phải đúng enterprise và resource ACL; nguồn domain public/licensed được dùng qua quyền tương ứng, không cần giả gắn nó làm tài sản riêng của mọi doanh nghiệp.

Ứng dụng local v0.2 hiện cách ly theo browser profile, chưa có cơ chế tài khoản/membership doanh nghiệp hoàn chỉnh. Muốn đạt SSOT xuyên thiết bị/người dùng phải bổ sung định danh và quyền doanh nghiệp; không được mô tả profile hiện tại là đã đáp ứng yêu cầu này. Hồ sơ legacy chỉ được gắn/chuyển vào doanh nghiệp sau khi chứng minh quyền và thao tác có chủ đích, không merge tự động theo tên.

Các entity nên có ID riêng: doanh nghiệp; cơ sở; sản phẩm/SKU/biến thể; phiên bản công thức/bao gói; người và vai trò; tài liệu; thị trường/mục tiêu; quan hệ đối tác; lô hàng. Một doanh nghiệp có nhiều cơ sở/sản phẩm; cùng doanh nghiệp không có nghĩa cùng công thức, nhãn hoặc điều kiện áp dụng.

### Những gì cần tích lũy

- **Dữ kiện tương đối ổn định:** thông tin doanh nghiệp, cơ sở, người phụ trách, năng lực và hồ sơ sản phẩm.
- **Dữ kiện có thời hạn/phiên bản:** công thức, bao gói, tài liệu/chứng nhận tự khai, hiệu lực giấy tờ, mục tiêu và quyết định đang áp dụng.
- **Dữ kiện theo giao dịch:** người nộp, ETA, số lượng, nơi lấy/giao; lưu ở lô/giao dịch phù hợp, không thành mặc định cho mọi lô.
- **Tùy chọn:** ngôn ngữ, cách xưng hô, cách nhận kết quả, mức chi tiết; tách preference cá nhân khỏi chính sách chung doanh nghiệp.
- **Lịch sử công việc:** mục tiêu, quyết định, lý do, artifact đã sửa, phần đang thiếu và việc đã thực sự hoàn thành.

Nhận xét suy ra như “có vẻ thích câu trả lời ngắn” là preference candidate. Nó không sửa consent, quyền chia sẻ hoặc ngân sách. Doanh nghiệp từng hỏi Mỹ không khiến mọi lần sau mặc định thị trường Mỹ khi yêu cầu mới nói EU.

## 3. Dữ kiện chuẩn, lịch sử và mâu thuẫn

| Object đề xuất | Trường quan trọng | Vai trò |
|---|---|---|
| `EnterpriseEntity` | enterprise/entity ID, type, ACL, active revision | Xác định đúng sản phẩm/cơ sở/người/lô |
| `FactAssertion` | entity+field, value, value_state, source/quote/document ref, actor, certainty, valid_from/to, recorded_at | Giữ điều được cung cấp hoặc quan sát; không tự là giá trị hiện hành |
| `FieldAuthorityPolicy` | field/type, người được sửa, nguồn được chấp nhận, rule mâu thuẫn và xác nhận | Thẩm quyền theo trường, không một luật “câu mới nhất thắng” |
| `FactResolution` | assertion refs, chọn/supersede/conflict, actor/policy version, lý do | Truy vết vì sao dùng giá trị này |
| `CurrentFact` | entity+field+as_of, effective assertion/ref, resolution ref, review/freshness state | Projection chuẩn để ứng dụng đọc, có thể dựng lại từ lịch sử |
| `EnterpriseContextRevision` | facts/decisions/preferences refs, version/hash, as_of | Snapshot đã dùng cho một mission/run |

Phân biệt thời điểm dữ kiện có hiệu lực (`valid_time`) với thời điểm hệ thống biết nó (`recorded_time`). Hai assertion khác thời kỳ không nhất thiết mâu thuẫn. Hai nguồn cùng thời kỳ khác giá trị cần resolution; model không tự chọn chỉ vì một nguồn dài hơn hoặc confidence cao hơn.

`unknown`, `known_absent`, `not_applicable`, `withheld`, `conflicted` là các trạng thái khác nhau. Freshness/expiry là một trục riêng: một dữ kiện từng đúng có thể cần kiểm lại. Null không tự xóa dữ kiện đã biết; danh sách trống không tự có nghĩa chưa từng có giấy tờ. “Chưa có” do doanh nghiệp khai vẫn giữ nguồn và mức xác minh đó.

Ví dụ: “Lô này dùng thùng 40 × 30 × 25” chỉ cập nhật đúng cấu hình/lô. “Từ nay bao gói của SKU X đổi…” tạo phiên bản bao gói có thời điểm hiệu lực. Không đổi mọi sản phẩm cùng doanh nghiệp. Địa chỉ vận hành tự khai và địa chỉ pháp lý trên giấy tờ có thể là hai field khác nhau, thay vì ghi đè để hết xung đột.

### Luồng cập nhật

1. **Capture:** lấy assertion từ lời/tài liệu được phép, giữ nguồn và entity/scope.
2. **Validate:** kiểm schema, grounding, thời gian, quyền trường và bản hiện hành.
3. **Resolve:** cập nhật rõ ràng, ít rủi ro từ người có quyền có thể áp theo policy và cho sửa/hoàn tác; dữ kiện mâu thuẫn hoặc ảnh hưởng lớn đưa một thẻ xác nhận gọn. Không bắt xác nhận lại mọi chi tiết đã cấp quyền.
4. **Promote:** một transaction kiểm version/CAS, lưu resolution và current revision. Model không có đường ghi SQL trực tiếp hoặc tự cấp approval.
5. **Snapshot:** mission đóng băng đúng refs/hash đã dùng; câu trả lời mới sử dụng revision mới khi hợp lệ.
6. **Impact:** đánh dấu finding/artifact phụ thuộc cần rà, không viết lại báo cáo lịch sử.

Hai người sửa cùng field không được ghi đè im lặng. Sửa sai phải supersede/tombstone theo policy, xóa giá trị khỏi current context/index; nghĩa vụ lưu/xóa lịch sử cần được thực thi nhất quán với quyền dữ liệu, không lấy “append-only” làm lý do bỏ yêu cầu xóa hợp lệ. Bản export đã tải xuống vẫn có giới hạn thu hồi đã nêu ở 02.

## 4. Cá nhân hóa mỗi lần phục vụ

Pipeline bổ sung:

`resolve enterprise/membership → lấy ngữ cảnh tối thiểu được phép → hiểu intent → truy vấn thêm field cần cho outcome → snapshot → plan + domain lookup → thực thi → ghi finding/đề xuất cập nhật`

`EnterpriseContextResolver` trả một `PersonalizationContext` ngắn: đúng entity; facts và provenance/trạng thái; quyết định còn áp dụng; công việc/tài liệu liên quan; preference được phép; mâu thuẫn/dữ kiện cũ cần hỏi. Không nhét toàn bộ lịch sử vào prompt. Các field chứa dữ liệu không được phép gửi provider bị loại tại ranh giới tạo context, không chỉ ẩn trên UI.

Snapshot/finding/artifact dẫn xuất phải giữ giới hạn read/use/export từ các input; cùng doanh nghiệp không tự có quyền mọi field. Lúc materialize/read phải kiểm lại ACL và thu hồi quyền hiện tại, không chỉ quyền lúc tạo. Chia sẻ rộng hơn cần cấp quyền rõ hoặc một revision được tạo lại từ input được phép/redaction đã kiểm; không xóa lineage để coi output là công khai. Body, nguồn dẫn, metadata, graph và bản dịch đều phải theo cùng giới hạn.

Context được đóng băng theo refs/phiên bản nhất quán cho mission. Trước dispatch và publish, kiểm quyền/consent/membership hiện tại và các fact/policy refs liên quan. Nếu một fact cần dùng đã bị sửa khi run đang chạy, không phát hành kết quả cũ như current/ready: chuyển needs_revalidation hoặc giữ as-of cho người còn quyền, chỉ ra phần ảnh hưởng. Không tự rerun model. Field không liên quan thay đổi không buộc chạy lại mọi task; thu hồi quyền vẫn chặn đọc/gửi tiếp theo, không được lách bằng chế độ lịch sử.

Trợ lý có thể nói: “Mình đã có công thức Trà Sen bản 2 và địa chỉ cơ sở anh cung cấp; lần này chỉ cần thêm lượng tịnh.” Nếu có dấu hiệu dữ kiện đổi, hỏi đúng phần đó. UI cho xem/sửa “Thông tin doanh nghiệp đang dùng”, nhưng người dùng không phải điền lại một form hồ sơ trước mọi nhiệm vụ.

Yêu cầu rõ của lượt hiện tại ưu tiên xác định mục tiêu; dữ kiện hiện hành đi qua resolver, không bị ghi đè tùy tiện. Một ngoại lệ chỉ cho lô này được ghi ở scope lô. Đã nhớ preference không tương đương được cấp quyền thêm một lượt AI có phí.

## 5. Tri thức domain để phục vụ doanh nghiệp khác

Đơn vị dùng lại là source/evidence/claim có điều kiện, rule, template hoặc playbook đã có version. Finding áp dụng vào doanh nghiệp A vẫn là dữ liệu riêng của A.

Các trường tối thiểu: domain/capability; jurisdiction/market/product family và đặc tính liên quan; câu hỏi/outcome được hỗ trợ; điều kiện/ngoại lệ; source snapshot+locator/hash; valid/effective interval nếu xác định được; ngày kiểm; trạng thái review; dependency versions; quyền đọc/lưu/trích/xuất/tái sử dụng.

Không phải mọi domain knowledge đều công khai: có thư viện công cộng được phép, thư viện của tổ chức và nội dung được cấp phép cho phạm vi hạn chế. Đọc được một nguồn không tự có quyền phân phối toàn bộ hay dùng cho khách hàng khác. MVP bắt đầu với catalog nguồn chính thức/template do DTT có quyền dùng; mô hình quyền vẫn phải chặn nội dung private đi ra ngoài scope.

**Promotion giữa doanh nghiệp:** từ một ca có thể rút ra đề xuất “cần nghiên cứu ai được nộp Prior Notice”. Tạo claim chung mới từ nguồn được phép, review/version riêng. Không chỉ xóa tên công ty hoặc private edges rồi đưa bản kết luận riêng lên kho chung. Private lineage/audit giữ dưới ACL; không rò qua snippet, badge “DN khác đã dùng”, số lượng, graph hoặc hash lookup.

Khi phục vụ B: lấy tri thức chung hợp lệ + SSOT của B → đánh giá khả năng áp dụng → finding riêng của B. Không sao chép kết luận của A. Một record gap `no_support_found` chỉ nói chưa tìm được trong phạm vi/query/source versions đã kiểm, không có nghĩa không tồn tại nghĩa vụ; gap cũng phải được xét lại khi input/catalog đổi.

## 6. Refresh khi cần thiết

Ba phép kiểm độc lập:

| Phép kiểm | Trả lời điều gì? | Không chứng minh điều gì? |
|---|---|---|
| `SourceCheck` | Có quan sát lại được nguồn/bản nào, thời điểm nào, nội dung có đổi? | 304/hash không đổi không chứng minh đã tìm đủ nguồn hoặc claim còn áp dụng |
| `ClaimReview` | Nhận định phiên bản này được chấp nhận trong scope/thời gian nào? | Review nguồn/claim không tự xác nhận dữ kiện doanh nghiệp |
| `ApplicabilityEvaluation` | Claim/rule có áp vào context và ngày mục tiêu của ca này? | Cùng chủ đề/tên sản phẩm không đủ để áp dụng |

Trigger thiết kế: trước khi dùng một record cần đối chiếu; giấy tờ/dữ kiện tới hạn; quan sát source hash/văn bản thay thế/thu hồi; reviewer sửa nhận định; doanh nghiệp sửa field phụ thuộc; người dùng yêu cầu kiểm lại; catalog/pack mới làm gap cũ cần xem xét. Không áp một TTL cố định cho luật, giá cước, giấy tờ và mẫu tài liệu.

### Workflow refresh

`check need + scope + rights → dedupe/reserve job → check source → nếu đổi: snapshot/observation mới + invalidation anchor → đánh dấu dependencies needs_revalidation → extract/compare → candidate claim/rule → review/gates → publish version mới`

Observation và invalidation anchor phải ghi bền vững cùng biên transaction; gate chặn reuse/publication hiện hành từ dependency bị ảnh hưởng ngay cả khi việc lan badge hoặc review chưa xong. Có thể tiếp tục đọc bản cũ theo as-of khi còn quyền. Không chờ bản thay thế approved mới cảnh báo bản phụ thuộc cũ; thay đổi nguồn không tự chứng minh claim sai, nên giữ lý do needs_revalidation thay vì tự kết luận pháp lý.

- Refresh nguồn công khai được phép và trong quota có thể không cần model. Chỉ dedupe deterministic source checks có authorization/rights và read grant/service budget phù hợp; key gồm source, access/auth scope, retrieval/parser/policy versions. Job/cache private hoặc licensed phải theo scope/entitlement. Không dùng grant của A trả model task cho B, không chia một paid attempt giữa các doanh nghiệp; kết quả domain chung đã hoàn tất được reuse là bước khác. Không dedupe theo cách lộ doanh nghiệp khác đang nghiên cứu gì.
- Phân tích/dịch/so sánh bằng model có phí cần grant tương ứng. Thiếu grant chuyển `refresh_pending`; không tự gọi model vì cache hết hạn. Cửa sổ dispatching/outcome_unknown và no-auto-retry áp dụng như 02.
- Nguồn mới không tự có claim approved. Nếu source/claim chưa đủ kiểm, phục vụ phần còn hợp lệ và ghi rõ phần cần rà; không trình bày stale như hiện hành.
- Nguồn, fact SSOT, consent hoặc ACL đổi trong lúc run đang chạy phải được kiểm lại trước dispatch/publish phần bị ảnh hưởng; gắn đúng snapshot và gate quyền hiện tại hoặc chuyển needs_revalidation. Không tự phát lại paid task, không dùng as-of để bỏ qua thu hồi quyền.
- Bản cũ giữ trạng thái as-of và cảnh báo hiện tại khi có quyền đọc. Bản mới tạo revision, approval cũ không tự chuyển sang nội dung mới.
- Metadata `next_check_hint`/refresh policy chưa phải lịch chạy. MVP ưu tiên on-use và thao tác kiểm lại; scheduler/monitor chỉ là khả năng thiết kế sau, chưa được tạo trong lượt này.

SSOT doanh nghiệp cũng được refresh: tài liệu sắp/hết hiệu lực, dữ kiện người dùng xác nhận đã đổi, preference được sửa, quyết định không còn áp dụng. Không điền một “giá trị mới” chỉ vì field đã cũ; hỏi người phụ trách hoặc đọc nguồn được phép, giữ trạng thái cần kiểm khi chưa biết.

## 7. Áp vào ba ca và ví dụ doanh nghiệp khác

**Giả định minh họa:** ba sản phẩm thuộc cùng một doanh nghiệp đã xác nhận. Những ca test browser cũ không tự được merge thành doanh nghiệp thật.

| Lượt phục vụ | Đọc/ghi Enterprise SSOT | Đọc/ghi Domain Knowledge |
|---|---|---|
| Trà Sen | Tích lũy đúng product ID, công thức/bao gói/cơ sở nếu được cung cấp, phiên bản khung nhãn và dữ kiện thiếu | Dùng/lưu hướng dẫn đăng ký/nhãn có căn cứ trong scope; không đưa công thức riêng lên kho chung |
| Mứt Sen cùng DN | Dùng lại thông tin DN/cơ sở khi có quan hệ được xác nhận; lấy dữ kiện riêng Mứt Sen/lô hàng | Reuse claim ai nộp và rule thời điểm qua gate; không tự copy người nộp/ETA hoặc công thức Trà Sen |
| Bột Sen cùng DN | Dùng hồ sơ DN và dossier đúng Bột Sen; chỉ hỏi công dụng/quy trình còn thiếu | Tra gap đúng câu hỏi; catalog mới có thể kích hoạt kiểm lại, không coi tám trang chung là câu trả lời chứng nhận |
| DN B hỏi tương tự | Chỉ lấy SSOT của B; không biết nội dung/private usage của A | Dùng cùng public claim/template nếu hợp phạm vi và quyền; tạo finding mới cho B |

## 8. Phạm vi 0.3 và nghiệm thu

SSOT tối thiểu phải nằm trong **0.3A**, không đợi sau khi đã xây thêm nhiều agent: enterprise identity/membership, entity IDs, một số field sản phẩm/cơ sở có provenance, fact resolver/version, mission context snapshot. 0.3B thêm kho domain tuyển chọn nhỏ, refresh on-use, reuse decision và ảnh hưởng phụ thuộc. Chưa xây enterprise ontology toàn diện hoặc hệ đồng bộ mọi phần mềm doanh nghiệp.

MCP/service dùng chung `EnterpriseContextResolver`. Bề mặt thiết kế có thể bổ sung context get, typed fact propose và resolve theo role khi có client cần; không cấp model một tool ghi profile tùy ý. Mọi write có expected version, idempotency, actor và scope. Các thao tác đọc/lưu typed không tự gọi AI; text/OCR cần model phải được tính phí/grant rõ.

Các cửa kiểm bắt buộc:

1. Cùng thành viên/doanh nghiệp ở chat hoặc thiết bị mới đọc lại đúng facts sau xác thực, không hỏi lại phần còn hiệu lực.
2. Một người đổi doanh nghiệp không mang facts/preference cấp doanh nghiệp cũ sang; cùng tên sản phẩm vẫn tách ID; đường đọc/list/tool legacy không bỏ qua enterprise/resource ACL mới.
3. Dữ kiện mâu thuẫn có provenance/resolution; hai người sửa đồng thời không lost update; null không xóa known fact im lặng.
4. Sửa công thức/ETA làm đúng artifact/finding cần rà; run cũ giữ snapshot, không bị cá nhân hóa bằng dữ kiện mới.
5. Domain claim dùng được cho DN B qua scope/rights/freshness, nhưng không có facts/kết luận/metadata riêng của A trong output.
6. Hash/304/TTL không tự nâng claim thành approved/current; source đổi phải có snapshot/review/impact riêng.
7. Freshness check/refresh pending/mở bản lưu không sinh paid call ngoài grant; timeout không replay model.
8. Gap cũ được xét lại khi điều kiện/catalog thay đổi; chưa tìm được không biến thành không có yêu cầu.
9. Preference suy ra không thay consent/quyền/ngân sách; người dùng sửa/quên được trong scope được phép.
10. Đánh giá personalization bằng giảm hỏi lại đúng nghĩa, giữ mục tiêu mới và tạo đầu ra hữu ích; không đo bằng lượng facts đã lưu hoặc độ dài prompt.
11. Nguồn đổi nhưng review thất bại/chưa xong: dependency đã có cờ, current reuse/publication bị gate chặn đúng phần, không phải chờ claim thay thế.
12. Hai DN cùng URL nhưng quyền/budget khác không chia paid attempt hoặc nội dung licensed; chỉ gộp source check khi authorization domain cho phép.
13. Field hạn chế trong cùng DN không xuất hiện trong snapshot/artifact được chia cho người thiếu quyền; redacted revision không chứa private refs/metadata.
14. Đổi enterprise không dùng lại grant/idempotency scope cũ; sửa fact đúng dependency giữa run làm output cũ không được phát hành như current, không tạo paid rerun.

Căn cứ phản biện: [review Enterprise SSOT](<research/enterprise-ssot-review.md>) và [review domain/refresh](<research/domain-refresh-review.md>). Đây là tiêu chí cần triển khai/kiểm sau, không phải kết quả hệ thống đã đạt.
