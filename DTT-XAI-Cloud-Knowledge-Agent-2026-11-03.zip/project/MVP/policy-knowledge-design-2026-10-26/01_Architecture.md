# Architecture — hệ thống tích lũy tri thức chính sách

**Phiên bản 1.1 · 26/10/2026 · Tích hợp P06 đã duyệt · Design only.** Không phải thông báo đã triển khai. Tài liệu này không cấp quyền lấy nguồn mới, chi tiêu, duyệt quy tắc hoặc nâng cấp database. [Quyết định và baseline review](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) tách nội dung đã duyệt khỏi các cổng triển khai còn mở.

Đọc cùng [bản trình duyệt](<00_De_nghi_phe_duyet.md>), [thiết kế dữ liệu/pipeline](<02_Du_lieu_pipeline_va_truy_xuat.md>), [quản trị/API/trải nghiệm/nghiệm thu](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>) và [review độc lập](<04_Review_doc_lap.md>).

## 1. Bài toán và kết quả cần đạt

Hệ thống cần nghiên cứu một nguồn công khai một lần, giữ nguyên căn cứ và các quyết định, rồi dùng đúng tri thức đó để phục vụ nhiều doanh nghiệp. Mỗi lần tư vấn vẫn phải hiểu intent, đọc đúng SSOT có quyền, kiểm tính hiện hành và giải thích căn cứ. Không dùng một câu trả lời riêng của doanh nghiệp làm tri thức công khai cho doanh nghiệp khác.

Đầu ra không chỉ là file PDF hoặc đoạn văn. Một phiên bản tri thức sử dụng được phải gồm: nguồn gốc, toàn bộ tài liệu cần đọc kèm, nội dung gốc và bản dịch nếu có, điều kiện/ngoại lệ có kiểu, thời điểm áp dụng, quyết định chuyên gia, phạm vi được phép tư vấn và dependency manifest. Thiếu một phần thì biểu diễn đúng phần thiếu.

Chuỗi đích:

**Phát hiện → tiếp nhận phiên bản → trích xuất → đề xuất tri thức → chuyên gia duyệt → phát hành → dùng lại → phát hiện thay đổi và rà lại.**

## 2. Hiện trạng và phần mở rộng

Baseline là app 0.5 build `v17-repair-2026-10-26`, bundle `release-final-v2`. [Audit ngày 26/10](<../source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md>) là căn cứ hiện trạng; không diễn giải thiết kế 19/10 thành tính năng đã chạy.

| Đã có trong baseline | Cần thiết kế/triển khai thêm |
|---|---|
| SQL/FTS5, nguồn/snapshot/chunks, graph SQL và dependency, source gates | Danh mục thu thập có độ phủ, phát hiện tài liệu mới, định danh văn bản/phiên bản pháp lý rõ |
| HTTP refresh Hà Nội có job/lease; hiện một lịch hằng ngày | Lịch dùng chung nhiều loại nguồn, conditional request, chống fetch trùng và chính sách freshness thống nhất |
| Gói xuất khẩu hữu hạn, kiểm trích đoạn tại URL đã biết | Adapter xuất khẩu dùng cùng freshness contract, phát hiện văn bản mới/thay thế/phụ lục |
| Rule review/publish/pack primitives; hiện chưa có rule/claim trong kho Hà Nội | Quy trình vận hành một bộ chính sách đủ căn cứ, review queue, kiểm ngoại lệ/độ phủ trước release |
| Model Gateway, consent/D06, request manifest và receipt | Authority có kiểu cho tác vụ domain công khai; không mượn doanh nghiệp/nguồn ngân sách chat để chạy nền |
| Chat mobile, SSOT có owner xác nhận, snapshot/receipt lịch sử | Thẻ trạng thái nguồn theo outcome, việc cần chủ cơ sở bổ sung, thông báo thay đổi trong app |

Số liệu audit: Hà Nội 4 nguồn/4 snapshot chưa được đánh dấu đủ bộ căn cứ, 0 rule/claim, 1 lịch kiểm nguồn; xuất khẩu 30 nguồn lưu và kiểm URL hữu hạn. Đây là phạm vi đã ghi nhận, không phải chỉ tiêu đích hay tuyên bố dữ liệu pháp luật đầy đủ.

## 3. Quyết định đã chốt và biên không được thay

| Quyết định | Ràng buộc của thiết kế này |
|---|---|
| D04 | Staff chỉ đọc/đề xuất đúng phạm vi; owner xác nhận facts vào SSOT. Chat/tệp riêng không tự chia sẻ |
| D05 | Tài liệu tài chính gốc xử lý ở server; chỉ tiêu tối thiểu gửi model cần egress grant riêng |
| D06 | Mỗi dispatch có model/purpose/manifest/quyền/ngân sách; không tự retry, đổi model, nâng model hay trả phí để sửa JSON |
| D07-A | Dừng riêng kết luận chưa đủ căn cứ hiện hành; vẫn trả phần độc lập hợp lệ và cho đọc lịch sử có quyền |
| Công nghệ | SQL + FTS5 + graph trên SQL. Chưa thêm vector DB, graph DB riêng hoặc embedding API |
| Chuyên gia đã chỉ định | `trung@dtt.vn` kiêm reviewer/publisher **chỉ** cho `HN-DIGITAL-CONSULTING-2026`, Phụ lục 03 và N1–N4. Không tự mở rộng quyền sang chương trình/nguồn khác |

Quỹ QA local 20 USD được duyệt ngày 26/10 là cho tester trong app hiện tại. **Không dùng quỹ này cho ingestion, OCR AI, dịch AI, embedding hoặc lịch AI nền.** Ngân sách domain là quyết định vận hành riêng trước khi bật những capability đó.

## 4. Phạm vi bản đầu

Đề xuất một lõi dùng chung, triển khai theo lát cắt Hà Nội trước. Bản đầu hoàn thành **một bộ chính sách** có căn cứ thật đầy đủ và được duyệt, dùng cho ít nhất hai doanh nghiệp tổng hợp với điều kiện khác nhau. Chương trình và tài liệu cụ thể phải được người phụ trách xác nhận đủ căn cứ; không hứa chính sách hiện có một mức hỗ trợ hoặc đợt đăng ký cụ thể khi chưa đọc đủ.

K1 tập trung ingestion xác định, kho phiên bản, công cụ chuyên gia, freshness và tư vấn có gate. K2 mới bật AI đề xuất tri thức sau khi authority domain và ngân sách được duyệt. K3 mở rộng số hóa quản trị, đào tạo nhân lực, xúc tiến thị trường/xuất khẩu và adapter xuất khẩu khi từng phạm vi có căn cứ và reviewer. Đây là thứ tự phụ thuộc, chưa phải lịch hoặc cam kết nhân lực.

Ngoài phạm vi bản đầu: tự duyệt luật; cam kết doanh nghiệp được hưởng; gửi hồ sơ/kiến nghị iHanoi thật khi chưa có API; tự đăng ký chính sách; crawl mọi website; học từ chat/tài liệu riêng thành domain; thay/gộp SSOT tự động; hệ thống pháp luật bao phủ mọi nước; tự gửi email/Zalo.

## 5. Sơ đồ thành phần

```mermaid
flowchart TB
  EXT[Nguồn Internet / manual / MCP chưa tin cậy]
  STAGE[Staging và phân loại nguồn, quyền, dữ liệu]
  QUAR[Quarantine riêng - chưa đủ quyền hoặc có dữ liệu riêng]
  EXT --> STAGE
  STAGE --> QUAR
  subgraph Public[Miền tri thức công khai]
    REG[Source Registry và quyền sử dụng]
    DIS[Discovery - chỉ đề xuất nguồn/tài liệu]
    JOB[Job SQL - lease, CAS, outbox]
    ACQ[HTTP acquisition và kiểm tệp]
    RAW[Kho bytes và phiên bản bất biến]
    REG --> DIS --> JOB --> ACQ --> RAW
    RAW --> EX[Extraction / OCR adapter]
    EX --> CAND[Nháp claim/rule/wiki/bản dịch + căn cứ]
    CAND --> REV[Review workbench]
    REV --> PUB[Publication Service - manifest và gates]
    PUB --> KNOW[SQL: body revision + claim/rule + quyết định + release]
    KNOW --> IDX[FTS5 + graph SQL + backlinks dẫn xuất]
    KNOW --> MD[Bản xuất Markdown theo manifest]
    RAW --> DIF[Change và coverage assessment]
    DIF --> REV
  end
  STAGE -->|chỉ public hoặc licensed đã được phép| REG
  subgraph Private[Miền phục vụ doanh nghiệp]
    CHAT[Chat mobile / MCP client]
    INT[Intent và kế hoạch theo từng outcome]
    SSOT[SSOT và quyền hiện hành]
    EV[Evidence Resolver dùng chung]
    ANS[Kết quả riêng + receipt + cảnh báo]
    CHAT --> INT --> EV
    SSOT --> EV
    IDX --> EV
    KNOW --> EV
    EV --> ANS --> CHAT
  end
  G[Model Gateway duy nhất - consent, scope, budget, manifest, dispatch fence]
  EX -. capability AI được duyệt .-> G
  CAND -. đề xuất AI được duyệt .-> G
  EV -. tổng hợp được duyệt .-> G
  G -. kết quả có kiểu, chưa được duyệt .-> CAND
  G -. kết quả riêng .-> ANS
```

Đường nét đứt là capability có thể cần phí, mặc định chưa bật cho ingestion. Mô hình không là nguồn pháp luật, reviewer hoặc publisher. Nguồn Internet/manual/MCP đều là dữ liệu không tin cậy; nội dung của chúng không được thay chỉ dẫn hệ thống, tool allowlist hoặc quyền.

### Ranh giới triển khai

- Giữ modular monolith Python/LangGraph/MCP hiện có ở bản local. Các worker là module có hợp đồng, không cần nhiều microservice hoặc một LLM cho từng bước.
- SQL là nguồn thẩm quyền cho jobs, bytes manifests, publication, rules, rights, dependencies và receipts. **K1 chọn SQLite BLOB** trong giới hạn tệp đã duyệt: bytes, rendition metadata, observation và outbox tiếp nhận commit cùng transaction. Extraction chạy sau, ngoài khóa SQL, rồi commit text/chunks/event/outbox riêng. Không hứa một transaction xuyên filesystem và SQL. File/object storage là ADR tương lai về độ bền, crash/orphan/recovery, quyền, dung lượng và backup/retention, chưa là phương án K1.
- FTS và graph là projection có thể dựng lại. Mất index không làm mất tri thức hoặc mở rộng quyền. Rebuild không gọi model và không thay quyết định.
- Một acquisition service cho mọi entrypoint. Frontend không tải luật trực tiếp rồi gửi toàn bộ cho model; MCP không bỏ qua source registry.
- Một Evidence Resolver cho chat, API/MCP và job. HTTP refresh nằm trong service/job có quyền, không lén làm tác dụng phụ của GET/status/cache read.

### Wiki như một sản phẩm tri thức — P06 đã duyệt

Wiki giữ các tổng hợp có giá trị qua nhiều lượt nghiên cứu: trang chủ đề, chương trình, quy trình, so sánh và vấn đề chưa đủ căn cứ. SQL lưu **nguyên body Markdown** của từng revision, hash, parent revision, claim/evidence dependencies và các quyết định. Nội dung tổng hợp không thể dựng lại y hệt bằng parser từ raw; mất projection thì dựng lại không AI, mất body chuẩn thì khôi phục từ backup, không gọi AI để giả phục hồi bản cũ.

Chỉ một authority ghi: edit/import tạo candidate có base revision/CAS; agent không sửa file live để publish. Publication Service quản trị chung cả rule và trang wiki nhưng dùng target kind/contract rõ; duyệt trang không đồng nghĩa duyệt rule. Metadata `stable`, `verified` trong file hoặc Git commit không cấp quyền. Release manifest ghim exact page revision/hash và closure căn cứ đã kiểm. Rights/currentness/READ gate thắng projection trễ.

Markdown chuẩn là hình thức trao đổi và trình bày, có khả năng ánh xạ OKF sau qualification. Không áp dụng mặc định trust/lifecycle của OKF làm authority XAI; không cam kết importer Gemini/Viettel khi chưa kiểm riêng. Không đồng bộ hai chiều watcher-file→SQL; file nhập luôn qua proposal service. Chi tiết canonical data ở tài liệu 02§7.4; API/quyền ở03§4.5.

## 6. Các agent và quyền của chúng

| Vai trò thực thi | Công việc | Không được làm |
|---|---|---|
| Discovery Worker | Theo dõi mục công bố/feed/sitemap/URL nằm trong registry, phát hiện tài liệu/quan hệ ứng viên | Tự chấp nhận nguồn mới, dùng snippet làm điều kiện pháp lý, lấy dữ liệu riêng để search |
| Acquisition Worker | Fetch có giới hạn, MIME/signature/hash/redirect checks; lưu observation/rendition | Tự coi HTTP 200/304 là còn hiệu lực; gọi LLM hoặc vượt host/rights |
| Extraction Worker | Đọc HTML/PDF có text; OCR qua adapter nếu có quyền; giữ locator/page/span | Đoán chữ OCR thiếu, thay text gốc hoặc sửa citation lịch sử |
| Knowledge Proposal Agent | Đề xuất claim/rule/ngoại lệ/quan hệ/bản dịch có schema và bằng chứng | Phát hành, duyệt, tự tạo field SSOT hay điền giá trị doanh nghiệp |
| Wiki Author Worker | Biên soạn/sửa nháp trang theo intent nghiên cứu, revision và evidence refs; ghi rõ mâu thuẫn/gap | Tự duyệt, tự trích wiki làm luật gốc, đưa chat/facts riêng vào public wiki hoặc sửa trusted skills |
| Change Analyst | So bytes/text và quan hệ cần đọc kèm; chỉ ra phần cần review | Tự kết luận hai bản tương đương pháp lý bằng similarity/LLM |
| Reviewer/Publisher | Người có scope thật kiểm, quyết định và phát hành bản đã duyệt | Duyệt ngoài scope, sửa nội dung sau khi đã ký hash, cho luật mới hồi sinh receipt cũ |
| Enterprise Advisor | Intent → SSOT được quyền → evidence → trả theo outcome và việc cần làm | Tự học facts vào SSOT, dùng dữ liệu DN khác, trả chắc chắn đủ điều kiện khi thiếu căn cứ |

Model route dùng registry hiện có: standard cho trích xuất/phân loại đã qualification, complex cho đối chiếu nhiều văn bản/mâu thuẫn. Đây là capability dự kiến, không phải sự cho phép mới để dùng ảnh/PDF/AI ở provider. AI chỉ được chạy khi adapter, egress, ngân sách và bộ kiểm tương ứng đã đạt.

## 7. Orchestration bằng LangGraph, thẩm quyền bằng SQL

Hai graph logic riêng, dùng chung services:

1. `KnowledgeBuildGraph`: nhận job → kiểm quyền và rights → lấy rendition/extraction → đánh giá độ đủ → tạo proposal → chờ review → chờ publication command → hoàn tất hoặc blocked.
2. `EnterpriseAdviceGraph`: nhận intent nhiều outcome → bind đúng doanh nghiệp/sản phẩm/thị trường → lấy SSOT snapshot có quyền → freshness/evidence plan → hỏi dữ kiện còn thiếu hoặc tổng hợp được duyệt → kiểm lại dependency → công bố riêng từng outcome.

Checkpoint chỉ giữ con trỏ điều phối và ID/version, không là nguồn phê duyệt. Tài liệu LangGraph mô tả checkpoint để giữ tiến trình và interrupt để chờ phản hồi; khi resume, node chứa interrupt có thể chạy lại. Do đó command nghiệp vụ và lần dispatch phải có idempotency/receipt riêng, không dựa vào việc graph “đã chạy qua”. [Persistence](https://docs.langchain.com/oss/python/langgraph/persistence), [Interrupts và side effects](https://docs.langchain.com/oss/python/langgraph/interrupts#side-effects-called-before-interrupt-must-be-idempotent).

Thiết kế thực thi:

- Job tạo trong cùng UoW với command và outbox. Worker claim bằng CAS + lease/fencing token, heartbeat cho tác vụ dài, hoàn tất bằng expected job revision.
- `thread_id` là opaque server-issued ref gắn workspace/domain/job/revision. Có ID không có nghĩa có quyền đọc hoặc resume.
- Human review có thể kéo dài; không giữ SQL transaction/HTTP request/worker lease trong thời gian chờ. Lưu review request rồi giải phóng worker. Review/resume command kiểm role hiện tại và exact hash.
- Checkpoint store phải là schema quản lý qua operator. Không để thư viện tự tạo bảng lúc runtime; không giả checkpointer và transaction nghiệp vụ commit nguyên tử nếu thực tế dùng hai kết nối.
- Sau crash ở khoảng business commit → checkpoint, đọc lại SQL job/receipt để dựng trạng thái; không tạo quyết định hay dispatch mới. Graph error không đồng nghĩa bước có phí chưa được thực hiện.
- Chỉ các node thuần, GET chính thức không phí và xử lý local có retry hữu hạn. Node có paid capability không dùng graph retry policy tự động. Unknown sau dispatch phải đối soát, không gọi lại.
- Không truyền bytes lớn, keys, cookies hoặc toàn SSOT vào checkpoint; chỉ lưu refs có ACL. Nhật ký không chép tài liệu riêng.

### Harness và năm loại bộ nhớ — P06 đã duyệt

Phân biệt nguồn/tri thức domain, SSOT, lịch sử tác nghiệp riêng, scratch/checkpoint và quy trình/skill do DTT quản lý. Không nhập tất cả vào một memory file dùng chung. Trusted skill/config được version riêng; nguồn/wiki là dữ liệu chưa tin cậy, không được ghi vào system instructions hoặc thay tool allowlist.

Giữ LangGraph làm runtime chính. Harness là hợp đồng kế hoạch→công cụ→ngữ cảnh→kiểm chứng→human gate→receipt, không chỉ folder Markdown. Có thể trình bày filesystem ảo `/knowledge/released/` chỉ đọc và `/work/<operation>/` cho nháp, nhưng mọi thao tác đi qua service xác thực actor/scope/revision; path không là quyền. Không shell/raw SQL hoặc provider SDK tự do.

Deep Agents là ứng viên worker, OpenWiki là ứng viên tái sử dụng bộ phận schema/validation/search/export; **chưa được chọn làm dependency production**. POC chỉ sau qualification mọi model call, compaction/planner/worker phụ/consolidation qua một Gateway; không paid auto retry hoặc transport/ledger thứ hai. Default thread files không tự là kho public bền vững. Claude Agent SDK không thay runtime chính trong quyết định này. Điều kiện TDD/benchmark nằm ở03§9 và §10.2; chưa cài/cấu hình thử framework.

## 8. Các state phải tách độc lập

Không dùng một nhãn `ready` cho mọi trục:

| Trục | Ví dụ trạng thái |
|---|---|
| Acquisition | discovered, allowed, fetched, not_modified, unavailable, quarantined |
| Extraction | pending, complete, partial, needs_ocr, invalid_file, human_required |
| Evidence completeness | sufficient_for_claim, missing_annex, missing_amendment, unresolved_conflict, unknown |
| Review | proposed, changes_requested, approved_exact_version, rejected |
| Publication | unpublished, released, withdrawn; lịch sử giữ quyết định gốc |
| Legal/applicability | effective, future, expired, superseded, unresolved; theo ngày mục tiêu và thẩm quyền |
| Paid execution | not_requested, authorized, reserved, dispatched, response_received, unknown, rejected, published |
| Advice outcome | answered, partially_answered, needs_fact, needs_source, awaiting_review, needs_revalidation, unsupported |

Các từ này là contract đề xuất; UI dùng lời tiếng Việt. Một nguồn không đọc được không tự thành hết hiệu lực; một rule từng duyệt không tự còn được dùng sau withdrawal. Cùng câu hỏi có thể trả hợp lệ outcome A và dừng outcome B theo D07.

## 9. Identity, thẩm quyền và chi phí cho domain jobs

Đây là thay đổi kiến trúc cần làm rõ trước khi bật AI nền. Gateway hiện tại gắn account/enterprise và ledger có foreign key doanh nghiệp. **Không được tạo một doanh nghiệp giả, mượn tài khoản Trà Sen, dùng membership owner hoặc quỹ tester để đại diện dịch vụ tri thức công khai.**

Hợp đồng đích của cùng Gateway:

```text
ExecutionAuthorization
  subject: account | service_principal
  scope: enterprise:<id> | public_domain:<id>
  capability_version, purpose, model_profile_version
  resources: exact source/rendition/extraction/rights revisions
  consent_or_operator_grant_ref, budget_authorization_ref
  operation_id, task_id, step_key, input/output limits
  request_manifest_hash, authorization_policy_version
```

Một reservation/dispatch path kiểm scope, quyền tài nguyên, D06 và ngân sách trước gửi; kiểm lại dependency trước công bố. Tác vụ public chỉ được nhận dữ liệu public/licensed thuộc scope. Tài liệu chưa đủ quyền hoặc có nội dung riêng phải quarantine; không tự chuyển sang public chỉ vì curator tải lên.

Implementation phải cung cấp mapping schema scope mới và compatibility adapter cho API/ledger v1. Không sửa ID, hash, ownership, grant hoặc payload của receipt cũ; replay v1 tiếp tục kiểm READ hiện tại theo contract gốc. Một logical authorization có một backend có thẩm quyền, không chạy đồng thời hai reservation system cho cùng command. Migration phải chứng minh không làm active quỹ local thành quỹ public hoặc production.

Nếu phần mở rộng scope chưa hoàn tất, K1 vẫn có thể đọc nguồn bằng code và cho chuyên gia nhập đề xuất thủ công. AI extraction/translation/comparison trả `capability_not_active` trước dispatch. Phê duyệt kiến trúc này chưa phê duyệt bảng giá, số lượt hoặc ngân sách vận hành.

## 10. Cache và freshness theo nghĩa nghiệp vụ

| Lớp dùng lại | Khóa/đầu vào chính | Điều kiện đọc lại |
|---|---|---|
| HTTP acquisition | endpoint + representation + auth/rights partition + validator | Theo source profile, Cache-Control/ETag/Last-Modified và quyền hiện hành |
| Extraction local | raw hash + parser/OCR/layout/language version + rights partition | Input còn đọc được, processor manifest khớp; không sửa text/citation cũ |
| AI derivation receipt | exact public input/output schema/purpose/profile/instructions/dependencies/operation manifest | Qua Gateway READ; replay không phát sinh dispatch; không gắn câu gần giống thành command cũ |
| Public retrieval projection | public query plan + target date + scope + pack/source/rights versions | Recheck canonical gates; stale index không được công bố sai rule |
| Wiki body và projection | Exact page revision/hash + source/claim/rule/translation dependencies + recipe/release/rights versions | Body chuẩn giữ SQL; FTS/backlink/Markdown dựng lại không AI; READ/gate hiện hành kiểm trước title/snippet/body/export |
| Advice riêng | enterprise/account/workspace/intent/SSOT/dependency versions | Current READ và trạng thái nguồn; không semantic-cache xuyên doanh nghiệp |

Conditional GET/304 chỉ là kiểm tra biểu diễn HTTP. Thiết kế theo [RFC 9111](https://www.rfc-editor.org/rfc/rfc9111.html#section-4.3), nhưng việc cập nhật cache không xác nhận đầy đủ bộ căn cứ hoặc pháp lý hiện hành. Một nguồn còn HTTP fresh có thể đã hết hiệu lực; nguồn HTTP unavailable vẫn có bản lịch sử đọc được nếu còn quyền.

Freshness Service dùng **một hợp đồng canonical `policy-freshness-decision/1` tại mục 5.1 tài liệu 02**; không duy trì enum khác theo chat/worker/domain. Trạng thái acquisition job là projection riêng, không phải quyết định được phép dùng căn cứ. Lịch, TTL kỹ thuật, currentness review, thời hạn chính sách và đợt tiếp nhận là các đồng hồ khác nhau. Profile được mô tả chi tiết ở tài liệu 02; mọi con số là mặc định đề xuất, không là dữ liệu pháp luật.

Hàng trăm câu hỏi trên cùng bản nguồn không tạo hàng trăm lần fetch/model extraction. Khi nguồn còn đủ điều kiện dùng, trả từ kho. Nếu cần refresh, command/job được gộp theo resource; query chỉ báo trạng thái và quyền thao tác. Không ép doanh nghiệp trả tiền xây lại cùng tài liệu công khai.

## 11. Phát hiện thay đổi, hiệu lực và công bố

Một tài liệu mới không tự thay thế tài liệu cũ. Một URL mới không tự là policy mới. Phân biệt raw diff, extraction diff, nội dung ứng viên và thay đổi có ý nghĩa áp dụng. Byte/layout đổi nhưng nội dung tương tự vẫn giữ phiên bản và đề xuất kiểm; similarity không có quyền miễn review.

Coverage manifest của một bộ chính sách ghi rõ: văn bản nền, sửa đổi, phụ lục, hướng dẫn, quy trình, đối tượng, điều kiện, ngoại lệ, cơ quan, thị trường/địa bàn, effective interval và đợt chương trình nếu có. Chỉ claim/outcome cần đến một căn cứ mới phụ thuộc nó; không khoá toàn bộ kho khi một file lỗi.

Publication command kiểm trong cùng transaction: scope hiện tại, exact approved member/translation/evidence versions, currentness, effective relations, expected release head và manifest hash. Commit release + head event + dependency/outbox; index chạy sau. Không suy bản hiện hành bằng `MAX(timestamp, UUID)`.

Nếu canonical state đã đổi mà index chưa dựng xong, reader không được nhận kết quả sai từ index cũ: truy vấn bản authoritative có điều kiện hoặc báo chưa sẵn sàng. Withdrawal/READ revoke áp dụng ngay ở gate trước công bố, không chờ worker quét dependency. Outbox sau đó đánh dấu các báo cáo phụ thuộc cần rà lại; không viết lại báo cáo/receipt cũ.

Đối với báo cáo đang sinh: recheck SSOT/rights/source/release revisions trước publication. Đổi giữa chừng thì trả trạng thái cần đối chiếu cho outcome liên quan, giữ raw model response và chi phí; không lén gọi model sửa lại.

## 12. Trải nghiệm lấy trợ lý làm trung tâm

Chủ cơ sở vẫn làm việc trong chat. Trợ lý nói kết luận/phần chưa đủ căn cứ trước, rồi mới chi tiết và ba việc theo câu hỏi. Thẻ nguồn cho biết tên, loại căn cứ, bản đang dùng, ngày kiểm và hạn chế; nút xem gốc không bị gọi là duyệt pháp lý.

Ví dụ thiết kế Trà Sen: “Chị muốn tìm hỗ trợ xuất khẩu và đào tạo người làm sổ sách buổi tối.” Trợ lý tạo hai outcome. Nếu chỉ bộ đào tạo đã phát hành đủ, trả riêng phần đó; phần xuất khẩu nêu thiếu nguồn/việc cần nghiên cứu. Khi cần tên pháp lý hoặc lao động theo kỳ, chỉ hỏi đúng fact có registry, tạo đề xuất cho owner xác nhận; không đọc tên giao dịch thành tên pháp lý hoặc lấy facts sản phẩm khác.

Chuyên gia có workbench riêng theo quyền: nguồn mới, chênh lệch phiên bản, đoạn gốc, rule/ngoại lệ đề xuất, ca thử và danh sách thiếu. Reviewer phê duyệt exact version; publisher thực hiện lệnh phát hành riêng. Một người đã được cấp cả hai vai vẫn làm hai quyết định có dấu vết. Thiết kế chi tiết màn/contract ở tài liệu 03.

Cảnh báo thay đổi ban đầu chỉ là thẻ trong app, không tự gửi ra kênh ngoài. App không nộp iHanoi, không gửi email/Zalo và không hứa nhận hồ sơ thay cơ quan từ việc phát hành tri thức.

## 13. Vận hành, an toàn và khả năng mở rộng

- Local worker chỉ chạy khi app/service hoạt động; lịch daily không phải cam kết 24/7. Sau downtime chạy lượt đến hạn được gộp, không bù hàng loạt lượt AI cho từng ngày đã qua.
- Source profiles có giới hạn host, kích thước, tần suất, timeout, backoff và concurrency. Mỗi redirect/DNS/IP/MIME được kiểm lại; không theo link tới private network, file path hoặc credential-bearing URL.
- Crawler tôn trọng chính sách truy cập và robots, nhưng robots không thay giấy phép/quyền sử dụng. [RFC 9309](https://www.rfc-editor.org/rfc/rfc9309.html#section-1) phân biệt giao thức crawler với authorization. Rights phải là gate riêng.
- Quarantine file giả, HTML giả PDF, nội dung quá lớn, archive bomb, tài liệu có dữ liệu riêng hoặc lệnh prompt injection. Tệp hỏng có tên/reason cụ thể, không khoá các job không liên quan.
- Ngân sách có phần riêng cho public domain jobs, text/OCR/dịch/model/HTTP nếu có dịch vụ có phí. Chưa có grant thì dừng phần cần phí; không làm gateway thứ hai hoặc dùng API key trong tool trả cho client.
- Đo theo loại nguồn và outcome: tuổi lần đọc/độ mới pháp lý, tỷ lệ bộ căn cứ đủ, queue lag, review lag, fetch avoided, extraction reuse, invalidation lag, token/cost, unknown paid outcomes và privacy denials. **Metric contract, mẫu số, corpus gold và cách đo canonical ở tài liệu 03, mục 10.1**; không gọi 4 nguồn là 4 chính sách đầy đủ, không cộng gap vào câu trả lời đầy đủ hoặc đặt latency SLA chưa qua qualification.
- Hosting/retention/backup chưa được chốt cho vận hành rộng. Bản thiết kế không tự đặt TTL xoá raw/facts/receipt. Thử nghiệm dùng tài liệu công khai và tài khoản tổng hợp, không đưa tài liệu riêng thật vào corpus chỉ vì đang demo.

## 14. Migration và tương thích

1. Chụp baseline source/schema/seed/managed objects/ledger và hash nghiệp vụ; review kế hoạch exact DDL có source pin, backup mới, rehearsal trên bản sao, runtime-target preflight và rollback/restore được thử.
2. Additive schema cho endpoint/discovery/rendition/extraction/review/policy identity. Giữ bảng/ID/bytes legacy; dùng adapter quan hệ có chứng cứ. Không đổi giả `complete_policy=1` hoặc tự tạo review event.
3. Các bản chưa map đủ vẫn đọc dưới legacy contract và có giới hạn; mutation mới yêu cầu contract đủ. Exact replay kiểm identity/READ trước defaults; không tái resolve SSOT/binding hôm nay để dựng lại command cũ.
4. Chuyển read path có feature gate theo domain, so kết quả trên corpus/clone không gọi AI; không chạy song song hai paid path. Công bố có CAS và ledger để đối soát, không apply lại vì hậu kiểm không đọc được receipt.
5. Cutover sau khi contract verification, data-preservation, private/public boundary, replay và độc lập đạt; giữ bản phát hành/backup cũ. Runtime không tự thêm bảng, cài source hoặc backfill business data.

## 15. Lộ trình và cổng duyệt

| Giai đoạn đề xuất | Kết quả có thể xem | Gate trước khi qua |
|---|---|---|
| K0 — duyệt thiết kế | Bộ tài liệu này, source coverage plan, risk/decision list | Chủ dự án chấp thuận kiến trúc/phạm vi; chưa có code hoặc model call |
| K1 — lõi dữ liệu và một policy đủ | Discovery/fetch/extraction local, wiki/diff/workbench thủ công, SQL body revisions và release, chat hai doanh nghiệp, change/revoke flow | Nguồn và reviewer đúng scope, operator migration, corpus expert, TDD + độc lập; không AI nền |
| K2 — AI đề xuất có kiểm soát | Trích xuất/so sánh/dịch hỗ trợ reviewer; lưu kết quả dùng lại | Gateway public scope được kiểm, adapter qualification, egress/retention/budget được duyệt riêng |
| K3 — mở rộng domain/độ phủ | Các bộ chính sách Hà Nội khác, xuất khẩu US/DE/JP dùng freshness chung | Danh mục nguồn và phạm vi chuyên gia từng domain, legal/technical coverage đạt |
| Sau có dữ liệu đánh giá | Xem xét embedding/rerank/nguồn mới/provider mới | Chỉ đề xuất khi baseline thất bại có đo lường và có chốt dữ liệu/chi phí |

Thiết kế không ấn định ngày triển khai hoặc SLA pháp lý khi chưa chốt nội dung/phân công. Ngân sách QA local không phải phê duyệt K2. Chi tiết đầu việc/ma trận kiểm ở tài liệu 03.

## 16. Tiêu chí thiết kế có thể kiểm chứng

- Mỗi outcome hoặc có đủ evidence có thẩm quyền theo ngày mục tiêu, hoặc có gap/lý do; không mất ý thứ hai và không đoán điều kiện.
- Citation dùng đúng raw/extraction/chunk/translation version và locator; rule/claim có decision/publication manifest; không lấy câu trả lời Claude làm gold.
- Hai doanh nghiệp dùng cùng public version nhưng SSOT/kết luận/receipt riêng; cùng nguồn fresh không bị fetch hoặc AI extraction lặp theo số người hỏi.
- Source đổi/phụ lục thiếu/withdraw/revoke/index stale/checkpoint replay/lease expiry có ca âm; không trả tư vấn mới sai từ cache và không tự tạo paid dispatch thứ hai.
- Schema upgrade giữ mọi hàng nghiệp vụ/receipt cũ, exact runtime contract và đối soát sau commit; không test xanh bằng sửa dữ liệu cũ.
- Reviewer độc lập kiểm cả kiến trúc, code/TDD và browser mobile sau khi triển khai; review tài liệu hiện tại không được ghi là đã chạy các ca đó.

## 17. Trace về lỗi thiết kế

| DF | Quyết định ngăn tái diễn |
|---|---|
| 008/009/050 | Explicit binding và scope trước SSOT/evidence; public domain không giả thành enterprise |
| 014/032/034/046/048 | Snapshot/receipt/authority hiện tại khác nhau; exact replay, bitemporal và causal head |
| 017/021/030/044 | Query/recovery 0 AI; một Gateway, scoped grant, egress và immutable request manifest |
| 024/025/026 | Outcome coverage, cụ thể hoá việc, disclosure phần thiếu; typed handoff |
| 027/033 | Source/discovery/rule/review/legal validity/release tách biệt; graph SQL có authority |
| 028/029 | Public/private partition, current READ/revoke cho mọi dẫn xuất |
| 035/037/043 | Parser boundaries, lỗi có tên, mobile/accessibility, không nhận proof sai phạm vi |
| 041/042/049 | Operator migration, frozen bundle, runtime-target verification; không startup repair |

[Sổ nguyên nhân có thẩm quyền](<../architecture/DESIGN_FLAWS.md>) giữ các lớp còn D1. Tài liệu này là phương án đáp ứng các bất biến, không tự đóng lỗi thiết kế hoặc thay quyền vận hành.

## 18. ADR và trạng thái quyết định

PK-01–11 là baseline đề xuất P01, đọc cùng các điểm trùng P06 đã chốt. **PK-12–14 được chấp thuận về định hướng qua P06 ngày 26/10/2026**; thử nghiệm framework/format và các migration/capability vẫn cần qualification/cổng triển khai. Phê duyệt hướng không là nghiệm thu hoặc mở quyền runtime.

| ADR | Quyết định và pattern | Lý do / tradeoff | Chỉ xem xét lại khi |
|---|---|---|---|
| PK-01 | Modular monolith, Ports and Adapters cho source/parser/model/storage | Dùng được lõi hiện hữu, ít ranh giới vận hành; cần giữ module contract thay vì gọi xuyên lớp tùy ý. Chưa tách agent thành microservice | Số liệu tải/độ độc lập triển khai chứng minh một module cần scale riêng |
| PK-02 | CQRS có giới hạn + append-only decisions/receipts + canonical read model | Read/status không tạo job/quyền; giữ causal decisions và snapshot, không bắt refactor toàn app thành event sourcing. Projection không là authority | Corpus chứng minh read model không đáp ứng đúng replay/as-of hoặc performance |
| PK-03 | Content-addressed immutable rendition + versioned derivation | Dùng lại bytes/xử lý có cùng manifest, giữ provenance/rights riêng; hash bằng nhau không là cùng identity/quyền | Dung lượng/backup cần storage adapter mới đã được review |
| PK-04 | Human review → immutable manifest → explicit publication, Optimistic Concurrency | Không tự publish từ AI hoặc một lần duyệt chung chung; hai vai có thể cùng người trong scope nhưng vẫn hai quyết định | Quy chế tổ chức được chốt mới yêu cầu tách người hoặc thêm cấp duyệt |
| PK-05 | Một Model Gateway với typed authorization scope, idempotency và dispatch fence | Không service SDK/budget thứ hai, không enterprise giả. Scope public cần mở rộng core và kiểm tương thích trước dùng | Provider/capability mới có qualification, data policy và ngân sách, không do prompt tự chọn |
| PK-06 | SQLite BLOB ở K1 | Đơn giản hoá atomicity và backup cùng metadata trong giới hạn tệp; DB có thể lớn hơn. Không giả transaction xuyên file/SQL | Đo corpus/backup vượt giới hạn, có ADR file/object store kèm protocol crash/orphan/recovery |
| PK-07 | SQL durable job + Transactional Outbox + lease/CAS/fencing + Single Flight | Không mất job sau commit, không nhân fetch theo DN, không giữ request/transaction khi xử lý ngoài. Phải kiểm starvation/lease expiry | Tải/cấu hình nhiều worker vượt khả năng đã benchmark; chuyển broker vẫn giữ authority SQL |
| PK-08 | LangGraph orchestrator với checkpoint refs; idempotent services | Framework giữ tiến trình, không giữ quyền phê duyệt; resume không được gọi lại paid step. Cần reconcile checkpoint với SQL | Đổi framework vẫn phải qua cùng services/receipts và bộ ca crash |
| PK-09 | FTS5 + metadata + graph SQL trước embedding | Kiểm được baseline và authority, ít chi phí/egress. Có thể thiếu recall với diễn đạt đa ngôn ngữ | Benchmark expert gold chỉ ra recall sai do diễn đạt, không do thiếu source; có duyệt dữ liệu/chi phí cho adapter mới |
| PK-10 | Anti-corruption adapter + Strangler rollout theo domain | Legacy IDs/payload/receipt giữ nguyên; new contracts không dựng lại defaults hôm nay. Có thời gian duy trì hai dạng dữ liệu nhưng không hai authority/paid paths cho cùng command | Migration có proof đủ và kế hoạch retire đọc legacy riêng, không xóa lịch sử ngầm |
| PK-11 | Public/private information boundary, deny override và typed evidence | Tri thức công khai được dùng chung; facts/answers/query riêng không thành public corpus. Official contact cần provenance/rights, không tự coi mọi số điện thoại là public | Quy trình chia sẻ dữ liệu mới được chủ thể và quản trị phê duyệt rõ; không phải đổi config cache |
| **PK-12 / P06 đã duyệt** | Governed Wiki + immutable Markdown revisions + CQRS/materialized views | Giữ công tổng hợp lâu dài và diff dễ đọc; SQL là bản chuẩn, claim/evidence/release tách nội dung. Phải quản trị dependency và không hai authority file/SQL | Số liệu thực chứng minh storage cần adapter mới; không từ việc muốn sửa file tiện hơn |
| **PK-13 / P06 đã duyệt** | Bounded harness trên LangGraph, Ports and Adapters cho tool/filesystem/model | Giữ một Gateway, service quyền và receipt; Deep Agents/OpenWiki chỉ POC có điều kiện. Không tự bật memory consolidation/subagent/retry trả phí | Qualification và A/B chứng minh lợi ích, mọi model call được kiểm soát; cần quyết định dependency riêng |
| **PK-14 / P06 đã duyệt** | Markdown chuẩn + mapping OKF có phiên bản; FTS/alias/typed SQL links trước embedding | Tri thức có thể trao đổi; metadata file không là ACL/approval, compatibility phải kiểm. Chưa thêm DB/model mới | Corpus chỉ ra thiếu recall/chi phí thực, có duyệt egress/provider/retention; không suy compatibility sản phẩm từ format |

Mọi ADR phải được nối vào implementation map, test và release evidence khi triển khai. Chỉ ghi tên pattern hoặc có unit test xanh không đủ đóng DF; các ca chuyển trạng thái, negative path, dữ liệu cũ và bản đóng gói vẫn là cổng nghiệm thu.
