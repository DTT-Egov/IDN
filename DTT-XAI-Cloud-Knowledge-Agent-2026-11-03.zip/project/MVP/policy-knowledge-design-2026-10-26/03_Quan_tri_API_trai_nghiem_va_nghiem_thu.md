# 03 — Quản trị, hợp đồng MCP, trải nghiệm và nghiệm thu tri thức chính sách

Ngày **26/10/2026, UTC+7** · Phiên bản **1.1**, tích hợp P06 đã duyệt · **Thiết kế, chưa phải mô tả tính năng đã triển khai.**

Tài liệu này đặc tả quyền quyết định của con người, các lệnh/truy vấn ở biên hệ thống, trải nghiệm doanh nghiệp/chuyên gia và điều kiện nghiệm thu cho chuỗi **phát hiện → lưu phiên bản → trích xuất, đề xuất → chuyên gia duyệt → phát hành → dùng lại**. Không chạy app, thay nguồn, cấp quyền, phát hành tri thức hoặc gọi model để lập tài liệu.

Đọc cùng [đề nghị phê duyệt](<00_De_nghi_phe_duyet.md>), [kiến trúc](<01_Architecture.md>) và [dữ liệu, pipeline, retrieval](<02_Du_lieu_pipeline_va_truy_xuat.md>). Các giai đoạn K0–K3 dùng chung định nghĩa ở tài liệu 01; phần dưới chia đầu việc chi tiết bằng mã W để tránh tạo một roadmap khác.

## 1. Những quyết định giữ nguyên

**Bổ sung bản 1.1 theo P06 đã duyệt ngày 26/10/2026:** wiki có body/revision chuẩn ở SQL, công cụ đi qua cùng services và một Gateway; chưa cài framework hoặc cấp capability/grant. [Quyết định P06](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) là sổ thay đổi; các ca WIKI và benchmark dưới đây đều **chưa chạy**. Bộ metric canonical vẫn ở §10.1, bổ sung phép so sánh wiki ở §10.2.

| Căn cứ | Ràng buộc áp dụng vào thiết kế này |
|---|---|
| D03 | Máy có thể cập nhật nguồn; DTT/chuyên gia quyết định quy tắc dùng để tư vấn. AI không tự duyệt hoặc tự phát hành. |
| D04 | Nhân viên xem/đề xuất SSOT theo phạm vi được giao; chủ doanh nghiệp xác nhận mọi thay đổi nghiệp vụ. Chat/tệp riêng không tự chia sẻ. Quyền quản trị tri thức công khai không cấp quyền xem dữ liệu riêng. |
| D05 | Tài liệu tài chính xử lý tại server. Không đưa bản gốc, ảnh trang, OCR hoặc bản dump tương đương vào pipeline domain hay Claude; chỉ chỉ tiêu tối thiểu được người có quyền cho phép cho đúng tác vụ mới có thể đi qua Gateway. |
| D06 | Mọi lượt AI phải qua Gateway/manifest/consent/hạn mức chung hiện hữu; không tự gửi lại, đổi model hay nâng model có phí. Ngân sách nền cập nhật tri thức không mặc nhiên lấy từ ngân sách tester. |
| D07-A | Dừng riêng phần cần căn cứ hiện hành chưa đủ; trả phần độc lập còn hợp lệ và lịch sử theo quyền. Cache, HTTP 200 hoặc model mạnh không vượt cổng này. |
| SQL trước | SSOT, graph và retrieval tiếp tục trên SQL/FTS; chưa mở graph DB, vector DB, embedding hoặc provider mới. |
| Phân công đã có | Người dùng đã chỉ định **`trung@dtt.vn` kiêm chuyên gia rà và người phát hành**, chỉ cho **`HN-DIGITAL-CONSULTING-2026`/Phụ lục 03 và bốn nguồn N1–N4**. Không yêu cầu chỉ định lại người cho phạm vi này. Không suy quyền mọi chính sách Hà Nội/xuất khẩu, quyền curator, quyền doanh nghiệp hoặc ngân sách AI. |
| iHanoi | Chuẩn bị kết nối; chưa có tài liệu API/môi trường nghiệp vụ. Phát hành tri thức hoặc tạo nháp kiến nghị **không đồng nghĩa gửi iHanoi**. |

[Sổ quyết định D04/D05/D06/D07](<../core-policy-detailed-design-2026-10-19/08_Quyet_dinh_can_chot.md>) và [ma trận D07](<../core-policy-detailed-design-2026-10-19/12_Chinh_sach_nguon_va_phat_hanh_D07.md>) là căn cứ. Dòng trạng thái “chưa chỉ định người duyệt” trong tài liệu lịch sử ngày 19/10 được hiểu theo thời điểm viết. [Hồ sơ Phụ lục 03, mục Quyền](<../../../REFERENCE_LINKS.md#ref-0006>) ghi phân công ngày 20/10: 8 scope grants reviewer/publisher theo bốn nguồn, **0 vai toàn cục**, không quyền private Trà Sen, chưa có review/publication. Quyết định hiện hành không phê duyệt nội dung đề xuất hoặc mở rộng quyền sang nguồn/chương trình khác.

Quỹ tester local 20 USD ngày 26/10 đã có phạm vi ở [quy trình kiểm thử Claude thật](<../source-pipeline-audit-2026-10-26/02_Kiem_thu_Claude_that_va_han_muc.md>). Thiết kế này **không dùng, gia hạn hoặc mở rộng** quỹ đó sang discovery/OCR/dịch/trích xuất nền. Khi triển khai, vòng đánh giá câu trả lời có thể dùng quỹ còn hiệu lực đúng phạm vi; tác vụ nền có phí phải có đề nghị riêng.

## 2. Mô hình quyền: capability có phạm vi, không chỉ tên vai trò

Quyền được xét theo **hành động × domain × chính sách/chương trình × nguồn × môi trường × tài nguyên**, có revision/hiệu lực/thu hồi. Một tài khoản có thể có nhiều capability; giao diện và model không tự suy quyền từ email, membership hoặc việc đã tải tài liệu.

| Chủ thể | Được làm trong phạm vi đã cấp | Không được suy ra |
|---|---|---|
| Bộ lấy nguồn nền | Đọc endpoint công khai đã đăng ký; lưu observation/snapshot; tạo việc cần xử lý | Không đọc SSOT/chat/tệp riêng; không approve/publish; không gọi model chỉ vì có API key |
| Bộ trích xuất | Đọc snapshot được giao; đề xuất trích đoạn, bản dịch và claim/rule có provenance | Không biến nội dung Internet thành chỉ dẫn hệ thống; không xác nhận pháp lý hoặc thay bản đã phát hành |
| Người quản lý nguồn DTT | Đăng ký phạm vi nguồn, chấp nhận chất lượng trích xuất, chuẩn bị bundle và đề xuất lịch | Không mặc định được duyệt mọi chính sách, cấp ngân sách hoặc đọc dữ liệu doanh nghiệp |
| Chuyên gia rà | Duyệt/từ chối đúng phiên bản rule/claim và bộ căn cứ được giao; ghi lý do, thiếu sót và phạm vi | Không phát hành bằng nút duyệt; không đổi bản đang rà rồi giữ approval cũ |
| Người phát hành | Phát hành manifest đã qua review, đúng hash/phạm vi và cổng hiện hành; rút bản theo quyền | Không dùng bản draft, bỏ dependency bị chặn hoặc tự hồi sinh bản cũ |
| Chủ doanh nghiệp | Đọc tri thức đã phát hành được phép; dùng SSOT của mình; xác nhận dữ kiện; duyệt nháp hồ sơ riêng | Không duyệt rule công khai bằng consent gửi Claude; không xem hồ sơ/chát của doanh nghiệp khác |
| Nhân viên doanh nghiệp | Xem/đề xuất dữ kiện và làm tác vụ trong phạm vi được giao; dùng ngân sách chỉ khi được cấp riêng | Không tự ghi current SSOT; quyền đọc không bằng quyền gửi dữ liệu ra provider |
| Tester | Dùng tài khoản thử, môi trường/quỹ được cấp và các tác vụ đã cho phép | Không tự cấp nguồn công khai hoặc dùng một policy fixture như văn bản thật |
| Người vận hành | Xem trạng thái kỹ thuật, dừng job, xử lý lease/outbox/migration có audit | Không tự duyệt nội dung, mở quyền private hoặc gọi lại lượt AI đã gửi |

**Tài khoản kiêm nhiệm:** `trung@dtt.vn` có thể dùng capability reviewer và publisher đã được cấp **trong chương trình/bốn nguồn nêu trên**. Hai quyết định vẫn là hai thao tác nghiệp vụ riêng, có lý do, exact version/hash, actor và biên nhận. Không giả là hai người độc lập; audit ghi rõ kiêm nhiệm. Người này có thể từ chối sau khi rà hoặc dừng trước khi phát hành. Không có hành vi tự publish sau approve. Thêm chính sách/nguồn vào scope hoặc phân công curator ngoài phạm vi hiện hữu là cấu hình quyền phải được phê duyệt riêng trước triển khai; không hỏi lại danh tính đã được chốt để thay việc chốt phạm vi còn thiếu.

**Thu hồi quyền khác rút nội dung:** thu hồi capability chặn các lệnh mới theo thời điểm kiểm. Một approval hợp lệ trong quá khứ không tự biến thành giả chỉ vì người rà sau đó đổi vai; việc mất tin cậy approval phải có quyết định rút/đình chỉ rõ. Ngược lại, READ của nguồn/tài nguyên bị thu hồi thì kết quả dẫn xuất phải chặn ngay theo dependency; ownership/grant shortcut không được vượt. Xóa quyền WRITE không được vô tình cấm đọc lại receipt nếu quyền READ hiện hành vẫn đủ.

## 3. Hai cấp quản trị con người, với cổng chất lượng riêng

### Cấp 1 — rà nội dung có thể dùng để tư vấn

Đơn vị rà là **một phiên bản bất biến** của rule/claim kèm bộ căn cứ, không phải một tiêu đề chính sách. Trước khi approve, chuyên gia xem:

1. Cơ quan, số/ký hiệu văn bản, phạm vi, loại văn bản và quan hệ với thông báo hướng dẫn/phụ lục/sửa đổi.
2. Bytes/hash, bản trích xuất và vị trí có thể mở lại: trang, mục/điều, bảng/ô, tọa độ khi cần; đối chiếu bản scan với OCR.
3. Mỗi mệnh đề nói gì, áp dụng cho ai/sản phẩm/thị trường/ngày nào, các ngoại lệ và định nghĩa liên quan; mỗi item trong checklist hoặc mức hỗ trợ có căn cứ riêng.
4. Điều kiện, phép tính, kết quả `đạt / không đạt / chưa biết / xung đột` và dữ kiện SSOT cần đọc. Không dùng natural-language rule vô hạn để tự chạy mã.
5. Phân biệt hiệu lực văn bản, hạn nhận hồ sơ, quota còn lại và thời điểm kiểm nguồn. Không suy cửa nhận đang mở từ ngày công bố hoặc trang truy cập được.
6. Bản tiếng Việt và nguyên văn khi nguồn ngoại ngữ; dịch sai số, đơn vị, phủ định hoặc ngoại lệ thì chưa approve claim phụ thuộc.
7. Bộ ca kiểm quy tắc: đủ/thiếu/sát biên/ngoại lệ/xung đột và ít nhất một ca không áp dụng. Kết quả kiểm được gắn đúng evaluator/contract version.

Có thể chấp nhận snapshot đạt chất lượng đọc nhưng **chưa approve rule**. Có thể approve rule A nhưng từ chối claim checklist B. “Nguồn hợp lệ”, “đọc đủ”, “đã rà”, “đã phát hành” là các trục riêng.

### Cấp 2 — phát hành manifest chính xác cho sử dụng

Người phát hành được xem manifest không thay đổi: member versions/hashes, review event IDs, nguồn/snapshot/quote hashes, quan hệ thay thế, phạm vi/ngày, evaluator version, currentness profile và kết quả bộ ca. Việc phát hành kiểm lại toàn bộ cổng trong giao dịch cuối.

- Một manifest có thể gồm nhiều member, nhưng không được gom bản chưa rà hoặc thiếu phụ lục thiết yếu để làm đẹp độ phủ.
- Giữa lúc mở màn và bấm phát hành, nguồn/approval/quyền/manifest đổi thì trả conflict có lý do; phải xem lại bản mới. Không tự bỏ item gây lỗi rồi phát hành phần còn lại nếu chưa có manifest mới được người dùng xác nhận.
- Rule dùng lại giữa các pack phải vẫn có trạng thái khả dụng chung. Member bị rút hoặc nguồn bị chặn không được dùng vòng qua một pack khác.
- Phát hành mới không sửa report, receipt hoặc manifest cũ. Lớp cảnh báo hiện tại được thêm riêng khi đọc kết quả lịch sử.
- Rút bản có audit và impact closure. Rút bản mới không tự phục hồi bản trước; muốn phát hành lại cần một quyết định mới đúng cổng. Rollback mã hoặc khôi phục DB không được làm yếu các cổng, hồi sinh quyền hay gửi lại lượt AI.

## 4. Kiểm kê API hiện có và hợp đồng đích

Các tên ở cột trái được quan sát trong [`core_v1/integration.py`](<../../nmate-backend-v0.2/src/nmate/core_v1/integration.py>). Bảng **không khẳng định API hiện có đã thỏa các trường bổ sung của thiết kế này**.

| Tool hiện có | Vai trò hiện tại | Bổ sung trong hợp đồng đích |
|---|---|---|
| `policy_list_sources`, `policy_review_queue`, `policy_refresh_jobs` | Đọc danh mục, hàng rà và lịch | DTO có capability/scope, revision, trạng thái và gap có kiểu; READ không enqueue job hoặc gọi mạng/model |
| `policy_register_source`, `policy_add_snapshot` | Đăng ký nguồn và nhập snapshot | operation identity, input digest, source provenance, content-type/bytes checks, artifact/locator contract, quyền sở hữu và trạng thái quarantine |
| `policy_check_source`, `policy_refresh_source` | Ghi kết quả kiểm và lấy lại URL đã biết | Observation typed, currentness quyết định riêng, không để người gọi tự gắn `current_until` nhằm vượt profile; refresh command chỉ nhận source refs hợp lệ |
| `policy_refresh_schedule`, `policy_refresh_disable` | Đặt/dừng lịch nguồn | expected schedule revision, operation identity, cadence profile và service identity; không tự bật AI nền |
| `policy_propose_member` | Đề xuất rule/claim | bundle/snapshot/quote refs exact, typed applicability/dependencies, extractor/model manifest nếu có và schema version |
| `policy_review_member` | Rà exact member/hash | operation identity, expected revision, review checklist/test result refs, quyết định và rationale có kiểu |
| `policy_publish_member`, `policy_release_pack` | Phát hành member và pack | Manifest ghim version/hash/review refs; CAS và kiểm khả dụng trong cùng Unit of Work; giao dịch cuối có outbox |
| `policy_withdraw_member` | Rút exact member | Lý do/phạm vi hiệu lực, expected revision, event và impact closure; không tự phục hồi bản khác |
| `policy_prepare`, `policy_start`, `policy_get`, `policy_list` | Lập, chạy và đọc ca riêng doanh nghiệp | Dùng chung retrieval/freshness decision; tách ca hiện hành, xem lịch sử và đánh giá lại; không dùng cache để vượt quyền hoặc D07 |

**Quy ước phiên bản:** các hợp đồng mới dưới đây ký hiệu `*.v2` là **đề xuất**. Cách đặt tên tool wire cuối cùng có thể là tool mới hoặc nâng DTO tương thích; phải chốt trong implementation plan, không ghi đè nghĩa của receipt v1. Không tạo provider transport, ngân sách hoặc bộ duyệt thứ hai song song với lõi.

### 4.1. Envelope lệnh thay đổi — đề xuất `policy.command.v2`

```json
{
  "contract": "policy.command.v2",
  "operation_id": "op_minh_hoa_review_01",
  "command": "review_member",
  "scope": {"domain_id": "hanoi-business-support", "policy_id": "policy_minh_hoa"},
  "target": {"member_version_id": "member_minh_hoa_v2", "content_hash": "sha256:MINH_HOA"},
  "expected_revision": 7,
  "payload": {
    "decision": "approved",
    "rationale_vi": "Lý do rà do chuyên gia ghi; ví dụ hợp đồng, chưa phải approval thật.",
    "review_checklist_ref": "checklist_minh_hoa_v2",
    "test_run_ref": "test_minh_hoa_v2"
  }
}
```

Danh tính actor, authority revision và hash payload chuẩn hóa do server tính từ phiên đăng nhập và dữ liệu đã kiểm; không tin client tự khai `actor_id`, quyền, nguồn đủ hay ngân sách. `scope` ở lệnh domain không là `enterprise_id` giả để mượn ownership của một doanh nghiệp.

**Idempotency:** khóa gồm namespace/môi trường/chủ thể lệnh/scope/operation ID theo contract. Cùng ID, cùng canonical payload trả receipt đã commit sau kiểm READ input hiện hành. Cùng ID khác payload trả conflict. Replay không dựng lại implicit defaults theo hồ sơ hôm nay và không chạy lại công việc. Lệnh mới kiểm WRITE/CAS/lifecycle; receipt cũ không trở thành lệnh mới vì role hoặc trạng thái đã đổi. Không dùng UUID/timestamp để suy thứ tự nhân quả.

### 4.2. Phát hành — đề xuất `policy.publication.v2`

```json
{
  "contract": "policy.publication.v2",
  "operation_id": "op_minh_hoa_publish_01",
  "domain_id": "hanoi-business-support",
  "expected_release_revision": 4,
  "manifest": {
    "pack_version_id": "pack_minh_hoa_v3",
    "members": [
      {
        "member_version_id": "member_minh_hoa_v2",
        "content_hash": "sha256:MINH_HOA",
        "review_event_id": "review_minh_hoa_01"
      }
    ],
    "wiki_revision_refs": [
      {
        "page_id": "page_minh_hoa",
        "page_revision_id": "wiki_revision_minh_hoa_v2",
        "body_hash": "sha256:MINH_HOA",
        "review_event_id": "review_wiki_minh_hoa_01",
        "dependency_manifest_hash": "sha256:MINH_HOA"
      }
    ],
    "dependency_manifest_hash": "sha256:MINH_HOA",
    "evaluation_contract_version": "policy-evaluator/2",
    "currentness_profile_version": "profile_minh_hoa_v1"
  },
  "manifest_hash": "sha256:MINH_HOA"
}
```

Server phải tự resolve/kiểm dependencies và tính lại hash; client không tự xác nhận manifest đủ. Các ID/hash trong ví dụ chỉ minh họa, **không phải chính sách hoặc biên nhận đã duyệt**.

Draft `policy.publication.v2` được bổ sung wiki refs theo P06; không phải sửa ngầm wire contract/receipt đang chạy. Trang chỉ dùng để assessment khi exact revision/hash, review target kind/scope, release và toàn closure căn cứ hợp lệ. Không suy từ approval của rule ra approval của body, hoặc ngược lại. Manifest không chứa wiki có thể có `wiki_revision_refs: []`; không ép mọi pack cũ phải có wiki, không backfill approval.

**Unit of Work:** trong một transaction kiểm authority/quyền đọc, CAS release head, exact review/hash, currentness/availability/dependencies và uniqueness operation; ghi release event + manifest + projection cần thiết + outbox event + receipt. Hoặc commit tất cả, hoặc không thay đổi gì. Nếu kiến trúc giữ `publish_member` rồi `release_pack`, member published chưa được dùng để assessment cho đến khi có pack release hợp lệ; không có “nửa pack” hiển thị như hoàn tất.

Network/LLM, quét PDF và thời gian chuyên gia suy nghĩ nằm **ngoài transaction**. Giao dịch cuối chỉ kiểm các observation/version đã ghi và còn đạt gate; cần lấy lại nguồn thì trả việc chờ kiểm, không giữ khóa DB khi tải mạng hoặc tự refresh để lách conflict. Manifest/revision được kiểm lại khi quay về.

Outbox xử lý invalidation/index/cảnh báo theo event ID, consumer idempotent và causal revision. Nó không được tự gửi AI hay iHanoi. Chỉ đọc status không enqueue paid repair. Chỉ mục chậm chưa làm bản mới bị dùng như cũ: truy vấn luôn có gate SQL có thẩm quyền trước trả hit.

### 4.3. Truy vấn dùng lại — đề xuất `policy.lookup.v2`

Input gồm câu hỏi/outcome IDs, refs SSOT được phép, thị trường/sản phẩm/ngày mục tiêu và chế độ `new_assessment` hoặc `read_existing`. Server tạo context manifest tối thiểu; không cho client truyền SQL, quyền hoặc toàn bộ profile. Query chuẩn chỉ tra kho/đánh giá bằng code, **không tự tải Internet hoặc gọi model**. Khi cần lấy mới, trả gap/job ref hoặc đề xuất command refresh riêng.

Output theo từng outcome:

| Trường | Nội dung |
|---|---|
| `outcome_id`, `question_span` | Giữ từng nhu cầu trong câu; không biến xuất khẩu + đào tạo thành một nhánh |
| `decision` | `usable`, `needs_facts`, `knowledge_gap`, `currentness_blocked`, `out_of_scope`, `historical_only` |
| `assessment` | Đối chiếu có điều kiện và phần chưa biết; không cam kết được cơ quan phê duyệt |
| `evidence_refs` | Pack/member/snapshot/quote exact versions; nguyên văn và bản tiếng Việt tương ứng |
| `wiki_revision_refs` | Page/revision/body hash và release dùng để định hướng/diễn giải; không thay claim hoặc nguyên bản. Evidence bundle draft canonical là `/2` tại tài liệu 02§7.2 |
| `freshness_decision_ref` | Lý do sử dụng/chặn, thời điểm quan sát, hạn kiểm và target date; không chỉ `cached=true` |
| `context_manifest_ref` | Những facts thực dùng, exact field keys/versions và quyền hiện hành; không biến enterprise revision thành toàn bộ context |
| `next_actions` | Việc cụ thể bám gap/intent; không cố định ba việc cho mọi câu |
| `saved_result_ref`, `model_receipt_ref` | Có khi thực sự lưu/đã gọi; null không được render “Claude đã trả lời” |

Mở lại report trả nội dung nguyên bản, `as_of` và lớp cảnh báo hiện tại riêng. ACL/dependency bị thu hồi vẫn chặn nội dung theo quyền hiện hành; archive không tự đồng nghĩa revoke lịch sử. Cache key hoặc receipt ID không cấp thêm quyền.

### 4.4. Lỗi có hành động và không giả thành công

Lỗi có `code`, tiếng Việt dễ hiểu, target/outcome có thể công bố, revision/job/receipt refs được phép và `paid_dispatch_state`. HTTP 200 cho một query không có nghĩa đã đối chiếu mọi outcome. Không hiển thị đồng thời lỗi cuối và “đang xử lý”. Không in raw JSON, tên bảng hoặc đường nội bộ cho doanh nghiệp.

| Nhóm | Hành vi UI/API |
|---|---|
| `REVISION_CONFLICT`, `MANIFEST_CHANGED` | Giữ nháp, nêu bản đã đổi, mở so sánh; không tự ghép quyết định |
| `SOURCE_INCOMPLETE`, `CURRENTNESS_UNCONFIRMED`, `MEMBER_BLOCKED` | Chặn đúng phần, hiển thị nguồn/căn cứ còn thiếu và phần vẫn dùng được |
| `READ_REVOKED`, `SCOPE_DENIED` | Không trả trích đoạn/receipt chứa dữ liệu bị thu hồi; thông báo quyền trung tính |
| `SOURCE_FORMAT_INVALID`, `EXTRACTION_INCOMPLETE` | Nêu tên tệp hiển thị an toàn và trạng thái chưa dùng được; không để “đang đọc” kẹt |
| `BUDGET_REQUIRED`, `CONSENT_CHANGED` | Dừng trước model; không coi số dư/khóa API là consent |
| `MODEL_SENT_RESULT_INVALID`, `MODEL_OUTCOME_UNKNOWN` | Nói thật đã gửi hoặc chưa rõ; lưu raw/receipt theo quyền; không tự gửi lại có phí |

### 4.5. Công cụ wiki, import/export và filesystem ảo — P06

Các tên capability dưới là **thiết kế đích**, chưa có endpoint/tool mới. Không thay kiểm kê API hiện hữu ở đầu §4. Wire naming/DTO cuối phải qua implementation plan; REST/MCP/filesystem adapter gọi cùng service và validator.

| Capability logic | Contract / boundary |
|---|---|
| `knowledge.search/read/evidence` | READ hiện hành cho body/title/snippet/link/quote và closure; page/revision/hash và release refs. Không enqueue AI/fetch hoặc tự tạo job khi chỉ đọc |
| `knowledge.propose/edit/import` | Envelope operation identity/base revision, server-issued scope; lưu candidate/body/evidence đúng `knowledge-page-revision/1` tại tài liệu 02§7.4; exact replay READ trước mutation, lệnh mới WRITE/CAS/lifecycle |
| `knowledge.review/publish` | Mở rộng cùng governance service bằng typed wiki target, exact revision/hash, rationale/evidence/test refs; scope và artifact-kind capability phải explicit. Không tự cấp quyền mới cho tài khoản chuyên gia |
| `knowledge.export` | Xuất bản đúng manifest từ các input còn READ; `knowledge-markdown-bundle/1`, as-of và hash; không dựng nội dung bằng model. Tệp đã xuất ngoài hệ thống không thể bảo đảm thu hồi bản sao; rights/retention/export permission phải rõ |
| `enterprise.context` | Cùng SSOT resolver exact entity/field và dependencies; wiki không là đường ghi dữ kiện, không cho worker public đọc private |
| `model.dispatch` | Cùng Gateway consent/D06/egress/request manifest/reservation/dispatch fence, kể cả planner/compaction/consolidation/worker phụ |

Filesystem ảo chỉ là adapter cho các capability trên: released chỉ READ, workdir chỉ nháp đúng operation/actor/scope/revision. Không cấp local shell, arbitrary path/SQL hoặc raw provider access. Giới hạn file-tool của framework không thay service ACL cho MCP/custom tools. Không import file nguồn như trusted skill/system instruction; config/skills DTT do pipeline quản lý riêng.

Import Markdown/OKF là candidate: parse/kiểm kind/ID/path/link/size/signature và tách nội dung khỏi authority. `status: stable`, `verified: human:...`, broken-link policy hoặc mặc định của format không mở quyền/phát hành. Export/import mapping OKF có version và conformance/round-trip tests riêng, chưa cam kết consumer Google/Viettel. UI không hiện thành “đã đồng bộ Google” khi mới xuất file.

## 5. Trải nghiệm chủ doanh nghiệp: trợ lý làm trung tâm

Wiki phục vụ phía sau chat: kết luận và việc làm ở đầu, nguồn tiếng Việt/bản gốc mở khi cần. Chủ cơ sở không phải chọn folder, page ID, graph, format hoặc framework. Trang nguồn hiện revision/as-of/trạng thái cần rà bằng lời dễ hiểu; bài wiki là giải thích có căn cứ, không hiển thị như văn bản pháp lý do cơ quan ban hành. Không tự đổi kết quả lịch sử khi wiki mới được phát hành; cảnh báo hiện hành là lớp riêng.

### Một câu nhiều mục tiêu, không thêm một màn thủ tục

Ví dụ: **“Chị muốn xuất khẩu Trà Sen sang Mỹ và nhờ Hà Nội hỗ trợ đào tạo nhân viên làm sổ sách buổi tối.”** Trợ lý chia hai outcome rõ trong cùng chat: nghĩa vụ xuất khẩu và nhu cầu chính sách/kiến nghị. Không mặc định chuyển tất cả sang số hóa kho, không bỏ đào tạo, không cho thị trường Mỹ trở thành mặc định của hội thoại mới.

Trình tự hiển thị mobile:

1. Bong bóng giữ nguyên câu người dùng và xưng hô đã xác định. Dưới đó là kết luận ngắn về phần đã biết và phần cần làm tiếp.
2. Một thẻ gọn “Mình sẽ giúp chị 2 việc” thể hiện phạm vi; dùng lại đúng sản phẩm Trà Sen và dữ kiện đã xác nhận. Nếu thiếu một dữ kiện quan trọng, hỏi **một câu cần nhất**; không hỏi lại facts đã chốt hoặc lặp form hồ sơ.
3. Phần chính sách nói thật độ phủ: “Đã tìm thấy đầu mối… / Chưa đủ căn cứ đối chiếu điều kiện…” khi chưa có rule được duyệt. Đề xuất chuẩn bị câu hỏi/kiến nghị không bị gắn nhầm là đăng ký tham gia được duyệt.
4. Phần xuất khẩu có các nghĩa vụ trong intent và các nghĩa vụ bắt buộc được policy planner xác định, mỗi mục có nguồn/gap. Không gói prior notice vào nhãn hoặc để “ba việc đầu tiên” thành câu làm rõ rồi bỏ nghiên cứu.
5. Ba việc tiếp theo đặt theo tính phụ thuộc/rủi ro, có hành động và đầu ra. Nếu chỉ có hai việc có căn cứ thì trả hai việc và nêu phần chưa rõ; không bịa cho đủ ba.
6. Nguồn, ngày kiểm, phần nguyên văn, chi phí và lịch sử bản đặt trong mục mở rộng có nhãn dễ hiểu. Kết luận và cảnh báo ảnh hưởng quyết định không được giấu trong mục chi phí.

**Ví dụ lời nói khi kho chưa đủ:** “Mình đã tách yêu cầu của chị thành xuất khẩu sang Mỹ và đào tạo sổ sách buổi tối. Phần đào tạo hiện chưa có bộ căn cứ đủ để kết luận hỗ trợ; mình có thể giúp chị chuẩn bị nội dung đề nghị và chỉ rõ đầu mối cần xác minh.” Đây là mẫu UX, không phải kết quả đã tra hoặc thông báo một chính sách cụ thể đang mở.

### Nguồn mới và cache phải có nghĩa rõ

Doanh nghiệp không phải hiểu “TTL”, “pack” hay “D06”. Thẻ nguồn thể hiện: cơ quan, tên văn bản, ngày bản lưu, lần kiểm gần nhất, phần đang thiếu và “Xem bản gốc”. Nguồn tiếng Anh có nội dung tiếng Việt trước, nút xem nguyên văn; không để bản dịch che mất số liệu/điều kiện gốc.

Khi nguồn quá hạn kiểm: “Chưa xác minh lại được phần …; mình chưa kết luận phần này. Chị vẫn xem được báo cáo tại ngày …”. Không gọi là hết hiệu lực chỉ vì timeout. Khi có thay đổi: giữ báo cáo cũ, thêm cảnh báo hiện tại và nút xem thay đổi; không tự chạy đánh giá Claude mới.

Nút “Kiểm tra nguồn” là command rõ, cho biết đang dùng bản lưu hay có job đọc lại; nhiều người bấm cùng nguồn dùng chung job. Chọn “Đánh giá mới bằng AI” là hành động có phí riêng với dữ liệu/mức xử lý/phí dự kiến. Lịch nền không được phát sinh từ việc mở thẻ nguồn.

### Mobile và hỗ trợ tiếp cận là hợp đồng nghiệm thu

- 320 px và 390 px không tràn ngang; kết luận đầu, khối nguồn gập đúng; ô soạn và điều hướng không che câu trả lời. Tất cả vùng bấm thực ít nhất 44 × 44 px, kể cả checkbox/summary/nút phụ.
- Thay đổi workspace/hội thoại không mang nháp cũ sang đích mới. Nháp có scope/revision, dirty indicator và giữ sau reload; thao tác stale không tự sửa SSOT.
- Browser Back/Forward hoạt động trong app, kiểm scope hiện hành, phục hồi focus và không gửi lại lệnh.
- Hành động có tên gồm đối tượng khi cần: “Mở nguồn: …”, “Cất nháp kiến nghị: …”. Nội dung dài được rút hình thức nhưng tên truy cập đầy đủ.
- `aria-live` có chủ đích cho kết quả mới/lỗi; không đọc lại toàn chat sau mỗi poll. Form có label, `aria-invalid`, lỗi tiếng Việt gắn đúng field; accordion có trạng thái mở/đóng; không có heading/nút rỗng.
- PDF có bản xem trước/in, tên thương hiệu nMate, exact revision và nhãn chưa duyệt/đã duyệt đúng thực tế. File PDF chỉ là artifact của hồ sơ; không có con dấu hoặc ngôn ngữ giả phê duyệt của Hà Nội.

## 6. Trải nghiệm chuyên gia: ít thao tác nhưng nhìn đủ căn cứ

Console chuyên gia là workspace riêng, không biến chat doanh nghiệp thành màn quản trị. MVP có bốn vùng:

| Vùng | Nội dung thiết yếu |
|---|---|
| Hàng đợi | Nguồn mới/đổi, member chờ rà, việc quá hạn, phạm vi và mức rủi ro; bộ lọc theo domain/chính sách và người có quyền |
| So sánh | Trái bản cũ, phải bản mới; highlight phần thay đổi và liên kết quote locator tới trang/điều/bảng; bản dịch mở cùng nguyên văn |
| Rà rule/claim | Điều kiện/ngoại lệ/facts cần đọc, từng item có evidence, bộ ca thử và kết quả; nút từ chối/duyệt có rationale |
| Phát hành | Chỉ manifest đã qua rà; hash/revision, phạm vi áp dụng, ảnh hưởng, kiểm cổng và quyết định phát hành riêng |

Nguồn scan chất lượng thấp phải hiện trang/vùng không đọc chắc, không chỉ một điểm confidence tổng. AI có thể soạn đề xuất hoặc đánh dấu khác biệt nhưng không thay quyết định chuyên gia. Sửa một câu ở member tạo version mới; UI không giữ nút “đã duyệt” của bản cũ.

Workbench wiki bổ sung editor Markdown/xem trước tiếng Việt, diff body theo exact base revision, side panel claim/evidence gốc/bản dịch, backlink và impact closure. Nội dung/metadata đều qua READ; source bị revoke không lộ title trong hàng đợi. Chuyên gia phải thấy rõ “nháp”, “đã duyệt bản nào”, “đã phát hành bản nào” và “cần rà” độc lập; không dùng ngày sửa file để kết luận đã cập nhật luật. Conflict giữ nháp và mở diff, không tự chọn revision mới nhất bằng timestamp.

Nhóm có scope Phụ lục 03/N1–N4 không tự có scope toàn Hà Nội/xuất khẩu hoặc quyền tác giả/curator/wiki-artifact mới. Qualification capability wiki giữ đúng phân công hiện có, không tạo người giả hoặc mở grant chung. Một body sửa sau review luôn thành candidate mới; chưa publish không phục vụ như bản chính thức.

Khi `trung@dtt.vn` kiêm hai vai, console hiện “Vai hiện tại: rà nội dung” ở bước rà và “Vai hiện tại: phát hành” ở bước sau; ghi một danh tính với hai event. Không tạo hai tài khoản giả. Chuyên gia không được thấy tên doanh nghiệp/câu hỏi private trong hàng đợi domain trừ quy trình hỗ trợ riêng đã được cấp quyền.

**Đào tạo quy trình:** dùng gói “CHÍNH SÁCH KIỂM THỬ — KHÔNG DÙNG TƯ VẤN THẬT” trong namespace/environment riêng. Có thể mô phỏng approve/publish để kiểm flow, nhưng bản thử không xuất hiện retrieval sản xuất. Ca nghiệm thu nội dung thật phải lấy văn bản thật, được reviewer/publisher quyết định thật; không đổi nhãn fixture thành thật sau demo.

## 7. Chi phí và dữ liệu ra ngoài

### Một Gateway, mở rộng quyền có kiểu cho tác vụ domain

Gateway hiện hành kiểm authority theo **`(account_id, enterprise_id)`** và các khóa ngoại doanh nghiệp. Vì vậy service cập nhật kho công khai **chưa thể chỉ thêm một purpose rồi dispatch**. Thiết kế đích mở rộng envelope trong cùng Gateway thành `Subject(account | service)` và `Scope(enterprise | public_domain)`, với public-domain operation/attempt có authority đúng kiểu, dùng chung bộ reservation, ledger, dispatch fence, adapter và manifest. Không tạo doanh nghiệp giả hoặc membership giả cho DTT; không bỏ kiểm membership bằng cờ `system=true`; không tạo SDK/ngân sách phụ trong worker.

Public-domain service chỉ dùng **DomainGrant có giới hạn do DTT cấp**, ghim domain/chính sách/nguồn, purpose/capability, model profile, manifest/egress classification, trần lượt/tiền/token, môi trường và hiệu lực/thu hồi. Quyền này khác quyền reviewer/publisher và khác quỹ tester. Schema/namespace/idempotency cần có contract và ca âm trước triển khai; wire/receipt enterprise cũ vẫn đọc theo hợp đồng cũ, không remap sang domain scope. Khi envelope/authority mới chưa có hoặc grant chưa duyệt, AI nền phải `blocked_before_dispatch`; HTTP/parse xác định và hàng đợi metadata vẫn có thể chạy trong quyền đã cấp.

### Giữ ranh giới ngân sách và egress

HTTP tải nguồn công khai, parse PDF/text, SQL/FTS, đối chiếu rule, đọc lịch sử và kiểm trạng thái là các bước xác định ở baseline; không tự tạo paid call. Nếu OCR/LLM/dịch dùng dịch vụ trả phí, đó là capability riêng qua **Gateway hiện hữu** với service identity, manifest và grant nền, không phải một HTTP retry “miễn phí”. Chi phí hạ tầng vẫn cần đo dù bước đó không dùng Claude.

Tác vụ nền dùng nguồn công khai tối thiểu. Discovery query ra Internet không mang tên doanh nghiệp, doanh thu, câu chat hay tệp riêng khi không cần; ưu tiên danh mục/URL/feeds chính thức và topic generic. Nguồn thủ công phải xác nhận provenance, quyền dùng/chia sẻ và độ nhạy; tài liệu riêng doanh nghiệp không được đổi nhãn thành domain public bằng thao tác upload của DTT.

Nguồn lấy qua MCP/connector cũng là **dữ liệu chưa tin cậy**, không tự thành nguồn công khai hay mệnh lệnh điều phối. Adapter phải ghim server/tool contract, capability READ, provenance và ACL; output chứa yêu cầu mở tool/URL hoặc gửi private data không được thực thi. MCP trả tài liệu private chỉ được dùng trong phạm vi tài nguyên được cấp, không đi vào kho domain/public cache; thêm connector có egress/chi phí mới phải qua cùng cổng dữ liệu và ngân sách.

Trước bật AI nền phải trình một bảng: tập nguồn/loại trang, số snapshot dự kiến, số lần dispatch tối đa mỗi bước, model profile đã kiểm, input/output caps, giá cấu hình đã xác minh, trần ngày/đợt, retention/egress, cách dừng và người có quyền cấp. Chưa chốt thì chạy pipeline xác định tới hàng “cần trích xuất/rà”, không tự lấy tiền từ 20 USD tester hoặc từ ngân sách chủ doanh nghiệp.

Consent cho câu hỏi doanh nghiệp phải thể hiện đúng facts/trích đoạn gửi, mục đích, model, phí dự kiến và giới hạn. Đồng ý tài liệu nguồn công khai không phải đồng ý gửi toàn bộ SSOT. Consent cũ không tự áp cho dữ liệu, provider, capability hoặc purpose mới. Có API key, ngân sách dư hoặc raw response cũ đều không phải quyền dispatch mới.

## 8. Hành trình Trà Sen để kiểm kiến trúc

### Hành trình A — dùng kho hiện có, không giả chính sách đã duyệt

1. Chủ cơ sở mở đúng SSOT Trà Sen; hệ thống đọc liên kết canonical, không tự lấy sản phẩm đầu danh sách. Các facts đã chốt không bị hỏi lại. Dữ kiện còn thiếu được hỏi theo ưu tiên cho từng outcome.
2. Gửi câu về xuất khẩu Mỹ và đào tạo sổ sách buổi tối. Plan giữ hai mục, tên sản phẩm và yêu cầu cụ thể. Hành động chuẩn bị kiến nghị giữ nguyên ý “buổi tối”, không thay bằng “đăng ký chương trình số hóa kho”.
3. Với nguồn Hà Nội hiện chưa đủ bộ căn cứ/rule, trợ lý chỉ trả đầu mối/giới hạn và nháp đề nghị theo quyền. Không hiện “đủ điều kiện”, “đang mở” hay “đã nộp”.
4. Phần xuất khẩu dùng đúng gói nguồn Mỹ, phủ FDA/cơ sở/US agent, prior notice, nhãn/nước xuất xứ, trách nhiệm bên nhập khẩu trong phạm vi căn cứ. Mục nào thiếu nguồn hoặc facts thì ghi riêng; không làm hỏng phần độc lập.
5. Nếu dùng Claude thật, tester chủ động xác nhận trong quỹ hợp lệ; lưu model thực, manifest, usage/phí và trạng thái công bố. Reload giữa chừng/mở kết quả không gọi lại. Lỗi sau dispatch nói thật về phí và giữ kết quả/receipt theo quyền.
6. Sửa một fact SSOT hoặc nguồn thay đổi: report cũ giữ nguyên, có cảnh báo phụ thuộc đúng phần. Không mất nháp kiến nghị, không tự đánh giá có phí.

### Hành trình B — sau khi có một bộ chính sách thật đủ căn cứ

Lát cắt đầu đề xuất tiếp tục **`HN-DIGITAL-CONSULTING-2026`/Phụ lục 03**, tận dụng phạm vi chuyên gia đã được chỉ định; không khẳng định chương trình này đáp ứng nhu cầu xuất khẩu/đào tạo nếu chưa có căn cứ. Phát hiện/nhập đủ văn bản và phụ lục, lưu snapshot/locator → parser/AI được phép đề xuất claim/rule → chuyên gia rà từng exact version → publisher phát hành manifest. Chỉ lúc đó query mới có thể đối chiếu điều kiện có căn cứ, vẫn phân biệt tình trạng nhận hồ sơ và kết luận của cơ quan. Nguồn hoặc chính sách mới ngoài scope hiện hữu cần phân công quyền rõ trước thao tác tương ứng.

Hai doanh nghiệp hỏi cùng chủ đề dùng chung snapshots/member/pack, không tải lại hay trích xuất lại vô ích. Facts và kết quả áp dụng vẫn riêng; doanh nghiệp B không đọc chat, tên nhân viên, tài liệu hoặc kết luận riêng của Trà Sen. Một nguồn đổi chỉ chạy một job; graph xác định phần nào trong hai ca cần cảnh báo. Phần không phụ thuộc vẫn dùng được theo D07-A.

### Hành trình C — kiến nghị và tham gia

Trợ lý có thể tạo nháp kiến nghị hoặc nháp đăng ký khác loại với trích dẫn và SSOT snapshot rõ ràng. Người có quyền xem/sửa/duyệt bản riêng; PDF ghi đúng trạng thái revision. **Chưa có API iHanoi thì chỉ chuẩn bị và hướng dẫn kênh chính thức**. Duyệt PDF, phát hành tri thức hoặc bấm tải file không gửi đi. Sau này connector cần consent/đích nhận/phiên bản riêng và biên nhận thật; phải xin chốt quy trình trước bật gửi.

## 9. Bộ kiểm TDD trước triển khai

Đây là kế hoạch ca kiểm, **chưa chạy và chưa đạt**. Mỗi change bắt đầu bằng RED thể hiện bất biến bị thiếu; GREEN không chỉ kiểm helper mà phải có đường MCP/BFF/service/DB thực. Ghi DF ID trong test note và evidence; không đưa dữ liệu private/khóa/mật khẩu vào artifact.

| Nhóm / mã | Tình huống bắt buộc | Kết quả phải chứng minh |
|---|---|---|
| GOV-01 | AI/curator/owner cố approve hoặc publish ngoài scope; model chèn yêu cầu cấp quyền | Từ chối trước mutation, không có review/release event giả |
| GOV-02 | `trung@dtt.vn` kiêm hai vai | Hai quyết định riêng exact version/hash; không tự publish; audit phản ánh cùng người |
| GOV-03 | Sửa member sau approve; đổi manifest khi console còn mở | CAS/hash conflict; không phát hành version chưa rà |
| GOV-04 | Publisher bị revoke giữa preview và commit; source READ bị revoke | Lệnh mới bị chặn; không lộ input/output; ownership không vượt nguồn bị revoke |
| GOV-05 | Exact receipt sau mất WRITE nhưng còn READ; cùng operation khác payload | Replay đúng receipt không gọi lại; payload khác conflict; READ revoke thắng replay |
| GOV-06 | Member bị rút trong một pack nhưng còn trong pack khác | Không đánh giá qua pack khác; report cũ có cảnh báo, không tự hồi sinh bản trước |
| SRC-01 | HTML 200 nhưng trang lỗi/login; PDF giả, file đổi đuôi, scan trắng/OCR sai | Quarantine/gap đúng tên tệp; không accepted-as-complete; không sinh rule dùng được |
| SRC-02 | Quote cũ còn nguyên, thêm ngoại lệ hoặc thiếu phụ lục | Đúng dependency bị needs_review/blocked; không “hiện hành” từ exact quote |
| SRC-03 | HTTP 304/không đổi, timeout/403/429/5xx, hết hạn kiểm | Observation riêng; không gia hạn pháp lý; D07-A chặn đúng outcome |
| SRC-04 | Nguồn Anh có phủ định/đơn vị/ngày; bản dịch khác nghĩa | Quote locator ngôn ngữ gốc đúng; claim phụ thuộc chưa usable |
| SRC-05 | URL redirect ngoài allowlist, private/loopback, MIME/bytes quá lớn, prompt injection | Fetcher chặn đúng, không đọc mạng nội bộ/secret; data không thành instruction |
| EVT-01 | Crash trước/sau snapshot, review, release transaction và outbox; phát lại event | Không half-release, duplicate approval/cảnh báo hoặc mất event; consumer đúng causality |
| EVT-02 | Hai tab/two workers cùng refresh hoặc publish; lease cũ hết | Một job/source, CAS/fence đúng; không dùng timestamp+UUID thay quan hệ nhân quả |
| RET-01 | Source/rule mới, index chưa cập nhật; index trả hit cũ/bị block | Gate SQL có thẩm quyền lọc; không lộ draft hoặc dùng stale hit |
| RET-02 | Cùng nguồn, hai doanh nghiệp; private MCP/tệp/SSOT xen vào public corpus | Public snapshot dùng lại; private refs/query/answers không rò; revoke áp ngay trước render/download |
| RET-03 | Ngày mục tiêu quá khứ, mở report cũ và lập đánh giá mới quá khứ | Phân biệt as-of/known-at/history READ; không lách current block/ACL hoặc viết đè raw/receipt |
| INT-01 | Xuất khẩu + đào tạo sổ sách; OCOP/nhãn hiệu; ngoài phạm vi | Mỗi mục có outcome/trạng thái riêng; không cùng gói cố định hoặc trạng thái giả “đã có kết quả” |
| INT-02 | Câu tự nhiên Trà Sen/Mứt Sen, nhiều sản phẩm/market, SSOT rỗng | Binding rõ, giữ hoa/thường, không mượn hồ sơ; hỏi ít nhất cần thiết; không ghi facts tự động |
| COST-01 | Chỉ status/cache/recovery/reload/download/FTS, fake adapter fail-if-called | 0 dispatch và không tăng reservation/usage; ghi rõ là replay, không báo Claude mới |
| COST-02 | Service ingestion không DomainGrant; thử dùng pool 20 USD tester, enterprise giả hoặc `system=true`; mất consent/price/profile | Dừng trước dispatch, không cấp child grant ngoài phạm vi; cùng Gateway/ledger, không membership shortcut hoặc transport phụ |
| COST-03 | Provider đã nhận nhưng timeout; output thiếu mục hoặc sai citation | Giữ raw/hold/receipt, phân biệt phí và công bố; không tự retry/fallback/rewrite có phí |
| UI-01 | 320/390 px, reload/back/forward, callback từ workspace cũ, nháp chưa lưu | Không mất mạch/nháp, không cross-scope mutation; focus và dirty status đúng |
| UI-02 | Screen reader/keyboard: kết quả/lỗi mới, nút nguồn, form, accordion/PDF denied | Tên truy cập, live region, aria states và lỗi tiếng Việt đúng; không leak JSON/nguồn bị revoke |
| MIG-01 | Old snapshot/report/receipt/schema, upgrade/restart/rollbackcode | Đọc đúng hợp đồng cũ và quyền; không tự seed, backfill facts, enqueue AI hay hồi sinh policy bị rút |
| WIKI-01 | Tạo/sửa/đọc/diff, đổi title/slug, hai editor cùng base revision | Stable ID, immutable body/parent/hash, CAS conflict giữ nháp; không chọn identity theo tên gần giống |
| WIKI-02 | Import có `stable`, `verified`, lệnh bỏ kiểm duyệt, link/path escape; cố sửa trusted skill | Chỉ candidate trong scope; không authority từ nội dung, không thực thi code hoặc đọc URL/path ngoài quyền |
| WIKI-03 | Đã review rồi sửa body/claim/evidence; review rule nhưng chưa review trang | Exact revision/hash/target-kind gate; không approval kế thừa hoặc nửa release |
| WIKI-04 | Crash sau SQL commit/trước file materialize, file sửa tay hoặc generation cũ | Receipt/body chuẩn còn nguyên; rebuild projection không AI; không phục vụ hash/gate sai |
| WIKI-05 | Source/field READ bị revoke sau tạo trang, search hit hoặc export preview | Chặn đúng closure trước trả title/snippet/backlink/body/export; ownership/cache không vượt revoke |
| WIKI-06 | Source thêm ngoại lệ, bản dịch đổi, call hết hạn; link navigation còn tốt | Dependency invalidation và freshness canonical; không dùng graph link/HTTP304 làm hiệu lực |
| WIKI-07 | Wiki tự trích wiki, claim không về raw, quote có thật nhưng kết luận sai | Lint binding/closure và reviewer chuyên môn chặn; không nhận schema/quote-match là đủ đúng luật |
| WIKI-08 | Public worker nhận chat/facts riêng, đổi workspace hoặc callback từ revision cũ | Không private-to-public K1, full scope fencing; SSOT không tự thay; giữ nháp gốc |
| WIKI-09 | Framework planner/compaction/worker phụ/consolidation/provider retry; resume unknown | Tất cả dispatch qua Gateway chung, không paid auto retry; READ/status/rebuild 0 model; adapter chưa qualification không được bật |
| WIKI-10 | Export/import round-trip, thiếu trust metadata, ID/hash xung đột, source revoke | Mapping có version, không tự cấp approval hoặc hồi sinh release; export permission/rights rõ, bản sao ngoài hệ thống có giới hạn thu hồi |

**Các kiểm bảo toàn dữ liệu:** so hash raw assertions/snapshots/decisions/receipts trước/sau; expected immutable rows không đổi. Những field có qualifier vẫn dùng registry/base field key để phân loại nhưng giữ nguyên exact key/value/phạm vi. Test không sửa dữ liệu cũ để “đạt”.

## 10. Nghiệm thu độc lập và đánh giá Claude thật

Người kiểm độc lập không chỉ đọc báo cáo do người sửa tạo. Tối thiểu có hai vòng:

1. **Đường quyết định xác định:** dùng nguồn/fixtures công khai trong namespace thử, tái hiện lỗi/race/revoke/crash và kiểm SQL/events/receipts. Đây không phải đánh giá chất lượng Claude thật.
2. **Đường chất lượng thật:** sau duyệt triển khai, trên build đóng gói cố định và bộ nguồn/phát hành thật đã đủ cổng, dùng Claude thật qua MCP/app với quỹ đúng scope. Ghi câu hỏi, outcome matrix, facts/evidence manifests, model thực, token/phí, latency, chỗ bị chặn và khả năng tự phục vụ. Không gọi thêm chỉ để cải thiện điểm ca thất bại.

Tiêu chí tối thiểu trước nghiệm thu lát cắt:

- **An toàn không có ngoại lệ nghiệm thu:** không leak chéo doanh nghiệp, không AI tự approve/publish, không lách D05/D07, không dispatch thiếu consent/grant, không paid replay. Một ca vi phạm là dừng phát hành.
- **Độ phủ:** mọi ý của bộ câu hỏi Trà Sen có outcome và câu trả lời/gap rõ; không bỏ prior notice, đào tạo hoặc yêu cầu buổi tối giữa intake→plan→answer→PDF.
- **Căn cứ:** mọi kết luận điều kiện, mức tiền, deadline/checklist và trạng thái nhận có loại evidence phù hợp; quote locator mở đúng phiên bản. Không chấm một JSON hợp lệ là tư vấn đạt.
- **Dùng lại:** hai doanh nghiệp dùng cùng source revision trong TTL dùng chung quan sát/job; facts/answers riêng. Chứng minh không thêm HTTP/model khi mở lại, không chỉ đếm response `cached=true`.
- **Nhất quán:** review/release exacthash, state machine và outbox qua crash; cùng semantics ở chat/MCP/direct mission. Không có entry point legacy vượt gate.
- **UX:** chủ cơ sở hoàn thành hành trình mobile không cần biết D06/pack/TTL; không vòng hỏi lặp; giữ nháp/reload; region/touch/focus được kiểm bằng thao tác thật.
- **Chi phí có thể đối soát:** số dispatch thực khớp marker/request ID/usage. Chưa biết phí phải ghi “chưa đối soát”, không 0 USD. Không tăng quỹ để làm ca lỗi biến mất.

Hồ sơ nghiệm thu gồm frozen build/hash, phiên bản schema/contract/prompt/evaluator/model, tập nguồn và thời điểm, script ca, ảnh mobile, log đã làm sạch, kết quả kiểm độc lập và các ca chưa kiểm. Nếu còn không đủ nguồn pháp lý thì đánh giá pipeline/UX riêng, **không tuyên bố đã nghiệm thu tư vấn hiện hành**.

### 10.1. Hợp đồng metric và bằng chứng nghiệm thu có thẩm quyền

Đây là nơi định nghĩa chuẩn cách đo cho bộ thiết kế. Các mục khác dẫn về đây, không tự đặt mẫu số hoặc ngưỡng khác. Tất cả ngưỡng là đề xuất và mọi phép đo hiện ở trạng thái chưa chạy.

#### 10.1.1. Bộ câu hỏi chuẩn do chuyên gia xác nhận

Trước K1, đóng băng một **gold corpus có phiên bản/hash**: câu hỏi tự nhiên, từng outcome cần phục vụ, bối cảnh/SSOT được phép, ngày mục tiêu, bộ căn cứ/version, kết luận hoặc gap đúng, ngoại lệ, và các hành động chấp nhận được. Chuyên gia đúng scope xác nhận đáp án tham chiếu; tester độc lập chạy và đối chiếu. Không lấy câu trả lời Claude, output lần chạy trước hoặc danh sách URL làm đáp án chuẩn.

Corpus K1 phải có ít nhất một ca cho mỗi lớp: đủ điều kiện theo rule; không đạt; chưa biết vì thiếu fact; xung đột fact; ngoại lệ/không thuộc đối tượng; nguồn/phụ lục thiếu; quá hạn kiểm; cửa tiếp nhận chưa biết; ngoài phạm vi; và câu có nhiều outcome trong đó chỉ một phần trả lời được. Có ca “xuất khẩu + đào tạo sổ sách buổi tối” để kiểm giữ đủ ý, nhưng gold pháp lý của domain mở rộng chỉ được công nhận sau phân công chuyên gia và căn cứ tương ứng; phạm vi Phụ lục 03 không tự thành quyền thẩm định FDA hoặc mọi chương trình đào tạo.

Mỗi ca ghi các mệnh đề quan trọng mong đợi hoặc bị cấm, quote locator chính xác và lý do. Khi rule/source/corpus đổi, tạo phiên bản mới rồi đánh giá lại đúng phạm vi; không sửa đáp án cũ sau khi nhìn kết quả để làm điểm tăng. Corpus phải có kết quả thật sự trả lời được và kết quả phải dừng; bộ toàn gap hoặc không có critical claim không đủ để nghiệm thu chất lượng tư vấn.

#### 10.1.2. Hợp đồng metric chuẩn: mẫu số, nguồn đo và ngưỡng

Các công thức và ngưỡng sau là **tiêu chí đề xuất trình duyệt**, chưa phải số liệu đã đo. Mỗi kết quả phải kèm corpus/build/version, khoảng thời gian, query đo hoặc event contract và số lượng mẫu thô. Mẫu số bằng 0, thiếu event hoặc không đủ evidence thì ghi `not_evaluable/unknown`, không ghi đạt 100% hoặc 0 lỗi.

| Metric | Tử số / mẫu số và phạm vi | Cách thu và đối soát | Cổng nghiệm thu đề xuất |
|---|---|---|---|
| `outcome_coverage` | `(outcome được trả lời đủ + outcome có gap/blocked/out-of-scope tường minh đúng lý do) / tổng outcome tham chiếu trong corpus` | So intent→plan→answer→artifact với từng outcome ID/question span trong gold; ý bị gộp hoặc rơi không được tính | **100% trên gold corpus**. Gap là coverage, **không phải đã trả lời** |
| `answered_outcome_rate` | `outcome được trả lời có căn cứ / tổng outcome corpus`; tách theo lớp mà gold xác định có đủ nguồn/facts và lớp phải gap | Ghi kết quả theo từng ca; so với gold, không tính câu chung chung hoặc nói “đã ghi nhận” là answered | Mọi outcome gold yêu cầu trả lời phải trả lời đúng; mọi outcome gold yêu cầu dừng phải dừng. Báo tỷ lệ tổng và các lớp, không đặt một tỷ lệ tổng để che bỏ ý khó |
| `evidence_support_rate` | `critical claims được gold xác nhận có đúng evidence / toàn bộ critical claims đã công bố đủ điều kiện đánh giá trong tập nghiệm thu` | Tách từng claim về điều kiện/ngoại lệ, mức tiền, deadline, checklist, thủ tục, hiệu lực/cửa nhận; mở exact quote/snapshot/translation và applicability | **100% trên gold corpus**, không có critical claim thiếu/sai căn cứ. Claim bịa, ngoài gold hoặc không map được phải tính chưa được hỗ trợ, không loại khỏi mẫu số để tăng điểm. Mẫu số 0 không đủ nghiệm thu |
| `policy_completeness` | `required companion/document refs được chuyên gia xác nhận đủ, đọc được và đúng version / toàn bộ required refs trong coverage manifest của chính sách K1 đã chọn` | Chuyên gia kiểm văn bản nền, sửa đổi, phụ lục, định nghĩa/ngoại lệ, thủ tục/cửa nhận cần cho phạm vi claim; manifest cùng evidence/review refs có hash | **100% đối với bộ căn cứ bắt buộc của phạm vi chính sách K1 định phát hành**. Không lấy số URL/snapshot làm độ đầy đủ. Nếu chưa xác định được toàn bộ required refs thì trạng thái `coverage_unknown`, chưa đạt |
| `refresh_lag` | Thời gian `checked_at - due_at` cho từng lượt đến hạn, không phải tỷ lệ HTTP thành công | Event lịch `due_at`, source/profile revision và observation `checked_at`; phân loại success/unchanged/failure/cancelled. Ghi phần chờ khi app/worker online riêng với downtime; ca chưa kiểm ghi tuổi overdue hiện tại, không 0 | Không đặt SLA giây/phút trước K1 qualification. Phải quan sát được mọi job đến hạn, không mất job, không “fresh” giả. Downtime/worker không chạy phải thể hiện rõ, không báo lịch local là hoạt động 24/7 |
| `review_lag` | Thời gian từ `ready_for_review_at` đến decision của đúng member version; tách processing và human wait | Events tiếp nhận đủ/rà bắt đầu/yêu cầu bổ sung/quyết định; thời gian parser/validator/queue khác thời gian chờ chuyên gia. Version bị từ chối và version tiếp theo là các chu kỳ riêng | Hiển thị số lượng, phân bố và tuổi hàng chờ; **không hứa SLA con người khi chưa thỏa thuận**. Ca còn chờ là pending/open-age, không tính như đã hoàn tất 0 giây |
| `fetch_avoided_rate` | `cơ hội đọc lặp đủ điều kiện được phục vụ từ kho không fetch / tổng cơ hội đọc lặp đủ điều kiện tái sử dụng cùng exact source/representation/rights/profile/version` | Gắn opportunity IDs và source refs ở resolver, đối chiếu job/HTTP-attempt events trong cùng trace; loại đúng các ca buộc revalidate vì đổi/quá hạn/thu hồi. Không suy từ nhãn `cached=true` | Kịch bản 100 câu hỏi/2 doanh nghiệp ở mục 10.1.3; status/history READ không fetch hoặc model. Báo cả raw counts và các lần fetch hợp lệ ngoài mẫu, không bỏ lỗi thành “không đủ điều kiện” sau khi chạy |
| `extraction_reuse_rate` | `cơ hội tái sử dụng derivation cùng input hash/parser-layout-language/schema/rights versions được dùng lại / toàn bộ cơ hội đủ điều kiện đó` | Extraction manifest/receipt và lần chạy processor/Gateway thực; giữ provenance khi dùng lại; không semantic-cache private answers giữa doanh nghiệp | Kịch bản 10.1.3 không có extraction/model derivation lặp theo số doanh nghiệp. Processor/schema/input đổi phải tạo version mới, không coi là cache miss vô ích |
| `privacy_incidents` | Số lần trả nội dung/metadata không được phép ở UI, MCP, nguồn, raw, artifact, PDF hoặc cache trong toàn bộ ca quyền/thu hồi | Đối chiếu allow/deny matrix, exact input/output dependency ACL và kiểm nội dung phản hồi; cả đường trực tiếp lẫn report dẫn xuất | **0 — cổng cứng**. Denial đúng quyền không phải incident. Thiếu trace/không quan sát được không được báo 0 như đã kiểm |
| `unauthorized_dispatches` | Số dispatch thiếu đúng authority/consent/egress/grant/environment/model-purpose scope tại thời điểm gửi | Join operation, sealed manifest, authority revision, reservation, dispatch fence và provider request ID theo exact attempt; thử chặn các đường bypass | **0 — cổng cứng**; API key hoặc số dư không thay quyền. Một ca vi phạm dừng phát hành |
| `automatic_paid_retries` | Số dispatch có phí bổ sung của cùng logical step mà không có quyết định mới hợp lệ của người có quyền | Đối chiếu marker/outbox/SDK config và request IDs qua crash/reload/timeout/unknown; đổi tên operation không hợp thức hóa retry | **0 — cổng cứng**. Chủ động đồng ý một tác vụ mới phải có manifest/consent/grant mới và được báo riêng, không giấu trong metric retry |

Các metric tỷ lệ phải công bố **cả tử số/mẫu số**, danh sách ca thất bại và lý do loại mẫu đã chốt trước chạy. Critical claims không có evidence không được hạ xuống “chữ trang trí” để vượt cổng. Ngoài các tỷ lệ, kiểm nguyên văn/nội dung yêu cầu cụ thể trong nháp và PDF, như “buổi tối”, để tránh kết quả có đủ nhãn outcome mà mất nhu cầu thực.

#### 10.1.3. Ca đo dùng lại cụ thể: 100 câu hỏi, hai doanh nghiệp

Đây là một ca nghiệm thu được thiết kế, **chưa chạy**; 100 câu hỏi không đồng nghĩa 100 lượt Claude có phí.

1. Đóng băng một public source version và extraction/pack đủ gate, hai tài khoản/doanh nghiệp, rights partition, source profile, thời gian đánh giá trong freshness window; đặt private SSOT khác nhau. Lưu baseline events/HTTP/Gateway counters.
2. **Cold setup riêng:** nếu chưa có snapshot/extraction thì command chuẩn tạo tối đa một fetch và một extraction cho cùng processing key. Setup phải có scope và dữ liệu phù hợp; dùng deterministic/local extraction K1, không tự bật AI nền. Các bước discovery/companion khác không bị nhập nhằng là cùng nguồn trong mẫu.
3. Chạy 100 câu hỏi tra cứu/repeat opportunities phân bố qua hai doanh nghiệp, gồm xen kẽ/concurrent và reopen/status. Khi nguồn/processing version vẫn fresh, kỳ vọng **0 fetch và 0 extraction mới trong 100 lượt lặp**; tổng cold setup + repeat không quá một lần cho cùng exact key. Nếu bắt đầu warm thì tổng kỳ vọng 0. Không dùng lại lời tư vấn riêng của A cho B.
4. Kiểm SQL/job/HTTP/processor/provider events, không chỉ response UI. Query chuẩn, history/status/recovery trong ca có **0 model calls**. Đánh giá chất lượng Claude thật là bộ ca riêng được đồng ý, không cần trả phí cho 100 lần kiểm reuse.
5. Đổi nguồn/quá hạn/rights trong ca tách biệt: một explicit refresh được gộp, đúng outcome bị chặn/needs-review; không cố giữ tỷ lệ reuse bằng cách bỏ cổng. Khi rights không còn thì từ chối đọc ngay, không “cache hit” trái phép.

Kết quả báo raw counts `eligible_repeat_opportunities`, `avoided_fetches`, `http_attempts`, `processor_runs`, `paid_dispatches`, cùng source/processing/dependency hashes. Việc hai doanh nghiệp đều nhận HTTP 200 hoặc cùng `cached=true` chưa chứng minh dùng lại an toàn.

#### 10.1.4. Chi phí, token và provenance kết quả

Mỗi kết quả đo gắn `execution_mode` có kiểu: deterministic/local, replay kết quả đã lưu, hoặc paid model attempt mới; có configured model profile và model thực trả về khi đã gửi. Không gắn nhãn Claude cho bước local hoặc replay như lần gọi mới.

Đối với model mới, báo input/output/cache/thinking token theo receipt thực mà provider hỗ trợ, price-catalog version và trạng thái chi phí `estimated / reconciled / unknown`. Token không có hoặc phí chưa xác minh giữ **null/unknown**, không đổi thành 0 hoặc cộng cache như miễn phí khi chưa có căn cứ. Unknown dispatch giữ reservation/đối soát theo Gateway; bảng chi phí nêu phần chưa biết. Chỉ báo 0 dispatch khi đối chiếu đầy đủ marker/request ID/receipt và các bước xác định không gọi adapter.

`cost_per_testcase` phải gồm tất cả paid attempts của ca, kể cả lỗi validator/chưa công bố; `cost_per_published_answer` là metric khác, có mẫu số và số ca không ra kết quả riêng. Không loại các lượt hỏng để làm chi phí trông thấp. So model/prompt chỉ giữa những corpus/config tương đương, phân biệt cache warm/cold và model binding/version. Quỹ QA local đúng scope được dùng khi còn hiệu lực; metric không tự cấp tiền hoặc quyền AI nền.

#### 10.1.5. Latency và throughput: đặt mục tiêu sau qualification K1

K1 trước hết đo baseline trên **máy local cụ thể**: cấu hình CPU/RAM/OS/runtime/worker, corpus và loại PDF/text/scan, bytes/trang, số nguồn/dependencies, database size, concurrency, mạng và phiên bản processor. Ghi cold/warm riêng, số mẫu/số lỗi, cách tính percentile; không quảng bá p95 từ một lượt hoặc bỏ timeout khỏi phân bố. Dùng elapsed time đơn điệu cho thời lượng thực thi và event time có timezone cho lịch đến hạn.

Tách latency theo bước: lookup/gate SQL; fetch; parse/OCR; queue; human wait; model; validation/publication; render. Throughput có đơn vị cụ thể như snapshot/giờ hoặc lookup/giây và cấu hình concurrency; không gom việc chờ con người vào năng lực CPU. “Đã hiện tiến độ” và “đã đọc xong” là hai mốc khác nhau.

**Chưa đặt SLA latency/throughput trong tài liệu này.** Sau qualification K1, mang kết quả/mẫu/điều kiện và đề xuất mục tiêu có biên tài nguyên ra duyệt trước cam kết pilot. Dù chưa có SLA thời gian, không được có pending không giải thích, status lệch với terminal state, job mất hoặc kích hoạt paid retry nhằm đạt mốc tốc độ. Bộ ca an toàn, quyền và nội dung ở trên vẫn là cổng cứng.

#### 10.1.6. Từ yêu cầu đo sang bằng chứng nghiệm thu

Artifact của vòng triển khai cần một metric manifest chứa metric contract version, frozen corpus/build/config hashes, khoảng thời gian và môi trường, tử số/mẫu số/raw counts, danh sách event/receipt refs đã làm sạch, kết quả `pass / fail / not_evaluable / not_run`, người kiểm và hạn chế. Có thể xuất Markdown/JSON để đối soát; không đưa toàn văn private vào telemetry hoặc dịch vụ theo dõi mới.

Tại ngày lập thiết kế, các metric trên đều là **`not_run`/đề xuất**. Duyệt tài liệu không biến chúng thành số đo hoặc nghiệm thu. Reviewer độc lập xác nhận phương pháp/mẫu, tái hiện một số ca từ refs và nêu phần chưa quan sát được; lỗi nghiêm trọng hoặc mẫu số rỗng không được thay bằng nhận xét “cảm giác tốt”.

### 10.2. Benchmark wiki và harness — phương pháp canonical theo P06

Mục này cụ thể hóa phép so sánh ở nghiên cứu 05; số đo/tử số/mẫu số và artifact dùng §10.1, không tạo authority metric thứ hai. **Chưa chạy A/B hoặc gọi model trong đợt cập nhật thiết kế.**

| Nhánh | Mục tiêu | Biến kiểm soát |
|---|---|---|
| A — SQL/FTS + raw evidence | Baseline không wiki biên soạn | Cùng corpus/source/rights/gold/model và trần dispatch/token |
| B — A + wiki/typed links | Đo đóng góp lớp tri thức đã tổng hợp | Giữ runtime/model của A; tính cả build/bảo trì wiki |
| C — B + Deep Agents adapter, tùy chọn | Đo đóng góp harness | Chỉ sau qualification/budget riêng; cùng Gateway/evidence, không cộng lợi ích đổi corpus/model vào framework |

Pilot đề xuất **30 câu gold do chuyên gia đủ scope xác nhận**: 8 multi-intent, 6 điều kiện/ngoại lệ, 6 nguồn/đợt/hiệu lực đổi, 4 diễn đạt Việt–Anh, 3 thiếu căn cứ/ngoài phạm vi, 3 quyền/chéo doanh nghiệp. Chưa đủ nguồn thật thì `not_evaluable` cho phần đó, không fixture giả luật để đánh giá chất lượng pháp lý. Bộ kiểm contract/ACL/crash riêng không cần gọi AI cho từng ca.

Các cổng: không bỏ mục tiêu trong 8 ca; claim vật chất trong gold trace về đúng nguồn/rule và được chuyên gia kiểm; không fabricated citation; 0 unauthorized dispatch/leak/paid replay; phát hiện các lỗi lint được gieo. Gap được báo đúng không tính là tư vấn đầy đủ. B không kém A về chất lượng/coverage; nếu chưa có lợi ích tổng chi phí hoặc công chuyên gia thì chưa mở rộng. Các tiêu chí này chưa là kết quả đã đạt.

Đo riêng build + maintenance + N×query, token từng bước kể cả planner/compaction/worker phụ, thời gian reviewer và độ trễ hệ thống. Đo trang/claim thiếu support, trang đến hạn chưa rà, link quan trọng hợp lệ, growth/update/contradiction qua nhiều đợt. Một demo không chứng minh bảo trì gần 0 hoặc tiết kiệm tỷ lệ cố định. Điểm hòa vốn chỉ tính khi có mẫu/thành phần đo thật và chất lượng tương đương.

### 10.3. Hồ sơ qualification framework/định dạng

Trước POC, pin dependency/spec commit và đọc lại license/capability; kiểm mọi hidden model call/retry/trace/egress, namespace lâu dài, READ/WRITE và crash/recovery. Không mặc định bật external tracing hoặc memory background. Mẫu cấu hình chạy phải qua allowlist capabilities, Gateway manifest và grant đúng public-domain, không mượn tester enterprise. `max_turns` hoặc budget flag của SDK không thay reservation D06 hoặc thành trần hóa đơn tuyệt đối.

Các bài nghiên cứu và tài liệu nhà phát triển trong05 là cơ sở chọn ứng viên, không là chứng cứ runtime qualification. POC vượt điều kiện thì giữ LangGraph/native services và tắt adapter, không tự fallback gọi model/provider khác.

## 11. Các đầu việc triển khai đề xuất sau khi duyệt

[Kế hoạch milestones 07](<07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>) cụ thể hóa thứ tự W/K thành M0–M5, M6/K2 và M7. Theo yêu cầu người dùng, cuối mỗi mốc dừng để kiểm tra; không tự chuyển mốc. Hiện chỉ lập kế hoạch tại M0. TDD được mở theo dependency; full tập áp dụng là gate M5a, không đòi kiểm UI/governance của phần chưa xây ở W1/M1.

| Đầu việc và giai đoạn | Phạm vi | Điều kiện ra đầu việc / điều chưa được tự bật |
|---|---|---|
| W0 / K0 — duyệt thiết kế | Chốt tài liệu, invariants, lát cắt Phụ lục 03 và kế hoạch nguồn; xuất khẩu là ca tương thích/độ phủ mở rộng, không tự gộp scope expert | Chưa thay MAIN/nguồn/permission/ngân sách; quyết định triển khai rõ sau duyệt |
| W1 / K1 — hợp đồng và kho có phiên bản | API/DTO, immutable lineage, source registry, locator, wiki canonical body/revision/typed links, manifests, role-scope và migration trên clone | TDD service/storage ACL/CAS/replay/upgrade và phần WIKI-01/03/04/05 thuộc M1 đạt; UI/ingestion/governance tích hợp kiểm ở mốc phụ thuộc, toàn tập áp dụng trước M5a; chưa biến nguồn mới thành usable |
| W2 / K1 — cập nhật và chất lượng đọc | Cadence/conditional HTTP/single-flight, PDF/OCR local, diff/impact; explicit ingest manual | Ma trận invalid/scan/SSRF/lease đạt; chưa bật AI nền trả phí hoặc metadata “complete” không căn cứ |
| W3 / K1 — governance end-to-end | Wiki editor/preview/diff và claim/evidence panel, import candidate/export; test rule, typed target review, exacthash publish và outbox/materialization; một bộ căn cứ đủ | Reviewer/publisher đúng scope/kind; READ/revoke/SQL-file crash được kiểm; thiếu nguồn dừng hàng chờ, không dùng fixture thay |
| W4 / K1 — phục vụ hai doanh nghiệp | Chat mobile, nhiều outcome, D07 per outcome, artifacts/history/ACL; chất lượng câu trả lời ở Gateway enterprise hiện hữu | Trà Sen + doanh nghiệp thử B, model quality trong grant đúng scope; AI nền chưa cần bật; 0 leak/paid replay; iHanoi chưa gửi |
| W5 / mỗi K — phát hành có kiểm độc lập | Frozen release, backup/restore, source/runtime manifest, walkthrough và vận hành | Operator plan/rollback không làm yếu gate; vấn đề dữ liệu/chi phí cần chốt đã có quyết định trước bước tương ứng |
| W6 / K2 — AI hỗ trợ đề xuất | Public-domain Gateway scope, AI biên soạn wiki/trích/so sánh/dịch; A/B và tùy chọn Deep Agents/OpenWiki POC theo §10.2–10.3 | Schema/compatibility, mọi model call qua Gateway, adapter qualification, egress/retention/DomainGrant riêng; quỹ tester không thay thế |
| W7 / K3 — mở rộng độ phủ | Chính sách Hà Nội khác và xuất khẩu US/DE/JP qua freshness chung | Danh mục nguồn, bộ căn cứ và phạm vi reviewer/publisher từng domain đủ; không tự mở rộng grants Phụ lục 03 |

W1–W4 là các đầu việc phụ thuộc trong K1; W5 áp dụng cho mỗi bản phát hành. K1 có thể hoàn tất bằng công cụ xác định và chuyên gia nhập đề xuất thủ công trước K2; không lấy việc public Gateway chưa có làm lý do dựng enterprise giả hoặc chặn toàn bộ pipeline. [Profile lấy nguồn ở tài liệu 02](<02_Du_lieu_pipeline_va_truy_xuat.md>) đề xuất discovery 24 giờ, tài liệu chính thức đã biết 24 giờ và cửa tiếp nhận gần hạn 6 giờ, với định nghĩa “gần hạn” do chuyên gia chỉ rõ. Đây là nhịp kiểm kỹ thuật trình duyệt, chưa active và không gia hạn pháp lý/approval.

Các đầu việc là thứ tự phụ thuộc, **không tự gán thời hạn cam kết hoặc xác nhận ngân sách**. Nhóm kỹ thuật tự chọn cách chia code/migration/test trong phạm vi thiết kế được duyệt; không yêu cầu chủ dự án chọn thư viện.

## 12. Điểm phải dừng trao đổi trước hành động tương ứng

Không mở lại D04/D05/D07 hoặc phân công `trung@dtt.vn`. Những điểm dưới không cản hoàn thiện thiết kế và kiểm xác định, nhưng cản hành động vượt phạm vi:

| Điểm dừng | Tài liệu cụ thể phải mang ra duyệt | Trạng thái an toàn khi chưa chốt |
|---|---|---|
| Bật AI nền trích xuất/dịch/OCR | Workload, dữ liệu/egress, provider profile đã kiểm, số lượt và trần phí theo ngày/đợt, service identity | Pipeline dừng ở extraction/review-required; không lấy tiền tester |
| Bật tư vấn thật cho lát cắt chính sách đầu tiên | Danh sách văn bản/phụ lục/sửa đổi đã thu đủ, nhu cầu phục vụ, khoảng trống và scope curator/reviewer/publisher; giữ phân công `trung@dtt.vn` hiện có cho Phụ lục 03 | Có thể thử quy trình trên namespace thử; chưa mở scope nguồn/chương trình khác hoặc phát hành kết luận thật |
| Nội dung thủ công không công khai/quyền dùng chưa rõ | Chủ sở hữu, cơ sở chia sẻ, nhóm người được đọc, retention và xử lý yêu cầu gỡ | Quarantine private, không vào domain dùng chung/LLM |
| Pilot ngoài local, vendor/embedding mới hoặc dữ liệu lưu bên ngoài | Môi trường, dữ liệu, retention, terms, truy cập/hỗ trợ, chi phí và migration | Không kế thừa pool local/egress; giữ binding disabled |
| Gửi iHanoi hoặc thông báo ngoài app | API/môi trường/đích nhận thật, quyền gửi, dữ liệu, consent exact version và receipt | Chỉ nháp/xem trước, không gửi hoặc ghi “đã nộp” |
| Sửa/gộp/xóa dữ liệu legacy thật | Bảng đối soát có exact IDs, lý do, ảnh hưởng, phương án khôi phục | Không sửa ngược snapshot/approval/receipt/facts để migration hoặc test đạt |

Sau khi người dùng duyệt bộ thiết kế, bước tiếp là implementation plan/TDD và bộ nguồn cụ thể. Tài liệu này không tự là lệnh triển khai.

## 13. Truy ngược các lỗi thiết kế đã biết

| Ràng buộc trong tài liệu | DF cần giữ khi triển khai |
|---|---|
| Tách source acceptance, đủ căn cứ, approval, publication và currentness; D07 partial | DF-027, DF-033 |
| Đủ multi-intent và công việc bám câu hỏi; nháp kiến nghị/đăng ký khác loại | DF-024, DF-025, DF-026 |
| One Gateway, service budget riêng, không paid replay; status/receipt READ không mutation | DF-017, DF-019, DF-021, DF-044, DF-046 |
| Private enterprise dữ liệu không thành domain public; revoke vượt cache | DF-028, DF-029, DF-030, DF-032 |
| Exact version/hash, Unit of Work, causal events; không timestamp-order hoặc default mới cho receipt | DF-013, DF-014, DF-034, DF-048 |
| Nháp scoped, mobile/a11y, source/process/evidence đồng nhất | DF-016, DF-036, DF-037, DF-042, DF-043, DF-051 |

Các nguy cơ mới được nêu như **yêu cầu thiết kế/ca âm**, không ghi là RCA sự cố đã chứng minh. Chỉ sau khi có implementation map và bằng chứng trên các đường liên quan mới xem xét trạng thái thiết kế D2; bộ tài liệu được duyệt không tự đóng DF.


## 14. Bổ sung testing review và chuẩn demo — 27/10/2026

Chuẩn demo gồm một trang tổng quan, 5 FAQ và checklist 5–7 việc; từng mục có căn cứ hoặc ghi rõ thiếu nguồn. AI agent khác có thể mô phỏng chuyên gia qua bundle tự đủ thông tin, exact revision/hash, rubric và review-result theo schema. Review/release mô phỏng chỉ trong sandbox, ghi đúng actor/mode, không mượn danh tính chuyên gia, không đáp ứng D07 production hoặc quyền chi tiền. File và MCP cùng dùng application service/receipt/ACL hiện hành. [Thiết kế](<../policy-knowledge-M4-M6-2026-10-27/15_Chot_dau_ra_review_mo_phong_va_nhanh_doc_lap.md>). Không tự mở lại batch từ tài liệu này.

[Bàn giao triển khai C2](<../policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md>) đã qua gate kỹ thuật miễn phí/review độc lập trong phạm vi. Màn thử và MCP mô phỏng chỉ bật khi host được cấu hình testing; MAIN chưa đổi. Giao quyền chi phí trên chat cần chỉ định tài khoản chủ dự án, không suy từ quyền chuyên gia/reviewer. D04/D05/D06/D07 và phê duyệt phát hành thật giữ nguyên.
