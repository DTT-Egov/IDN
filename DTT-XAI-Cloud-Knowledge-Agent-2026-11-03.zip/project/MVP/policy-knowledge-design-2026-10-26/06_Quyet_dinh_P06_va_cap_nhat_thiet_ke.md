# Quyết định P06 — wiki được quản trị và agent harness

**DTT XAI / nMate · 26/10/2026, UTC+7 · Bản thiết kế 1.1 · Chỉ cập nhật tài liệu.**

## 1. Căn cứ và phạm vi phê duyệt

Sau khi nhận [nghiên cứu Markdown/wiki và harness](<05_Nghien_cuu_Markdown_Wiki_va_Agent_Harness.md>), người dùng yêu cầu:

> đồng ý với các đề xuất, cập nhật các tài liệu liêu quan

Ghi nhận **P06 đã được chấp thuận về định hướng thiết kế**, gồm:

1. Wiki Markdown là sản phẩm tri thức được biên soạn và tích lũy, có trang chủ đề, liên kết, mâu thuẫn và khoảng trống; SQL lưu nguyên body từng revision cùng bằng chứng và thẩm quyền. Tệp xuất là projection; file nhập là candidate có CAS.
2. LangGraph tiếp tục runtime chính và một Model Gateway duy nhất. Harness có bounded tools/context/state/validation/human gate; Deep Agents/OpenWiki là ứng viên thử/tái sử dụng có điều kiện, chưa chọn làm dependency production hoặc cài đặt.
3. Markdown chuẩn, khả năng ánh xạ OKF được xem xét với contract/conformance riêng. Metadata định dạng không thay quyền/duyệt/hiệu lực; chưa cam kết importer hoặc API sản phẩm Google/Viettel.
4. Chưa thêm embedding model hoặc graph/vector DB riêng. Quyết định dựa trên corpus expert, phép so sánh A/B và chi phí cả xây/bảo trì/truy vấn.

Yêu cầu hiện tại là **đồng bộ tài liệu**, không giao triển khai app hoặc thử nghiệm trả phí. Không xin lại P06. Phần nguyên tắc SQL/LangGraph/Gateway/public-private trùng baseline được giữ nhất quán; không suy thành đã chốt riêng cadence, nguồn/rights, curator, hạn mức ingestion, hosting/retention hoặc cutover trong P01–P05.

## 2. Các quyết định hiện có tiếp tục áp dụng

- D04: nhân viên theo quyền đề xuất, chủ doanh nghiệp xác nhận SSOT. Wiki không là đường ghi dữ kiện thứ hai.
- D05: không gửi tài chính gốc; chỉ tiêu tối thiểu cần permission/egress riêng. Public wiki không nhận private chat/facts/tệp của doanh nghiệp trong K1.
- D06: một Gateway/ledger, không tự retry/fallback có phí; status/search/cache/recovery/materialize không AI. Quỹ tester local 20 USD không chuyển thành ngân sách AI xây kho.
- D07-A: dừng riêng phần thiếu căn cứ hiện hành, giữ phần hợp lệ và lịch sử có READ; HTTP/TTL hoặc ngày sửa wiki không xác nhận hiệu lực luật.
- `trung@dtt.vn` giữ phạm vi reviewer/publisher Phụ lục 03/N1–N4 đã giao. Không cấp thêm curator/global domain/artifact capability từ tài liệu này; command mới phải có quyền và qualification đúng target kind.
- iHanoi chưa có đặc tả/ủy quyền API: chỉ chuẩn bị nháp, không gửi hoặc báo đã nộp.

## 3. Tài liệu đã được đồng bộ

| Tài liệu | Thay đổi | Trạng thái |
|---|---|---|
| [00 — Tổng quan/quyết định](<00_De_nghi_phe_duyet.md>) | Thêm trạng thái P06, wiki như sản phẩm, tiêu chí và liên kết bản 1.1 | Cập nhật thiết kế |
| [01 — Architecture](<01_Architecture.md>) | Component flow có wiki, canonical body và projection; phân biệt năm bộ nhớ; bounded harness; ADR PK-12–14 | Hướng P06 đã duyệt; chưa code |
| [02 — Dữ liệu/pipeline](<02_Du_lieu_pipeline_va_truy_xuat.md>) | Page/revision/typed links; canonical §7.4, evidence bundle draft/2; UoW/import/export/cache; inventory schema wiki | Contract thiết kế, không DDL đang chạy |
| [03 — Quản trị/API/UX/kiểm thử](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>) | Typed wiki target/release refs, service tools/filesystem ảo, workbench; WIKI-01–10; benchmark và framework qualification | TDD/A-B/qualification chưa chạy |
| [04 — Review lịch sử](<04_Review_doc_lap.md>) | Thêm chú thích phạm vi/hash baseline; giữ nguyên nội dung nhận xét lịch sử | Không phải review mới |
| [05 — Nghiên cứu](<05_Nghien_cuu_Markdown_Wiki_va_Agent_Harness.md>) | Ghi P06 đã duyệt, trỏ contracts/metric mới và trạng thái thực | Cơ sở nghiên cứu, không benchmark implementation |
| [Index kiến trúc](<../architecture/README.md>), [sổ DF](<../architecture/DESIGN_FLAWS.md>) | Trỏ bản hiện hành và ghi các biên thiết kế/điều kiện đóng | Không nâng DF lên D2 |

### Nguồn thẩm quyền trong bộ tài liệu

- **Quyết định người dùng/phạm vi:** tài liệu 06 này; tổng quan 00 là bản đọc nhanh.
- **ADR và sơ đồ:** tài liệu 01 §5/7/18; PK-12–14 tương ứng P06.
- **Identity/body/lineage/tool data:** tài liệu 02 §7.4; evidence bundle draft/2 ở §7.2.
- **Freshness:** duy nhất `policy-freshness-decision/1` ở02 §5.1; không enum riêng cho wiki.
- **Quyền/tool/publication/UX:** tài liệu 03 §4.2/4.5/6, không authority thứ hai trong adapter.
- **Metric:** tài liệu 03 §10.1; A/B corpus/phương pháp ở §10.2, framework/format qualification ở §10.3. Tài liệu05 giải thích cơ sở, không có metric registry riêng.

## 4. Bảo toàn review và lịch sử

Trước khi sửa đã chụp **sáu file 00–05 nguyên byte** cùng SHA-256 tại [baseline-before-P06-approval/manifest.json](<../../../REFERENCE_LINKS.md#ref-0008>). Các file 04 và bảng hash 00–03 trước P06 kiểm theo snapshot, không theo bản 1.1 hiện hành. File manifest lưu đường gốc; relative links bên trong snapshot là tham chiếu của tài liệu ở vị trí gốc, không phải một bản website đã di chuyển.

Review 04 được giữ phần nhận xét lịch sử và thêm ghi chú tác giả ở đầu để tránh hiểu là reviewer đã kiểm thay đổi mới. Không ghi lại hash mới vào kết luận cũ, không tuyên bố có vòng review độc lập mới. Phiên bản 1.1 được kiểm tĩnh đường dẫn, heading/anchor, DF IDs, code fences và JSON minh họa; không thay cho review độc lập hoặc nghiệm thu app.

[Biên bản kiểm tĩnh lúc chốt bản 1.1/P06](<../../../REFERENCE_LINKS.md#ref-0009>) ghi hash các file tại đợt đó, trước khi bổ sung kế hoạch 07. Tài liệu nghiên cứu và các biên bản cũ giữ làm lịch sử của đúng byte/đợt; không coi là current manifest sau khi thêm kế hoạch. [Kế hoạch 07](<07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>) trỏ baseline và biên bản kiểm tài liệu mới tương ứng.

## 5. Việc còn mở trước triển khai/thử nghiệm

| Bước | Điều kiện còn cần | Chưa tự thực hiện |
|---|---|---|
| Triển khai K1 | Giao triển khai, TDD contract/schema, nguồn/rights và scope thật, clone migration/backup/operator plan | Sửa app, tạo bảng hoặc đổi dữ liệu/permissions |
| Phát hành tri thức thật | Đủ bộ văn bản/ngoại lệ/phụ lục/đợt, review và publication exact version/hash | Dùng wiki nháp để khẳng định quyền hưởng |
| AI biên soạn/POC | Public-domain Gateway subject/scope, mọi hidden model call/egress/trace/retry được qualification; workload và hạn mức riêng | Mượn tài khoản/grant tester hoặc gọi thêm Claude |
| Tái sử dụng framework/OKF | Pin version/commit/license, adapter/capability và conformance tests | Cài framework hoặc nhận tương thích chỉ vì đọc được Markdown |
| Mở rộng/pilot ngoài local | Corpus/coverage, quyền và hosting/retention/chi phí cụ thể | Mang quỹ local, dữ liệu riêng hoặc kết luận A sang doanh nghiệp B |

Các ca WIKI, A/B và review độc lập được đưa vào kế hoạch triển khai; chưa có bằng chứng đã đạt. Việc cập nhật tài liệu không nâng tình trạng thiết kế DF lên “đã kiểm chứng”, không cấp tiền/quyền hoặc thay SSOT.

## 6. Yêu cầu tiếp theo — dừng theo milestone

Người dùng yêu cầu lập kế hoạch và dừng ở các milestone để kiểm tra. [Kế hoạch 07](<07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>) là quy trình thực hiện đề xuất: M0 chờ kiểm tra kế hoạch, M1–M5 triển khai K1 khi được cho tiếp tục, M6/K2 có cửa dữ liệu/quyền/phí riêng. Không tự hiểu yêu cầu lập kế hoạch thành đã thực hiện triển khai; cuối mỗi mốc chờ chỉ dẫn tiếp theo của người dùng.
