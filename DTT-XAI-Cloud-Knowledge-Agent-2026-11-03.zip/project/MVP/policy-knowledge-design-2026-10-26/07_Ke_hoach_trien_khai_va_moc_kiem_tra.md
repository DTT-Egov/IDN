# Kế hoạch triển khai và các mốc dừng kiểm tra

**DTT XAI / nMate · Kế hoạch thực hiện 1.0 · 26/10/2026, UTC+7.**

Theo yêu cầu: “lên kế hoạch thực hiện việc này và dừng lại tại các milestone để kiểm tra”. Kế hoạch dùng [thiết kế 1.1/P06 đã duyệt](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>), [architecture](<01_Architecture.md>), [data contracts](<02_Du_lieu_pipeline_va_truy_xuat.md>) và [quản trị/kiểm thử](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>).

**Cập nhật 27/10:** M1 và M2 đã scoped-pass; [bàn giao và giới hạn](<../policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md>). Người dùng sau đó cho M3 và dùng AI xây kho, duyệt riêng tối đa6lượt/2USD. [Phạm vi M3](<../policy-knowledge-M3-2026-10-27/00_Pham_vi_M3_va_AI_xay_kho.md>) đưa lát cắt AI tạo đề xuất có giới hạn lên M3; chưa cho M4/M5/deploy hoặc lịch AI nền. Trạng thái/chi phí thực theo gói bàn giao M3, không suy từ phê duyệt này.

## 1. Phạm vi và kết quả đầu tiên

**Ủy quyền tiếp theo 27/10:** người dùng yêu cầu sau M3 review độc lập đến đạt rồi thực hiện M4–M6, mỗi mốc review và sửa đến đạt trước khi chuyển. Quy tắc xin tiếp tục thủ công giữa các mốc dưới đây là lịch sử của kế hoạch ban đầu; gate hiện tại theo [phạm vi M4–M6](<../policy-knowledge-M4-M6-2026-10-27/00_Pham_vi_va_gate.md>). D04/D05/D06/D07 và quyền chuyên gia giữ nguyên; không tự mở grant M3 đang pause hoặc chuyển quỹ tester sang ingestion. M3 đã tái gate scoped-pass; phần nội dung thật chưa được duyệt không trở thành đủ nguồn từ chỉ dẫn triển khai.

Ưu tiên hoàn thành **K1: một bộ chính sách Hà Nội đi hết chuỗi nguồn → wiki/claim → chuyên gia duyệt → phát hành → tư vấn theo SSOT → thay đổi nguồn**. Giữ chat tiếng Việt, lấy trợ lý làm trung tâm và mobile first. Không yêu cầu chủ cơ sở học wiki hoặc quản lý graph.

Lát cắt ưu tiên vẫn là Phụ lục 03 trong phạm vi chuyên gia đã giao. Trước đưa nguồn thật vào hệ thống, phải có danh mục URL/tài liệu/phụ lục/sửa đổi, quyền sử dụng, người vận hành nguồn và bảng khoảng trống được kiểm. Chưa đủ căn cứ thì dừng đúng phần, không đổi fixture thành chính sách thật để đủ demo.

K2 đầy đủ, benchmark A/B và framework qualification vẫn có cổng riêng; chỉ batch AI đề xuất đã được giao chuyển lên M3. Chưa thêm graph/vector DB hoặc embedding, chưa thay LangGraph. Deep Agents/OpenWiki/OKF là ứng viên qualification, không là điều kiện để xong K1. iHanoi dừng ở nháp nếu chưa có API/ủy quyền.

## 2. Quy tắc dừng bắt buộc

1. Thực hiện trong **một mốc đã được cho tiếp tục**; làm đủ code, test, tài liệu và bằng chứng của mốc đó trước khi trình kiểm tra. Không hỏi lại các lựa chọn đã duyệt trong mốc.
2. Cuối mỗi mốc, gửi một gói bàn giao cụ thể và **dừng**. Không tự chạy tác vụ thuộc mốc sau, kể cả tác vụ trả phí hoặc kích hoạt lịch nền. Chờ người dùng kiểm tra và cho tiếp tục; hết thời gian chờ không là đồng ý.
3. Kiểm kỹ thuật đạt chưa đồng nghĩa người dùng đã cho qua mốc. Người dùng cho tiếp tục cũng không thay quyền chuyên gia, D06 hoặc cổng dữ liệu còn thiếu.
4. Nếu phát hiện lỗi chặn, sửa và kiểm lại trong cùng mốc; nêu rõ bằng chứng lỗi/sửa. Không vượt mốc để né lỗi hoặc tự giảm tiêu chí nghiệm thu.
5. Quyền, nguồn, chi phí hoặc dữ liệu vượt phạm vi đã chốt thì dừng ngay tại hành động phụ thuộc, không đợi hết mốc. Chuẩn bị phương án/bằng chứng đủ cụ thể trước khi trao đổi.

Mỗi mốc có trạng thái tách biệt: **chưa bắt đầu → đang làm → chờ kiểm tra → được tiếp tục**, hoặc **còn vấn đề phải sửa**. Sổ trạng thái ở §10 là bản theo dõi hiện tại; không dùng trạng thái kiểm thử thay trạng thái chấp thuận.

## 3. Bản đồ các mốc

| Mốc | Kết quả xem được | Điểm dừng để kiểm tra |
|---|---|---|
| **M0 — kế hoạch** | Phạm vi, thứ tự phụ thuộc, tiêu chí và cách bàn giao | Xem kế hoạch này; chưa bắt đầu code |
| **M1 — nền dữ liệu và hợp đồng** | Wiki revisions trên SQL, service quyền/receipt, migration trên bản sao | Kiểm nguyên vẹn dữ liệu, ACL, CAS, replay và phục hồi cơ bản |
| **M2 — nhập nguồn và tra cứu** | Nguồn/version/extraction, wiki candidate, FTS/links, xuất Markdown và invalidation | Kiểm căn cứ/coverage, nguồn thay đổi, projection và cache không AI |
| **M3 — chuyên gia biên soạn và phát hành** | Workbench wiki/diff/evidence, hai bước duyệt–phát hành đúng scope | Thử sửa sau duyệt, conflict, rút nguồn và xem ảnh hưởng |
| **M4 — flow Trà Sen trên mobile** | Chat nhiều intent, dùng wiki và SSOT; hai doanh nghiệp; nguồn Việt/bản gốc | Chủ cơ sở thao tác được; kiểm chất lượng Claude trong hạn mức hợp lệ |
| **M5 — nghiệm thu và phát hành local** | Review độc lập, đóng gói, rehearsal/backup và bản local mới | Kiểm release candidate trước thay 8025; sau triển khai kiểm lại rồi dừng |
| **M6 — K2, AI biên soạn có kiểm soát** | Model Gateway public-domain, worker tạo nháp, đánh giá A/B | Duyệt workload/phí trước gọi; nghiệm thu riêng trước tự động hóa |
| **M7 — mở rộng, chưa thuộc đợt K1** | Nhiều chính sách/thị trường hoặc connector mới | Kế hoạch riêng dựa trên kết quả M5/M6 và nguồn/quyền thật |

Đường phụ thuộc chính: **M0 → M1 → M2 → M3 → M4 → M5**. M6 chỉ bắt đầu khi được giao riêng sau M5 và đủ cổng. M7 chưa triển khai trong kế hoạch K1. Mỗi dấu chuyển là một điểm dừng thực, không chỉ thông báo tiến độ.

## 4. M1 — nền dữ liệu và hợp đồng

**Việc làm**

- Đối chiếu build/source/runtime và schema đang chạy với thiết kế trước khi chọn migration; không dùng số liệu V17 cũ như kiểm chứng hiện tại.
- Lập implementation map: mỗi contract/DF → service/DTO/storage/permission → test → bằng chứng. Ghi rõ adapter legacy và hợp đồng mới.
- TDD cho canonical page/revision/body/hash/parent/base, evidence dependencies, exact-field READ, scope, operation identity và receipt. SQL là authority duy nhất; chưa có file watcher ghi live.
- Bổ sung lớp lưu/service trên bản sao và migration/operator plan có preflight. Không DDL hoặc backfill business facts ở máy chính.
- Kiểm crash tại commit/receipt boundary, concurrent edit, replay sau mất WRITE nhưng còn READ, revoke READ và restart không tự ghi nghiệp vụ.

**Bàn giao:** schema/contract diff, RED→GREEN cho phần M1, đối soát bản sao trước/sau, ca âm ACL/CAS/replay, operator rehearsal ban đầu và backlog còn mở.

**Điều kiện qua mốc:** không đổi raw assertions/decisions/receipts cũ; không tạo nguồn hoặc approval giả; không leak/sai identity; không model/network dispatch từ các đường đọc. Chưa cần toàn bộ UI/ingestion tests của các mốc sau xanh ở M1. Các ca chưa áp dụng phải ghi `not_run`, không xóa khỏi kế hoạch.

**Kiểm trực tiếp:** tạo một trang thử, sửa thành revision mới; mở revision cũ; thử hai người sửa cùng base; kiểm bản sửa bị từ chối không ghi đè hoặc báo thành công giả.

## 5. M2 — nhập nguồn, wiki candidate và truy xuất

**Việc làm**

- Trình source manifest pilot: identity/URL, rights, loại tệp, vai trò trong bộ căn cứ, người vận hành và khoảng trống. Khi scope chưa rõ, chỉ kiểm trên fixture công khai được phép; chưa kích hoạt fetch/lịch nguồn thật.
- Implement registry/acquisition/local extraction/version/diff theo hai UoW; giới hạn tài nguyên, nhận diện PDF giả/scan thiếu và báo tên tệp/trạng thái đúng.
- Làm typed evidence/claim-to-source binding và trang wiki candidate. Nội dung chưa được duyệt không phục vụ assessment thật.
- Implement FTS/alias/typed links, lookup/read, xuất Markdown theo manifest và materializer qua outbox. Chưa bật mapping OKF hay framework nếu không cần K1.
- Source change/revoke chặn đúng dependency ngay, không chờ index/Markdown dựng lại; cache/index/rebuild/status không AI.

**Bàn giao:** source/coverage manifest và các phần chưa đủ; demo nhập→revision→search→mở nguyên bản; bằng chứng PDF lỗi, crash materialization, file sửa tay và source revoke.

**Điều kiện qua mốc:** WIKI-02/04/05/06/07 theo phạm vi service và SRC/RET/EVT tương ứng có ca kiểm; source đúng bytes/locator; không wiki tự làm bằng chứng pháp lý; SQL/file không thành hai bản chuẩn. Không nhận đủ bộ căn cứ chỉ từ số tệp hoặc quote-match.

**Kiểm trực tiếp:** thay một đoạn nguồn trên namespace thử; trang phụ thuộc hiện cần rà, bản lịch sử giữ nguyên; xóa projection rồi dựng lại mà không gọi model; tìm kiếm không lộ title/snippet của nguồn bị revoke.

## 6. M3 — workbench, duyệt và phát hành

**Việc làm**

- Editor/xem trước Markdown tiếng Việt, diff bản cũ–mới, side panel claim/evidence/bản dịch, backlink/ảnh hưởng và conflict giữ nháp.
- Mở rộng cùng governance service bằng wiki target kind và capability explicit; không tạo reviewer/global grant mới hoặc authority song song.
- Hai quyết định độc lập về logic: rà exact revision/hash và phát hành exact manifest. Cùng chuyên gia chỉ thực hiện trong scope thật được giao; không coi approval rule là approval wiki.
- Thực hiện source completeness và ca chuyên môn với chuyên gia cho bộ pilot; nếu chưa được duyệt, chỉ demo workflow trên namespace kiểm thử.
- Kiểm sửa sau duyệt, manifest đổi, mất quyền trước commit, withdraw và outbox còn trễ.

**Bàn giao:** walkthrough chuyên gia, review/publication receipts đã làm sạch nếu thực sự có, test GOV và WIKI tương ứng, ma trận scope/artifact kind và bảng gap.

**Điều kiện qua mốc:** trang và rule được dùng có quyết định đúng phiên bản/scope; UI không ghi trạng thái cũ cho body mới. Chưa đủ căn cứ hoặc chưa có quyết định thật thì chưa mở tư vấn điều kiện hưởng. Người dùng duyệt UX không thay quyết định chuyên gia.

**Kiểm trực tiếp:** chuyên gia từ chối một nhận định thiếu nguồn, sửa body và duyệt lại; thử phát hành hash cũ phải bị chặn; trang mới chỉ xuất hiện cho phục vụ sau release hợp lệ.

## 7. M4 — Trà Sen, SSOT và chất lượng câu trả lời

**Việc làm**

- Chat theo từng outcome: xuất khẩu + đào tạo sổ sách; ngoài phạm vi; câu thiếu dữ kiện. Không trả cùng một gói bất kể intent.
- Bind exact doanh nghiệp/sản phẩm/thị trường và READ SSOT; dữ kiện mới thành nháp để chủ xác nhận, không tự học vào SSOT hoặc public wiki.
- Chat gọn trên 320/390 px: kết luận trước, việc cụ thể, nguồn tiếng Việt và xem nguyên bản; không bắt thao tác folder/graph. Giữ mạch sau reload, lịch sử, pending/error và phí đúng thực trạng.
- Chạy doanh nghiệp A/B trên cùng public release: dùng lại tri thức nhưng dữ kiện và kết luận riêng. Thay nguồn/revoke cho đúng outcome theo D07-A.
- Kiểm Claude thật **chỉ ở phần đánh giá trả lời doanh nghiệp có grant hợp lệ**, tách khỏi AI xây kho. Đầu mốc đọc trạng thái grant/thời hạn/số dư hiện tại và chuẩn bị batch manifest: câu hỏi, intent, model/role/purpose, số dispatch tối đa, token/trần tiền và egress. Không mặc định quỹ cũ còn đủ; số USD 20 trước đây không là số dư đã kiểm hôm nay. Nếu grant thiếu/sai scope/hết hạn thì dừng phần live, trình nhu cầu cụ thể; không tự cấp hoặc retry.

**Bàn giao:** walkthrough chủ cơ sở có ảnh 320/390 và câu hỏi/coverage matrix; manifest và receipts/usage cho những lượt thật đã gọi; phân biệt replay/model-free/live; báo các phần chưa đủ nguồn.

**Điều kiện qua mốc:** không bỏ nhu cầu; thông tin thiếu được nói rõ; không mượn hồ sơ khác; 0 leak/unauthorized dispatch/paid replay. QA Claude không được tính là kiểm xong corpus 30 A/B hoặc pháp lý mọi domain. Khi câu có hai nhu cầu mà kho chỉ đủ một, nghiệm thu sự trung thực và D07, không chấm là trả lời đầy đủ cả hai.

**Kiểm trực tiếp:** chủ Trà Sen hỏi hai nhu cầu; mở nguồn, xác nhận riêng dữ kiện và tải lại; chủ doanh nghiệp B hỏi tương tự; xem kết quả khác theo SSOT nhưng nguồn public được dùng chung.

## 8. M5 — kiểm độc lập và phát hành local

M5 có **hai điểm dừng** để không gộp duyệt release candidate với việc đã deploy:

**M5a — trước cutover 8025**

- Đóng băng source/build/schema/contract/model configuration. Chạy đủ bộ kiểm có liên quan, toàn WIKI-01–10 trong capability thực được triển khai, regression nghiệp vụ và migration/restore trên bản sao. Phần framework chưa có ghi `not_applicable` kèm lý do, không giả đã qualification.
- Review độc lập kiến trúc và chủ doanh nghiệp mobile: người kiểm tự chạy các ca từ build đã đóng gói, không chỉ đọc walkthrough. Nếu dùng agent độc lập thì thực hiện trong phạm vi được giao và không tự sinh paid calls.
- Tập trung chuỗi lỗi cũ: nháp xác nhận từng phần/reload, thông báo lưu và version, sản phẩm cất/đổi chọn, dữ liệu sai, multi-intent, source/citation, title/metadata ACL và model consent/budget/recovery.
- Đưa operator plan, backup/restore proof, rehearsal, danh sách lỗi/phạm vi chưa kiểm và release candidate để người dùng kiểm trước khi thay bản đang chạy.

**M5b — sau khi được cho deploy**

- Backup mới và preflight đúng target runtime; migration có giới hạn, không backfill/sửa SSOT hoặc cấp grant ngầm. Rollback code không được hồi sinh nguồn bị rút hoặc làm yếu quyền.
- Deploy local 8025; kiểm HTTP/assets/build identity, startup không ghi nghiệp vụ, đối soát dữ liệu và ngân sách trước/sau; smoke test mobile không tạo paid call ngoài batch đã duyệt.
- Cập nhật walkthrough, kịch bản tester, các ID DF và manifest phát hành. Báo URL/build, kết quả và điều còn mở; **dừng để người dùng test**.

**Điều kiện hoàn tất K1:** một bộ thật đủ căn cứ và có quyết định thật, hai doanh nghiệp cách ly, source-change/revoke/replay đúng, các lỗi chặn trong phạm vi được xử lý; không “đạt” từ fixture hoặc review tài liệu. Nếu nguồn chưa đủ thì có thể nghiệm thu phần kỹ thuật trong phạm vi ghi rõ, không tuyên bố tư vấn hiện hành đã hoàn tất.

## 9. M6/K2 và M7 — đợt riêng sau K1

### M6a — dừng trước AI xây kho

Trình workload và phạm vi nguồn; typed service subject/public-domain scope trong cùng Gateway; quyền egress; model/profile, lượt/trần phí, retention/trace và phương án dừng. Quỹ tester enterprise không dùng cho ingestion. Qualification planner/compaction/consolidation/worker phụ/retry qua cùng Gateway trước paid dispatch. Không tạo doanh nghiệp giả hoặc transport thứ hai. Cần quyết định ngân sách/scope trước khi gọi.

### M6b — thử nghiệm có giới hạn và dừng đánh giá

Worker tạo nháp có evidence để chuyên gia rà; không tự publish. So A (SQL/FTS/raw) với B (thêm wiki) theo metric/corpus canonical ở tài liệu 03 §10.1–10.2. C (Deep Agents adapter) chỉ khi có lý do và được giao riêng. Không thay đồng thời model/corpus/harness để nhận hiệu quả giả; tính build/maintenance/query và công reviewer. Không gọi thử lại trả phí tự động nếu ca kém.

Kết thúc trình chi phí, chất lượng, coverage, lỗi và đề nghị giữ/bỏ từng adapter. Không bật lịch AI tự động chỉ vì một lượt chạy thành công. Corpus chưa đủ hoặc grant không đủ thì ghi `not_evaluable`/`not_run`, không báo điểm giả.

### M7 — chưa triển khai trong đợt này

Mở policy Hà Nội khác, xuất khẩu US/DE/JP, embedding, OKF partner connector hoặc iHanoi đều cần kế hoạch/scope/nguồn/quyền tương ứng. Quyết định dựa trên kết quả M5/M6; không mở rộng quyền `trung@dtt.vn` hoặc quỹ local ngầm.

## 10. Trạng thái và gói bàn giao mỗi mốc

| Mốc | Trạng thái hiện tại | Bằng chứng đã có |
|---|---|---|
| M0 | Người dùng đã cho triển khai M1–M2 | Chỉ dẫn mới ở đầu tài liệu |
| M1 | Review độc lập đạt có giới hạn; được chuyển M2 | Bàn giao M1, candidate3; không MAIN/paid |
| M2 | Review độc lập đạt có giới hạn; người dùng đã cho M3 | Frozen2:211author;39độc lập+4ca riêng; không MAIN/paid/realpolicy |
| M3 | Bàn giao tại mốc; nháp nội dung thật chờ chuyên gia | Frozen5:259ca hồi quy author,41ca M3 chạy lại,52ca độc lập; mobile và bounded S1 thật.1Sonnetước tính0,029836USD, dừng và free-recover nháp, không tự dùng5slot còn lại. [Gói M3](<../policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md>) |
| M4 | Scoped technical pass candidate4 sau3vòng sửa | [Bàn giao M4](<../policy-knowledge-M4-M6-2026-10-27/03_Ban_giao_M4.md>); MAIN8025 chưa đổi, không AI trả phí; legalgold còn thiếu |
| M5 | Scoped technical pass M5a/M5b; đã triển khai8025 | [Bàn giao M5](<../policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md>);100bảng cũ nguyên,4receipt,0lượt mới; không backfill/grant; nội dung thật chưa có release |
| M6 | C4/C6 qua gate kỹ thuật scoped; M6b thật chưa đạt end-to-end, dừng ở O1 trước O2 | [Bàn giao](<../policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md>) và [đợt bốn slot](<../policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md>):5lượt/4proposal/ước0,217632USD; O1JSONthiếu/O2chưagọi. DF-060/053 đóng bản vá lexical/read scoped; DF-061/062 mới và DF-025/026 coverage còn mở. Chưa legalgold/phát hành; không dùng94ca/30ca lexical để nhận Opus đãqualified |
| M7 | Chưa được giao | Không thêm domain/framework/embedding/iHanoi thật từ hạn mức batch |

Mỗi gói bàn giao gồm:

1. Kết quả xem/thử được và thay đổi so với mốc trước.
2. Build/contract/schema/source manifest, thời điểm và môi trường; RED→GREEN và kết quả `pass/fail/not_run/not_evaluable`, không cộng các lượt test thành full run giả.
3. Walkthrough/ảnh/receipt/log đã làm sạch theo loại công việc; ca người kiểm độc lập thực sự tự chạy và giới hạn quan sát.
4. Chi phí/dispatch/usage thực hoặc “chưa đối soát”; nguồn được phép và quyền đã kiểm. Không đưa mật khẩu, token, tài liệu riêng vào báo cáo.
5. DF IDs, nguyên nhân đã chứng minh, biện pháp hiện tại và lớp thiết kế còn mở; không nhận D2 chỉ vì ca cũ xanh.
6. Vấn đề chặn, điều cần người dùng/chuyên gia quyết định và phạm vi mốc tiếp theo. Kết thúc ở trạng thái chờ kiểm tra, không tự chuyển.

Không gán ngày hoàn tất khi chưa rà implementation thực ở M1 và chưa biết thời gian chờ nguồn/chuyên gia. Sau M1 có thể đề xuất ước lượng còn lại dựa trên dữ liệu, tách thời gian kỹ thuật với chờ duyệt; không tự cam kết SLA hoặc lịch AI nền.

## 11. Truy vết và kiểm tài liệu

M1–M5 cụ thể hóa W1–W5/K1 ở tài liệu03. WIKI tests được mở theo dependency từng mốc; **toàn bộ tập áp dụng là gate M5a**, không đòi UI/governance chưa xây phải xanh ở M1. M6 tương ứng W6/K2, M7 tương ứng W7/K3. Không tạo roadmap/domain authority thứ hai.

Các DF chính: DF-013/014/027/028/029/030/032/033/034/043/044/046 cùng biên qualifier registry/causal decisions/revoke trong AGENTS. [Sổ DF](<../architecture/DESIGN_FLAWS.md>) giữ nguyên trạng thái D1 cho thiết kế chưa được kiểm chứng; kế hoạch không tự sửa dữ liệu hoặc nhận đã đóng lỗi.

[Baseline trước kế hoạch](<../../../REFERENCE_LINKS.md#ref-0010>) giữ hash tài liệu; [kiểm tĩnh kế hoạch](<../../../REFERENCE_LINKS.md#ref-0011>) chỉ kiểm file/links/ID/fences. Biên bản P06 trước đó là lịch sử của đúng byte phiên bản ấy, không coi như kiểm mới cho tài liệu đã bổ sung kế hoạch. Chưa có test app/model hoặc review độc lập mới trong lượt lập kế hoạch.


## 12. Điều chỉnh thiết kế sau M6b — 27/10/2026

[Quyết định đầu ra, simulated review và nhánh độc lập](<../policy-knowledge-M4-M6-2026-10-27/15_Chot_dau_ra_review_mo_phong_va_nhanh_doc_lap.md>): giữ chuẩn demo và trần mỗi model; triển khai profile/artifact/completion receipt, gói bàn giao reviewer và continuation permit qua TDD miễn phí/review độc lập. Pilot ba mức vẫn cần D06 riêng sau kiểm thử; M6b thật chưa đạt, O1 giữ lỗi và O2 chưa gọi. Không tự mở M7 hoặc chuyển simulated release thành release thật.

**Gate miễn phí tiếp M6 đã đạt scoped trên C2:** [bàn giao và kết quả kiểm](<../policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md>). Tách rõ bản code đã kiểm với nghiệm thu nội dung thật/M6b chưa đạt. Điểm dừng còn lại: chỉ định đúng tài khoản nếu đưa quyền tiếp tục có phí vào chat MAIN; hoàn thiện và trình manifest/D06 riêng trước live qualification. Không tự dispatch O2 hoặc phát hành chính sách thật từ signoff kỹ thuật.
