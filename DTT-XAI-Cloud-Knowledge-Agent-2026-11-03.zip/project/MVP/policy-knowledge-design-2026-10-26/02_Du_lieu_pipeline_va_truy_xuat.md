# 02 — Dữ liệu, pipeline tích lũy và truy xuất tri thức chính sách

Ngày thiết kế: **26/10/2026, UTC+7**. Trạng thái: **đề xuất để duyệt; chưa triển khai**. Tên bảng `kp_*` và hợp đồng `/1` dưới đây là tên đề xuất, không mô tả schema đang chạy. Tài liệu này không cấp quyền lấy nguồn, gọi mô hình, phát hành tri thức, sửa dữ liệu cũ hoặc dùng ngân sách tester cho công việc nền.

**Bản 1.1 — tích hợp P06 đã duyệt:** SQL canonical Markdown revisions, wiki evidence/typed links, import/export và storage boundary được cụ thể hóa dưới đây. Các schema/tool vẫn là hợp đồng thiết kế, chưa tạo bảng hoặc thay receipt/app. [Quyết định P06](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) ghi rõ phần đã chốt và các cửa còn mở.

Đi cùng [kiến trúc tổng thể](<01_Architecture.md>) và [quản trị, vận hành, trải nghiệm](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>). Căn cứ hiện trạng là [audit nguồn ngày 26/10](<../source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md>), mã đóng gói V17 `release-final-v2` và contract `nmate-main-20261026-v17`. Các chi tiết pháp luật trong ví dụ chỉ là tên nhóm vấn đề, **không phải kết luận pháp lý hiện hành**.

## 1. Mục đích và giới hạn

Mục tiêu là chuyển từ kho tài liệu tham chiếu hữu hạn thành một chuỗi có kiểm soát: **phát hiện → lưu bằng chứng → đọc được → đề xuất tri thức → chuyên gia duyệt → phát hành → dùng lại theo đúng câu hỏi**. Tiền mô hình mua được một bước phân tích; không thay thế nguồn đủ, thẩm quyền duyệt hoặc quyền đọc.

| Đang có ở V17 | Đề xuất bổ sung | Không được tuyên bố trước khi nghiệm thu |
|---|---|---|
| Hà Nội có `pol_sources`, snapshot/chunk/hash, FTS5, member/review/publication/pack, graph SQL và job kiểm nguồn bền vững | Registry có phiên bản; discovery hữu hạn; đọc HTML/PDF đầy đủ hơn; phân loại khác biệt; danh tính văn bản; freshness dùng chung | Đã bao phủ mọi chính sách Hà Nội; HTTP 200 là đã kiểm hiệu lực |
| Chỉ một nguồn Hà Nội có lịch hằng ngày theo audit | Lịch theo loại nguồn, mức rủi ro và hạn kiểm đã duyệt; bảng điều khiển khoảng trống và công việc chờ | Cứ mỗi ngày là mọi chính sách đều được cập nhật và duyệt |
| Xuất khẩu dùng `v03_domain_sources/references` và kiểm các URL đã biết ở một số entry point | Cùng hợp đồng nguồn, lịch kiểm, version và gate với Hà Nội; giữ adapter tương thích kho cũ | Một gói FDA, một nước EU hoặc một chủ đề là đủ mọi nghĩa vụ |
| Kho công khai tách hồ sơ doanh nghiệp; một số quyền, receipt và lineage đã kiểm | Phủ cùng cơ chế ở ingest, extraction, cache, retrieval, download và phát hành mới | Nội dung ở Internet mặc nhiên có quyền sao chép/phát hành; chủ tài khoản vượt quyền nguồn |
| SQL/FTS5 và graph SQL; chưa bật embedding | Nâng chất lượng dữ liệu, alias, phiên bản chỉ mục và benchmark trước | Đã cần vector DB/graph DB hoặc embedding để hoàn thành pipeline |

Thiết kế giữ D04, D05, D06 và D07-A. Đặc biệt, phần thiếu căn cứ được dừng riêng; vẫn trả phần độc lập hợp lệ và lịch sử có nhãn. Nguồn mới không tự thành quy tắc tư vấn. Không mở rộng chính sách tài chính hoặc tự tạo lượt AI khi đọc status, mở cache hay khôi phục.

## 2. Danh tính dữ liệu phải tách rõ

```mermaid
flowchart LR
  R[Registry và endpoint có phiên bản] --> O[Quan sát HTTP hoặc tiếp nhận thủ công]
  O --> B[Bytes bất biến: rendition]
  B --> X[Extraction có phiên bản và chất lượng]
  X --> C[Chunk và locator nguyên bản]
  C --> E[Binding chứng minh từng mệnh đề]
  I[Văn bản và phiên bản pháp lý] --> E
  P[Chương trình và đợt nhận hồ sơ] --> E
  E --> K[Rule hoặc claim đề xuất]
  K --> V[Duyệt đúng hash và phát hành]
  V --> M[Manifest bộ tri thức]
  M --> T[FTS và graph SQL dẫn xuất]
  T --> Q[Gói căn cứ theo outcome và SSOT được phép]
```

| Đối tượng | Danh tính và vai trò | Bất biến quan trọng |
|---|---|---|
| Nguồn/endpoint | `source_id` legacy giữ nguyên; cấu hình mới có `source_config_revision_id`; URL, cơ quan, loại kênh và quyền sử dụng | URL là nơi lấy dữ liệu, không phải ID văn bản pháp lý. Không bỏ tham số URL chứa mã bài/văn bản để gộp nhầm |
| Lần quan sát | `observation_id`, endpoint revision, request representation, trạng thái, response metadata, thời điểm | Một lần kiểm 304, 403 hoặc nội dung không đổi vẫn có sự kiện riêng; không sửa ngày công bố |
| Văn bản logic | `instrument_id`, loại văn bản, cơ quan ban hành, số/ký hiệu/ngày nếu xác minh được | Hai văn bản trùng tiêu đề không tự gộp. Một văn bản có nhiều nơi đăng; identity chưa chắc thì để ứng viên chờ xác minh |
| Phiên bản văn bản | `instrument_edition_id`, instrument, rendition/extraction được chọn, khoảng hiệu lực và quan hệ sửa đổi có căn cứ | Không đồng nhất lần tải mới với phiên bản pháp lý mới. Một bản hợp nhất không mặc nhiên thay văn bản gốc |
| Chương trình | `program_id`, cơ quan vận hành, nhóm hỗ trợ và các văn bản làm căn cứ | Chương trình khác văn bản ban hành. Tin giới thiệu chưa chứng minh đủ điều kiện hưởng |
| Đợt/cửa tiếp nhận | `call_id`, program, thời gian nhận, kênh, tình trạng/chỉ tiêu, nguồn trạng thái | Đợt 2026 và đợt 2027 là hai đợt; văn bản còn hiệu lực không đồng nghĩa cửa đang mở |
| Bản thể hiện bytes | `rendition_id`, `raw_sha256`, MIME, kích thước, nguồn gốc, nơi lưu bytes | Bytes bất biến; PDF, HTML và phụ lục là bản thể hiện cụ thể, không phải bản dịch thay nguyên văn |
| Lần trích xuất | `extraction_id`, rendition, processor/version/config, text hash, trang/cấu trúc, chất lượng | Sửa parser tạo extraction mới. Không ghi đè text/offset/hash của bản đã dùng làm căn cứ |
| Chunk | ID gắn extraction, section/page/span/table-cell, text hash, language | Không trộn hai extraction trong một chunk. Không cắt mất ngoại lệ/tiêu đề bảng rồi coi câu còn lại là toàn điều kiện |
| Bản dịch | `translation_id`, chunk/quote/hash nguyên bản, ngôn ngữ đích, method/profile, review event | Bản tiếng Việt dẫn xuất, có đường xem nguyên bản. Bản dịch không tự có thẩm quyền cao hơn nguồn |
| Rule/claim version | ID phiên bản bất biến, kind/schema, phạm vi, điều kiện, ngoại lệ, evidence bindings và hash | Rule xét điều kiện; claim có kiểu như thủ tục/hồ sơ/mức hỗ trợ/đầu mối. Không đưa thủ tục thành fact doanh nghiệp để lách evaluator |
| Trang wiki | `page_id` ổn định; kind, domain/scope, title/alias; không lấy slug/tên làm identity | Điều hướng và biên soạn, không là entity SSOT hoặc văn bản pháp lý; đổi title không đổi ID |
| Revision wiki | `page_revision_id`, parent/base revision, body Markdown nguyên bản/hash, schema/recipe, claim/evidence dependencies | Giữ bản nháp và bản phát hành bất biến; không coi file `stable` hoặc timestamp mới là đã duyệt/còn hiệu lực |
| Bộ phát hành | Pack manifest/version, chính xác member/hash/review/publication events | Pack không thay danh tính văn bản hoặc chương trình. Một member bị chặn thì pack không làm member đó dùng được |
| Gói truy xuất | `retrieval_run_id`, outcome, scope/ngày, context manifest, evidence/dependency versions | Không phải SSOT thứ hai. Câu trả lời cho doanh nghiệp A không là tri thức công khai cho B |

`source_id`, `instrument_id`, `instrument_edition_id`, `program_id`, `call_id`, `member_version_id` và `pack_release_id` không dùng thay nhau. Bộ thu thập không được suy loại chỉ từ tiền tố ID.

### 2.1. Trùng lặp, liên kết và xung đột

- Cùng bytes tại hai URL: có thể dùng chung lưu trữ vật lý theo hash, nhưng giữ hai provenance/endpoint và quyền. Hash bằng nhau không cho phép gộp ACL, nguồn có thẩm quyền hoặc identity văn bản.
- Cùng số/ký hiệu nhưng khác cơ quan/năm/ngày: đưa vào `identity_conflict`, không tự gộp. Thiếu số/ký hiệu: dùng ID nội bộ, giữ identity là `unresolved` thay vì suy từ tiêu đề.
- HTML giới thiệu, PDF ký và phụ lục: liên kết `introduces`, `official_rendition_of`, `has_annex` với căn cứ; không coi mọi link trên bài là phụ lục bắt buộc hoặc nguồn đáng tin.
- Hai worker lấy cùng endpoint cùng lúc: một observation có thể được ghi cho mỗi lần thực sự gửi, nhưng chỉ một rendition/extraction/member đề xuất theo idempotency key hợp lệ. Không xóa sự kiện trùng để che việc gọi thừa.
- Hai người sửa đề xuất từ cùng phiên bản: CAS theo revision/hash; nhánh thua giữ bản nháp và báo xung đột. Không chọn bản thắng bằng timestamp/UUID lớn hơn.

## 3. Hai trục thời gian và chuỗi quyết định

| Nhóm | Trường tối thiểu | Ý nghĩa |
|---|---|---|
| Thời gian pháp lý/nghiệp vụ | `published_on`, `effective_from/until`, `application_from/until`, deadline timezone | Các mốc có căn cứ; `null` nghĩa chưa biết, không thay bằng ngày tải |
| Thời gian hệ thống biết | `retrieved_at`, `recorded_at`, `reviewed_at`, `released_at`, `checked_at`, `review_due_at` | Theo dõi khi nào hệ thống lấy, biết và duyệt thông tin |
| Mốc câu hỏi | `as_of`, `known_at`, chế độ `new_assessment` hoặc `recorded_history` | Phân biệt lập đánh giá tại ngày mục tiêu và đọc lại báo cáo đã có |
| Quan hệ nhân quả | `event_seq`, `previous_event_id`, `supersedes_event_id`, expected revision | Xác định quyết định đã commit kế tiếp; đồng hồ chỉ là metadata |

Khoảng hiệu lực dùng `[from, until)` với phép chuyển “đến hết ngày” được version hóa và giữ biểu đạt gốc. Nếu chỉ biết ngày thì không bịa giờ. Khoảng tiếp nhận có thể là `unknown`, `announced`, `open_verified`, `closed`, `quota_unconfirmed`; trạng thái phải có nguồn và thời điểm riêng.

Sửa đổi/thay thế gồm loại quan hệ, phạm vi điều/khoản, ngày hiệu lực, evidence và review event. Redirect, trang 404, ngày đăng mới hoặc một LLM nói “mới hơn” không đủ tạo quan hệ thay thế. Một bản mới đã được xác nhận thay bản cũ vẫn loại bản cũ khỏi tư vấn hiện hành ngay cả khi bản mới đang tạm không đọc được; không tự hồi sinh quy tắc cũ. Khi quan hệ mâu thuẫn hoặc có chu trình, trả `legal_lineage_conflict` và chặn riêng phần phụ thuộc để chuyên gia xử lý.

Tái dựng `as_of` không khôi phục quyền đã thu hồi. Báo cáo cũ, raw assertion, quyết định và receipt giữ nguyên; cảnh báo hiện tại là projection bổ sung. Không sửa lịch sử để làm cache hoặc phép thử mới khớp.

## 4. Tiếp nhận: registry, discovery, manual và MCP

### 4.1. Registry có phiên bản, phạm vi hữu hạn

Một cấu hình nguồn cần: cơ quan/chủ quản; domain nghiệp vụ; jurisdiction/market; loại kênh (trang danh mục, RSS, sitemap, API, URL văn bản); endpoint/redirect policy; bộ parser; quyền sử dụng và căn cứ; người quản trị; mục tiêu coverage; cadence/timeout/byte budget; cấu hình ưu tiên và lịch rà.

Allowlist **hẹp theo host/path/kênh**, được duyệt ngoài nội dung tải về. Danh mục hiện tại của Hà Nội và các host xuất khẩu là đầu vào kế thừa cần đối soát, không mặc nhiên mở mọi tên miền chính phủ. Nguồn khác quốc gia/cấp cơ quan cần đăng ký rõ. Không đưa một danh sách mới vào production chỉ vì được ghi trong tài liệu thiết kế này.

Discovery đọc danh mục chính thức/feeds/sitemap/API đã được phép; ghi URL/ID ứng viên, metadata tối thiểu, parent observation và lý do phát hiện. Search API tổng quát nếu sau này có chỉ là adapter phát hiện ứng viên, chưa được bật và không có ngân sách ở thiết kế này. Kết quả search/snippet không là toàn văn, evidence hay approval.

### 4.2. Máy trạng thái tiếp nhận

```text
discovered → quarantined → provenance_checked → accepted_for_extraction
                                             ↘ rejected / needs_clarification
accepted_for_extraction → bytes_stored → extraction_pending → extraction_ready
                                                        ↘ partial / unreadable / failed
extraction_ready + coverage verified → ready_for_knowledge_proposal
```

Các trạng thái không thay gate pháp lý hoặc review. `bytes_stored` không hiển thị “đã đọc”; `partial` không hiển thị “đã hiểu đủ”. Tệp chưa đọc được vẫn có bằng chứng lỗi và tên tệp cụ thể; lỗi của một tệp không giữ khóa chờ ở mọi tác vụ.

### 4.3. Bảng quyền và provenance

| Đường vào | Lưu tối thiểu | Điều kiện trước kho công khai |
|---|---|---|
| Internet | URL gốc/cuối, redirect chain, DNS/IP kiểm tra, request representation, status/headers chọn lọc, bytes/hash, trigger, cơ quan | Xác minh nguồn/loại quyền và phạm vi tái sử dụng; hợp lệ host không thay kiểm quyền nội dung |
| Manual | Actor, scope nhận, tên file gốc, bytes/hash, nguồn được khai, căn cứ quyền sử dụng, đơn vị sở hữu nếu riêng | Curator không tự công khai tài liệu riêng. Cần quyết định quyền/phạm vi có thẩm quyền và bản public đã loại dữ liệu riêng nếu được phép |
| MCP | Connector/tool/version, principal, resource ID, grant/scope hiện hành, payload hash, nguồn gốc nếu có | MCP không cấp quyền mới; connector đọc được không có nghĩa được sao chép/phát hành công khai |

Tài liệu doanh nghiệp riêng đi vào intake riêng và giữ ACL riêng; không dùng schema `usage_scope='public'` hiện có để chứa tạm dữ liệu riêng. Chuyển từ private sang public là một quy trình phát hành khác, mặc định **không hỗ trợ trong đợt đầu**. Cần dừng xin quyết định dữ liệu nếu thật sự cần; không có lệnh curator “đánh dấu public” vượt biên này.

Thông tin bí mật, dữ liệu cá nhân riêng hoặc không cần thiết, khóa truy cập, cookie và response header nhạy cảm không vào kho tri thức/log công khai; phát hiện thì quarantine theo phạm vi và xử lý có quyền. **Đầu mối công vụ được cơ quan công bố chính thức** có thể là typed claim `contact_channel`: tên/chức trách, số điện thoại hoặc email đã xác minh nguồn, đúng quyền sử dụng/phạm vi/mục đích/retention và qua review. Không coi mọi tên/số trong một tệp là đầu mối công khai; không biến dữ liệu khách hàng/nhân viên của doanh nghiệp thành public contact. Log chỉ ghi refs/hash cần thiết, không sao chép cả thông tin liên hệ nếu không phục vụ đối soát. K1 không có private→public promotion. Nguồn có chứa chỉ dẫn cho agent luôn là dữ liệu không tin cậy; không được đổi model, ACL, budget, tools hoặc SSOT từ nội dung nguồn.

## 5. Fetch, scheduler và cache kiểm mạng

### 5.1. Một quyết định độ mới dùng chung

Chat, MCP, worker, tác vụ xuất khẩu trực tiếp và policy assessment dùng chung **một hợp đồng chuẩn `policy-freshness-decision/1`**. Không có enum quyết định riêng ở UI hoặc entry point khác:

```text
FreshnessPolicy.evaluate(
  source_config_revision, selected_evidence_refs, outcome_kind,
  mode: new_assessment | discovery | history,
  as_of, now, current_rights, observation_head, approved_profile_revision
) -> {
  schema_version: policy-freshness-decision/1,
  decision: reusable | refresh_required | source_incomplete |
            changed_needs_review | currentness_unconfirmed | forbidden,
  mode, reason_codes[], usable_for[], blocked_outcomes[], next_check_at,
  basis_refs[], decision_hash
}
```

Đây là hàm quyết định không tự gọi Internet/mô hình hoặc thay source head. Status, recovery và mở kết quả cũ chỉ đọc; nếu cần kiểm mới, UI giải thích và tác vụ nghiệp vụ/lịch đã được phép mới yêu cầu job. Không có đường riêng tự gọi HTTP chỉ vì một nhánh chat chưa kiểm TTL như hiện tại.

Thứ tự chọn `decision` khi nhiều điều kiện cùng tồn tại, **trong cùng source/evidence scope**, là:

| Ưu tiên | Decision chuẩn | Ý nghĩa và giới hạn |
|---|---|---|
| 1 | `forbidden` | Quyền READ/quyền sử dụng/phạm vi nguồn không cho phép. Không trả nội dung hoặc ID/lý do nội bộ làm lộ nguồn không có quyền |
| 2 | `changed_needs_review` | Đã biết thay đổi/mâu thuẫn/quan hệ thay thế tác động phần đang xét, chưa hoàn tất rà và phát hành lại. Fetch thành công không gỡ cổng này |
| 3 | `source_incomplete` | Chưa có đủ text/trang/phụ lục/locator/coverage để chứng minh phần đang xét. HTTP thành công, quote khớp hoặc model tốt không làm đủ |
| 4 | `currentness_unconfirmed` | Không xác minh được yêu cầu hiện hành: lần kiểm thất bại, thiếu/hết hạn profile rà, tình trạng cửa nhận chưa xác minh hoặc một yêu cầu hiện hành chưa đạt |
| 5 | `refresh_required` | Đủ cấu trúc đọc nhưng hạn kiểm kỹ thuật đã tới, chưa có blocker ở mức trên; cần job kiểm được phép. Đây không là quyền tiếp tục assessment hiện hành trong lúc chờ |
| 6 | `reusable` | Các yêu cầu freshness/coverage/rights của source/evidence scope đã đạt. Vẫn cần các gate riêng về hiệu lực pháp lý, cửa nhận, review/member/release, context và quyền trước khi kết luận |

`reason_codes` giữ mọi nguyên nhân được phép công bố, không chỉ nguyên nhân thắng. Scope/outcome khác được đánh giá riêng; một nguồn forbidden không làm lộ metadata của nó khi giải thích gap, và một outcome bị chặn không chặn toàn bộ phần độc lập. Khoảng hiệu lực, cửa nhận và release có hợp đồng gate riêng; `reusable` **không đồng nghĩa** `eligible`, cửa nhận mở hoặc `assessment_allowed=true` cho cả nhiệm vụ.

Chế độ `new_assessment` không cấp căn cứ cho kết luận mới dựa trên phần source không reusable; các gate khác vẫn phải đủ theo D07. `discovery` chỉ cho metadata/đầu mối công khai đã được phép và trạng thái thiếu căn cứ; không nâng snippet thành claim. `history` cho đọc đúng snapshot/receipt theo READ hiện hành và cảnh báo riêng, không đổi quyết định freshness thành reusable chỉ vì đó là lịch sử. `forbidden` chặn nội dung bị từ chối trong cả ba chế độ; `as_of` không khôi phục quyền.

Trạng thái công việc là **projection trực giao**, không là decision enum:

```text
AcquisitionStatus {
  source_scope_ref, job_ref_if_readable,
  job_state: not_requested | queued | running | succeeded | failed | cancelled,
  observed_at, progress_if_known
}
```

Nguồn có thể reusable trong khi job định kỳ đang chạy; job succeeded vẫn có thể đi cùng source_incomplete hoặc changed_needs_review. Không dùng chữ “đang cập nhật” để thay blocker thật. Các tên `can_reuse`, `refresh_due`, `refresh_pending`, `currentness_review_required`, `blocked` xuất hiện trong **bản dự thảo đầu**, không phải bằng chứng API V17 đã chạy có enum đó. Nếu dùng làm nhãn UI thì chỉ là mapping từ **decision chuẩn + reason + job_state + mode**, không ghi thành decision thứ hai. DTO legacy thật phải được kiểm kê/version mapping riêng; không viết lại enum/raw payload/receipt đã lưu và chỉ đọc qua compatibility adapter có phiên bản.

### 5.2. TTL khác hiệu lực và khác độ đầy đủ

- **Fetch TTL**: khi nào cần kiểm endpoint lại. Trong TTL phù hợp có thể dùng observation/rendition đã đạt yêu cầu kỹ thuật, không tải lại theo từng doanh nghiệp.
- **Review due**: lúc cần rà tri thức/ngữ nghĩa/pháp lý dù bytes chưa đổi. Hạn này có thể sớm hơn hoặc muộn hơn cadence fetch; không tự gia hạn bằng HTTP thành công.
- **Legal validity**: hiệu lực có căn cứ của từng văn bản/điều khoản. Không suy từ TTL, `Last-Modified` hoặc ngày tải.
- **Application status**: cửa nhận/chỉ tiêu có nguồn riêng. `open_verified` hết độ mới thì thành chưa xác minh cho outcome cửa nhận, không tự đổi điều kiện của văn bản.
- **Completeness**: full text, trang, phụ lục, định nghĩa và companion documents cần thiết đã được đọc. Quote cũ còn tồn tại không giải quyết phần này.

Các giá trị cadence/TTL/giới hạn tài nguyên được lưu trong profile đã duyệt theo loại nguồn và claim. Bảng dưới là **mặc định kỹ thuật đề xuất để anh duyệt**, chưa hoạt động và không là kết luận nguồn còn hiệu lực:

| Profile đề xuất | Cadence/TTL kiểm kỹ thuật | Giới hạn pháp lý |
|---|---|---|
| Danh mục/feeds discovery đã được phép | 24 giờ | Chỉ phát hiện đầu mối mới; không duyệt nguồn mới hoặc nội dung |
| Văn bản chính thức đã đăng ký | 24 giờ | Kiểm lại representation và companion theo phạm vi; không tự gia hạn review/hiệu lực |
| Cửa tiếp nhận hoạt động, sự kiện hoặc gần hạn | 6 giờ | Chuyên gia định nghĩa trigger “gần hạn”, nguồn trạng thái và scope cụ thể; không suy quota còn từ việc trang truy cập được |

`currentness_review_due`, completeness và điều kiện legal/call gate vẫn do profile/chuyên gia có thẩm quyền xác định bằng căn cứ, không được điền tự động bằng các số trên. Thiếu profile hợp lệ: dùng discovery/lịch sử có nhãn; không tự chọn TTL để mở assessment hiện hành. Cần duyệt tập nguồn đầu tiên và profile trước khi bật lịch mới.

### 5.3. Gộp job và HTTP conditional request

Fetch key gồm endpoint revision + representation (Accept/language) + authorization partition + rights revision + fetch policy version. Nhiều doanh nghiệp cùng cần một nguồn public có thể cùng chờ một job public; câu hỏi/facts của doanh nghiệp không được ghi vào job chung. Nguồn riêng hoặc principal khác không gộp chỉ vì URL bằng nhau.

Lưu `ETag`/`Last-Modified` theo đúng endpoint/representation. Gửi `If-None-Match`/`If-Modified-Since` nếu có validator gắn một rendition đã lưu đầy đủ. `304` chỉ xác nhận server nói representation không đổi theo validator; ghi observation và giữ rendition, không tạo snapshot bytes rỗng. Nếu không có bản lưu hợp lệ hoặc validator/request không khớp, 304 không đủ; cần một lần full fetch được phép. HEAD hoặc Content-Length bằng nhau không là xác nhận nội dung.

Redirect kiểm lại HTTPS, host/path/IP tại từng bước; chặn localhost, private/link-local/metadata endpoint và DNS rebinding. Giới hạn redirect, kích thước nén/giải nén, timeout, số link/tệp/trang, MIME/signature, CPU/RAM và số worker. Trang đăng nhập, CAPTCHA, lỗi HTML trong response PDF hoặc response 200 rỗng phải thành lỗi tiếp nhận, không thành tài liệu mới đã đọc.

**Giới hạn bảo vệ đề xuất, chưa bật:** tối đa 3 HTTP request toàn worker và 1 mỗi host; 3 redirect; 20 giây/request; 10 MiB response nén và 20 MiB sau giải nén; PDF tối đa 100 trang và local parse tối đa 60 giây/job. Mỗi job HTTP được tối đa 2 lần thử thêm, có backoff/`Retry-After`; quá giới hạn vào hàng chờ với lý do. Đây là trần khởi đầu để qualification trên tài liệu công khai, không phải SLA hoặc quyền tải mọi tài liệu. Cần profile chuyên biệt nếu văn bản thật vượt trần; không tự tăng cap hoặc chuyển sang AI trả phí. Bộ giới hạn của parser sandbox/host hiện hữu nếu chặt hơn vẫn được giữ tới khi thay đổi được duyệt.

Job có lease + fencing token + expected head revision. Kết quả worker hết lease chỉ ghi observation/audit được phép; không được ghi đè head hoặc phát hành member. **K1 chọn SQLite BLOB cho bytes**, cùng database SQL với rendition/observation/outbox, để giao dịch có một authority. Không giữ transaction trong lúc network, parser, mô hình hoặc con người hoạt động. Hai unit of work riêng:

1. **UoW-A — tiếp nhận bytes:** tải/kiểm response hữu hạn ngoài SQL. Sau khi có bytes đã qua kiểm tiếp nhận, mở transaction ngắn, kiểm lại scope/rights/fencing/CAS, ghi BLOB bất biến + rendition + observation + outbox trích xuất rồi commit nguyên tử. Không có rendition khả dụng trỏ tới bytes chưa commit. Response lỗi chỉ ghi observation/audit tương ứng, không giả rendition hợp lệ. 304 tham chiếu rendition hiện hữu đã kiểm, chỉ ghi observation/validator/outbox cần thiết; không ghi BLOB rỗng.
2. **UoW-B — trích xuất:** worker đọc chính rendition đã commit và manifest; parser chạy **ngoài SQL**, K1 không gọi model. Sau đó transaction ngắn kiểm lại quyền/fencing/input hash/revision, ghi extraction + toàn bộ chunks/locators + event chất lượng + outbox cho indexing/diff rồi commit nguyên tử. Parser lỗi/partial có event trạng thái rõ; không để một phần chunks thành extraction ready. Bytes từ UoW-A vẫn giữ để đối chiếu và xử lý lại có phép.

Crash trước commit-A không để raw pointer/outbox nửa vời; sau commit-A nhưng trước commit-B thì SQL cho biết rendition đã bền và extraction còn chờ. Worker đọc lại SQL để tiếp tục, không tải lại Internet chỉ vì mất bộ nhớ. Crash trước commit-B không để extraction/chunks nửa bộ; sau commit-B, idempotent outbox/receipt được đọc lại, không tạo extraction hoặc đề xuất thứ hai. Khi K2 có model, durable Gateway manifest/attempt/reconciliation riêng vẫn có trước dispatch và **không tự gọi model lại** khi hồi phục. Việc đổi sang file/object store chỉ có ở ADR tương lai với protocol riêng cho staging, fsync/rename hoặc object finalization, SQL commit, orphan cleanup, backup và crash tests; không thuộc K1.

### 5.4. Ưu tiên và ngân sách tài nguyên

| Mức | Ví dụ | Quy tắc vận hành |
|---|---|---|
| P0 | Nguồn đã dùng phát hiện thay đổi/rút, hoặc cửa nhận gần hạn có nguồn trạng thái | Đánh dấu blocker đúng dependency ngay; ưu tiên kiểm có giới hạn, không chờ AI mới chặn |
| P1 | Job cho một đánh giá đang được người dùng yêu cầu, nguồn quá hạn kiểm | Gộp với job có sẵn; trả progress/gap theo từng outcome; không khóa toàn app |
| P2 | Kiểm định kỳ nguồn đã phát hành và companion documents | Theo cadence/rate limit của cơ quan, dàn lịch có jitter |
| P3 | Discovery hoặc ingest số lượng lớn | Có hạn mức số URL/bytes/thời gian; không làm đói P0/P1 và review queue |

Mỗi host có concurrency/rate quota, backoff hữu hạn và `Retry-After` cho 429/503. Retry HTTP không trả phí phải theo policy đã duyệt và ghi số lần; không biến retry HTTP thành OCR/dịch/LLM có phí. Lỗi cần người xử lý vào dead-letter có lý do, không lặp vô hạn. Dashboard theo dõi tuổi job, số lần lỗi, review backlog, bytes/CPU, độ trễ và chi phí AI tách riêng.

## 6. Extraction, diff và đề xuất tri thức

### 6.1. Đọc có thể kiểm chứng

HTML giữ bytes gốc, version main-content extractor, text và cấu trúc. PDF kiểm signature/encryption/page count; parser local trước; lưu text/locator theo từng trang và bảng nếu nhận được. PDF scan/mixed scan có `ocr_required` hoặc `partial`; không đưa vài trang có text thành “đủ văn bản”. Tệp đuôi PDF nhưng nội dung Excel bị từ chối trước parser/AI, nêu đúng tên tệp và cho gỡ khỏi lượt xử lý.

Chất lượng cần các trục riêng: MIME hợp lệ; số trang đã đọc/tổng; mất ký tự/font; đọc bảng; thứ tự; chữ ký/phụ lục; trạng thái ngôn ngữ; parser version; coverage verification. “Parser chạy thành công” không được dùng làm `complete_policy=true`.

OCR hoặc mô hình đọc ảnh/dịch/trích xuất AI, nếu có, là capability có egress, consent/governance và ngân sách riêng qua **cùng Model Gateway**. Mặc định không bật tự động. Có API key và quỹ 20 USD dành tester không phải quyền chạy cả corpus hoặc job nền.

Derivation key gồm rendition/extraction refs và hash, processor/config/schema revision, ngôn ngữ, profile/model nếu dùng, quyền và rights revision. Trước reuse kiểm lại READ/quyền sử dụng. Chỉ raw payload/manifest public **khớp chính xác** mới có thể dùng lại receipt mô hình tương ứng; không fuzzy-match và không chia câu trả lời riêng.

### 6.2. Khác biệt bytes và khác biệt có ý nghĩa

| Tình huống | Xử lý lưu trữ | Tác động tư vấn |
|---|---|---|
| Không đổi bytes, extraction version không đổi | Observation mới, dùng lại rendition/extraction; không tạo member | Chỉ kiểm lại gate kỹ thuật được phép; không tạo legal review giả |
| Bytes đổi do định dạng/banner; toàn phần liên quan chứng minh không đổi | Rendition/diff mới; giữ liên kết cũ và quyết định phân loại có căn cứ | Chỉ giữ gate nếu policy phân loại cho phép; trường hợp chưa chắc vào review |
| Bytes không đổi nhưng parser mới đọc thêm ngoại lệ/bảng/phụ lục | Extraction mới + semantic diff; giữ extraction cũ | Có thể cần block/review member dù raw hash không đổi |
| Điều kiện, hạn, số tiền, đối tượng, ngoại lệ, thủ tục hoặc companion đổi | New rendition/extraction; diff có locator; proposal mới | Mark dependency impacted/needs_review; không tự mang approval sang bản mới |
| Chỉ quote cũ còn, nhưng phần khác chưa đọc hoặc thêm mục chưa phân loại | Không nhận “không thay đổi đáng kể” | D07-A chặn phần nghi ngờ; không chỉ dựa exact-excerpt check |
| Nguồn biến mất hoặc tạm lỗi | Observation thất bại, giữ bản lưu | Không suy bãi bỏ; currentness gate theo outcome/profile |

Diff máy là tín hiệu và công cụ review, không tự xác nhận tương đương pháp lý. Giữ cả raw diff và semantic diff proposal với processor version. Phần xác định tác động phải duyệt cả các mục “không đổi”; nếu mapping dependency thiếu thì chặn phạm vi nghi ngờ thay vì tuyên bố không ảnh hưởng.

### 6.3. Đầu ra trích xuất là đề xuất có kiểu

Một extraction/proposal trả `instrument_candidates`, `program_candidates`, `call_candidates`, `claim_candidates`, `rule_candidates`, `relation_candidates` và `coverage_gaps`. Mỗi item có ID trong batch, schema/kind, scope, ngày đã biết/chưa biết, exact quote/locator/hash và lý do. Nội dung tự suy không có căn cứ phải được gắn `unsupported` và không có đường phát hành.

Rule dùng DSL hữu hạn và registry field dùng chung. Field có qualifier phải qua `domain_validation.base_field_key` để phân loại scope/value/sensitivity; vẫn giữ exact key/value và exact-field permission. Field nghiệp vụ mới cần contract + ca âm, không chỉ thêm prompt. `applies_when`, condition, exception và claim item đều có dependency/evidence, tránh chỉ condition được nối graph.

Claim có kiểu tách biệt: `eligibility_explanation`, `amount_or_formula`, `preparation_item`, `procedure_step`, `application_window`, `contact_channel`, `definition` hoặc loại khác chỉ sau contract mới. Không chấp nhận `kind=rule` nhưng payload tự nhận amount; không dùng citation chung để hợp thức hóa mọi checklist item.

Proposal không sửa SSOT của doanh nghiệp. Các biến như tỉnh đăng ký, quy mô hoặc ngành nghề chỉ là field yêu cầu; khi áp dụng mới đọc đúng SSOT được phép và hỏi phần còn thiếu. “Có thể phù hợp” không là “đủ điều kiện”; “đủ điều kiện theo rule” không là “đang nhận” hoặc “đã được duyệt hỗ trợ”.

## 7. SQL, graph và manifest dùng lại

### 7.1. Quan hệ có kiểu trên SQL

Các cạnh cần cho đợt đầu:

```text
endpoint --observed_as--> rendition --extracted_as--> extraction --contains--> chunk
instrument_edition --has_rendition--> rendition
instrument_edition --amends/replaces/repeals--> instrument_edition [scope + valid interval + evidence]
program --grounded_in--> instrument_edition
call --part_of--> program
member_version --supported_by/exception_supported_by--> exact chunk/span
member_version --requires_fact/applicability_requires_fact--> exact field contract
member_version --depends_on--> instrument_edition/call/other member_version
pack_release --contains_exact--> member_version + hash + publication event
page_revision --references_claim--> exact member_version
page_revision --supported_by--> exact evidence binding / chunk span
page_revision --links_to--> page_id [navigation only; not a legal relation]
pack_release --contains_exact_wiki--> page_revision + body hash + review event
retrieval_run --used--> pack_release/member/evidence/context manifest
```

Mỗi relation có contract/version, endpoint kinds, scope, provenance, review state và hash. Mọi command propose/review/publish/release/read đều dùng cùng validator. Graph index là projection dựng lại từ dữ liệu có thẩm quyền; không là đường ghi truth mới. Không traversal không giới hạn, không query tùy ý do LLM đưa vào SQL.

### 7.2. Manifest căn cứ theo outcome

Ví dụ hợp đồng **logic**, không phải response đang có:

```json
{
  "schema_version": "policy-evidence-bundle/2",
  "outcome_id": "training_support",
  "domain": "hanoi_policy",
  "scope": {"jurisdiction": "VN-HN", "target_date": "2026-10-26"},
  "decision": "source_incomplete",
  "source_refs": [],
  "member_refs": [],
  "pack_release_refs": [],
  "wiki_revision_refs": [],
  "context_manifest_ref": "private-context-reference",
  "retrieval_policy_revision": "proposed-baseline/1",
  "index_generation": "generation-reference",
  "usable_for": ["show_known_public_contact"],
  "blocked_for": ["eligibility_conclusion"],
  "missing_evidence": ["verified_full_policy_and_annex"],
  "provider_call_required": false
}
```

Khi có evidence, từng ref ghi exact version/hash/locator và rights/availability decision; không chỉ source ID. Manifest không tự được công khai nếu có context private. LLM không được bổ sung claim ngoài tập hợp `allowed_claim_ids` và phạm vi `usable_for`. Kết quả tiếng Việt; nguồn không phải tiếng Việt có bản dịch mang trạng thái và nút xem nguyên bản, không để nguyên đoạn tiếng Anh thành kết luận pháp lý chính.

Bản 1.1 dùng **`policy-evidence-bundle/2`** làm draft canonical có `wiki_revision_refs`; `/1` của baseline trước P06 là bản thiết kế đã lưu, không được mô tả như wire contract đang chạy. Mỗi wiki ref có page/revision/body hash, release và dependency manifest; không thay `member_refs` hoặc original evidence. API legacy thực tế giữ adapter/receipt cũ, không tự promote payload.

### 7.3. Trình tự retrieval

1. Giải câu hỏi thành outcome riêng, giữ câu gốc và ngày/thị trường người dùng nêu. Không tự thêm Nhật hoặc bỏ nhu cầu thứ hai.
2. Context resolver đọc exact SSOT fields/entities được phép. Facts chuẩn theo ID, không tìm gần nghĩa để chọn doanh nghiệp/sản phẩm.
3. Lọc domain/jurisdiction/market, rights, loại nguồn, legal/call time và trạng thái review/publication. Unknown scope không fallback Mỹ hoặc gói số hóa kho.
4. Tìm ứng viên bằng metadata + FTS5 + alias version, gồm wiki đã phát hành để định hướng; mở rộng có giới hạn qua typed links để lấy definition/exception/annex/companion. Wiki chỉ đến exact claim/evidence, không tự trở thành nguồn pháp lý hoặc thay closure ngoại lệ.
5. Nạp lại canonical rows, kiểm hash/coverage/currentness/release/member/dependency; không tin chỉ mục. Selected candidate phải áp dụng đúng outcome và SSOT; một candidate gần từ khóa không đủ.
6. Trả evidence bundle cho từng outcome, kể cả outcome bị chặn và gap. Nếu dùng Claude, Gateway seal manifest đúng payload/profile và quyền; không cho agent tự gọi transport khác.
7. Trước công bố, kiểm lại ACL, context, source head, rights, reviewed member và release. Nếu đã đổi, giữ response đã trả phí làm lịch sử có giới hạn; không tự gọi lại để sửa.

Baseline không dùng embedding/reranker AI. Thêm alias có phiên bản và tập đánh giá recall trước. Chỉ mở embedding port sau benchmark cho thấy thiếu do diễn đạt/đa ngôn ngữ, có data/egress/budget approval; SQL gates giữ quyền và thẩm quyền dù sau này có vector.

### 7.4. Canonical wiki revision và hợp đồng dữ liệu — P06

Wiki là sản phẩm biên soạn có giá trị riêng, không chỉ template xuất bảng. SQL giữ body Markdown nguyên bản và mọi revision để đọc/diff/khôi phục. Body tổng hợp không được coi là có thể tái tạo y hệt bằng AI từ nguồn; chỉ **projection** mới có thể dựng lại không model.

| Hợp đồng logic | Thành phần và bất biến |
|---|---|
| `knowledge-page-revision/1` | Stable page ID, exact revision/base/parent, kind/scope/language, body bytes/hash, recipe/schema version, author/operation/receipt refs; dependencies là exact claim/rule/evidence/translation refs. Server tính digest và kiểm READ/WRITE/CAS, không tin frontmatter |
| `knowledge-page-evidence/1` | Binding từng nhận định vật chất/section ID tới claim version và exact evidence span; navigation links có role riêng. Đường về raw không được kết thúc ở một trang wiki khác. Quote khớp là kiểm kỹ thuật, không tự chứng minh entailment/completeness |
| Release extension | Exact `wiki_revision_refs` có body hash, review event và dependency manifest. Publication service kiểm target kind wiki; duyệt wiki không duyệt rule, rule approved không tự làm mọi trang wiki được publish |
| `knowledge-markdown-bundle/1` | Export manifest ghim page/revision/hash + canonical source refs; index/backlinks/log là projection. Bản xuất chỉ chứa các resource có quyền và cảnh báo phạm vi/as-of. Đây là contract XAI, không tự nhận conformant OKF |

**Không tạo freshness enum mới.** `policy-freshness-decision/1` ở §5.1 tiếp tục là authority; workflow nháp/review/publish, job state và READ là các trục độc lập. Bản dịch wiki có revision và liên kết bản gốc, không ghi đè hoặc cấp hiệu lực cho nguyên bản.

**Command edit/import:** actor và scope do server giải từ phiên; nhận `page_id`/base revision được phép, body và operation identity. Sửa tạo revision candidate; concurrent update báo conflict và giữ nháp. New-page candidate cần identity resolution riêng; title/casefold/semantic similarity không đủ để gộp trang hoặc dữ kiện. File nhập có `verified`, `stable` hay chữ “approved” vẫn là nội dung chưa có quyết định server. Trusted skills/config không nằm trong import target.

**UoW ghi wiki:** kiểm current READ của mọi dependency, WRITE/lifecycle/CAS của target và uniqueness command → lưu revision/body/evidence/dependencies + head/decision cần thiết + outbox + receipt trong SQL. Parser/render/LLM nằm ngoài transaction; commit tái kiểm input versions. Exact receipt replay kiểm identity và READ hiện hành, không dựng defaults hoặc yêu cầu mutation mới. Review/publication thực hiện command riêng qua authority hiện có và exact hash.

**Materialization:** consumer outbox ghi projection theo revision/hash, temp file rồi replace; commit SQL không phụ thuộc filesystem thành công. File cũ/trễ hoặc sửa tay không được dùng nếu không khớp canonical manifest/gates. Lỗi materializer có thể xử lý lại không AI, không tạo publication/receipt mới. Mọi search/read/title/snippet/backlink/export đều tái kiểm READ, không chờ cleanup index để bảo mật. Nếu dependency không được phép thì chặn trang hoặc trả một projection độc lập đã được chứng minh có quyền, không tự redaction body bằng LLM.

**Liên kết và trao đổi:** Markdown links chuẩn được resolve về stable ID; đổi slug không đổi identity. `links_to` chỉ điều hướng, khác `amends`, `requires_fact`, `exception_supported_by`. Resolver chặn traversal không giới hạn/path escape. Import/export hỗ trợ metadata mở có version; mapping OKF phải có conformance/round-trip tests riêng và không lấy trust advisory/mặc định `stable` làm quyền phát hành. Không hai chiều tự đồng bộ file→SQL; không agent ghi thẳng file live, release hoặc quyền.

## 8. Các lớp cache, không trộn quyền

| Lớp | Dùng chung được khi nào | Key/dependency | Không được làm |
|---|---|---|---|
| Fetch/bytes/extraction công khai | Cùng endpoint/representation/rights/processor contract hợp lệ | Source config/rights revision, rendition/extraction hash, processor/config/version | Mỗi doanh nghiệp tải lại cùng public source; coi cache còn hạn là luật còn hiệu lực |
| Wiki body/release và các projection | Exact public page revision và closure căn cứ còn đọc/dùng được | Body/schema/recipe hash, claim/evidence/translation refs, release/rights/gate revisions; materialization generation | Xóa body chuẩn rồi gọi model dựng lại; tin metadata file/Git; cache hit tự refresh/model hoặc lộ title khi source revoke |
| Ứng viên/evidence công khai | Chỉ public canonical facts, cùng structured scope/outcome và version | Retrieval policy, alias/index generation, evidence/member/release/gate revisions, target date | Ghi câu hỏi hoặc SSOT riêng vào key/value public; lộ ID nguồn private qua lý do loại |
| Retrieval/kết quả cá nhân hóa | Cùng actor/enterprise/workspace hoặc sharing được quyền hiện hành, exact inputs/contract | Context manifest exact fields, source/member/release/rights/gate, schema/prompt/profile, operation/receipt lineage | Dùng câu trả lời của A cho B; ACL hash cũ thay current READ; cache hit tự gọi AI |

Cache invalidation dựa dependency, không chỉ revision tổng. Đổi quyền nguồn chặn READ ngay; cleanup FTS/cache có thể chạy sau nhưng không quyết định quyền. Đổi pháp lý/nguồn/call/member/release/translation ảnh hưởng đúng outcome. Thêm một field trước đó thiếu nhưng nay làm applicability khác cũng phải invalidation; không chỉ field đã có giá trị mới là dependency.

FTS có generation, analyzer/alias/extraction manifest và coverage hash. Canonical write + outbox → xây generation → kiểm đủ và integrity → swap pointer nguyên tử. Không trộn generation mà không trace. Index lỗi có fallback SQL/từ khóa hữu hạn và nhãn coverage nếu đủ quyền/căn cứ; không bỏ gate để lấy nhiều kết quả hơn.

Đổi hợp đồng output/prompt không làm receipt cũ mất đường đọc: finite compatibility registry cho đúng whole request/manifest, không khớp gần đúng. New command dùng contract mới; exact replay kiểm identity gốc và READ input hiện hành, không dựng lại implicit defaults theo hồ sơ hôm nay. Archive không tự thu hồi READ lịch sử; revoke quyền nguồn vẫn thắng ownership/grant shortcut.

## 9. Mô hình vật lý và lộ trình schema

### 9.1. Dùng lại authority hiện có

| Thành phần đang có | Giữ/dùng lại | Điểm cần bổ sung bằng contract mới |
|---|---|---|
| `pol_sources`, `pol_source_snapshots`, `pol_chunks`, `pol_translations` | Giữ nguyên rows, IDs, hash và evidence lịch sử; làm adapter typed legacy refs | Sidecar revision/quality/identity. Không UPDATE snapshot immutable để thêm text/offset mới |
| `pol_members`, review/publication events, packs/releases | Authority duyệt/phát hành hiện có; exact member/content hash/review event | Validator/binding schema có version cho new evidence refs; không lấy approval cũ cho bản mới |
| `pol_graph_edges`, FTS, aliases, retrieval/dependencies | Projection và truy xuất baseline | Typed edge contract, generation/watermark và complete applicability dependencies |
| `pol_refresh_jobs/events`, source observations/gates | Lịch/lease/event hiện có là nền, không tạo scheduler song song | CAS/fencing/coalescing, request validators, rights partition, profile/outbox contract |
| `v03_domain_sources/references/observations`, export pack/supersessions | Giữ legacy identity và receipt; adapter cho nguồn xuất khẩu | Mapping explicit sang pipeline mới; không tự nâng `reference_unreviewed` thành approved |
| Core ACL, SSOT, operations/receipts, Gateway và schema lifecycle | Dùng cùng authority; không service riêng vượt cổng | Public-domain service subject và scoped grant cho job nền trong **cùng Gateway**, không giả doanh nghiệp/tài khoản |

### 9.2. Các bảng logic mới đề xuất

Tên/schema cuối sẽ được duyệt trong ADR triển khai. Không tạo tất cả “để dành”; từng bảng phải gắn ca nghiệm thu và gói migration. Đây là inventory để nhận diện trách nhiệm, không là DDL đã cho phép.

| Nhóm đề xuất | Bảng logic | Nội dung/khóa tối thiểu |
|---|---|---|
| Registry | `kp_source_config_revisions`, `kp_source_heads` | Immutable config/rights/fetch profile revisions; head CAS; legacy source ref |
| Discovery | `kp_discovery_candidates` | Endpoint/candidate key, provenance, classification/rights review, state/revision; không chứa SSOT |
| Bytes | `kp_renditions` | Rendition ID, **bytes lưu SQLite BLOB trong K1**, raw hash, MIME/size, provenance/rights ref; legacy snapshot ref tùy chọn. External blob ref chỉ sau ADR/crash protocol tương lai |
| Extraction | `kp_extractions`, `kp_chunks` | Exact rendition, processor/config version, text hash/quality/page coverage; chunk text/span/locator/hash |
| Diff/derivation | `kp_derivation_runs` | Input refs/hash, kind, processor/profile, output refs/hash, status; Gateway manifest/attempt/receipt ref nếu có phí |
| Identity | `kp_instruments`, `kp_instrument_editions` | Legal identity/provenance, version/interval and selected rendition; unresolved identity giữ riêng |
| Chương trình/đợt | `kp_programs`, `kp_calls` | Program/call identity và typed version payload; nguồn/căn cứ; không chỉ một cột trạng thái chung |
| Quan hệ | `kp_relation_events` | Typed immutable relation decision, evidence, scope/valid time, causal predecessor; projection head riêng |
| Đề xuất/binding | `kp_knowledge_proposals`, `kp_evidence_bindings` | Proposal revision/hash/kind và exact claim-item→chunk span/role; promotion ref sang member version |
| Wiki identity/body | `kp_wiki_pages`, `kp_wiki_revisions` | Stable ID/scope/kind và canonical immutable body/hash/parent/base/recipe; head CAS không tự cấp publication. Không lưu đường dẫn mutable thay body |
| Wiki links | `kp_wiki_links` | Exact source revision, target page/claim/evidence refs và role; navigation tách quan hệ nghiệp vụ; semantic edges có authority typed chung |
| Phụ lục/coverage | `kp_document_requirements` | Edition/outcome cần tài liệu nào, trạng thái đủ/thiếu, evidence và người kiểm; không đếm file là đủ |
| Điều phối | `kp_pipeline_jobs`, `kp_pipeline_outbox` | Kind/key/input manifest, scoped authorization/budget reference, lease/fence/CAS, attempt; event durable |
| Chỉ mục | `kp_index_generations` | Generation/config/version, canonical watermark/hash, ready/active pointer |

Nếu có thể mở rộng đúng contract `pol_refresh_jobs`/events thay `kp_pipeline_jobs` ở lát cắt đầu, **chọn một** scheduler/job authority, không chạy hai đường cùng xử lý nguồn. Bảng cần cho extraction/pháp lý mới không được giả lập bằng chèn dữ liệu riêng vào public table. K1 **bắt buộc dùng SQLite BLOB** theo UoW-A/UoW-B ở mục 5.3; file/object store là ADR tương lai về dung lượng, ACL, backup/retention và protocol crash xuyên hai hệ lưu trữ, không là tùy chọn âm thầm trong K1 hoặc lý do mở thêm database ngay.

Legacy snapshot đã lưu cả bytes và text là một envelope bất biến. Adapter chỉ tham chiếu nó; lần trích lại tạo `kp_extractions/kp_chunks` mới. Rendition mới lưu bytes trước extraction, không phải nhét text rỗng rồi UPDATE snapshot legacy sau. New binding có typed ref `legacy_pol_chunk` hoặc `pipeline_chunk`; canonical resolver kiểm đúng type/hash/quyền, không trùng namespace. Promotion tạo member phiên bản mới theo hợp đồng mới; không sửa evidence_json của member cũ.

Wiki dùng chung `kp_knowledge_proposals`/evidence, operation/receipt, review/publication và outbox services; không thêm kho proposal, ledger hoặc bộ duyệt song song. Extension cho target kind wiki phải có validator/capability/migration explicit trong implementation plan; không ép page ID thành rule ID, không mở toàn cục scope của chuyên gia hiện tại. Title/validation metadata cũng qua exact READ cùng lineage như body. Tên bảng ở trên là inventory thiết kế, không tự tạo lúc startup.

Public job cần manifest riêng về **quyền vận hành**: service subject, allowed source/domain/actions, rights revision, request input hash, capability/profile, scoped budget/grant ref, idempotency key và outcome. Số lượt/chi phí/dispatch ledger vẫn thuộc Gateway hiện có. Không có provider adapter hoặc ledger ngân sách thứ hai ở pipeline; không tạo doanh nghiệp giả để vượt FK, cũng không dùng quỹ tester local làm grant công việc nền. Khi chưa có service-subject capability, job dừng ở bước local/manual hoặc explicit authorized command được thiết kế đủ, không giả là đã hỗ trợ nền có phí.

### 9.3. Phạm vi K1/K2/K3

| Gói | Phạm vi dữ liệu cần trước | Chưa bật trong gói |
|---|---|---|
| **K1 — pipeline deterministic Hà Nội** | Một chương trình được chọn, đủ bộ căn cứ; registry có phiên bản; bytes/extraction/coverage; identity/version; lịch/observation/outbox; wiki body/diff/typed links và manual proposal/import/export qua governance; evidence/retrieval dùng chung | Không paid OCR/dịch/extraction, không tự phát hành, không mở toàn bộ Internet. Parser không đọc đủ thì vào hàng chờ xử lý thủ công, không giả kết quả |
| **K2 — đề xuất tri thức bằng AI** | Service subject/public-domain authorization, scoped grant và manifest trong cùng Gateway; derivation/proposal/binding có phiên bản; review đúng hash | Không lấy pool tester để chạy nền; không tự retry/fallback hoặc approve. Đến đây mới bàn dự toán corpus và grant cụ thể |
| **K3 — mở rộng domain và chất lượng retrieval** | Adapter xuất khẩu giữ legacy receipts, thêm source/coverage theo scope được duyệt; benchmark tiếng Việt/đa ngôn ngữ | Không embedding hoặc database mới nếu chưa có bằng chứng và phê duyệt dữ liệu/chi phí |

K1 chỉ bắt đầu sau khi chủ dự án duyệt thiết kế/phạm vi, không là bước đang chạy. Các bảng logic chỉ cần cho K2/K3 không được triển khai sớm để làm K1 có vẻ hoàn chỉnh. K1 cũng không tự động biến bốn snapshot hiện tại thành một pack đủ căn cứ; phải kiểm thật bộ văn bản/phụ lục và có review/publication events hợp lệ.

### 9.4. Migration và backfill là hai việc khác nhau

1. Thiết kế DDL/constraints/index/triggers và exact runtime contract, gồm managed ledger hợp lệ. Preflight trên DB V17 có ledger và fixture baseline được hỗ trợ; không wildcard object lạ.
2. Migration **schema/metadata kỹ thuật** tạo bảng rỗng và contract version. Không tự nhập nguồn, tạo rule, chọn identity, công khai tài liệu, bật lịch, gán reviewer hay đổi approval khi startup.
3. Backfill/mapping legacy là operator command riêng: preview source IDs, kiểu ref, hash, quyền và số bản ghi; cần phê duyệt phạm vi dữ liệu. Dữ liệu legacy không đủ bằng chứng giữ `legacy_reference`/gap; không tự nâng chất lượng.
4. Rehearsal backup → apply → verify → managed factory → exact receipt replay → các bảng cũ hash/rows không đổi. Xử lý baseline không có optional ledger trước commit theo contract, không báo sau commit như có thể apply lại.
5. New schema + adapter chưa đủ để bật toàn bộ job. Bật từng registry/profile và permission sau nghiệm thu; restart không làm business backfill. Rollback app phải đọc được schema/receipts đã tạo hoặc dừng có chủ đích; không phục hồi backup đè dữ liệu mới.

## 10. Ma trận kỹ thuật khó và kết quả cần có

| Ca | Hành vi bắt buộc |
|---|---|
| Cùng URL đổi đuôi PDF/HTML hoặc trả trang lỗi | Kiểm MIME/signature và quality; observation lỗi nêu tên; không nhận là policy mới |
| 304 nhưng mất blob cũ hoặc sai representation | Không trả “nguồn còn nguyên”; yêu cầu full fetch được phép hoặc gap |
| PDF bytes không đổi, parser mới phát hiện ngoại lệ | Extraction/diff mới; dependency affected; approval cũ không tự bao phủ |
| Một trong ba phụ lục chưa đọc | Outcome phụ thuộc dừng riêng; không đếm ba URL là đủ ba bản đọc |
| Trang chỉ đổi banner nhưng kèm phụ lục đổi âm thầm | Companion/version check nhận thay đổi; không dùng body HTML không đổi để bỏ kiểm |
| Lease worker A hết, worker B đã commit | A không đổi head/state mới; audit stale lease, không duplicate member |
| DNS/redirect trỏ private hoặc file nén phình lớn | Chặn trước đọc/parse ngoài hạn; không fallback sang tool tự do |
| Hai văn bản cùng số/ký hiệu khác cơ quan | Identity conflict; curator review, không tự merge |
| Văn bản thay thế bị rút quyền truy cập | Nguồn cũ không tự sống lại; phần hiện hành thiếu căn cứ, lịch sử theo READ |
| Reviewer duyệt hash A, proposal đã là B | Publish B bị từ chối; approval A chỉ áp dụng A |
| Source rights revoke khi result đang render/download | Current READ deny; không đợi index/cache cleanup |
| Hai doanh nghiệp hỏi cùng public policy | Reuse nguồn/approved knowledge, mỗi bên giải quyền/applicability SSOT riêng; không copy kết luận |
| Model trả JSON hợp lệ nhưng bỏ outcome thứ hai | Coverage fail cho phần thiếu; giữ kết quả có phí đã nhận, báo giới hạn; không auto retry |
| Cache/replay từ contract trước | Exact historical builder/READ hoặc fail có nhãn; không sửa request/receipt gốc hoặc gọi lại |
| Model/paid parse chết sau dispatch | Giữ durable manifest/attempt, reconcile theo Gateway; không gọi lại vì chưa thấy UI kết quả |

## 11. Nghiệm thu ban đầu và bằng chứng

| ID | Kiểm chứng | Điều kiện đạt |
|---|---|---|
| PK-D01 | URL/identity/rendition/extraction | Cùng bytes khác URL; cùng URL khác bytes; cùng bytes khác parser đều giữ đúng identity/provenance; không overwrites |
| PK-D02 | Fetch coalescing, conditional HTTP và freshness chuẩn | N doanh nghiệp chỉ một fetch public đang chạy; 304 đúng/sai context có kết quả đúng; 0 provider call. Nhiều blocker chọn đúng precedence, giữ reason được phép; new_assessment/discovery/history không đổi authority; job running/succeeded không tự đổi decision |
| PK-D03 | Completeness/D07 | HTML thiếu phụ lục, PDF scan/mixed/encrypted, quote cũ còn nhưng thêm ngoại lệ; chặn đúng outcome, phần độc lập còn dùng được |
| PK-D04 | Causal/time | Cùng timestamp/UUID đảo; tương lai/quá khứ; replacement withdrawn; closed call nhưng law effective; không đoán head hoặc revive |
| PK-D05 | Kind/binding | Contradictory rule/claim, missing exception, applies_when không có dependency, sai quote/span/hash, sai typed legacy ref đều bị chặn tại mọi write/read gate |
| PK-D06 | Rights/private | Manual/MCP private không vào public corpus; source revoke sau cache/LLM/read/download; owner/grant không thắng deny nguồn. Official duty contact có evidence/review được claim đúng scope; số riêng/không cần thiết trong cùng tệp không được promote theo |
| PK-D07 | Retrieval | Hai nhu cầu xuất khẩu+đào tạo, nhãn hiệu/OCOP, ngoài phạm vi; không trả một gói cố định; gap rõ, đúng thị trường/ngày |
| PK-D08 | Cache và lịch sử | Same exact public derivation có thể reuse; private answer không reuse cross-enterprise; old receipt nguyên vẹn; status/recovery không provider |
| PK-D09 | Worker/crash | Crash ngay trước/sau commit-A (BLOB+rendition+observation+outbox) và ngay trước/sau commit-B (extraction+chunks+event+outbox): không dangling bytes pointer, thiếu chunks, orphan/duplicate hoặc publish nhầm. Giữa A/B đọc SQL tiếp tục không refetch/model; sau B exact replay. Lease expiry/CAS branch collision/duplicate connector event có ca âm; không transaction giữ qua network/parser/model/human |
| PK-D10 | Migration | V17 baseline → operator → current readiness/managed factory → exact replay; old rows/hash giữ nguyên; negative extra object/ledger sai bị chặn |
| PK-D11 | Chất lượng thực | Một policy/program/call do chuyên gia chọn, đủ căn cứ và phát hành thật; tập câu hỏi Trà Sen đối chiếu bởi reviewer độc lập; chi phí/coverage/độ mới có số đo |
| PK-D12 | Ngân sách | Chưa có grant public job thì paid stage không dispatch; budget/consent/egress/common Gateway fail trước reserve; không tự lấy tester pool/retry/fallback |

Test kỹ thuật được viết trước triển khai. Kiểm chất lượng Claude thật phải tách khỏi test deterministic, có phạm vi nguồn/câu hỏi/lượt/trần phí đã duyệt và biên nhận; thiết kế này chưa gọi lượt nào. Cần bằng chứng release cuối, không cộng test các source khác nhau để gọi là full acceptance. Một văn bản đủ làm demo không đủ đánh dấu cả domain đã bao phủ.

## 12. Quyết định còn cần khi duyệt thiết kế

**P06 đã chốt:** wiki có canonical body/revision trên SQL, Markdown chuẩn, cùng LangGraph/Gateway, FTS/typed links trước embedding. Không xin lại hướng này. Các quyết định vận hành bên dưới chưa được suy thành đã duyệt qua P06.

1. **Tập nguồn/chương trình đầu tiên và taxonomy coverage**: ưu tiên một chương trình có chiều sâu, sau đó mở đào tạo/xúc tiến thị trường/nhãn hiệu/OCOP theo nguồn thực. Danh sách này là hướng cần chốt, không phải công bố đã có đủ nguồn.
2. **Profiles cadence/TTL/review due và resource budget** theo rủi ro, host và loại outcome; không mặc định hằng ngày cho mọi thứ.
3. **Quyền lưu/tái sử dụng và retention** của raw bytes, lịch sử, extraction, model receipt, backup và các connector; tách public/private. Nếu phải đưa dữ liệu riêng sang nhà cung cấp/công khai thì dừng chốt dữ liệu.
4. **Grant vận hành public-domain service** cho OCR/dịch/extraction bằng AI: ai duyệt, scope, lượt/trần phí và cơ chế dừng. Chưa có số tiền đề xuất trong tài liệu này; không dùng hạn mức tester thay quyết định đó.
5. **Chính sách promotion legacy và bộ tiêu chí completeness** của nhóm chính sách đầu tiên. Không bật backfill nghiệp vụ hoặc cho AI tự gán pháp lý.

Các vấn đề trên không mở lại D04/D05/D07-A hoặc phân công chuyên gia đã chốt. Cơ chế `trung@dtt.vn` kiêm reviewer/publisher đã được người dùng chỉ định; quyền/scope thực tế và hai sự kiện riêng vẫn phải kiểm tại runtime. Tài liệu D07 cũ ghi “chưa gán người” là trạng thái lịch sử của ngày thiết kế, không dùng để phủ nhận quyết định sau đó.

## 13. Truy ngược lỗi thiết kế và tài liệu

| Nguyên nhân đã ghi | Biện pháp trong thiết kế này | Phần chưa được nhận là đã đóng |
|---|---|---|
| [DF-027](<../architecture/DESIGN_FLAWS.md#df-027--nguồn-công-bố-quy-tắc-được-duyệt-và-quyền-dùng-bị-trộn>) | Tách technical freshness, completeness, legal/call validity, review, release và D07 theo outcome | Chưa có pipeline mới, nguồn đầy đủ hoặc phát hành policy mới |
| [DF-033](<../architecture/DESIGN_FLAWS.md#df-033--knowledge-graphpolicy-dùng-chung-id-và-enum-cho-các-khái-niệm-khác-nhau>) | Identity/times/typed rule-claim-relations, per-item binding, complete applicability dependencies | Chưa kiểm runtime schema/adapters/migration mới |
| [DF-029](<../architecture/DESIGN_FLAWS.md#df-029--quyền-output-không-theo-quyền-input-hiện-hành>) | Rights/READ tại ingest, reuse, context, publication và render; cache không cấp quyền | Chưa chứng minh mọi derivative/new adapter |
| [DF-034](<../architecture/DESIGN_FLAWS.md#df-034--prompt-decoration-thay-đổi-nhưng-hợp-đồng-cache-không-cùng-phiên-bản>) | Exact versioned manifest/builder và compatibility registry; không fuzzy recovery | Chưa có hợp đồng mới được code/đối soát |
| [DF-041](<../architecture/DESIGN_FLAWS.md#df-041--constructor-startup-kiêm-migration-nghiệp-vụ>) | Operator schema riêng, backfill nghiệp vụ riêng, managed startup không tác dụng | Không hứa toàn constructor legacy đã loại backfill |
| [DF-044](<../architecture/DESIGN_FLAWS.md#df-044--đầu-vào-gốc-chưa-được-lưu-bền-trước-dispatch>) | Durable public-job input/authorization manifest và same Gateway receipt trước paid stage | Chưa thử crash/egress của capability mới |
| [DF-048](<../architecture/DESIGN_FLAWS.md#df-048--sắp-xếp-resolution-theo-đồng-hồ-và-uuid-thay-cho-nhân-quả>) | Predecessor/sequence/CAS cho relation/proposal/head; timestamp không chọn truth | Chưa có phép thử same-time/branch cho pipeline mới |
| [DF-049](<../architecture/DESIGN_FLAWS.md#df-049--schema-của-operator-và-runtime-chưa-có-một-hợp-đồng-tương-thích>) | Exact managed schema/ledger và upgrade chain trước cutover | Chưa có DDL/operator/runtime proof của bộ schema mới |

Nguồn đọc để thiết kế: [retrieval và vòng đời tri thức 19/10](<../core-policy-detailed-design-2026-10-19/03_Retrieval_va_vong_doi_tri_thuc.md>), [D07-A đã chốt](<../core-policy-detailed-design-2026-10-19/12_Chinh_sach_nguon_va_phat_hanh_D07.md>), [schema V17 đóng gói](<../../../REFERENCE_LINKS.md#ref-0002>), [catalog Hà Nội](<../../../REFERENCE_LINKS.md#ref-0003>), [scheduler hiện có](<../../../REFERENCE_LINKS.md#ref-0004>), [catalog xuất khẩu](<../../../REFERENCE_LINKS.md#ref-0005>). Đọc mã/tài liệu chỉ chứng minh hiện trạng kỹ thuật, không thay thẩm định nguồn pháp luật. Không có network, provider call, thay MAIN hoặc migration trong công việc thiết kế này.
