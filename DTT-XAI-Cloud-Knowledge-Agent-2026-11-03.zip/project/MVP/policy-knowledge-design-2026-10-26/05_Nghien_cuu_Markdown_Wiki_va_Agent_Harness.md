# Markdown + wiki và agent harness cho DTT XAI

**Bản nghiên cứu 1.1 · 26/10/2026 · P06 đã được người dùng duyệt về định hướng; chưa triển khai.**

[Quyết định P06 và cập nhật liên quan](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) ghi nhận lời đồng ý và việc đồng bộ các tài liệu 00–03. Các phần “đề xuất” dưới đây giữ tính chất thiết kế/POC; không đồng nghĩa dependency, capability, ngân sách hoặc kết quả đo đã được chấp thuận/vận hành.

Phụ lục của [đề nghị thiết kế hệ thống tích lũy tri thức](<00_De_nghi_phe_duyet.md>). Nghiên cứu tài liệu công khai, đối chiếu thiết kế và sổ DF; chưa cài framework, chạy thử model, sửa app hoặc nhập tri thức. Các nhận định “nên”, hợp đồng và lộ trình dưới đây là đề xuất của DTT XAI, không phải chức năng đã triển khai.

## 1. Khuyến nghị để ra quyết định

**Nên dùng Markdown và cách tổ chức kiểu Wikipedia làm lớp tri thức được biên soạn, có liên kết và tích lũy qua thời gian. Kết hợp với SQL quản lý bản chuẩn, bằng chứng, quyền và phát hành.**

Wiki cần có giá trị vượt việc xuất dữ liệu ra `.md`: nó giữ những tổng hợp đã được làm, quan hệ giữa chủ đề, câu hỏi còn thiếu, mâu thuẫn và hướng dẫn thực hành. Các lần nghiên cứu tiếp theo sửa đúng phần bị ảnh hưởng, thay vì luôn đọc lại và ghép mọi tài liệu từ đầu. Tuy nhiên, câu văn tổng hợp không được tự trở thành quy tắc xác định doanh nghiệp có đủ điều kiện hưởng chính sách.

Đề xuất kiến trúc bổ sung:

| Thành phần | Lựa chọn cho DTT XAI | Lý do |
|---|---|---|
| Tri thức người và agent cùng đọc | Wiki tiếng Việt, nội dung Markdown, trang nhỏ theo chủ đề, dẫn nguồn và liên kết | Giữ lại công nghiên cứu; chuyên gia dễ kiểm và sửa |
| Nơi giữ bản chuẩn | SQL lưu cả nội dung từng revision Markdown và các bản ghi có cấu trúc | Một thẩm quyền ghi; không tạo hai bản chuẩn ở SQL và thư mục |
| Nguồn gốc | Bản gốc bất biến, extraction có phiên bản, claim/rule và bằng chứng | Đọc lại được nguyên bản; kiểm sửa đổi và ngoại lệ |
| Tìm kiếm | FTS5 + từ đồng nghĩa/thuật ngữ + liên kết có kiểu trên SQL | Dùng ngay lõi đã chọn, đo thiếu sót trước khi thêm embedding |
| Điều phối | Giữ LangGraph; bổ sung harness có công cụ và phạm vi hữu hạn | Giữ mạch công việc, quyền, receipt và kiểm soát phí chung |
| Framework bổ sung | Thử nghiệm Deep Agents cho worker biên soạn sau khi đạt điều kiện tích hợp | Có thể giảm công xây công cụ đọc/ghi ngữ cảnh; chưa có bằng chứng cần thay runtime |
| Định dạng trao đổi | Markdown chuẩn; khảo sát ánh xạ Open Knowledge Format (OKF) | Giảm phụ thuộc công cụ; thuận lợi khi tích hợp đối tác |
| Phần chưa cần | MediaWiki server, graph/vector DB riêng, agent tự sửa rồi tự phát hành luật | Chưa giải quyết khoảng trống quan trọng nhất: đủ nguồn, đúng phiên bản, đúng duyệt |

**Điểm cần điều chỉnh trong thiết kế trước:** nói “Markdown để đọc/xuất” là chưa khai thác hết mô hình wiki. Nên bổ sung một sản phẩm tri thức tồn tại lâu dài, được người/agent biên soạn và bảo toàn từng bản. SQL vẫn giữ bản chuẩn của sản phẩm đó. Hai lựa chọn này bổ trợ nhau.

## 2. Nghiên cứu cho thấy gì, và chưa chứng minh được gì?

### 2.1. LLM Wiki là một pattern đáng áp dụng

Karpathy mô tả ba lớp: nguồn gốc bất biến, wiki Markdown được LLM duy trì và quy ước vận hành; ba hoạt động chính là nhập nguồn, hỏi và rà chất lượng. Đây là ý tưởng cho kho tri thức, chưa phải hệ thống chính sách nhiều doanh nghiệp có cơ chế duyệt. [LLM Wiki — bài gốc](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f).

**Đánh giá cho XAI:** lấy nguyên tắc tổng hợp một lần và tiếp tục tích lũy. Điều chỉnh quyền “LLM sở hữu lớp wiki”: agent chỉ sửa nháp đúng phạm vi; chuyên gia quyết định nội dung nào được phát hành để tư vấn. Không đưa kết luận riêng của một doanh nghiệp vào wiki công khai.

Nhận xét trong bài rằng RAG thường phải ghép lại kiến thức là động cơ của tác giả, không phải định nghĩa rằng mọi hệ thống RAG đều không có trí nhớ. Ta có thể kết hợp truy xuất với wiki đã biên soạn; đây không phải lựa chọn loại trừ.

### 2.2. “Kiểu Wikipedia” là cách tổ chức, không bắt buộc một công nghệ lưu

MediaWiki lưu mỗi lần sửa thành revision trong cơ sở dữ liệu, có identity và metadata. Vì vậy, dùng SQL làm bản chuẩn hoàn toàn phù hợp với trải nghiệm wiki. [MediaWiki: Revision](https://www.mediawiki.org/wiki/Manual:Revision).

Obsidian dùng tệp Markdown cục bộ và cache metadata để phục vụ những chức năng như đồ thị; cache có thể dựng lại. [Obsidian: cách lưu dữ liệu](https://obsidian.md/help/Files%2Band%2Bfolders/How%2BObsidian%2Bstores%2Bdata).

**Đánh giá cho XAI:** học trang chủ đề, backlinks, lịch sử, diff, nguồn và liên kết ổn định. Chủ cơ sở vẫn dùng chat trên mobile; không phải học một ứng dụng wiki. Chuyên gia có workbench xem wiki và diff. Obsidian có thể là công cụ xem bản xuất công khai; chưa cần plugin, đồng bộ cloud hay quyền ghi thẳng vào dữ liệu sản xuất.

### 2.3. Không có cơ sở khẳng định cứ dùng thư mục Markdown là trả lời tốt hơn

Nghiên cứu *Filesystem-Based Memory for LLM Agents* khảo sát tổ chức kho, công cụ và năng lực agent. Kết quả cho thấy lợi ích tìm kiếm phụ thuộc dữ liệu, còn chất lượng trả lời không có một cấu trúc luôn thắng; tổ chức kho cũng có thể suy giảm khi tích lũy. Đây là preprint và benchmark ngoài nghiệp vụ Hà Nội. [Bài nghiên cứu, toàn văn](https://arxiv.org/html/2607.26637v1).

**Đánh giá cho XAI:** không hứa “gần như miễn phí bảo trì”, tiết kiệm một tỷ lệ cố định hoặc tăng độ đúng chỉ nhờ Markdown. Phải đo cả công xây wiki, duy trì khi nguồn đổi và chất lượng trả lời. Kho cần lint và người chịu trách nhiệm, không chỉ thêm một prompt “hãy ghi nhớ”.

### 2.4. Harness quyết định agent làm việc ra sao

Anthropic dùng thiết lập môi trường, tiến bộ từng phần và artifacts bàn giao để agent tiếp tục qua nhiều phiên; compaction một mình không đủ. Bối cảnh bài là phát triển phần mềm. [Effective harnesses for long-running agents](https://www.anthropic.com/research/effective-harnesses-for-long-running-agents).

Tài liệu context engineering khuyến khích lấy đúng ngữ cảnh khi cần, kết hợp ghi chú thay vì nạp mọi thứ vào prompt. [Effective context engineering](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents).

**Đánh giá cho XAI:** Markdown là một loại bộ nhớ. Harness còn phải điều khiển kế hoạch, công cụ, ngữ cảnh, giới hạn, tiếp tục công việc, kiểm tra kết quả và bàn giao cho người duyệt. Viết `AGENTS.md` hoặc lưu toàn bộ chat không thay được những phần đó.

## 3. Tách năm loại bộ nhớ trước khi chọn công cụ

| Loại | Ví dụ | Nơi giữ bản chuẩn / quyền sửa |
|---|---|---|
| Nguồn và tri thức domain | Văn bản Hà Nội, khái niệm, hướng dẫn, quy tắc | Nguồn bất biến + SQL revision/claim/rule/release; agent đề xuất, người có quyền duyệt |
| SSOT doanh nghiệp | Cơ sở, sản phẩm, khối lượng tịnh, năng lực, dữ kiện được xác nhận | Lõi SSOT hiện có; nhân viên đề xuất theo quyền, chủ xác nhận |
| Lịch sử tác nghiệp riêng | Câu hỏi Trà Sen, quyết định, kết quả, receipt | Workspace/enterprise/owner đúng phạm vi, giữ lineage và READ hiện hành |
| Bộ nhớ làm việc | Kế hoạch đang chạy, nháp, scratch, checkpoint | Theo operation/intake/revision; không tự nâng thành tri thức được duyệt |
| Quy trình cho agent | Cách tra chính sách, chuẩn trích dẫn, hướng dẫn viết nháp | Cấu hình/skill do DTT quản lý, có phiên bản và kiểm thử; tài liệu nguồn không được sửa |

Một câu “chị muốn xuất khẩu sang Mỹ” là intent, không phải chứng cứ sản phẩm đạt điều kiện. Một câu trả lời hay của Claude là artifact riêng, không tự thành quy tắc dùng chung. Một ghi chú scratch bị nén không thay raw assertion hoặc quyết định SSOT.

LangGraph phân biệt checkpoint theo thread với store dùng qua nhiều thread. Cả hai vẫn cần hợp đồng nghiệp vụ của ứng dụng; chọn store lâu dài không tự cung cấp phê duyệt pháp lý hoặc quyền doanh nghiệp. [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence).

## 4. So sánh phương án lưu tri thức

Đây là đánh giá kiến trúc cho phạm vi XAI, không phải benchmark định lượng.

| Phương án | Điểm mạnh | Điểm yếu trong use case này | Kết luận |
|---|---|---|---|
| Thư mục `.md` + Git là toàn bộ hệ thống | Nhẹ, đọc được, diff và mang đi dễ | ACL nhiều doanh nghiệp, nhiều người ghi, transaction, hiệu lực và receipt phải tự xây; Git commit không thay review đúng phạm vi | Hợp kho cá nhân/public docs; chưa phù hợp làm toàn bộ lõi |
| Cài MediaWiki làm nền chính | Sẵn trải nghiệm chỉnh sửa, trang liên kết, revision | Thêm một hệ thống quyền/vận hành và tích hợp; vẫn phải xây rule, SSOT, Gateway | Chưa có lý do chuyển app sang nền này |
| Chỉ SQL/chunks + FTS | Quản lý dữ liệu và quyền rõ, ít thành phần | Công tổng hợp có thể mất trong chat; chuyên gia khó đọc toàn cảnh nếu chỉ có bảng | Giữ làm lõi, bổ sung wiki |
| SQL + wiki Markdown được quản trị | Dễ đọc và tích lũy; một nơi giữ bản chuẩn; có thể xuất mở | Cần hợp đồng page revision, evidence links, compiler và review | **Đề xuất lựa chọn** |
| Vector DB làm kho tri thức chính | Tìm tương đồng ngữ nghĩa | Vector không biểu diễn đủ điều kiện/ngoại lệ/quyền; sửa/xóa/phiên bản vẫn cần lõi khác | Chỉ cân nhắc làm index bổ sung khi đo thấy cần |
| Knowledge graph riêng hoặc GraphRAG toàn kho | Có thể giúp khám phá quan hệ và tổng quan lớn | Chi phí xây/cập nhật; graph do AI trích không mặc nhiên đúng, không thay rule được duyệt | Graph có kiểu trên SQL trước; chưa thêm sản phẩm riêng |

Microsoft GraphRAG phân biệt local search kết hợp graph và raw chunks, global search trên community reports theo map-reduce và các phương pháp khác. Đây là kỹ thuật truy xuất, không phải cơ chế phê duyệt chính sách. [GraphRAG query overview](https://microsoft.github.io/graphrag/query/overview/).

### Khi nào cần embedding?

Wiki Markdown **không bắt buộc embedding**. Giai đoạn đầu, tìm theo từ khóa, alias, thuật ngữ Việt–Anh và liên kết có kiểu có thể là baseline hợp lý. Bắt đầu bằng corpus thật và các câu tự nhiên từng làm app sai.

Chỉ đề xuất thêm embedding khi bộ đo cho thấy FTS/alias/links bỏ sót đáng kể câu diễn đạt khác, và semantic retrieval cải thiện coverage/citation với chi phí, quyền và freshness chấp nhận được. Khi đó phải duyệt model embedding, nơi xử lý, egress, giá, lưu vector và xóa/invalidate. Không mặc định gửi hồ sơ riêng đến một API embedding ngoài hệ thống.

Vector là index có thể dựng lại; không là bản chuẩn của claim, quyền hay hiệu lực. Chưa đủ bằng chứng chọn model embedding cụ thể hoặc quyết định cần database vector riêng.

## 5. Nghiên cứu framework và lựa chọn harness

### Deep Agents

Deep Agents cung cấp mặt công cụ filesystem với backend có thể thay thế. Mặc định file nằm trong state theo thread; backend lâu dài là lựa chọn khác. Vì vậy, “có file tools” không đồng nghĩa có knowledge base dùng chung đã bền vững. [Backends](https://docs.langchain.com/oss/python/deepagents/backends).

Memory của Deep Agents có thể được nạp đầu phiên hoặc đọc khi cần; có cơ chế sửa và consolidation tùy cấu hình. [Memory](https://docs.langchain.com/oss/python/deepagents/memory).

Quyền filesystem tích hợp không bao phủ custom tools/MCP hoặc arbitrary execution trong sandbox. [Permissions](https://docs.langchain.com/oss/python/deepagents/permissions).

**Đánh giá:** ứng viên phù hợp để thử cho worker biên soạn nháp, vì có thể làm backend ảo trỏ về service XAI. Không bật thẳng local filesystem/shell, memory tự ghi xuyên doanh nghiệp hoặc consolidation nền. Cần chứng minh mọi đường model — kể cả lập kế hoạch, tóm tắt ngữ cảnh, worker phụ và consolidation — qua cùng Model Gateway. Adapter không chỉ đổi `base_url`; phải hỗ trợ đúng tool-call/streaming/schema và hạch toán từng dispatch.

### OpenWiki

OpenWiki của LangChain duy trì Markdown wiki, có MCP đọc/tìm và Grounded Claims theo bằng chứng phiên bản. Grounded Claims hiện tập trung repository code; facts từ connector chưa được tuyên bố có cùng cơ chế. Native CLI có xử lý lỗi provider qua LangChain. [Repository và giới hạn hiện hành](https://github.com/langchain-ai/openwiki).

**Đánh giá:** đáng học và kiểm tra tái sử dụng schema/validator, page jobs, claim sidecars, tìm kiếm chọn lọc và export. Chưa dùng nguyên CLI làm policy ingestion production: bằng chứng pháp lý, quyền nguồn, hiệu lực và review khác code repository; đường gọi model và retry phải qualification theo D06. Không nhập tài liệu thật hoặc cài chạy thử trong đợt nghiên cứu này.

### Claude Agent SDK

Agent SDK đóng gói vòng lặp, công cụ và quản lý ngữ cảnh của Claude Code, khác Client SDK gọi API trực tiếp. [SDK overview](https://code.claude.com/docs/en/agent-sdk/overview). Vòng lặp có thể tự thực hiện nhiều round trip; giới hạn tiền SDK xét theo usage sau phản hồi và có thể vượt ngưỡng bởi lượt đang chạy. [Agent loop và budget headroom](https://code.claude.com/docs/en/agent-sdk/agent-loop).

**Đánh giá:** có ích cho tác vụ nghiên cứu/coding độc lập được kiểm soát, nhưng thay backend XAI sẽ phát sinh một vòng điều phối và authority phí cần hợp nhất. Chưa có bằng chứng tích hợp từng model call với Gateway hiện có. Không dùng hạn mức SDK như thay thế D06 hoặc coi đây là trần hóa đơn tuyệt đối.

### Bảng quyết định

| Lựa chọn | Vai trò hợp lý | Điều kiện / quyết định đề xuất |
|---|---|---|
| **LangGraph + service nghiệp vụ hiện có** | Runtime chính, state machine hữu hạn, chờ người duyệt | Giữ; bổ sung công cụ/hợp đồng, không viết lại từ đầu |
| **Deep Agents qua adapter** | Worker nghiên cứu và biên soạn nháp trong graph lớn | POC sau; chỉ nhận nếu quyền, mọi model call, chi phí và recovery được kiểm chứng |
| **OpenWiki** | Tham khảo/tái sử dụng bộ phận tạo và kiểm wiki | Thử trên corpus công khai sau duyệt; không mặc định lấy toàn runtime |
| **Claude Agent SDK** | Môi trường nghiên cứu có phạm vi riêng | Chưa thay runtime chính; không tạo transport/ledger song song |
| **GraphRAG** | Retrieval khi corpus và kiểu câu hỏi cần | Không phải harness; chưa đưa vào K1 |

**Không cần một agent riêng cho mỗi trang.** Tách vai trò logic — tìm nguồn, trích, biên soạn, kiểm căn cứ — trước; có thể chạy tuần tự bằng một worker có giới hạn. Chỉ thêm xử lý song song khi có bằng chứng lợi ích và reservation ngân sách tổng trước dispatch. Agent thứ hai dùng cùng model không được coi là chuyên gia phê duyệt độc lập.

## 6. Kiến trúc đề xuất: wiki được quản trị

```mermaid
flowchart TD
  A[Nguồn chính thức / manual / MCP được phép] --> B[Bản gốc bất biến + extraction có phiên bản]
  B --> C[Đề xuất claim / rule / trang wiki]
  C --> D[Kiểm cấu trúc + bằng chứng + phạm vi]
  D --> E[Chuyên gia xem diff và quyết định]
  E --> F[SQL: revision chuẩn + quyết định + release manifest]
  F --> G[FTS / liên kết SQL / bản xuất Markdown]
  G --> H[Retrieval theo intent và quyền hiện hành]
  F --> H
  B --> H
  I[SSOT đúng doanh nghiệp và sản phẩm] --> J[Đánh giá riêng theo từng mục tiêu]
  H --> J
  J --> K[Chat tiếng Việt: kết luận, việc làm, nguồn]
  K -. ghi nhận khoảng trống, không tự phát hành .-> C
  B -. nguồn đổi: gate phần phụ thuộc và đưa vào hàng rà .-> F
```

### 6.1. Một thẩm quyền ghi, nhiều hình thức đọc

SQL giữ **nguyên nội dung Markdown từng revision** cùng hash, parent revision, người/operation đề xuất, dependencies và quyết định. Các claim/rule/evidence có cấu trúc cũng ở SQL; quan hệ giữa body và claim refs phải được kiểm trước phát hành. Không chỉ lưu một đường dẫn tới tệp có thể bị agent sửa sau duyệt.

Thư mục `.md`, mục lục, backlinks, graph và FTS là projection từ revision/release cụ thể. Dựng lại chúng không gọi model. Ngược lại, **không thể xóa nội dung wiki chuẩn rồi hứa dựng lại y hệt từ raw**: sự tổng hợp của người/AI là một sản phẩm cần lưu bền.

Chuyên gia có thể sửa Markdown trong workbench, hoặc nhập file thành đề xuất với `base_revision` và CAS. Không watcher hai chiều tự ghi đè SQL khi file thay đổi. Agent không ghi trực tiếp bảng release hoặc sửa file live để lách review.

K1 giữ lựa chọn SQLite BLOB và hai UoW của [thiết kế dữ liệu](<02_Du_lieu_pipeline_va_truy_xuat.md>). Markdown xuất ra disk không nằm trong transaction SQL: outbox/materializer ghi temp rồi thay bản projection; hỏng giữa chừng có thể dựng lại. Retrieval kiểm SQL manifest và hash; projection trễ không cấp quyền dùng revision cũ. Không thêm lời hứa “SQL và filesystem cùng atomic”.

### 6.2. Dạng trang và liên kết

| Dạng trang | Nội dung | Ranh giới |
|---|---|---|
| Chủ đề/khái niệm | Ý nghĩa, thuật ngữ Việt–Anh, liên kết liên quan | Không tự là rule đánh giá đủ điều kiện |
| Chính sách/chương trình | Mục tiêu, đối tượng, bộ văn bản, điều kiện, khoảng trống | Phân biệt văn bản, phiên bản, chương trình và đợt nhận |
| Quy trình/hướng dẫn | Việc chuẩn bị, biểu mẫu, đầu mối, kênh chính thức | Không hứa đã nộp hoặc được tiếp nhận |
| Tổng hợp/so sánh | Điểm giống/khác, trường hợp áp dụng, nguồn còn thiếu | Mỗi nhận định vật chất phải về được claim/evidence |
| Vấn đề chưa giải quyết | Mâu thuẫn, nguồn chưa đủ, câu hỏi cần chuyên gia | Là hàng việc biên soạn, không đưa thành kết luận chắc chắn |

Trang có ID ổn định; title/slug có thể đổi. Dùng Markdown links chuẩn cho trao đổi. Có thể hỗ trợ `[[wikilink]]` trong editor nhưng chuẩn hóa qua ID resolver. Heading và số dòng có thể đổi, nên trích dẫn pháp lý dùng rendition/extraction/span/claim version, không chỉ URL và anchor heading.

Graph tách hai nhóm: **liên kết điều hướng** và **quan hệ nghiệp vụ có kiểu**. “Có nhắc tới” khác “được sửa đổi bởi”, “đòi hỏi dữ kiện”, “được chứng minh bởi” hoặc “ngoại lệ của”. Link tự sinh chưa được duyệt không tự tạo cạnh rule. Không thay causal chain bằng sắp theo timestamp+UUID.

### 6.3. Hợp đồng đề xuất cho một revision wiki

Đây là cấu trúc logic để bổ sung thiết kế, không phải tên bảng/API đã tồn tại.

| Nhóm | Thông tin bắt buộc cho bản có thể phát hành |
|---|---|
| Identity | `page_id`, `revision_id`, `parent_revision_id`, schema/recipe version, body hash |
| Phạm vi | Public domain/jurisdiction/market/topic; actor và quyền review đúng scope |
| Nội dung | Body Markdown nguyên bản, ngôn ngữ, alias, bản gốc/bản dịch liên kết |
| Căn cứ | Claim/rule version refs, evidence spans, source edition/extraction refs, dependencies |
| Thẩm quyền | Decision/release refs exact revision+hash; không tin status do file tự khai |
| Thời gian | Thời điểm biết/quan sát, hiệu lực áp dụng, đợt nhận; theo contract nền |
| Vận hành | Command/operation receipt, provenance, lint findings, các khoảng trống chưa giải quyết |

Không tạo enum freshness thứ hai cho wiki. Tiếp tục dùng **`policy-freshness-decision/1`** ở tài liệu 02; trạng thái biên soạn, trạng thái job, quyền READ và quyết định dùng hiện hành là các trục riêng.

## 7. Open Knowledge Format và khả năng tích hợp Google

OKF v0.2 dùng Markdown/frontmatter, có trường provenance và lifecycle; trust metadata chỉ mang tính tín hiệu, không phải ACL. Thiếu status có mặc định `stable`; broken links được dung nạp. [Đặc tả OKF](https://github.com/GoogleCloudPlatform/knowledge-catalog/blob/main/okf/SPEC.md). Repository chứa đặc tả ghi rõ các nội dung là công cụ/mẫu, không phải sản phẩm Google chính thức. [Phạm vi repository](https://github.com/GoogleCloudPlatform/knowledge-catalog).

**Đề xuất cho XAI:** thiết kế export/import có ánh xạ OKF, nhưng giữ contract nghiêm hơn trong lõi. File nhập thiếu review/release chỉ là candidate, dù có `status: stable` hoặc `verified: human:...`. Không lấy mặc định của định dạng mở làm quyền phát hành. Một trường `stale_after` không thay kiểm hiệu lực luật, bộ căn cứ và đợt tiếp nhận.

Phần mở rộng XAI cần giữ ID/version/evidence/release và scope; không thay đổi ý nghĩa các trường chuẩn. Trước khi cam kết tương thích phải pin phiên bản spec, viết conformance/round-trip tests và kiểm riêng consumer. **Có cùng định dạng không chứng minh Gemini Business đã có API nhập trực tiếp, giữ được ACL hoặc dùng đúng cơ chế review của XAI.**

Đây là hướng bổ trợ Google/Viettel hợp lý: DTT sở hữu kho tri thức Việt Nam có căn cứ và quản trị, phục vụ qua API/MCP được cấp quyền; model/provider có thể thay sau qualification. Không gửi cả wiki riêng hoặc bản gốc tài chính sang partner để đổi lấy khả năng đọc Markdown.

## 8. Harness nghiệp vụ cần vận hành như thế nào?

### 8.1. Hai vòng làm việc khác nhau

**Vòng xây kho công khai:**

1. Xác định nhiệm vụ và source scope; lấy registry/edition/dependencies hiện hành.
2. Tải có giới hạn, lưu bản gốc; parser local trích đúng loại tài liệu.
3. Xác định phần thực sự đổi và các trang/claim/rule phụ thuộc; không biên soạn lại mọi trang.
4. Đề xuất nội dung wiki/claim/rule kèm chứng cứ, chỗ thiếu và mâu thuẫn. Nếu cần model, chờ Gateway có quyền public-domain và ngân sách riêng.
5. Kiểm xác định: schema, link, quote/span/hash, scope, coverage; kiểm chuyên môn: điều kiện, ngoại lệ, diễn giải. Quote khớp không đủ chứng minh kết luận đúng.
6. Người có quyền xem diff, quyết định exact revision; phát hành qua service chung và outbox.
7. Lint và theo dõi thay đổi tiếp; ghi rõ việc nào chưa được duyệt, không giả thành published.

**Vòng phục vụ doanh nghiệp:**

1. Lấy nguyên câu hỏi, tác vụ đang chọn và context có quyền; tách các mục tiêu theo intent.
2. Tìm wiki để định hướng, truy xuống claim/rule và nguồn chính xác; kiểm READ/release/freshness ở server.
3. Đối chiếu SSOT đúng doanh nghiệp/sản phẩm/phiên bản. Chỉ hỏi các dữ kiện còn thiếu; dữ kiện chat mới vào nháp, không ghi đè SSOT.
4. Lập coverage theo từng mục tiêu: đủ căn cứ, cần dữ kiện, thiếu nguồn, ngoài phạm vi. Wiki không được che việc kho chưa có luật cần thiết.
5. Trả kết luận đầu tiên, sau đó việc cần làm và nguồn; giữ phần hợp lệ khi phần khác thiếu căn cứ theo D07-A.
6. Lưu manifest/receipt và kết quả riêng. Ghi nhận nhu cầu bổ sung kho bằng mô tả đã loại dữ liệu riêng, không tự đưa chat doanh nghiệp vào public wiki.

### 8.2. Công cụ có ranh giới

Các tên dưới là đề xuất capability, chưa đăng ký endpoint:

| Capability | Được làm | Không được làm |
|---|---|---|
| `knowledge.search/read` | Tìm/đọc bản và snippets có quyền, trả refs và gate | Tự refresh AI, trả lộ title từ nguồn bị revoke |
| `knowledge.evidence` | Đọc bằng chứng đúng revision và phạm vi | Tin câu trích nằm trong wiki như bản gốc |
| `knowledge.propose` | Lưu nháp với base revision/operation/CAS | Tự cấp review hoặc publication |
| `knowledge.review/publish` | Service kiểm actor/scope, exact hash và dependencies | Để model tự gọi với quyền chuyên gia chung |
| `enterprise.context` | Lấy SSOT/nháp đúng scope và dữ kiện có quyền | Cho worker public-domain duyệt mọi hồ sơ |
| `model.dispatch` | Đi qua consent/D06/egress/manifest/reservation chung | Gọi SDK/provider khác để “chỉ tóm tắt” ngoài hạn mức |

Backend filesystem ảo có thể cho agent thấy `/knowledge/released/` chỉ đọc, `/work/<operation>/` để nháp. Path là hình thức thao tác, **không thay ACL**. Mỗi request gắn actor/enterprise/workspace/intake/revision tại server; không nhận path hoặc tenant do model đưa như quyền có sẵn. MCP cũng gọi cùng service, không có business logic thứ hai.

Public-domain job dùng subject/scope của public domain đã thiết kế; không giả doanh nghiệp Trà Sen để có FK hoặc mượn ngân sách tester. K1 không mở đường đưa private knowledge lên public. Skills do DTT phát hành tách khỏi nguồn/wiki; tài liệu có câu “bỏ qua kiểm duyệt” vẫn chỉ là dữ liệu.

## 9. Cache, refresh và việc không được tự gọi AI

| Lớp | Khóa/điều kiện reuse | Khi có thay đổi |
|---|---|---|
| Bản tải nguồn | Source identity + observation + content hash; HTTP validator chỉ hỗ trợ tải | Lưu observation mới; giữ bản gốc cũ; đánh giá đủ bộ căn cứ/hiệu lực riêng |
| Extraction | Rendition hash + parser/version/options | Tạo extraction mới, không sửa bytes hoặc spans cũ |
| Wiki đã biên soạn | Exact revision + claim/rule/evidence dependencies + recipe/release | Đưa phần phụ thuộc vào hàng rà; không tự viết lại khi có người mở trang |
| FTS/backlinks/graph | Revision/release projection version | Dựng lại có tính xác định, không cần model |
| Kết quả riêng doanh nghiệp | Manifest của request, SSOT/input/release refs và READ hiện hành | Giữ snapshot lịch sử; báo cần rà lại cho đánh giá mới, không tự chạy lại có phí |

Nguồn thay đổi: gate đọc hiện hành phải có hiệu lực trước khi worker kịp xây lại wiki. Bản mới chưa duyệt không thay bản cũ thành “luật mới đã chốt”. Bản cũ có thể còn đọc như lịch sử nếu quyền cho phép, nhưng không được dùng làm kết luận hiện hành khi gate từ chối. Dừng đúng outcome, không nhất thiết xóa toàn báo cáo.

Đọc wiki, tìm kiếm, status, mở lịch sử, refresh trình duyệt, xây lại index hoặc resume để đọc receipt **không gọi AI**. Resume worker có thể chỉ tiếp tục phần xác định; dispatch mới phải là tác vụ được phép riêng. Trạng thái gọi model không rõ thì giữ unknown và đối soát, không coi node replay là quyền retry.

## 10. Áp dụng vào ca Trà Sen và lỗi đã gặp

### Câu hỏi chính sách có hai nhu cầu

“Chị muốn hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách.”

- Intent lưu đủ hai mục tiêu; wiki có thể dẫn đến chủ đề thị trường và đào tạo. Không chọn một “gói số hóa kho” thay cho cả câu.
- Từng mục tiêu đi tới nguồn/rule/đợt riêng. Nếu kho chưa đủ nguồn đào tạo, trả rõ khoảng trống đó; không có trang wiki thì lập nhu cầu nghiên cứu, không suy rằng không tồn tại chính sách.
- SSOT Trà Sen chỉ tham gia đánh giá riêng. Doanh nghiệp B dùng cùng trang public nhưng context và kết luận của B riêng.
- Phần hỗ trợ kiến nghị có thể lập nháp đúng nhu cầu; chưa có API iHanoi thì chưa gửi. Trang hướng dẫn không là biên nhận tiếp nhận.

### Câu xuất khẩu: FDA, nhãn và ba việc đầu tiên

Wiki nên có các trang nghĩa vụ và liên kết theo thị trường/nhóm hàng, thay vì một trang “xuất khẩu Mỹ” quá lớn. Kế hoạch đối chiếu ma trận nghĩa vụ để không rơi mất prior notice/nhãn hoặc trách nhiệm nhập khẩu khi có liên quan. Mỗi kết luận vẫn cần nguồn và điều kiện thực; tài liệu nghiên cứu này không xác nhận luật hiện hành hoặc khẳng định mọi trường hợp áp dụng.

“Ba việc đầu tiên” là yêu cầu về đầu ra hành động, không phải một mục “cần làm rõ” để loại cả báo cáo. Ba việc phải được tạo từ intent, nghĩa vụ đã có căn cứ, mức thiếu dữ kiện và khả năng thực hiện; không copy ba việc cố định từ wiki. Nếu chỉ có đủ căn cứ cho hai việc, nói rõ giới hạn thay vì bịa việc thứ ba.

### Dữ kiện sản phẩm và SSOT

Wiki không sửa lỗi “200 g” bị hiểu thành bao bì hoặc trùng sản phẩm. Những lỗi đó thuộc identity/domain validation/nháp/confirmation. Markdown profile chỉ là projection có revision, không đường ghi khác. Quy tắc field qualifier và registry chung của workspace vẫn giữ nguyên; casefold để phân loại không được đổi key/value hoặc mở exact-field permission.

## 11. Các design pattern cần dùng và đánh đổi

| Pattern | Áp dụng cụ thể | Đánh đổi/cửa kiểm |
|---|---|---|
| CQRS / Materialized View | SQL command authority; wiki export/search/backlinks là read projection | Có độ trễ projection, nên gate hiện hành không chỉ dựa index |
| Repository + Ports and Adapters | Tool/MCP/filesystem ảo gọi cùng knowledge service | Phải kiểm mọi tool, không chỉ HTTP |
| Immutable Revision + Provenance | Giữ body, nguồn, extraction, claim và quyết định exact version | Tốn lưu trữ; cần retention phù hợp, không gom lịch sử tùy tiện |
| Optimistic Concurrency | Nháp/edit/review dùng base revision/hash; concurrent edit không ghi đè | Người dùng cần diff/merge rõ, không tự chọn bản “mới nhất” |
| UoW + Outbox | Commit revision/quyết định/event rồi materialize có thể replay | Không tuyên bố atomic hai hệ lưu; ca crash là điều kiện nghiệm thu |
| Dependency Graph + Invalidation | Source/claim đổi xác định các phần cần rà | Cạnh sai/mất làm cache sai; phải test cả thêm/xóa nguồn và revoke |
| Capability Security / Reference Monitor | Kiểm current READ cho nội dung, metadata, snippets và export | File permissions và owner artifact không đủ |
| State Machine + Human Gate | Agent đề xuất; review/publication có phạm vi | Chờ người là trạng thái thật, không mô phỏng có chuyên gia đang xử lý |
| Bounded Agent Loop | Giới hạn mục tiêu/công cụ/context/dispatch, dừng có lý do | Ít “tự do” hơn coding agent tổng quát nhưng kiểm soát được nghiệp vụ |

Không cần event-sourcing toàn bộ hệ thống để có audit và causal decisions. Tái sử dụng raw assertions, quyết định, receipt và chuỗi hiệu lực đã thiết kế; không tạo một “truth log” tự do bằng Markdown cạnh SQL.

## 12. Rủi ro thiết kế cần chặn ngay từ hợp đồng

Các mục dưới là phân tích rủi ro cho thiết kế mới, **không phải sự cố runtime mới đã được tái hiện**.

| Rủi ro | Cơ chế | Cách chặn / liên hệ sổ DF |
|---|---|---|
| Hai bản chuẩn | File đã sửa, SQL vẫn cũ hoặc ngược lại | Một authority, CAS import/projection; DF-013/014/033 |
| Tự dẫn lại nhận định sai | AI trích wiki → wiki được coi như nguồn pháp lý → lỗi lan qua bản tổng hợp | Claim về raw evidence, review đúng phạm vi; DF-027/033 |
| Luật cũ trông như mới | Chạm file/ngày generated/HTTP304 được hiểu là luật còn hiệu lực | Freshness canonical, hiệu lực và review tách nhau; DF-019/027 |
| Nhiễm bộ nhớ công khai | Agent ghi trải nghiệm/private facts của A vào memory chung | Không private-to-public K1; namespace và full READ; DF-028/029/030 |
| Lộ từ metadata/search | File hoặc source bị revoke nhưng title/snippet/backlink vẫn hiện | Gate trước trả nội dung và metadata; DF-029/034 |
| Mở quyền qua nội dung | Frontmatter tự ghi approved/human; tài liệu chứa lệnh; skill mutable | Dữ liệu không là policy/authority; quyết định ở server; DF-021/027/035 |
| Phí ẩn và retry | Harness compaction/subagent/consolidation/provider retry ngoài ledger | Một Gateway, manifest, reservation và không auto retry; DF-017/021/044 |
| Tiếp tục sai workspace | Scratch/nháp giữ tenant hoặc revision trước | Operation scope/callback fencing; DF-032/036/046 |
| Wiki phát triển thành đống tài liệu | Trùng trang, broken link, tổng hợp lỗi thời, nạp cả kho vào prompt | Lint/coverage/ownership/progressive retrieval; kiểm dài hạn theo DF-043 |

HTML/Markdown renderer phải xử lý nội dung không tin cậy; không thực thi code, tự tải URL riêng hoặc nhúng tài nguyên ngoài khi chỉ mở trang. PDF/export cũng qua current READ. Nếu một trang tổng hợp có dependency bị chặn thì không tự hứa trả body đã “che bớt” an toàn; cần một projection được phép và chứng minh độc lập, hoặc dừng đọc trang đó.

## 13. Kế hoạch kiểm chứng trước khi chọn thêm framework

### 13.1. Tách thử nghiệm kiến thức khỏi thử nghiệm harness

| Nhánh | So sánh | Biến giữ nguyên |
|---|---|---|
| A | Baseline SQL/FTS + nguồn/extraction | Corpus, quyền, model, câu hỏi, trần token/dispatch, gold |
| B | A + wiki được biên soạn + liên kết có kiểu | Runtime/model như A; đo tác động của lớp wiki |
| C, tùy chọn | B + Deep Agents worker qua adapter | Cùng quyền/evidence/Gateway; đo tác động harness riêng |

Không đồng thời đổi model, corpus, prompt, retriever và framework rồi kết luận Markdown gây tăng chất lượng. Thứ tự chạy/nguồn dữ liệu được kiểm soát; lưu recipe và manifest để so sánh. Model-free fixtures chứng minh contract, không chứng minh Claude thật trả lời tốt hơn.

### 13.2. Corpus và tiêu chí

Đề xuất bộ pilot **30 câu do chuyên gia duyệt gold**, phân bố: 8 câu nhiều intent, 6 câu điều kiện/ngoại lệ, 6 câu thay nguồn/đợt/hiệu lực, 4 câu diễn đạt tự nhiên Việt–Anh, 3 câu thiếu căn cứ/ngoài phạm vi và 3 câu chéo doanh nghiệp/quyền. Nếu chưa đủ nguồn thật cho một nhóm thì ghi thiếu điều kiện thử, không bịa chính sách để đủ số lượng. Corpus attack/ACL/crash xác định có thể riêng và lớn hơn, không cần gọi model từng ca.

Tiêu chí bắt buộc ở pilot:

- Không bỏ mất mục tiêu trong 8 ca nhiều intent; mỗi mục tiêu có câu trả lời có căn cứ hoặc trạng thái thiếu cụ thể. Khoảng trống được báo đúng không tính là câu trả lời đầy đủ.
- 100% nhận định điều kiện/quyền hưởng/thời hạn trong gold được chuyên gia kiểm trace về đúng evidence/rule version; không chấp nhận fabricated source hoặc wiki tự làm căn cứ.
- Không dispatch không phép, không lộ private/metadata/revoked input; không AI từ search/read/cache/recovery; không retry/fallback có phí.
- Đổi raw source, thu hồi quyền, hai editor cùng sửa, đổi scope, pending review và source unavailable cho đúng kết quả gate. Replay receipt giữ exact identity và kiểm READ hiện hành.
- Lint phát hiện được các ca gieo lỗi: thiếu citation, link quan trọng bị gãy, dependency thiếu, trùng ID, đổi hash sau duyệt và source tự ghi trạng thái. Broken link mang nghĩa “chưa nghiên cứu” được lưu có nhãn, không dẫn thành nguồn đã có.
- B không kém A về chất lượng/coverage trên corpus; nếu không tốt hơn về tổng chi phí hoặc trải nghiệm chuyên gia thì chưa mở rộng. Không có mẫu thì ghi chưa đo, không báo tỷ lệ 100%.

Các chỉ số dùng [metric contract đã thiết kế](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>), bổ sung: số claim không có support / tổng claim vật chất; số trang cần rà quá hạn / tổng trang đến hạn; links hợp lệ theo loại; token tìm/đọc/tổng hợp; thời gian chuyên gia; chi phí build và maintenance; chất lượng sau nhiều đợt cập nhật. Đếm cả chi phí compaction/planner/worker phụ, không chỉ final answer.

```text
Tổng chi phí A(N) = build_A + maintenance_A + N × query_A
Tổng chi phí B(N) = build_B + maintenance_B + N × query_B
```

Chỉ tính điểm hòa vốn nếu đã đo được các thành phần và chất lượng tương đương. Không lấy giả định “hàng nghìn doanh nghiệp” làm bằng chứng wiki đã rẻ hơn. Thử thêm các đợt tăng nguồn, sửa đổi và mâu thuẫn để xem kho có xuống cấp; một demo tốt không đủ kết luận vận hành lâu dài.

### 13.3. Kiểm thử UX

Chủ Trà Sen trên 320/390 px: hỏi hai nhu cầu, thấy kết luận và việc làm, mở nguồn tiếng Việt và bản gốc, tải lại khi chờ, xem lịch sử và phần cần rà. Không lộ cấu trúc folder/graph/enum nội bộ vào chat. Chuyên gia: xem một diff có nguồn đổi, rà dependencies, chặn một kết luận thiếu căn cứ và phát hành đúng revision. Cần kiểm độc lập khi triển khai; nghiên cứu hiện tại chưa chạy các ca này.

## 14. Lộ trình bổ sung và các điểm cần duyệt

| Giai đoạn | Đề xuất làm | Cửa dừng |
|---|---|---|
| **K0 bổ sung** | P06 đã duyệt hướng wiki; bản 1.1 đã đồng bộ ADR, page/revision/evidence/tool/export và kế hoạch kiểm | Chưa lập trình; schema/tool là thiết kế đích, chưa qualification/runtime |
| **K1** | Một bộ chính sách Hà Nội đủ căn cứ; workbench Markdown/diff; SQL canonical revision; FTS/links; import candidate/export và ca revoke/crash | Nguồn và phạm vi chuyên gia đúng; chưa AI xây kho nền khi chưa có quyền/ngân sách |
| **K2** | Thử AI biên soạn, so A/B; thử Deep Agents adapter hoặc phần tái sử dụng OpenWiki | Qualification Gateway/public-domain egress và hạn mức riêng trước paid POC; không dùng quỹ tester thay quỹ xây kho |
| **K3** | Mở rộng domain/market, đánh giá embedding và connector partner | Chỉ thêm khi có kết quả đo; quyền, retention/hosting và chi phí theo đúng cửa duyệt |

**P06 — định hướng đã được chủ dự án duyệt ngày 26/10/2026:**

1. Chọn wiki Markdown được biên soạn làm một sản phẩm tri thức lâu dài; SQL giữ bản chuẩn nội dung/revision và authority, tệp chỉ là projection hoặc đầu vào đề xuất.
2. Giữ LangGraph và một Model Gateway; Deep Agents/OpenWiki là ứng viên thử có giới hạn, chưa thay runtime chính hoặc tự cài đặt.
3. Ưu tiên Markdown chuẩn và khả năng ánh xạ OKF; quyền/duyệt/hiệu lực của XAI nghiêm hơn metadata của định dạng mở. Chưa cam kết tương thích sản phẩm Google/Viettel cụ thể.
4. Chưa thêm graph/vector DB hoặc embedding model; quyết định bằng corpus A/B và chi phí toàn vòng đời.

P06 đã duyệt về định hướng theo [quyết định 06](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>); không suy rộng thành đã chốt các cadence, danh mục nguồn, curator, chi phí hoặc triển khai ở P01–P05. D04/D05/D06/D07-A giữ nguyên. `trung@dtt.vn` vẫn chỉ reviewer/publisher phạm vi Phụ lục 03/N1–N4 đã giao; chưa tự trở thành curator hoặc reviewer toàn bộ kho. Không có khóa API, grant hoặc chi phí mới trong đợt tài liệu.

## 15. Đối chiếu với bộ thiết kế và giới hạn nghiên cứu

- [Architecture nền](<01_Architecture.md>): đã cập nhật bản 1.1, ADR PK-12–14, wiki-as-product/canonical revision và bounded harness; giữ SQL/LangGraph/Gateway. Đây là cập nhật tài liệu, chưa code.
- [Dữ liệu và pipeline](<02_Du_lieu_pipeline_va_truy_xuat.md>): đã thêm body revision, typed links, proposal/import/export và dependency contracts; giữ freshness canonical, hai UoW và causal ordering.
- [Quản trị/API/UX/nghiệm thu](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>): đã thêm scoped virtual filesystem/capabilities, diff, WIKI-01–10 và benchmark A/B; giữ metric contract và cổng public-domain paid jobs. Các ca chưa chạy.
- [Sổ design flaws](<../architecture/DESIGN_FLAWS.md>): DF-027/028/029/033/034/043 cùng các biên Gateway/context vẫn mở D1; nghiên cứu không nâng trạng thái thiết kế đã kiểm chứng.
- [Review độc lập trước đó](<04_Review_doc_lap.md>) chỉ đánh giá hash 00–03 của baseline đã lưu. Đợt nghiên cứu ban đầu giữ nguyên 00–04; đợt cập nhật sau khi người dùng duyệt P06 đã lưu snapshot trước sửa và ghi rõ phạm vi review lịch sử. Bản 1.1/Phụ lục 05 chưa có review độc lập mới; không mượn kết luận cũ cho lựa chọn framework mới.

Nguồn web được đọc ngày 26/10/2026. Tài liệu framework và nhánh `main` thay đổi theo thời gian; trước POC phải pin phiên bản/commit và đọc lại license/capability/retry/egress. Nguồn là tài liệu tác giả, nhà phát triển hoặc nghiên cứu gốc; không dùng các comment trong gist như bằng chứng đã kiểm. Đây không phải thử nghiệm implementation, tư vấn hiệu lực của một chính sách cụ thể hoặc chứng minh tiết kiệm chi phí trên dữ liệu XAI.
