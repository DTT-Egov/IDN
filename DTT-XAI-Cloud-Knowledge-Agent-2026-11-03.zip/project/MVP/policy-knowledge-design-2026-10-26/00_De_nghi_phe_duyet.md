# Đề nghị duyệt thiết kế — hệ thống tích lũy tri thức chính sách

**DTT XAI / nMate · Bản 1.1 · 26/10/2026 · P06 đã duyệt về thiết kế; chưa triển khai.**

[Quyết định P06 và lịch sử phiên bản](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) ghi nhận lời đồng ý của chủ dự án và phạm vi cập nhật. Bộ này đã tích hợp wiki Markdown được quản trị; không có lệnh triển khai app hoặc ngân sách AI mới trong đợt cập nhật tài liệu. Review 04 thuộc baseline cũ đã lưu, chưa là review độc lập của bản 1.1.

**Kế hoạch thực hiện:** [07 — Milestones và các điểm dừng kiểm tra](<07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>). Theo yêu cầu mới, kết thúc mỗi mốc phải bàn giao bằng chứng và chờ người dùng cho tiếp tục; M5 tách kiểm release candidate trước deploy và kiểm sau deploy. Hiện dừng tại M0 để xem kế hoạch, chưa khởi động M1 hoặc thay app.

Tài liệu trình chủ dự án duyệt hướng kiến trúc, phạm vi và cổng kiểm soát. Không phải phê duyệt chi phí hoặc tuyên bố các chức năng mới đã có trong app. Đợt soạn tài liệu không chạy app, migration, cập nhật nguồn, gọi Claude hoặc thay quyền.

## 1. Đề xuất cần duyệt

Xây **một lõi tri thức chính sách công khai dùng chung**, bắt đầu từ Hà Nội, có thể mở rộng cho quy định xuất khẩu. Agent chủ động tìm tài liệu mới và chuẩn bị tri thức; người có thẩm quyền duyệt điều kiện tư vấn; trợ lý dùng tri thức đã phát hành cùng SSOT để phục vụ từng doanh nghiệp.

```mermaid
flowchart LR
  A[Phát hiện tài liệu] --> B[Lưu bản gốc và phiên bản]
  B --> C[Trích xuất và đề xuất tri thức]
  C --> D[Chuyên gia duyệt đúng bản]
  D --> E[Phát hành có phạm vi và hiệu lực]
  E --> F[Dùng lại cho nhiều doanh nghiệp]
  F --> G[Theo dõi thay đổi và rà lại]
  G --> B
```

Ba quyết định kiến trúc chính:

1. **Nghiên cứu nguồn một lần, dùng lại nhiều lần.** Kho nguồn và tri thức công khai có phiên bản riêng, tách SSOT/chat/tài liệu và kết luận riêng của doanh nghiệp. Không bắt mỗi chủ cơ sở trả phí đọc lại cùng một tài liệu.
2. **AI đề xuất, chuyên gia duyệt và phát hành.** Có đoạn trích không đồng nghĩa đủ luật; HTTP 200/304 hoặc cache còn hạn không chứng minh chính sách còn hiệu lực. Điều kiện, ngoại lệ, phụ lục, sửa đổi và đợt tiếp nhận phải được quản lý riêng.
3. **Giữ lõi SQL/LangGraph/MCP và một Model Gateway.** Chưa mua hay thêm vector/graph DB hoặc embedding. Job, quyết định, release và receipt có thẩm quyền ở SQL; graph/checkpoint/index không tự cấp quyền hoặc gọi lại AI.

Theo **P06 đã duyệt**, bổ sung **wiki Markdown là sản phẩm tri thức được biên soạn và tích lũy**, có trang chủ đề, tổng hợp, liên kết, mâu thuẫn và khoảng trống. SQL lưu nguyên nội dung từng revision cùng căn cứ và quyết định phát hành. Agent tạo nháp; file xuất, FTS và backlinks là projection. SSOT doanh nghiệp tiếp tục tách riêng; một trang wiki không thay quy tắc được duyệt hoặc nguồn pháp lý gốc.

## 2. Vì sao cần thay đổi này

[Audit bản đang chạy](<../source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md>) ghi nhận Hà Nội có 4 nguồn chưa được xác nhận đủ bộ căn cứ, 0 rule/claim và mới một lịch kiểm hằng ngày. Xuất khẩu có gói tham chiếu hữu hạn, chưa có discovery hoặc freshness chung mọi entrypoint. Đây là lý do cần đầu tư nguồn và quy trình tích lũy, thay vì chỉ tăng lượt Claude.

Thiết kế mới phải chứng minh được: câu hỏi có nhiều nhu cầu không mất ý; mỗi kết luận biết dựa vào đâu; hai doanh nghiệp dùng chung luật nhưng không lộ hồ sơ; luật đổi thì chỉ phần liên quan cần rà lại; lịch sử giữ nguyên; đọc cache/status không tốn lượt AI.

## 3. Phạm vi đề xuất cho đợt đầu

| Giai đoạn | Bàn giao | Giới hạn và cửa dừng |
|---|---|---|
| **K0 — duyệt thiết kế** | Bộ tài liệu hiện tại và quyết định phạm vi | Chưa lập trình hay gọi model |
| **K1 — một bộ chính sách Hà Nội hoàn chỉnh** | Thu thập có giới hạn, lưu/trích xuất local, workbench chuyên gia, phát hành, chat theo SSOT và thay đổi nguồn | Ưu tiên chương trình đang có hồ sơ Phụ lục 03; phải xác minh bộ căn cứ đủ. Không giả có đợt mở hoặc đủ điều kiện. Ngoài scope chuyên gia hiện có phải được cấp riêng |
| **K2 — AI hỗ trợ xây kho** | Đề xuất claim/rule/bản dịch, so sánh thay đổi, kết quả dùng lại có provenance | Chỉ bật khi Gateway hỗ trợ public-domain authority, model capability/egress và ngân sách ingestion được duyệt riêng |
| **K3 — mở rộng độ phủ** | Các bộ Hà Nội về số hóa quản trị, nhân lực, thị trường và xuất khẩu; adapter US/DE/JP dùng freshness chung | Mỗi bộ cần nguồn, phạm vi reviewer, ca kiểm và release riêng; không hứa bao phủ mọi thị trường |

K1 có thể bắt đầu bằng parser xác định và đề xuất do chuyên gia nhập thủ công, để kiểm chứng toàn chuỗi trước khi trả phí tự động hóa. Không có nghĩa sẽ dùng mock làm bằng chứng chất lượng AI. Khi kiểm chất lượng câu trả lời trong app, dùng Claude thật theo quỹ QA hiện có và đúng capability; thiết kế hiện tại chưa thực hiện vòng kiểm đó.

## 4. Demo nghiệp vụ dùng để nghiệm thu

**Chủ cơ sở Trà Sen hỏi:** “Chị muốn tìm hỗ trợ xuất khẩu và đào tạo nhân viên làm sổ sách buổi tối.”

1. Trợ lý nhận hai nhu cầu, lấy đúng hồ sơ cơ sở và sản phẩm; chỉ hỏi dữ kiện thực sự còn thiếu.
2. Hệ thống dùng bộ tri thức công khai đã phát hành. Nếu chỉ phần đào tạo đủ căn cứ thì trả phần đó và nêu rõ phần xuất khẩu còn thiếu; không lấp bằng gói tư vấn số hóa kho.
3. Câu trả lời nêu việc làm tiếp theo, điều kiện áp dụng, thông tin còn thiếu, nguồn và ngày kiểm; không khẳng định chắc chắn được hưởng khi chưa có căn cứ.
4. Chủ cơ sở soạn đề nghị/kiến nghị cụ thể, xem/sửa và duyệt bản nháp; facts mới chỉ vào SSOT khi owner xác nhận. Bản nháp chưa gửi iHanoi.
5. Doanh nghiệp B hỏi tương tự: dùng chung bộ nguồn nhưng đối chiếu SSOT B, không đọc chat/facts/kết luận của A.
6. Một phụ lục hoặc điều kiện thay đổi: hệ thống lưu phiên bản mới, tạo việc chuyên gia rà lại, cảnh báo đúng phần báo cáo phụ thuộc. Bản lịch sử không bị sửa âm thầm; nếu cần lượt AI mới phải hiện rõ và có phép.

Đây là kịch bản thiết kế, không phải tuyên bố chính sách thực tế hỗ trợ lớp buổi tối hay Trà Sen đủ điều kiện. Gold/căn cứ và các ca hợp lệ/không hợp lệ do chuyên gia xác nhận trước nghiệm thu.

## 5. Các quyết định đã có, không xin lại

- D04: staff đọc/đề xuất theo quyền; owner xác nhận SSOT; tài liệu/chat riêng không tự chia sẻ.
- D05: không gửi tài chính gốc; chỉ tiêu tối thiểu cần quyền egress riêng.
- D07-A: dừng riêng phần chưa đủ căn cứ hiện hành, vẫn trả phần độc lập hợp lệ và lịch sử có quyền.
- SQL/FTS5/graph SQL; chưa vector/graph DB riêng hoặc embedding.
- `trung@dtt.vn` kiêm reviewer/publisher đúng **`HN-DIGITAL-CONSULTING-2026` / Phụ lục 03 và N1–N4**; không mặc định có quyền mọi chính sách Hà Nội, xuất khẩu, curator hoặc hồ sơ doanh nghiệp.
- Quỹ QA local 20 USD đã được cấp riêng cho tester; không được chuyển sang AI ingestion nền hoặc deployment.

## 6. Các mục trình duyệt trong bộ này

| Mã | Phương án đề nghị | Tác động khi duyệt thiết kế |
|---|---|---|
| **P01 — kiến trúc lõi** | Duyệt pipeline có version, review/publication và public/private boundary; SQL/LangGraph/MCP/Gateway chung | Là chuẩn cho thiết kế chi tiết/TDD, chưa tự đổi app |
| **P02 — lát cắt đầu** | K1 một bộ chính sách Hà Nội đủ căn cứ; ưu tiên phạm vi Phụ lục 03 hiện có, chưa triển khai đồng loạt mọi chủ đề | Tránh dàn trải; danh mục văn bản và owner nguồn phải chốt trước nhập/phát hành thật |
| **P03 — cập nhật nguồn** | Profile kỹ thuật đề xuất: discovery 24h, văn bản đã biết 24h, cửa tiếp nhận gần hạn 6h khi chuyên gia xác định; có conditional GET và gộp job | Không phải hạn hiệu lực luật; thiếu legal/currentness review vẫn dừng assessment. Chi tiết giới hạn ở tài liệu 02 |
| **P04 — trách nhiệm** | Kế thừa reviewer/publisher đúng scope đã có; curator DTT vận hành nguồn theo danh mục được cấp | Mở rộng nguồn/chương trình hoặc phân công curator mới cần quyết định/quyền cụ thể, không tự gán |
| **P05 — trình tự** | K1 dữ liệu–duyệt–phục vụ trọn luồng → K2 AI hỗ trợ xây kho → K3 mở rộng | Giữ các cổng nghiệm thu; không coi approve kiến trúc là ngân sách chạy nền |
| **P06 — wiki và harness** | **Đã duyệt định hướng ngày 26/10/2026:** wiki biên soạn lâu dài + SQL canonical revision; giữ LangGraph/Gateway; Deep Agents/OpenWiki chỉ thử có điều kiện; Markdown chuẩn/ánh xạ OKF; chưa thêm embedding hoặc graph/vector DB | Cập nhật thiết kế chi tiết và tiêu chí kiểm; không tự cài framework, mở quyền hoặc gọi model |

Tại thời điểm trình duyệt: P01–P05 **đề xuất, chưa được người dùng phê duyệt**. Phần nào được chốt sau phải ghi ngày/phạm vi thật, không sửa như đã chốt từ trước.

**Cập nhật 26/10/2026:** người dùng đồng ý các đề xuất nghiên cứu và yêu cầu cập nhật tài liệu; ghi nhận phê duyệt **P06** tại tài liệu 06. Không suy thành việc đã duyệt riêng cadence, danh mục nguồn, curator, ngân sách ingestion hoặc triển khai P01–P05. Các nguyên tắc lõi tương ứng P06 đã được chốt trong phạm vi đó; những cửa vận hành ở mục 7 vẫn giữ.

## 7. Điểm phải dừng trước hành động tương ứng

| Điểm còn thiếu | Dừng việc gì | Phần vẫn tiếp tục được sau khi được giao triển khai |
|---|---|---|
| Ngân sách riêng cho ingestion/model/search/OCR/dịch có phí, giới hạn và provider data policy | Mọi paid domain dispatch; không lấy 20 USD QA để bù | Thiết kế, parser local, source registry, review thủ công và cache |
| Danh mục nguồn/chính sách mới, rights, curator/reviewer ngoài scope hiện có | Kích hoạt fetch/ingest/phát hành ngoài phạm vi đã duyệt | Kiểm trên fixture công khai đã có và chuẩn bị manifest nguồn |
| Hosting, retention, backup/khôi phục khi thí điểm thật | Đưa tài liệu/doanh nghiệp thực vào vận hành rộng hoặc tự xóa dữ liệu | Local với tài khoản tổng hợp/nguồn công khai trong scope; không thay retention cũ |
| Tài liệu/ủy quyền API iHanoi | Gửi hồ sơ hoặc kiến nghị thật | Chuẩn bị nháp/PDF, adapter hợp đồng và kiểm không gửi |
| Triển khai schema mới | Cutover khi chưa rehearsal, runtime-target preflight và backup | Soạn operator plan/TDD/clone migration sau lệnh triển khai |

Các điểm này được đưa vào bộ duyệt để thấy phạm vi, **không phải yêu cầu anh cấp tiền hoặc chốt toàn bộ ngay trong lượt thiết kế**. Khi bắt đầu K2 hoặc vận hành rộng sẽ có workload, ước lượng và phương án cụ thể để quyết định.

## 8. Tiêu chí nghiệm thu trước khi gọi là hoàn thành

1. Một bộ chính sách đủ căn cứ, có rule/claim đúng scope được review và phát hành thật; không giả nguồn hoặc bypass D07.
2. Hai doanh nghiệp có SSOT khác nhau nhận đối chiếu khác nhau từ cùng tri thức công khai; kiểm quyền và revoke không rò dữ liệu.
3. Cùng nguồn còn đủ điều kiện dùng không bị tải/trích/AI lặp theo số câu hỏi; cache có version và current READ.
4. Nguồn đổi/mất phụ lục/đến hạn/withdraw được xử lý theo outcome; lịch sử và receipt giữ nguyên.
5. Crash, replay, hai worker, lease hết hạn và paid unknown không gây ghi/thu phí trùng; không retry/fallback có phí.
6. TDD + review độc lập trên bản đóng gói; mobile 320/390, accessibility và báo cáo chi phí. Claude thật chỉ theo grant/tác vụ được duyệt; kết quả cache không ghi là lượt mới.
7. Wiki giữ được nội dung/revision/diff và căn cứ; import file không tự phát hành; source revoke thắng title/snippet/backlink/export; rebuild projection không AI. Bộ ca WIKI và phép đo A/B tại tài liệu 03 đều phải có bằng chứng trước nghiệm thu tương ứng.

Các số đo và ma trận ca ở tài liệu 03 là tiêu chí đề xuất, **chưa phải kết quả đã kiểm**.

## 9. Hồ sơ kỹ thuật để đối chiếu

| Tài liệu | Nội dung |
|---|---|
| [01 — Architecture](<01_Architecture.md>) | Component/agent boundaries, LangGraph/SQL, state, Gateway scope, cache/freshness, migration và ADR |
| [02 — Dữ liệu, pipeline và truy xuất](<02_Du_lieu_pipeline_va_truy_xuat.md>) | Identity/version, jobs, extraction, graph, cache keys, source coverage, schema logic và tình huống lỗi |
| [03 — Quản trị, API, trải nghiệm và nghiệm thu](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>) | Role/scope, review–publish contracts, MCP, mobile, workload/budget gates, TDD và kiểm độc lập |
| [04 — Review độc lập](<04_Review_doc_lap.md>) | Nhận xét nghiêm khắc, điểm đã chỉnh và phần còn chờ; không phải review app đã triển khai |
| [05 — Nghiên cứu wiki và harness](<05_Nghien_cuu_Markdown_Wiki_va_Agent_Harness.md>) | Cơ sở nghiên cứu và lựa chọn P06; phân biệt framework, bộ nhớ và thẩm quyền |
| [06 — Quyết định P06](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) | Phê duyệt, các tài liệu được đồng bộ, baseline review và cửa còn mở |
| [07 — Kế hoạch triển khai và mốc kiểm tra](<07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>) | M0–M5 cho lõi K1, M6/K2 có cổng phí riêng; dừng sau từng mốc, tiêu chí và gói bàn giao |
| [Sổ lỗi thiết kế](<../architecture/DESIGN_FLAWS.md>) | Trace các bất biến DF-027/033 và nhóm liên quan; giữ trạng thái còn mở |

**Trạng thái quyết định:** P06 đã được duyệt và tích hợp vào thiết kế1.1. P01–P05 giữ các phần đề nghị/cửa riêng như mục 6–7; không yêu cầu duyệt lại P06. Triển khai phần mềm cần được giao riêng, với TDD và các cổng dữ liệu/quyền/chi phí tương ứng.
