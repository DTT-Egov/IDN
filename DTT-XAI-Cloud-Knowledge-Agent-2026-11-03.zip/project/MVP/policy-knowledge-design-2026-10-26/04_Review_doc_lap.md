# Review độc lập — thiết kế tích lũy tri thức chính sách

> **Ghi chú phiên bản do tác giả bổ sung sau phê duyệt P06, 26/10/2026:** nội dung review bên dưới và bảng hash ở §5 thuộc baseline trước P06, đã lưu nguyên byte tại [snapshot baseline](<../../../REFERENCE_LINKS.md#ref-0007>). Các hash đó kiểm với file snapshot, không với các file 00–03 bản 1.1 hiện tại. Người dùng đã duyệt hướng wiki/harness và yêu cầu cập nhật tài liệu; việc đó không phải vòng review độc lập mới. [Sổ quyết định 06](<06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>) ghi các phần được cập nhật. Chưa có kết luận độc lập cho thay đổi P06, TDD hoặc app mới. Phần review lịch sử sau đây được giữ nguyên.

**Ngày 26/10/2026 · Rà kiến trúc và tài liệu, chưa nghiệm thu phần mềm.**

Người rà độc lập đã đọc bộ [00 — Đề nghị phê duyệt](<00_De_nghi_phe_duyet.md>), [01 — Architecture](<01_Architecture.md>), [02 — Dữ liệu và pipeline](<02_Du_lieu_pipeline_va_truy_xuat.md>), [03 — Quản trị và nghiệm thu](<03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md>), đối chiếu với audit nguồn 26/10, D04/D05/D07, phạm vi chuyên gia đã được cấp và sổ lỗi thiết kế. Không chạy app, tải nguồn, gọi model, sửa dữ liệu, cấp quyền hoặc dùng quỹ tester trong lượt review này.

## 1. Kết luận sau hai vòng rà

**Bộ tài liệu đã đủ điều kiện trình người dùng duyệt hướng kiến trúc P01–P05; không còn điểm P1 chưa xử lý trong phạm vi review tài liệu này.** Người rà đã đọc lại trực tiếp phần tác giả chỉnh, không chỉ dựa vào lời xác nhận. Pipeline giải quyết đúng lớp vấn đề: thiếu bộ căn cứ và vòng đời thẩm quyền, thay vì coi thêm model, vector database hoặc cache là đủ. K1 hữu hạn và kiểm bằng một chính sách thật là hợp lý; chưa có căn cứ nhận toàn bộ Hà Nội hoặc xuất khẩu đã được bao phủ.

Hai điểm P1 là thiếu nhất quán/thiếu quyết định trong đặc tả, **không phải RCA của một lỗi app mới đã tái hiện**. Việc người dùng duyệt kiến trúc không thay cho lệnh triển khai, quyền nguồn, review/publication thật hoặc ngân sách cho AI xây kho.

## 2. Phát hiện và yêu cầu chỉnh

| ID | Mức | Bằng chứng trong bản đọc đầu | Rủi ro thiết kế | Điều kiện xử lý |
|---|---|---|---|---|
| R1 | P1 | 01 §10 và 02 §5.1 cùng khai báo quyết định Freshness Service nhưng hai tập enum khác nhau | Adapter chat/MCP/worker có thể hiểu khác trạng thái cần kiểm, thiếu nguồn và bị cấm; tái diễn lớp DF-027/033 | Một hợp đồng canonical duy nhất; trạng thái job pending tách quyết định nguồn; các tài liệu còn lại tham chiếu hoặc mapping tường minh |
| R2 | P1 | 01 §5 cho phép bytes trong filesystem, 02 §5.3 yêu cầu rendition/extraction/outbox commit cùng transaction, 02 §9.2 chưa chọn nơi lưu K1 | Có thể commit tham chiếu tới bytes chưa bền hoặc hứa nguyên tử xuyên filesystem/SQL mà chưa có protocol | Chọn SQLite BLOB cho K1, hoặc đặc tả durable-bytes-before-SQL, recovery và orphan handling; không để hai lựa chọn có bảo đảm khác nhau dưới cùng lời hứa |
| R3 | P2 | Danh sách metric ở 01 §13 và nghiệm thu 03 §10 có tiêu chí tốt nhưng chưa xác định hết mẫu số/mốc đo | Có thể báo cache hit, nguồn đủ hoặc tốc độ tốt theo các cách không so sánh được | Metric contract cho coverage, evidence, refresh/review lag, reuse và dispatch/privacy; latency/công suất đo baseline trước khi đặt SLA |
| R4 | P2 | 02 §4.3 cấm chung PII vào kho public, trong khi `contact_channel` cần đầu mối công vụ được công bố | Hoặc chặn mất đầu mối hợp lệ, hoặc người triển khai tự mở ngoại lệ không có quyền | Phân biệt thông tin công vụ được nguồn công bố và có quyền dùng với dữ liệu cá nhân riêng/không cần thiết; không mở private-to-public workflow K1 |

### Kết quả đọc lại phần chỉnh

| ID | Sửa trong bản cuối | Kết quả review thiết kế |
|---|---|---|
| R1 | 02 §5.1 định nghĩa duy nhất `policy-freshness-decision/1`, sáu decision có precedence/mode và `AcquisitionStatus.job_state` trực giao; 01 §10 tham chiếu hợp đồng chuẩn. Tên ở bản dự thảo đầu chỉ có thể là nhãn UI mapping, không phải bằng chứng enum V17; DTO legacy thật cần kiểm kê/versioned adapter riêng | **Đã xử lý trong đặc tả.** `reusable` không tự cho phép eligibility/cửa nhận/release; `forbidden` vẫn chặn cả lịch sử, còn mỗi outcome có quyết định riêng |
| R2 | 01 §5/ADR PK-06 và 02 §5.3/§9.2 cùng chọn SQLite BLOB cho K1. UoW-A commit bytes/rendition/observation/outbox; parser ngoài SQL; UoW-B commit extraction/chunks/event/outbox. PK-D09 nêu crash trước/sau cả hai commit | **Đã xử lý trong đặc tả.** File/object store chỉ còn là ADR tương lai; không hứa transaction xuyên hai hệ lưu trữ. Vẫn phải có proof runtime/migration/crash khi triển khai |
| R3 | 03 §10.1 là metric contract có gold corpus/version, tử số/mẫu số, unknown/not-evaluable, raw events, source completeness, refresh/review lag, reuse, privacy/dispatch và chi phí. Ca 100 query/2 doanh nghiệp đo cache xác định, không phải 100 paid calls | **Đã xử lý trong đặc tả.** Gap không bị tính như câu trả lời; corpus toàn gap/mẫu số rỗng không đủ nghiệm thu; latency/throughput đặt mục tiêu sau qualification, tách downtime và human wait |
| R4 | 02 §4.3 cho đầu mối công vụ chính thức đi qua typed `contact_channel`, provenance/rights/scope/mục đích/retention và review; PII riêng/không cần thiết vẫn quarantine. 01 ADR PK-11 giữ cùng biên | **Đã xử lý trong đặc tả.** Không mở private-to-public promotion K1, không tự coi mọi tên/điện thoại trong tệp là công khai |

“Đã xử lý trong đặc tả” chỉ xác nhận phương án thiết kế đã rõ và nhất quán. Không nhận code đã sửa, test đã đạt hoặc lớp lỗi DF tương ứng đã đóng D2. Những thiếu sót bản nháp được giữ ở bảng đầu để truy nguyên lý do thay đổi.

## 3. Các biên đã đối chiếu và phải giữ khi triển khai

| Biên | Kết quả rà logic tài liệu |
|---|---|
| Nguồn và luật | Endpoint, bytes, extraction, văn bản/phiên bản pháp lý, chương trình và đợt tiếp nhận được tách; HTTP 200/304, quote còn nguyên, TTL và ngày luật có hiệu lực không dùng thay nhau |
| Độ đầy đủ | Có full text, phụ lục, sửa đổi, định nghĩa/ngoại lệ, per-item evidence và coverage gap; thiếu căn cứ dừng đúng outcome theo D07-A |
| Thẩm quyền | AI chỉ đề xuất; review và publication là hai quyết định exact version/hash; scope `trung@dtt.vn` không bị mở rộng ngoài Phụ lục 03/N1–N4 |
| Công bố và cache | Transaction/manifest/CAS/outbox có cổng hiện hành; withdrawal/READ revoke thắng pack/cache/index trước khi outbox hoàn tất; rollback không tự hồi sinh bản cũ |
| SSOT và dùng chung | Tri thức công khai dùng chung; facts/chat/tài liệu/đánh giá riêng không thành corpus công khai; mỗi doanh nghiệp giải context/READ riêng; owner xác nhận facts |
| Nhân quả và lịch sử | Causal predecessor/revision, không timestamp+UUID để chọn chân lý; as-of/known-at phân biệt; raw assertion, receipt và lịch sử không bị viết lại |
| Dispatch và phí | Một Gateway; public-domain subject/scope là thay đổi có contract/migration, không dùng enterprise giả; quỹ tester 20 USD không cấp AI ingestion; status/cache/recovery không dispatch; unknown không tự gọi lại |
| Orchestration | LangGraph checkpoint không cấp quyền hoặc thay receipt; worker có lease/fencing/CAS; giải phóng lease khi chờ chuyên gia; side effect trả phí không có auto retry |
| An toàn nguồn | Registry hữu hạn, rights riêng, private/redirect/DNS/MIME/page/byte limits; MCP/manual/Internet là dữ liệu chưa tin cậy; không có prompt injection mở quyền |
| Tương thích | Schema/operator và backfill nghiệp vụ tách biệt; legacy refs/bytes/receipt giữ nguyên; mutation mới cần contract đủ, không tự nâng nguồn cũ thành approved |
| Hành trình thực tế | Multi-intent Trà Sen, hai doanh nghiệp, đổi nguồn, thu hồi quyền, kiến nghị và PDF được mô tả; iHanoi dừng ở chuẩn bị nháp khi chưa có API/ủy quyền |

Đây là kết quả đối chiếu **logic đã viết**, không chứng minh code hoặc vận hành tương lai đã tuân thủ.

## 4. Giới hạn và các cửa còn mở

- Bộ văn bản đầu tiên, completeness, scope nguồn và profile phải được xác minh trước phát hành thật. Không coi chương trình Phụ lục 03 mặc nhiên hỗ trợ đào tạo buổi tối hoặc xuất khẩu.
- K1 chưa có AI xây kho trả phí; K2 cần public-domain authority trong cùng Gateway, adapter qualification, egress/retention và grant riêng. Quỹ QA chỉ có thể dùng cho ca chất lượng trong phạm vi đã cấp và còn hiệu lực.
- Retention/hosting/backup khi pilot rộng, quyền dùng tài liệu mới và connector ngoài scope còn là cửa vận hành. Không cần xin lại D04/D05/D07 hoặc danh tính chuyên gia đã chốt.
- Gold/corpus pháp lý phải do chuyên gia xác nhận. JSON đúng schema, test pass hoặc Claude nhận xét hay không tự chứng minh đầy đủ luật, đủ điều kiện hoặc cửa nhận đang mở.
- TDD, kiểm browser mobile, kiểm thiết bị/trình đọc màn hình, migration và Claude thật đều là công việc **sau lệnh triển khai**; chưa chạy trong review này.

## 5. Kiểm tài liệu và phiên bản đã đọc

Lượt đầu kiểm bốn file 00–03: **38 liên kết nội bộ hiện có đều trỏ tới đường dẫn hợp lệ**, các anchor Markdown có dùng trong bốn file đối chiếu được với heading đích. Liên kết tới file review này khi đó là liên kết chờ tạo, không bị tính thành lỗi tài liệu. Không kiểm truy cập mạng hoặc xác minh hiệu lực nguồn ngoài.

Vòng cuối đã đọc lại canonical freshness, các transaction/crash boundaries, privacy contact và toàn bộ metric contract; kiểm ADR có tên pattern đi cùng lý do/tradeoff/cửa xem xét lại. Không xem việc đặt tên CQRS, Outbox, Single Flight hoặc Anti-corruption Adapter là bằng chứng đã triển khai chúng.

Sau hai chỉnh nhỏ cuối, đã đọc lại sơ đồ staging/quarantine nằm ngoài miền công khai và cách gọi đúng tên enum bản dự thảo thay vì gán nhầm cho API V17. Kiểm toàn bộ **năm file 00–04, 42 liên kết nội bộ**: không có đường dẫn/anchor thiếu hoặc code fence chưa đóng theo phép kiểm tĩnh. Đây là kiểm file/Markdown, không chạy trình duyệt hoặc thực thi Mermaid.

Hash SHA-256 các tài liệu nội dung được review sau chỉnh:

| Tài liệu | SHA-256 |
|---|---|
| `00_De_nghi_phe_duyet.md` | `200de2d24f1d371e1affd5aa31376fbbb380d9987798ff35800cac9d12561e85` |
| `01_Architecture.md` | `cb3c669cea4ba301dba8d8fe7fb3081abf5095a4eecafaa4de6450f0f6bc53c9` |
| `02_Du_lieu_pipeline_va_truy_xuat.md` | `e4c1407f0000f1cb07ed25b6fc89af7e4637d031ab522998a2ac494591d91085` |
| `03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md` | `f8fa0c01d136e4120245600ef0f09f8a343b26eaa60e2c356020b1b1e2520a92` |

Review tài liệu kết thúc ở việc đủ rõ để người có thẩm quyền quyết định kiến trúc/phạm vi. Danh mục nguồn, completeness thật, phê duyệt rule/claim, ngân sách AI nền, vận hành/migration và các vòng test vẫn theo đúng cửa ở 00/03.
