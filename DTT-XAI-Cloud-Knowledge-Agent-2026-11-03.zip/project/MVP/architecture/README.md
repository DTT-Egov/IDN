# Theo dõi kiến trúc nMate

[Sổ lỗi thiết kế và nguyên nhân gốc](<DESIGN_FLAWS.md>) là nơi ghi các lớp lỗi đã được RCA xác nhận, biện pháp hiện tại và công việc thiết kế còn mở. Khi một lỗi tái diễn, cập nhật cùng ID để thấy được lịch sử; không chỉ tạo thêm một bản RCA rời.

Các tài liệu nền:

- [Kế hoạch thực hiện và mốc dừng kiểm tra M0–M7](<../policy-knowledge-design-2026-10-26/07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>). Hiện M0 chờ kiểm tra kế hoạch; M1–M5 là lõi K1, M6 AI xây kho có cổng riêng. Cuối mỗi mốc bàn giao và dừng; chưa triển khai app theo kế hoạch này.
- [P06 đã duyệt — quyết định và bản thiết kế 1.1, 26/10](<../policy-knowledge-design-2026-10-26/06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md>), [nghiên cứu wiki/harness](<../policy-knowledge-design-2026-10-26/05_Nghien_cuu_Markdown_Wiki_va_Agent_Harness.md>). Wiki là sản phẩm biên soạn lâu dài, SQL giữ canonical body/revision và quyền/phát hành; LangGraph/Gateway chung, Deep Agents/OpenWiki/OKF thử sau qualification. Chỉ cập nhật tài liệu; chưa triển khai/gọi model/cấp quyền. Review cũ giữ theo baseline snapshot, chưa review độc lập thay đổi P06.
- [Thiết kế tích lũy tri thức chính sách 1.1](<../policy-knowledge-design-2026-10-26/00_De_nghi_phe_duyet.md>), [architecture/ADR](<../policy-knowledge-design-2026-10-26/01_Architecture.md>), [review baseline trước P06](<../policy-knowledge-design-2026-10-26/04_Review_doc_lap.md>). P06 chốt hướng wiki/harness; các cửa nguồn/quyền/chi phí/triển khai còn riêng, không nhận ngân sách ingestion từ approve thiết kế.
- [V17 đã phát hành trên 8025: RCA và kiến trúc](<../../../REFERENCE_LINKS.md#ref-0390>), [walkthrough mobile](<../../../REFERENCE_LINKS.md#ref-0391>), [nghiệm thu và giới hạn](<../../../REFERENCE_LINKS.md#ref-0392>). Baseline cho thiết kế mới, không đồng nghĩa pipeline tích lũy đã triển khai.
- [V16 — mốc phát hành 23/10: RCA và phạm vi](<../../../REFERENCE_LINKS.md#ref-0393>), [walkthrough mobile](<../../../REFERENCE_LINKS.md#ref-0394>), [nghiệm thu và giới hạn](<../../../REFERENCE_LINKS.md#ref-0395>). Build `v16-repair-2026-10-23`, 2.711 backend/621 UI, 0 AI/phí mới; sự cố cất nhầm gốc chưa đủ chứng cứ đóng RCA.
- [Lõi R2–R3: kiến trúc và bất biến](<../../../REFERENCE_LINKS.md#ref-0396>), [walkthrough lịch sử](<../../../REFERENCE_LINKS.md#ref-0397>), [nghiệm thu R2–R3](<../../../REFERENCE_LINKS.md#ref-0398>). Nguồn chính sách thiếu vẫn theo D07.
- [R0–R1 đã phát hành trên 8025: kiểm thử, bundle và audit dữ liệu](<../../../REFERENCE_LINKS.md#ref-0399>), [walkthrough mobile](<../../../REFERENCE_LINKS.md#ref-0400>).
- [Kế hoạch xử lý các lớp lỗi thiết kế còn mở, sau bản residual-six 22/10](<KE_HOACH_DONG_LOI_THIET_KE_2026-10-22.md>).
- [Kiến trúc tổng thể, mốc 19/10/2026](<../../../REFERENCE_LINKS.md#ref-0401>).
- [Thiết kế lõi, SSOT, retrieval, SQL graph và Model Gateway](<../core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md>).
- [Thiết kế củng cố nháp, giao dịch và phép chiếu](<../../../REFERENCE_LINKS.md#ref-0402>).
- [RCA toàn vẹn dữ liệu và mobile, mốc 22/10/2026](<../../../REFERENCE_LINKS.md#ref-0403>).
- [Bản củng cố field, SSOT, Gateway, quyền và workspace, 22/10/2026](<../../../REFERENCE_LINKS.md#ref-0404>).

Các tài liệu theo ngày giữ nguyên phạm vi lịch sử. Sổ không biến đề xuất trong tài liệu thành tính năng đã triển khai; trạng thái cần đối chiếu bằng chứng của đúng bản phát hành.
