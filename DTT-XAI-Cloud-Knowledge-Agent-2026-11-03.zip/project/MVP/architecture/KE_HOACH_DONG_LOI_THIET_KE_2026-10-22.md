# Kế hoạch xử lý các lớp lỗi thiết kế còn mở

Ngày 22/10/2026. Mốc đối chiếu: build `residual-six-2026-10-22`, [nghiệm thu gần nhất](<../../../REFERENCE_LINKS.md#ref-0387>). Đây là kế hoạch tiếp theo, **chưa phải thay đổi đã triển khai**. Đợt lập kế hoạch chỉ đọc mã/tài liệu, không gọi Claude, không ghi dữ liệu hay thay bản 8025.

**Cập nhật thực hiện 18:58 cùng ngày:** đã phát hành lát cắt R0–R1 theo [báo cáo riêng](<../../../REFERENCE_LINKS.md#ref-0388>): inventory, query/preview, READ/replay, managed startup và schema lifecycle, bundle/process. 2.421 backend + 581 frontend đạt; 96 bảng MAIN không đổi sau cutover, 0 phí mới. Nội dung bên dưới giữ làm kế hoạch đích; các hạng mục R1 rộng còn lại và R2–R3 chưa được nhận hoàn tất.

**Cập nhật 01:00 ngày 23/10:** đã phát hành lát cắt R2–R3 theo [nghiệm thu có phạm vi](<../../../REFERENCE_LINKS.md#ref-0389>): Field Registry, current workspace/SSOT theo provenance, IntentPlan/ActionBrief/delivery và graph tri thức SQL có kiểu/quyền/dependency. 2.687 ca backend duy nhất từ các nhóm có đối chiếu (nhiều lượt chạy), 602 frontend; mobile clone 320/390, bundle backend/web/worker, 96 bảng MAIN nguyên vẹn, 0 AI/0 phí mới. M2 cho các đường/corpus đã kiểm; toàn bộ 48 lớp DF vẫn D1. Nội dung nguồn chính sách xuất khẩu/đào tạo chờ duyệt D07, không dùng việc phát hành lõi làm bằng chứng nội dung đã hoàn tất.

**Mốc app hiện hành 01:10:** bundle final-v7 giữ nguyên backend và mã UI đã kiểm, đồng bộ HTML phụ và lệnh build; frontend cuối **606/606**, gồm bốn ca hồi quy đóng gói. Backup/audit mới tiếp tục giữ đủ 96 bảng/quyền/hạn mức, 0 AI/phí. Xem cùng báo cáo nghiệm thu để phân biệt mốc lõi và mốc đóng gói, không cộng các bộ UI.

## 1. Điều gì còn thiếu?

[Sổ DF](<DESIGN_FLAWS.md>) có 48 lớp nguyên nhân, toàn lớp vẫn D1: đã có ràng buộc ở một phần hệ thống nhưng chưa kiểm kê và nghiệm thu mọi đường liên quan. Điều này **không có nghĩa 48 lỗi vẫn đang tái hiện**. Sáu lỗi gần nhất đã có bản vá và bằng chứng giới hạn theo ca kiểm; phần còn thiếu là đưa các ràng buộc thành hợp đồng dùng chung, xử lý đường cũ và kiểm chuyển trạng thái.

Ba loại việc phải tách rõ:

| Loại | Ví dụ | Cách xử lý |
|---|---|---|
| Thiếu chuẩn hóa hoặc coverage | Resolver, status, schema, UI và adapter chưa cùng hợp đồng | Inventory đường thực thi, thay dần và kiểm invariant; không viết lại phần đã đúng |
| Thiếu nội dung/capability | Nguồn chính sách xuất khẩu/đào tạo chưa đủ; PDF scan chưa OCR | Bổ sung nguồn hoặc capability theo hợp đồng, giữ thông báo phần chưa làm được |
| Chưa đủ bằng chứng nghiệm thu | Chưa có reader âm thanh, điện thoại thật hoặc Claude sinh mới sau refactor | Lập bài kiểm riêng; không dùng số test offline thay bằng chứng này |

### Đính chính cách đọc các mục cũ

- **DF-031:** mã hiện tại đã có server command ID và khóa idempotency theo enterprise/actor/kind/client ID trong [ReviewStore](<../../nmate-backend-v0.2/src/nmate/core_v1/review_store.py>); [Gateway](<../../nmate-backend-v0.2/src/nmate/core_v1/gateway.py>) đã có khóa enterprise+operation, task/step không NULL. Việc còn lại là đối soát runtime DDL, các adapter và collision/concurrency; không thiết kế lại từ số không.
- **DF-041:** [IntakeService](<../../nmate-backend-v0.2/src/nmate/v04/intake.py>) hiện đã có `migrate_reviews` tường minh; constructor đó tạo schema, không còn backfill alias như mốc lịch sử. Vẫn phải inventory constructor/bootstrap/schema/seed khác và bằng chứng interrupted/resume/restore trước khi đóng toàn lớp.
- **DF-033:** đã có cấu trúc policy/rule/claim và pack version ở một số đường. Cần kiểm nhất quán schema/query/cache/legacy và rebuild projection, không kết luận graph đang làm rò hay trộn chính sách khi chưa tái hiện.
- **Query hạn mức:** [MainProvider](<../../nmate-backend-v0.2/src/nmate/main/provider.py>) đã gọi `status(provision=False)`. [CoreIntegration.gateway_status](<../../nmate-backend-v0.2/src/nmate/core_v1/integration.py>) còn gọi mặc định `provision=True` của Gateway. Đây là bất nhất contract nhìn thấy trong mã: query có thể cấp child grant trong quỹ đã duyệt. **Không phải bằng chứng phát sinh model call, tăng ngân sách hoặc tính phí trên MAIN.** Cần fixture runtime xác nhận từng adapter trước sửa.

Các trạng thái danh mục M0/M1 cần được đối soát theo phạm vi chứng cứ, không dùng nhãn cũ làm bằng chứng cơ chế chưa tồn tại. Kế hoạch này không nâng tất cả mục thành M2/D2 chỉ từ đọc mã.

## 2. Bảy gói công việc và cửa nghiệm thu

Trước mỗi gói: ghi DF → invariant → command/query/adapter → test → release. Lập danh sách đường main HTTP, MCP trực tiếp, LangGraph, form hồ sơ, chat miễn phí/có phí, import, artifact, history/cache/recovery và legacy. Mỗi đường có một trong ba kết quả: đã chuyển sang hợp đồng chung, chỉ đọc có giới hạn, hoặc ngừng ghi có giải thích. Không để hai writer cùng có thẩm quyền.

### P1 — Đọc thuần túy, quyền và vòng đời lượt AI

**DF:** 013/017/019/021/028/029/030/031/032/034/044/046.

- CQRS trong cùng SQL: status, preview, đọc receipt đã commit và đối soát/đọc kết quả chỉ đọc. **Áp dụng kết quả đã lưu là command idempotent riêng**, có receipt/audit, kiểm READ input hiện hành và quyền nghiệp vụ cần cho thao tác đó; được ghi trạng thái ứng dụng theo domain nhưng không tạo reservation/dispatch model mới. Không giấu thao tác áp dụng dưới query hoặc cấm mọi recovery ghi. Activation quỹ là command rõ hoặc một bước được phép trong command bắt đầu; giữ eligibility/purpose/role/expiry hiện tại.
- Một contract readiness theo capability cho UI và server: quyền input, source readiness, consent theo payload/context, grant/model và pending operation là các trục riêng.
- Dùng một canonical request builder và registry phiên bản cho cả gửi và nhận lại kết quả cũ. Giữ full request hash, lineage và READ hiện hành; không mở hash gần đúng.
- Operation/attempt có namespace và quan hệ đầy đủ; một đầu mối reserve/dispatch/reconcile. Checkpoint LangGraph không cấp quyền ghi SSOT, quyền gửi dữ liệu hay ngân sách.
- Tách trạng thái xử lý, vận chuyển, kiểm chứng, công bố và chi phí. Không giữ transaction SQL trong lúc chờ mạng/model.

**Đóng lát cắt khi:** lặp status/đọc receipt đã commit không đổi grant/ledger; hai tài khoản tranh lượt cuối không vượt quỹ; không có dispatch từ query; input bị revoke chặn output dẫn xuất; receipt đọc theo READ mà không đòi quyền WRITE mới. Command áp dụng kết quả đã lưu chỉ ghi một lần theo đúng quyền, không gửi model lại; đối soát usage cũ không được coi là một lượt mới. Crash trước reserve/sau reserve/sau dispatch/trước response có outcome đối soát rõ. Khi đã dispatch mà kết quả chưa rõ: giữ uncertain và đối soát, không tự gửi lại. Không hứa exactly-once đối với dịch vụ ngoài chỉ bằng idempotency nội bộ.

### P2 — Migration và khởi động có kiểm soát

**DF:** 031/033/040/041/042/043; thực hiện trước các thay đổi DDL rộng của gói sau.

- Inventory mọi tác dụng constructor/startup/bootstrap; tách schema migration, seed được quản lý và biến đổi nghiệp vụ.
- Migration runner có version, checksum nguồn/dependency, precondition, dry-run, receipt và điểm resume. Khởi động runtime kiểm schema tương thích, không tự diễn giải lại facts/alias/grant.
- Diễn tập nâng cấp, gián đoạn, chạy lại và restore bằng DB riêng; xác định rollback code có còn đọc được schema đã nâng hay phải phục hồi có kiểm soát.

**Đóng lát cắt khi:** startup trên DB đã migrate không đổi dữ liệu nghiệp vụ; chạy migration hai lần không áp dụng lại; dừng giữa chừng/resume không tạo bản ghi nửa vời; restore giữ integrity, quyền và ledger. Mọi MAIN migration cần kế hoạch cụ thể, backup mới và đối soát; không lấy quyền sửa code làm quyền gộp/sửa dữ liệu legacy.

### P3 — Registry field, identity và đọc tài liệu

**DF:** 001/002/003/006/007/008/009/030/035/040.

- Hoàn thiện registry đang có thành một hợp đồng versioned: kiểu field, entity scope, qualifier, đơn vị, unknown/set/clear/known-absent, sensitivity, ACL, validator và quy tắc hiển thị cảnh báo. Schema gửi model được sinh hoặc kiểm tương thích tự động với registry.
- Dùng `domain_validation.base_field_key` để phân loại field có qualifier; casefold chỉ phục vụ phân loại, không sửa exact field key/value hoặc mở rộng ACL của field gốc.
- ID thực thể khác tên/alias; alias có căn cứ owner, lifecycle và version. Resolver trả explicit/ambiguous/new/conflict có provenance; không fuzzy merge hoặc biến mention thành owner selection.
- Ingestion chung cho chat/Excel/PDF/ảnh/HTTP/MCP: nhận diện signature, giới hạn tài nguyên, quyền và D05 trước đường trả phí. Error contract phân biệt tệp sai với hạ tầng/mất kết quả.
- Trích dữ kiện là observation/proposal có source span và target; chưa phải SSOT. Đường đọc tài liệu không biến lệnh trong tệp thành chỉ thị agent.

**Đóng lát cắt khi:** cùng dữ liệu qua chat/form/Excel/PDF/MCP cho kết quả kiểu/đích nhất quán; giá trị legacy sai bị cách ly khỏi dùng mới; create/rename/restore collision và race đúng tenant. Các ca trống/0/null/clear/oz/fl oz/nonfinite/phủ định/tên dài/tên nhiều từ có đối chứng. PDF lỗi hạ tầng không được bỏ tệp; mẫu demo phải qua cùng parser/egress. OCR vẫn là capability riêng, chưa bật chỉ vì PDF text đã chạy.

### P4 — Nháp, SSOT và view hiện tại cùng một vòng đời

**DF:** 007/008/009/010/011/012/013/014/015/016/018/019/020/032/034/036/038/044/045/046/047/048.

- Dùng tiếp Aggregate/state machine, Unit of Work và CAS đã có; chuyển các writer/adapter còn lại sang cùng handler. Facts, quyết định, binding, revision và receipt cùng commit/rollback.
- Proposal/observation/receipt bất biến. Binding có phiên bản; đổi đích tạo proposal dẫn xuất có audit, không sửa hash hoặc target gốc.
- Context compiler phân biệt facts hiện hành, nháp còn chờ, quyết định giữ/bỏ và case facts; manifest gắn dependency thực, kể cả field trước đó chưa có.
- DTO/reducer theo owner/enterprise/workspace/entity/intake/revision và operation; response/callback cũ không được đổi scope mới. Snapshot lịch sử không thay view hiện tại.
- Context dùng thứ tự quyết định/hiệu lực, không dùng timestamp+UUID thay quan hệ nhân quả.

**Đóng lát cắt khi:** lưu riêng tên cơ sở → tên+mã → reload → ba field còn lại vẫn đúng một sản phẩm; nháp đã bỏ không hồi sinh; hai tab có conflict rõ; archive/restore/revoke/switch account không đổi đích. Replay exact trả receipt gốc theo READ hiện hành, không ghi hoặc đòi còn lượt. Model-based sequence tests kiểm chuỗi và ca âm trên tất cả adapter đã inventory, không chỉ từng hàm riêng.

### P5 — Hiểu intent, phân rã yêu cầu và giao việc theo kết quả

**DF:** 004/005/006/015/022/023/024/025/026/027.

- Một `IntentEnvelope` chứa các mục tiêu, product/market references, exclusions, thông tin đã có, nguồn câu gốc và điểm còn mơ hồ. Bổ sung hội thoại nối tiếp vào đúng goal; đổi focus không mang slot nghiệp vụ cũ sang.
- Parser xác định dùng cho dữ kiện rõ và guard. Khi dùng LLM hiểu câu tự nhiên, LLM chỉ đề xuất intent/plan theo schema; server kiểm scope, quyền, nguồn và dependencies. Không thêm lượt LLM âm thầm; đọc lại intent/plan đã lưu không gọi model. Chưa rõ thì hỏi một câu cần thiết hoặc nêu phần chưa hỗ trợ.
- Plan ánh xạ goal → requirements → task/dependency → section/outcome/blocker. Yêu cầu hỗ trợ cho mục tiêu rộng phải có căn cứ và ngoại lệ, không suy mọi chuyến hàng đều cùng checklist.
- Correctness và completeness là hai kiểm riêng. Một section thiếu căn cứ không hủy phần độc lập hợp lệ, cũng không làm phần thiếu trở thành kết luận được phép.
- `ActionBrief`: làm gì trước, ai làm ở mức đã biết, đầu vào/đầu ra, cách biết đã xong, căn cứ và bước đi tiếp. “Ba việc đầu tiên” phải thay theo câu hỏi, không quay về một gói ba việc mặc định.

**Đóng lát cắt khi:** corpus câu thực tế/đa ý/phủ định/không tên sản phẩm/đổi thị trường/đang có nháp chạy qua cùng contract. Trà Sen hỏi toàn bộ lô, chỉ hỏi nhãn và loại trừ một chủ đề phải có kế hoạch khác nhau; đăng ký, nhãn, prior notice và trách nhiệm bên nhập khẩu có coverage hoặc blocker đúng phạm vi khi liên quan. Xuất khẩu + đào tạo giữ đủ hai mục tiêu. Không mất cả output đã trả phí chỉ vì có câu làm rõ. Nghiệm thu offline cấu trúc chưa thay đánh giá chất lượng Claude sinh mới.

### P6 — Tri thức domain có kiểu, phiên bản và hạn sử dụng

**DF:** 005/009/025/027/029/032/033/034.

- Hoàn thiện graph trên SQL đang có: tách source snapshot/excerpt/claim/rule/policy version/pack version; quan hệ có scope, vai trò căn cứ, `applies_when`, hiệu lực, exception và supersession.
- Graph và retrieval index là projection từ bản ghi có thẩm quyền, không thành SSOT doanh nghiệp thứ hai. Tri thức domain dùng lại không mang tài liệu/facts riêng của doanh nghiệp khác.
- Refresh nguồn, phát hiện thay đổi và vô hiệu căn cứ cũ; nguồn tự cập nhật không tự phát hành rule tư vấn mới. D07 vẫn trả phần hợp lệ, dừng riêng phần thiếu căn cứ hiện hành.
- Ưu tiên source pack còn thiếu cho xuất khẩu và đào tạo; việc đọc đủ và được duyệt là đầu ra riêng, không coi thêm URL là hoàn thành chính sách.

**Đóng lát cắt khi:** claim sai loại bị chặn, thay một policy không làm sai các policy khác trong pack; nguồn bị thay thế/không đọc đủ/hết freshness không bị dùng như nguồn hiện hành. Rebuild projection không đổi facts/quyết định nghiệp vụ. Cache invalidation theo dependencies, kiểm multi-market và revoke. Quy tắc mới chỉ được phát hành qua vai trò `trung@dtt.vn` đã chỉ định.

### P7 — Primitive mobile và cửa phát hành bắt buộc

**DF:** 014/016/018/019/020/036/037/038/039/040/041/042/043.

- Tách dần renderer lớn thành editor, disclosure, notice/error, progress, attachment, consent/cost và action card dùng cùng contract. Không viết lại toàn app cùng lúc hoặc đổi giao diện khỏi prototype.
- Mỗi primitive giữ target/revision, nháp và focus; accessibility name, hit area 44 px, expanded/controls, live announcement và cảnh báo nhìn thấy trước nút xác nhận là thuộc hợp đồng thành phần.
- Một localization/address policy cho template và input model mới; không sửa raw lời người dùng hoặc lời Claude cũ.
- Release manifest nối source/backend/dependencies/assets/migration/tests/process. Build khóa trước bộ tổng; cutover và rollback có script, backup mới và health/DB/budget audit.
- Gate sequence/property/failure injection bắt đầu từ P1, không đợi hết refactor mới thêm. Mỗi DF có đối chứng có thể làm test đỏ khi vi phạm invariant; tổng test xanh một mình không là tiêu chí đóng.

**Đóng lát cắt khi:** browser 320/390, keyboard/zoom, disclosure lồng nhau, lỗi liên tiếp, reload/two-tab và mạng chậm có evidence. Một lỗi chỉ thông báo một lần; progress không đọc mỗi giây hoặc giả làm lượt phục hồi cũ. Điện thoại thật và NVDA/VoiceOver có âm thanh được nghiệm thu riêng, chỉ ghi đạt khi có phiên kiểm thật. Bản đang phục vụ phải khớp bundle đã kiểm, không sửa MAIN để làm smoke test xanh.

## 3. Thứ tự phát hành

| Đợt | Đầu ra cụ thể | Phụ thuộc / cửa đi tiếp |
|---|---|---|
| R0 — Đối soát kiến trúc | Ma trận mọi command/query/writer/adapter, schema và startup effect; cập nhật trạng thái DF theo chứng cứ thực; test đỏ cho khoảng hở đã chứng minh | Chỉ đọc và DB riêng, không migration MAIN. Đây là việc bắt đầu trước, không tiếp tục vá từng câu rồi coi như đóng kiến trúc. |
| R1 — An toàn dữ liệu và lượt AI | P1 + P2: query thuần đọc, capability gates, request/recovery contract, migration/release nền | Giữ nguyên quota/eligibility/D04–D07; race/crash/READ/ledger và restore đạt trước đổi DDL rộng. |
| R2 — Hợp đồng dữ kiện và workspace | P3 + P4; chuyển các UI primitive liên quan của P7 cùng từng lát cắt | Cùng field/binding/command/revision qua mọi đường đang bật; chuỗi partial confirm/reload/legacy/direct MCP đạt. Không tự dọn dữ liệu cũ. |
| R3 — Agent hiểu nhu cầu và tri thức dùng lại | P5 + P6; hoàn tất P7 trên các flow đích | Đủ goal/outcome/blocker, task có acceptance, nguồn/rule đủ thẩm quyền; mobile/release evidence đạt. Chuẩn bị live evaluation riêng trước khi xin phép gọi Claude. |

Có thể làm song song inventory UI và nguồn domain sau R0. P2 là tiền đề cho DDL; registry P3 là đầu vào cho context/schema P4–P5; P5 và P6 phải cùng kiểm dependency/coverage. Mỗi đợt có người triển khai và reviewer độc lập; không dùng review của cùng người thay nghiệm thu cuối. Chốt thời lượng sau R0 dựa số đường cần chuyển và migration thực, không hứa ngày chỉ dựa số DF.

## 4. Khi nào cần trao đổi với chủ dự án?

Các gói kỹ thuật giữ nguyên dữ liệu/quyền/ngân sách không cần hỏi lại quyết định đã chốt. Chỉ đưa ra quyết định khi có phương án cụ thể để duyệt:

1. **Dữ liệu legacy:** gộp hồ sơ, chọn facts chuẩn, sửa ownership/chuỗi nhân quả, xóa dữ liệu hay đổi retention. Chuẩn bị danh sách ảnh hưởng, diff, backup/rollback; chưa duyệt thì không tự sửa.
2. **Claude/evaluation mới:** trình câu hỏi, model/purpose, payload tối thiểu, số lượt và trần tiền theo D06; không tự dùng lại grant cũ hoặc retry/fallback. Trong lúc đó dùng kết quả đã lưu và test không phí.
3. **Quy tắc chính sách mới:** chuẩn bị hồ sơ nguồn, điều khoản và rule để `trung@dtt.vn` duyệt/phát hành theo D07. Không cần chỉ định lại người đã được chốt; thiếu căn cứ thì giữ blocker.
4. **Capability hoặc egress mới:** OCR/vision ngoài server, loại chỉ tiêu tài chính mới, lịch đổi tên tương lai hay thay cơ chế ngân sách. Chuẩn bị tradeoff về dữ liệu/chi phí/hành vi trước khi hỏi; D05 không gửi tài liệu tài chính gốc cho Claude vẫn giữ nguyên.

Không cần graph/vector DB riêng, microservices hoặc thêm một agent cho mỗi lỗi để triển khai kế hoạch này. Chỉ đề xuất thêm hạ tầng khi có bài đo retrieval/chất lượng/độ trễ và nhu cầu vượt SQL hiện tại.

## 5. Điều kiện chuyển D1 sang D2

Chỉ chuyển **đúng phạm vi** đã có: contract versioned, một đầu mối thực thi, inventory đủ đường bật và legacy, ca âm/sequence/concurrency/crash, migration/compatibility khi có, bằng chứng mobile/release đúng source và giới hạn rõ. Không nhận mọi câu tự nhiên, mọi tài liệu hoặc mọi agent tương lai đã an toàn chỉ vì flow Trà Sen đạt.

Ba flow dùng làm ca tham chiếu xuyên các đợt: **Trà Sen xuất khẩu theo thị trường; Bột sen đọc tài liệu → nháp → xác nhận từng phần; xuất khẩu + đào tạo trong chính sách Hà Nội**. B1 tồn kho và sales-month là đối chứng bắt buộc để refactor xuất khẩu không làm mất mạch công việc khác.
