# S4 — Checklist chuẩn bị hồ sơ: nháp AI để chuyên gia rà soát

Ngày27/10/2026. Đây là nội dung Claude đã lưu, chưa được chuyên gia duyệt hoặc phát hành. Trích dẫn có vị trí nguồn; ngữ nghĩa và hiệu lực chính sách chưa được xác minh.

[Kết quả batch và giới hạn](<13_M6_Ket_qua_4_slot_Claude.md>)

## 1. Nhận định đề xuất

Thông báo nêu thời hạn nhận hồ sơ đăng ký của doanh nghiệp và việc nộp hồ sơ theo Phụ lục.

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 170–204 trong chunk đã ghim.

> Từ 30/03/2026 đến khi đủ
> chỉ tiêu.

## 2. Nhận định đề xuất

Mức hỗ trợ theo Phụ lục 3 là 50% kinh phí, có trần theo quy mô doanh nghiệp; Nghị định 80/2021 có quy định tương tự.

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 1056–1091 trong chunk đã ghim.

> 50% kinh phí
> từ Ngân sách
> nhà nước,

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 285–347 trong chunk đã ghim.

> không quá 100 triệu đồng/hợp đồng/năm đối với doanh nghiệp vừa

## 3. Nhận định đề xuất

Hồ sơ gồm tờ khai xác định quy mô doanh nghiệp kèm đề xuất nhu cầu hỗ trợ, và tài liệu liên quan nếu có.

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 405–505 trong chunk đã ghim.

> Tờ khai xác định doanh nghiệp siêu nhỏ, doanh nghiệp nhỏ, doanh nghiệp vừa và đề xuất nhu cầu hỗ trợ

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 572–641 trong chunk đã ghim.

> Những tài liệu, hồ sơ liên quan đến nội dung đề xuất hỗ trợ (nếu có).

## 4. Nhận định đề xuất

Có ba hình thức nộp: trực tiếp tại các địa điểm nêu, bưu chính công ích, hoặc trực tuyến qua Cổng dịch vụ công quốc gia. Sau khi nhận hồ sơ, cán bộ trao đổi về hồ sơ cần chứng minh (nếu có).

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 2976–3021 trong chunk đã ghim.

> (ii) Nộp thông qua dịch vụ
> bưu chính công ích

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 3157–3224 trong chunk đã ghim.

> cán bộ phụ trách
> sẽ trao đổi chi tiết về các
> hồ sơ doanh nghiệp cần

## 5. Nhận định đề xuất

Checklist sơ bộ (chưa duyệt): xác định quy mô nhỏ/vừa; điền tờ khai theo mẫu; chuẩn bị hợp đồng/báo giá tư vấn và tài liệu liên quan; chọn hình thức nộp; chờ trao đổi bổ sung. Báo giá được nhắc ở Thông tư 06/2022 và cần chuyên gia xác minh.

Nguồn `VN-CIRCULAR-06-2022-GAZETTE`; vị trí ký tự 1217–1251 trong chunk đã ghim.

> báo giá của bên cung cấp (nếu có).

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 405–443 trong chunk đã ghim.

> Tờ khai xác định doanh nghiệp siêu nhỏ

## Khoảng trống cần kiểm

- Thông báo số /TB-TTXT chưa có số và ngày ban hành trong trích đoạn.
- Chưa có toàn văn Phụ lục 3, nên thành phần hồ sơ có thể còn thiếu.
- Chưa rõ tiêu chí chọn doanh nghiệp, điều kiện hợp đồng tư vấn, thời điểm ký hợp đồng và chứng từ thanh toán.
- Chưa rõ cách xử lý khi hết chỉ tiêu hoặc ngoại lệ.
- Chưa có căn cứ về hiệu lực hiện hành của Nghị định 80/2021 và Thông tư 06/2022.
- Thông tin liên hệ trong trích đoạn có chỗ trùng lặp, cần xác minh.

## Câu hỏi cho chuyên gia

- Bản thông báo chính thức đã ban hành chưa, số và ngày nào, có thay đổi so với Phụ lục này không?
- Hồ sơ cần thêm báo giá, hợp đồng tư vấn, chứng từ thanh toán hoặc tài liệu chứng minh quy mô nào?
- Có điều kiện về loại tư vấn, đơn vị tư vấn hoặc thời điểm ký hợp đồng không?
- Hạn mức 50/100 triệu áp dụng thế nào theo hợp đồng và theo năm?
- Các số điện thoại, email liên hệ trong Phụ lục có chính xác không?
