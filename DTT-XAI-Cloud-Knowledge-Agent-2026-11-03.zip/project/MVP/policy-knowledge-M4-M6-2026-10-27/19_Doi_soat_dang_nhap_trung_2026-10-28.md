# Đối soát đăng nhập trung@dtt.vn — 28/10/2026

## Kết luận theo bằng chứng hiện có

Đã thực hiện **một lần đăng nhập chẩn đoán trực tiếp qua API của app chính 8025**, dùng thông tin trong tệp riêng trên máy. Thành công; đọc lại phiên nhận đúng `trung@dtt.vn`, API thẻ quyền O2 trả enabled. Không đổi mật khẩu hoặc quyền, không gửi Claude, không ghi quyết định O2. Sau chẩn đoán đã đăng xuất riêng phiên vừa tạo.

Điều này bác bỏ hai giả thuyết “tài khoản chưa có trên 8025” và “mật khẩu trong tệp hiện không khớp”. **Chưa xác định nguyên nhân lần đăng nhập thất bại của tester**, vì chưa có HTTP status, thông báo lỗi trên form hoặc bằng chứng trình duyệt ở thời điểm thất bại. Không coi API thành công là bằng chứng đã đăng nhập qua UI bằng tài khoản thật.

## Phép kiểm đã thực hiện

| Bước | Kết quả |
|---|---|
| Build đang chạy | `policy-cost-approval-2026-10-27`, launcher `launch_approved_cost.py` |
| Đọc phiên trước đăng nhập | HTTP 200, authenticated=false; nhận preauth/CSRF theo giao thức hiện có |
| POST đăng nhập đúng 1 lần | HTTP 200; authenticated=true; khoảng 0,485 giây |
| Đọc lại phiên với cookie do server cấp | HTTP 200; authenticated=true; username=trung@dtt.vn |
| Đọc quyền thẻ chi phí | HTTP 200; enabled=true |
| Đăng xuất phiên chẩn đoán | HTTP 200 |
| Trình duyệt bên cạnh | Ban đầu là màn “Bắt đầu với doanh nghiệp” với nút “Đã có tài khoản? Đăng nhập”; đã chuyển sang “Mở lại hồ sơ doanh nghiệp”, nút chính “Đăng nhập”. Không nhập mật khẩu hoặc submit trên UI trong đợt kiểm này. |
| Console của tab được kiểm | Không có error/warn được công cụ trả lại; không chứng minh tab/proﬁle của tester trước đó không có lỗi |

[Log đã làm sạch](<../../../REFERENCE_LINKS.md#ref-0177>) · [Phép kiểm một lượt](<../../../REFERENCE_LINKS.md#ref-0178>).

Không ghi mật khẩu, hash mật khẩu, cookie, CSRF hoặc token vào báo cáo. Hai cookie phiên/preauth và mã CSRF do API tạo chỉ dùng trong bộ nhớ của client chẩn đoán. Không cấp thêm quyền hoặc mở đường đăng nhập bỏ qua kiểm tra mật khẩu.

## Hướng dẫn tester tiếp tục

1. Dùng đúng `http://127.0.0.1:8025/web/`. Tải lại trước khi nhập để nhận phiên đăng nhập mới. Không luân chuyển sang `localhost` giữa quá trình vì cookie gắn với host.
2. Nếu còn ô “Tên doanh nghiệp” hoặc nút “Tạo hồ sơ & vào trợ lý”, đây là màn tạo tài khoản. Bấm “Đã có tài khoản? Đăng nhập” để chuyển chế độ trước. Sau chuyển, tiêu đề phải là “Mở lại hồ sơ doanh nghiệp”.
3. Nhập `trung@dtt.vn`; lấy riêng phần giá trị ở dòng “Mật khẩu” của tệp đã bàn giao, không gồm nhãn hoặc ký tự xuống dòng. Bấm nút chính “Đăng nhập” một lần.
4. Chờ **điều kiện cụ thể**: form biến mất và xuất hiện điều hướng Hồ sơ/Lịch sử; không chỉ chờ cố định 6 giây. Nếu lỗi, ghi nguyên văn thông báo trong role=alert và HTTP status/mã lỗi đã làm sạch. Nếu vẫn pending, ghi pending và thời gian; không kết luận sai mật khẩu từ thời gian chờ.
5. Đăng nhập và đọc lại phiên không gọi Claude. Quy tắc không tự retry có phí không cấm một lần đăng nhập mới có chủ đích sau khi xác định lỗi phiên/nhập liệu. Không dùng điều đó để gửi lại chat, nghiên cứu hoặc ghi quyết định O2.
6. Vòng A dùng `trung@dtt.vn`. Phần hồi quy Trà Sen dùng tài khoản chủ doanh nghiệp thử có đúng dữ liệu Trà Sen; tài khoản chuyên gia không tự có quyền đọc hồ sơ Trà Sen.

## Giả thuyết còn cần kiểm, chưa phải RCA

- Nhầm thao tác chuyển chế độ với submit đăng nhập, hoặc submit khi còn ở màn tạo tài khoản.
- Phiên preauth/CSRF cũ, đổi host, nhiều tab hoặc tiến trình được khởi động lại sau lúc tải form.
- Sao chép sai phần giá trị, hoặc tự động điền thay dữ liệu trên form.
- Server nhận đăng nhập nhưng trình duyệt không giữ cookie, hoặc bước tải workspace sau đăng nhập lỗi.

Không sửa code, reset mật khẩu, mở quyền hoặc ghi một trong các giả thuyết thành nguyên nhân thiết kế đã xác nhận khi chưa tái hiện được. Cần lấy lỗi/HTTP và trạng thái DOM đúng lần thất bại để phân biệt các nhánh. DF-019/043/049 là các biên cần đối chiếu về lỗi theo giai đoạn, bằng chứng end-to-end và composition; chưa tạo DF mới hoặc đóng lớp thiết kế từ kết quả API này.
