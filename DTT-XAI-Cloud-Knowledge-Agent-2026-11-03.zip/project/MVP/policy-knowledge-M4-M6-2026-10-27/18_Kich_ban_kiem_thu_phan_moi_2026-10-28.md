# Kịch bản kiểm thử các phần mới — 28/10/2026

Đối tượng: tester đóng vai chủ doanh nghiệp và người duyệt của DTT. App chính: [8025](http://127.0.0.1:8025/web/). Build đã kiểm qua HTTP khi soạn tài liệu: `policy-cost-approval-2026-10-27`.

**Bản sửa P3 mới đã deploy ngày 28/10:** `cost-card-a11y-2026-10-28`. Tải lại trước khi kiểm A02/A03/A05/A08; [bằng chứng sửa và review](<20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md>). Mốc build ở câu trên là lịch sử lúc soạn kịch bản.

**Đây là kịch bản để chạy, chưa phải báo cáo đã chạy lại.** Các bằng chứng cũ nằm ở [bàn giao 17](<17_Phan_quyen_duyet_chi_phi_trung.md>). Đợt soạn này không gửi Claude, không ghi quyết định tiếp tục hoặc cấp hạn mức.

## 1. Chuẩn bị và phạm vi

- Dùng mobile 390×844, kiểm lại các ca có dấu ★ ở 320×740. Có thêm một profile trình duyệt riêng cho tài khoản khác; không dùng hai tab cùng profile để giả lập hai tài khoản độc lập vì chúng dùng chung cookie.
- A là `trung@dtt.vn`, được duyệt tiếp tục riêng O2. B là tài khoản thử của doanh nghiệp khác đã có; tự đăng nhập bằng mật khẩu đang dùng, không ghi mật khẩu vào báo cáo. Không tạo hoặc sửa tài khoản thật chỉ để test.
- Với A: tải lại đúng host 127.0.0.1 → chuyển từ màn tạo tài khoản sang “Mở lại hồ sơ doanh nghiệp” → nhập thông tin từ tệp riêng → bấm nút chính “Đăng nhập”. Kiểm form biến mất và xuất hiện Hồ sơ/Lịch sử; nếu lỗi phải ghi thông báo/mã HTTP thay vì kết luận sau thời gian chờ cố định. [Đối soát đăng nhập 28/10](<19_Doi_soat_dang_nhap_trung_2026-10-28.md>) xác nhận một lượt API thật thành công; chưa xác định nguyên nhân lỗi UI tester báo.
- O1 là nhánh rà S1/S2 đã lỗi; O2 là nhánh rà wiki/FAQ và checklist từ S3/S4. Nút O2 phục vụ **xây kho tri thức công khai**, không phải lượt tư vấn Trà Sen hoặc ngân sách tester chung.
- **Vòng A chạy trên 8025:** chỉ đọc, xem trước và kiểm checkbox. Không bấm “Cho phép tiếp tục riêng O2”, không bấm Gửi có phí hoặc Nghiên cứu có phí.
- **Vòng B–C chạy trên dữ liệu thử riêng:** được ghi quyết định, giả lập mất mạng/nguồn đổi/thu hồi quyền, review và phát hành mô phỏng. Không sửa nguồn, quyền, đồng hồ hệ điều hành, hạn mức hoặc DB thật để tạo lỗi.
- Mốc bàn giao 27/10: 5 lượt đã gọi, chi phí ước tính 0,217632 USD, O1 lỗi, O2 chưa gọi, chưa có quyết định tiếp tục thật. Đây là **mốc cũ để đối soát**, không mặc định là trạng thái hiện tại. Người phụ trách chụp số liệu lúc bắt đầu đợt test; nếu đã có thay đổi hợp lệ thì ghi mốc mới, không đưa DB về trạng thái cũ.
- Hạn gốc: **07:40:33 ngày 29/10/2026, giờ Việt Nam**. Không đổi giờ máy hoặc tự gia hạn để chạy ca sau mốc này.

## 2. Vòng A — chủ dự án tự test trên app chính, khoảng 15 phút

| ID | Thao tác | Kết quả phải thấy / điều kiện lỗi |
|---|---|---|
| A01 ★ Đúng người duyệt | Tải lại 8025; đăng nhập A; vào Trợ lý; tìm thẻ “Kho chính sách: một nhánh cần quyết định”. | Hiện đúng `trung@dtt.vn`. Có thể xem phạm vi/chi phí và đọc lại trạng thái. Nếu đã có quyết định thật trước đợt test, thẻ phải phản ánh quyết định đó; không yêu cầu làm lại. |
| A02 ★ Thông tin đủ để quyết định | Mở “Phạm vi và chi phí”. | Nêu O1 giữ lỗi/chi phí; O2 dùng S3/S4; Opus 5.5, trần 0,50 USD cho O2 và hạn gốc. Phân biệt chi phí ước tính với hóa đơn thực; không cộng ngân sách tư vấn doanh nghiệp vào quỹ xây kho. |
| A03 ★ Không đồng ý sẵn | Nếu batch còn đủ điều kiện và chưa được duyệt, bấm “Xem quyết định O2 · miễn phí”. Thử khi checkbox chưa tích, tích rồi bỏ tích. **Không bấm nút cho phép.** | Checkbox ban đầu trống; nút cho phép bị khóa → mở khi tích → khóa khi bỏ. Có giải thích đây chỉ ghi quyết định, chưa gọi Claude. Thiếu ô đồng ý hoặc nút mở khi chưa tích là lỗi. |
| A04 Tải lại trước xác nhận | Sau xem trước, bỏ tích và tải lại. Mở xem trước lần nữa nếu còn đủ điều kiện. | Không tự ghi quyết định, không tự gửi AI, không giữ sự đồng ý mặc định. Không báo “đã duyệt” từ một lần xem trước. |
| A05 Đọc lại nhiều lần | Bấm “Đọc lại trạng thái” 3 lần, tải lại trang, vào Hồ sơ rồi quay lại Trợ lý. | Không tăng lượt, không tăng phí do các thao tác đọc, không sinh quyết định mới. Không còn nút/khung lỗi kẹt hoặc thông báo thành công giả. Đối soát server với mốc đầu đợt test; không chỉ nhìn UI. |
| A06 ★ Cách ly hai profile | A mở thẻ và xem trước. Ở profile riêng đăng nhập B, vào Trợ lý, Lịch sử, Hồ sơ. Sau đó đăng xuất A và đăng nhập B trong profile A. | B không thấy thẻ, quyết định, batch hay chi phí của A. Không mang hồ sơ/lịch sử của A sang B. A vẫn đọc được trạng thái khi đăng nhập lại; B không được tự nhận quyền duyệt từ vai trò chủ doanh nghiệp. |
| A07 ★ Phản hồi chậm không lộ tài khoản | Người kiểm kỹ thuật làm chậm phản hồi status/preview; khi đang chờ thì đăng xuất và đổi sang B. | Phản hồi cũ không hiện thẻ của A trên B. Không cần cố tạo bằng DB thật; nếu không điều khiển được độ trễ, ghi “chưa kiểm”, chạy lại bằng fixture ở vòng B. |
| A08 ★ Mobile và trình đọc màn hình | Kiểm thẻ mở/gập, checkbox và nút ở cả 390/320 px; mở bàn phím; dùng đọc màn hình/Tab nếu có. | Không tràn ngang hoặc che nút; nút/checkbox ≥44 px; có nhãn; trạng thái và lỗi được thông báo; mở/gập có trạng thái phù hợp. Đóng/mở chi tiết không làm mất xác nhận ngoài dự kiến. |

**Điểm dừng vòng A:** lưu ảnh và số liệu trước/sau. Nếu muốn kiểm nút ghi quyết định thật, cần chuyển sang một đợt kiểm đã chỉ định rõ việc ghi quyết định đó. Quyền của A không có nghĩa tester được dùng tài khoản A để tự chấp thuận chạy O2.

**Bổ sung A06:** sau khi bấm Đăng xuất, đọc trạng thái hiện tại trước. Nếu tiêu đề đã là “Mở lại hồ sơ doanh nghiệp” thì nhập B và bấm nút chính “Đăng nhập” ngay; không bắt buộc tìm link “Đã có tài khoản? Đăng nhập”. Link chuyển chế độ chỉ hiện khi đang ở màn tạo tài khoản. Hai ca P3 về disclosure/live region có [RCA và bước kiểm lại riêng](<20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md>).

## 3. Vòng B — các tình huống đặc biệt, chỉ trên fixture riêng

Người phụ trách dựng app giống bản đóng băng với DB tổng hợp, provider giả và đường gọi provider thật bị vô hiệu hóa. Mỗi ca đòi trạng thái ban đầu mới dùng fixture mới; không xóa receipt hoặc sửa lịch sử để chạy lại. Fixture mobile 8033 của lần review trước **đã dừng**, không coi đó là môi trường hiện sẵn.

### B01 ★ Ghi quyết định → tải lại → không gọi AI

1. Đăng nhập người được giao quyền trong fixture; mở xem trước, tích rồi bấm cho phép đúng một lần.
2. Phải hiện “Đã ghi quyết định tiếp tục riêng O2” và giải thích chưa gọi Claude từ thao tác này.
3. Tải lại, bấm đọc trạng thái, mở lại cùng hồ sơ. Quyết định vẫn còn; không yêu cầu đồng ý lại cho quyết định đã ghi.
4. Kiểm receipt ghi đúng account ID, mã quyết định và đầu vào S3/S4. O1/raw/usage/lỗi, trần tiền và hạn gốc giữ nguyên; không tạo attempt O2 hoặc gọi provider từ thao tác duyệt.

### B02 Bấm đúp và hai tab cùng duyệt

Mở cùng batch ở hai tab của cùng tài khoản. Bấm đúp nút duyệt ở tab 1 và thử duyệt từ tab 2 với bản xem trước cũ. Cùng command phải trả cùng receipt; command khác dựa trên head cũ phải bị chặn/đối soát. Không có hai permit, không tăng tiền/lượt, không chạy lại O1. Ghi rõ kết quả từng tab, không chỉ ghi “nút đã khóa”.

### B03 ★ Mất phản hồi ở hai thời điểm

- Trường hợp 1: yêu cầu chưa tới server thì mất kết nối.
- Trường hợp 2: server đã commit nhưng trình duyệt chưa nhận receipt thì mất kết nối.

Ở mỗi trường hợp: khôi phục mạng rồi tải lại. Không tự POST/gọi AI. Dùng “Đối chiếu quyết định trước · không gọi AI” khi có quyết định chờ: phải dùng đúng mã và nội dung cũ. Nếu chưa commit, đối chiếu có thể hoàn tất **quyết định đã được đồng ý trước đó** khi các điều kiện còn đúng; nếu đã commit, phải trả receipt cũ. Không âm thầm tạo mã mới hoặc nhân đôi quyền. Lỗi phải rõ, không cùng lúc báo chưa ghi và đã ghi.

### B04 Thu hồi quyền: ghi mới khác đọc lịch sử

Sau một quyết định đã commit trong fixture: thu hồi phân công duyệt. Quyết định mới bị chặn; đọc lại đúng receipt vẫn được nếu quyền READ nguồn còn. Tiếp tục thu hồi READ nguồn: đọc lại cũng phải bị chặn. Chỉ thu hồi EXPORT phải chặn hành động xuất/dùng mới cần EXPORT, không tự chặn READ còn hợp lệ. Không dùng quyền owner/chuyên gia để đi vòng.

### B05 Nguồn hoặc S3/S4 thay đổi sau xem trước

Xem trước → tạo phiên bản nguồn hoặc bản nháp mới trong fixture → gửi quyết định cũ. Phải bị từ chối, yêu cầu đối chiếu bản mới; không tự đổi đầu vào trong quyết định cũ. Lặp tình huống nguồn/quyền đổi giữa lúc giữ hạn mức và trước gửi: shared Gateway phải chặn trước provider và giải phóng khoản giữ. Receipt lịch sử giữ nguyên theo quyền READ.

### B06 Hết hạn hoặc chưa đối soát được chi phí

Dùng fixture đã hết hạn, hết lượt, hoặc có kết quả/usage chưa rõ. Không được ghi tiếp tục hay dispatch bằng cách sửa tham số trình duyệt. UI phải nói rõ cần xử lý điều kiện nào, không báo vẫn có thể chạy từ một số dư tiền đơn lẻ. Không tự gia hạn, cấp quỹ mới, đổi model hoặc retry.

## 4. Vòng C — kho tri thức và bàn giao cho agent khác

Các ca này kiểm những phần mới của M6-next, **không mặc định đã có màn review mô phỏng trên 8025**. Màn `/knowledge/simulation` chỉ được bật trong host testing riêng. Fixture có nội dung tổng hợp, không dùng để chấm đúng/sai chính sách Hà Nội thật.

| ID | Nội dung kiểm | Tiêu chí đạt |
|---|---|---|
| C01 Gói đầu ra đúng yêu cầu | Đọc gói demo đã lưu/fixture: tổng quan, FAQ và checklist. | Đúng 5 câu hỏi–trả lời, checklist 5–7 việc. Mỗi nhận định có ID và căn cứ đúng phiên bản/đoạn, hoặc nêu rõ thiếu căn cứ. Không gọi “đã hoàn thành tư vấn” chỉ vì JSON hợp lệ. Không ép S3/S4 cũ đạt schema mới bằng sửa raw. |
| C02 Handoff tự đủ thông tin | Giao `agent-handoff` cho reviewer không có lịch sử chat. | Có START_HERE, manifest/hash, artifact, evidence và mẫu/schema review theo manifest. Agent tìm được nguồn từng mục, biết phần chưa rà và cách nộp. Không phải hỏi lại nguồn ở chat hoặc có quyền chi tiền. |
| C03 Review thiếu/sai phải bị chặn | Nộp JSON hỏng; thiếu một target; trùng target; sai hash; đánh dấu đạt nhưng vẫn có mục chưa rà. Sau đó nộp bản hợp lệ theo rubric. | Có lỗi rõ; bản sai không ghi thành công; bản đúng có receipt. Không bỏ mục khó để biến cả gói thành đạt. Nộp lại cùng operation/nội dung không nhân đôi receipt. |
| C04 ★ Mô phỏng không thành duyệt thật | Dùng tài khoản testing được giao scope, lưu review rồi phát hành riêng môi trường thử. | Hiện nhãn mô phỏng; không dùng danh tính chuyên gia thật. Bảng review/release production và kho tư vấn thật không đổi; không cập nhật SSOT doanh nghiệp hoặc cho phép chạy AI. |
| C05 Nguồn đổi sau review | Review bản cũ → tạo nguồn/target hash mới → thử phát hành mới từ review cũ. | Bị chặn vì target đã đổi; cần review bản mới. Historical receipt đọc theo quyền hiện hành, không viết lại review cũ hoặc tự đổi hash. |
| C06 Ba mức tiền và phản hồi lỗi | Kiểm tự động profile cao/trung/thấp và provider giả trả JSON thiếu/metadata lỗi. | Manifest ghim profile/price version; giữ cùng đầu vào và mô hình khi so mức tiền; tính đủ input/thinking/text. Không đủ trần thì báo không khả thi và không dispatch. Phản hồi lỗi vẫn giữ raw/usage/metadata được phép, không xóa chi phí hoặc tự retry. |

**Kiểm chất lượng với dữ liệu Claude đã lưu:** nếu người phụ trách cung cấp gói nguồn/đầu ra công khai được phép đọc, chấm riêng độ đúng, độ đủ và tính hữu dụng. Không coi C01–C06 đạt bằng fixture là chứng minh Claude thật trả lời tốt. Mỗi thiếu sót phải phân loại: nguồn thiếu, intent/task bỏ sót, tổng hợp sai, validation sai hay UI làm rơi nội dung.

## 5. Hồi quy ngắn bằng câu chuyện Trà Sen

Chạy trên tài khoản/DB thử, dùng kết quả cũ hoặc đường trích miễn phí rõ nhãn; không nhấn Gửi có phí để tạo câu trả lời mới.

Dùng **tài khoản chủ doanh nghiệp thử sở hữu dữ liệu Trà Sen**, không mặc định dùng `trung@dtt.vn`. Quyền chuyên gia/duyệt chi phí không cấp READ hồ sơ và hội thoại riêng của doanh nghiệp khác.

1. Tạo sản phẩm thử “Trà Sen Tây Hồ”, xác nhận riêng tên và mã TS01 trước; các dữ kiện chưa chọn vẫn có đường xác nhận tiếp sau tải lại.
2. Từ câu “Chị có Trà Sen Tây Hồ, hộp 100 g, mã TS01”, trích đúng vào nháp của sản phẩm đang chọn. Sau đó chuyển sang “Mứt sen sấy, túi zip 200 g, mã MS02”: không lấy nhầm 4 dữ kiện Trà Sen; không tạo trùng khi chỉ đổi hoa/thường.
3. Lưu từng nháp; thẻ cũ, Hồ sơ và số phiên bản phải cùng phản ánh kết quả thật. Lưu sai phải có lý do, không giữ thông báo thành công của lần trước.
4. Đọc lại kết quả chính sách đã có cho hai nhu cầu “hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách”: phải giữ cả hai mục; mục thiếu nguồn nói rõ thiếu. Không biến câu trả lời mô phỏng thành chính sách đã duyệt.
5. Kiểm Hồ sơ/Lịch sử của tài khoản doanh nghiệp khác: không đọc được SSOT, nháp hoặc hội thoại Trà Sen. Số lượt/chi phí không tăng từ đọc lại kết quả cũ.

## 6. Khi nào mới kiểm Claude thật?

Đợt test này mặc định không có lượt trả phí mới. Trước đợt thật cần manifest nêu rõ model, nguồn/bản nháp ghim, số lượt, trần từng lượt/tổng phí, thời hạn và quy tắc dừng. Quỹ tester không tự thay thế quyền xây kho.

- Tiếp tục riêng O2 cần quyết định thực sự của người được giao quyền và worker đã được đối soát/ghim tương thích v2. Paid launcher C6 cũ chưa được đổi chỉ vì đã có nút duyệt trên web.
- Pilot 3 mức tiền là đề xuất riêng chưa được cấp; không tự dùng slot O2 còn lại cho pilot. Đầu ra thật được chấm theo C01 và rubric chuyên gia, gồm cả phần thiếu căn cứ.
- Nếu lượt thật lỗi: lưu lỗi/phí/raw và dừng. Không tự retry, fallback hoặc dùng slot khác khi chưa có quyết định tiếp tục phù hợp.

## 7. Mẫu biên bản cho tester

```text
Build / thời gian và múi giờ:
Môi trường: main8025 chỉ đọc / fixture riêng (đường dẫn hoặc ID):
Viewport / trình duyệt / tài khoản A,B (không ghi mật khẩu):
Mốc đầu: lượt, phí ước tính, trạng thái O1/O2, quyết định hiện có:

ID ca:
Các bước thực tế và câu nhập nguyên văn:
Kỳ vọng:
Kết quả: đạt / lỗi / chưa kiểm / bị chặn vì điều kiện môi trường:
Ảnh hoặc log đã làm sạch:
Mã quyết định/receipt nếu có (không ghi token/session):
Lượt/phí/SSOT trước → sau:
Mức nghiêm trọng và ảnh hưởng:
RCA đã chứng minh hay mới là giả thuyết; DF liên quan:

Tổng kết: ca đã chạy, ca chưa chạy và lý do; số lượt Claude mới thực sự:
```

**Dừng ngay nếu:** lộ dữ liệu tài khoản khác; thao tác đọc tạo lượt/phí; duyệt tạo attempt hoặc gọi AI; O1 bị sửa thành đạt; mô phỏng thành phát hành thật; SSOT ghi nhầm sản phẩm. Giữ bằng chứng, không reset/xóa dữ liệu để test xanh.

Đối với lỗi đã xác nhận RCA, cập nhật [DESIGN_FLAWS](<../architecture/DESIGN_FLAWS.md>) trong cùng đợt sửa, tách bản vá khỏi điều kiện đóng thiết kế. Truy vết chính: DF-014/016/021/025/026/027/029/033/043/044/046/048/052/053/056/057/061/062. Tài liệu kịch bản này không tạo RCA mới hoặc đóng lớp thiết kế nào.

Ưu tiên chạy A01–A08 trước; sau đó B01–B06 và C01–C06 bằng fixture, cuối cùng mới trình vòng nghiệm thu Claude thật nếu cần. Từng ca phải có kết quả riêng, không ghi “toàn bộ đạt” từ review cũ.
