# M4 — dùng lại tri thức theo nhu cầu, giữ riêng hồ sơ doanh nghiệp

**Đã đạt gate kỹ thuật ởcandidate4:** [review cuối](<../../../REFERENCE_LINKS.md#ref-0094>) · [bàn giao và phạm vi](<03_Ban_giao_M4.md>). Các trạng thái chờ review/blocked bên dưới giữ lịch sử của từngcandidate. M5 bắt đầu sau signoff này; chưa coi nguồn thật đủ hoặc đã phát hành.

**Mới nhất — candidate3 đang review:** [Candidate2 review](<../../../REFERENCE_LINKS.md#ref-0095>) xác nhận2lỗi host/nháp đã đạt, nhưng phát hiện F03 nguồn cũ có thể được dùng lại sau rewind pointer/gate. Đã bổ sung source-control causal chain và legacy failclosed, đóng băng [candidate3](<../../../REFERENCE_LINKS.md#ref-0096>), SHA256`b4edb1c208c9f91b7af372ebe27ea87cead6facbc728cb2fa3a51d068ebdcc82`. Chưa qua gate M4, chưa triển khai8025. Lịch sử/SSOT/raw giữ nguyên, không gọi AI.

**Cập nhật gate:** [review candidate1](<../../../REFERENCE_LINKS.md#ref-0097>) tìm2blocker: hostroute bịcatch-all nuốt và DOM nháp riêng còn sau đổi phiên. Đã sửa, đóng băng [candidate2](<../../../REFERENCE_LINKS.md#ref-0098>), rawSHA256`feff1c04a705a9486eede47709ccf7beb5367db10910734f765ca5954eb31a60`; reviewer đang kiểm lại. Chưa chuyểnM5. Ảnh bên dưới là flowchat candidate1, không dùng làm chứng cứ màn chuyên gia candidate2.

27/10/2026. **Bản kiểm kỹ thuật, chưa phát hành chính sách thật.** App8025 chưa đổi. Candidate1: [manifest](<../../../REFERENCE_LINKS.md#ref-0099>), **raw SHA256 `042a5350ee989e04c8fb90cfb1cc3d973e66638fcf02f296ee5d72e9e0eba13a`**. Hash `f51576…` công bố đầu tiên là chuỗi JSON LF trước khi ghi ra Windows; đã đính chính, không sửa manifest hoặc431file frozen. Xem DF-042.

## Chủ cơ sở Trà Sen trên mobile

Môi trường riêng8034, cookie riêng, tài khoản và nguồn đều THỬ NGHIỆM. Không đọc .env, không gọi Claude/Internet; provider bị chặn trong fixture. Phân quyền và thao tác xác minh/phát hành ở fixture chỉ tạo tình huống kiểm, không đại diện quyết định chuyên gia thật.

1. Đăng nhập tài khoản thử, thấy ba dữ kiện doanh nghiệp đã xác nhận. Chọn Chính sách Hà Nội trong trợ lý.
2. Gửi: “Chị cần hỗ trợ xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách buổi tối. Có đủ điều kiện không?” bằng nút tra cứu nguồn miễn phí.
3. Chat giữ nguyên câu hỏi. Trợ lý nói ngay: có phần giải thích đã duyệt cho một nhu cầu, nhu cầu còn lại chưa đủ nguồn; điều kiện hưởng và tiếp nhận cần căn cứ riêng.
4. Hai nhu cầu có dòng riêng. Xuất khẩu thiếu bản phát hành phù hợp, không dùng chính sách đào tạo/số hóa thay thế. Đào tạo có giải thích; yêu cầu **buổi tối** vẫn được giữ và báo chưa có căn cứ xác nhận lịch học.
5. Mở phần giải thích để xem nội dung và nguồn gốc. Chuẩn bị hồ sơ/kiến nghị vẫn là bản nháp riêng, chưa gửi cơ quan.
6. Tải lại chỉ đọc hồ sơ đã lưu, không gọi AI. Console sau vòng này:0errors/0warnings. DOMđo được viewport320px/scrollWidth320px, không tràn ngang.

![Chat hai nhu cầu ở320px](<../../../REFERENCE_LINKS.md#ref-0100>)

Ảnh và thao tác trên do tác giả tự chạy; chưa thay review độc lập. Reviewer đang kiểm trên frozen candidate ở môi trường khác.

![Tải lại vẫn giữ câu hỏi và hai nhu cầu](<../../../REFERENCE_LINKS.md#ref-0101>)

## Hợp đồng và kiểm đã có

- 67ca backend liên quan M3/M4/workbench đạt ở working byte trước freeze;2ca host/MCP mới đạt riêng. Không cộng thành một full-run.
- Frozen candidate1:357ca frontend hồi quy đạt. Bộ backend rộng M1–M4/CoreGateway/Policy: **262/262đạt**,484,70giây; [log](<../../../REFERENCE_LINKS.md#ref-0102>). Đây là hai bộ chạy riêng, không cộng thành một full-run.
- Qualification runtime ngoài candidate:1ca đạt trên frozen source, kiểm nguyên dữ liệu trước/sau migration, exact receipt replay không backup lại, managed factory không ghi DB và thiếu trigger bị chặn trước rehearsal. Lượt harness đầu sai giả định `IncludedRouter.path`, đã sửa phép kiểm thành HTTPthực, không đổi source hoặc bỏ assertion kiểm route.
- Hai doanh nghiệp dùng chung exact public release refs nhưng context manifest và SSOT khác; không đưa câu hỏi/facts vào public lookup.
- SourceREADrevoke chặn cả bản cũ; withdraw giữ lịch sử và chặn tư vấn mới. Applicability/review/release ghim exactrevision; gắn scope sau review làm review cũ không đủ.
- Gateway giữ một ledger/transport: replay kiểm READ; reserve/fence kiểm current-use+EXPORT. Model chỉ chọn sectionID hữu hạn, không biến wiki thành quy tắc điều kiện hưởng.

## Phần chưa nghiệm thu

Chưa có legal gold thật, chưa có chuyên gia duyệt S1, chưa xuất bản wiki thật. M4 không lấy phép thử nguồn giả làm chứng cứ chính sách đủ/hiện hành. QA enterprise bằng Claude thật được dời sang M5 sau rehearsal/cutover trên authority ngân sách gốc; không nhân đôi quỹ tester sang clone.

DF được truy vết: **DF-014/024/025/027/029/033/046/049**, phần thiết kế còn mở ghi ở [RCA](<01_RCA_va_hop_dong_M4.md>) và [sổ gốc](<../architecture/DESIGN_FLAWS.md>). M5 chỉ bắt đầu sau reviewer xác nhận gate M4 kỹ thuật.
