# M5 — triển khai local, bảo toàn hồ sơ và hạn mức

27/10/2026. **Đã triển khai; reviewer xác nhận M5b không còn blocker trong phạm vi kỹ thuật.** M5a đã SCOPED PASS. M6 chuyển tiếp theo gate kỹ thuật này; không dùng biên bản trước cutover thay kết quả app thật hoặc quyết định chuyên gia.

## Bản đang chạy

- App: http://127.0.0.1:8025/web/ ; workbench: http://127.0.0.1:8025/knowledge/.
- Build `policy-knowledge-m5-2026-10-27`; runtime contract `nmate-main-20261027-knowledge-m4`.
- Candidate2:437file, raw manifest SHA256 `eaff60188236c8b0527d769a61d7b2d6b9356def8a46e9f7f90d5c485345dd34`.
- [Identity operator](<../../../REFERENCE_LINKS.md#ref-0107>) ghim công cụ đã review; khởi động và cutover dùng cùng bootstrap kiểm identity ngoài bundle.
- Thời điểm chuyển bản10:43 ngày27/10(UTC+7); listenerPID101176, launcher25212. Không dùng PID làm identity lâu dài; kiểm lại commandline/manifest nếu khởi động lại.

## Bằng chứng

[Review M5a](<../../../REFERENCE_LINKS.md#ref-0108>) kiểm29ca operator độc lập,4bootstrap và12runtime/lock/host. Mobile môi trường riêng320/390, hai nhu cầu→nháp→reload, SSOT không đổi,0attempt. Root có9ca operator sau chỉnh cuối,6ca bundle/bootstrap,14runtime/host; các bộ chạy riêng, không cộng thành một full-run.

[Cutover thật](<../../../REFERENCE_LINKS.md#ref-0109>) dùng đúng4plan qua schema operator chung.100bảng cũ nguyên vẹn, thêm đúng4receipt, không backfill SSOT/source anchor hoặc cấp role/grant. Managed factory0ghi. Backup mới và lệnh khởi động cũ được giữ riêng; không liên kết tệp chứa dữ liệu riêng trong walkthrough công khai.

[HTTP/schema audit](<../../../REFERENCE_LINKS.md#ref-0110>): HTML và3asset khớp byte, schema135bảng bắt buộc/141bảng hiện có, nguồn chuẩn152seed. Core attempts16 và legacy15 giữ nguyên; domain attempts0. Wiki/review/release thật0. Không có lượt AI/phí mới từ nâng cấp hoặc audit.

Lần audit đầu lấy mọi HTML trong package làm public route và gặp401 ở QA document không mount. Đã sửa công cụ audit theo public entrypoint/HTMLParser; không nới route hoặc thay app để làm audit đạt. Giữ giới hạn bằng chứng của phép kiểm.

## Dùng thử và giới hạn

[Kịch bản test](<05_Kich_ban_test_local_M5.md>) · [vận hành](<06_M5_Ghi_chu_van_hanh.md>) · [kế hoạch và phục hồi](<04_M5_Ke_hoach_trien_khai.md>).

Không có wiki thật đã phát hành, nên QA Claude dùng wiki mới ghi `not_run_no_released_corpus`. Không gọi có phí chỉ để lấp cổng nội dung. Nháp M3 ở staging chưa chuyên gia duyệt, nguồn pháp lý vẫn thiếu; đây là triển khai lõi kỹ thuật, không chứng nhận hoàn thành K1 nội dung.5slot M3 còn pause, chưa mở lại khi chưa có câu trả lời phê duyệt tiếp tục.

RCA sửa trong M5: DF-042(identity bootstrap), DF-043(quiescence phải phủ host state), DF-049(contract schema ghim qua CLI). Các lớp thiết kế vẫn D1; root-of-trust đa máy, lifecycle của workflow mới và legalgold còn mở.

## Đối soát độc lập sau triển khai

[Review M5b cuối](<../../../REFERENCE_LINKS.md#ref-0111>) SCOPED TECHNICAL PASS. Reviewer tự GET6asset main/workbench, đối chiếu process101176/parent25212 với approved bootstrap, schema M4,4receipt mới và receipt cũ. Tự hash100bảng cũ so freshbackup đều nguyên vẹn; core16/legacy15/domain0, wiki/review/release0. Browser anonymous320px chỉ hiện đăng ký, không lộ hồ sơ. Không đăng nhập/tạo account, ghi MAIN hoặc gọi AI. Flow có xác thực ở môi trường synthetic trước cutover được giữ bằng chứng riêng; không nhận đã lặp lại flow đó trên dữ liệu thật. ActualClaude/legalcorpus `not_run`.
