# Phân công duyệt tiếp tục riêng O2 — trung@dtt.vn

Ngày 27/10/2026. Người dùng đã chọn trực tiếp tài khoản `trung@dtt.vn` để nhận quyền duyệt chi phí cho nút tiếp tục riêng O2. Đây là phân công người duyệt; chưa phải quyết định tiếp tục batch, cấp tiền hoặc yêu cầu gọi Claude.

## Phạm vi được giao

- Đọc trạng thái, xem trước và ghi quyết định tiếp tục riêng O2 trong đúng batch kho chính sách công khai đã được duyệt trước đây.
- Tài khoản, tên đăng nhập, đường dẫn dữ liệu chính và batch công khai được ghim trong cấu hình phía máy chủ. Tài khoản khác, kể cả chủ doanh nghiệp hoặc chuyên gia, không có quyền này từ vai trò hiện có.
- Quyền chuyên gia rà soát/phát hành hiện có của `trung@dtt.vn` giữ nguyên. Không mở thêm quyền xem hồ sơ doanh nghiệp, không cấp quyền chi tiền cho agent mô phỏng chuyên gia.
- Trần gốc giữ nguyên: Sonnet 0,25 USD/lượt, Opus 0,50 USD/lượt, toàn batch 6 lượt/2 USD; hết hạn 07:40:33 ngày 29/10/2026 (giờ Việt Nam). Phân công không gia hạn hoặc cấp thêm lượt.

## Quy trình trên app chính

**Thông tin đăng nhập:** mật khẩu ban đầu lưu trong [tệp riêng trên máy](<../../../REFERENCE_LINKS.md#ref-0168>). Ngày 28/10/2026 đã kiểm chỉ đọc và xác nhận mật khẩu trong tệp vẫn khớp tài khoản đang hoạt động; không đặt lại mật khẩu, tạo phiên hoặc thay quyền/dữ liệu. Không sao chép nội dung mật khẩu vào tài liệu/chat. Đây là tệp có sẵn từ lần tạo tài khoản, không phải mật khẩu mới cấp cùng quyền O2.

1. Đăng nhập bằng `trung@dtt.vn` tại [app 8025](http://127.0.0.1:8025/web/), tải lại để nhận bản mới khi đã triển khai.
2. Trong Trợ lý, thẻ “Kho chính sách: một nhánh cần quyết định” cho biết O1 giữ lỗi và chi phí, O2 là nhánh rà riêng hai bản nháp S3/S4.
3. “Xem quyết định O2 · miễn phí” chỉ đọc và đối chiếu đầu vào. Tích xác nhận rồi mới có thể ghi quyết định. Hệ thống gắn quyết định với tài khoản thực, đầu vào, nguồn và mốc trạng thái gốc.
4. Ghi quyết định không gọi Claude. Sau tải lại hoặc mất phản hồi, thao tác đối chiếu dùng đúng mã quyết định trước để đọc biên nhận; không tự tạo quyết định hay lượt AI khác.
5. O1 vẫn bị từ chối, không hoàn phí, không sửa thành đạt, không chạy lại. Không tự phát hành tri thức sau quyết định O2.

**Giới hạn vận hành:** launcher trả phí cũ C6 vẫn được giữ nguyên. Trước khi chạy O2 thật cần đối soát và ghim worker hỗ trợ hợp đồng quyết định v2 đã kiểm thử; không dùng launcher cũ để suy đoán quyền hoặc sửa quyết định. Đợt này chưa thực hiện bước chạy O2.

## Thiết kế

- `ApproverAssignment` là quyền ghi quyết định hẹp, tách khỏi ngân sách D06, quyền chuyên gia D07 và quyền hồ sơ D04/D05.
- HTTP dùng phiên đăng nhập và CSRF hiện có; trình duyệt không chọn tài khoản thực thi, đường dẫn dữ liệu hoặc tập nguồn. Quyết định phiên bản 2 ghi tài khoản thật và identity của phân công; hợp đồng operator phiên bản 1 giữ nguyên.
- Quyết định mới kiểm quyền hiện hành, CAS và nguồn hiện hành. Đọc lại đúng biên nhận kiểm quyền READ, không dựng lại WRITE/default theo trạng thái mới.
- Shared Gateway kiểm lại phân công khi giữ hạn mức và ngay trước lúc gửi. Thu hồi quyền trong khoảng này chặn trước provider và giải phóng khoản giữ.
- Không có bảng role/budget mới, migration, transport, retry hay thẩm quyền ngân sách thứ hai. Cấu hình được ghim độc lập với bản phát hành, kiểm trước khi đọc cấu hình khóa API.
- Callback trình duyệt gắn tài khoản, doanh nghiệp và thế hệ màn hình; chuyển phiên không nhận kết quả cũ. Nút và ô xác nhận tối thiểu 44 px.

## Bằng chứng kiểm thử

- Author: 5 ca trong một lần chạy, gồm ghép vào app chính và đường biên độc lập cũ; không dùng provider thật. [Log](<../../../REFERENCE_LINKS.md#ref-0169>).
- Review độc lập bản làm việc: 17 ca khác nhau qua các lần chạy được ghi rõ, không cộng thành một full run giả. [Review](<../../../REFERENCE_LINKS.md#ref-0170>).
- Bản đóng băng `M5-cost-candidate1`: 465 tệp, manifest SHA `a896231b65ec09f1f24aa0963583ffe6ca3a96aac518666433fb152f13b44cf0`.
- Rehearsal app trên bản sao riêng: schema đạt, HTTP chưa đăng nhập trả 401, 141 bảng không đổi, không migration/cấp tiền/ghi quyết định/gọi AI. [Biên bản](<../../../REFERENCE_LINKS.md#ref-0171>).
- Đối soát phân công thật chỉ đọc: đúng tài khoản, batch vẫn 5 lượt, O1 blocked, O2 chưa gọi; bảng dữ liệu chính và batch không đổi. [Biên bản](<../../../REFERENCE_LINKS.md#ref-0172>).
- Rehearsal lần đầu dừng vì phép kiểm của script giả định router phải xuất hiện trực tiếp trong danh sách route; FastAPI ghép router lười. Đã thay bằng kiểm HTTP thực và giữ log cũ. Đây là lỗi công cụ kiểm, không phải RCA sản phẩm.

## Kết quả cuối và triển khai

- [Review độc lập C1](<../../../reference/reviews/Cost-approval-C1.md>): một lần chạy 17 ca độc lập đạt trên đúng bản đóng băng; reviewer kiểm toàn bộ 465 tệp và hash. Mobile 320/390 px trên app chính dùng fixture riêng ở 8033: xem trước, đồng ý, ghi quyết định, tải lại, đọc lại và đăng xuất/đổi tài khoản đều đạt. Nút/ô xác nhận ≥44 px, không tràn ngang, console không lỗi/cảnh báo. Chỉ ghi quyết định vào fixture, không batch thật. Ảnh kiểm tra nằm trong luồng công cụ của reviewer, không có bộ ảnh file riêng.
- [Hồi quy app chính](<../../../REFERENCE_LINKS.md#ref-0173>): một lần chạy riêng 8 ca HTTP/Gateway và khóa runtime đạt; provider được giả lập, không đọc khóa hoặc gọi Claude thật.
- Đã chuyển local 8025 sang build `policy-cost-approval-2026-10-27`, giữ nguyên schema hiện tại. [Biên nhận chuyển bản](<../../../REFERENCE_LINKS.md#ref-0174>) và [xác minh sau khởi động](<../../../REFERENCE_LINKS.md#ref-0175>): 141 bảng giống bản sao trước chuyển, asset đúng bản ghim, API duyệt từ phiên chưa đăng nhập trả 401. Không có tác vụ đang xử lý tại thời điểm đổi bản.
- [Đối soát thật sau triển khai](<../../../REFERENCE_LINKS.md#ref-0176>): đúng `trung@dtt.vn`, có quyền xem trước/ghi quyết định, vẫn 5 lượt cũ; O1 blocked và O2 chưa gọi, chưa ghi quyết định tiếp tục thật, không thêm hạn mức/chi phí.
- Không đăng nhập thay tài khoản người dùng trên main, không tạo phiên hoặc đổi mật khẩu để chứng minh UI. UI có đăng nhập được kiểm độc lập trên fixture 8033; triển khai main được kiểm bằng HTTP chưa đăng nhập và đối soát quyền thật chỉ đọc.

**Cách kiểm nhanh:** tải lại app 8025 → đăng nhập `trung@dtt.vn` → vào Trợ lý → xem thẻ kho chính sách và bấm xem trước miễn phí nếu cần. Chưa muốn tiếp tục O2 thì không tích/ghi quyết định. Không cần gửi câu chat có phí để kiểm phân quyền.

**Còn mở:** quyết định O2 thật, worker trả phí tương thích v2 và nghiệm thu nội dung/chuyên gia D07 vẫn là các bước riêng. Không suy ra đã gọi O2 hoặc đã nghiệm thu nội dung chính sách từ các ca giả lập này.

Truy vết thiết kế: DF-016, DF-021, DF-029, DF-033, DF-044, DF-046, DF-048, DF-052, DF-053, DF-056, DF-057. Chưa có nguyên nhân thiết kế mới được chứng minh trong phạm vi này; các lớp thiết kế vẫn D1, không đóng D2 dựa trên fixture.
