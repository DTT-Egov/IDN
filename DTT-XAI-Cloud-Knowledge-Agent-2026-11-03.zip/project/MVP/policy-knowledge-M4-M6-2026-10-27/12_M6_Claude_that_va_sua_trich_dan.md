# M6 — kết quả Claude thật và sửa hợp đồng trích dẫn

Ngày27/10/2026. **Đã chạy thêm đúng một lượt S2; batch dừng theo quy tắc đã duyệt. Bản sửa đã qua review độc lập và phục hồi proposal S2 miễn phí, giữ nguyên trạng thái dừng.** App chính 8025 không đổi. [Bản nháp để chuyên gia đọc](<S2_Ban_nhap_de_chuyen_gia_ra_soat.md>) có5nhận định và6trích dẫn gắn đúng vị trí nguồn, chưa được chuyên gia duyệt hoặc phát hành.

**Mốc sau đợt S2 này:** người dùng đã cho tiếp tục bốn slot; S3/S4 có nháp, O1 nhận JSON dở dang và O2 chưa gọi. Hiện toàn batch5lượt/ước0,217632USD, vẫn dừng. [Báo cáo mới nhất](<13_M6_Ket_qua_4_slot_Claude.md>); bảng số liệu dưới đây giữ riêng mốc S2 trước đó.

## Lượt thật đã diễn ra

Người dùng đồng ý tiếp tục đúng năm slot gốc sau gate kỹ thuật M6. Operator ghi [quyết định người dùng](<../../../REFERENCE_LINKS.md#ref-0145>) và [biên nhận tiếp tục](<../../../REFERENCE_LINKS.md#ref-0146>), giữ nguyên grant/instance/corpus và hạn07:40:33 ngày29/10/2026, UTC+7. Không lấy quỹ tester hoặc cấp lại hạn mức.

S2 dùng `claude-sonnet-5-5`,6.835 token đầu vào và1.549 token đầu ra. JSON đạt schema; có5 nhận định và6 tham chiếu trích dẫn. Năm câu trích khớp chính xác, một câu khác cách xuống dòng của PDF. Adapter exact-only từ chối tạo proposal và ghi pause; S3/S4/O1/O2 chưa gọi. [Review độc lập đợt thật](<../../../REFERENCE_LINKS.md#ref-0147>) phân biệt fail-stop/caps đạt với bàn giao nội dung chưa đạt.

| Lượt | Chi phí ước tính theo token | Trạng thái |
|---|---:|---|
| S1, từ M3 |0,029836 USD|Nháp đã lưu, chưa được chuyên gia duyệt|
| S2, đợt này |0,029160 USD|Raw giữ nguyên; đã phục hồi nháp admission v3, chờ chuyên gia|
| S3/S4/O1/O2 |0 USD|Chưa gọi|
| Tổng batch tới lúc dừng |**0,058996 USD**|2/6 lượt đã dùng; trần gốc2 USD giữ nguyên|

Đây là ước tính từ usage và bảng giá đã ghim, chưa phải hóa đơn đối soát. Không có Opus, retry, fallback hoặc S1 gửi lại. [Audit dữ liệu đã lưu](<../../../REFERENCE_LINKS.md#ref-0148>) chỉ đọc, không mở khóa API hoặc gọi model.

## RCA và thiết kế bản sửa

**DF-060:** hợp đồng yêu cầu model sao chép cả linewrap của parser PDF. Guard exact hoạt động đúng, nhưng sai khác trình bày khiến mất đường bàn giao cho chuyên gia. Không có bằng chứng đây là lỗi khóa, mạng, chi phí hoặc chữ trong câu trích bị thay đổi.

Admission v3 giữ nguyên assertion/quote gốc của Claude. Bộ căn chỉnh chỉ gom các run space, tab, CR và LF để tìm duy nhất một span trong đúng trích đoạn đã gửi. Quote được ghi vào evidence phải là chuỗi liên tục nguyên gốc của nguồn tại span đó, có proof liên kết model quote, canonical quote, ref hash và vị trí. Không trim, ghép từ, bỏ gạch nối, đổi chữ hoa/thường, số, dấu câu hoặc chuẩn hóa Unicode. Không có vị trí hoặc có nhiều vị trí thì vẫn từ chối.

Reader kiểm lại projection từ raw và input đã niêm phong của đúng phiên bản, cùng quyền READ hiện hành. Hạ tag về legacy không được trở thành đường bỏ kiểm evidence. Biên nhận v1/v2 hợp lệ giữ nội dung gốc, không nâng cấp tự động hoặc dựng defaults từ hồ sơ hiện tại. AI proposal luôn có `reviewed_by` và `published_by` bằng null; review/phát hành là quyết định riêng.

**DF-053:** review C5 có4 ca forged-row phát hiện reader legacy shortcut và metadata tự nhận đã được duyệt/phát hành. Đây fault injection ngoài writer chuẩn; storage trigger hiện hữu đã chặn UPDATE. Sổ RCA ghi cả đính chính lỗi harness ban đầu, không diễn giải thành vượt quyền phát hành thật. C6 kiểm lại cả storage barrier và reader độc lập.

## TDD và gate trước phục hồi miễn phí

- [Ca RED đầu tiên](<../../../REFERENCE_LINKS.md#ref-0149>) tái hiện response hợp lệ về schema bị chặn do xuống dòng, không gọi AI thật.
- Candidate5:446 tệp, raw SHA`81b4d5d9ad16770a436dbadfd678121667a40f416fd44af4ca72435eb2f6ac72`; giữ các ca RED độc lập, không dùng bản này để phục hồi S2.
- Candidate6:446 tệp, raw SHA`a0405f016d7f1040a2ca12df89d3ba095508e0ac40e0706524f0fe7da49b0746`;94/94ca author đạt, reviewer tự chạy lại94/94;30/30ca độc lập đạt. Các lần chạy không cộng trùng. [Gate trước phục hồi](<../../../REFERENCE_LINKS.md#ref-0150>) kiểm cả alignment, metadata, legacy replay, ACL và audit khô S2.
- Sau gate, common pin đã chuyển đúng C6, SHA`66a82e64e3ade12f6dd5f8cccd245c904f5280978259786e1c1659587108ed15`; schema/DDL không đổi. Entry app8025/M5 giữ nguyên.
- [Biên nhận phục hồi miễn phí](<../../../REFERENCE_LINKS.md#ref-0151>): chỉ thêm một proposal S2; raw/input/usage/grant/expiry/S1 và mọi bảng khác giữ nguyên. Batch vẫn pause,0SDK/wiki/review/release thêm.
- [Đối soát độc lập sau phục hồi](<../../../REFERENCE_LINKS.md#ref-0152>): so với backup mới, chỉ một proposal được thêm, candidate/admission khớp dry derivation đã review; đọc không làm đổi DB. Tổng2lượt/2proposal/0,058996 USD, bốn slot còn lại chưa gọi. [Review cuối C6](<../../../REFERENCE_LINKS.md#ref-0153>) giới hạn nghiệm thu ở bàn giao kỹ thuật nháp, không gồm pháp lý hoặc mở lại AI.

## Điểm dừng tại mốc S2 — trạng thái sau đó ở báo cáo13

Bốn slot S3/S4/O1/O2 vẫn dừng. Điều khoản đã duyệt yêu cầu quyết định tiếp tục sau mỗi lỗi mới; phục hồi miễn phí không tạo quyền resume. Trần từng slot còn lại giữ0,25 USD cho mỗi Sonnet và0,50 USD cho mỗi Opus, thời hạn gốc không gia hạn.

Không có partial admission/quarantine tổng quát, gold pháp lý hoặc kết luận semantic/currentness từ bộ căn chỉnh. Nguồn đầy đủ, hiệu lực và quyết định chuyên gia vẫn cần kiểm riêng. [Sổ lỗi thiết kế](<../architecture/DESIGN_FLAWS.md>) ghi bản vá scoped DF-060/053 đã kiểm, giữ thiết kế toàn lớp D1; không nhận mọi lỗi tương tự đã bị loại bỏ.
