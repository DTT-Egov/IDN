# M6 — worker AI có kiểm soát và bộ đánh giá truy xuất

27/10/2026. Bắt đầu sau M5b SCOPED TECHNICAL PASS. Không thay bản app đang chạy, không tự mở batch đang pause. Thiết kế này giữ các biên D04/D05/D06/D07 và SQL là nguồn chuẩn; Markdown là bản xem/xuất.

**Lịch sử review:** [C1](<../../../REFERENCE_LINKS.md#ref-0112>) có8RED; C2 còn mất legacy root, C3 còn bỏ qua chứng cứ terminal. Thiết kế hiện tại là C4, đã đạt review kỹ thuật độc lập trước/sau operator trên kho thật; [các sửa kiến trúc và gate operator](<10_M6_Sua_thiet_ke_va_gate_operator.md>), [bàn giao](<11_Ban_giao_M6.md>). Không dùng số ca xanh của bản cũ để kết luận bản mới đã đạt; chất lượng pháp lý và paid trial còn chưa nghiệm thu.

## Hai đường tách biệt

**Vận hành xây kho:** quyết định operator → đúng kho công khai/instance/corpus/hạn mức gốc → khóa một worker → đọc checkpoint → slot chưa gọi → Gateway chung → manifest/fence → SDK duy nhất → raw output/usage → proposal → chuyên gia. Các slot cố định S1–S4 dùng Sonnet, O1/O2 dùng Opus và nhận đúng các kết quả Sonnet đã lưu. Không bổ sung planner động, compaction, subagent hoặc model mới ngoài hợp đồng đã kiểm.

**Đánh giá miễn phí:** bộ30câu hỏi thử đóng băng → intent → A(SQL/FTS/source snippets) và B(cùng A + released wiki) → đo đường đọc và100lần dùng lại → báo số liệu cùng giới hạn. Không dùng câu trả lời AI làm gold, không tự phát hành fixture vào kho thật. Hai đường không dùng chung authority ngân sách với quỹ tester doanh nghiệp.

## Checkpoint và tiếp tục

Checkpoint đọc từ grant/slot/attempt/proposal trong SQL; không có file tiến độ thứ hai quyết định gọi AI. Không chọn “mới nhất” bằng timestamp/UUID. Thứ tự slot hữu hạn là một phần workload được duyệt; hash tập pause events chỉ nhận diện đúng tập sự kiện, không giả làm quan hệ nhân quả.

ControlM6 có bảng quyết định bất biến và head riêng, FK cùnggrant/attempt/previous, unique root/sequence/successor và receipt commandresume. Chỉ controlchain cho phép hiệu lực active/paused; grant.state là projection. Gateway reserve và fence cùng đọc proofcausal, ghi proof tại dispatch; worker/directbatch cùng bị chặn khi rewind head/projection hoặc event envelope sai. Chi phí vẫn do grant/attempt ledger Gateway duy nhất, không thêm quỹ/counter/transport.

Chứng cứ terminal của kernel (`estimate_overrun`) và stop helper (`batch_stop_terminal`) là tập bất biến riêng. Reader kiểm envelope/attempt/grant, đối chiếu số phí với attempt gốc và đưa hash tập vào proof chung. Còn chứng cứ terminal thì không được active hoặc pause/resume lại; trạng thái projection bị ghi lùi không thể mở slot tiếp. Đây là khóa an toàn, không phải thẩm quyền tự đối soát: quy trình giải tỏa tài chính trong tương lai cần hợp đồng/quyết định riêng. Trigger bảo vệ cả event legacy bằng DDL, không tạo control hoặc sửa lịch sử trên READ.

Extension được operator chung nâng rõ ràng với backup/plan/receipt; runtime không DDL. Originalprepared/schemahash/legacy receipt giữ nguyên, reader kiểm phần schema còn lại đúng hashM3 sau loại đúng object M6 đã đăng ký. Trước upgrade chỉ đọc legacy status/history, không tạo anchor; run/resume boundbatch bị chặn trước key/reservation. Sau upgrade vẫn0control/head cho đến mutation được phép đầu tiên. Không có cấp hạn mức hoặc resume chỉ từ schema.

Một lần chạy mặc định tối đa1slot mới, có giới hạn1–6; không có vòng daemon. Slot đã có attempt không gọi lại, kể cả bị hủy/trạng thái chưa biết. Kết quả không chắc hoặc thiếu handoff dừng batch. Process chết sau raw response/trước proposal: lần chạy rõ ràng tiếp theo chỉ ghi pause; phục hồi proposal miễn phí không tự active grant.

Resume là lệnh operator riêng sau quyết định thật của chủ dự án, có receipt và CAS trong sổ sự kiện chung. Ghim grant/instance/corpus/pause-set/expiry/slots còn lại; không cấp lại, chuyển DB, đổi hạn/phí/usage, gọi lại S1 hoặc biến proposal thành được duyệt. Exact replay kiểm quyết định gốc và READ hiện tại, không yêu cầu EXPORT cho receipt đã commit. Mutation resume mới phải kiểm EXPORT và lifecycle; source READ revoke chặn cả status/receipt.

`pause_after_failure` là primitive an toàn “bảo đảm đang dừng”, chỉ idempotent tại đúng pausedhead đang xét. Một lệnh gọi sauresume lại bảo đảm pause; API không cócommandID nên không nhận là replay commandstop lịch sử. Nếu mở lệnh stopcho người dùng sau này phải thêm explicitcommandID/expectedhead. Humanresume có commandID và receipt exact; flags boolean phải đúng kiểu, JSON1không làtrue.

Không đăng ký resume hoặc quyền cấp tiền thành MCP tool cho model/frontend. File do AI sinh không là phê duyệt. CLI status không đọc API key, không DDL/ghi DB, không phục hồi/resume/gọi model. CLI run chỉ mở cấu hình sau khi checkpoint cho phép bước mới; Gateway vẫn là authority kiểm tiền, scope, source, manifest và dispatch cuối.

## Đánh giá và giới hạn kết luận

Corpus30câu gồm đào tạo, xuất khẩu, hai nhu cầu, phủ định và ngoài phạm vi. Gold hiện chỉ là intent/kết quả kỹ thuật trên nguồn THỬ NGHIỆM. A là tìm nguồn, B thêm giải thích đã phát hành; khác dạng đầu ra nên không nhận chênh lệch số kết quả là thắng về chất lượng. Đo thời gian từng đường và số ký tự, giữ model ở chế độ không dùng; không đổi đồng thời model/corpus/harness rồi nhận wiki tốt hơn.

Chưa có gold pháp lý thật và chưa có tổng hợp câu trả lời A/B bằng cùng model: chất lượng pháp lý/độ đúng nhận định/precision/critical-claim coverage ghi `not_evaluable`, điểm chất lượng `null`. Công reviewer và bảo trì chưa đo ghi `null`, không ghi0. Chi phí AI xây kho thực đã biết báo riêng với chi phí truy vấn của phép đo miễn phí; không suy0chi phí vận hành thật.

Phải ghi build/question hash/source hashes/date, số câu/đọc, model calls, writes và giới hạn. Kho nguồn thay đổi/revoke/withdraw phải hiện gap hoặc bị chặn; không lấy cache/projection cũ thành current-use. Không cần graph/vector DB, embedding, Deep Agents hoặc OKF để kiểm đường K2 này; việc mở rộng các adapter vẫn là gate riêng.

## Ngân sách và đợt thật sau khi được đồng ý

Batch gốc6lượt/2USD đã dùng S1, rồi người dùng [đồng ý tiếp tục năm slot](<../../../REFERENCE_LINKS.md#ref-0113>). S2 gọi1lần và pause vì linewrap; C6 phục hồi nháp miễn phí. Sau [quyết định tiếp tục bốn slot](<../../../REFERENCE_LINKS.md#ref-0114>), S3/S4 có nháp, O1 nhận JSON dở dang và O2 chưa gọi. Tổng hiện tại5lượt/4proposal/ước0,217632USD, vẫnpause; giữ expiry29/10 lúc07:40:33(UTC+7). [Đợt thật mới nhất](<13_M6_Ket_qua_4_slot_Claude.md>) phân biệt admission kỹ thuật với artifact/semantic/legal chưa đạt. [Thiết kế cần sửa](<14_M6_Thiet_ke_sua_ngan_sach_va_slot_loi.md>) cho execution profile/completionmetadata/failed-slot không được tự áp dụng lên grant gốc hoặc biến O1 thành accepted để chạy O2.

M6 kỹ thuật có thể đạt có giới hạn; M6b thử nghiệm AI còn chờ quyết định tiếp tục, gold và chuyên gia. Không coi chữ “milestone pass” kỹ thuật là lệnh gọi AI, phát hành nội dung hoặc bật lịch tự động. DF-013/014/027/028/033/042/043/049/056/059 tiếp tục theo sổ thiết kế.
