# M4 — bàn giao kỹ thuật, chuyển M5

Ngày27/10/2026. [Reviewer độc lập xác nhận SCOPED PASS](<../../../REFERENCE_LINKS.md#ref-0103>), không còn blocker kỹ thuật đã tái hiện trong phạm vi. Đây không phải phát hành chính sách hay nghiệm thu chất lượng pháp lý thật.

Candidate4 gồm434tệp; raw manifest SHA256`ed63bea66af049c25d73150fe7c93ab9db27a2c579410cc962f766cbf6832344`. Frozen1–3 và các ca RED được giữ nguyên.

## Kết quả

- Tri thức công khai đúng revision/review/release/scope, dùng lại theo từng nhu cầu; context/SSOT riêng của hai doanh nghiệp không vào public bundle.
- Lịch sử tách current-use; thu hồi READ chặn cả cache, withdraw không xóa lịch sử, EXPORT kiểm trước gửi. Một Gateway/SDK/budget authority.
- Source-control causal chain chặn lùi pointer/gate/head; nguồn legacy chưa có anchor chặn dùng mới. Không backfill khi migration/READ, không sửa raw. Quan sát mới qua writer chung không tự thành phê duyệt pháp lý.
- Bàn chuyên gia dùng phiên/CSRF sẵn có; nháp riêng bị dọn khỏi DOM khi mất/đổi phiên, callback cũ bị chặn. Nháp server của chủ cũ được giữ.
- Proof source/attestation được ghi tại final dispatch fence, ngoài nội dung/identity model request cũ; lỗi ghi thì hủy trước transport.
- Chat mobile giữ hai nhu cầu và lịch “buổi tối”; phần thiếu nguồn có dòng riêng. [Walkthrough và giới hạn ảnh](<02_Walkthrough_M4.md>).

## Các bộ kiểm thực sự chạy

| Bộ | Kết quả/phạm vi |
|---|---|
| Root broad candidate3 |270/270, M1–M4/CoreGateway/Policy; baseline trước bổ sung trace |
| Root candidate4 thay đổi liên quan |[76/76](<../../../REFERENCE_LINKS.md#ref-0104>), Gateway/ACL/finance/domain/budget/policy |
| Root candidate4 whole-runtime |[1/1](<../../../REFERENCE_LINKS.md#ref-0105>), migration/replay/managed read-only/drift |
| Reviewer candidate4 author |92/92,13tệp |
| Reviewer candidate4 tự viết |22/22 chính,12/12 bổ sung,3/3 ràng buộc; ba lượt riêng |
| Reviewer candidate4 DOM |4/4 |
| Frontend main |357/357 ởcandidate1; toànweb/app chính không đổi ở4, chỉ thêm4ca workbench riêng |

Không cộng các lượt lặp thành một full-run. Ảnh mobile mới nhất là candidate3; diff xác nhận web/host/JS giốngcandidate4, được ghi rõ trong báo cáo độc lập. Native focus trình duyệt/điện thoại vật lý chưa đủ chứng cứ; listener được kích hoạt có kiểm soát với HTTP session và response thật trong fixture.

## Chi phí và phạm vi còn mở

Không gọi AI hoặc dùng MAIN trong M4. S1 thật ởM3 giữ nguyên proposal và grant đang pause. Không coi nguồn giả hoặc S1 là legal gold. Chưa đưa proposal đó thành chính sách đã duyệt.

M5 được làm rehearsal, backup/restore và deploy kỹ thuật sau review. Nguồn thật thiếu thì tiếp tục blocked/partial; không force anchor, không tự cấp quyền hoặc phê duyệt hộ `trung@dtt.vn`. Paid QA chỉ được thực hiện đúng authority và consent/D06; không nhân đôi hạn mức sang clone.

Đã cập nhật **DF-016/028,027/033/048,049/043,042**; **DF-014/024/025/029/046** tiếp tục được truy vết. Bản vá đã kiểm trong phạm vi M4; thiết kế vẫn **D1**, các domain/qualifier/gold pháp lý, adapter thực, nhiều máy và toàn audit ledger còn mở.
