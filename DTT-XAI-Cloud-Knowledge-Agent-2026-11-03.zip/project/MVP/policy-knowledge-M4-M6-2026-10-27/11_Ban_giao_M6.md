# Bàn giao M6 — worker kho tri thức có kiểm soát

Ngày 27/10/2026. **Đã đạt review kỹ thuật độc lập cả trước và sau nâng schema kho công khai M3.** [Review cuối](<../../../REFERENCE_LINKS.md#ref-0133>) và [biên bản](<../../../REFERENCE_LINKS.md#ref-0134>) xác nhận không còn blocker đã tái hiện trong phạm vi M6. Đây là bàn giao kỹ thuật có giới hạn. M6b chạy tiếp AI và nghiệm thu nội dung pháp lý vẫn chưa hoàn tất.

**Trạng thái mới nhất sau hai quyết định tiếp tục:** S2 đã phục hồi miễn phí qua C6; người dùng cho chạy bốn slot sau, S3/S4 đã lưu nháp và O1 bị từ chối do JSON dở dang. Hiện5lượt/4proposal/ước0,217632USD, O2 chưa gọi và batch vẫn dừng. [Kết quả đợt bốn slot](<13_M6_Ket_qua_4_slot_Claude.md>) là trạng thái mới nhất. C6 đạt94ca hồi quy/30ca độc lập cho lexical/read/recovery; đó không phải nghiệm thu dung lượng output của Opus hoặc chất lượng FAQ/checklist. Các số ca C4 bên dưới thuộc mốc trước khi gọi tiếp.

## Những gì đã làm được

Worker chạy hữu hạn theo từng slot được duyệt, lưu kết quả và đọc lại checkpoint trong SQL. Đóng tiến trình hoặc thiếu proposal không làm gửi lại một lượt đã gọi. Dùng lại kết quả, xem trạng thái và phục hồi dữ liệu cũ không gọi AI. Lệnh tiếp tục là quyết định operator riêng, không phải tool cho model hoặc chủ doanh nghiệp.

Quyết định dừng/tiếp tục có chuỗi nhân quả và biên nhận bất biến. Cùng bộ kiểm được dùng tại checkpoint và Gateway trước khi gửi. Trạng thái trái chuỗi quyết định đã lưu, mất head khi đã có quyết định, hoặc chứng cứ dừng đối soát còn tồn tại đều chặn lượt mới. Kết quả AI chỉ là đề xuất có căn cứ, không tự thành tri thức được phát hành.

App chính vẫn ở [8025](http://127.0.0.1:8025/web/) và [bàn làm việc tri thức](http://127.0.0.1:8025/knowledge/), dùng bản M5 đã review. M6 nâng công cụ vận hành kho công khai; không thay SSOT hoặc bản app đang phục vụ. [Kiểm HTTP](<../../../REFERENCE_LINKS.md#ref-0135>) xác nhận trang và ba asset khớp byte bản M5.

## Bản đã kiểm và kết quả

- Candidate4:444 tệp, raw manifest SHA-256 `cd57e7864ad1285d663924197c6d61aafd2d138ad3708c7c69f96aad0f794e77`.
- Author:63/63 ca M3/M6 đạt trên bản đóng băng; reviewer tự chạy lại cũng63/63 đạt. Hai lần chạy là bằng chứng riêng, không cộng thành126 ca.
- Reviewer:34 ca độc lập khác nhau và6 ca công cụ vận hành ngoài bundle đạt. Hai lỗi harness được giữ log và giải thích: ca fault-update nay bị storage chặn sớm, và test sao chép nhầm candidate cũ; đã có lượt tương đương sạch.
- [Review trước operator](<../../../REFERENCE_LINKS.md#ref-0136>) và [biên bản](<../../../REFERENCE_LINKS.md#ref-0137>) cho đúng bước nâng schema, không cho chạy model hoặc phát hành nội dung.
- [Diễn tập nâng và phục hồi](<../../../REFERENCE_LINKS.md#ref-0138>) giữ nguyên79 bảng cũ. Bản sao chỉ để kiểm, không được dùng hạn mức sao chép để gọi AI.
- [Operator trên kho thật](<../../../REFERENCE_LINKS.md#ref-0139>), [biên nhận](<../../../REFERENCE_LINKS.md#ref-0140>):79 bảng cũ nguyên, không thêm control/head/anchor hoặc hạn mức, không sửa prepared gốc, không thêm lượt AI. Backup riêng được giữ tại gói vận hành, không đưa dữ liệu gốc vào tài liệu này.
- [Đối soát độc lập sau operator](<../../../REFERENCE_LINKS.md#ref-0141>): đọc bắt buộc chỉ đọc, bảng cũ khớp backup, schema/receipt/plan đúng bản duyệt,0control/head/anchor; hash trước/sau audit không đổi. Tên artifact có chữ M6b nhưng đây là audit kỹ thuật, không phải paid trial.

Các bản C1–C3 và log lỗi được giữ nguyên. [Sửa thiết kế qua các vòng review](<10_M6_Sua_thiet_ke_va_gate_operator.md>) giải thích vì sao nhiều bộ kiểm xanh vẫn chưa đủ cho phép chuyển mốc.

## Kho thật và chi phí

| Nội dung | Trạng thái sau operator |
|---|---|
| S1 |1 kết quả Claude và1 proposal v2 giữ nguyên, chưa phát hành|
| S2 |1 kết quả Claude mới và1 proposal v3 được phục hồi miễn phí, chưa phát hành|
| S3/S4 |Mỗi slot1kết quả/1proposal v3; đều chưa phát hành|
| O1 |Đã nhận phản hồi, JSON dở dang, validation rejected; raw giữ nguyên|
| O2 |Chưa gọi; bị giữ dừng khi O1 còn failed|
| Grant |Vẫn `paused_admission_review`, không có bước tự chạy kế tiếp|
| Chi phí đã biết |S1:0,029836; S2:0,029160; S3:0,027184; S4:0,030140; O1:0,101312 USD; tổng0,217632 USD theo token, chưa phải hóa đơn đối soát|
| M4–M6 |M4/M5 và M6 kỹ thuật trước resume:0lượt mới; M6 thật thêm4lượt S2/S3/S4/O1|
| Hạn gốc |07:40:33 ngày29/10/2026, UTC+7; không gia hạn|
| Schema worker |Đã sẵn sàng; không đồng nghĩa được tiếp tục AI|

[Đề nghị năm slot](<../../../REFERENCE_LINKS.md#ref-0142>) và [đề nghị bốn slot](<../../../REFERENCE_LINKS.md#ref-0143>) đều đã được người dùng đồng ý và ghi receipt. Lỗi O1 đã tạo pause mới; JSON thiếu không được sửa thành accepted và hợp đồng resume hiện tại không bỏ qua failed slot để chạy O2. Không dùng quỹ tester, cấp lại/gia hạn hoặc tự thử lại; [thiết kế cần sửa](<14_M6_Thiet_ke_sua_ngan_sach_va_slot_loi.md>) phải được chốt trước đợt AI tiếp theo.

## Đánh giá tri thức và phần còn mở

[Diagnostic](<../../../REFERENCE_LINKS.md#ref-0144>) dùng30 câu tổng hợp và100 lần đọc lại: intent30/30,0ghi DB,0model. A tìm đoạn nguồn bằng SQL/FTS; B bổ sung wiki đã phát hành trong kho thử. Hai đường trả loại đầu ra khác nhau; số đo không chứng minh wiki tốt hơn, nhanh hơn hoặc rẻ hơn trong thực tế.

Chưa có bộ đáp án pháp lý do chuyên gia xác nhận, corpus thật đủ hiệu lực, hoặc tổng hợp câu trả lời A/B bằng cùng model. Điểm chất lượng, công chuyên gia và chi phí bảo trì vẫn để chưa đánh giá. Nội dung S1 chưa được chuyên gia duyệt/phát hành, không đưa vào MAIN như chính sách hiện hành đã kiểm chứng.

Các lớp DF-013/014/025/043/046/048/052/053/056 trong [sổ nguyên nhân thiết kế](<../architecture/DESIGN_FLAWS.md>) giữ trạng thái D1 ngoài phạm vi bằng chứng này. Còn mở quy trình đối soát tài chính có quyết định riêng, nhiều máy, provider/trạng thái mới và nghiệm thu pháp lý. Không tự triển khai M7, embedding, vector/graph DB, framework mới hoặc lịch AI nền.

[Walkthrough M6](<09_Walkthrough_M6.md>) · [Bàn giao M4](<03_Ban_giao_M4.md>) · [Bàn giao M5](<07_Ban_giao_M5.md>) · [Kịch bản thử app local](<05_Kich_ban_test_local_M5.md>).
