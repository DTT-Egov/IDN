# S3 — Wiki và FAQ: nháp AI để chuyên gia rà soát

Ngày27/10/2026. Đây là nội dung Claude đã lưu, chưa được chuyên gia duyệt hoặc phát hành. Trích dẫn có vị trí nguồn; ngữ nghĩa và hiệu lực chính sách chưa được xác minh.

[Kết quả batch và giới hạn](<13_M6_Ket_qua_4_slot_Claude.md>)

## 1. Nhận định đề xuất

Thông báo nêu thời hạn nhận hồ sơ đăng ký của doanh nghiệp: từ 30/03/2026 đến khi đủ chỉ tiêu.

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 170–204 trong chunk đã ghim.

> Từ 30/03/2026 đến khi đủ
> chỉ tiêu.

## 2. Nhận định đề xuất

Phụ lục 3 nêu số lượng nhận hỗ trợ: 200 doanh nghiệp trên địa bàn Hà Nội, gồm 100 doanh nghiệp nhỏ và 100 doanh nghiệp vừa.

Nguồn `HN-NOTICE-2026-14-ATTACHMENT`; vị trí ký tự 841–887 trong chunk đã ghim.

> 200 doanh
> nghiệp
> trên địa
> bàn thành
> phố Hà
> Nội

## 3. Nhận định đề xuất

Nghị định 80/2021/NĐ-CP quy định hỗ trợ tối đa 50% giá trị hợp đồng; trần 50 triệu đồng/hợp đồng/năm (doanh nghiệp nhỏ), 100 triệu (doanh nghiệp vừa).

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 13–78 trong chunk đã ghim.

> Hỗ trợ tối đa 50% giá trị hợp đồng tư vấn giải pháp chuyển đổi số

## 4. Nhận định đề xuất

Hồ sơ gồm tờ khai xác định quy mô doanh nghiệp và đề xuất nhu cầu hỗ trợ theo mẫu, cùng tài liệu liên quan (nếu có).

Nguồn `VN-DECREE-80-2021-SCAN`; vị trí ký tự 405–505 trong chunk đã ghim.

> Tờ khai xác định doanh nghiệp siêu nhỏ, doanh nghiệp nhỏ, doanh nghiệp vừa và đề xuất nhu cầu hỗ trợ

## 5. Nhận định đề xuất

FAQ: doanh nghiệp quan tâm nên đối chiếu quy mô nhỏ/vừa, mức trần và hồ sơ. Việc đủ điều kiện hưởng do cơ quan có thẩm quyền xác định, không khẳng định ở đây.

Nguồn `VN-CIRCULAR-06-2022-GAZETTE`; vị trí ký tự 1061–1133 trong chunk đã ghim.

> Tờ khai theo m ẫu quy định t ại Ph ụ l ục 1 ban hành kèm theo Ngh ị định

## Khoảng trống cần kiểm

- Thông báo số /TB-TTXT trong Phụ lục 3 để trống số và ngày; chưa xác nhận bản ban hành chính thức.
- Chưa có toàn văn Điều 5 Nghị định 80/2021/NĐ-CP về tiêu chí doanh nghiệp nhỏ và vừa.
- Trích đoạn Thông tư 06/2022 bị cắt, chưa thấy toàn bộ quy trình và ngoại lệ.
- Chưa rõ ý nghĩa 'đủ chỉ tiêu' và cách tính năm/hợp đồng.
- Thông tin liên hệ trong bảng có số điện thoại/email trùng giữa các đơn vị, cần kiểm tra bản gốc.
- Chưa xác nhận hiệu lực hiện hành của các văn bản.

## Câu hỏi cho chuyên gia

- Thông báo chính thức đã ban hành chưa, số và ngày là gì?
- Điều kiện hưởng, loại trừ và thứ tự xét hồ sơ theo văn bản toàn văn là gì?
- Thông tin liên hệ trùng lặp trong Phụ lục 3 có chính xác không?
