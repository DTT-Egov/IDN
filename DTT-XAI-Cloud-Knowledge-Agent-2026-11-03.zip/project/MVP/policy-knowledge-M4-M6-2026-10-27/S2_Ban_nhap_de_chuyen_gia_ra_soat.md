# S2 ? b?n nh?p ?? chuy?n gia r? so?t

Ng?y 27/10/2026. B?n xem t? ph?n h?i Claude ?? l?u; admission v3 ki?m v? tr? tr?ch d?n, ch?a ki?m ??ng ng? ngh?a ho?c hi?u l?c ph?p l?. Ch?a ???c chuy?n gia duy?t/ph?t h?nh.

[B?i c?nh, chi ph? v? review](<12_M6_Claude_that_va_sua_trich_dan.md>)

## C?c nh?n ??nh AI ?? xu?t

### 1. Nh?n ??nh ch?a duy?t

Phụ lục 3 nêu đối tượng: 200 doanh nghiệp trên địa bàn Hà Nội, gồm 100 doanh nghiệp nhỏ và 100 doanh nghiệp vừa, xác định theo Điều 5 Nghị định 80/2021/NĐ-CP.

Ngu?n `HN-NOTICE-2026-14-ATTACHMENT`; v? tr? k? t? 888?933 trong chunk ?? ghim.

> - 100 doanh
> nghiệp nhỏ
> - 100 doanh
> nghiệp vừa

Ti?p nh?n: di?n gi?i; semantic ch?a ???c chuy?n gia x?c minh.

### 2. Nh?n ??nh ch?a duy?t

Mức hỗ trợ là 50% kinh phí từ ngân sách, có trần theo loại doanh nghiệp (nhỏ: 50 triệu; vừa: 100 triệu đồng/hợp đồng/năm).

Ngu?n `HN-NOTICE-2026-14-ATTACHMENT`; v? tr? k? t? 1056?1091 trong chunk ?? ghim.

> 50% kinh phí
> từ Ngân sách
> nhà nước,

Ngu?n `VN-DECREE-80-2021-SCAN`; v? tr? k? t? 220?281 trong chunk ?? ghim.

> không quá 50 triệu đồng/hợp đồng/năm đối với doanh nghiệp nhỏ

Ti?p nh?n: di?n gi?i; semantic ch?a ???c chuy?n gia x?c minh.

### 3. Nh?n ??nh ch?a duy?t

Hồ sơ gồm tờ khai xác định quy mô doanh nghiệp và đề xuất nhu cầu hỗ trợ; tài liệu liên quan chỉ cần khi có.

Ngu?n `VN-DECREE-80-2021-SCAN`; v? tr? k? t? 569?641 trong chunk ?? ghim.

> b) Những tài liệu, hồ sơ liên quan đến nội dung đề xuất hỗ trợ (nếu có).

Ti?p nh?n: di?n gi?i; semantic ch?a ???c chuy?n gia x?c minh.

### 4. Nh?n ??nh ch?a duy?t

Thời hạn nhận hồ sơ bắt đầu từ 30/03/2026 và kéo dài đến khi đủ chỉ tiêu; đây là yếu tố giới hạn thực tế.

Ngu?n `HN-NOTICE-2026-14-ATTACHMENT`; v? tr? k? t? 170?204 trong chunk ?? ghim.

> Từ 30/03/2026 đến khi đủ
> chỉ tiêu.

Ti?p nh?n: di?n gi?i; semantic ch?a ???c chuy?n gia x?c minh.

C?u Claude sinh v? c?u ngu?n ch? kh?c c?ch xu?ng d?ng/kho?ng tr?ng; c? hai ???c gi? trong provenance.

### 5. Nh?n ??nh ch?a duy?t

Diễn giải: sau khi nhận hồ sơ, cán bộ có thể yêu cầu bổ sung chứng minh (nếu có). Chưa đủ căn cứ kết luận doanh nghiệp cụ thể đủ điều kiện hay được hỗ trợ; cần cơ quan có thẩm quyền xét.

Ngu?n `HN-NOTICE-2026-14-ATTACHMENT`; v? tr? k? t? 3157?3244 trong chunk ?? ghim.

> cán bộ phụ trách
> sẽ trao đổi chi tiết về các
> hồ sơ doanh nghiệp cần
> chứng minh (nếu có)

Ti?p nh?n: di?n gi?i; semantic ch?a ???c chuy?n gia x?c minh.

## Kho?ng tr?ng AI n?u

- Thông báo gốc số /TB-TTXT để trống số, ngày; chưa xác nhận bản ban hành chính thức.
- Thiếu toàn văn thông báo và các điều khoản loại trừ, điều kiện về hợp đồng tư vấn, đơn vị tư vấn, thời điểm ký/thanh toán.
- Chưa có trích đoạn Điều 5 Nghị định 80/2021 để xác định tiêu chí doanh nghiệp nhỏ/vừa.
- Chưa rõ cách tính 'kinh phí', thứ tự xét hồ sơ, tiêu chí khi vượt chỉ tiêu.
- Hiệu lực hiện hành của Nghị định 80/2021 và Thông tư 06/2022 chưa được xác nhận ngoài trích đoạn; thông tin liên hệ có điểm trùng lặp cần kiểm tra.
- Chưa rõ Thông tư 06/2022 áp dụng cho nội dung tư vấn chuyển đổi số này đến mức nào.

## C?u h?i c?n chuy?n gia tr? l?i

- Bản thông báo chính thức đã ban hành có số, ngày và điều kiện loại trừ nào?
- Tiêu chí doanh nghiệp nhỏ/vừa theo Điều 5 Nghị định 80/2021 hiện hành là gì?
- Hợp đồng tư vấn đã ký trước ngày 30/03/2026 có được xét không?
- Thông tin liên hệ trùng số điện thoại/email của MCG, TopCare, Sicix có chính xác không?
