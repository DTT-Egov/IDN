# M6 — sửa sau review và cổng nâng kho staging

27/10/2026. **Candidate4 qua review độc lập trước và sau operator; đã nâng schema kho công khai M3.** [Review cuối](<../../../REFERENCE_LINKS.md#ref-0124>) đạt có giới hạn kỹ thuật; M6b paid/gold chưa hoàn tất. Candidate3 bị chặn vì chứng cứ dừng để đối soát phí chưa được reader áp dụng. App 8025 vẫn M5 đã nghiệm thu. Không resume hoặc gọi AI từ bước nâng schema.

Sau mốc schema này, S2 đã phục hồi miễn phí qua C6; người dùng đồng ý chạy bốn slot tiếp, S3/S4 có nháp, O1 nhận JSON dở dang nên dừng trước O2. Worker vẫn ghim C6; schema/DDL không đổi, hiện5lượt/4nháp/ước0,217632USD. [Trạng thái mới nhất](<13_M6_Ket_qua_4_slot_Claude.md>) thay cho các câu “chờ năm slot” thuộc mốc operator lịch sử bên dưới.

## Những lỗi review đã chứng minh

C1 có8caRED độc lập: corpus B vượt tập nguồn, stop sauresume bị bỏ, envelope receipt sai, projectiongrant tự mở lại cả đường SDK chung, và3cờ boolean nhận số1. [Review C1](<../../../REFERENCE_LINKS.md#ref-0125>). C2 sửa các ca đó,19ca sâu bổ sung cũng đạt, nhưng còn lỗi root chuyển tiếp: xóa eventpauseM3 trướccontrolM6 đầu tiên làm grant trở lại issued-active. Giữ cả candidate/log lỗi để truy nguyên, không xóa dữ liệu để làm kiểm thử đạt.

Candidate3 thêm guard legacy nhưng reviewer phát hiện thêm 4 ca RED: retained `estimate_overrun` bị bỏ qua, UPDATE/DELETE event này chưa bị chặn, và `batch_stop_terminal` được bảo vệ ở storage nhưng reader vẫn bỏ qua. [Review C3](<../../../REFERENCE_LINKS.md#ref-0126>). Tất cả là fault injection trên kho giả, không có AI thật hoặc dữ liệu MAIN bị sửa.

## Thiết kế candidate4

- Decision bất biến, head và previous/sequence/unique root/successor/FK cùnggrant, cùngattempt.
- Record giữ canonical event envelope và hash; reader kiểm toàn chuỗi, leaf/head/projection và nguồn READ, không chỉ payload tự khẳng định.
- Gateway reserve/fence dùng cùng verifier. Quyết định dừng hiện hành thắng một trườnggrant.state bị rewind.
- Hai trigger exactregistered bảo vệ UPDATE/DELETE các lifecycle event, gồm hàngM3 cũ, ngay sau operator; không backfill/đổi nội dung cũ.
- Terminal evidence do kernel (`estimate_overrun`) hoặc stop helper (`batch_stop_terminal`) được đọc như tập chứng cứ bất biến riêng, kiểm envelope/scope/attempt và đưa hash vào proof ở Gateway fence. Nếu còn chứng cứ terminal, projection không được active/paused. Không dùng timestamp để suy lần cuối, không cho resume tự đối soát hoặc sửa usage; exact receipt lịch sử vẫn đọc được khi terminal hợp lệ.
- Resume cócommandID/receipt/CAS; replay READ không đòiEXPORT, mutation mới đòiEXPORT/lifecycle. Boolean phải đúng kiểu. Stop là primitive ensure-paused, không mạo nhận replaycommand lịch sử khi API không cócommandID.
- Corpus B chỉ nhận cả trang có toàn bộ căn cứ thuộc source_ids đã khai, ghi thêm identity tập wiki/release. Không lấy trang ngoài corpus rồi chỉ giấu tên nguồn trong report.

Các bảng mới giữ quyết định hiệu lực, **không có counter/phí/quỹ/transport thứ hai**. Hạn mức/giá/usage/SDK vẫn Gateway hiện hữu. READ không tạo control/root hoặc sửahead. Quyền kỹ thuật qua operator không thay phê duyệt D06 hoặc quyết định chuyên gia.

## Schema operator — trước khi nâng thật

Candidate4:444file, rawmanifest `cd57e7864ad1285d663924197c6d61aafd2d138ad3708c7c69f96aad0f794e77`. Các entrypoint dùng chung `m6_approved_bundle.py`, kiểm pin và mọi byte trước đọc dữ liệu/cấu hình. Đây localreviewidentity, chưa phải chữ ký chống quản trị viên OS.

[Diễn tập4](<../../../REFERENCE_LINKS.md#ref-0127>) chỉ mở kho gốc READ rồi nâng bản sao riêng:79bảng cũ nguyên, nguồn/prepared/terms/usage/roles không đổi,0control/head/grant/SDK thêm. Phục hồi vào đường mới khớp toàn dữ liệu vàschemaM3 gốc. Bản sao có hạn mức **không được dùng để gọi SDK**; registry vẫn ghim authority vào kho gốc.

Plan cóthể soát: [migration-plan](<../../../REFERENCE_LINKS.md#ref-0128>), raw SHA `a5921f067cedaf13c0afd377e34aebbac60b98bc8b65de4e285332c69f837a57`. Sau [preoperator pass](<../../../REFERENCE_LINKS.md#ref-0129>), root đã áp dụng đúng plan qua common operator có backup mới. [Kết quả thật](<../../../REFERENCE_LINKS.md#ref-0130>) giữ79 bảng cũ, prepared/grant/usage không đổi,0control/head/anchor/lượt AI mới. Nếu source/schema/plan đổi thì dừng, không tự chữa hoặc cấp lại grant. Target phải đúng prepared.database trước backup/DDL. Không có fallback hoặc restore đè dữ liệu thật sau khi có ghi mới.

`prepared.schema_sha256` cũ không được đổi. Reader chỉ nhận extension khi đủ exactDDL/trigger/receipt, và phần schema còn lại sau loại **đúng object đã đăng ký** khớp preparedhash gốc. Thiếu/đổi trigger, object lạ hoặc receipt sai đều bị từ chối trước dispatch. M3frozenloader cũ sẽ từ chối schema mới, vì vậy phải dùng pinnedM6entrypoint.

Reviewer đã đối soát riêng79bảng cũ/receipt/prepared sau apply: khớp backup, trạng thái grant còn pause, số lượt/chi phí không tăng, control/head vẫn0 và READ không ghi. [Audit](<../../../REFERENCE_LINKS.md#ref-0131>) là kỹ thuật, không phải paid trial dù tên artifact có chữ M6b. **Schema sẵn sàng không là lệnh resume.**5slot còn lại vẫn đợi câu trả lời đã hỏi trong [D06](<../../../REFERENCE_LINKS.md#ref-0132>).

## Kiểm và phần chưa kết luận

C2 root55ca liên quan đạt, bao gồm8test độc lập chạy lại; independent27ca riêng đạt trước phát hiện legacyroot. C3 author61, independent28 và external6 đạt nhưng terminal4RED nên chưa qua gate. C4 frozen author63/63, reviewer chạy lại63/63;34ca độc lập khác nhau và6ca external đạt. Số C2/C3 chỉ là lịch sử. Ca fault-update eventscope cũ bị storagebarrier từ chối sớm hơn; equivalent storage test đạt, không nới an toàn để giữ thủ thuật fault cũ. Test external đầu sao nhầm C3 trong khi pinC4, đã giữ log và chạy lại đúng candidate với6/6; không nhận hai lỗi harness là lỗi source hoặc xóa bằng chứng.

Corpus30câu/100lần dùng lại chỉ là diagnostic kỹ thuật; chưa có legalgold/answer synthesisA/B. Không chấm điểm hoặc suy giảmchi phí thực từ fixture. Nội dungS1 vẫn đề xuất cần chuyên gia; không vàoMAIN nhưwiki đã phát hành. Các DF-013/014/025/043/046/048/049/052/053/056 vẫn theo phạm vi trong [sổ RCA](<../architecture/DESIGN_FLAWS.md>), lớp thiết kếD1.
