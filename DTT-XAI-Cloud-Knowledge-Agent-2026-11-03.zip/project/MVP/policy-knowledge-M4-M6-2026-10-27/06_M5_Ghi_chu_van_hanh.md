# M5 — ghi chú vận hành và biên dữ liệu

Ngày 27/10/2026. Đọc cùng [kế hoạch triển khai](<04_M5_Ke_hoach_trien_khai.md>) và biên bản review độc lập; tài liệu này không tự xác nhận đã triển khai.

## Khởi động đúng bản

Dùng `C:\Enterprise AI\app\nmate-backend-v0.2\start-main.cmd` sau cutover đã kiểm. Lệnh gọi bootstrap `output/policy-knowledge-M4-M6-2026-10-27/launch_approved_m5.py`, ghim raw manifest candidate2 SHA256 `eaff60188236c8b0527d769a61d7b2d6b9356def8a46e9f7f90d5c485345dd34`. Bootstrap kiểm identity trước chạy launcher; launcher kiểm toàn bộ byte rồi mới mở cấu hình và dữ liệu. Chạy trực tiếp launcher bên trong bundle chỉ có kiểm tính nhất quán, không thay pin của bản được duyệt.

Process thứ hai dùng cùng DB phải dừng trước recovery hoặc provider. Không xóa file runtime lock để cố mở; OS tự nhả quyền khi process kết thúc. Không chạy server có model trên bản sao DB có hạn mức thật.

## Schema và phục hồi

Runtime chỉ nhận contract được ghim, không tự nâng hoặc backfill. Operator chung giữ từng DDL transaction và biên nhận bền vững; bốn bước M1–M4 không được mô tả là một transaction. Nếu bị ngắt, kiểm receipt và schema để quyết định bước tiếp; không chạy lại toàn bộ để “thử vận may”.

Backup riêng tại cutover giữ nguyên dữ liệu trước nâng. Phục hồi luôn thử ở đường dẫn mới. Sau khi có ghi nghiệp vụ mới, không chép backup cũ đè MAIN: cần bảo toàn SSOT, receipt, hạn mức và raw output đã phát sinh. Không dùng bản backup cũ làm authority ngân sách thứ hai.

## Tri thức và nội dung thật

Màn biên soạn dùng phiên của app chính; role/scope kiểm trên server. Không tự gán thêm quyền cho chủ doanh nghiệp hoặc chuyên gia. Nháp M3 ở staging không được copy sang kho phục vụ như nội dung đã phát hành. Phải có bằng chứng đầy đủ, review đúng revision/hash và release đúng scope.

Nguồn cũ chưa có causal observation sau nâng cấp chưa đủ để dùng mới; chỉ đọc không tự tạo anchor. Observation kiểm nguồn mới qua writer chung khác quyết định duyệt nội dung. Lịch sử giữ manifest gốc và kiểm quyền READ hiện tại; nguồn bị revoke thắng shortcut sở hữu.

## AI và chi phí

Bootstrap/nâng schema/status/cache/phục hồi không gọi AI. App thật chỉ gửi khi có consent và hạn mức hợp lệ qua Gateway chung. Không tự thử lại hoặc đổi sang mô hình có phí. Hạn mức batch xây kho và quỹ tester là hai phạm vi đã duyệt riêng; không chuyển phần còn lại giữa hai quỹ.

Theo dõi RCA: DF-042 về identity, DF-043 về quiescence/evidence, DF-049 về schema/runtime. Các lớp thiết kế toàn hệ thống vẫn D1; kiểm local không chứng minh triển khai nhiều máy hoặc tính đầy đủ pháp lý của kho.
