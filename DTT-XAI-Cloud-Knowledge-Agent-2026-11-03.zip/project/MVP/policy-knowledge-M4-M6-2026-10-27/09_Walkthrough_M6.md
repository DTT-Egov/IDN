# M6 — chạy một bước, dùng lại kết quả, không tự gọi lại AI

27/10/2026. **Worker C6 đã phục hồi S2 và lưu thêm S3/S4; O1 có JSON dở dang, batch dừng trước O2.** Hiện5lượt/4nháp/ước0,217632USD; M6b chưa hoàn tất. [Đợt Claude thật mới nhất](<13_M6_Ket_qua_4_slot_Claude.md>) · [Sửa lexical C6](<12_M6_Claude_that_va_sua_trich_dan.md>) · [Bàn giao](<11_Ban_giao_M6.md>). App chính vẫn là M5 tại http://127.0.0.1:8025/web/. Worker vận hành kho công khai; không đưa quyền cấp tiền/resume cho model hoặc chủ cơ sở. Số đo candidate1/C4 bên dưới là lịch sử đúng phạm vi, không phải nghiệm thu Opus hoặc chất lượng pháp lý.

## Kết quả mới nhất

**Sau mốc C4:** người dùng đã đồng ý chạy tiếp. S2 gọi Claude thật một lần rồi batch dừng vì một quote khác xuống dòng. Bản sửa C6 đã đạt94ca hồi quy/30ca độc lập và phục hồi miễn phí S2, bốn slot còn lại chưa gọi. [Walkthrough đợt thật](<12_M6_Claude_that_va_sua_trich_dan.md>) thay cho trạng thái “chờ phê duyệt năm slot” ở các mục lịch sử dưới đây.

- Bản đóng băng:444 tệp; raw manifest SHA-256 `cd57e7864ad1285d663924197c6d61aafd2d138ad3708c7c69f96aad0f794e77`.
- [Diễn tập nâng cấp và phục hồi lần4](<../../../REFERENCE_LINKS.md#ref-0115>): giữ79bảng cũ, không tạo control/head/anchor, không sửa prepared hoặc cấp tiền/gọi AI. [Đã áp dụng vào kho thật](<../../../REFERENCE_LINKS.md#ref-0116>) sau gate trước operator; [review độc lập cuối](<../../../REFERENCE_LINKS.md#ref-0117>) tự đối soát backup/dữ liệu/schema/receipt và READ không ghi.
- [Diagnostic C4](<../../../REFERENCE_LINKS.md#ref-0118>):30câu khác nhau, intent30/30,100lần dùng lại,0ghi DB/0model. Chất lượng pháp lý và chi phí duy trì chưa đánh giá được; không dùng số này chấm chất lượng câu trả lời thật.
- [Kiểm HTTP app chính](<../../../REFERENCE_LINKS.md#ref-0119>): trang và3asset khớp byte M5 đã duyệt, không đăng nhập/gửi câu hỏi hoặc làm gián đoạn8025.

| Bản review | Phát hiện và quyết định |
|---|---|
| C1 |8caRED: corpus ngoài phạm vi, dừng sauresume, envelope, stateprojection và kiểu boolean; chặn chuyển mốc|
| C2 |Các ca trên sửa được nhưng mất legacy pause-root vẫn mở slot; chặn nâng kho thật|
| C3 |Legacy storage đã được bảo vệ; còn4RED về terminal evidence/đối soát phí; tiếp tục chặn|
| C4 |Thêm terminal barrier chung và bảo vệ cả event kernel; author63/63, reviewer tái chạy63/63;40ca độc lập gồm34adversarial+6external đạt; sau operator đạt audit chỉ đọc|

[Sửa kiến trúc và cổng vận hành](<10_M6_Sua_thiet_ke_va_gate_operator.md>) giữ plan/receipt và các review. Thử sửa riêng grant.state khi giữ chứng cứ dừng phải bị chặn cả ở checkpoint và đường Gateway trực tiếp. Exact receipt cũ vẫn là lịch sử đọc được, không kích hoạt lại batch.

## 1. Đọc trạng thái batch thật

[Audit chỉ đọc](<../../../REFERENCE_LINKS.md#ref-0120>) đã dùng worker đóng băng để mở đúng kho M3 gốc. Hash toàn dữ liệu trước/sau bằng nhau,0ghi/0gọi AI, không đọc API key.

| Nội dung | Kết quả thực |
|---|---|
| S1 | Đã có raw output và proposal, còn chờ chuyên gia |
| S2/S3/S4/O1/O2 | Chưa gọi |
| Trạng thái hạn mức | Đang tạm dừng để rà đầu ra |
| Lượt đã dùng |1Sonnet từ M3, không có lượt mới trong M4–M6 tới audit này|
| Chi phí đã biết |Ước tính theo token0,029836USD; không phải hóa đơn đã đối soát|
| Thời hạn gốc |07:40:33 ngày29/10/2026, UTC+7|
| Bước tự chạy kế tiếp |Không có|

Phục hồi S1 miễn phí trước đó không tạo quyền resume. [Đề nghị tiếp tục5slot](<../../../REFERENCE_LINKS.md#ref-0121>) đang chờ câu trả lời; chưa tạo biên nhận đồng ý hoặc chạy model thay người dùng.

## 2. Thử ngắt tiến trình — dữ liệu THỬ NGHIỆM

1. Dùng kho riêng và model giả, qua đúng Gateway/manifest/ledger chung.
2. Một SDK giả trả output, Gateway commit raw/usage. Ngay trước tạo proposal, tiến trình con tắt hẳn bằng exit41; không có exception handler chạy.
3. Đọc lại thấy S1có phản hồi nhưng chưa handoff thành proposal. Lệnh chạy tiếp chỉ ghi pause, không gửi S2 hoặc gọi lại S1.
4. Phục hồi proposal bằng output cũ. Batch vẫn pause; cần quyết định resume riêng, kiểm cùng grant/instance/corpus/pause-set/expiry.
5. Khi thử resume có chủ đích trong fixture, chỉ state đổi cùng receipt, mọi điều khoản/số dư/expiry giữ nguyên. Replay cùng quyết định trả receipt cũ; thay nội dung bị từ chối.

Ca thật trên tiến trình con nằm trong `test_knowledge_m6_worker.py`; đây kiểm crash/cơ chế, không là một lượt Claude thật. Các ca timeout, hai worker, source revoke, READreceipt sau mất EXPORT và hết hạn cũng không dùng API trả phí.

## 3. Bộ30câu và100lần dùng lại — số đo candidate1 được giữ để đối chiếu

[Câu hỏi đóng băng](<../../../REFERENCE_LINKS.md#ref-0122>) · [số liệu kỹ thuật](<../../../REFERENCE_LINKS.md#ref-0123>).

30câu khác nhau gồm đào tạo, xuất khẩu, hai nhu cầu, phủ định và ngoài phạm vi. Intent khớp kỳ vọng30/30 trên tập này.100lần đọc lại không thay DB hoặc gọi model. Nguồn/wiki/capability của fixture đều THỬ NGHIỆM; không có dữ liệu doanh nghiệp thật hoặc quyết định chuyên gia thật.

A tìm snippet nguồn qua SQL/FTS và ACL. B giữ A, thêm public release đã qua các proof hiện hành. p50 trong lần đo này A≈1,76ms; B≈12,21ms; đọc lại B≈12,40ms. Hai đường trả loại đầu ra khác nhau, thứ tự đo cố định; **không kết luận B nhanh hơn/tốt hơn hoặc wiki rẻ hơn**. Số ký tự không phải token tính tiền. Tập nhỏ một chính sách giả không kiểm quy mô production.

Chất lượng pháp lý, độ đúng câu trả lời, critical-claim coverage: **chưa đánh giá được**. Điểm chất lượng, công chuyên gia/bảo trì để trống có nghĩa; không thay bằng0. Muốn đánh giá A/B câu trả lời thật cần corpus/gold chuyên gia và batch cùng model/giới hạn được duyệt riêng.

## 4. Lịch sử kiểm candidate1 và phần còn chờ

13ca mới đạt trên working source; frozen candidate1 có41ca liên quan M3/M6 đạt. Không cộng hai lần chạy thành một full-run. Hash candidate1: `b4b02ffe4710702f08d6d7b91f24583925f29b480f25178dc463ce5ea3b4aed0`,440file. Reviewer sẽ tự kiểm trước nhận scoped pass; các issue mới cần sửa/freeze lại.

Chưa resume hoặc gọi5slot còn lại, chưa nhập/publish proposal vào MAIN, chưa có chuyên gia duyệt nguồn toàn vẹn/hiệu lực. Không bật lịch AI, thêm model/provider, domain, embedding, vector/graph DB hoặc framework mới. Những phần này không tự được mở bởi nghiệm thu kỹ thuật M6.

Theo dõi DF-013/014/027/028/033/042/043/049/056/059; [thiết kế worker](<08_M6_Thiet_ke_worker_va_danh_gia.md>) và [sổ RCA](<../architecture/DESIGN_FLAWS.md>) giữ riêng bản vá và lớp thiết kế còn mở.
