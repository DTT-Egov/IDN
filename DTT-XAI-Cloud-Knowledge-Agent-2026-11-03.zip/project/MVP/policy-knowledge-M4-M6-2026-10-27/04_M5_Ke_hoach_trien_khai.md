# M5 — kế hoạch triển khai local và phục hồi

27/10/2026. M4 candidate4 đã qua review kỹ thuật độc lập. M5 chỉ triển khai kỹ thuật; không phát hành nội dung chính sách thật, không tự gọi AI hoặc mở lại batch M3.

## Bản chuẩn bị để review

Candidate `M5-candidate2`,437tệp, raw manifest SHA256`eaff60188236c8b0527d769a61d7b2d6b9356def8a46e9f7f90d5c485345dd34`. Build `policy-knowledge-m5-2026-10-27`, ứng dụng0.5. Gói có launcher kiểm byte, nguồn và giao diện đóng băng, hợp đồng schema M4 ghim riêng. CLI kiểm hợp đồng đó trước dựng managed runtime; vẫn giữ V17 làm baseline operator, không thay default để hợp thức hóa drift.

[Diễn tập2](<../../../REFERENCE_LINKS.md#ref-0106>) đọc MAIN bằng kết nối chỉ đọc rồi chỉ nâng bản sao riêng.100bảng cũ giữ nguyên,4migration receipt mới,40bảng mới,0anchor/backfill/role/budget/model attempt thêm; managed factory không sửa dữ liệu. Phục hồi backup vào đường dẫn mới khớp mọi chữ ký dữ liệu cũ và đạt contractV17. Không chạy server/model trên bản sao có ngân sách thật.

## Trước cutover

1. Reviewer kiểm đúng package/manifest, migration, restore, launcher và kịch bản mobile độc lập. Không có signoff kỹ thuật trước cutover thì chưa thay8025.
2. Kiểm byte một lần nữa, nhận diện đúng tiến trình hiện đang giữ8025 và đúng launcher V17. Không dừng các app/tiến trình khác.
3. Giữ giao dịch ghi để khóa reservation mới, kiểm cả lượt model và nghiên cứu queued/running; còn việc đang chạy thì dừng cutover, không ngắt SDK. Khi trống mới dừng đúng tiến trình cũ; lấy khóa runtime canonical trước nhả giao dịch. Không khởi động thêm authority trên một bản DB sao.
4. Backup mới của DB thật sau khi đã dừng, lưu bản cũ của start-main.cmd và các kế hoạch/biên nhận. Không dùng backup diễn tập thay backup tại thời điểm chuyển.

## Thực hiện

Áp dụng đúng4plan đã review, bằng schema operator chung chỉ cho DDL, có backup/lock/receipt và kiểm checksum nguồn. Đối soát mọi bảng cũ, receipt cũ, grants và SSOT; không backfill. Kiểm hợp đồng ghim và managed factory không ghi dữ liệu trước nhận traffic.

Đổi start-main.cmd sang launcher đã ghim, mở tiến trình ẩn tại127.0.0.1:8025. Không tự retry/fallback. Kiểm health/build/assets/schema, phiên và cách ly, không gọi AI trong smoke. Khi app chạy, lịch kiểm nguồn miễn phí đã được phép trước đây có thể ghi observation mới; phải phân biệt các ghi này với migration và cập nhật SSOT/grants. Quan sát mới không tự thành phê duyệt pháp lý.

## Phục hồi có điều kiện

Diễn tập restore dùng đường dẫn mới, không đè dữ liệu thật. Trước khi nhận bất kỳ ghi nghiệp vụ/lượt có phí mới nào, backup tại cutover là phương án phục hồi; lưu lại DB lỗi và lịch sử operator trước xử lý, không xóa dấu vết.

**Sau khi đã nhận ghi hoặc lượt AI mới, không tự chép backup cũ đè DB.** Làm vậy có thể mất SSOT/receipt hoặc hồi sinh hạn mức. Phải giữ DB, dừng tác vụ mới nếu cần, đối soát và sửa tiến; rollback code đơn thuần về V17 cũng không được bỏ qua kiểm schema M4. Nếu có dữ liệu cần quyết định thì trình người dùng, không sửa raw/history để các bài kiểm đạt.

## Nghiệm thu và chi phí

Review M5 sau cutover kiểm byte/build/HTTP và flow mobile miễn phí trên tài khoản THỬ NGHIỆM riêng nếu cần; không đụng hồ sơ thật, không tạo đồng ý trả phí thay người dùng. Nếu QA thật chưa có nguồn/wiki phát hành hợp lệ thì ghi blocked/not_run, không giả dữ liệu pháp lý. Quỹ tester gốc20USD giữ tại MAIN; không sử dụng bản sao để gọi SDK.5slot M3 vẫn pause chờ quyết định riêng đã hỏi.

M6 chỉ bắt đầu sau signoff M5. Worker/benchmark không tự tạo quyền phát hành hoặc thêm domain/framework.

## Chi tiết khóa của công cụ chuyển bản

`output/policy-knowledge-M4-M6-2026-10-27/cutover_m5.py` mặc định chỉ đọc, chỉ mutation khi có `--execute`. Giữ giao dịch SQLite qua bước kiểm việc đang chạy/dừng đúng process, lấy canonical runtime lock trước nhả giao dịch. Backup dưới khóa đó. Mỗi DDL sau đó lấy khóa qua **schema operator chung**; không lồng khóa bằng monkeypatch hoặc thêm authority. Giữa các transaction có bước bàn giao khóa: nếu runtime khác chiếm được, operator dừng an toàn, không tự thử lại. Không nhận cả bốn migration là một transaction nguyên tử. Hợp đồng schema chặn V17 mở DB sau bước M1; mọi kiểm tra và backup giữ để đối soát nếu bị ngắt. Sau bốn bước, lấy lại khóa để kiểm dữ liệu và factory, rồi nhả khi khởi động launcher mới. Không tự restore sau lỗi.
