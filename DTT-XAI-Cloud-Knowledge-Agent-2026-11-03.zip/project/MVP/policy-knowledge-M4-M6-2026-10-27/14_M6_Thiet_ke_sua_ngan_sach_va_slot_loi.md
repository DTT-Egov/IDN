# M6 — phương án sửa sau đợt Claude thật

Ngày27/10/2026. **Đề xuất để trao đổi, chưa triển khai và chưa xin gọi thêm AI.** [Kết quả thực](<13_M6_Ket_qua_4_slot_Claude.md>) dừng ở O1; O2 chưa gọi. Không nhận M6b đã đạt từ94ca hồi quy/30ca độc lập của bản lexical C6.

## 1. Execution profile trong Model Gateway chung — DF-061

Registry do server quản lý chọn model, effort, chế độ thinking được model hỗ trợ, trần tổng output, giới hạn artifact và phiên bản profile theo purpose/recipe. Trước reserve, compiler đưa policy đã chọn vào request identity/manifest và tính hold từ cùng tổng token. Transport thực thi đúng policy được niêm phong, không bổ sung mặc định không truy vết được. Giữ một SDK, một sổ usage và một thẩm quyền D06.

Ngân sách tiền là trần cứng; `max_tokens` là trần tổng thinking+text, không phải dung lượng JSON bảo đảm. Profile cần được kiểm cho cả khả năng hoàn tất artifact lẫn giá tối đa. Không giả định tắt được thinking trên Opus5.5; không tự tăng token limit, đổi effort/model hoặc chia nhỏ thành nhiều paid call để vượt scope gốc.

**Điểm cần chốt về chi phí trước live qualification:** giữ trần0,50USD/lượt Opus hay duyệt mức khác; artifact review cần kiểm bao nhiêu nhận định trong một lượt; ngưỡng chấp nhận incomplete. Chưa chọn token limit mới hoặc gọi lại O1. Sau khi profile/schema/test miễn phí có bằng chứng, mới trình batch live với số lượt/giá cụ thể; grant cũ không dùng làm phép retry O1.

## 2. Hợp đồng artifact theo mục tiêu — DF-025/026

Giữ proposal là lớp chưa duyệt nhưng tách artifact schema: wiki có sections và claims; FAQ có question/answer/evidence/gap; checklist có action/input/output/evidence; critique có target-claim IDs/finding/severity/evidence và coverage chưa rà. Mọi nhận định vẫn đi qua source binding/admission chung.

Không đổi cùng lúc toàn bộ agent. Trước hết thiết kế bounded critique cho mục tiêu O1/O2: ưu tiên phát hiện rủi ro quan trọng, giới hạn độ dài, trả rõ target nào chưa rà. Từng câu hỏi/công việc có done criteria; JSON hợp lệ hoặc `proposal_saved` chỉ là thành công kỹ thuật, không tự là completed goal. Có thể dùng evidence atoms/IDs do server tạo để giảm việc chép quote và độ dài, nhưng phải giữ original spans/version/ACL, không biến ID thành kết luận semantic.

**Điểm cần chốt nghiệp vụ:** người dùng muốn tài liệu demo có tối thiểu những mục/Q&A/công việc nào. Không chấm output thiếu cấu trúc là đạt chỉ vì có chữ “FAQ” hoặc “Checklist”. Không lấy nhận xét của AI làm gold pháp lý hoặc quyết định chuyên gia.

## 3. Completion receipt — DF-062

Trong shared Gateway, lưu normalized provider outcome trước validation, cùng UoW raw/usage: reported model, request ID, provider stop reason đã lọc, tổng token, độ dài visible text và execution-profile hash. Sau validation, ghi mã cơ học riêng cho JSON chưa đủ/schema/model/stop mismatch. Không lưu thinking text, secret hoặc toàn bộ lỗi SDK có dữ liệu nhạy cảm.

Legacy O1 giữ metadata unknown ở những trường chưa lưu; không backfill stopreason suy đoán. Status/recovery chỉ đọc receipt, không gọi lại AI. Nếu phải thêm schema, dùng migration operator/backup/rehearsal/receipt; không DDL trong constructor hoặc runtime.

## 4. Quyết định xử lý slot lỗi — mở rộng lifecycle có kiểm soát

Hiện fail-stop chặn mọi slot sau lỗi; điều này đúng hợp đồng đã chốt nhưng chưa có bước xử lý một failure không thể phục hồi. Không đổi O1 từ rejected sang accepted, không xóa attempt hoặc làm lại operation ID.

Phương án đề nghị: một quyết định operator bất biến cho failed-slot disposition, ghim grant/instance/attempt/rawhash/outcome/expected lifecycle head và lý do. Có thể xác nhận “kết quả này không dùng được, giữ để đối soát”; quyết định không trả lại lượt/tiền hoặc tạo quyền retry. Slot độc lập chỉ được chạy khi dependency graph cho phép và có quyết định tiếp tục/D06 hiện hành. O2 phụ thuộc S3/S4, không dùng O1 làm căn cứ; phải chứng minh điều này ở reserve/fence, không chỉ scheduler.

Thiết kế action/schema mới cần review rõ quyền, CAS, replay/currentREAD, terminal states, nguồn revoke và money invariants. Không áp dụng quyết định này vào grant thật khi chưa có hợp đồng/test/operator được duyệt. Thử O1 lại là một tác vụ mới có phê duyệt riêng, không giả là slot chưa dùng hoặc lấy O2 làm repair.

## 5. Trình tự và điểm dừng

1. Review tài liệu kiến trúc/profile/artifact/disposition và chốt yêu cầu nghiệp vụ/chi phí ở trên. **Dừng trao đổi trước quyết định làm thay đổi tác vụ trả phí.**
2. TDD miễn phí với fake provider có thinking+text, output ở giới hạn, JSON thiếu, schema lệch và source sai; failed-slot không tự refund/skip/retry. Kiểm sharedGateway, manifest, legacy receipt, ACL và crash/CAS; review độc lập bản đóng băng.
3. Nếu có DDL: diễn tập trên bản sao, giữ raw/usage/terms, operator đúng target/backup/receipt; review trước và sau apply. Không sửa MAIN/SSOT để test đạt.
4. Trình batch live cụ thể với giới hạn mới đã kiểm; chỉ gọi sau phê duyệt. Review kết quả lưu, báo completion/coverage/chi phí và phần nguồn/chuyên gia còn thiếu. Không nhận regression xanh là nghiệm thu chất lượng thực.

Đây là backlog/đề xuất. Chưa triển khai execution profile mới, schema critique mới, completion metadata hoặc failed-slot adjudication trong đợt vận hành này.


## 6. Bổ sung sau trao đổi ngày 27/10

[Thiết kế chi tiết](<15_Chot_dau_ra_review_mo_phong_va_nhanh_doc_lap.md>) ghi nhận chuẩn một trang tổng quan, 5 FAQ, checklist 5–7 việc; trần 0,25 USD/Sonnet và 0,50 USD/Opus, thử ba mức từ cao xuống thấp. Gói bàn giao agent review có hash/rubric/mode mô phỏng. Nguyên tắc giữ O1 lỗi và quyết định riêng để tiếp tục nhánh độc lập đã được chủ dự án nêu rõ. Các mục “cần chốt” ở phần trước là lịch sử trước quyết định này. Pilot 6 lượt/trần đề xuất 1,70 USD chưa được cấp D06. Chưa gọi AI từ thay đổi thiết kế.

Ghi chú hiệu chỉnh: đoạn bổ sung trước bị hỏng dấu khi ghi qua pipeline shell; đã sửa văn bản UTF-8, không đổi nội dung quyết định hoặc dữ liệu vận hành.
