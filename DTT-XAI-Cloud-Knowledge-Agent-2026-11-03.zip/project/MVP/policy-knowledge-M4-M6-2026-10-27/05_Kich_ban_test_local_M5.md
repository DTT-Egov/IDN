# M5 — kịch bản thử app chính và màn chuyên gia

27/10/2026. Tài liệu chuẩn bị trước triển khai; trạng thái thực tế phải đối chiếu biên bản M5 cuối. Không bấm nút AI có phí trong kịch bản này.

## Chủ cơ sở — mobile 320 và 390 px

1. Mở http://127.0.0.1:8025/web/ bằng tài khoản THỬ NGHIỆM riêng. Kiểm build `policy-knowledge-m5-2026-10-27`. Mở Hồ sơ, đối chiếu sản phẩm/dữ kiện/lịch sử có sẵn; không xác nhận thay đổi ngoài mục đang thử.
2. Chọn Chính sách Hà Nội, hỏi “Chị muốn hỗ trợ xuất khẩu Trà Sen sang Mỹ và đào tạo nhân viên làm sổ sách buổi tối”. Chọn tra cứu miễn phí. Cả hai nhu cầu phải có dòng riêng; phần thiếu nguồn nói rõ, không đổi sang chính sách khác hoặc tự kết luận đủ điều kiện.
3. Mở các phần giải thích và nguồn. Nếu chưa có wiki phát hành đúng nhu cầu, phải hiện thiếu căn cứ; không lấy bản AI đề xuất/chờ duyệt làm câu trả lời đã duyệt. Bản gốc và giải thích tiếng Việt cần phân biệt.
4. Tải lại. Câu hỏi và kết quả đã lưu vẫn giữ; không tự phát sinh lượt AI. Lịch sử và ngân sách chỉ đọc.
5. Hỏi tồn kho “Sổ 120 hộp, thực đếm 110 hộp”, bổ sung “Ngày 18/10/2026, mã TS01”, rồi tải lại. Phải giữ mạch đối chiếu, không chuyển sang xuất khẩu hoặc sản phẩm khác.
6. Hỏi về sản phẩm Mứt Sen mới trong hội thoại riêng. Kiểm nháp riêng, chưa xác nhận thì SSOT Trà Sen không đổi. Nếu thử xác nhận, chỉ chọn các trường cần lưu; các trường còn lại vẫn có đường xác nhận sau tải lại.
7. Đăng xuất, mở tài khoản thử khác. Không còn nội dung chat/nháp riêng trong màn hiện tại hoặc màn chuyên gia; kết quả đến muộn không được ghép sang tài khoản mới.

## Chuyên gia — công cụ biên soạn

Mở http://127.0.0.1:8025/knowledge/ sau đăng nhập app chính. Không tự cấp vai trò. Chỉ người có quyền chuyên gia và scope tương ứng mới được biên soạn/duyệt/phát hành. Tài khoản chủ cơ sở thường bị từ chối; đây là kết quả đúng.

Các bản công khai dùng trong kiểm kỹ thuật nằm ở môi trường thử riêng. Không nhập các quyết định chuyên gia giả vào kho thật để làm kịch bản đạt. Batch M3 thật vẫn ở staging, chưa có quyết định duyệt/phát hành và không tự trở thành nội dung phục vụ.

## Dấu hiệu phải dừng và báo lỗi

- Có dữ kiện doanh nghiệp khác, chọn nhầm sản phẩm hoặc mất trường chưa xác nhận.
- Nói đủ điều kiện hưởng chính sách khi nguồn/quy tắc chưa duyệt.
- Tải lại/status/cache tự gửi model; nút miễn phí làm giảm lượt hoặc có phí.
- Thiếu nhu cầu thứ hai, bỏ “buổi tối”, thông báo thành công cho thao tác bị từ chối.

Ghi câu hỏi, bước, thời điểm và tên tài khoản thử; không gửi mật khẩu/API key. Mốc này theo dõi DF-014/016/024/025/027/028/033/042/043/048/049. Các lớp thiết kế còn mở không được coi đã đóng chỉ vì ca cũ đạt.
