# M4 — hợp đồng phục vụ và RCA trong đợt triển khai

27/10/2026. Các phát hiện dưới thuộc code trước freeze M4 hoặc seam kế thừa; không phải bằng chứng app8025 đã trả lời sai trong đợt này. Test chỉ dùng nguồn và doanh nghiệp thử riêng, không gọi AI trả phí.

## DF-027/033 — thiếu đầu nguồn trong dependency closure

**Bằng chứng:** [RED](<../../../REFERENCE_LINKS.md#ref-0086>),2ca: sau khi wiki đã duyệt/phát hành, đổi snapshot gốc hoặc đánh dấu nguồn không đọc được ở catalog hiện có; consumer M4 ban đầu vẫn trả bản như usable. Pipeline reader đã kiểm state/rendition/extraction/rights M1–M3, nhưng chưa theo thay đổi ở source catalog mà hệ thống cũ vẫn cập nhật.

**Cơ chế:** hai đường tiếp nhận cùng source ID không được nối đủ trong manifest phụ thuộc. Kiểm một nhánh đúng không chứng minh toàn closure còn đúng. Đây là tái diễn biên nguồn/graph DF-027/033, không lỗi xưng hô hoặc quote-match.

**Sửa:** thêm `KnowledgeCatalog.source_control_ref` chỉ đọc current source/snapshot và operational gate hiện có. Review manifest M4 ghim upstream identity/snapshot/content metadata. Known unavailable/changed/superseded chặn current-use theo outcome. Operational check thành công lặp lại không tự thành revision pháp lý hoặc làm thay body/review hash; source/rights/attestation vẫn được kiểm qua authority cũ. Không tạo lịch, AI refresh hoặc một bộ quyết định phí khác.

**Bất biến:** new-use/fence phải xét đủ upstream closure; READ lịch sử giữ bản nguồn/URL/lang gốc và vẫn kiểm READ hiện hành. Source mới/ngoại lệ không bị bỏ qua vì wiki vẫn còn link tốt.

**Còn mở:** qualification seam legacy, causal integrity của các gate cũ, currentness/độ đủ nguồn thật và mọi adapter ngoài scope pilot. Bản vá hai ca đã GREEN, chưa nâng D2 hoặc nhận legal completeness.

## DF-024/025 — goal đúng nhưng rơi yêu cầu cụ thể

Phân tích trước chỉ giữ goal đào tạo; câu gốc còn “buổi tối” nhưng DTO tối thiểu gửi model không có lựa chọn lịch học. [RED request constraints](<../../../REFERENCE_LINKS.md#ref-0087>) xác nhận thiếu trait ở lớp intent/response; chưa phải phép đo câu trả lời Claude thật.

`policy-request-constraints/1` thêm enum `training_schedule=evening`, chỉ khi nêu tích cực và thuộc goal đào tạo. Có ca phủ định và câu ngoài phạm vi. Không thêm fact SSOT hoặc đưa raw chat ra ngoài D05. Khi chưa có dữ liệu xác nhận lịch học, bundle ghi constraint chưa đáp ứng và task xác minh lớp buổi tối; không gọi giải thích đào tạo chung là đã đáp ứng yêu cầu. Intent method lên9; receipt cũ không sửa, bản chưa gửi cần reprepare nếu semantics đổi.

## DF-014 — nguồn lịch sử không dùng metadata hôm nay

Trong adapter M4 ban đầu, citation lấy URL/lang từ `_state` hiện tại dù body/ref là bản phát hành trước. Xác định bằng đọc code trước freeze, chưa có sự cố MAIN hoặc RED cũ cho URL. Đã chuyển citation sang source manifest đã được review gốc; READ quyền hiện hành kiểm riêng. Test regression phải đổi URL manifest rồi đọc history, không chỉ đổi raw bytes giữ cùng URL.

**Đính chính sau kiểm pre-freeze:** test đổi URL bị M2 guard từ chối “URL khác identity nguồn”; không có write để tái hiện URL đổi qua lệnh đó. Nhận định URL có thể đổi âm thầm chưa được chứng minh và được rút trong phạm vi API này. Giữ ca âm URL và kiểm biến thể language được phép thay; lịch sử phải giữ ngôn ngữ review gốc. Không sửa dữ liệu hoặc bỏ guard để làm test đạt. Bản sửa chọn manifest gốc cho cả hai trường là bảo toàn receipt; bằng chứng language được báo riêng, không gọi ca URL là đã tái hiện.

## Hợp đồng đang triển khai

- Applicability là immutable record của exact page/revision; goal hữu hạn, VN-HN, thời gian và chỉ explain_public_policy. Gắn sau review làm hash cũ không đủ; sửa scope cần revision mới. Null ngày kết thúc chỉ biểu diễn văn bản không quy định ngày kết thúc, không phải bằng chứng cho lịch tiếp nhận.
- Public READ chỉ exact revision có release/review/binding/hash đúng; không mượn curator. New draft không được mở vì page từng phát hành. Archive/withdraw không tự thu hồi lịch sử; revoke READ nguồn chặn cả owner/cached derivative.
- Public bundle không chứa SSOT/câu hỏi doanh nghiệp. Private case mới gắn context manifest; A/B dùng chung public refs, giữ riêng facts và câu hỏi.
- Model schema3 chỉ thêm lựa chọn wiki section IDs có enum khi thực sự có wiki. Wiki không trở thành rule/eligibility; legacy schema2 và receipts không được thêm default refs mới.
- Public refs vào canonical request manifest và Gateway kernel chung; READ ở replay, current-use+EXPORT ở reserve/fence, kiểm lại trước công bố sau inference. Không transport/retry hoặc ngân sách thứ hai.

Tình trạng bản vá và thiết kế theo [sổ DF](<../architecture/DESIGN_FLAWS.md>); chưa nhận M4 nghiệm thu trước reviewer độc lập trên frozen build.

## Review candidate1 → candidate2

[Review độc lập](<../../../REFERENCE_LINKS.md#ref-0088>) chặn gate vì2lỗi dù82author/20ownbackend đã đạt. DF-049/043: adapter riêng không có catch-all nên bỏ sót host composition. Basehost nay có finalize transport một lần; main đăng ký mọi route trước rồi gắn MCP cuối, thay4patch thứtựroute rời rạc. Phiên/CSRF/capability và bearerMCP vẫn do authority cũ kiểm. Fixture xây managedhost sau migration, kiểm index/session/RPC qua HTTPthực.

DF-016/028: modelstate đã reset nhưng các input/preview/nguồn/lýdo riêng cònDOM; focus tab không hỏi lại phiên. Reset presentation dùng chung nay xóa các trường và dữ liệu dẫn xuất, revalidate bằng GETsession khi focus/visible, ghim scopeEpoch trước/sauRPC. Chỉ đọc phiên và giữserverbuffer, không gọi model/tựghi/xóa nháp. [RED2](<../../../REFERENCE_LINKS.md#ref-0089>) → [GREEN4gồmfocusepoch](<../../../REFERENCE_LINKS.md#ref-0090>). Candidate2 đang được kiểm lại bằng browserfullhost; không lấy unit GREEN thay quyền đọc thực.

DF-042: rawhash manifestcandidate1 khác công bố vì newlineWindows,431filekhớp0drift. Giữ nguyên bytecandidate1 và [receiptđínhchính](<../../../REFERENCE_LINKS.md#ref-0091>). Công cụ freeze sau ghi bytes rồi hashbytesđọc lại; candidate2rawhash`feff1c04a705a9486eede47709ccf7beb5367db10910734f765ca5954eb31a60` được root đối soát432file0drift.

## Candidate3 — nguồn cũ không được hồi sinh qua pointer rewind

[F03 của reviewer](<../../../REFERENCE_LINKS.md#ref-0092>) tái hiện2biến thể: chỉ lùi con trỏ snapshot và lùi thêm toàn bộ gate về giá trị cũ. Snapshot/observation mới vẫn còn, nhưng manifest ban đầu không biết quyết định nào là head thật. Đây DF-027/033/048; không phải lỗi mạng hoặc source quote.

M4 chưa phát hành nên chốt lại additive schema trước candidate3: `ks_source_controls` bất biến, predecessor/sequence theo nguồn và unique successor, `ks_source_control_heads` ghim exact decision. Catalog writer chung ghi observation, gate và control decision trong cùng giao dịch; crash làm rollback cả ba. Reader kiểm leaf, record/payload hash, exact source/snapshot/gate/observation. Không chọn authority bằng ngày/UUID/rowid. Đếm observation chỉ là phép bảo toàn version của writer legacy, không dùng để lựa head.

Migration không dựng lại lịch sử hay tự khẳng định nguồn legacy đã hợp lệ. Chưa có post-migration control anchor thì chặn current-use và cần một observation mới qua writer cũ/đợt kiểm nguồn miễn phí hiện có. Không cấp thêm vai trò cho `trung@dtt.vn`; source acquisition không thành xác nhận pháp lý. Expert vẫn phải kiểm đủ bộ/hiệu lực bằng quyết định riêng. Fixture ghi mới một kiểm synthetic sau migration để tạo tình huống thành công, không dùng cách đó với MAIN.

Receipt/history chỉ kiểm READ nguồn gốc và quyết định đã lưu, không đòi hoặc thêm causal proof mới vào manifest cũ. Một kiểm thành công lặp lại làm advance operational chain nhưng không đổi semantic review hash hoặc tự làm mới thời hạn legal attestation. Corruption bị chặn, không chọn/sửa head hộ operator.

[7ca mới đạt](<../../../REFERENCE_LINKS.md#ref-0093>),42ca M4 hiện có đạt riêng; candidate3 đang chạy broad regression và reviewer độc lập. Chưa nhận đã đóng toàn lớp hoặc đạt pháp lý thật.
