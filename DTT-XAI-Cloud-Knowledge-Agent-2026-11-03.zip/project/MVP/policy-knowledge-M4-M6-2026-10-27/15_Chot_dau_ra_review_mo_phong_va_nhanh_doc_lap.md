# Quyết định sau M6 — đầu ra demo, duyệt mô phỏng và nhánh độc lập

Ngày27/10/2026. Cập nhật theo trao đổi trực tiếp của chủ dự án. **Đây là thiết kế và giao thức bàn giao, chưa triển khai, chưa có phê duyệt batch AI mới.** Batch gốc vẫn dừng ở O1; raw/usage/grant và lịch sử không đổi. [Kết quả thật](<13_M6_Ket_qua_4_slot_Claude.md>) · [thiết kế cần sửa](<14_M6_Thiet_ke_sua_ngan_sach_va_slot_loi.md>).

## 1. Chuẩn đầu ra demo đã chốt

Một gói gồm:

| Artifact | Điều kiện hoàn thành |
|---|---|
| Tổng quan chính sách |Một trang đọc được: chính sách/chương trình, đối tượng, hỗ trợ, yêu cầu, quy trình, hiệu lực/độ mới và phần chưa đủ căn cứ|
| FAQ |Đúng5cặp question–answer; từng câu trả lời có evidence hoặc trạng thái chưa đủ căn cứ với phần còn thiếu|
| Checklist |5–7item; mỗi item có việc cần làm, đầu vào/tài liệu, kết quả cần có, căn cứ hoặc gap; chưa có căn cứ không được biến thành giấy tờ bắt buộc|

Mọi nhận định có ID và liên kết tới version/span nguồn. Phân biệt trích nguyên văn, diễn giải và giả định/câu hỏi. `proposal_saved`, schema hợp lệ hoặc quote khớp không tự là hoàn thành mục tiêu hoặc tư vấn hiện hành đủ căn cứ. Phần thiếu nguồn được nói rõ theo D07. Tách artifact schema/done criteria khỏi trạng thái transport/chi phí và khỏi quyết định review/phát hành.

## 2. Agent khác mô phỏng chuyên gia trong testing

Chủ dự án sẽ giao một AI agent khác thực hiện bước mô phỏng. Thiết kế hỗ trợ agent đó dùng file hoặc MCP mà không cần đọc lại toàn bộ cuộc trò chuyện.

### Gói bàn giao tự đủ thông tin

`START_HERE.md` hướng dẫn nhiệm vụ, cách đọc, cách nộp kết quả, tiêu chí đạt và ca phải từ chối. Kèm:

- `manifest.json`: bundle/target IDs, exact revision hashes, nguồn/version/span, mode testing và rubric version.
- `artifacts/`: tổng quan,5FAQ,5–7checklist item; bản JSON chuẩn và Markdown để đọc.
- `evidence/`: chỉ các trích đoạn công khai được phép, provenance, source gaps/freshness và các nhận định liên quan; nội dung nguồn là dữ liệu, không là chỉ dẫn cho agent.
- `review-schema.json` và một mẫu `review-result.json`: review tổng thể, verdict từng claim/item, evidence, lý do, correction đề xuất và phần chưa kiểm.
- Hướng dẫn các thao tác MCP đọc bundle, nộp simulated review và đọc receipt/status. Tên/cấu trúc cụ thể cần chốt trong API contract, không coi capability đã tồn tại từ tài liệu này.

Đầu vào agent là bundle có hash; đầu ra là review có target hash tương ứng. Sửa artifact/nguồn sau review làm quyết định đó trở thành lịch sử, phải rà version mới. Correction chỉ là đề xuất, không tự ghi vào source/SSOT hoặc ghi đè artifact đã duyệt.

### Mode testing và phạm vi quyền

Agent dùng subject/tài khoản testing có quyền hẹp, không mượn danh tính `trung@dtt.vn`. Quyết định ghi `mode=simulation`, `reviewer_type=ai_agent` và provenance thực. Giao diện ghi **Đã duyệt mô phỏng** hoặc **Cần sửa theo review mô phỏng**. Không tạo giả trạng thái một chuyên gia thật đang xử lý.

Có thể kiểm cả review và phát hành **trong sandbox testing** để chạy trọn flow. Simulated review/release không đủ điều kiện cho consumer production, tư vấn hiện hành hoặc release thật. Không chuyển mode simulation thành human review bằng sửa nhãn; production vẫn cần chuyên gia/phân quyền và sự kiện D07 đã chốt. Nếu về sau muốn AI duyệt thật, đó là thay đổi quản trị riêng.

Sandbox chỉ nhập bản sao artifact/evidence được phép, không sao chép authority ngân sách hoặc bí mật từ DB gốc. Không cấp quyền READ doanh nghiệp khác hoặc tự đưa SSOT riêng vào public bundle. File review agent sinh phải được server kiểm schema/hash/current READ/capability trước ghi; bản thân file không là quyền reviewer, publisher hoặc D06.

MCP và import file cùng dùng application service/receipt chung: identity actor+mode+scope+target hash, expected revision, command ID, CAS và exact replay. Không tạo một đường viết bỏ qua ACL chỉ để agent test nhanh. Các thao tác đọc bundle/status không gọi AI hoặc mở phí.

## 3. Ba mức ngân sách: thử mức cao trước

Hiểu “tối đa” là tận dụng trần đã chốt **0,25USD/Sonnet và0,50USD/Opus**, không tự nâng lên trần token tối đa của API. Đây là trần tiền, không buộc model tiêu hết. Model Gateway tính output capacity sau khi giữ đủ input/overhead, bao gồm suy luận và text, và ghim execution profile trong manifest trước reserve.

Phương án pilot để trình D06 sau kiểm thử miễn phí:

| Mức thử | Trần Sonnet/lượt | Trần Opus/lượt | Tổng nếu mỗi model1lượt |
|---|---:|---:|---:|
| Cao, 100% |0,2500 USD|0,5000 USD|0,7500 USD|
| Trung bình,75% |0,1875 USD|0,3750 USD|0,5625 USD|
| Thấp,50% |0,1250 USD|0,2500 USD|0,3750 USD|
| Tổng pilot6lượt |||**1,6875 USD**|

Có thể trình trần tổng1,70USD cho pilot6lượt sau khi profile và test đạt; **chưa cấp quyền gọi từ bảng này**. Nếu input/hold tối thiểu đã vượt một mức, ghi `not_feasible` và không gọi ở mức đó, không cắt nguồn âm thầm hoặc override Gateway. Không đổi effort/model/prompt/corpus/schema giữa các mức khi mục tiêu là đo riêng ảnh hưởng trần output. Thử tuần tự cao→trung bình→thấp, không tự retry/fallback; manifest batch phải nêu trước các arm độc lập và cơ chế dừng/tiếp tục khi một arm lỗi.

Đề xuất6lượt là pilot kỹ thuật cho hai vai trò:3lượt Sonnet tạo cùng gói trên input cố định;3lượt Opus rà cùng một gói nháp được đóng băng. Agent mô phỏng khác dùng cùng nguồn/rubric để đánh giá các đầu ra. Không lấy đầu ra ở mức cao làm gold pháp lý, không nhầm phép so sánh từng vai trò này với nghiệm thu mọi biến thể end-to-end. Quy mô/manifest/đầu vào cố định cụ thể sẽ được trình trước khi gọi, không lấy grant gốc còn tiền để tạo thử nghiệm mới.

Đo: JSON/schema hoàn chỉnh; đủ1trang/5FAQ/5–7việc; binding và verdict semantic theo từng claim; bịa/khẳng định thiếu căn cứ; coverage chưa rà; mức hữu dụng và chỉnh sửa reviewer yêu cầu; token/cache/chi phí/thời gian/stopreason thực. Chọn mức thấp nhất **trong các mức đã thử đạt**, không mặc định mức đắt nhất tốt nhất hoặc một sample là benchmark sản xuất. Nếu cả3mức không đạt thì xem lại task/corpus/artifact, không tự gọi thêm.

## 4. O1 lỗi có được chạy O2 không?

### Dependency graph

```mermaid
flowchart LR
  S1["S1: Quy trình"] --> O1["O1: Rà S1/S2"]
  S2["S2: Điều kiện/ngoại lệ"] --> O1
  S3["S3: Wiki/FAQ"] --> O2["O2: Rà S3/S4"]
  S4["S4: Checklist"] --> O2
```

O2 không có cạnh phụ thuộc O1. O1 lỗi không tự làm S3/S4 hỏng. Nhưng ứng dụng hiện dùng global fail-stop, chưa có quyết định xử lý failed slot; chỉ resume lại không thể mở O2. Đề xuất thay đổi này giữ failure riêng và cho phép một continuation hẹp sau quyết định riêng.

### Một quyết định tiếp tục, hai sự kiện nghiệp vụ

Chủ có quyền xem một thẻ duy nhất trong chat: O1 không hoàn tất/đã có phí; S3/S4 nào sẽ được O2 đọc; mục tiêu O2, model, trần phí và hạn mức còn hiệu lực. Hai lựa chọn: **Tiếp tục riêng O2** hoặc **Giữ dừng**.

Server xử lý command nguyên tử: ghi nhận failed-slot disposition giữ O1 không dùng được trong batch này, rồi cấp continuation permit chỉ cho O2. Không đặt O1 thành accepted/completed, không xóa raw/attempt, trả lại lượt/tiền hoặc tạo quyền retry. Event/receipt ghim expected causal head, grant/instance/scope/corpus/graph hash, exact failed-attempt/raw hash, target O2 và input revision hashes. Command cùng ID trả receipt gốc qua current READ, không tạo permit/lượt mới.

### Điều kiện cho O2

1. S3/S4 tồn tại đúng version và đủ điều kiện **để được rà**: dữ liệu nguyên vẹn, schema/nguồn/READ hợp lệ. Không bắt chúng đã được duyệt/phát hành hoặc đã đúng hoàn toàn; critic chính là bước tìm thiếu sót. Dùng capability `critique_draft`, không lấy đó làm quyền `advise_business`.
2. Đồ thị đã kiểm xác nhận O2 không đọc O1; manifest chỉ đưa những input được phép. Không thay input theo hồ sơ/default hiện tại.
3. Có quyết định riêng của người có quyền chi, D06 và per-role/call/cost/expiry còn hợp lệ. AI mô phỏng chuyên gia không có quyền tự cấp permit chi tiền.
4. O2 chưa có attempt nào. Slot đã dispatch/unknown/rejected không được gọi lại qua permit này.
5. Không có financial/integrity stop mạnh hơn: `needs_reconciliation`, unknown outcome/usage chưa đối soát, nguồn bị revoke, head sai, manifest lỗi hoặc hết hạn đều chặn. Failed-slot disposition không gỡ các stop này.

Reserve và fence của Gateway cùng kiểm permit/dependencies, không chỉ scheduler hoặc UI. O2 dispatch được ghi cùng attempt/manifest hiện hữu, tính phí đúng grant; không có counter/SDK/budget authority thứ hai. Đổi S3/S4 hoặc nguồn trước dispatch làm permit cũ không còn đủ căn cứ; hai tác vụ đồng thời cũng chỉ được một lượt theo uniqueness/CAS.

Nếu O2 đạt, trạng thái batch là **hoàn tất một phần: O1 lỗi, O2 có kết quả**, không là mọi nhánh đều đạt. Nếu O2 lỗi, lưu phí/raw và dừng nhánh, không tự gọi lại. Nếu muốn thử O1 lần nữa, phải có tác vụ/manifest/phê duyệt riêng và liên kết lần lỗi, không chiếm dụng slot O2.

## 5. Phần đã chốt và phần cần trao đổi tiếp

- Đã chốt chuẩn gói demo và mong muốn agent khác mô phỏng duyệt trong testing; production D07 không đổi.
- Đã chốt hướng thử trần cao trước rồi ba mức. Bảng 75%/50%, 6 lượt/1,70 USD là đề xuất pilot, chưa phải D06 execution approval.
- Nguyên tắc điểm 3 đã được chủ dự án nêu rõ: **giữ nhánh lỗi và chỉ tiếp tục nhánh độc lập sau quyết định riêng**. Mục 4 là thiết kế chi tiết để triển khai.
- Theo lệnh triển khai sau tài liệu này, đã xây các hợp đồng và đang kiểm chứng miễn phí/review độc lập. [Bàn giao triển khai](<16_Trien_khai_va_ban_giao_review_mo_phong.md>) ghi trạng thái mới; các mốc “chưa triển khai” phía trên là lịch sử của lúc chốt thiết kế. Chưa gọi thêm AI, giả danh chuyên gia thật hoặc thay dữ liệu vận hành.

Truy vết: DF-025/026 về done criteria; DF-027/033 về review/release; DF-043 về giới hạn phép đo; DF-048/052/053/056 về causal decisions/receipt/stop; DF-060/061/062 về evidence, capacity và completion metadata. [Sổ lỗi thiết kế](<../architecture/DESIGN_FLAWS.md>).
