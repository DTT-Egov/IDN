# M4–M6 — phạm vi thực hiện và review từng mốc

27/10/2026. Người dùng cho triển khai tiếp M4–M6, mỗi mốc review độc lập, sửa lỗi chặn đến đạt rồi mới chuyển. Chỉ dẫn này thay việc phải xin tiếp tục thủ công giữa các mốc kỹ thuật; không thay D04–D07, phê duyệt chuyên gia hoặc tự cấp ngân sách mới. Không triển khai M7.

## Gate hiện tại

M3 đã được reviewer độc lập tái xác nhận scoped technical pass, frozen5 và S1 giữ nguyên. [Tái gate M3](<../../../REFERENCE_LINKS.md#ref-0085>). Nguồn thật chưa đủ, S1 chỉ proposal, chưa có wiki phát hành thật. Kiểm thành công nội dung thật còn chờ chuyên gia; được xây và kiểm technical serving bằng namespace thử riêng, đồng thời kiểm đường thật bị chặn đúng lý do.

## M4 — serving theo outcome, giữ SSOT

1. Thêm contract applicability của từng wiki revision: goals hữu hạn, phạm vi VN-HN, khoảng thời gian và chỉ dùng giải thích công khai; không nâng thành DSL/điều kiện hưởng. Applicability nằm trong manifest chuyên gia rà/phát hành; thêm/sửa sau duyệt làm approval cũ không đủ.
2. Public serving đọc exact released revision bằng chính reader/validator/source-rights hiện có. Không dùng candidate search hoặc mượn actor curator. Metadata/body/gợi ý chỉ xuất hiện sau đủ gate. READ lịch sử còn hợp lệ khi chỉ withdraw/archive; new-use/egress cần current release, source và quyền hiện hành.
3. Evidence bundle `/2` theo từng goal/outcome, exact release/review/source/hash/locator và context manifest riêng. SSOT thuộc actor/doanh nghiệp/sản phẩm đã chọn; không đưa câu hỏi, facts hoặc kết luận doanh nghiệp vào cache domain công khai. Các needs thiếu nguồn vẫn có dòng riêng.
4. Khi gửi wiki cho Claude, refs typed đi vào cùng request manifest/Gateway, kiểm READ ở replay và EXPORT/current-use ở reservation/fence. Không gọi model từ lookup/read/status/reload. Không thêm transport hoặc bộ đếm phí.
5. Chat gọn mobile320/390px, kết luận và bước tiếp theo trước; nguồn tiếng Việt/nguyên bản; thay nguồn thì dừng phần mới, giữ lịch sử có nhãn. Regression nháp/xác nhận riêng/reload/đổi sản phẩm và A/B hai doanh nghiệp.

M4 dùng clone/fixtures riêng; không copy hạn mức tester sang clone để gọi AI (sẽ nhân đôi authority). Live QA enterprise chỉ thực hiện trên authority thực khi đủ runtime/corpus và đúng grant; các ca chưa đủ ghi rõ not_run/blocked, không lấy fixture hoặc S1 xây kho làm gold pháp lý.

## M5 — release local có rehearsal và review

Đóng băng RC; kiểm schema/seed/source/ACL/receipt và restore trên bản sao. Reviewer độc lập tự chạy service và chủ doanh nghiệp mobile trên đúng build; chỉ sau đạt mới backup/preflight/cutover8025. Không backfill SSOT hoặc cấp grant ngầm. Tích hợp host auth/CSRF cho bàn chuyên gia; không dùng callback fixture cố định. Deploy kỹ thuật được phép giữ chính sách chưa đủ nguồn ở trạng thái chặn, không giả nội dung tư vấn đã hoàn tất.

Quỹ tester đọc tại máy ngày27/10: approval `D06-LOCAL-TESTERS-20261026-20USD`, standard10USD/complex10USD, mỗi role100lượt, tổng đã dùng0USD tại thời điểm kiểm; hết hạn02/11/2026 lúc17:55:57(UTC+7). Phải đọc lại trước dispatch, consent đúng tác vụ và không tự retry. Không dùng quỹ này xây kho.

## M6 — worker AI và benchmark

Hoàn thiện worker/checkpoint/failure quarantine qua cùng Gateway, không auto-publish. Read/recovery không AI; grant M3 đang pause không tự mở lại. A/B raw SQL/FTS so với thêm wiki phải giữ cùng corpus/model/question, báo raw counts/chi phí build-maintenance-query/reviewer. Không tự thêm Deep Agents/embedding/OKF.

Gold corpus thật cần chuyên gia xác nhận; nếu còn thiếu thì benchmark kỹ thuật synthetic được ghi riêng, chất lượng pháp lý thật là not_evaluable. Workload AI xây kho mới cần đề nghị D06 riêng trước dispatch. Không dùng lại 5 slot M3 đang pause như một cơ chế sửa kết quả có phí.

## Bằng chứng mỗi mốc

RED→GREEN; frozen manifest; review độc lập và các vòng sửa; ảnh/walkthrough; số model/network dispatch thực; hạn mức/usage; DF IDs và giới hạn. Mốc sau chỉ bắt đầu khi reviewer xác nhận không còn blocker kỹ thuật trong scope đã ghi; phần pháp lý hoặc phí chưa đủ không bị đổi nhãn thành pass.
