# Sửa thẻ duyệt O2: mở/gập, thông báo và mobile — 28/10/2026

Theo kết quả tester trên main: đăng nhập đã thành công, 5 lượt cũ/0,217632 USD, chưa có quyết định O2. Phạm vi sửa là hai lỗi P3 và hai điểm thiếu chữ; không thay quyền, ngân sách hoặc nghiệp vụ tiếp tục nhánh.

## Nguyên nhân đã tái hiện

- **DF-036:** mỗi lần xem trước/đọc trạng thái/lỗi, `render()` xóa toàn bộ thẻ rồi tạo `<details>` mới mặc định đóng. Các dòng model, trần, hạn và chi phí không mất từ server nhưng bị ẩn sau thao tác. Cùng cơ chế đã gặp trong form duyệt chính sách khác; bản vá cũ chưa áp dụng cho component mới.
- **DF-037:** checkbox gọi render thay control/focus; thẻ chưa có live region ổn định khi đổi consent. Vùng status chỉ xuất hiện sau commit nên không thể báo nút đã mở/khóa khi chưa ghi quyết định.
- Thẻ mới thiếu câu “chưa phải hóa đơn” và chỉ nói rõ S3/S4 sau xem trước. Đây là thiếu thông tin trình bày, không có bằng chứng đổi chi phí hoặc thay đầu vào nghiên cứu.

[RED trên DOM thật](<../../../REFERENCE_LINKS.md#ref-0179>). Năm thất bại trực tiếp tái hiện các vấn đề nêu trên; probe thứ sáu lúc RED timeout được giữ là ca chưa quy nguyên nhân riêng, không gán thành bằng chứng lộ tài khoản.

## Bản sửa

1. Giữ trạng thái mở/gập trong phạm vi tài khoản/doanh nghiệp; thay thẻ khi cần mà bảo toàn trạng thái disclosure. Đổi tài khoản thì xóa trạng thái này.
2. Vùng `role=status`, `aria-live=polite`, `aria-atomic=true` giữ node qua các lần render của component. Checkbox cập nhật nút và thông báo ngay tại chỗ, giữ node và focus. Nội dung nói rõ nút đã mở/khóa và chưa ghi quyết định/gọi Claude. Sau xem trước, focus tới checkbox.
3. Lỗi vẫn dùng một `role=alert`, không lặp cùng lỗi trong status. Phản hồi cũ bị guard theo actor/enterprise/generation; logout xóa cả nội dung thông báo riêng.
4. Nêu S3/S4 trước xem trước; ghi chi phí ước tính theo token **chưa phải hóa đơn**. Giữ nguyên trần/hạn/số đã dùng do server cấp.
5. Đổi phiên bản URL của tệp cost-approval.js để tải bản mới. Khi kiểm fixture, reload từng giữ script cũ trong cache; đổi URL khiến browser tải đúng byte sửa. Đây là bằng chứng trên static fixture, chưa khẳng định main đã có cùng lỗi cache.

Không thay backend nghiệp vụ. [So sánh C1→C2](<../../../REFERENCE_LINKS.md#ref-0180>) xác nhận chỉ đổi module UI, main.html, build identity và thêm ba tệp QA; các file backend logic, authority, worker và grant giữ nguyên byte. Không sửa bản đóng băng C1.

## Kiểm thử đã có trước triển khai

| Phép kiểm | Kết quả / giới hạn |
|---|---|
| DOM thật trên source sửa | 6/6 đạt, không approve request, không paid call. [Log](<../../../REFERENCE_LINKS.md#ref-0181>). |
| DOM thật trên bản đóng băng C2 | 6/6 đạt ở static fixture riêng 8037: copy ban đầu, disclosure sau preview/refresh/error, focus/live region, delayed callback khi đổi actor. Không là kiểm HTTP session bị trì hoãn trong trình duyệt thật. |
| Hồi quy C2 đóng băng | 357/357 đạt trong một lần chạy hai suite main-app/main-ui-contracts. [Log](<../../../REFERENCE_LINKS.md#ref-0182>). |
| App đầy đủ trên fixture C2 8036 | 320×740: mở chi phí → xem trước → tích/bỏ, disclosure vẫn mở; focus trên checkbox; summary/input/nút khoảng 44 px, scrollWidth305 < viewport320. 390×844: đọc lại trạng thái vẫn mở; scrollWidth375 < viewport390. |
| Đổi tài khoản trong cùng profile | Đăng xuất tài khoản fixture A qua Hồ sơ → app ở sẵn màn đăng nhập → nhập B trực tiếp; B không còn thẻ/region của A. Console warn/error rỗng. Không dùng mật khẩu thật hoặc main8025. |
| Đối soát thật chỉ đọc trước deploy | 5 lượt/217632 microUSD, O1 blocked/O2 chưa gọi/chưa ghi quyết định; toàn bảng main và public không đổi do phép đọc. [Biên bản](<../../../REFERENCE_LINKS.md#ref-0183>). |

Lần chạy hồi quy source ban đầu có 356/357 đạt: một ca PDF cũ quan sát UI còn pending. Ca đó đạt khi chạy riêng; suite baseline C1 và suite C2 sau đó đều 357/357. File nghiệp vụ và test ca đó không đổi; chưa kết luận nguyên nhân timing từ kết quả này, không sửa code PDF hay xóa log đầu. Chưa chứng minh đã loại bỏ mọi bất ổn của harness cũ.

Ảnh mobile đã hiện trong luồng công cụ, không có bộ ảnh file riêng trong báo cáo này. Đã kiểm DOM/AX/live-region content, **chưa có kiểm âm thanh NVDA/VoiceOver**. Các giới hạn DF-036/037 chung vẫn mở; không nhận D2 từ bản vá component này.

Candidate `M5-cost-candidate2`: 468 tệp, manifest SHA `05e9d632ba23dd0e0a440ae9ce4f3ce8f957e1adb6b40b4bc4f06f27a8fd3840`. Build `cost-card-a11y-2026-10-28`.

## Review độc lập và triển khai đã hoàn tất

- [Review độc lập C2](<../../../reference/reviews/Cost-card-C2.md>) và [receipt](<../../../REFERENCE_LINKS.md#ref-0184>): scoped technical pass; reviewer tự kiểm đủ 468 tệp/hash và đúng 6 file khác C1; backend nghiệp vụ/schema không đổi. Reviewer chạy lại 357 ca hồi quy đạt, thêm 5 probe VM độc lập đạt: phản hồi fetch trễ qua đổi account, JSON trễ qua đổi doanh nghiệp, response sai actor, 403 xóa consent/preview, live region text-only và tránh ghi lặp cùng nội dung.
- Browser reviewer không khả dụng; không nhận reviewer đã tự chạy lại mobile. Bằng chứng native DOM 6 ca và full-main fixture 320/390 nêu trên do root thực hiện. Reviewer không đọc DB thật, không deploy hoặc gọi AI.
- Đã chuyển **8025** sang build mới ngày 28/10/2026 sau kiểm quiescent, không DDL hoặc đổi hạn mức. [Cutover](<../../../REFERENCE_LINKS.md#ref-0185>), [xác minh sau khởi động](<../../../REFERENCE_LINKS.md#ref-0186>): 141 bảng giống backup trước chuyển, asset đúng byte và URL phiên bản, API chi phí chưa đăng nhập trả 401.
- Đối soát thật sau deploy vẫn **5 lượt, 217632 microUSD = 0,217632 USD**, O1 blocked, O2 chưa gọi, 0 quyết định tiếp tục. Không đổi quyền chuyên gia, mật khẩu hoặc SSOT. Paid-worker C6 không đổi.
- Chưa thao tác thẻ bằng tài khoản thật trong UI 8025 sau triển khai; xác minh main bằng HTTP/asset và quyền/trạng thái thật chỉ đọc, UI có phiên được kiểm trên fixture riêng.

## Tester kiểm lại nhanh sau triển khai

1. Tải lại 8025 để nhận bản mới, đăng nhập A, mở “Phạm vi và chi phí”. Nêu được S3/S4 ngay trước xem trước và dòng “chưa phải hóa đơn” khi mở chi tiết.
2. Bấm xem trước miễn phí: model/trần/hạn/số dùng vẫn đang mở. Tích/bỏ checkbox: nút đổi trạng thái, focus không mất; status báo tương ứng. **Không bấm cho phép O2 thật.**
3. Bấm đọc lại trạng thái: chi phí vẫn mở. Lặp ở 320/390 px.
4. Kiểm A06: sau đăng xuất, nếu đã thấy “Mở lại hồ sơ doanh nghiệp”, điền B và bấm nút chính “Đăng nhập”; chỉ tìm link chuyển chế độ khi còn màn tạo tài khoản. Đây là sửa kịch bản tester, không cấp quyền cho B.
5. A07 có probe delayed callback ở fixture; để nghiệm thu HTTP/browser đầy đủ cần làm chậm đúng phản hồi trước đổi tài khoản trong môi trường thử. Không báo đã kiểm đủ trên main chỉ từ ca DOM.

Không có quyết định O2 thật, paid-worker pin mới hoặc phê duyệt D07 nào từ đợt sửa này. Truy vết: DF-036/037; DF-016/042/043 cho scope, identity phát hành và giới hạn bằng chứng.
