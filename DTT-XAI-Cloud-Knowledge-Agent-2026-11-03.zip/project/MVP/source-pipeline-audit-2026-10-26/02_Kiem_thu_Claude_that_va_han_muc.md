# Kiểm thử chất lượng bằng Claude thật — hạn mức local

Ngày 26/10/2026. Theo phê duyệt: “20 usd cho tester khi hệ thống chạy trên local machine này, khi deploy sẽ cần tính lại”.

## Hạn mức đã cài

- App: <http://127.0.0.1:8025/web/>, build `v17-repair-2026-10-26`.
- Quỹ **dùng chung toàn app local: 20 USD**, không phải 20 USD mỗi tài khoản. Không có quỹ/hạn mức cũ còn hiệu lực khi cài.
- Chia **10 USD Sonnet 5.5** và **10 USD Opus 5.5** theo hai pool mà Gateway hiện hỗ trợ. Không tự chuyển tiền hay tự gia hạn pool.
- Giới hạn bảo vệ của operator: tối đa 100 lượt mỗi model; dừng khi hết lượt, hết tiền hoặc hết hạn trước. Hiệu lực đến **17:55:57 ngày 02/11/2026 (UTC+7)**. Số tiền là hạn mức do app tính theo bảng giá/token cấu hình, không phải hạn mức chi tiêu tại tài khoản nhà cung cấp.
- Tác vụ: hiểu câu chat/Excel nghiệp vụ có kiểu, nghiên cứu xuất khẩu và tổng hợp chính sách Hà Nội. Không mở thêm quyền gửi bản gốc tài chính, vision hoặc công cụ web mới.
- Mỗi lần gửi vẫn cần consent đúng dữ liệu/tác vụ. Không tự gửi lại, đổi model có phí, nạp thêm tiền hoặc xóa dấu vết lỗi để chạy lại.
- Approval chỉ áp dụng vận hành local này. Không mang pool đang active sang deployment; môi trường triển khai cần phê duyệt mới, không dùng bản sao DB local như quyền chi tiêu production.

[Approval](<../../../REFERENCE_LINKS.md#ref-0043>) · [Biên nhận và đối soát](<../../../REFERENCE_LINKS.md#ref-0044>).

Đã kiểm preview hạn mức trên 11 chủ tài khoản thử đang hoạt động: cùng hai pool, cùng tổng 20 USD; đọc status không tạo child grant. Cấp quỹ chỉ thay bảng pool, không thay facts, tài khoản hoặc lịch sử; chưa tạo lượt model hoặc phí nào.

## Quy tắc kiểm thử từ vòng tiếp theo

Ca đánh giá chất lượng hiểu câu hỏi, suy luận và khuyến nghị phải đi qua Claude thật trong app/MCP. Kết quả giả lập, dữ liệu seed và báo cáo cũ có thể kiểm UI/hồi quy, nhưng không được ghi là một lượt chất lượng Claude mới.

1. Tải lại app, mở hạn mức và kiểm hai model/tổng quỹ chung còn hiệu lực.
2. Dùng tài khoản thử riêng, hội thoại mới, SSOT và đúng sản phẩm đã xác nhận. Không nhập tài liệu tài chính gốc hoặc dữ liệu cá nhân không cần thiết.
3. Gửi câu tự nhiên qua **Gửi có phí** sau khi xem thông tin đồng ý. Chọn mức xử lý phức tạp khi cần đánh giá Opus; mức tự động vẫn theo router thật, không được gắn nhãn Opus chỉ vì người kiểm muốn dùng Opus.
4. Với xuất khẩu, lượt hiểu câu hỏi và lượt **Nghiên cứu** là hai bước có thể tốn hai lượt. Đọc kế hoạch, phạm vi nguồn còn thiếu và model trước khi xác nhận nghiên cứu.
5. Lưu câu hỏi, task/mission/attempt ID, model thực, token, trạng thái công bố, thời gian và chi phí theo receipt. Phân biệt kết quả mới với kết quả đã lưu (`cached`/replay). Không đưa mật khẩu, cookie, khóa hoặc nội dung tài liệu riêng vào báo cáo.
6. Nếu có lỗi: giữ nguyên hội thoại/receipt, ghi phần đã tính phí và phần chưa trả lời, dừng ca đó. Không bấm gửi lại như một bước tự động. Lượt mới cần là lựa chọn chủ động, được nêu rõ và còn ngân sách.
7. Đánh giá theo từng mục đã hỏi, nguồn hỗ trợ từng kết luận, ba việc cụ thể và phần chưa đủ căn cứ. Không chấm một câu trả lời hay là đầy đủ chỉ vì model mạnh.

## Ba ca chất lượng ưu tiên

| Ca | Nội dung kiểm | Điều phải nhìn thấy |
|---|---|---|
| Trà Sen → Mỹ | Đăng ký cơ sở, US agent, prior notice, nhãn, nước xuất xứ, trách nhiệm bên nhập khẩu và ba việc đầu tiên | Phủ từng mục có nguồn hoặc chỉ rõ thiếu nguồn; không mất mục từ kế hoạch; việc cụ thể, không lặp ba việc cố định |
| Bán hàng/tồn kho | Tháng 9 bán 120 hộp, tồn 30 hộp; sau đó bổ sung ngày/mã hoặc chỉnh số | Giữ đúng vai số bán/số tồn và mạch hội thoại; không biến số tồn thành tên, không tự ghi SSOT |
| Chính sách Hà Nội | Xúc tiến xuất khẩu + đào tạo sổ sách buổi tối; đề nghị kiến nghị cụ thể | Hai nhu cầu riêng, đúng SSOT/tên giao dịch; không tự khẳng định đủ điều kiện nếu kho thiếu văn bản/rule; giữ nội dung đề nghị khi soạn PDF |

Việc cấp quỹ không bổ sung kho nguồn. Hiện chính sách Hà Nội vẫn chưa có quy tắc hưởng chính sách đã duyệt; gọi Opus không cho phép vượt gate này. [Hiện trạng nguồn và lộ trình](<01_Hien_trang_va_huong_hoan_thien.md>) phân biệt rõ dữ liệu hiện có với hướng cần phát triển.
