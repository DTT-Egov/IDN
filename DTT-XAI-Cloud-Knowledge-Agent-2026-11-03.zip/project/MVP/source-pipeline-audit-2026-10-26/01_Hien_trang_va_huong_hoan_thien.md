# Chính sách Hà Nội và quy định xuất khẩu: hiện trạng nguồn và hướng hoàn thiện

Ngày đối soát: **26/10/2026**, bản đang phục vụ 8025 là `v17-repair-2026-10-26`, bundle `release-final-v2`. Đây là báo cáo đọc mã đã đóng gói và số liệu tổng hợp từ kho nguồn công khai; **chưa triển khai thay đổi, chưa lấy thêm nguồn, chưa gọi Claude và chưa duyệt quy tắc mới**.

## 1. Trả lời trực tiếp

App **có lưu và dùng lại nguồn**. Không có cơ chế để mỗi câu hỏi tự search toàn bộ Internet. Tuy nhiên hai luồng đang khác nhau:

| | Chính sách Hà Nội | Quy định xuất khẩu |
|---|---|---|
| Kho đang dùng | Snapshot, trích đoạn, bản dịch, quy tắc/khẳng định và quan hệ phụ thuộc trên SQLite | Gói nguồn công khai, trích đoạn tham chiếu, phạm vi thị trường và quan hệ phụ thuộc trên SQLite |
| Khi hỏi mới | Tra kho bằng FTS5, aliases và intent; đối chiếu SSOT/quy tắc có thẩm quyền | Tra gói nguồn đúng chủ đề/thị trường; ở đường gửi xuất khẩu của chat chính có bước thử đọc lại các URL chính thức đã biết |
| Tìm nguồn hoàn toàn mới trên Internet | Chưa có discovery/crawler tổng quát | Chưa có discovery/crawler tổng quát |
| Cập nhật nền | Có hàng đợi bền vững; hiện mới một nguồn được lên lịch mỗi ngày | Chưa có lịch nền chung hoặc TTL tái sử dụng; đường chat mới có thể đọc lại cùng URL |
| Vai trò Claude thật | Chọn bằng chứng liên quan, xếp ưu tiên công việc nghiên cứu và câu hỏi SSOT từ kho đã cung cấp | Hiểu câu hỏi/lập kế hoạch và tổng hợp nghiên cứu từ nguồn tham chiếu được cung cấp, có kiểm hợp đồng đầu ra |
| Xem lại kết quả | Đọc bản đã lưu, kiểm quyền và cảnh báo thay đổi; không gọi thêm Claude | Đọc bản đã lưu/biên nhận; không tự tạo lượt AI mới |

**Cấp thêm lượt Claude thật không tự làm kho chính sách rộng hơn hoặc có hiệu lực pháp lý hơn.** Cần cải thiện cả nguồn, quy trình cập nhật và chuyên gia duyệt; không chỉ thay mô hình.

## 2. Những gì đang có thật trong kho 8025

Số liệu đọc lúc **17:48 ngày 26/10/2026, UTC+7**, từ [bằng chứng tổng hợp nguồn công khai](<../../../REFERENCE_LINKS.md#ref-0029>). Không đọc nội dung hồ sơ riêng để lập báo cáo này.

### Chính sách Hà Nội

- **4 nguồn công khai, 4 snapshot được tiếp nhận**. Cả 4 có `complete_policy=0`: đã nhập được nội dung nhưng **chưa được xác nhận đủ bộ căn cứ pháp lý**.
- **0 phiên bản rule/claim trong `pol_members`**. Vì vậy chưa có quy tắc tư vấn điều kiện hưởng hỗ trợ được duyệt/phát hành từ bảng này. Nguồn và đầu mối đã lưu vẫn có thể phục vụ tìm hiểu, chuẩn bị câu hỏi hoặc nháp; không được biến thành kết luận doanh nghiệp chắc chắn đủ điều kiện.
- **1 lịch tự kiểm mỗi 86.400 giây**, cho `HN-NOTICE-2026-14`. Kiểm gần nhất **15:41 ngày 26/10**, lần tiếp theo dự kiến **15:41 ngày 27/10/2026**, khi app/worker hoạt động. Nguồn trả về nguyên nội dung đã lưu; sự kiện có `provider_calls=0`.
- Bốn nguồn thuộc gói tư vấn chuyển đổi số và căn cứ liên quan. Không phải danh mục đầy đủ mọi chính sách Hà Nội. Một câu có nhiều nhu cầu có thể được nhận diện đủ nhưng vẫn báo thiếu nguồn đúng từng nhu cầu.

### Quy định xuất khẩu

- **30 nguồn ở trạng thái `recorded_snapshot`**: có bản tham chiếu đã lưu, không đồng nghĩa đã được chuyên gia xác nhận hiện hành toàn diện.
- Có **17 lần kiểm mạng đã ghi nhận**, đều có kết quả `exact_excerpts_present`; lần gần nhất **12:54 ngày 21/10/2026**. Con số 17 là số bản ghi kiểm, không phải khẳng định có 17 nguồn khác nhau hoặc đã kiểm toàn bộ 30 nguồn.
- Phạm vi hiện hữu là các gói hữu hạn cho **Mỹ, Đức và Nhật**. Chưa phải hệ thống bao phủ mọi hàng hóa và mọi thị trường.

## 3. Luồng chính sách Hà Nội hiện tại

### Tiếp nhận và lưu

Người có vai trò quản trị nguồn đăng ký URL chính thức hoặc nhập snapshot. URL hiện chỉ cho phép HTTPS thuộc `hanoi.gov.vn` và `chinhphu.vn`, kể cả tên miền con. Các file nguồn đã chuẩn bị được kiểm hash trước khi nhập; managed runtime không tự nhập lại hoặc backfill dữ liệu nghiệp vụ khi khởi động.

Kho lưu bytes gốc, văn bản trích xuất, hash, ngày công bố/đọc, khoảng hiệu lực nếu biết, các đoạn có vị trí và phiên bản trích xuất. Đây là **lưu trữ bền vững có phiên bản**, không chỉ cache tạm. Dữ liệu nguồn công khai tách khỏi SSOT, chat và tài liệu riêng của từng doanh nghiệp.

### Cập nhật và kiểm chứng

Job nền tải URL đã được lên lịch, có lease chống xử lý trùng và ghi sự kiện. HTML hợp lệ được tách bài rồi so hash; nếu đổi sẽ tạo snapshot mới, giữ bản cũ và đánh dấu tri thức phụ thuộc cần rà lại. Nếu HTTP thành công nhưng nội dung không đổi thì chỉ ghi nhận quan sát, **không gia hạn kiểm chứng pháp lý**.

PDF tải qua job hiện chỉ báo cần trích xuất/rà lại; chưa tự OCR rồi chuyển thành quy tắc. Việc đã có một số PDF trích xuất trong gói nguồn không có nghĩa worker hiện làm được tự động toàn bộ chuỗi đó.

Tải được trang web, đọc đủ văn bản, còn hiệu lực, còn nhận hồ sơ, quy tắc được chuyên gia duyệt và được phép sử dụng là các trạng thái riêng. Kết luận điều kiện phải qua nguồn đủ căn cứ, hạn kiểm hiện hành, hiệu lực, reviewer, publisher và phiên bản phát hành. Hạn kiểm đã hết hoặc nguồn không kiểm lại được thì dừng phần cần căn cứ hiện hành theo D07, vẫn giữ phần hợp lệ/lịch sử.

### Khi chủ doanh nghiệp hỏi

App nhận intent, đọc đúng SSOT được phép, tra trích đoạn bằng FTS5 và aliases, lọc mục tiêu/chương trình/trang, rồi đối chiếu graph SQL/quy tắc. Câu hỏi mới không tự phát sinh search web. Khi được phép gọi Claude, server gửi các đoạn nguồn và ứng viên công việc đã lọc; Claude chọn/xếp ưu tiên bằng ID trong hợp đồng đầu ra. Kết luận pháp lý vẫn do quy tắc và gate kiểm chứng quyết định. Trước công bố, app kiểm lại SSOT, nguồn và tri thức có thay đổi trong lúc chạy hay không.

Kết quả lưu kèm phiên bản SSOT, nguồn, trích đoạn, hash và biên nhận mô hình. Mở lại chỉ đọc và cảnh báo thay đổi, không tự gọi Claude; không đưa kết luận riêng của doanh nghiệp A vào kho tri thức công khai dùng cho doanh nghiệp B.

## 4. Luồng xuất khẩu hiện tại

Gói nguồn công khai được tra theo thị trường, thẩm quyền, chủ đề, thời điểm và quan hệ thay thế. Danh mục chỉ đọc nguồn đã biết; bản thân lookup không gọi Internet hoặc mô hình.

Ở **đường gửi xuất khẩu trong chat chính**, trước lượt Claude hiểu câu hỏi, app thử tải lại URL chính thức liên quan đến các mục tiêu được nhận ra. Bước này không phải search nguồn mới và không có TTL để bỏ qua một lần kiểm gần đây. Cùng URL được gộp trong một batch, tối đa 3 kết nối, một lần thử mỗi URL và giới hạn thời gian. Bản kiểm mạng được lưu riêng với bản tham chiếu gốc.

Phép kiểm chỉ hỏi: **nguyên văn các trích đoạn đã lưu còn xuất hiện trên trang hay không**, chỉ chuẩn hóa khoảng trắng. Nếu thiếu, nguồn thành `needs_revalidation`, kế hoạch phụ thuộc bị đánh dấu cần rà lại; không sửa âm thầm trích đoạn cũ. Nếu còn nguyên, cũng không có nghĩa đã tìm hết sửa đổi, ngoại lệ, văn bản thay thế hoặc mọi nghĩa vụ của sản phẩm. Nguồn bị chặn/không đọc được phải hiện đúng bản cũ và giới hạn; không được gọi là vừa kiểm chứng toàn diện.

Một khác biệt cần chuẩn hóa là direct mission prepare không tự chạy bước refresh như chat chính. Có đường sửa kế hoạch rõ ràng do người dùng yêu cầu sử dụng lại đầu ra đã ghi và kiểm nguồn miễn phí, nhưng GET/status/khôi phục thông thường không tự gọi mô hình. Các đường này chưa hình thành một chính sách freshness chung cho mọi entry point.

## 5. Pipeline đề xuất để mở rộng

Phần dưới là **đề xuất**, chưa phải tính năng đã triển khai.

```mermaid
flowchart LR
  A[Nguồn chính thức và nhập thủ công] --> B[Phát hiện tài liệu mới hoặc thay đổi]
  B --> C[Snapshot bất biến, hash, ngày và nguồn gốc]
  C --> D[Trích xuất, phân loại, đề xuất tri thức]
  D --> E[Chuyên gia rà điều kiện và căn cứ]
  E --> F[Phát hành phiên bản có phạm vi và hiệu lực]
  F --> G[Kho domain công khai dùng chung]
  G --> H[Tra đúng intent và SSOT được phép]
  H --> I[Claude phân tích, kết quả có trích dẫn]
  G --> J[Lịch refresh theo rủi ro]
  J --> B
```

### Ưu tiên 1 — hoàn thành một chính sách Hà Nội có chiều sâu

Chọn một chương trình cụ thể: thu thập đủ văn bản có thẩm quyền, phụ lục, sửa đổi, đối tượng, điều kiện, giấy tờ, mức hỗ trợ và kênh tiếp nhận; phân biệt thông tin chưa biết. Đưa rule/claim đề xuất vào hàng đợi để người đã được phân quyền rà/phát hành đúng phiên bản. Khi chưa có xác minh cửa nhận, app chỉ giúp hỏi, chuẩn bị hoặc kiến nghị; không hứa được hưởng hỗ trợ hoặc đã nộp hồ sơ. Phần nối iHanoi vẫn cần API và môi trường thật trước khi tuyên bố gửi thành công.

### Ưu tiên 2 — một chính sách nguồn chung cho Hà Nội và xuất khẩu

Mỗi nguồn cần có chủ quản, phạm vi, loại tài liệu, nhịp refresh, lần kiểm gần nhất, lần tiếp theo, hạn kiểm, hiệu lực pháp lý và tài liệu phụ thuộc. Dùng cùng quyết định ở chat, MCP và mission trực tiếp; không để mỗi entry point tự quyết định một cách.

- **TTL kiểm lại không phải ngày hết hiệu lực pháp luật.** TTL quyết định khi nào cần kiểm nguồn lại; hiệu lực phải có căn cứ từ văn bản và quan hệ sửa đổi/thay thế.
- Trong TTL phù hợp có thể dùng lại snapshot/quan sát tốt, không tải lại cùng nguồn theo từng doanh nghiệp. Dùng một job cho một nguồn và gộp các yêu cầu đang cùng chờ.
- Nội dung thay đổi làm stale đúng phần phụ thuộc; giữ bản lịch sử và không tự hồi sinh quy tắc cũ sau khi bản thay thế bị rút.
- Nội dung cập nhật tự động không tự trở thành quy tắc tư vấn. Gate chuyên gia và quyền phát hành vẫn độc lập.

### Ưu tiên 3 — bổ sung nguồn theo khoảng trống intent

Có danh mục theo chủ đề để thấy đã/thiếu nguồn nào: xúc tiến thị trường, đào tạo nhân viên, nhãn hiệu, OCOP và các lĩnh vực đã thống nhất; tránh trả gói số hóa kho cho mọi câu hỏi. Discovery theo cổng/feeds/API hoặc nhập thủ công chỉ tạo nguồn chờ kiểm. Claude có thể đề xuất cách phân loại hoặc nghiên cứu khi được cấp quyền/ngân sách; không tự duyệt nguồn, luật hoặc hồ sơ.

Với xuất khẩu, bổ sung theo ma trận thị trường × nhóm sản phẩm × nghĩa vụ, thay vì coi một gói FDA hoặc một nước EU là đủ mọi trường hợp. Các nguồn công khai được dùng lại giữa doanh nghiệp; áp dụng vào trường hợp cụ thể vẫn theo SSOT riêng và quyền truy cập hiện hành.

### Ưu tiên 4 — tối ưu retrieval và chi phí có đo lường

Giữ SQL/FTS5/graph hiện có trong lúc hoàn thiện coverage và dữ liệu chuẩn. Chỉ bổ sung embedding/hybrid retrieval khi bộ câu hỏi đánh giá chứng minh bỏ sót do ngôn ngữ/từ khóa, không dùng vector để che việc chưa có nguồn. Dù dùng embedding, filter quyền, thị trường, phiên bản, hiệu lực và rule đã duyệt vẫn phải chạy bằng hợp đồng có thẩm quyền.

Tách ba thứ khi tối ưu: kho nguồn công khai dùng chung; kết quả truy xuất có dependency/version; kết quả phân tích riêng của tài khoản/doanh nghiệp. Cache không cấp thêm quyền. Chỉ dùng lại đầu ra Claude đúng phạm vi, đầu vào và hợp đồng; một câu hỏi/SSOT khác không mặc nhiên dùng lại kết luận cũ.

Kiểm thử chất lượng thường xuyên bằng Claude thật là phù hợp sau khi có hạn mức rõ. Mỗi ca cần biết số lượt, mục đích, model, phí và có công bố thành công hay không; không tự retry, đổi model hoặc gọi thêm để sửa lỗi có phí. Tải lại, đọc status và mở kết quả đã lưu vẫn không tạo lượt mới. Tài liệu tài chính gốc không gửi Claude theo D05.

## 6. Điều kiện nghiệm thu tiếp theo

1. Một chính sách Hà Nội có bộ căn cứ đủ, rule/claim được duyệt/phát hành thật và tư vấn đúng phạm vi; khi thiếu căn cứ thì trả đúng phần còn dùng được.
2. Cùng nguồn không bị tải lại vô ích giữa nhiều câu hỏi/doanh nghiệp; dữ liệu riêng không vào kho domain hoặc cache công khai.
3. Nguồn đổi, thiếu phụ lục, hết hạn kiểm, bị chặn hoặc bị thay thế đều tạo hành vi rõ; HTTP 200 không được nâng thành xác nhận pháp lý.
4. Chat và MCP dùng chung freshness decision; xem lại/khôi phục không gọi AI. Test ít nhất hai doanh nghiệp và thu hồi quyền đọc.
5. Đánh giá riêng độ phủ câu hỏi, độ chính xác trích dẫn, chất lượng hành động, tuổi nguồn và chi phí; có kiểm độc lập trên bản phát hành cuối. Không gọi ca chưa đủ nguồn là kết quả pháp lý đạt chỉ vì Claude trả JSON hợp lệ.

Liên hệ sổ thiết kế: **[DF-027](<../architecture/DESIGN_FLAWS.md#df-027--nguồn-công-bố-quy-tắc-được-duyệt-và-quyền-dùng-bị-trộn>)**, thiết kế vẫn D1. Audit này bổ sung bằng chứng phạm vi/coverage và backlog, không khẳng định một sự cố mới hoặc nghiệm thu thay đổi chưa thực hiện.

## 7. Đường dẫn kiểm chứng mã đã phát hành

- Hà Nội — [schema kho nguồn](<../../../REFERENCE_LINKS.md#ref-0030>), [HTTP refresh và giới hạn PDF](<../../../REFERENCE_LINKS.md#ref-0031>), [snapshot/hash/index](<../../../REFERENCE_LINKS.md#ref-0032>), [retrieval local](<../../../REFERENCE_LINKS.md#ref-0033>), [gate pháp lý](<../../../REFERENCE_LINKS.md#ref-0034>).
- Hà Nội — [lịch refresh bền vững](<../../../REFERENCE_LINKS.md#ref-0035>), [worker](<../../../REFERENCE_LINKS.md#ref-0036>), [phân tích Claude có giới hạn](<../../../REFERENCE_LINKS.md#ref-0037>), [đọc lại và cảnh báo](<../../../REFERENCE_LINKS.md#ref-0038>).
- Xuất khẩu — [gói nguồn và lookup local](<../../../REFERENCE_LINKS.md#ref-0039>), [refresh ở chat chính](<../../../REFERENCE_LINKS.md#ref-0040>), [prepare trực tiếp](<../../../REFERENCE_LINKS.md#ref-0041>), [kiểm exact excerpts và lưu observation riêng](<../../../REFERENCE_LINKS.md#ref-0042>).

Phạm vi kiểm của tài liệu: đọc mã đóng gói và thống kê bảng nguồn công khai; không coi đây là rà soát hiệu lực pháp luật, thẩm định nội dung từng nguồn hoặc kiểm kết quả Claude mới.
