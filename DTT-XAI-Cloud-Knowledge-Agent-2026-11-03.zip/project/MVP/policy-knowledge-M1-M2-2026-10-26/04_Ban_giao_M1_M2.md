# M1–M2 đã qua review độc lập — dừng để kiểm tra

27/10/2026 · DTT XAI/nMate. Không thay app8025, dữ liệu/quyền thật hoặc gọi AI có phí.

## Kết quả

**M1:** SQL giữ nguyên Markdown, revisions/hash, typed dependencies, quyền nguồn, causal events và exact receipts. Có operator migration trên DB thử; startup không tự khởi tạo/backfill. Review độc lập47/47, thêm1ca clock/ID đạt riêng. [Bàn giao M1](<01_Ban_giao_M1.md>).

**M2:** đi hết nguồn công khai thử → lưu tệp → trích chữ cục bộ → wiki candidate gắn nhận định với nguồn → FTS/alias/liên kết → xuất Markdown → nguồn đổi/thu hồi quyền. MCP adapter dùng chung cổng xác thực/service, chưa đăng ký vào app chính. [Walkthrough](<03_Walkthrough_M2.md>) và [thiết kế implementation](<02_Thiet_ke_implementation_M2.md>).

## Bằng chứng cuối

| Bộ kiểm | Kết quả | Phạm vi |
|---|---|---|
| [Hồi quy author trên M2 frozen2](<../../../REFERENCE_LINKS.md#ref-0054>) | **211/211 đạt**, 10file kiểm thử | M1/M2, MCP SDK, operator/startup/schema, policy/replay/ACL liên quan |
| [Review M2 độc lập](<../../../REFERENCE_LINKS.md#ref-0055>) | **39/39 đạt**; thêm **4ca riêng đạt** | Reviewer tự viết fixture/test, local PDF worker thật, SDK trong bộ nhớ, outbox, source causal head, Windows junction thật |
| [Signoff M2](<../../../REFERENCE_LINKS.md#ref-0056>) | PASS có giới hạn | Service/storage/operator/MCP trong bộ nhớ/materializer offline; không suy thành UI hoặc chính sách thật |
| [Rehearsal cuối](<../../../REFERENCE_LINKS.md#ref-0057>) |103bảng cũ nguyên vẹn,152seed;11bảng mới; startup không ghi; operator receipt replay đúng | DB toàn app synthetic, không phải MAIN |
| [Kiểm artifact](<../../../REFERENCE_LINKS.md#ref-0058>) | M1:143file; M2:149file nguyên SHA; không thiếu/thừa | Frozen bundles giữ nguyên, kể cả candidate cũ có lỗi |

Không cộng full run và các ca bổ sung thành số full mới. Candidate1 và các log RED giữ nguyên để đối chiếu; số211 thuộc đúng frozen2 cuối, không mượn197ca của candidate1.

## Review đã buộc sửa thiết kế gì

1. Tách nhận diện/admission tài liệu khỏi việc đọc được chữ; trang đăng nhập/lỗi không tạo evidence. Mọi tài liệu đọc được vẫn là candidate chưa xác minh.
2. Thêm hợp đồng loại trang bất biến; đường M1 cũ cũng không được bỏ bindings M2 hoặc đọc bỏ gate.
3. Parser output phải kiểm locator theo MIME, bounds/order và chất lượng nhất quán trước lưu. Hash không biến output sai thành bằng chứng đúng.

Sổ có thẩm quyền đã cập nhật **DF-005/013/019/027/029/033/035/041/043/048**, thêm **DF-052/053/054 ở M1** và **DF-055 ở M2**. [DESIGN_FLAWS](<../architecture/DESIGN_FLAWS.md>) giữ lớp thiết kế **D1**; các bản vá được kiểm trong lát cắt này, chưa tuyên bố toàn hệ thống hết lớp lỗi.

## Điểm dừng và phần tiếp theo

M1→M2 đã thực hiện theo ủy quyền mới; **dừng sau M2**, chưa bắt đầu M3 hoặc thay8025.

M3 sẽ làm workbench chuyên gia, diff/evidence và duyệt–phát hành exact revision/hash. Trước mở tư vấn thật cần kiểm bộ nguồn Phụ lục03, toàn văn/phụ lục/sửa đổi, quyền lưu/tái sử dụng và scope wiki cho chuyên gia. Fixtures không thay những cổng này.

Chưa nghiệm thu: nguồn thật/độ đầy đủ pháp lý, dịch evidence Anh→Việt, Internet/304/DNS/lịch, hợp nhất consumer legacy, UI/mobile/chat/SSOT trong app và deploy. Các phần đó thuộc M3–M5 hoặc gate riêng; không cài thêm framework/database và không dùng quỹ tester để AI xây kho.
