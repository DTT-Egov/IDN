# Walkthrough M2 — tích lũy tri thức từ nguồn công khai

27/10/2026 · Flow kỹ thuật trên **frozen candidate2**, DB synthetic. Chưa phải màn chat/mobile hoặc chính sách thật. Không mở MAIN, không gọi Internet/AI.

[Thiết kế implementation](<02_Thiet_ke_implementation_M2.md>) · [Manifest149files](<../../../REFERENCE_LINKS.md#ref-0050>) · [Bằng chứng toàn flow](<../../../REFERENCE_LINKS.md#ref-0051>).

## 1. Nâng cấp bản thử, giữ dữ liệu cũ

Tạo DB toàn app synthetic, qua operator M1 rồi M2. Đối soát103bảng nghiệp vụ có trước M2 không đổi hash/rowcount;11bảng M2 mới.152seed bắt buộc vẫn khớp. Target readiness đạt; mở managed service không ghi. Replay đúng operator plan trả receipt đã commit, không tạo backup hoặc DDL lần hai.

Tất cả số này thuộc DB thử, không phải backup hay migration của app8025.

## 2. Khai danh mục và quyền nguồn

Nguồn `M2-TEST-TRAINING`, URL `/test-only/m2-training`, văn bản do bài kiểm tạo. Fixture author có role explicit trên DB thử; quyền READ/export được ghi riêng, không suy từ chữ “public”. Manifest nêu còn thiếu phụ lục và chưa rà pháp lý; mạng tắt.

Không tự chuyển bốn snapshot legacy thành bộ chính sách hoàn chỉnh hoặc cấp quyền wiki cho chuyên gia thật.

## 3. Lưu tệp trước khi đọc

Nhập `nguon-kiem-thu.txt`. UoW-A lưu nguyên bytes, SHA256, tên/MIME, source/manifest, observation, causal head/event, outbox và receipt. Trạng thái nhận tệp là pending extraction. Mất phản hồi sau commit thì đọc/replay operation cũ; không phải tải hay gọi AI lại.

## 4. Trích chữ và đối chiếu vị trí

Bộ đọc cục bộ chạy ngoài giao dịch SQL; UoW-B kiểm lại quyền/manifest/raw rồi lưu extraction/chunks/quality/admission. TXT giữ Unicode offsets; PDF giữ số trang; HTML giữ đoạn text trích và khoảng trống phụ lục. PDF giả/scan/mixed/encrypted và lỗi parser được kiểm riêng trong test, không giả OCR thành công.

Đọc lại nguyên tệp cho đúng bytes đã nhập. Câu trích giữ chunk/hash/quote và vị trí start/end. Câu lặp phải chỉ occurrence; không lấy tùy ý câu đầu.

## 5. Tạo trang nháp có bindings

Trang kiểm thử nói về đào tạo nhân viên và xúc tiến xuất khẩu. Mỗi phần prose gắn exact claim span và evidence. SQL lưu nguyên Markdown, body hash, immutable target contract và bindings. Không công bố claim là điều kiện hưởng hỗ trợ; `assessment_eligible=false`.

Đọc ban đầu cho `source_incomplete`, lý do thiếu phụ lục; đồng thời lưu lý do chưa xác minh hiện hành/chưa phát hành. Tất cả blockers được giữ, không để trạng thái job thay thế căn cứ.

## 6. Dựng projection và tìm lại

Trước chạy materializer, search không giả đã index trang. Outbox dựng Markdown từ SQL và đăng ký page/revision/hash cho retrieval. Sau đó tìm “đào tạo xuất khẩu” thấy đúng trang; alias “đào tạo sổ sách” cũng có kiểm thử riêng.

FTS chỉ nhận canonical documents đã qua READ; không lấy title/snippet từ file. File sửa tay/xóa rồi dựng lại không đổi body SQL hoặc gọi AI. Markdown có cảnh báo **BẢN NHÁP — chưa phát hành**. Đây là projection local, chưa được phục vụ static vào8025.

## 7. Nguồn đổi nhưng câu cũ vẫn còn

Nhập bản v2 giữ câu cũ, thêm một ngoại lệ. Source diff hiện dòng mới; trang phụ thuộc đổi ngay thành `changed_needs_review` dù chưa dựng lại index/file. Mở revision cũ vẫn đọc đúng body cũ nếu còn READ; không tự sửa lịch sử hoặc coi quote còn khớp là đủ hiện hành.

## 8. Thu hồi quyền, kiểm mọi đầu ra

Thu hồi READ/export của nguồn thử. Search trả rỗng ngay; export bị từ chối. Outbox cleanup xóa bản Markdown được quản lý; status/recovery không gọi AI. File người dùng đã copy ra ngoài không thể bị SQL thu hồi; vì vậy app sau này phải đọc/download qua service gate, không dùng thư mục này như static source.

## Phạm vi đã quan sát và giới hạn

[Verification](<../../../REFERENCE_LINKS.md#ref-0052>) ghi0paid calls,0network fetches, MAIN_opened=false. [Operator receipt](<../../../REFERENCE_LINKS.md#ref-0053>) là receipt schema, không phải hạn mức D06 hoặc approval chính sách.

MCP adapter được kiểm bằng SDK trong bộ nhớ và callback xác thực hiện có; chưa nối tool vào HTTP/chat/mobile. Nguồn thật, dịch thuật evidence, expert publication, legacy consumers, Internet/304/DNS/lịch là `not_run` trong flow này. M3–M5 mới nối các phần đó theo gate đã chốt. Review độc lập cuối được bàn giao riêng, không suy đạt từ walkthrough.

Truy vết: DF-005/013/014/019/027/029/033/035/041/043/044/046/048/049/052/053/054/055. Các lớp thiết kế cònD1; mới chứng minh lát cắt kỹ thuật bằng fixture.
