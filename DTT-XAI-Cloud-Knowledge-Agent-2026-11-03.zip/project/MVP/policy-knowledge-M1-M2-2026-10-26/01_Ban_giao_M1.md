# Bàn giao M1 — đạt trong phạm vi lõi

26/10/2026. Quyền chuyển M2: chỉ dẫn người dùng “làm M1, review lại độc lập đến khi ok thì làm tiếp M2 và review tiếp”.

SQL giữ nguyên Markdown, revisions, typed dependencies, quyền nguồn, causal events và exact receipts. Operator dùng chung lifecycle hiện có; contract đích riêng, startup không DDL/backfill. Bản8025 không thay đổi.

## Bằng chứng

- [Frozen candidate3/manifest](<../../../REFERENCE_LINKS.md#ref-0045>):143files; reviewer kiểm SHA trước/sau không đổi.
- [Author cuối44/44](<../../../REFERENCE_LINKS.md#ref-0046>).
- [Review độc lập47/47](<../../../REFERENCE_LINKS.md#ref-0047>), thêm1ca clock/ID chạy riêng; [signoff](<../../../REFERENCE_LINKS.md#ref-0048>).
- [Rehearsal](<../../../REFERENCE_LINKS.md#ref-0049>):95bảng cũ trong DB synthetic nguyên logical hash/rowcount;152requiredseeds; migration→target readiness→managed service không ghi; exact operator receipt replay không backup/apply lần hai.

Review đã bắt và sửa hai lỗi: helper UTF8 chưa tự ánh xạ domain error; con trỏ cùng aggregate nhưng cũ vẫn có thể bỏ qua quyết định/revoke tiếp theo. Không sửa các candidate trước hoặc lịch sử để làm test xanh.

## Giới hạn / gate còn mở

Chưa kiểm UI/HTTP/MCP, consumer legacy, nguồn thật, đủ căn cứ pháp lý hoặc phê duyệt chuyên gia. Evidence M1 mới kiểm quote/dependency, chưa claim-to-body coverage. M2 bổ sung binding và truy xuất; M3 mới review/publication. Không tuyên bố revoke đã phủ app cũ hoặc whole-system D2.

DF mới052/053/054; cập nhật013/014/027/029/033/043/044/046/048/049. Tất cả lớp thiết kế cònD1; các ca source/private/legacy/governance phải kiểm lại theo adapter tại mốc sau. Không gọiAI, không đọc MAIN hay cấp quyền thật.
