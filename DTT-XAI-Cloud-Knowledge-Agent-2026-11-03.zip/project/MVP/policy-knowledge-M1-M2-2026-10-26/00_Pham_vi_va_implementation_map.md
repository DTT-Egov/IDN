# M1–M2: triển khai lõi tri thức có kiểm độc lập

Khởi đầu26/10, bàn giao27/10/2026 · M1–M2 scoped-pass, dừng chờ kiểm tra; chưa deploy8025.

## 1. Phạm vi được giao

Người dùng cho làm M1, review độc lập đến khi đạt rồi tiếp tục M2 và review tiếp. Đây là chỉ dẫn mới cho phép chuyển M1→M2 khi đủ tiêu chí và review, thay điểm chờ người dùng ở giữa hai mốc trong [kế hoạch07](<../policy-knowledge-design-2026-10-26/07_Ke_hoach_trien_khai_va_moc_kiem_tra.md>). Không cho chuyển M3, deploy MAIN hoặc gọi AI trả phí. Cuối M2 phải dừng bàn giao.

Source phát triển ở `nmate-backend-v0.2/src`; bản8025 hiện dùng frozen V17 `output/v17-2026-10-26/release-final-v2/backend-src`. Không thay launcher, frozen bytes, `.env`, tài khoản, grants hoặc dữ liệu thật. Mọi schema/test ở DB synthetic hoặc clone được chỉ rõ. Không dùng dữ liệu cá nhân làm fixture, không đọc khóa.

## 2. Kiến trúc implementation

- Module `nmate.knowledge_v1`: public wiki candidate, source rights/version và typed evidence, dùng repo transaction port và catalog authority hiện có. Chưa có private wiki; SSOT/private-file dependency bị từ chối.
- SQL giữ body/revision/dependency/operation/event; projection không là nơi ghi truth. Candidate chưa phải tri thức được duyệt hoặc đủ điều kiện tư vấn.
- Public-domain receipts có namespace/domain/kind/actor riêng, không mượn `enterprise_id` hoặc grant tester; đây không là ledger chi phí mới.
- Source `usage_scope=public` chỉ là phân loại; new-use phải có source-rights decision explicit, deny thắng creator/curator. Availability khác READ: không truy cập được Internet hoặc archive không tự thu hồi lịch sử.
- Operator dùng lại `core_v1.schema_lifecycle` (lock, backup, plan/source hash, additive DDL và receipt); triggers whitelist exact. Không sửa active V17 runtime contract; target contract cho candidate/clone riêng.
- Không model SDK, provider hoặc transport mới trong M1/M2; không cài Deep Agents/OpenWiki/embedding. M3 mới UI/governance publication, M4 mới tư vấn trong app.

## 3. Traceability đang thực hiện

| Thiết kế / DF | Module/đường liên quan | Bộ kiểm và bằng chứng |
|---|---|---|
| Canonical body, parent, CAS, lifecycle — DF-013/014/033/048 | schema/service wiki và event chain | test_knowledge_m1; mutation/rollback/replay/conflict; reviewer tự phá |
| Public receipts, current READ trước WRITE/CAS — DF-031/044/046 | service operation namespace + exact request + closure | Lost WRITE/READ, request khác cùng operation, lịch sử/reload |
| Rights và typed input — DF-027/028/029/030/032 | source rights overlay/evidence resolver | Chưa có quyền, revoke, wrong domain/jurisdiction, private/self-ref rejected |
| Operator/target/read-only startup — DF-041/042/049 | operator, trigger registry và target contract riêng | Clone migration, crash, managed service startup, seed/data hashes giữ nguyên |
| Ingestion/projection/invalidation — DF-005/013/019/027/029/033/034/035/055 | M2 source_state/rendition/extraction/candidate/lookup/materializer | Hai UoW, localPDF, typed locator/claim, source change, revoke, FTS/alias/nav, file crash/rebuild; frozen2 scoped-pass |
| TDD/review/giới hạn — DF-043 | Tests và evidence từng frozen candidate | RED, GREEN và độc lập ghi riêng; không cộng thành full run giả |

## 4. Các giới hạn phải giữ rõ khi nghiệm thu

- Source-rights overlay ban đầu có hiệu lực trong new knowledge service. Các consumer legacy Catalog/DomainGraph/app chưa được nối; chưa tuyên bố revoke đã phủ toàn hệ thống. M2 lookup/MCP mới phải dùng cùng resolver; inventory/hợp nhất legacy consumers là gate trước M3/M4/cutover.
- M1 evidence refs chứng minh dependency closure/quote/version, chưa chứng minh mọi câu trong body có support hay đúng pháp lý. Hợp đồng claim-to-body/section binding được hoàn thiện trong M2; publication vẫn tắt và review chuyên môn ở M3.
- Scoped reviewer/publisher hiện tại không tự thành author/curator/global wiki role. Fixtures có quyền synthetic explicit trong namespace thử, không cấp quyền thật.
- Constructor/read không initialize/backfill. Target contract riêng không được thay vào app chính trước rehearsal và mốc phát hành.
- Đạt ca fixture không là xác nhận bộ chính sách Phụ lục03 đủ căn cứ. M2 chỉ dùng fixtures công khai/nguồn đã có trong scope nếu chưa có manifest nguồn thật và phân công vận hành đủ.

## 5. Trạng thái

M1 đã qua review độc lập trên frozen candidate3: author44/44; reviewer47/47, thêm1ca clock/ID chạy riêng đạt. Không cộng thành một full run48. Xem [bàn giao M1](<01_Ban_giao_M1.md>). Người dùng đã cho chuyển sang M2 sau review đạt; M2 cũng đã scoped-pass. Chưa cho chuyển M3 hoặc thay8025.

M2 đã có [implementation design](<02_Thiet_ke_implementation_M2.md>) và [walkthrough kỹ thuật](<03_Walkthrough_M2.md>). Frozen1: author197/197broad, reviewer bắt admission/typedtarget/parser-contract nên chưa đạt; giữ nguyên artifact. Frozen2: author211/211broad, độc lập39/39+4ca chạy riêng đạt; rehearsal trên DB synthetic giữ103bảng cũ/152seeds và đi hết flow. [Bàn giao cuối](<04_Ban_giao_M1_M2.md>). Dừng chờ người dùng kiểm tra, không chuyển M3.
