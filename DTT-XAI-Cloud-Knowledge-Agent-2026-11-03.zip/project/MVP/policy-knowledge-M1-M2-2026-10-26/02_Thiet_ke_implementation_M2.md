# M2 — hợp đồng nhập nguồn và wiki candidate

27/10/2026 · Đã scoped-pass review độc lập; [bàn giao và giới hạn](<04_Ban_giao_M1_M2.md>). Chưa triển khai8025 hoặc nghiệm thu chính sách thật.

## 1. Lát cắt được triển khai

Nhập **nguồn công khai được phép từ bytes cục bộ**, ghi nguyên bản trước, trích chữ bằng bộ đọc cục bộ, tạo wiki nháp với bindings từng phần, tìm bằng FTS/alias, xem bản gốc, đối chiếu phiên bản và xuất Markdown. Không có tải Internet, lịch mới, OCR/LLM hoặc publication trong M2. Các tác vụ đó không được ẩn sau thao tác đọc/status/recovery.

Các bảng và tên wire là implementation của thiết kế logic02/03, không là database/authority thứ hai. Không thay raw/receipt legacy, SSOT, nguồn thật, quyền `trung@dtt.vn`, ngân sách hoặc active contract app.

## 2. Nguồn pilot và khoảng trống

| Tập | Quyền/căn cứ trong đợt này | Trạng thái |
|---|---|---|
| `KB-TEST-A`, `M2-TEST-TRAINING` | Văn bản synthetic, tự tạo cho kiểm thử; URL `/test-only/` chỉ định danh, không được tải | Được kiểm kỹ thuật trên DB thử, không phải luật |
| Phụ lục03 và nguồn legacy N1–N4 | Danh mục công bố đã lưu trong source pack cũ; chuyên gia hiện được giao phạm vi cũ | Chưa chuyển/backfill M2, chưa nhận đủ toàn văn/phụ lục/sửa đổi/rights mới |
| Nguồn thực về đào tạo, xuất khẩu, OCOP, nhãn hiệu | Chưa có bộ pilot được kiểm đủ trong M2 | Gap; không bịa nguồn/điều kiện để đủ flow |

Danh mục tham khảo legacy (không fetch lại hoặc xác nhận còn hiệu lực): [pack đã lưu](<../../nmate-backend-v0.2/src/nmate/policy_v1/data/hanoi_digital_source_pack.json>), [audit26/10](<../source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md>). Bảng nguồn thật cần người vận hành, quyền lưu/tái sử dụng/retention, bản ký/công báo, phụ lục/sửa đổi, completeness và phân công rà cụ thể trước kích hoạt. Quyền nguồn không suy ra từ `public` hoặc HTTPS200.

M2 manifest bắt buộc URL identity đã đăng ký, MIME, ngôn ngữ, operator, document_role, rights_basis, required_parts, gaps và `network_enabled=false`. Đây là cấu hình nhập, không chứng cứ đủ bộ hay quyết định chuyên gia. Admin/curator đã có mới ghi được; không tự cấp thêm role.

## 3. Canonical storage và hai giao dịch

```mermaid
flowchart LR
 A[Bytes công khai đã được phép] --> B[UoW A: rendition BLOB + observation + source head/event + outbox + receipt]
 B --> C[Parser cục bộ ngoài giao dịch]
 C --> D[UoW B: recheck bytes/quyền/manifest + extraction/chunks/quality + event/outbox + receipt]
 D --> E[Claim/section bindings + wiki revision nháp]
 E --> F[Current READ và freshness]
 F --> G[FTS / bản gốc / Markdown projection]
```

- Raw: `kp_renditions`, SHA256 nguyên bytes, tên/MIME/source/manifest pin; không ghi `pol_source_snapshots` rỗng rồi cập nhật.
- Source state: `kp_source_manifests`, `kp_source_state`, `kp_acquisition_observations`; version/CAS/causal event head tách khỏi rendition/extraction. Mất head nhưng còn lịch sử thì dừng đối soát; không tạo root mới.
- Extraction: `kp_extractions`, `kp_extraction_chunks`; recipe server `knowledge-local/2`, BLOB SHA, text/locator/content hash, quality/admission và tên tệp lỗi. Chunk không sửa tại chỗ. HTML admission (title/form/credential/visible body) riêng bước đọc chữ; candidate_unverified không là legal admission, trang lỗi/đăng nhập bị rejected không có chunks.
- Parser ngoài mọi SQL transaction; B kiểm lại quyền hiện hành và exact rights decision/manifest/raw. Bản tệp cũ vẫn có thể trích để đối chiếu nhưng không đè observation mới. Hai worker có thể tốn CPU cục bộ lặp; unique rendition/recipe và commit check ngăn extraction trùng. Chưa có mạng/job lease nên chưa nhận đã kiểm fetch coalescing hoặc scheduler fencing.
- TXT/HTML UTF8: tối đa5MB,64.000ký tự; locator theo ký tự Unicode trong **text đã trích**, không giả là raw HTML byte offset. PDF dùng worker giới hạn hiện có:5MB/20trang/64.000ký tự, timeout/resource limit; trang trắng/scan/mixed là gap, không tự OCR. HTML script không được chạy; link phụ lục không tự được tải hoặc coi đã đọc.

## 4. Evidence và coverage

`pipeline_chunk` là ref riêng, không trộn với legacy chunk/member/wiki. Ref pin source/rendition/extraction/chunk/hash/quote và quote_start/end; locator nằm trong chunk hash. Quote lặp cần vị trí explicit; không tự lấy occurrence đầu. Bản gốc được giữ để chuyên gia mở đối chiếu.

`kp_page_contracts` pin discriminator immutable `knowledge-candidate/1`; bare M1 service cũng phải tuân hợp đồng này, không được sửa làm rơi bindings hay đọc bỏ gate. `kp_candidate_bindings` pin exact wiki revision/body SHA; mỗi claim có kind (`source_excerpt` hoặc `interpretation`), start/end/text và evidence. Section identity có kiểu được suy deterministically từ body hash + start/end/kind, không từ tên hiển thị. Nội dung prose ngoài claim bị từ chối; heading Markdown là cấu trúc và **vẫn phải được chuyên gia rà khi mang nhận định vật chất**. `source_excerpt` phải khớp nguyên văn; `interpretation` luôn là diễn giải chưa rà, không được tự biến thành rule/điều kiện/approved claim. Không nhận private_file/SSOT/wiki làm căn cứ gốc.

Đây là **mechanical binding**, không chứng minh entailment, đầy đủ ngoại lệ hoặc đủ luật. Không import approval từ Markdown/frontmatter. Chưa tạo `pol_members` hay approval/release cho wiki; M3 nối governance hiện có với exact target/revision/hash. Candidate luôn `assessment_eligible=false`, kể cả quote khớp và parser đọc được chữ.

## 5. Retrieval và projection

- `policy-freshness-decision/1` giữ decision/mode/reason_codes/usable_for/blocked_outcomes/basis/hash chuẩn. Source change thắng incomplete; incomplete thắng currentness_unconfirmed. M2 chưa có approved live-check profile nên không tự cấp reusable; publication là gate riêng.
- Search projection chỉ giữ page/revision/hash. Mỗi lần tìm reload canonical body/aliases/bindings và READ trước khi tạo **FTS5 trong bộ nhớ**, tối đa500trang. Alias/analyzer từ canonical revision, không trộn legacy FTS có quyền khác. Đây là lựa chọn có giới hạn cho K1; chưa có benchmark hoặc persistent index generation cho kho lớn. Vượt ngưỡng thì dừng rõ, không trả kết quả một phần như đầy đủ.
- Navigation chỉ `related_topic`/`see_also`, pin target page/revision, READ cả hai đầu; khác quan hệ pháp lý. Không traversal đệ quy không giới hạn. Backlink không lấy title của trang bị chặn.
- Markdown là projection từ SQL, mang manifest/hash và cảnh báo chưa phát hành. Local materializer dùng thư mục riêng có marker, temp+fsync+replace; file sửa tay không nhập ngược. Crash giữa replace/ack thì dựng lại không AI. Outbox delivery cũ luôn đọc current head, không viết bản cũ đè bản mới.
- Quyền/source change đã có hiệu lực tại SQL gate trước khi outbox chạy. Export/read/search dùng quyền hiện hành; cleanup file không là authority. Thư mục projection không phục vụ static cho app. Tệp đã được người dùng xuất/copy ra ngoài không thể thu hồi bằng SQL; app phải tải qua service, không đọc file bỏ qua READ.
- `reconcile_exports/drain_outbox` là operator local explicit; kiểm writer trước filesystem, không nhận root/path từ MCP. Không là scheduler/budget/model authority mới.

## 6. MCP và operator

Adapter `knowledge_v1.mcp.register_tools(server, service, call)` dùng callback xác thực hiện có từ `v03.mcp`. Wire không có actor, API key, filesystem path hoặc paid consent. SDK in-memory dùng dispatcher/DTO thật để kiểm auth và read. Chưa đăng ký tool vào app8025/HTTP ở M2; đó là gate tích hợp M3–M5.

Operator `install_m2_on_clone` dùng cùng lifecycle/lock/backup/receipt và exact finite triggers. M1→M2 additive11bảng; `require_schema` chỉ nhận exact M1 hoặc exact M1+M2, không wildcard bỏ qua object lạ. Contract đích `nmate-main-20261026-knowledge-m2`, active V17 không đổi. Managed constructor không bootstrap hoặc import nguồn/grant. Candidate1 là bằng chứng lịch sử chưa phát hành; candidate2 đổi schema trước nghiệm thu, không upgrade tại chỗ DB candidate1 hoặc sửa receipts cũ để khớp.

## 7. Gate còn mở

Nguồn thật/coverage nghiệp vụ, translated evidence tiếng Việt cho nguồn Anh, expert workbench/publication, private-to-public (mặc định không hỗ trợ), legacy consumer adaptation, real fetch/304/DNS/scheduler và chat mobile chưa được nghiệm thu tại M2. Không dùng số test kỹ thuật hoặc fixture để nhận xong toàn hệ thống.

DF liên quan005/013/014/019/027/029/033/035/041/043/044/046/048/049/052/053/054 vẫnD1. Review M2 phải chỉ rõ ca thực chạy và phần chưa áp dụng; dừng sau M2.
