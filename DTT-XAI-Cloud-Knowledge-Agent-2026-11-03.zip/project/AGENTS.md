# nMate — quy ước làm việc trong workspace

## Ghi nhận lỗi thiết kế sau RCA

Người dùng yêu cầu giữ một sổ nguyên nhân thiết kế để sửa kiến trúc, không chỉ vá code. Sổ có thẩm quyền là [MVP/architecture/DESIGN_FLAWS.md](<MVP/architecture/DESIGN_FLAWS.md>).

- Khi điều tra lỗi, đọc các mục liên quan trong sổ trước khi chọn phương án sửa.
- Ngay khi xác nhận nguyên nhân gốc, cập nhật sổ trong cùng đợt công việc. Ghi cả lỗi đã được vá ngay; không đợi có kế hoạch refactor mới ghi.
- Phân biệt giả thuyết, triệu chứng và nguyên nhân đã được chứng minh. Giả thuyết chưa kiểm không được ghi thành RCA xác nhận. Nếu bằng chứng mới bác bỏ RCA cũ, ghi đính chính và liên kết; giữ lịch sử thay đổi.
- Dùng ID `DF-NNN` ổn định. Nếu cùng nguyên nhân tái diễn, bổ sung mốc/bằng chứng vào mục cũ; nếu nguyên nhân khác, tạo mục mới và liên kết. Không gộp các nguyên nhân khác nhau chỉ vì chúng cùng gây một thông báo lỗi.
- Mỗi mục phải có: bằng chứng và phạm vi; cơ chế gây lỗi; ảnh hưởng; biện pháp code hiện tại; bất biến thiết kế; thay đổi kiến trúc còn cần; cách kiểm chứng/điều kiện đóng. Dùng mẫu trong sổ.
- Theo dõi riêng **tình trạng bản vá** và **tình trạng xử lý thiết kế**. Test ca cũ đạt không đủ để kết luận cả lớp lỗi đã bị loại bỏ. Chỉ đánh dấu thiết kế đã kiểm chứng khi có bằng chứng về các đường liên quan và tiêu chí đóng; ghi rõ phần chưa kiểm.
- Với thay đổi liên quan, ghi ID DF trong ghi chú triển khai, review hoặc walkthrough để truy ngược thiết kế → thay đổi → bằng chứng.
- Không ghi khóa API, mật khẩu, token, tài liệu gốc hoặc dữ liệu riêng không cần thiết vào sổ. Dẫn đường tới bằng chứng đã làm sạch, không sao chép dữ liệu nhạy cảm.
- Kết thúc đợt sửa, nêu ngắn các ID mới/cập nhật và phần thiết kế còn mở. Với công việc chỉ sửa tài liệu, kiểm liên kết/ID là đủ; không chạy app hoặc gọi AI trả phí chỉ để cập nhật sổ.

Các quy ước này không cấp thêm ngân sách, không cho tự retry/fallback có phí, không thay D04/D05/D06/D07 hoặc yêu cầu phê duyệt hiện có. Khi chỉ được yêu cầu ghi log/thiết kế, không tự triển khai các thay đổi kiến trúc trong backlog.

## Các biên thiết kế cần giữ khi sửa tiếp

- Field có qualifier phải dùng `domain_validation.base_field_key` và registry dùng chung cho scope/value/sensitivity; chỉ phân loại được casefold, không đổi key/value hoặc mở quyền exact field. Field nghiệp vụ mới cần contract và ca âm, không chỉ thêm vào prompt.
- Exact receipt replay kiểm identity của command đã commit và READ input hiện hành; không dựng lại implicit defaults theo hồ sơ hôm nay. Mutation mới kiểm WRITE/CAS/lifecycle. ACL nguồn bị revoke thắng ownership/grant shortcut; archive không tự thu hồi READ lịch sử.
- Context dùng chuỗi quyết định/hiệu lực, không dùng timestamp+UUID thay thứ tự nhân quả. Giữ raw assertion, quyết định và receipt; không tự sửa dữ liệu cũ để làm test đạt.
- Trạng thái nháp, conflict và async callback phải gắn owner/enterprise/workspace/intake/revision; đổi workspace không mang khóa nháp trước. Nháp cũ vẫn giữ để đối chiếu khi mở lại.
- Chỉ đọc status, cache hoặc recovery không được gọi AI. Khi thêm provider/capability, phải qua consent, D06, egress và request manifest chung; không tạo transport, retry hoặc budget authority thứ hai.
