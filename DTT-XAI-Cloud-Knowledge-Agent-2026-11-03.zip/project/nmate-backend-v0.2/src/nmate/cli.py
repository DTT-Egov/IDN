import argparse
import asyncio
import json
import sys

import uvicorn

from .app import create_app
from .config import Settings


async def verify_model(settings: Settings) -> dict:
    """User-invoked tiny Claude call. Never return SDK errors or the configured key."""
    if not settings.model_configured:
        return {"ok": False, "code": "MODEL_NOT_CONFIGURED",
                "message": f"Cần cấu hình model phù hợp và {settings.credential_env_name} trên máy."}
    if settings.model_provider != "anthropic":
        return {"ok": False, "code": "CLAUDE_ONLY", "message": "Tiện ích này kiểm tra cấu hình Claude; chọn provider anthropic."}
    import anthropic

    try:
        async with anthropic.AsyncAnthropic(api_key=settings.selected_api_key.get_secret_value(),
                        base_url="https://api.anthropic.com", max_retries=0, timeout=30) as client:
            response = await client.messages.create(model=settings.model_name, max_tokens=32,
                          messages=[{"role": "user", "content": "Reply with only OK. This is an API connection test."}])
        return {"ok": True, "provider": "anthropic", "model": response.model,
                "live_model_verified": True, "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
                "message": "Claude API đã phản hồi thật. Tiếp tục thử agent qua giao diện web."}
    except anthropic.AuthenticationError:
        code, message = "INVALID_API_KEY", "Khóa Claude bị từ chối; kiểm tra hoặc tạo lại khóa trên Console."
    except anthropic.PermissionDeniedError:
        code, message = "API_PERMISSION_DENIED", "Khóa chưa có quyền workspace/model; kiểm tra Console."
    except anthropic.NotFoundError:
        code, message = "MODEL_NOT_AVAILABLE", "Model không khả dụng với tài khoản; chọn API model ID được cấp quyền."
    except anthropic.RateLimitError:
        code, message = "API_RATE_OR_SPEND_LIMIT", "Đã chạm hạn mức; kiểm tra Usage/Billing trong Claude Console."
    except anthropic.BadRequestError:
        code, message = "API_REQUEST_REJECTED", "Yêu cầu bị từ chối; kiểm tra model, API credits và Billing trong Console."
    except (anthropic.APIConnectionError, anthropic.APITimeoutError):
        code, message = "API_CONNECTION_FAILED", "Chưa kết nối được Claude API; kiểm tra mạng và thử lại."
    except Exception:
        code, message = "API_CHECK_FAILED", "Chưa xác minh được API. Khóa và lỗi chi tiết không được xuất ra màn hình."
    return {"ok": False, "code": code, "message": message}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description="nMate local backend and MCP preview")
    parser.add_argument("command", choices=["serve", "doctor", "verify-model"], nargs="?", default="serve")
    args = parser.parse_args()
    if args.command == "doctor":
        settings = Settings()
        print(json.dumps({"mode": settings.mode, "model_provider": settings.model_provider,
              "model_name": settings.safe_model_name, "credential_variable": settings.credential_env_name,
              "model_policy": settings.safe_model_policy,
              "credential_present": bool(settings.selected_api_key), "model_configured": settings.model_configured,
              "live_model_verified": False, "web_available": (settings.web_dir / "index.html").is_file(),
              "web_url": settings.base_url + "/web/#research-live"}, ensure_ascii=False, indent=2))
        return
    if args.command == "verify-model":
        result = asyncio.run(verify_model(Settings()))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        raise SystemExit(0 if result["ok"] else 1)
    if args.command == "serve":
        settings = Settings()
        # Intentionally loopback-only. Hosted identity/OAuth is a separate deployment milestone.
        uvicorn.run(create_app(settings), host="127.0.0.1", port=settings.port, access_log=False,
                    log_level="warning")


if __name__ == "__main__":
    main()
