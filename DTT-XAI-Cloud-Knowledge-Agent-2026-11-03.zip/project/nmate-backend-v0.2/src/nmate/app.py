import logging
import secrets
from contextlib import asynccontextmanager
from pathlib import Path

import httpx2
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.staticfiles import StaticFiles

from .agents.registry import AGENTS
from .auth import LocalAuth, McpBearerMiddleware, sha
from .config import Settings
from .conversations.models import (
    ConversationCreate, ConversationDTO, ConversationSummary, ConfirmInput, FactsInput, LinkInput, MessageInput,
    ResearchCaseInput, ResearchCaseResponse,
)
from .conversations.service import ConversationService
from .mcp_server import TOOL_NAMES, create_mcp
from .models import AppError, CaseCreate, CaseReplace, ToolCall
from .service import ResearchService, public_run
from .store import Store

logger = logging.getLogger(__name__)
STATIC = Path(__file__).parent / "static"


def create_app(settings: Settings | None = None, *, graph_factory=None, conversation_model_factory=None) -> FastAPI:
    settings = settings or Settings()
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    store = Store(settings.data_dir / "business.sqlite3")
    auth = LocalAuth(store, settings.data_dir)
    browser_mcp_tokens: dict[str, str] = {}
    # An unrecognized browser session after a restart is replaced; business data persists.
    service = ResearchService(store, settings, None, graph_factory=graph_factory)
    conversations = ConversationService(store, settings, model_factory=conversation_model_factory)
    mcp = create_mcp(service)
    mcp_app = mcp.streamable_http_app(streamable_http_path="/mcp", stateless_http=True,
                                     json_response=True, max_request_body_size=65536)

    @asynccontextmanager
    async def lifespan(app):
        async with AsyncSqliteSaver.from_conn_string(str(settings.data_dir / "checkpoints.sqlite3")) as cp:
            await cp.setup()
            service.checkpointer = cp
            async with mcp_app.router.lifespan_context(mcp_app):
                store.interrupt_incomplete_runs()
                conversations.store.interrupt_processing()
                await service.start_worker()
                try:
                    yield
                finally:
                    await service.stop_worker()

    app = FastAPI(title="nMate Backend 0.2 — local preview", version="0.2.0", lifespan=lifespan)
    app.state.service, app.state.store, app.state.settings, app.state.mcp = service, store, settings, mcp
    app.state.conversations = conversations
    app.state.auth = auth
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost"])

    @app.middleware("http")
    async def request_limits(request: Request, call_next):
        if request.method in ("POST", "PUT", "PATCH"):
            try:
                if int(request.headers.get("content-length", "0")) > 65536:
                    return JSONResponse({"error": "request_too_large"}, 413)
            except ValueError:
                return JSONResponse({"error": "invalid_content_length"}, 400)
            # Read with an actual streaming bound; content-length alone is not a limit.
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 65536:
                    return JSONResponse({"error": "request_too_large"}, 413)
            request._body = bytes(body)
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'"
        return response

    @app.exception_handler(AppError)
    async def app_error(request, exc):
        return JSONResponse(exc.envelope(), exc.status)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, exc):
        return JSONResponse({"ok": False, "error": {"code": "VALIDATION_ERROR", "message": "Dữ liệu đầu vào chưa hợp lệ.",
                            "fields": [".".join(str(p) for p in e["loc"]) for e in exc.errors()]}}, 422)

    def session(request: Request, *, mutation=False):
        value = request.cookies.get("nmate_session")
        record = auth.get_session(value)
        p = auth.device_principal(request.cookies.get("nmate_device"))
        if not p or not record or auth.record_principal(record) != p or value not in browser_mcp_tokens:
            raise AppError("SESSION_REQUIRED", "Phiên thử đã hết hạn; hãy tải lại trang.", 401)
        if mutation:
            origins = {settings.base_url, f"http://localhost:{settings.port}"}
            if request.headers.get("origin") and request.headers["origin"] not in origins:
                raise AppError("ORIGIN_FORBIDDEN", "Nguồn yêu cầu không được phép.", 403)
            csrf = request.headers.get("x-csrf-token", "")
            if not secrets.compare_digest(csrf, record["csrf"]):
                raise AppError("CSRF_INVALID", "Phiên yêu cầu chưa hợp lệ.", 403)
        return p, browser_mcp_tokens[value]

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(STATIC / "index.html")

    @app.get("/health")
    async def health():
        return {"status": "ok", "version": "0.2.0", "local_preview": True, "mode": settings.mode,
                "model_provider": settings.model_provider, "model_name": settings.safe_model_name,
                "model_policy": settings.safe_model_policy,
                "model_configured": settings.model_configured, "mcp_protocol": "2026-07-28",
                "agents": [{"kind": a.kind, "title": a.title, "status": a.status} for a in AGENTS.values()]}

    @app.get("/api/session")
    async def get_session(request: Request):
        cookie = request.cookies.get("nmate_session")
        device_cookie = request.cookies.get("nmate_device")
        p = auth.device_principal(device_cookie)
        new_device = p is None
        if new_device:
            device_cookie = auth.create_device()
            p = auth.device_principal(device_cookie)
        record = auth.get_session(cookie)
        new = None
        if not record or auth.record_principal(record) != p or cookie not in browser_mcp_tokens:
            new = auth.create_session(p)
            cookie = new["session_id"]
            if len(browser_mcp_tokens) >= 100:
                browser_mcp_tokens.clear()
            browser_mcp_tokens[cookie] = new["mcp_token"]
            record = {"csrf": new["csrf"]}
        payload = await health()
        payload["csrf_token"] = record["csrf"]
        payload.update(workspace_id=sha(p.tenant_id)[:32], browser_user_id=sha(p.tenant_id)[:32], identity_mode="browser_profile_local",
                       legacy_workspace_quarantined=True)
        response = JSONResponse(payload)
        if new:
            response.set_cookie("nmate_session", cookie, httponly=True, samesite="strict", max_age=8*3600)
        if new_device:
            response.set_cookie("nmate_device", device_cookie, httponly=True, samesite="strict", max_age=365*24*3600)
        return response

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon():
        from fastapi.responses import Response
        return Response(status_code=204)

    @app.post("/api/cases", status_code=201)
    async def create_case(data: CaseCreate, request: Request):
        p, _ = session(request, mutation=True)
        return store.create_case(p, data.model_dump(mode="json"))

    @app.get("/api/cases")
    async def list_cases(request: Request):
        p, _ = session(request)
        return store.list_cases(p)

    @app.get("/api/cases/{case_id}")
    async def get_case(case_id: str, request: Request):
        p, _ = session(request)
        return store.get_case(p, case_id)

    @app.put("/api/cases/{case_id}")
    async def update_case(case_id: str, data: CaseReplace, request: Request):
        p, _ = session(request, mutation=True)
        return store.replace_case(p, case_id, data.expected_case_version,
                                 data.model_dump(mode="json", exclude={"expected_case_version"}))

    @app.get("/api/runs")
    async def runs(request: Request):
        p, _ = session(request)
        return [public_run(run) for run in store.list_runs(p)]

    @app.post("/api/conversations", response_model=ConversationDTO, status_code=201)
    async def create_conversation(data: ConversationCreate, request: Request):
        p, _ = session(request, mutation=True)
        return conversations.store.create(p, data.model_dump())

    @app.get("/api/conversations", response_model=list[ConversationSummary])
    async def list_conversations(request: Request):
        p, _ = session(request)
        return conversations.store.list(p)

    @app.get("/api/conversations/{conversation_id}", response_model=ConversationDTO)
    async def get_conversation(conversation_id: str, request: Request):
        p, _ = session(request)
        return conversations.store.get(p, conversation_id)

    @app.post("/api/conversations/{conversation_id}/messages", response_model=ConversationDTO)
    async def conversation_message(conversation_id: str, data: MessageInput, request: Request):
        p, _ = session(request, mutation=True)
        return await conversations.message(p, conversation_id, data.model_dump())

    @app.post("/api/conversations/{conversation_id}/facts", response_model=ConversationDTO)
    async def edit_conversation_facts(conversation_id: str, data: FactsInput, request: Request):
        p, _ = session(request, mutation=True)
        return conversations.store.edit_facts(p, conversation_id, data.model_dump())

    @app.post("/api/conversations/{conversation_id}/confirm", response_model=ConversationDTO)
    async def confirm_conversation(conversation_id: str, data: ConfirmInput, request: Request):
        p, _ = session(request, mutation=True)
        return conversations.store.confirm(p, conversation_id, data.model_dump())

    @app.post("/api/conversations/{conversation_id}/link", response_model=ConversationDTO)
    async def link_conversation(conversation_id: str, data: LinkInput, request: Request):
        p, _ = session(request, mutation=True)
        return conversations.store.link(p, conversation_id, data.model_dump())

    @app.post("/api/conversations/{conversation_id}/research-case", response_model=ResearchCaseResponse)
    async def conversation_research_case(conversation_id: str, data: ResearchCaseInput, request: Request):
        p, _ = session(request, mutation=True)
        return conversations.store.research_case(p, conversation_id, data.model_dump())

    @app.get("/api/artifacts/{artifact_id}/translations")
    async def artifact_translations(artifact_id: str, request: Request):
        p, _ = session(request)
        artifact = store.get_artifact(p, artifact_id)
        from .agents.shipment.translations import evidence_display_translations
        return {"artifact_id": artifact["artifact_id"], "content_sha256": artifact["content_sha256"],
                "evidence_translations": evidence_display_translations(artifact["report"])}

    @app.get("/api/report-schema")
    async def report_schema(request: Request):
        session(request)
        from .agents.shipment.models import ShipmentReport
        return ShipmentReport.model_json_schema()

    @app.post("/api/mcp/call")
    async def mcp_call(data: ToolCall, request: Request):
        _, token = session(request, mutation=True)
        if data.name not in TOOL_NAMES:
            raise AppError("TOOL_NOT_AVAILABLE", "Công cụ chưa được triển khai trong bản này.", 404)
        try:
            async with httpx2.AsyncClient(headers={"Authorization": f"Bearer {token}"}, timeout=15, trust_env=False) as http:
                transport = streamable_http_client(settings.base_url + "/mcp", http_client=http)
                async with Client(transport, mode="2026-07-28", cache=None) as client:
                    result = await client.call_tool(data.name, data.arguments)
                    value = result.structured_content
            # Interpret after exiting SDK contexts; preserve structured business errors.
            if result.is_error and not isinstance(value, dict):
                raise AppError("TOOL_INPUT_INVALID", "MCP từ chối tham số công cụ; hãy kiểm tra hợp đồng đầu vào.", 422)
            if not isinstance(value, dict):
                raise AppError("MCP_INVALID_RESULT", "MCP trả kết quả không đúng cấu trúc.", 502)
            return value
        except AppError:
            raise
        except Exception as exc:
            logger.warning("mcp client failure type=%s", type(exc).__name__)
            raise AppError("MCP_UNAVAILABLE", "Chưa kết nối được MCP server; hãy kiểm tra backend.", 503) from None

    # Only expose the frontend assets, never the project's .git, server scripts or local settings.
    if (settings.web_dir / "index.html").is_file() and (settings.web_dir / "src").is_dir():
        @app.get("/web", include_in_schema=False)
        async def web_redirect():
            from fastapi.responses import RedirectResponse
            return RedirectResponse("/web/", status_code=307)

        @app.get("/web/", include_in_schema=False)
        async def web_index():
            return FileResponse(settings.web_dir / "index.html")

        app.mount("/web/src", StaticFiles(directory=settings.web_dir / "src"), name="web-assets")

    # Mounted at root so the actual MCP endpoint is /mcp, with no redirect/trailing slash dependency.
    app.mount("/", McpBearerMiddleware(mcp_app, auth))
    return app
