"""0.4A capabilities share the owner-authenticated MCP transport with 0.3B."""
import asyncio
from typing import Annotated, Any, Literal

from pydantic import Field

from nmate.v03.mcp import Identifier, Operation, Result
from nmate.v03.core import CoreError

TOOL_NAMES = {"prepare_intake", "get_intake", "list_intakes", "confirm_intake", "get_attachment", "clarify_intake",
              "send_message", "get_conversation", "list_conversations", "save_conversation_draft",
              "get_review_workspace", "get_review_receipt", "dismiss_review_candidates"}


def register_tools(server, intake, call):
    from .conversations import ConversationService
    conversations = getattr(intake, "conversations_factory", ConversationService)(intake)

    def checked_draft(account, enterprise, intake_id, draft):
        if not isinstance(draft, dict) or not intake_id:
            return
        value = intake.get(account, enterprise, intake_id)
        if (value.get("review") or {}).get("schema_version") == "workspace-review/2" and (
                "base_review_revision" not in draft or "ui_revision" not in draft):
            raise CoreError("CLIENT_UPGRADE_REQUIRED", "Tải lại app để lưu lựa chọn nháp có phiên bản. Nội dung đang sửa được giữ; chưa đổi hồ sơ.", 409)

    @server.tool(structured_output=True, description="Continue an owner-private conversation, retaining messages, documents and unconfirmed work. Atomic creation and idempotent sends. " +
        ("Requires paid_consent=true; at most one paid Claude call per new operation, no automatic retry. No automatic SSOT update." if getattr(intake, "paid_review", False) else "No model call or automatic SSOT update."))
    async def send_message(enterprise_id: Identifier, text: Annotated[str, Field(max_length=4000)],
                           attachments: Annotated[list[dict[str, str]], Field(max_length=3)], operation_id: Operation,
                           conversation_id: Identifier | None = None, product_entity_id: Identifier | None = None,
                           draft: dict[str, Any] | None = None, target_intake_id: Identifier | None = None,
                           paid_consent: bool = False,
                           task_hint: Literal["profile_intake", "export_research", "sales_inventory"] | None = None,
                           market_code: Literal["US", "DE", "JP"] | None = None) -> Result:
        if getattr(intake, "unified_main", False) and task_hint is None:
            def require_main_client(account):
                # A still-open mock 0.4 page must never become a paid client
                # simply because the loopback server was upgraded in place.
                raise CoreError("APP_REFRESH_REQUIRED", "App chính đã cập nhật. Bạn tải lại trang để kiểm tra kết nối Claude và chi phí trước khi gửi.", 409)
            return await call(require_main_client)
        if hasattr(conversations, "send_async"):
            options = {"task_hint": task_hint, "market_code": market_code} if getattr(intake, "unified_main", False) else {}
            async def send(account):
                if draft:
                    checked_draft(account, enterprise_id, draft.get("intake_id"), draft)
                return await conversations.send_async(account, enterprise_id, text, attachments,
                    operation_id, conversation_id, product_entity_id, draft, target_intake_id, paid_consent=paid_consent, **options)
            return await call(send)
        async def send_sync(account):
            if draft:
                checked_draft(account, enterprise_id, draft.get("intake_id"), draft)
            return await asyncio.to_thread(conversations.send, account, enterprise_id, text, attachments,
                operation_id, conversation_id, product_entity_id, draft, target_intake_id)
        return await call(send_sync)

    @server.tool(structured_output=True, description="Read an authorized conversation and the actual committed SSOT confirmation state. Does not send, parse or run a model.")
    async def get_conversation(enterprise_id: Identifier, conversation_id: Identifier) -> Result:
        return await call(lambda account: conversations.get(account, enterprise_id, conversation_id))

    @server.tool(structured_output=True, description="List only the authenticated owner's conversations, without other enterprise data.")
    async def list_conversations(enterprise_id: Identifier) -> Result:
        return await call(lambda account: conversations.list(account, enterprise_id))

    @server.tool(structured_output=True, description="Save private per-intake working selections and edits. Does not update SSOT. Idempotent; unknown candidate IDs rejected.")
    async def save_conversation_draft(enterprise_id: Identifier, conversation_id: Identifier, intake_id: Identifier,
                                      draft: dict[str, Any], operation_id: Operation) -> Result:
        def save(account):
            checked_draft(account, enterprise_id, intake_id, draft)
            return conversations.save_draft(account, enterprise_id, conversation_id, intake_id, draft, operation_id)
        return await call(save)

    @server.tool(structured_output=True, description="Prepare a private image/XLSX intake and a bounded intent plan. "
        "Excel is parsed locally. Only hash-matched demo images have explicitly simulated recognition; other images are stored, not read. "
        "Extracted values remain candidates until owner confirmation. No paid calls, no policy research.")
    async def prepare_intake(enterprise_id: Identifier, text: Annotated[str, Field(max_length=4000)],
                             attachments: Annotated[list[dict[str, str]], Field(max_length=3)], operation_id: Operation,
                             product_entity_id: Identifier | None = None) -> Result:
        return await call(lambda account: asyncio.to_thread(intake.prepare, account, enterprise_id, text,
            attachments, operation_id, product_entity_id))

    @server.tool(structured_output=True, description="Read an authorized saved intake. Never re-parses files or re-runs a model.")
    async def get_intake(enterprise_id: Identifier, intake_id: Identifier) -> Result:
        return await call(lambda account: intake.get(account, enterprise_id, intake_id))

    @server.tool(structured_output=True, description="Clarify the goal of an owned unconfirmed intake, retaining its original attachments, candidate IDs and CAS snapshot. "
                 "Does not re-parse files, write SSOT or call a model. Idempotent.")
    async def clarify_intake(enterprise_id: Identifier, intake_id: Identifier,
                             text: Annotated[str, Field(min_length=1, max_length=4000)], operation_id: Operation) -> Result:
        return await call(lambda account: asyncio.to_thread(intake.clarify, account, enterprise_id, intake_id, text, operation_id))

    @server.tool(structured_output=True, description="List up to 50 private intakes owned by the authenticated enterprise owner.")
    async def list_intakes(enterprise_id: Identifier) -> Result:
        return await call(lambda account: intake.list(account, enterprise_id))

    @server.tool(structured_output=True, description="Atomically confirm selected extracted facts into enterprise SSOT. "
        "Owner choices resolve conflicts; all selected entity versions must match. Idempotent, no model call, never guesses missing facts.")
    async def confirm_intake(enterprise_id: Identifier, intake_id: Identifier,
                             selected_fact_ids: Annotated[list[str], Field(max_length=40)],
                             expected_entity_versions: dict[str, int], operation_id: Operation,
                             edits: dict[str, Any] | None = None,
                             conflict_choices: dict[str, Literal["incoming", "current"]] | None = None,
                             expected_review_revision: int | None = None,
                             expected_proposal_hashes: dict[str, str] | None = None) -> Result:
        def confirm(account):
            try:
                if expected_review_revision is None or expected_proposal_hashes is None:
                    raise CoreError("CLIENT_UPGRADE_REQUIRED", "Tải lại app để xác nhận đúng phiên bản nháp. Chưa ghi thay đổi từ yêu cầu này.", 409)
                return intake.confirm(account, enterprise_id, intake_id, selected_fact_ids, expected_entity_versions,
                    operation_id, edits, conflict_choices, expected_review_revision=expected_review_revision,
                    expected_proposal_hashes=expected_proposal_hashes)
            except CoreError as exc:
                # Domain CoreError rolls back the local command's single UoW.
                # Network/SQLite/unknown failures are deliberately not labelled.
                exc.commit_state = "not_committed"
                raise
        return await call(lambda account: asyncio.to_thread(confirm, account))

    @server.tool(structured_output=True, description="Read a versioned owner-private review workspace in one SQL snapshot. No parsing, model call, or fact write.")
    async def get_review_workspace(enterprise_id: Identifier, intake_id: Identifier) -> Result:
        def read(account):
            from nmate.main.workspace_view import intake_workspace_view
            with intake.repo.connection() as db:
                value = intake._owned(account, enterprise_id, intake_id, db)
                return intake_workspace_view(intake.repo, account, enterprise_id, value, db)
        return await call(read)

    @server.tool(structured_output=True, description="Read the immutable receipt of a local confirmation and the separate current workspace state. Never replays a model call.")
    async def get_review_receipt(enterprise_id: Identifier, intake_id: Identifier, operation_id: Operation,
                                 command_kind: Literal["confirm_selected", "dismiss_candidates"] = "confirm_selected") -> Result:
        return await call(lambda account: intake.get_review_receipt(account, enterprise_id, intake_id, operation_id,
                                                                   command_kind=command_kind))

    @server.tool(structured_output=True, description="Explicitly dismiss selected pending proposals, preserving observations and SSOT. Unchecked proposals are never implicitly dismissed.")
    async def dismiss_review_candidates(enterprise_id: Identifier, intake_id: Identifier,
                                          candidate_ids: Annotated[list[str], Field(min_length=1, max_length=40)],
                                          operation_id: Operation, expected_review_revision: int,
                                          expected_proposal_hashes: dict[str, str],
                                          reason: Literal["owner_dismissed"] = "owner_dismissed") -> Result:
        return await call(lambda account: asyncio.to_thread(intake.dismiss_candidates,
            account, enterprise_id, intake_id, candidate_ids, operation_id, reason,
            expected_review_revision=expected_review_revision, expected_proposal_hashes=expected_proposal_hashes))

    @server.tool(structured_output=True, description="Read the original bytes of an authorized private attachment as base64, for source inspection only.")
    async def get_attachment(enterprise_id: Identifier, attachment_id: Identifier) -> Result:
        return await call(lambda account: intake.attachment(account, enterprise_id, attachment_id))
