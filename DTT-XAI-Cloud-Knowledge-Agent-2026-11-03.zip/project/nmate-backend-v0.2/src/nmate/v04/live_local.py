"""Isolated Claude-backed 0.4A review runner; never used by default preview."""
import argparse
import ipaddress
import os
from pathlib import Path
import socket


def review_network_guard():
    """Only loopback and DNS results for api.anthropic.com may connect."""
    lookup, connect, connect_ex = socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex
    allowed_ips = set()
    counts = {"blocked_network_attempts": 0}

    def local(host):
        if host in {"localhost", "127.0.0.1", "::1"}:
            return True
        try:
            return ipaddress.ip_address(host).is_loopback
        except ValueError:
            return False

    def allowed(host):
        return local(host) or host in allowed_ips

    def getaddrinfo(host, *args, **kwargs):
        if isinstance(host, bytes):
            host = host.decode("ascii", "strict")
        if host != "api.anthropic.com" and not allowed(host):
            counts["blocked_network_attempts"] += 1
            raise OSError("Review network policy blocked destination")
        values = lookup(host, *args, **kwargs)
        if host == "api.anthropic.com":
            allowed_ips.update(value[4][0] for value in values)
        return values

    def check(address):
        if isinstance(address, tuple) and (not allowed(address[0]) or
                not local(address[0]) and address[1] != 443):
            counts["blocked_network_attempts"] += 1
            raise OSError("Review network policy blocked destination")

    def guarded_connect(sock, address):
        check(address)
        return connect(sock, address)

    def guarded_connect_ex(sock, address):
        check(address)
        return connect_ex(sock, address)

    socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex = getaddrinfo, guarded_connect, guarded_connect_ex
    return counts


def make_live_app(db_path, *, api_key, simple_model, complex_model, port=8034, web_dir=None, request_fn=None,
                  cookie_namespace="nmate_v04a_live_review"):
    from nmate.v03.app import create_app
    from .live_review import LiveIntakeService, V04ReviewProvider, LIVE_TOOLS, MODE
    holder = {}

    def factory(repo):
        provider = V04ReviewProvider(repo, api_key=api_key, simple_model=simple_model,
                                     complex_model=complex_model, request_fn=request_fn)
        provider.recover()
        holder["provider"] = provider
        return LiveIntakeService(repo, provider=provider)

    def metadata():
        return {k: v for k, v in holder["provider"].summary().items() if k != "attempts"}

    app = create_app(Path(db_path), port=port, enable_v04=True, intake_factory=factory,
        tool_allowlist=LIVE_TOOLS, web_dir=web_dir, cookie_namespace=cookie_namespace,
        mode=MODE, metadata_provider=metadata, mcp_timeout=115)
    app.title = "nMate 0.4A · Review độc lập bằng Claude thật"
    app.state.review_provider = holder["provider"]

    @app.get("/api/v04/qa-status")
    async def qa_status():
        return {"version": "0.4A", "mode": MODE, "vision_mode": "claude_vision_unverified_candidates",
                "intent_mode": "claude_validated_dialogue", "excel_mode": "bounded_real_xlsx_parser",
                "model_policy": {"simple": simple_model, "complex": complex_model},
                **app.state.telemetry, **getattr(app.state, "network_guard", {}), **metadata(),
                "retry_policy": "no_sdk_retry_no_fallback_no_automatic_resend",
                "network_policy": "loopback_and_api.anthropic.com_only",
                "audit_isolation": "separate_database_and_cookie_namespace"}

    app.router.routes.insert(-1, app.router.routes.pop())
    return app


def main():
    parser = argparse.ArgumentParser(description="Isolated Claude 0.4A owner review; maximum four explicit sends")
    parser.add_argument("--port", type=int, default=8034)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--web-dir", type=Path, required=True)
    parser.add_argument("--env-file", type=Path, default=Path(__file__).resolve().parents[3] / ".env")
    args = parser.parse_args()
    from nmate.config import Settings
    settings = Settings(_env_file=args.env_file)
    if settings.model_provider != "anthropic" or not settings.model_configured:
        raise RuntimeError("Claude chưa được cấu hình đúng. Chưa gửi yêu cầu nào.")
    if args.port == 8025:
        raise RuntimeError("Bản review phải dùng cổng riêng; không thay thế 8025.")
    os.environ["LANGSMITH_TRACING"] = "false"
    os.environ["LANGCHAIN_TRACING_V2"] = "false"
    counts = review_network_guard()
    args.data_dir.mkdir(parents=True, exist_ok=True)
    app = make_live_app(args.data_dir / "enterprise.sqlite3", port=args.port, web_dir=args.web_dir,
        api_key=settings.anthropic_api_key.get_secret_value(), simple_model=settings.simple_model,
        complex_model=settings.complex_model)
    app.state.network_guard = counts
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning", access_log=False)


if __name__ == "__main__":
    main()
