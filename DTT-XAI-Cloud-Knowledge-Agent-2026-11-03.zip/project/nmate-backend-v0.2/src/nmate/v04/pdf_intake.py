"""Bounded local PDF observations; original files never enter an LLM request."""
from __future__ import annotations

import json
import copy
import hashlib
from contextvars import ContextVar
import os
import subprocess
import sys
import re

from nmate.v03.core import CoreError
from .pdf_worker import MAX_PAGES, MAX_CHARS

PDF_PREFLIGHT = ContextVar('request_local_pdf_preflight', default=None)


ERRORS = {
    'invalid_pdf': 'PDF không hợp lệ hoặc không đọc được. Chị xuất lại thành PDF văn bản rồi thử lại.',
    'encrypted_pdf': 'PDF có mật khẩu. Chị mở và xuất bản PDF không khóa trước khi đính kèm; không gửi mật khẩu trong chat.',
    'pdf_page_limit': 'Mỗi PDF tối đa 20 trang. Chị tách các trang cần đọc thành tệp nhỏ hơn.',
    'pdf_text_limit': 'PDF có quá nhiều chữ; mỗi tệp tối đa 64.000 ký tự. Chị tách phần cần hỗ trợ.',
    'pdf_resource_limit': 'PDF quá phức tạp để đọc an toàn. Chị xuất lại các trang cần thiết dưới dạng PDF văn bản.',
    'pdf_size_limit': 'Mỗi PDF tối đa 5 MB.',
    'pdf_reader_unavailable': 'Bộ đọc PDF trên máy chủ chưa sẵn sàng. Tệp vẫn được giữ; chị có thể đọc lại sau.',
}


def extract_pdf_pages(raw):
    env = {key: value for key, value in os.environ.items() if key not in {
        'ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'LANGSMITH_API_KEY', 'LANGCHAIN_API_KEY'}}
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    try:
        process = subprocess.run([sys.executable, '-X', 'utf8', '-m', 'nmate.v04.pdf_worker'], input=raw,
                                 capture_output=True, timeout=15, env=env, creationflags=flags)
        if process.returncode or len(process.stdout) > 600_000:
            raise CoreError('pdf_resource_limit', ERRORS['pdf_resource_limit'])
        result = json.loads(process.stdout)
    except subprocess.TimeoutExpired as exc:
        raise CoreError('pdf_resource_limit', ERRORS['pdf_resource_limit']) from exc
    except (ValueError, OSError) as exc:
        # Spawn/JSON failures say nothing about the submitted PDF's validity.
        raise CoreError('pdf_reader_unavailable', ERRORS['pdf_reader_unavailable'], 503) from exc
    if not isinstance(result, dict) or type(result.get('ok')) is not bool:
        raise CoreError('pdf_reader_unavailable', ERRORS['pdf_reader_unavailable'], 503)
    if not result['ok']:
        code = result.get('code')
        if code not in ERRORS:
            raise CoreError('pdf_reader_unavailable', ERRORS['pdf_reader_unavailable'], 503)
        raise CoreError(code, ERRORS[code], 503 if code == 'pdf_reader_unavailable' else 400)
    pages, page_count = result.get('pages'), result.get('page_count')
    if (not isinstance(pages, list) or type(page_count) is not int or not 0 <= page_count <= MAX_PAGES
            or len(pages) != page_count or result.get('status') not in {'text_extracted', 'no_readable_text'}
            or any(not isinstance(page, dict) or type(page.get('page_number')) is not int
                   or page['page_number'] != number or not isinstance(page.get('text'), str)
                   for number, page in enumerate(pages, 1))
            or sum(len(page['text']) for page in pages) > MAX_CHARS):
        raise CoreError('pdf_reader_unavailable', ERRORS['pdf_reader_unavailable'], 503)
    return result


def parse_pdf(raw):
    cache = PDF_PREFLIGHT.get()
    key = hashlib.sha256(raw).hexdigest()
    if cache is not None and key in cache:
        return copy.deepcopy(cache[key])
    from .extraction import extract_business_text, ALIASES, FIELD_SPECS, normalize, typed_value
    result = extract_pdf_pages(raw)
    facts, notices = [], []
    for page in result['pages']:
        observations = extract_business_text(page['text'])
        # PDFs often contain labeled form rows rather than first-person chat.
        # Only the small known registry is accepted; prose/instructions and
        # financial rows do not invent fields or authorize outbound processing.
        for line in page['text'].splitlines():
            match = re.fullmatch(r'\s*([^:：\n]{1,80}?)\s*[:：]\s*(.{1,2000})\s*', line)
            if not match:
                continue
            field = ALIASES.get(normalize(match[1]))
            if not field or field == 'revenue':
                continue
            try:
                value, value_type = typed_value(field, match[2].strip())
            except CoreError:
                notices.append(f"Dòng '{FIELD_SPECS[field][0]}' ở trang {page['page_number']} chưa hợp lệ; chưa tạo dữ kiện từ dòng đó.")
                continue
            observations.append({'entity_type':FIELD_SPECS[field][1], 'field':field,
                'label_vi':FIELD_SPECS[field][0], 'value':value, 'value_type':value_type,
                'unit':None, 'period':None, 'confidence':'local_pdf_text_unverified',
                'note_vi':'Dòng có nhãn được đọc tại máy chủ; chủ doanh nghiệp xác nhận trước khi lưu.',
                'source':{'quote':line,'value_quote':match[2].strip(),'review_state':'owner_confirmation_required'}})
        seen = set()
        for fact in observations:
            fact_key = (fact['entity_type'], fact['field'], json.dumps(fact['value'], ensure_ascii=False, sort_keys=True))
            if fact_key in seen:
                continue
            seen.add(fact_key)
            fact['source'].update(kind='local_pdf_text', parser='pypdf-6.10.0',
                                  page_number=page['page_number'], locator=f"PDF - trang {page['page_number']}",
                                  simulation=False, review_state='owner_confirmation_required')
            facts.append(fact)
    if result['status'] == 'no_readable_text':
        notices.append('PDF chỉ có ảnh hoặc chưa có lớp chữ đọc được. Bản này chưa OCR PDF scan; chưa tạo dữ kiện. Chị có thể gửi ảnh rõ hoặc PDF văn bản.')
    else:
        notices.append(f"Đã đọc chữ tại máy chủ từ {result['page_count']} trang PDF, không gửi tài liệu cho Claude. Chỉ tạo nháp những dữ kiện có câu khai rõ; chị xác nhận trước khi lưu hồ sơ.")
    preview = [{'page_number': page['page_number'], 'text': page['text'][:2000]}
               for page in result['pages'] if page['text'].strip()]
    return facts, notices, {'page_count': result['page_count'], 'text_preview_pages': preview,
                            'extraction_status': 'parsed_local_pdf' if result['status'] == 'text_extracted' else 'stored_not_read',
                            'egress_policy': 'server_only_no_llm'}
