"""Explicit product identity and minimal business context, without SSOT writes."""
from __future__ import annotations

import copy
import hashlib
import re
import unicodedata

from nmate.v03.core import CoreError, json_text
from nmate.v03.field_scope import canonical_entity_type
from .extraction import extract_product_text, normalize, product_name_key, PRODUCT_NAME_END, named_profile_lookup


def declared_product_name(text):
    # A reference may resolve an authorized exact existing product for context,
    # but is not an owner assertion and is absent from extracted fact proposals.
    result = next((item["value"] for item in extract_product_text(text, include_product_references=True,
        reject_multiple_products=True) if item["field"] == "name"), None)
    if result is None and isinstance(text, str):
        # Identity comparison can normalize composition; candidates still come
        # only from the original text with their original offsets and spelling.
        composed = unicodedata.normalize("NFC", text)
        if composed != text:
            result = next((item["value"] for item in extract_product_text(composed, include_product_references=True,
                reject_multiple_products=True) if item["field"] == "name"), None)
    return result


def exact_product_reference(text, name):
    """An authorized saved identity may be referenced; accents remain identity.

    A trailing word cannot turn a shorter saved name into a match for a longer
    unknown product. The same field/operational boundaries used by extraction
    determine where a reference ends. This never creates an alias.
    """
    value, key = product_name_key(text), product_name_key(name)
    return any(re.match("(?:" + PRODUCT_NAME_END + ")", value[match.end():], re.IGNORECASE)
               for match in re.finditer(r"(?<!\w)" + re.escape(key) + r"(?!\w)", value))


def product_reference_spans(text, name):
    """Literal identity spans only; eligibility and subject boundaries are separate."""
    value, key = product_name_key(text), product_name_key(name)
    if not key:
        return []
    return [(match.start(), match.end()) for match in re.finditer(
        r"(?<!\w)" + re.escape(key) + r"(?!\w)", value)]


def authorized_product_reference_ids(text, aliases):
    """Resolve a joint set of authorized exact subjects, never a last-name win.

    Longest known literals suppress their component aliases. A conjunction is
    a separator only when its right-hand side is another authorized full span
    whose chain reaches a valid terminal boundary; it is not a global boundary.
    """
    lookup = named_profile_lookup(text)
    value = product_name_key(lookup or text)
    spans = {(start, end, entity_id) for entity_id, name in aliases
             for start, end in product_reference_spans(lookup or text, name)}
    maximal = {span for span in spans if not any(
        other[0] <= span[0] and span[1] <= other[1] and other[1]-other[0] > span[1]-span[0]
        for other in spans)}
    accepted = set()
    for span in sorted(maximal, key=lambda item: item[1], reverse=True):
        start, end, entity_id = span
        terminal = end == len(value) if lookup else re.match("(?:" + PRODUCT_NAME_END + ")", value[end:], re.IGNORECASE)
        if terminal:
            accepted.add(span)
            continue
        separator = re.match(r"\s+(?:và|hoặc|hay)\s+", value[end:], re.IGNORECASE)
        if separator and any(next_start == end + separator.end() for next_start, _end, _id in accepted):
            accepted.add(span)
    if not lookup:
        return {entity_id for _start, _end, entity_id in accepted}
    # A specifically named lookup must be covered completely. Recognizing only
    # its last known member cannot silently select it over an unknown first or
    # middle member, or over the unrecognized prefix of a longer literal name.
    reachable, result, complete = {0}, set(), False
    for start, end, entity_id in sorted(accepted):
        if start not in reachable:
            continue
        result.add(entity_id)
        if end == len(value):
            complete = True
        else:
            separator = re.match(r"\s+(?:và|hoặc|hay)\s+", value[end:], re.IGNORECASE)
            if separator:
                reachable.add(end + separator.end())
    return result if complete else set()


def product_binding_changed(previous, chosen_product, binding):
    """Reference/new identity changes start another work unit, not a rename."""
    if not previous:
        return False
    prior_product = previous.get("product") or {}
    prior_binding = previous.get("product_binding") or {}
    prior_name = (prior_binding.get("referenced_name") or prior_binding.get("declared_name") or
                  next((c["value"] for c in previous.get("candidates", []) if c["field"] == "name"), None) or
                  prior_product.get("name"))
    named_change = binding["state"] in {"new_product_draft", "unbound_reference"} and product_name_key(
        binding.get("declared_name") or binding.get("referenced_name") or "") != product_name_key(prior_name or "")
    return bool(chosen_product and chosen_product != prior_product.get("id") or named_change)



def owned_product_names(repo, account, enterprise, product_id, db):
    """Return only aliases authorized for this exact owner-private resource."""
    entity = repo._entity(account, enterprise, product_id, db)
    if entity["entity_type"] != "product":
        raise CoreError("invalid_product", "Thông tin được chọn chưa phải sản phẩm.")
    names = {product_name_key(row[0]) for row in db.execute(
        "SELECT name_key FROM v03_entity_names WHERE entity_id=?", (product_id,))}
    names.add(product_name_key(entity["name"]))
    return entity, names


def matching_owned_products(repo, account, enterprise, name, db):
    """Exact active owned identities/aliases, never observations or fuzzy names."""
    repo.get_membership(account, enterprise, db)
    key = product_name_key(name)
    matches = {row["entity_id"] for row in db.execute(
        "SELECT n.entity_id,n.name_key FROM v03_entity_names n JOIN v03_entities e ON e.id=n.entity_id "
        "WHERE e.enterprise_id=? AND e.created_by=? AND e.acl='private_owner' AND e.entity_type='product'",
        (enterprise, account)) if product_name_key(row["name_key"]) == key}
    # Read the current resource spelling too; never rewrite an alias or SSOT.
    matches.update(row["id"] for row in db.execute(
        "SELECT id,name FROM v03_entities WHERE enterprise_id=? AND created_by=? AND acl='private_owner' AND entity_type='product'",
        (enterprise, account)) if product_name_key(row["name"]) == key)
    result = []
    for entity_id in sorted(matches):
        entity = repo._entity(account, enterprise, entity_id, db)
        if entity["can_select_for_ai"]:
            result.append({"id": entity_id, "name": entity["name"], "version": entity["version"]})
    return result


def product_selection_error(code, message, matches, *, requested_name=''):
    """Bounded owner-authorized choice; an offer never writes or binds SSOT."""
    error = CoreError(code, message, 409)
    error.details = {"kind": "product_selection_required", "reason": "selection_conflict" if code == "product_selection_conflict" else "multiple_matches",
                     "requested_name": requested_name, "matched_entities": matches[:5]}
    return error


def resolve_declared_product(repo, account, enterprise, name, db, selected=None):
    """An exact declared name cannot resolve through a shorter saved prefix."""
    matches = matching_owned_products(repo, account, enterprise, name, db)
    if len(matches) > 1:
        if selected and any(item['id'] == selected for item in matches):
            return selected
        raise product_selection_error("ambiguous_product", "Tên này khớp nhiều hồ sơ sản phẩm. Chị chọn đúng hồ sơ rồi trích lại; chưa ghi thay đổi.", matches, requested_name=name)
    return matches[0]["id"] if matches else None


def product_scope(intake, account, enterprise, text, db, selected=None, previous=None):
    """A sole saved product is never evidence that a new question concerns it.

    A declared unknown name creates a private draft, including when a stale
    client supplied its previous selection. It cannot inherit another product's
    facts, candidates or working answers.
    """
    if selected:
        entity = intake.repo.require_active_entity(account, enterprise, selected, db)
        if entity["entity_type"] != "product":
            raise CoreError("invalid_product", "Thông tin được chọn chưa phải sản phẩm.")
    lookup = named_profile_lookup(text)
    declared = None if lookup else declared_product_name(text)
    explicit = (resolve_declared_product(intake.repo, account, enterprise, declared, db, selected=selected) if declared
                else intake.resolve_product_reference(account, enterprise, text, db, selected=selected))
    if explicit and selected and explicit != selected:
        target = intake.repo.require_active_entity(account, enterprise, explicit, db)
        raise product_selection_error("product_selection_conflict", "Tên sản phẩm trong câu hỏi khác hồ sơ đang chọn. Chị chọn đúng hồ sơ rồi trích lại; chưa ghi thay đổi.",
            [{key: target[key] for key in ('id', 'name', 'version')}], requested_name=declared or target['name'])
    if lookup and not explicit:
        return None, {"state": "unbound_reference", "referenced_name": lookup, "confirmed": False}
    identity_asserted = any(item["field"] == "name" for item in extract_product_text(text))
    if declared and not explicit and identity_asserted:
        return None, {"state": "new_product_draft", "declared_name": declared, "confirmed": False}
    if declared and not explicit:
        # An unknown operational reference never creates an SSOT name proposal
        # and cannot inherit a different selected/previous product's facts.
        return None, {"state": "unbound_reference", "referenced_name": declared, "confirmed": False}
    if previous and not previous.get("product_binding") and not lookup and not declared:
        prior_lookup = named_profile_lookup(previous.get("text", ""))
        if prior_lookup:
            # Read warnings cannot be the authority for a later command. An
            # untyped legacy lookup must resolve consistently before its old
            # product/context can be inherited by a bare date/code follow-up.
            prior_target = intake.resolve_product_reference(account, enterprise, previous["text"], db, selected=selected)
            prior_product = (previous.get("product") or {}).get("id")
            if prior_target and selected and prior_target != selected:
                target = intake.repo.require_active_entity(account, enterprise, prior_target, db)
                raise product_selection_error("product_selection_conflict",
                    "Hồ sơ được nêu ở lượt trước khác lựa chọn hiện tại. Chị chọn đúng hồ sơ trước khi tiếp tục; chưa ghi thay đổi.",
                    [{key: target[key] for key in ("id", "name", "version")}], requested_name=prior_lookup)
            if not prior_target or not selected and prior_target != prior_product:
                return None, {"state": "unbound_reference", "referenced_name": prior_lookup,
                              "confirmed": False, "legacy_binding_rejected": True}
    chosen = explicit or selected
    if not chosen and previous:
        # An existing typed binding/lookup decision is not reparsed as a new
        # name assertion on every bare follow-up (including a selected list).
        prior_declared = (declared_product_name(previous.get("text", ""))
                          if not previous.get("product_binding") and not named_profile_lookup(previous.get("text", "")) else None)
        if (not previous.get("product_binding") and prior_declared
                and not intake.resolve_product_reference(account, enterprise, previous.get("text", ""), db)):
            return None, {"state": "new_product_draft", "declared_name": prior_declared,
                          "confirmed": False, "legacy_binding_rejected": True}
        prior = (previous.get("product") or {}).get("id")
        if prior and not prior.startswith("new_"):
            chosen = prior
        elif prior and (previous.get("product_binding") or {}).get("state") == "new_product_draft":
            return None, copy.deepcopy(previous["product_binding"])
    return chosen, {"state": ("explicit_confirmed" if identity_asserted else "exact_reference") if explicit else "selected_confirmed" if selected else
                             "conversation_confirmed" if chosen else "unbound",
                    "entity_id": chosen, "confirmed": bool(chosen)}


def scoped_business_context(context, product, market_codes=None):
    """Keep enterprise context plus only this product and its linked resources."""
    result = copy.deepcopy(context)
    product_id = (product or {}).get("id")
    markets = set(market_codes or [])
    selected = set()
    for entity in context["entities"]:
        kind = canonical_entity_type(entity["entity_type"])
        linked = bool(product_id and entity.get("parent_entity_id") == product_id)
        if (kind == "enterprise" or entity["id"] == product_id or linked and kind != "market_profile"
                or linked and (entity.get("values", {}).get("market_code") in markets)):
            selected.add(entity["id"])
    result["entities"] = [entity for entity in result["entities"] if entity["id"] in selected]
    result["fact_refs"] = [ref for ref in result.get("fact_refs", []) if ref.get("entity_id") in selected]
    result["context_hash"] = hashlib.sha256(json_text(result["fact_refs"]).encode()).hexdigest()
    return result


def reuse_metadata(context):
    return {"entity_count": len(context["entities"]), "fact_count": len(context.get("fact_refs", [])),
            "context_revision": context.get("context_revision"),
            "entity_ids": [entity["id"] for entity in context["entities"]],
            "used_confirmed_facts": bool(context.get("fact_refs"))}


def detect_export_topics(text):
    value = normalize(text)
    topics = []
    if "fda" in value or "dang ky co so" in value:
        topics.append("facility_registration")
    raw = str(text).casefold()
    if re.search(r"\bnhãn\b|\blabel(?:ling|ing)?\b", raw) or (re.search(r"\bnhan\b", raw)
            and re.search(r"\bsan pham\b|\bthuc pham\b|\bbao bi\b|\bfda\b|\bxuat khau\b", value)):
        topics.append("food_label")
    if "prior notice" in value or "thong bao truoc" in value:
        topics.append("prior_notice")
    if "chung nhan" in value or "certificate" in value:
        topics.append("certifications")
    return topics
