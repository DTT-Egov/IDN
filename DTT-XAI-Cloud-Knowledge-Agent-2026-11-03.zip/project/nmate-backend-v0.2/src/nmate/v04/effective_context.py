"""Owner decisions projected from durable state, never inferred from AI prose.

The original observations remain in the intake for audit. This read-only view
separates a resolved choice of profile value from a physical source discrepancy.
"""
from __future__ import annotations

import copy
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

from nmate.v03.core import CoreError
from nmate.v03.field_scope import canonical_entity_type, field_is_in_scope
from .extraction import typed_value


class ContextRecord(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Observation(ContextRecord):
    intake_id: str
    candidate_id: str
    entity_id: str
    field: str
    observed_value: Any
    status: str
    sources: list[dict[str, Any]]
    source_disagreement: dict[str, Any] | None


class OwnerDecision(ContextRecord):
    intake_id: str
    entity_id: str
    field: str
    status: Literal["committed", "superseded_by_current_ssot"]
    chosen_candidate_id: str
    committed_value: Any
    current_value: Any
    confirmed_at: str
    requires_choice_again: Literal[False] = False
    # A resolved profile choice does not certify the observed physical label.
    source_discrepancy_preserved: bool


class DraftField(ContextRecord):
    intake_id: str
    entity_id: str
    field: str
    selected_candidate_ids: list[str]
    effective_value: Any
    state: Literal["chosen_not_saved", "needs_choice", "excluded", "invalid_edit"]
    validation_error: str | None = None
    is_committed: Literal[False] = False


class EffectiveContext(ContextRecord):
    schema_version: Literal["owner_context_v1"] = "owner_context_v1"
    # Values in editable drafts can be used for advice, but never presented as
    # committed. History/observations cannot override either authority tier.
    authority_order: list[str] = Field(default_factory=lambda: [
        "active_editable_draft_for_proposed_work_only", "current_confirmed_ssot",
        "unresolved_source_observations", "historical_ai_advice"])
    confirmed_ssot: dict[str, Any]
    owner_decisions: list[OwnerDecision]
    active_editable_draft: list[DraftField]
    unresolved_candidates: list[Observation]
    archived_observations: list[Observation]


def _observation(item, candidate):
    return Observation(intake_id=item["id"], candidate_id=candidate["id"],
        entity_id=candidate["entity_id"], field=candidate["field"],
        observed_value=copy.deepcopy(candidate["value"]), status=candidate["status"],
        sources=copy.deepcopy(candidate.get("sources", [candidate.get("source", {})])),
        source_disagreement=copy.deepcopy(candidate.get("conflict")))


def project_owner_context(ssot, intakes, active, draft):
    """Project all linked intakes so a later text-only intake keeps decisions.

    Draft validation/ownership happens in ConversationService before this pure
    function. Old drafts of confirmed work are deliberately excluded.
    """
    # Older stored intakes/snapshots can still contain a wrongly scoped choice.
    # Keep their durable audit intact, but do not reintroduce it into an AI view
    # as an owner decision, draft or archived observation.
    ssot = copy.deepcopy(ssot)
    entity_types = {entity["id"]: entity["entity_type"] for entity in ssot["entities"]}
    for entity in ssot["entities"]:
        entity.pop("invalid_facts", None)
        entity["facts"] = [fact for fact in entity.get("facts", [])
                           if field_is_in_scope(entity["entity_type"], fact["field"])]
        entity["values"] = {field: value for field, value in entity["values"].items()
                            if field_is_in_scope(entity["entity_type"], field)}
    ssot["fact_refs"] = [ref for ref in ssot.get("fact_refs", [])
                         if ref["entity_id"] in entity_types and field_is_in_scope(entity_types[ref["entity_id"]], ref["field"])]

    def in_scope(candidate):
        entity_type = entity_types.get(candidate["entity_id"])
        if candidate["entity_id"] in {"new_product", "new_enterprise"}:
            entity_type = candidate["entity_id"].removeprefix("new_")
        return bool(entity_type and field_is_in_scope(entity_type, candidate["field"]) and
                    canonical_entity_type(candidate.get("entity_type", entity_type)) == canonical_entity_type(entity_type))

    current = {(e["id"], field): value for e in ssot["entities"] for field, value in e["values"].items()}
    # DF-048: intake clocks and list order do not establish fact causality.
    # The current assertion carries the owner-confirmed source identity. Keep
    # ambiguous legacy histories as observations instead of picking a winner.
    provenance = {(e["id"], fact["field"]): fact.get("source", {})
                  for e in ssot["entities"] for fact in e.get("facts", [])}
    decisions, archived, committed_candidates = {}, [], {}
    for item in intakes:
        partial = {candidate_id: decision["confirmed_at"]
                   for decision in item.get("partial_confirmations", [])
                   for candidate_id in decision.get("selected_candidate_ids", [])}
        for candidate in item.get("candidates", []):
            if not in_scope(candidate):
                continue
            if candidate["status"] in {"confirmed", "kept_current", "skipped", "already_known", "superseded", "dismissed", "legacy_archived"}:
                archived.append(_observation(item, candidate))
            if (item["status"] != "confirmed" and candidate["id"] not in partial) or candidate["status"] not in {"confirmed", "kept_current"}:
                continue
            key = (candidate["entity_id"], candidate["field"])
            value = current.get(key)
            committed = candidate.get("confirmed_value", candidate.get("current_value", candidate["value"]))
            discrepancy = any(c["entity_id"] == key[0] and c["field"] == key[1] and c["value"] != committed
                              for c in item["candidates"])
            choice = OwnerDecision(intake_id=item["id"], entity_id=key[0], field=key[1],
                status="committed" if value == committed else "superseded_by_current_ssot",
                chosen_candidate_id=candidate["id"], committed_value=copy.deepcopy(committed),
                current_value=copy.deepcopy(value), confirmed_at=partial.get(candidate["id"], item.get("confirmed_at", "")),
                source_discrepancy_preserved=discrepancy)
            committed_candidates.setdefault(key, []).append(choice)
    for key, choices in committed_candidates.items():
        source = provenance.get(key) or {}
        exact = [choice for choice in choices if source.get("intake_id") == choice.intake_id
                 and source.get("candidate_id") == choice.chosen_candidate_id]
        if len(exact) == 1:
            decisions[key] = exact[0]
        elif len(choices) == 1:
            choice = choices[0]
            if source.get("intake_id") or source.get("candidate_id"):
                # Same text/value from another assertion is not the same
                # decision; preserve this record as historical context only.
                choice = choice.model_copy(update={"status": "superseded_by_current_ssot"})
            decisions[key] = choice
    effective_draft, unresolved = [], []
    if active and active["status"] != "confirmed":
        draft = draft or {}
        groups = {}
        for candidate in active["candidates"]:
            if not in_scope(candidate):
                continue
            if candidate["status"] in {"candidate", "conflict"}:
                groups.setdefault((candidate["entity_id"], candidate["field"]), []).append(candidate)
        for (entity_id, field), candidates in groups.items():
            selected = [c for c in candidates if draft.get("selected", {}).get(c["id"], True)]
            state, value, error = "needs_choice", None, None
            if not selected:
                state = "excluded"
            elif len(selected) == 1:
                candidate = selected[0]
                choice = draft.get("choices", {}).get(candidate["id"])
                if choice == "current" and "current_value" in candidate:
                    state, value = "chosen_not_saved", copy.deepcopy(candidate["current_value"])
                elif candidate["status"] != "conflict" or choice == "incoming":
                    try:
                        value, _ = typed_value(candidate["base_field"], draft.get("edits", {}).get(candidate["id"], candidate["value"]),
                            candidate.get("unit"), candidate.get("period"))
                        state = "chosen_not_saved"
                    except CoreError as exc:
                        state, error = "invalid_edit", str(exc)
            effective_draft.append(DraftField(intake_id=active["id"], entity_id=entity_id, field=field,
                selected_candidate_ids=[c["id"] for c in selected], effective_value=value,
                state=state, validation_error=error))
            for candidate in candidates:
                observation = _observation(active, candidate)
                if state in {"needs_choice", "invalid_edit"} and candidate in selected:
                    unresolved.append(observation)
                elif candidate not in selected:
                    archived.append(observation.model_copy(update={"status": "excluded_in_editable_draft"}))
                else:
                    archived.append(observation.model_copy(update={"status": "chosen_in_editable_draft_not_saved"}))
    return EffectiveContext(confirmed_ssot={k: copy.deepcopy(v) for k, v in ssot.items() if k != "as_of"},
        owner_decisions=list(decisions.values()), active_editable_draft=effective_draft,
        unresolved_candidates=unresolved, archived_observations=archived).model_dump(mode="json")
