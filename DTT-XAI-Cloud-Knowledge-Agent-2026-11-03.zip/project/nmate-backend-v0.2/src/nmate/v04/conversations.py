"""Owner-private conversations link work, files and draft choices atomically."""
import copy
import json

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from .dialogue import address_text
from .product_binding import product_scope, product_binding_changed

SCHEMA = """
CREATE TABLE IF NOT EXISTS v04_conversations (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 owner_id TEXT NOT NULL REFERENCES v03_accounts(id), payload_json TEXT NOT NULL,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v04_conversation_owner ON v04_conversations(enterprise_id,owner_id,updated_at);
"""


class ConversationService:
    def __init__(self, intake):
        self.intake, self.repo = intake, intake.repo
        with self.repo.connection(write=True) as db:
            db.executescript(SCHEMA)

    def _owned(self, account, enterprise, conversation_id, db):
        self.repo.get_membership(account, enterprise, db)
        row = db.execute("SELECT payload_json FROM v04_conversations WHERE id=? AND enterprise_id=? AND owner_id=?",
                         (conversation_id, enterprise, account)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy cuộc trao đổi của tài khoản này.", 404)
        return json.loads(row[0])

    def _store(self, db, payload):
        payload["revision"] = payload.get("revision", 0) + 1
        payload["updated_at"] = now_iso()
        db.execute("UPDATE v04_conversations SET payload_json=?,updated_at=? WHERE id=?",
                   (json_text(payload), payload["updated_at"], payload["id"]))

    def _view(self, account, enterprise, payload, db):
        result = copy.deepcopy(payload)
        active = payload.get("active_intake_id")
        result["intake"] = self.intake._owned(account, enterprise, active, db) if active else None
        result["status"] = result["intake"]["status"] if active else "ready"
        # Confirmation text is derived solely from committed facts, including older work.
        for intake_id in payload["intake_ids"]:
            item = self.intake._owned(account, enterprise, intake_id, db)
            if item["status"] == "confirmed":
                count = sum(c["status"] == "confirmed" for c in item["candidates"])
                kept = sum(c["status"] == "kept_current" for c in item["candidates"])
                result["messages"].append({"id": "confirmed:" + intake_id, "role": "assistant",
                    "text": address_text(f"Đã ghi nhớ {count} dữ kiện bạn xác nhận." +
                                         (f" Giữ nguyên {kept} dữ kiện theo lựa chọn của bạn." if kept else ""),
                                         item.get("intent", {})),
                    "kind": "confirmation", "intake_id": intake_id, "created_at": item["confirmed_at"], "attachments": []})
        result["messages"].sort(key=lambda m: m["created_at"])
        result["model_calls"] = result.get("model_calls", 0)
        if active and hasattr(self.intake, "review_store"):
            # UI selections are private and revisioned separately from decisions.
            for intake_id in payload["intake_ids"]:
                row = db.execute("SELECT payload_json,ui_revision,base_workspace_revision FROM core_review_ui_drafts "
                                 "WHERE enterprise_id=? AND workspace_id=? AND actor_id=?",
                                 (enterprise, intake_id, account)).fetchone()
                if row:
                    result.setdefault("drafts", {})[intake_id] = {**json.loads(row["payload_json"]),
                        "ui_revision": row["ui_revision"], "base_review_revision": row["base_workspace_revision"]}
            from nmate.main.workspace_view import intake_workspace_view
            result["workspace_view"] = intake_workspace_view(self.repo, account, enterprise, result["intake"], db, result)
        return result

    def get(self, account, enterprise, conversation_id):
        with self.repo.connection() as db:
            return self._view(account, enterprise, self._owned(account, enterprise, conversation_id, db), db)

    def list(self, account, enterprise):
        with self.repo.connection() as db:
            self.repo.get_membership(account, enterprise, db)
            rows = db.execute("SELECT payload_json FROM v04_conversations WHERE enterprise_id=? AND owner_id=? ORDER BY updated_at DESC,id DESC LIMIT 50", (enterprise, account))
            result = []
            for row in rows:
                value = json.loads(row[0])
                current = self.intake._owned(account, enterprise, value["active_intake_id"], db)
                result.append({k: value.get(k) for k in ("id", "title", "created_at", "updated_at", "active_intake_id", "intake_ids", "latest_operation_id", "operation_ids")}
                              | {"status": current["status"]})
            return result

    def _draft(self, account, enterprise, payload, intake_id, draft, db):
        if intake_id not in payload["intake_ids"]:
            raise CoreError("invalid_draft", "Bản nháp không thuộc cuộc trao đổi này.", 403)
        item = self.intake._owned(account, enterprise, intake_id, db)
        if not isinstance(draft, dict) or set(draft) - {"selected", "edits", "choices", "base_review_revision", "ui_revision"}:
            raise CoreError("invalid_draft", "Bản nháp chưa đúng định dạng.")
        ids = {c["id"] for c in item["candidates"]}
        for key in ("selected", "edits", "choices"):
            values = draft.get(key, {})
            if not isinstance(values, dict) or set(values) - ids:
                raise CoreError("invalid_draft", "Bản nháp có dữ kiện không thuộc tài liệu này.")
            if key == "selected" and any(not isinstance(v, bool) for v in values.values()):
                raise CoreError("invalid_draft", "Lựa chọn nháp chưa đúng định dạng.")
            if key == "edits" and any(not isinstance(v, str) or len(v) > 2000 for v in values.values()):
                raise CoreError("invalid_draft", "Nội dung sửa nháp quá dài hoặc chưa đúng định dạng.")
            if key == "choices" and any(not isinstance(v, str) or v not in {"", "current", "incoming"} for v in values.values()):
                raise CoreError("invalid_draft", "Lựa chọn mâu thuẫn chưa đúng định dạng.")
        review = item.get("review") or {}
        base = draft.get("base_review_revision")
        if base is not None and (isinstance(base, bool) or not isinstance(base, int) or base != review.get("revision")):
            raise CoreError("WORKSPACE_CHANGED", "Nháp đã thay đổi ở lượt khác. Giữ phần đang sửa và đối chiếu bản mới trước khi lưu.", 409)
        if hasattr(self.intake, "review_store") and review.get("schema_version") == "workspace-review/2":
            previous = db.execute("SELECT ui_revision,payload_json FROM core_review_ui_drafts WHERE "
                                  "enterprise_id=? AND workspace_id=? AND actor_id=?", (enterprise, intake_id, account)).fetchone()
            revision = previous["ui_revision"] if previous else 0
            expected = draft.get("ui_revision")
            if expected is not None and (isinstance(expected, bool) or not isinstance(expected, int) or expected != revision):
                raise CoreError("UI_DRAFT_CHANGED", "Lựa chọn nháp đã thay đổi ở tab khác. Đọc lại trước khi lưu; chưa thay hồ sơ.", 409)
            stored = json.loads(previous["payload_json"]) if previous else {}
            pending = {c["id"] for c in item["candidates"] if c["status"] in {"candidate", "conflict"}}
            for key in ("selected", "edits", "choices"):
                values = {**stored.get(key, {}), **draft.get(key, {})}
                stored[key] = {candidate: value for candidate, value in values.items()
                               if candidate in pending or key == "selected" and value is False}
            payload["drafts"][intake_id] = {**stored, "ui_revision": revision + 1, "base_review_revision": review["revision"]}
        else:
            payload["drafts"][intake_id] = copy.deepcopy(draft)

    def _persist_ui_draft(self, account, enterprise, payload, intake_id, db):
        """Write command only; preflight _draft validation stays side-effect free."""
        draft = payload.get("drafts", {}).get(intake_id) or {}
        if "ui_revision" not in draft:
            return
        stored = {key: draft.get(key, {}) for key in ("selected", "edits", "choices")}
        db.execute("INSERT INTO core_review_ui_drafts VALUES(?,?,?,?,?,?,?) "
                   "ON CONFLICT(enterprise_id,workspace_id,actor_id) DO UPDATE SET "
                   "ui_revision=excluded.ui_revision,base_workspace_revision=excluded.base_workspace_revision,"
                   "payload_json=excluded.payload_json,updated_at=excluded.updated_at",
                   (enterprise, intake_id, account, draft["ui_revision"], draft["base_review_revision"], json_text(stored), now_iso()))

    def save_draft(self, account, enterprise, conversation_id, intake_id, draft, operation_id):
        with self.repo.connection(write=True) as db:
            payload = self._owned(account, enterprise, conversation_id, db)
            digest, prior = self.repo._operation(db, account, enterprise, "v04_conversation_draft", operation_id,
                                                {"id": conversation_id, "intake_id": intake_id, "draft": draft})
            if not prior:
                self._draft(account, enterprise, payload, intake_id, draft, db)
                self._persist_ui_draft(account, enterprise, payload, intake_id, db)
                self._store(db, payload)
                self.repo._save_operation(db, account, enterprise, "v04_conversation_draft", operation_id, digest, {"id": conversation_id})
            return self._view(account, enterprise, payload, db)

    def send(self, account, enterprise, text, attachments, operation_id, conversation_id=None, product_entity_id=None, draft=None, target_intake_id=None):
        if not isinstance(text, str) or len(text) > 4000 or not isinstance(attachments, list):
            raise CoreError("invalid_message", "Câu hỏi hoặc tài liệu chưa đúng định dạng.")
        if not text.strip() and not attachments:
            raise CoreError("invalid_message", "Bạn gửi câu hỏi hoặc tài liệu để tiếp tục.")
        with self.repo.connection(write=True) as db:
            self.repo.get_membership(account, enterprise, db)
            request = {"conversation_id": conversation_id, "text": text, "attachments": attachments,
                       "product_entity_id": product_entity_id, "draft": draft, "target_intake_id": target_intake_id}
            digest, prior = self.repo._operation(db, account, enterprise, "v04_conversation_send", operation_id, request)
            if prior:
                return self._view(account, enterprise, self._owned(account, enterprise, prior["id"], db), db)
            if hasattr(self, "validate_dispatch_snapshot"):
                self.validate_dispatch_snapshot(account, enterprise, db)
            if conversation_id:
                payload = self._owned(account, enterprise, conversation_id, db)
            else:
                stamp = now_iso()
                payload = {"id": new_id("conversation"), "title": text.strip()[:140] or "Trao đổi từ tài liệu",
                           "created_at": stamp, "updated_at": stamp, "messages": [], "intake_ids": [], "drafts": {},
                           "active_intake_id": None, "operation_ids": []}
            if len(payload["messages"]) >= 200:
                raise CoreError("conversation_limit", "Cuộc trao đổi đã dài. Bạn có thể mở cuộc chat mới; hồ sơ và bản nháp cũ vẫn được giữ.")
            if target_intake_id:
                if not conversation_id or target_intake_id not in payload["intake_ids"]:
                    raise CoreError("invalid_context", "Phần đang rà không thuộc cuộc trao đổi này.", 403)
                payload["active_intake_id"] = target_intake_id
            if draft:
                if not isinstance(draft, dict):
                    raise CoreError("invalid_draft", "Bản nháp chưa đúng định dạng.")
                if set(draft) - {"intake_id", "selected", "edits", "choices", "base_review_revision", "ui_revision"}:
                    raise CoreError("invalid_draft", "Bản nháp chưa đúng định dạng.")
                if not conversation_id and draft.get("intake_id"):
                    legacy = self.intake._owned(account, enterprise, draft["intake_id"], db)
                    payload["intake_ids"].append(legacy["id"])
                    payload["active_intake_id"] = legacy["id"]
                    payload["title"] = legacy["text"][:140] or "Trao đổi từ tài liệu"
                    payload["messages"].append({"id": "legacy:" + legacy["id"], "role": "user", "text": legacy["text"],
                        "created_at": legacy["created_at"], "intake_id": legacy["id"], "attachments": legacy["attachments"], "kind": "message"})
                self._draft(account, enterprise, payload, draft.get("intake_id"), {k: v for k, v in draft.items() if k != "intake_id"}, db)
                self._persist_ui_draft(account, enterprise, payload, draft.get("intake_id"), db)
            previous = self.intake._owned(account, enterprise, payload["active_intake_id"], db) if payload["active_intake_id"] else None
            # A document instruction's product mention is not an owner target
            # selection. Defer its identity to the parsed file/declarations in
            # Intake.prepare; preserve only an explicit caller-selected ID.
            chosen_product, binding = product_scope(self.intake, account, enterprise, "" if attachments else text, db,
                                                    product_entity_id, previous if not attachments else None)
            changed_product = product_binding_changed(previous, chosen_product, binding)
            if previous and previous["status"] != "confirmed" and not attachments and not changed_product:
                item = self.intake.clarify(account, enterprise, previous["id"], text, operation_id, db=db)
            else:
                product = chosen_product
                if not product and binding["state"] not in {"new_product_draft", "unbound_reference"} and not attachments and previous and previous.get("product") and not previous["product"]["id"].startswith("new_"):
                    product = previous["product"]["id"]
                item = self.intake.prepare(account, enterprise, text, attachments, operation_id, product, db=db)
                inherited = copy.deepcopy(previous.get("intent")) if previous and not attachments else None
                if changed_product and inherited:
                    inherited.pop("working_answers", None)
                item = self.intake.refresh_dialogue(account, enterprise, item["id"], text, inherited, db=db)
            if item["id"] not in payload["intake_ids"]:
                payload["intake_ids"].append(item["id"])
            payload["active_intake_id"] = item["id"]
            payload["latest_operation_id"] = operation_id
            payload["operation_ids"].append(operation_id)
            stamp = now_iso()
            payload["messages"].append({"id": new_id("message"), "role": "user", "text": text,
                "intake_id": item["id"], "created_at": stamp, "attachments": item["attachments"] if attachments else [], "kind": "message"})
            unread = any(a.get("extraction_status") == "stored_not_read" for a in item["attachments"])
            answer = "Mình chưa đọc được ảnh này trong chế độ giả lập. Ảnh được giữ riêng; chưa có dữ kiện từ ảnh được ghi vào hồ sơ." if unread else (
                "Bạn muốn mình giúp việc gì từ những tài liệu này?" if item["intent"]["primary"] == "needs_clarification" else
                "Mình hiểu bạn muốn " + item["intent"]["primary_label"].lower() + ".")
            answer = item.get("assistant_text", answer)
            payload["messages"].append({"id": new_id("message"), "role": "assistant", "text": answer,
                "intake_id": item["id"], "created_at": now_iso(), "attachments": [], "kind": "message"})
            if hasattr(self, "decorate_conversation"):
                self.decorate_conversation(payload)
            if not conversation_id:
                db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (payload["id"], enterprise, account, json_text(payload), payload["created_at"], payload["updated_at"]))
            self._store(db, payload)
            self.repo._save_operation(db, account, enterprise, "v04_conversation_send", operation_id, digest, {"id": payload["id"]})
            return self._view(account, enterprise, payload, db)
