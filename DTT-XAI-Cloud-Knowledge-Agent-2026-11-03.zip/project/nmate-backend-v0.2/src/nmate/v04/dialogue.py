"""Bounded, explicit mock dialogue state. Working answers never become SSOT facts."""
from contextvars import ContextVar
from datetime import date, datetime, timedelta, timezone
import re
import unicodedata

from nmate.v03.markets import detect_markets, get_market
from nmate.v03.intent_plan import scoped_working_inputs
from .extraction import normalize
from .product_binding import detect_export_topics

SELECTED_TASK_HINT = ContextVar("selected_local_dialogue_task_hint", default=None)
PREFERRED_ADDRESS = ContextVar("local_dialogue_preferred_address", default=None)

LABELS = {"digitize_operations": "Số hóa bán hàng và tồn kho", "export_readiness": "Chuẩn bị năng lực xuất khẩu",
          "improve_packaging": "Cải thiện bao bì sản phẩm", "understand_business": "Cập nhật hồ sơ doanh nghiệp",
          "needs_clarification": "Cần làm rõ mục tiêu"}
FINANCING_UNSUPPORTED = ("Bản hiện tại chưa hỗ trợ tư vấn vay vốn, tín dụng hoặc huy động vốn. "
                         "Mình chưa thể đánh giá điều kiện vay hay đề xuất khoản vay cho bạn.")
RESTOCKING_PATTERN = (r"\b(?:nhap (?:them|bo sung) (?:hang|san pham|tra|mut|bot)|"
                      r"dat (?:them|bo sung) (?:hang|san pham|tra|mut|bot)|dat hang bo sung|"
                      r"bo sung hang|luong dat hang|(?:nhap|dat) them(?=\s*(?:khong|nua)?$)|"
                      r"lay them [a-z ]{0,40}ve ban)\b")
RESTOCKING_KEYS = frozenset({"available_quantity", "recent_sales_quantity", "sales_period", "sales_period_kind",
                            "supplier_lead_days", "quantity_unit", "product_code", "available_quantity_unit",
                            "recent_sales_quantity_unit"})
CALENDAR_SALES_MONTH = r"thang\s+(0?[1-9]|1[0-2])(?!\d)(?:\s*(?:/|nam)\s*(20\d{2}))?"
COUNT_UNIT_PATTERN = r"hop|goi|tui|chai|cai|san pham|don vi|kg"
COUNT_UNITS = {"hop": "hộp", "goi": "gói", "tui": "túi", "chai": "chai", "cai": "cái",
               "san pham": "sản phẩm", "don vi": "đơn vị", "kg": "kg"}
REPORTED_STOCK_KEYS = frozenset({"reported_stock_quantity", "reported_stock_unit", "reported_stock_quote"})


def _reported_stock_statement(text):
    """One quoted stock observation, never sellable stock or a closing balance.

    Sales period/unit do not qualify this quantity. Explicit opening/book/physical
    counts belong to other roles, and targets, hypotheses and multiple quantities
    must not be silently collapsed into a single observation.
    """
    units = '|'.join(sorted({*COUNT_UNITS.keys(), *COUNT_UNITS.values()}, key=len, reverse=True))
    matches = list(re.finditer(r"\b(?:tồn|ton)(?: kho)?\s*(?:còn|con|là|la|:)?\s*"
        r"(?P<quantity>\d{1,12}(?:[.,]\d{1,6})?)\s*"
        r"(?P<unit>" + units + r")\b", text, re.IGNORECASE))
    if len(matches) != 1:
        return None
    match = matches[0]
    prefix = normalize(re.split(r"[;!?\n]|(?<!\d)\.(?!\d)", text[:match.start()])[-1])
    if re.search(r"\b(?:khong|chua|muon|can|dinh|se|co the)\s*$|"
                 r"\b(?:du kien|du bao|muc tieu|ke hoach|gia su|vi du|neu)\b(?:(?![,;.!?]).){0,75}$", prefix):
        return None
    return {"reported_stock_quantity": float(match['quantity'].replace(',', '.')),
            "reported_stock_unit": COUNT_UNITS[normalize(match['unit'])],
            "reported_stock_quote": match[0]}


def _sales_calendar_period(value, *, reply_only=False, prefer_last=False):
    matches = list(re.finditer(r"\b" + CALENDAR_SALES_MONTH + r"\b", value)) if not reply_only else []
    match = (re.fullmatch(r"(?:(?:theo|trong)\s+)?" + CALENDAR_SALES_MONTH + r"[.!?]?", value.strip())
             if reply_only else matches[-1 if prefer_last else 0] if matches else None)
    if not match:
        return None
    return {"sales_period": "tháng " + str(int(match[1])) + ("/" + match[2] if match[2] else ""),
            "sales_period_kind": "calendar_month"}


def _sales_statement(text):
    """One explicit actual-sales count, with a period from its own clause.

    Working inputs are neither an aggregate report nor SSOT assertions. Do not
    collapse multiple counts, forecasts, targets or returns into an actual sale.
    Calendar periods retain their identity; September is not a recurring month.
    """
    value = normalize(text)
    matches = list(re.finditer(r"\bban\s*(?:duoc|khoang|trung binh)?\s*"
        r"(?P<quantity>\d{1,12}(?:[.,]\d{1,6})?)\s*"
        r"(?P<unit>" + COUNT_UNIT_PATTERN + r")\b", value))
    if len(matches) != 1:
        return None
    sale = matches[0]
    # A decimal point belongs to the count, not to a new sentence.
    sentence_boundary = r"[;!?\n]|(?<!\d)\.(?!\d)|\bnhung\b"
    other_role = r"\b(?:nha cung cap|thoi gian giao|thoi gian nhan|giao|nhan hang|dat|nhap)\b"
    boundary = sentence_boundary + "|" + other_role
    before = re.split(sentence_boundary, value[:sale.start()])[-1]
    if re.search(other_role, before):
        # A supplier clause before a comma can contain its own duration.
        # Only text after its explicit connector may qualify this sale.
        parts = re.split(r",|\b(?:va|con)\b", before)
        before = parts[-1] if len(parts) > 1 and not re.search(other_role, parts[-1]) else ""
    after = re.split(boundary, value[sale.end():], maxsplit=1)[0]
    target_prefix = re.sub(r"\b(?:thang\s+\d{1,2}(?:\s*(?:/|nam)\s*20\d{2})?|"
                           r"(?:moi|mot)\s+(?:ngay|tuan|thang))\b", " ", before)
    if (re.search(r"\b(?:khong|chua|muon|can|dinh|se|co the)\s*$", target_prefix)
            or re.search(r"\b(?:du kien|du bao|muc tieu|ke hoach|gia su|vi du|neu)\b"
                         r"(?:(?![,;.!?]).){0,75}$", before)):
        return None
    if re.search(r"\b(?:tra lai|hoan tra|bi tra|huy)\b", after):
        return None
    result = {"recent_sales_quantity": float(sale["quantity"].replace(",", "."))}
    if sale["unit"]:
        result["quantity_unit"] = result["recent_sales_quantity_unit"] = COUNT_UNITS[sale["unit"]]
    period_clause = before + " " + after
    calendar = _sales_calendar_period(after) or _sales_calendar_period(before, prefer_last=True)
    before_calendar = _sales_calendar_period(before, prefer_last=True)
    after_calendar = _sales_calendar_period(after)
    if before_calendar and after_calendar and before_calendar != after_calendar:
        calendar = None
    if calendar:
        result.update(calendar)
    elif recurring := re.search(r"(?:\b(?:moi|mot)\s+|/\s*)(ngay|tuan|thang)\b", period_clause):
        result["sales_period"] = {"ngay": "ngày", "tuan": "tuần", "thang": "tháng"}[recurring[1]]
        result["sales_period_kind"] = "recurring"
    elif duration := re.search(r"\btrong\s+(\d{1,3})\s+ngay\b", period_clause):
        result["sales_period"] = duration[1] + " ngày"
        result["sales_period_kind"] = "duration"
    return result


def address_term(text, previous=None):
    """Remember only a self-declared form of address, never infer it from a name."""
    # Preserve accents: 'chỉ muốn' and 'có cần' are not declarations of 'chị'/'cô'.
    value = unicodedata.normalize("NFC", text).casefold()
    for term in ("chị", "anh", "cô", "chú", "bác", "em"):
        if (re.search(r"\bgọi\s+(?:tôi|mình|em)\s+là\s+" + term + r"\b", value)
                or re.search(r"\b(?:cơ sở|doanh nghiệp|công ty|sản phẩm|cửa hàng)\s+của\s+" + term + r"\b", value)
                or re.search(r"(?:^|[.!?;]\s*)" + term +
                             r"\s+(?:muốn|cần|đang|vừa|sẽ|bán|sản xuất|kinh doanh|quản lý|hỏi|gửi|báo|nhờ|kiểm|cho|nên|tính|nhập|đặt|có nên)\b", value)
                or re.search(r"(?:^|[.!?;]\s*)" + term +
                             r"\s+có\s+(?:cơ sở|doanh nghiệp|công ty|sản phẩm|lô hàng|trà|mứt|bột|cửa hàng|xưởng)\b", value)
                or re.search(r"\b(?:giúp|cho)\s+" + term + r"\b", value)):
            return term
    return PREFERRED_ADDRESS.get() or (previous or {}).get("address_term", "bạn")


def address_text(text, intent):
    """Adapt server-authored templates only; callers must not pass user/source quotes."""
    term = intent.get("address_term", "bạn")
    if term == "bạn":
        return text
    text = re.sub(r"Anh/chị|Bạn", lambda _match: term.capitalize(), text)
    return re.sub(r"\banh/chị\b|\bbạn\b", lambda _match: term, text)


def _inventory_followup(value, previous, slots):
    answers = slots or previous.get("working_answers", {})
    waiting = previous.get("focus") == "inventory_accuracy" or all(
        key in answers for key in ("book_quantity", "physical_quantity"))
    if not waiting:
        return False
    # Match the requested fields, allowing punctuation and ordinary courtesy
    # words, rather than treating the noun 'sản phẩm' as a new profile task.
    remainder, count = re.subn(
        r"(?:(?:ngay kiem ke|kiem ke ngay|ngay)\s*(?:la\s*)?)?\d{1,2}/\d{1,2}/20\d{2}", " ", value)
    remainder, code_count = re.subn(r"\bma\s+(?:san pham\s+)?[:：]?\s*[a-z0-9][a-z0-9._/-]*\b", " ", remainder)
    if count and not code_count:
        remainder, code_count = re.subn(r"\b[a-z][a-z0-9._/-]*\d[a-z0-9._/-]*\b", " ", remainder)
    return bool(count or code_count) and bool(re.fullmatch(
        r"(?:(?:va|la|cua|chi|anh|em|toi|minh|nhe|a|day|do|giup|cho)|\s)*", remainder))


def _positive(text):
    # A rejected clause cannot win merely because it contains a strong keyword.
    clauses = re.split(r"[,.;!?\n]|\b(?:nhung|bay gio|gio|thay vao do)\b", normalize(text))
    return " ".join(" ".join(c for c in clauses if not re.search(
        r"\b(?:khong|chua)\s+(?:muon|can|dinh|tiep tuc)\b|\bkhong\b.*\bnua\b|\bbo qua\b", c)).split())


def _restocking_request(value):
    for match in re.finditer(RESTOCKING_PATTERN, value):
        prefix = value[max(0, match.start()-80):match.start()]
        if re.search(r"\b(?:khong|chua)\s*(?:(?:can|muon|dinh)\s*)?$|\b(?:da|vua)\s*$", prefix):
            continue
        # Recording an already received delivery in a workbook is not a new
        # replenishment decision, even though both use the verb 'nhập'.
        if re.match(r"\s+(?:vao|len)\s+(?:excel|so|phan mem|he thong)\b", value[match.end():]):
            continue
        return True
    return False


def _restocking_followup(value, previous):
    return (previous or {}).get("focus") == "restocking_planning" and bool(re.search(
        r"(?:ton kho|hang con|con ton|con)\s*(?:la|:)?\s*\d|"
        r"ban\s*(?:duoc|khoang|trung binh)?\s*\d|"
        r"(?:giao|nhan hang|thoi gian giao)\s*(?:sau|trong|la|khoang)?\s*\d", value))


PACKAGING_SUBJECT = r"\b(?:bao bi|dong goi|nhan san pham)\b"
PACKAGING_ACTION = (r"(?:cai thien|thiet ke|tu van|toi uu|dieu chinh|lam lai|danh gia|ra soat|"
                    r"huong dan|kiem tra|gop y|nhan xet|xem lai|doi|thay)")


def _packaging_request(text):
    """An action/question has a different role from an observed field value.

    Work on clauses before joining normalized text: a request in another
    clause must not turn ``bao bì: túi zip`` into a packaging instruction.
    This chooses a bounded workflow only; it never confirms a field or gives
    a packaging/regulatory conclusion.
    """
    # Keep the accent distinction before comparison normalization: receiving
    # a product (nhận) is not a request to design its label (nhãn).
    comparison_text = re.sub(r"\bnhận\s+sản\s+phẩm\b", "", unicodedata.normalize("NFC", text).casefold())
    for clause in re.split(r"[,.;!?\n]|\b(?:nhung|bay gio|gio|thay vao do)\b", normalize(comparison_text)):
        value = _positive(clause)
        if not value or re.search(r"\b(?:khong|chua)\s+(?:(?:can|muon|dinh)\s+)?(?:" + PACKAGING_ACTION + r"|dong goi)\b", value):
            continue
        if re.search(r"\bthiet ke\s+hop\b", value) and not re.search(r"\b(?:da|vua|dang)\s+thiet ke\s+hop\b", value):
            return True
        if not re.search(PACKAGING_SUBJECT, value):
            continue
        for action in re.finditer(r"\b" + PACKAGING_ACTION + r"\b"
                                  r"(?:(?!\b(?:ho so|ghi nho|luu|cap nhat)\b).){0,100}" + PACKAGING_SUBJECT, value):
            if not re.search(r"\b(?:da|vua|dang)\s*$", value[:action.start()]):
                return True
        if re.search(r"\b(?:muon|can|nen)\s+(?:(?:cach|lam|duoc|de|mot|loai)\s+){0,3}" + PACKAGING_SUBJECT, value):
            return True
        if re.search(PACKAGING_SUBJECT + r".{0,100}\b(?:the nao|nhu the nao|co phu hop|co can|nen|can ghi(?!\s+nho)|ghi gi|can gi|bao nhieu)\b", value):
            return True
        if re.search(PACKAGING_SUBJECT + r"\s+can\s+(?!(?:ghi nho|luu|cap nhat|bo sung)\b)\S", value):
            return True
        if (re.search(r"\b(?:co nen|co can|nen dung|nen chon)\b", value)
                or re.search(PACKAGING_SUBJECT + r"\s+nao\b", value)
                or re.search(PACKAGING_SUBJECT + r".{0,100}\bco\b.{1,100}\bkhong\b", value)):
            return True
    return False


def interpret(text, previous=None, slots=None, task_hint=None):
    task_hint = task_hint or SELECTED_TASK_HINT.get()
    value = _positive(text)
    # Preserve accents long enough to distinguish Nhật from nhất and Mỹ from mỹ phẩm.
    market_raw = re.sub(r"\bnhất\b|\bmỹ phẩm\b", "", unicodedata.normalize("NFC", text).casefold())
    market_text = re.sub(r"\b(?:cap nhat|thong nhat|duy nhat|thu nhat|tot nhat|nhat ky|chu nhat)\b", "", _positive(market_raw))
    detected = detect_markets(market_text)
    codes = [code for code in detected if code in {"US", "DE", "JP"}]
    unresolved_market = any(code in {"OTHER", "EU"} for code in detected)
    primary, focus = None, None
    sale = _sales_statement(text)
    unsupported = bool(re.search(r"\b(?:vay von|vay ngan hang|goi vay|tin dung|huy dong von|tiep can von)\b", value))
    export_topics = detect_export_topics(text)
    # Explicit profile maintenance wins over incidental mentions of Excel/tools.
    if re.search(r"(?:cap nhat|ghi nho|luu|bo sung|doc|kiem tra|doi chieu)\s+(?:lai\s+)?ho so|chi.*ho so|"
                 r"(?:cap nhat|ghi nho|luu|bo sung)\s+.*(?:doanh thu|so lieu|so lao dong|nhan vien|thong tin doanh nghiep)", value):
        primary = "understand_business"
    if re.search(r"(?:so hoa|chuyen doi so|giam sai lech|doi chieu ton|kiem ke|tong hop.*ban hang|bao cao.*ban hang)", value):
        primary = "digitize_operations"
    packaging_request = _packaging_request(text)
    if packaging_request:
        primary = "improve_packaging"
    if re.search(r"xuat khau|thi truong|fda|nhap khau", value):
        primary = "export_readiness"
    if export_topics and (codes or previous and previous.get("primary") == "export_readiness"):
        primary = "export_readiness"
    if primary is None and codes and (task_hint == "export_research" or re.search(
            r"\b(?:muon|can|dinh)\s+(?:di|sang|gui|ban)\b|\b(?:gui|ban)\s+(?:sang|vao|tai)\b", value)):
        primary = "export_readiness"
    # A restrictive instruction is intentional, even with another domain mentioned.
    profile_only = re.search(r"chi\s+(?:(?:muon|can)\s+)?(?:cap nhat|ghi nho|doc|luu).*ho so", value)
    if (re.search(r"sai lech.*ton|kiem ke|doi chieu ton|ton kho.*sai lech", value)
            or re.search(r"(?:ton (?:tren )?so|tren so)\s*(?:la|:)?\s*\d", value)
            and re.search(r"(?:kiem dem|(?:dem )?thuc te)\s*(?:con|la|:)?\s*\d", value)):
        primary, focus = "digitize_operations", "inventory_accuracy"
    elif re.search(r"tong hop.*ban hang|bao cao.*ban hang|ban hang.*(?:tong hop|bao cao)", value):
        primary, focus = "digitize_operations", "sales_reporting"
    elif re.search(r"ban hang|ton kho|quan ly", value) and primary is None:
        primary = "digitize_operations"
    if sale is not None and primary in {None, "digitize_operations"} and focus is None:
        primary = "digitize_operations"
        focus = "restocking_planning" if (previous or {}).get("focus") == "restocking_planning" else "sales_reporting"
    if (primary is None and (previous or {}).get("focus") in {"sales_reporting", "restocking_planning"}
            and _sales_calendar_period(value, reply_only=True)):
        primary, focus = "digitize_operations", previous["focus"]
    if primary in {None, "digitize_operations"} and focus is None and (previous or {}).get("focus") == "sales_reporting" and _reported_stock_statement(text):
        primary, focus = "digitize_operations", "sales_reporting"
    if (_restocking_request(value) or
            primary in {None, "digitize_operations"} and _restocking_followup(value, previous)
            and not re.search(r"kiem ke|kiem dem|sai lech|doi chieu ton|ton (?:tren )?so", value)):
        primary, focus = "digitize_operations", "restocking_planning"
    operation_topics = []
    if primary == "digitize_operations":
        if focus == "restocking_planning":
            operation_topics.append("restocking_planning")
        elif focus == "sales_reporting" or re.search(r"\bban hang\b|\bdoanh so\b", value):
            operation_topics.append("sales_reporting")
        if focus != "restocking_planning" and re.search(r"\bton kho\b|\bkiem ke\b|\bton (?:tren )?so\b", value):
            operation_topics.append("inventory_accuracy")
        if focus is None and operation_topics:
            focus = operation_topics[0] if len(operation_topics) == 1 else "sales_inventory_overview"
    if primary is None and previous and previous.get("primary") != "needs_clarification":
        # A short reply belongs to the waiting task. An unrelated question is clarified.
        if (re.fullmatch(r"(?:co roi|chua co|chua|co|roi|khong co|khong)(?: a| nhe)?", value)
                or re.search(r"(?:ton (?:tren )?so|kiem dem|kiem ke|thuc te)\s*(?:la|:)?\s*\d", value)
                or _inventory_followup(value, previous, slots)
                or previous.get("focus") == "inventory_accuracy" and (
                    re.fullmatch(r"(?:(?:ngay|ngay kiem ke|kiem ke ngay)\s+)?\d{1,2}/\d{1,2}/20\d{2}(?:\s+(?:ma\s+(?:san pham\s+)?)?[a-z][a-z0-9._/-]*)?", value)
                    or re.fullmatch(r"ma\s+(?:san pham\s+)?[a-z0-9._/-]+", value)
                    or re.fullmatch(r"[\d\s/.,]+(?:\s*(?:hop|kg|gam))?", value))
                or previous.get("focus") == "sales_reporting" and re.fullmatch(
                    r"(?:theo\s+)?(?:ngay|thang)(?:\s+(?:va|theo)\s+(?:san pham|kenh|kenh ban))?", value)
                or previous.get("primary") == "export_readiness" and codes):
            primary, focus = previous["primary"], previous.get("focus")
            if _inventory_followup(value, previous, slots):
                primary, focus = "digitize_operations", "inventory_accuracy"
    # A mentioned packaging field supplies profile input, not a redesign goal.
    # Apply this fallback after explicit workflows and waiting-task replies so
    # a field mention cannot suppress a real export/operation request.
    primary = primary or ("understand_business" if re.search(
        r"ho so|doanh nghiep|san pham|doc anh|doc excel|" + PACKAGING_SUBJECT, value) else "needs_clarification")
    if previous and primary == previous.get("primary") and focus is None:
        focus = previous.get("focus")
    if profile_only:
        primary, focus = "understand_business", None
    if unsupported:
        primary, focus = "needs_clarification", None
    if primary == "export_readiness" and not codes and previous and not unresolved_market and not re.search(
            r"khong.*(?:my|duc|nhat)|(?:chua|khong)\s+(?:chon|xac dinh).*thi truong", normalize(text)):
        codes = previous.get("market_codes", [])
    if primary != "export_readiness":
        codes = []
    term = address_term(text, previous)
    return {"primary": primary, "primary_label": LABELS[primary], "focus": focus, "market_codes": codes,
            "operation_topics": operation_topics if primary == "digitize_operations" else [],
            "market_clarification_needed": unresolved_market if primary == "export_readiness" else False,
            "objectives": [] if primary == "needs_clarification" else [{"id": primary, "title": LABELS[primary]}],
            "address_term": term, "unsupported_request": "financing" if unsupported else None,
            "unsupported_reason_vi": address_text(FINANCING_UNSUPPORTED, {"address_term": term}) if unsupported else None,
            "export_question_topics": export_topics if primary == "export_readiness" else [],
            "interpretation_mode": "bounded_no_paid_calls"}


def working_answers(text, intent, previous=None):
    result = scoped_working_inputs(intent, previous)
    value = normalize(text)
    if intent.get("focus") == "restocking_planning":
        # These are quoted working inputs, not confirmed product/financial
        # facts. Never reuse a stock-count discrepancy as available inventory.
        result = {key: item for key, item in result.items() if key in RESTOCKING_KEYS}
        if "available_quantity" in result and result.get("quantity_unit"):
            # Compatibility for an old stock observation whose global unit
            # predates role-qualified units. A later sales unit cannot set it.
            result.setdefault("available_quantity_unit", result["quantity_unit"])
        for key, pattern in (
            ("available_quantity", r"(?:ton kho|hang con|con ton|con)\s*(?:la|:)?\s*(\d+(?:[.,]\d+)?)"),
            ("supplier_lead_days", r"(?:giao|nhan hang|thoi gian giao)\s*(?:sau|trong|la|khoang)?\s*(\d{1,3})\s*ngay\b"),
        ):
            if match := re.search(pattern, value):
                result[key] = float(match[1].replace(",", "."))
                if key == "available_quantity":
                    unit = re.match(r"\s*(" + COUNT_UNIT_PATTERN + r")\b", value[match.end():])
                    if unit:
                        result["available_quantity_unit"] = result["quantity_unit"] = COUNT_UNITS[unit[1]]
                    else:
                        result.pop("available_quantity_unit", None)
                        result.pop("quantity_unit", None)
        if (sale := _sales_statement(text)) is not None:
            # A new count without a period cannot inherit another calendar
            # month's identity. An established recurring rate keeps its grain.
            if not sale.get("sales_period") and result.get("sales_period_kind") == "calendar_month":
                result.pop("sales_period", None)
                result.pop("sales_period_kind", None)
            result.update({key: item for key, item in sale.items() if key != "quantity_unit"})
            if "available_quantity" not in result:
                result["quantity_unit"] = sale["quantity_unit"]
        elif (calendar := _sales_calendar_period(value, reply_only=True)) and not result.get("sales_period"):
            result.update(calendar)
        return result
    if intent.get("focus") == "inventory_accuracy":
        prior_inventory = any(key in result for key in ("book_quantity", "physical_quantity"))
        result = {key: item for key, item in result.items() if key in {
            "book_quantity", "physical_quantity", "quantity_unit", "count_date", "count_date_phrase",
            "count_date_proposed", "product_code"}}
        if not prior_inventory:
            # A sales/stock planning unit cannot qualify a new count. The
            # gateway stays closed; normalize the producer's working scope.
            result.pop("quantity_unit", None)
        for key, pattern in [("book_quantity", r"(?:ton\s+(?:tren\s+)?so|tren so|ton so)\s*(?:la|:)?\s*(\d+(?:[.,]\d+)?)"),
                             ("physical_quantity", r"(?:kiem dem|kiem ke|thuc te)\s*(?:con|la|:)?\s*(\d+(?:[.,]\d+)?)")]:
            match = re.search(pattern, value)
            if match:
                result[key] = float(match[1].replace(",", "."))
        if "hom qua" in value:
            # Preserve the relative phrase for owner confirmation; don't pretend a date was confirmed.
            result["count_date_proposed"] = (datetime.now(timezone(timedelta(hours=7))).date() - timedelta(days=1)).isoformat()
            result["count_date_phrase"] = "hôm qua"
        match = re.search(r"\b(\d{1,2})/(\d{1,2})/(20\d{2})\b", text)
        if match:
            try:
                result["count_date"] = date(int(match[3]), int(match[2]), int(match[1])).isoformat()
            except ValueError:
                pass
        code = re.search(r"\b(?:mã|ma)\s+(?:(?:sản phẩm|san pham)\s+)?[:：]?\s*([A-Za-z0-9][A-Za-z0-9._/-]{1,63})\b", text, re.IGNORECASE)
        if code is None:
            code = re.search(r"\d{1,2}/\d{1,2}/20\d{2}[\s,;]+([A-Za-z][A-Za-z0-9._/-]*\d[A-Za-z0-9._/-]*)\b", text)
        if code:
            result["product_code"] = code[1]
        if re.search(r"\bhop\b", value):
            result["quantity_unit"] = "hộp"
    if intent.get("focus") == "sales_reporting":
        result = {key: item for key, item in result.items() if key in RESTOCKING_KEYS | REPORTED_STOCK_KEYS | {"report_period", "report_dimension"}
                  and key not in {"available_quantity", "available_quantity_unit", "supplier_lead_days"}}
        if stock := _reported_stock_statement(text):
            result.update(stock)
        if (sale := _sales_statement(text)) is not None:
            if not sale.get("sales_period"):
                for key in ("sales_period", "sales_period_kind", "report_period"):
                    result.pop(key, None)
            result.update(sale)
            if sale.get("sales_period"):
                result["report_period"] = sale["sales_period"]
        elif re.search(r"\btheo\s+thang\b", value) or re.fullmatch(r"thang(?:\s+va\s+(?:san pham|kenh(?: ban)?))?", value):
            calendar = _sales_calendar_period(value, reply_only=True)
            if calendar and not result.get("sales_period"):
                result.update(calendar)
                result["report_period"] = calendar["sales_period"]
            else:
                result["report_period"] = "tháng"
        elif re.search(r"\btheo\s+ngay\b", value) or re.fullmatch(r"ngay(?:\s+va\s+(?:san pham|kenh(?: ban)?))?", value):
            result["report_period"] = "ngày"
        elif (calendar := _sales_calendar_period(value, reply_only=True)) and not result.get("sales_period"):
            result.update(calendar)
            result["report_period"] = calendar["sales_period"]
        if "san pham" in value:
            result["report_dimension"] = "sản phẩm"
        elif "kenh" in value:
            result["report_dimension"] = "kênh bán"
    return result


def business_values(context, product):
    selected_id = product.get("id") if product else None
    return {k: v for e in context["entities"] if e["entity_type"] == "enterprise" or e["id"] == selected_id
            for k, v in e["values"].items()}


def business_plan(intent, values):
    if intent.get("unsupported_request"):
        return []
    primary, slots = intent["primary"], intent.get("working_answers", {})
    if primary == "digitize_operations" and intent.get("focus") == "restocking_planning":
        return [{"id": "restocking_stock", "title": "Xác nhận lượng tồn có thể bán của đúng mã sản phẩm",
                 "basis": "Số lượng vừa nêu trong hội thoại; chưa ghi SSOT" if "available_quantity" in slots else "Chưa có lượng tồn có thể bán",
                 "status": "proposed" if "available_quantity" in slots else "needs_input", "capability_id": "operations_inventory", "depends_on": []},
                {"id": "restocking_sales", "title": "Chuẩn bị số bán trong một kỳ cụ thể",
                 "status": "proposed" if "recent_sales_quantity" in slots and slots.get("sales_period") else "needs_input", "capability_id": "operations_sales", "depends_on": ["restocking_stock"]},
                {"id": "restocking_lead_time", "title": "Xác nhận thời gian từ đặt đến nhận hàng",
                 "basis": "Chỉ chuẩn bị dữ liệu; chưa tính lượng nên nhập hoặc cam kết hiệu quả tài chính",
                 "status": "proposed" if "supplier_lead_days" in slots else "needs_input", "capability_id": "operations_inventory", "depends_on": ["restocking_sales"]}]
    if primary == "digitize_operations" and intent.get("focus") == "inventory_accuracy":
        has_counts = "book_quantity" in slots and "physical_quantity" in slots
        ready_to_reconcile = has_counts and slots.get("count_date") and slots.get("product_code")
        return [{"id": "inventory_baseline", "title": "Chuẩn hóa bảng nhập – xuất – tồn theo mã sản phẩm",
                 "basis": "Công cụ đã khai: " + str(values.get("inventory_management", "chưa xác nhận")), "status": "proposed", "capability_id": "operations_inventory", "depends_on": []},
                {"id": "inventory_reconciliation", "title": "Đối chiếu phiếu nhập/xuất để tìm nguyên nhân chênh lệch" if ready_to_reconcile else "Xác nhận thời điểm kiểm kê và đối chiếu chênh lệch" if has_counts else "Đối chiếu tồn sổ và kiểm kê thực tế cùng thời điểm",
                 "basis": "Đã nhận số lượng trong hội thoại; chưa ghi vào hồ sơ" if has_counts else "Chưa có bảng số lượng tồn và số kiểm kê thực tế",
                 "status": "needs_input", "capability_id": "operations_inventory", "depends_on": ["inventory_baseline"]}]
    if primary == "digitize_operations" and intent.get("focus") == "sales_reporting":
        return [{"id": "sales_schema", "title": "Chuẩn hóa ngày bán, mã sản phẩm, số lượng và doanh thu", "basis": "Công cụ đã khai: " + str(values.get("sales_management", "chưa xác nhận")), "status": "proposed", "capability_id": "operations_sales", "depends_on": []},
                {"id": "sales_reporting_period", "title": "Chuẩn bị báo cáo theo " + slots.get("report_period", "kỳ cần chọn") + (" và " + slots["report_dimension"] if slots.get("report_dimension") else ""),
                 "basis": (f"Số bán vừa nêu: {slots['recent_sales_quantity']:g} {slots.get('quantity_unit', 'đơn vị')}; "
                           "chưa ghi SSOT. Cần bảng giao dịch để đối chiếu" if "recent_sales_quantity" in slots else
                           "Cần bảng giao dịch để lập báo cáo thật"), "status": "needs_input", "capability_id": "operations_sales", "depends_on": ["sales_schema"]}]
    if primary == "digitize_operations" and intent.get("focus") == "sales_inventory_overview":
        return [{"id":"shared_product_codes","title":"Dùng chung mã sản phẩm giữa sổ bán hàng và sổ kho",
                 "basis":"Chưa có bảng giao dịch để đối chiếu; không tự tính hoặc ghi số tồn","status":"needs_input","capability_id":"operations_inventory","depends_on":[]},
                {"id":"sales_period","title":"Chuẩn bị ngày bán, mã sản phẩm, số lượng, kênh bán và hàng trả lại",
                 "status":"needs_input","capability_id":"operations_sales","depends_on":["shared_product_codes"]},
                {"id":"stock_period","title":"Đối chiếu tồn đầu, nhập, xuất và kiểm đếm cùng kỳ",
                 "status":"needs_input","capability_id":"operations_inventory","depends_on":["shared_product_codes"]}]
    if primary == "digitize_operations":
        systems = [label for key, label in (("sales_management", "bán hàng"), ("inventory_management", "tồn kho")) if normalize(values.get(key, "")) == "excel"]
        return [{"id": "operations_baseline", "title": "Lập hiện trạng bán hàng và tồn kho", "basis": "Đã xác nhận dùng Excel cho " + " và ".join(systems) if systems else "Cần xác nhận công cụ hiện tại", "status": "proposed", "capability_id": "business_context", "depends_on": []},
                {"id": "operations_priority", "title": "Chọn vấn đề cần cải thiện và cách đo", "status": "needs_input", "capability_id": "intent_clarification", "depends_on": ["operations_baseline"]}]
    if primary == "improve_packaging":
        return [{"id": "packaging_baseline", "title": "Đối chiếu bao bì đã khai và thông tin có thể đọc từ tệp", "basis": values.get("packaging", "Chưa có loại bao bì được xác nhận"), "status": "proposed", "capability_id": "business_context", "depends_on": []},
                {"id": "packaging_goal", "title": "Làm rõ yêu cầu bảo quản, vận chuyển hoặc nhận diện", "status": "needs_input", "capability_id": "intent_clarification", "depends_on": ["packaging_baseline"]}]
    if primary == "export_readiness":
        codes = intent.get("market_codes", [])
        market = get_market(codes[0])["name_vi"] if len(codes) == 1 else None
        return [{"id": "export_context", "title": "Chuẩn bị hồ sơ sản phẩm cho xuất khẩu", "basis": values.get("name", "Chưa có tên sản phẩm được xác nhận"), "status": "proposed", "capability_id": "business_context", "depends_on": []},
                {"id": "export_market", "title": f"Chuẩn bị cho luồng xuất khẩu {market}" if market else "Chọn thị trường trước khi nghiên cứu quy định", "status": "proposed" if market else "needs_input", "capability_id": "export_handoff", "depends_on": ["export_context"]}]
    if primary == "understand_business":
        return [{"id": "profile_review", "title": "Đối chiếu dữ kiện mới với hồ sơ đã nhớ", "status": "proposed", "capability_id": "business_context", "depends_on": []}]
    return [{"id": "business_goal", "title": "Làm rõ mục tiêu muốn đạt từ hồ sơ này", "status": "needs_input", "capability_id": "intent_clarification", "depends_on": []}]


def next_steps(payload):
    intent = payload["intent"]
    if intent.get("unsupported_request") == "financing":
        return [intent.get("unsupported_reason_vi") or address_text(FINANCING_UNSUPPORTED, intent)]
    context = payload.get("saved_context") or {"entities": []}
    values = business_values(context, payload.get("product"))
    slots = intent.get("working_answers", {})
    notices = []
    unread = [a for a in payload.get("attachments", []) if a.get("extraction_status") == "stored_not_read"]
    if unread:
        notices.append("Mình chưa đọc được nội dung ảnh này trong chế độ giả lập. Ảnh được giữ riêng để đối chiếu; chưa có dữ kiện nào từ ảnh được ghi nhớ. Bạn có thể dùng ảnh mẫu hoặc Excel theo mẫu.")
    if intent["primary"] == "digitize_operations":
        if intent.get("focus") == "restocking_planning":
            notices.append("Mình hiểu đây là quyết định nhập thêm hàng. Bước này chỉ chuẩn bị dữ liệu; mình chưa thể khuyên nên nhập thêm hay nhập bao nhiêu và chưa đánh giá hiệu quả tài chính.")
            if "available_quantity" in slots:
                notices.append(f"Mình giữ lượng tồn {slots['available_quantity']:g} {slots.get('available_quantity_unit', slots.get('quantity_unit', 'đơn vị'))} bạn vừa nêu trong hội thoại; chưa ghi vào hồ sơ.")
            missing = []
            if "available_quantity" not in slots:
                missing.append("lượng tồn có thể bán và mã sản phẩm")
            if "recent_sales_quantity" not in slots or not slots.get("sales_period"):
                missing.append("số bán trong kỳ cụ thể, ví dụ số hộp bán mỗi tuần")
            if "supplier_lead_days" not in slots:
                missing.append("thời gian giao hàng từ khi đặt đến khi nhận của nhà cung cấp")
            stock_unit = slots.get("available_quantity_unit") or (slots.get("quantity_unit") if "available_quantity" in slots else None)
            sales_unit = slots.get("recent_sales_quantity_unit")
            if "available_quantity" in slots and not stock_unit:
                missing.append("đơn vị của lượng tồn có thể bán")
            if stock_unit and sales_unit and stock_unit != sales_unit:
                notices.append("Đơn vị tồn kho là " + stock_unit + ", đơn vị số bán là " + sales_unit +
                               "; mình giữ riêng hai số, chưa so sánh hoặc tự quy đổi. Cần quy cách tương đương đã xác nhận hoặc số liệu cùng đơn vị trước khi tính lượng nhập.")
            notices.append("Bạn cho biết " + "; ".join(missing) + ". Chưa cần gửi chỉ tiêu tài chính." if missing else
                           "Mình đã giữ số bán theo kỳ và thời gian giao hàng vừa nêu. Bạn có thể gửi sổ bán hàng và kho để đối chiếu dữ liệu; bản này chưa có bộ tính khuyến nghị lượng đặt hàng.")
        elif intent.get("focus") == "inventory_accuracy":
            if "book_quantity" in slots and "physical_quantity" in slots:
                book, physical = slots["book_quantity"], slots["physical_quantity"]
                notices.append(f"Mình đã nhận tồn sổ {book:g} và kiểm đếm {physical:g} {slots.get('quantity_unit', 'đơn vị')}. Chênh lệch tạm tính {physical-book:g}; đây là số liệu bạn vừa nêu, chưa ghi vào hồ sơ.")
                if not slots.get("count_date") and not slots.get("product_code"):
                    notices.append("Bạn xác nhận ngày kiểm kê cụ thể (ngày/tháng/năm) và mã sản phẩm giúp mình; mình vẫn giữ số lượng vừa nêu.")
                elif not slots.get("count_date"):
                    notices.append("Mình giữ mã sản phẩm " + slots["product_code"] + ". Bạn xác nhận ngày kiểm kê cụ thể (ngày/tháng/năm) giúp mình.")
                elif not slots.get("product_code"):
                    notices.append("Mình giữ ngày kiểm kê đã nêu. Bạn cho biết mã sản phẩm để đối chiếu đúng dòng hàng.")
                else:
                    count_date = date.fromisoformat(slots["count_date"]).strftime("%d/%m/%Y")
                    notices.append("Ngày kiểm kê " + count_date + ", mã " + slots["product_code"] +
                                   ": đối chiếu phiếu nhập/xuất trước khi kết luận nguyên nhân chênh lệch. Bạn gửi bảng hoặc phiếu của mã này trong kỳ kiểm kê để mình rà tiếp.")
            else:
                notices += ["Mục tiêu đã rõ: giảm sai lệch tồn kho. Cần đối chiếu nhập – xuất – tồn và kiểm kê cùng thời điểm.", "Bạn đã có số kiểm kê thực tế cùng thời điểm với tồn trên Excel chưa?"]
        elif intent.get("focus") == "sales_reporting":
            if "recent_sales_quantity" in slots:
                period = " trong " + slots["sales_period"] if slots.get("sales_period") else ""
                notices.append(f"Mình đã nhận số bán {slots['recent_sales_quantity']:g} {slots.get('quantity_unit', 'đơn vị')}" + period +
                               (f" và giữ riêng số tồn {slots['reported_stock_quantity']:g} {slots['reported_stock_unit']}" if 'reported_stock_quantity' in slots else '') +
                               "; đây là số liệu bạn vừa nêu, chưa ghi vào hồ sơ và chưa đối chiếu giao dịch.")
                if 'reported_stock_quantity' in slots:
                    notices.append("Bạn xác nhận thời điểm của số tồn này và mã sản phẩm, rồi gửi bảng giao dịch để mình đối chiếu. Mình chưa coi đó là tồn đầu hay cuối kỳ bán, cũng chưa kết luận lượng còn có thể bán.")
                    return [address_text(notice, intent) for notice in notices]
                notices.append("Bạn gửi mã sản phẩm và bảng giao dịch của kỳ này để mình đối chiếu; chưa cần gửi chỉ tiêu tài chính." if slots.get("sales_period") else
                               "Bạn cho biết kỳ bán của số lượng vừa nêu, ví dụ tháng 9 hoặc trong 7 ngày; mình vẫn giữ số bán đã nhận.")
            else:
                notices.append("Mục tiêu đã rõ: tổng hợp bán hàng nhanh hơn. Cần bảng giao dịch để lập báo cáo.")
                notices.append("Đã nhận kỳ tổng hợp theo " + slots["report_period"] + ". Bạn gửi bảng giao dịch để mình đối chiếu cột dữ liệu." if slots.get("report_period") else "Bạn muốn tổng hợp theo ngày hay tháng, theo sản phẩm hay kênh bán?")
        elif intent.get("focus") == "sales_inventory_overview":
            notices.append("Mình sẽ đối chiếu cả bán hàng và tồn kho theo cùng mã sản phẩm: số bán và hàng trả lại từ sổ bán hàng; tồn đầu, nhập, xuất và kiểm đếm từ sổ kho. Chưa có bảng số liệu nên mình chưa tính chênh lệch hoặc thay hồ sơ.")
            notices.append("Bạn gửi Excel nghiệp vụ hoặc nêu kỳ đối chiếu, mã sản phẩm và số lượng hiện có. Chỉ cần một sản phẩm trước; mình sẽ chỉ rõ cột nào còn thiếu.")
        else:
            notices.append("Mình có thể chuẩn hóa sổ bán hàng hoặc đối chiếu tồn kho theo mã sản phẩm. Chưa có số liệu nên chưa lập được báo cáo thực tế.")
            notices.append("Bạn gửi Excel nghiệp vụ hoặc nêu một việc cụ thể, ví dụ tồn trên sổ và số đếm thực tế của cùng một mã sản phẩm.")
    elif intent["primary"] == "improve_packaging":
        notices.append("Bao bì trong hồ sơ đã xác nhận: " + str(values["packaging"]) + "." if values.get("packaging") else "Thông tin bao bì chưa được xác nhận vào hồ sơ. Mình giữ các tệp và phần đang rà để bạn kiểm tra.")
        notices.append("Bạn muốn cải thiện bảo quản, vận chuyển hay cách thể hiện bao bì?")
    elif intent["primary"] == "export_readiness":
        codes = intent.get("market_codes", [])
        topics = payload.get("export_question_topics") or intent.get("export_question_topics", [])
        topic_names = {"facility_registration": "đăng ký cơ sở với FDA", "food_label": "nhãn thực phẩm",
                       "prior_notice": "thông báo trước lô hàng (prior notice)", "certifications": "chứng nhận"}
        if topics:
            requested = ", ".join(topic_names[topic] for topic in topics if topic in topic_names)
            notices.append("Mình chưa trả lời được câu hỏi về " + requested + " ở bước lập kế hoạch này. Chưa chạy nghiên cứu hoặc kiểm chứng nguồn hiện hành; mình chưa kết luận nghĩa vụ của sản phẩm.")
        notices.append("Thị trường vừa nêu chưa có luồng riêng trong bản thử nghiệm. Hiện có Mỹ, Đức (EU) và Nhật Bản; mình chưa chọn thị trường khác thay bạn." if intent.get("market_clarification_needed") else
                       "Đã ghi nhận thị trường " + get_market(codes[0])["name_vi"] + "; đây mới là kế hoạch chuẩn bị, chưa chạy nghiên cứu hay tự chuyển hồ sơ." if len(codes) == 1 else "Bạn muốn chuẩn bị cho thị trường nào? Mình chưa chọn thay bạn.")
        if not values.get("name"):
            notices.append("Hãy chọn hoặc xác nhận đúng sản phẩm muốn dùng cho kế hoạch này." if any(
                entity["entity_type"] == "product" for entity in context["entities"]) else
                "Cần xác nhận hồ sơ sản phẩm trước khi dùng lại cho nghiên cứu xuất khẩu.")
    elif intent["primary"] == "understand_business":
        notices.append("Mình đã chuẩn bị nháp để đối chiếu với hồ sơ. Chỉ dữ kiện được bạn chọn và xác nhận mới được ghi nhớ; các phần chưa chọn vẫn giữ trong bản nháp.")
    else:
        notices.append("Bạn muốn cập nhật hồ sơ, số hóa vận hành, cải thiện bao bì hay chuẩn bị xuất khẩu?")
    return [address_text(notice, intent) for notice in notices]


def mock_reply(payload):
    """Put the grounded result and one follow-up in the compact chat contract.

    The full notices remain available as plan detail. Choosing the follow-up by
    its position in the state-derived notices, rather than '?' punctuation,
    also exposes requests such as 'Bạn xác nhận ngày...' and the next action.
    LiveIntakeService supplies actual Claude text through its own override.
    """
    notices = payload.get("next_steps", [])
    unread = any(a.get("extraction_status") == "stored_not_read" for a in payload.get("attachments", []))
    normal = notices[1:] if unread else notices
    lead = normal[0] if normal else notices[0] if notices else "Bạn muốn mình hỗ trợ việc gì từ hồ sơ này?"
    if unread:
        lead = "Mình chưa đọc được ảnh này trong chế độ giả lập. " + lead
    return {"assistant_text": lead, "pending_question": normal[-1] if len(normal) > 1 else None}
