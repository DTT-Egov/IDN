"""Private attachment -> bounded intent -> proposed facts -> explicit SSOT save.

Preparation never creates an enterprise/product entity. Confirming selected
facts materializes new entities and records assertions within one transaction.
"""
from __future__ import annotations

import base64
import copy
import hashlib
import json

from langgraph.graph import END, START, StateGraph
from langsmith import tracing_context

from nmate.v03.core import CoreError, json_text, new_id, now_iso, require_valid_entity_name
from nmate.v03.field_scope import canonical_entity_type, field_is_in_scope
from nmate.core_v1.review_store import ReviewStore, digest
from .dialogue import interpret, business_plan, business_values, next_steps, working_answers, mock_reply, address_text
from .extraction import (FIELD_SPECS, MAX_TOTAL, extract_business_text, parse_workbook, named_profile_lookup,
                         read_image_fixture, typed_value, validate_attachment, product_name_key)
from .product_binding import (product_scope, scoped_business_context, reuse_metadata, detect_export_topics,
                              declared_product_name, resolve_declared_product, owned_product_names, matching_owned_products,
                              product_selection_error, product_reference_spans, authorized_product_reference_ids)


SCHEMA = """
CREATE TABLE IF NOT EXISTS v04_intakes (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 owner_id TEXT NOT NULL REFERENCES v03_accounts(id), status TEXT NOT NULL,
 payload_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v04_attachments (
 id TEXT PRIMARY KEY, intake_id TEXT NOT NULL REFERENCES v04_intakes(id),
 enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id), owner_id TEXT NOT NULL,
 filename TEXT NOT NULL, media_type TEXT NOT NULL, sha256 TEXT NOT NULL,
 data BLOB NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS v04_intake_owner ON v04_intakes(enterprise_id,owner_id,created_at);
"""

BOUNDED_ORIGINS = {"intent": "bounded_local_parser", "working_answers": "bounded_local_parser",
                   "business_plan": "bounded_local_parser", "next_steps": "bounded_local_parser",
                   "plan": "server_ssot_state_machine"}

def make_plan(intent, files):
    tasks = []
    if files:
        tasks.append({"id": "read_documents", "title": "Đọc tệp và giữ vị trí nguồn",
                      "capability_id": "document_intake", "depends_on": [], "status": "completed"})
    tasks.append({"id": "understand_intent", "title": intent["primary_label"], "capability_id": "intent_planner",
                  "depends_on": [], "status": "completed"})
    tasks.append({"id": "confirm_facts", "title": "Xác nhận dữ kiện muốn ghi nhớ",
                  "capability_id": "ssot_candidate_review", "depends_on": [x["id"] for x in tasks],
                  "status": "awaiting_confirmation"})
    tasks.append({"id": "remember_facts", "title": "Cập nhật hồ sơ dùng lại cho lần sau",
                  "capability_id": "ssot_confirm", "depends_on": ["confirm_facts"], "status": "awaiting_confirmation"})
    return tasks


class IntakeService:
    def __init__(self, repo, manifest_path=None):
        self.repo = repo
        self.manifest_path = manifest_path
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)
        self.review_store = ReviewStore(repo)
        graph = StateGraph(dict)
        graph.add_node("read_documents", self._read_documents)
        graph.add_node("understand_intent", lambda state: {**state, "intent": interpret(state["text"])})
        graph.add_edge(START, "read_documents")
        graph.add_edge("read_documents", "understand_intent")
        graph.add_edge("understand_intent", END)
        self.graph = graph.compile()

    def migrate_reviews(self, *, db=None):
        """Explicit additive backfill. Deployment must back up/rehearse first.

        No SSOT/alias/entity/model rows are written and running twice is a no-op.
        """
        with self.repo._fact_transaction(db) as connection:
            migrated = 0
            for row in connection.execute("SELECT enterprise_id,owner_id,payload_json FROM v04_intakes").fetchall():
                payload = json.loads(row["payload_json"])
                if self.review_store.workspace(connection, row["enterprise_id"], payload["id"]) is None:
                    self.review_store.sync(connection, row["owner_id"], row["enterprise_id"], payload, legacy=True)
                    migrated += 1
            return {"migrated_workspace_count": migrated, "model_calls": 0}

    def _read_documents(self, state):
        extracted, attachments = [], []
        for item in state["files"]:
            pdf_metadata = {}
            if item["kind"] == "pdf":
                from .pdf_intake import parse_pdf
                facts, notices, pdf_metadata = parse_pdf(item["raw"])
            else:
                facts, notices = (parse_workbook(item["raw"]) if item["kind"] == "spreadsheet"
                                  else read_image_fixture(item, self.manifest_path))
            attachment_id = item["id"]
            for fact in facts:
                fact["source"].update({"attachment_id": attachment_id, "filename": item["filename"],
                                       "sha256": item["sha256"]})
            extracted.extend(facts)
            attachments.append({k: item[k] for k in ("id", "filename", "media_type", "size", "sha256", "kind")}
                               | {"extraction_status": "parsed" if item["kind"] == "spreadsheet" else
                                  "simulated_fixture" if facts else "stored_not_read", "warnings": notices, **pdf_metadata})
        return {**state, "extracted": extracted, "attachments": attachments}

    def _owned(self, account_id, enterprise_id, intake_id, db):
        self.repo.get_membership(account_id, enterprise_id, db)
        row = db.execute("SELECT * FROM v04_intakes WHERE id=? AND enterprise_id=? AND owner_id=?",
                         (intake_id, enterprise_id, account_id)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy hồ sơ đính kèm của tài khoản này.", 404)
        return self.review_store.project(db, account_id, enterprise_id, json.loads(row["payload_json"]))

    def get(self, account_id, enterprise_id, intake_id):
        with self.repo.connection() as db:
            from nmate.core_v1.workspace_contract import project_intake_plan, resource_workspace_contract, current_product_reference
            raw = self._owned(account_id, enterprise_id, intake_id, db)
            context = scoped_business_context(self.repo.get_context(account_id, enterprise_id, db=db), raw.get("product"))
            value = project_intake_plan(raw, values=business_values(context, raw.get("product")),
                                        context_revision=context.get("context_revision"),
                                        current_product=current_product_reference(context, raw.get("product")))
            value["workspace_contract"] = resource_workspace_contract(self.repo, account_id, enterprise_id, value, db, kind="intake")
            return value

    def list(self, account_id, enterprise_id):
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            return [self.review_store.project(db, account_id, enterprise_id, json.loads(row[0])) for row in db.execute("SELECT payload_json FROM v04_intakes "
                "WHERE enterprise_id=? AND owner_id=? ORDER BY created_at DESC,id DESC LIMIT 50", (enterprise_id, account_id))]

    def resolve_product_reference(self, account_id, enterprise_id, text, db, *, selected=None):
        """Explicit owned names take precedence over inherited conversation context."""
        self.repo.get_membership(account_id, enterprise_id, db)
        declared = None if named_profile_lookup(text) else declared_product_name(text)
        if declared:
            return resolve_declared_product(self.repo, account_id, enterprise_id, declared, db, selected=selected)
        rows = list(db.execute("SELECT n.entity_id,n.name_key FROM v03_entity_names n JOIN v03_entities e ON e.id=n.entity_id "
                          "WHERE e.enterprise_id=? AND e.created_by=? AND e.acl='private_owner' AND e.entity_type='product'",
                          (enterprise_id, account_id)))
        mentioned = {row["entity_id"] for row in rows if product_reference_spans(text, row["name_key"])}
        eligible = {entity_id: self.repo._entity(account_id, enterprise_id, entity_id, db) for entity_id in mentioned}
        eligible = {key: item for key, item in eligible.items() if item["can_select_for_ai"]}
        ids = authorized_product_reference_ids(text,
            [(row["entity_id"], row["name_key"]) for row in rows if row["entity_id"] in eligible])
        matches = [{key: eligible[entity_id][key] for key in ('id', 'name', 'version')} for entity_id in sorted(ids)]
        if len(matches) > 1:
            if selected and any(item['id'] == selected for item in matches):
                return selected
            raise product_selection_error("ambiguous_product", "Chị đang nhắc nhiều hồ sơ sản phẩm. Chọn một hồ sơ cho phần đang rà rồi trích lại; chưa ghi thay đổi.", matches)
        return matches[0]['id'] if matches else None

    def refresh_dialogue(self, account_id, enterprise_id, intake_id, text, previous_intent=None, db=None):
        with self.repo._fact_transaction(db) as db:
            payload = self._owned(account_id, enterprise_id, intake_id, db)
            self._append_text_observations(account_id, enterprise_id, payload, text, db, allow_terminal_derivation=True)
            previous = previous_intent or payload.get("intent", {})
            intent = interpret(text, previous=previous)
            intent["working_answers"] = working_answers(text, intent, previous.get("working_answers"))
            payload["intent"] = intent
            context = scoped_business_context(self.repo.get_context(account_id, enterprise_id, db=db), payload.get("product"))
            payload["saved_context"] = context
            payload["reused_context"] = reuse_metadata(context)
            payload["export_question_topics"] = detect_export_topics(text) or payload.get("export_question_topics", [])
            payload["business_plan"] = business_plan(intent, business_values(context, payload.get("product")))
            payload["questions"] = ([address_text("Bạn muốn cập nhật hồ sơ, số hóa vận hành, cải thiện bao bì hay chuẩn bị xuất khẩu?", intent)]
                                    if intent["primary"] == "needs_clarification" and not intent.get("unsupported_request") else [])
            if (payload.get("product") or {}).get("id") == "new_product" and not any(
                    c["field"] == "name" for c in payload["candidates"]):
                payload["questions"].append("Nêu tên sản phẩm trong chat để chuẩn bị nháp trước khi xác nhận các dữ kiện sản phẩm.")
            pending = any(c["status"] in {"candidate", "conflict"} for c in payload["candidates"])
            if payload["status"] != "confirmed":
                payload["status"] = "awaiting_confirmation" if pending else "needs_clarification" if payload["questions"] else "ready"
            payload["plan"] = make_plan(intent, payload["attachments"])
            if not pending:
                payload["plan"] = [t for t in payload["plan"] if t["id"] not in {"confirm_facts", "remember_facts"}]
            payload["next_steps"] = next_steps(payload)
            payload.update(mock_reply(payload))
            # Track the producer of the current fields, not the first prepare
            # operation: a clarification can regenerate the same intake later.
            # LiveIntakeService has its own refresh and records Claude origins.
            payload.setdefault("origins", {}).update(BOUNDED_ORIGINS,
                                                     assistant_text="bounded_local_parser")
            payload["summary"] = address_text("Mình đang giữ tệp và phần bạn đang rà; chưa tự ghi thêm dữ kiện vào hồ sơ.", intent)
            self.review_store.sync(db, account_id, enterprise_id, payload)
            db.execute("UPDATE v04_intakes SET status=?,payload_json=?,updated_at=? WHERE id=?",
                       (payload["status"], json_text(payload), now_iso(), intake_id))
            return payload

    def _append_text_observations(self, account, enterprise, payload, text, db, *, allow_terminal_derivation=False):
        """Add bounded current-message observations to the existing private draft."""
        # A task instruction accompanying a document may mention its category
        # without asserting the exact product name. Keep that instruction for
        # intent/provenance, but do not recreate the excluded mention when this
        # same message is projected again by the conversation service.
        document_instruction = payload.get("document_instruction_sha256") == hashlib.sha256(text.encode("utf-8")).hexdigest()
        observations = extract_business_text(text, include_name_mentions=not document_instruction)
        if not observations or payload["status"] == "confirmed":
            return []
        context = self.repo.get_context(account, enterprise, db=db)
        targets = {}
        for kind in {raw["entity_type"] for raw in observations}:
            anchor = payload.get("product" if kind == "product" else "enterprise_entity")
            if anchor and not anchor["id"].startswith("new_"):
                entity = self.repo._entity(account, enterprise, anchor["id"], db)
                if canonical_entity_type(entity["entity_type"]) != kind:
                    raise CoreError("invalid_field_scope", "Dữ kiện không thuộc loại hồ sơ đang chọn; chưa thêm nháp.", 409)
                if payload["expected_entity_versions"].get(anchor["id"]) != entity["version"]:
                    raise CoreError("version_conflict", "Hồ sơ đã đổi; cần đối chiếu lại trước khi thêm dữ kiện từ tin nhắn.", 409)
                target = next(item for item in context["entities"] if item["id"] == anchor["id"])
                if kind == "product":
                    names = {item["value"] for item in observations if item["field"] == "name"}
                    _, aliases = owned_product_names(self.repo, account, enterprise, anchor["id"], db)
                    if names and not all(product_name_key(name) in aliases for name in names):
                        raise CoreError("text_product_scope_ambiguous", "Tên sản phẩm vừa nêu khác hồ sơ đang chọn. Chọn đúng sản phẩm trước khi ghi nhận dữ kiện.", 409)
            else:
                if kind == "enterprise" and any(canonical_entity_type(item["entity_type"]) == "enterprise" for item in context["entities"]):
                    raise CoreError("version_conflict", "Hồ sơ doanh nghiệp đã được tạo; cần mở lại nháp để đối chiếu.", 409)
                target = {"id": "new_" + kind, "name": (anchor or {}).get("name",
                    "Sản phẩm chờ xác nhận" if kind == "product" else context["enterprise_name"]), "version": 0, "values": {}}
                payload["product" if kind == "product" else "enterprise_entity"] = {key: target[key] for key in ("id", "name", "version")}
                payload["expected_entity_versions"][target["id"]] = 0
            targets[kind] = target
        existing = {(c["entity_id"], c["field"], json_text(c["value"])): c for c in payload["candidates"]}
        created = []
        for raw in observations:
            target = targets[raw["entity_type"]]
            key = (target["id"], raw["field"], json_text(raw["value"]))
            derived_from = None
            if key in existing:
                prior = existing[key]
                prior_sources = prior.get("sources", [prior["source"]])
                current_same = raw["field"] in target["values"] and (target["values"][raw["field"]] == raw["value"] or
                    raw["field"] == "name" and product_name_key(target["values"][raw["field"]]) == product_name_key(raw["value"]))
                source_hash = raw["source"].get("text_sha256") or raw["source"].get("message_sha256")
                prior_hashes = {s.get("text_sha256") or s.get("message_sha256") for s in prior_sources}
                fresh_owner_statement = (allow_terminal_derivation and prior.get("decision_state") not in {None, "pending"} and
                    raw["source"].get("kind") == "server_text_extract" and not current_same and
                    bool(raw["source"].get("quote")) and source_hash is not None and source_hash not in prior_hashes)
                if not fresh_owner_statement:
                    if prior.get("decision_state") in {None, "pending"} and raw["source"] not in prior_sources:
                        prior.setdefault("sources", [prior["source"]]).append(raw["source"])
                    continue
                # A new owner statement creates a new observation/candidate.
                # Its terminal predecessor is never changed or re-selected.
                derived_from = prior["id"]
            current, known = target["values"].get(raw["field"]), raw["field"] in target["values"]
            candidate = {**raw, "id": new_id("candidate"), "entity_id": target["id"], "base_field": raw["field"],
                "sources": [raw["source"]], "status": "already_known" if known and (current == raw["value"] or raw["field"] == "name" and product_name_key(current) == product_name_key(raw["value"])) else "conflict" if known else "candidate"}
            if derived_from:
                candidate["derived_from_candidate_id"] = derived_from
            if known:
                candidate["current_value"] = current
                candidate["conflict"] = {"kind": "ssot_value", "current_value": current, "incoming_value": raw["value"]} if not (current == raw["value"] or raw["field"] == "name" and product_name_key(current) == product_name_key(raw["value"])) else None
            pending = [c for c in payload["candidates"] if c["entity_id"] == target["id"] and c["field"] == raw["field"]
                       and c["status"] in {"candidate", "conflict"} and c["value"] != raw["value"]]
            if pending:
                candidate["status"] = "conflict"
                candidate["conflict"] = {"kind": "document_disagreement", "other_candidate_ids": [c["id"] for c in pending]}
                for item in pending:
                    item["status"] = "conflict"
                    item["conflict"] = {"kind": "document_disagreement", "other_candidate_ids": [candidate["id"]]}
            payload["candidates"].append(candidate)
            existing[key] = candidate
            created.append(candidate["id"])
        if len(payload["candidates"]) > 40:
            raise CoreError("candidate_limit", "Mỗi lượt tối đa 40 dữ kiện; hãy chia nhỏ thông tin.")
        payload.setdefault("origins", {})["text_values"] = "server_text_extract"
        return created

    def clarify(self, account_id, enterprise_id, intake_id, text, operation_id, db=None):
        if not isinstance(text, str) or not text.strip() or len(text) > 4000:
            raise CoreError("invalid_intent", "Hãy nói rõ mục tiêu trong 1–4.000 ký tự.")
        with self.repo._fact_transaction(db) as db:
            payload = self._owned(account_id, enterprise_id, intake_id, db)
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "v04_clarify", operation_id,
                                                        {"intake_id": intake_id, "text": text})
            if previous:
                return self._owned(account_id, enterprise_id, previous["id"], db)
            if payload["status"] == "confirmed":
                raise CoreError("already_confirmed", "Hồ sơ này đã lưu; hãy gửi yêu cầu mới để dùng lại thông tin đã xác nhận.", 409)
            prior_intent = payload.get("intent")
            payload.setdefault("messages", [{"role": "user", "text": payload["text"], "created_at": payload["created_at"]}])
            payload["messages"].append({"role": "user", "text": text, "created_at": now_iso()})
            payload["text"] = text
            payload["latest_intake_operation_id"] = operation_id
            db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(payload), intake_id))
            payload = self.refresh_dialogue(account_id, enterprise_id, intake_id, text, prior_intent, db)
            self.repo._save_operation(db, account_id, enterprise_id, "v04_clarify", operation_id, request_hash, {"id": intake_id})
            return payload

    def attachment(self, account_id, enterprise_id, attachment_id):
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            row = db.execute("SELECT * FROM v04_attachments WHERE id=? AND enterprise_id=? AND owner_id=?",
                             (attachment_id, enterprise_id, account_id)).fetchone()
            if row is None:
                raise CoreError("not_found", "Không tìm thấy tệp riêng tư của tài khoản này.", 404)
            self._owned(account_id, enterprise_id, row["intake_id"], db)
            return {"id": row["id"], "filename": row["filename"], "media_type": row["media_type"],
                    "sha256": row["sha256"], "data_base64": base64.b64encode(row["data"]).decode("ascii")}

    def prepare(self, account_id, enterprise_id, text, attachments, operation_id, product_entity_id=None, db=None):
        if not isinstance(text, str) or len(text) > 4000:
            raise CoreError("invalid_intent", "Mục tiêu cần tối đa 4.000 ký tự.")
        if not isinstance(attachments, list) or len(attachments) > 3:
            raise CoreError("attachment_limit", "Mỗi lượt nhận tối đa 3 tệp, tổng tối đa 6 MB.")
        if not text.strip() and not attachments:
            raise CoreError("invalid_intent", "Hãy nêu mục tiêu hoặc gửi ảnh/Excel để bắt đầu.")
        # Authorize before parsing bytes; invalid/forbidden requests create no file/entity.
        with self.repo._context_transaction(db) as auth_db:
            self.repo.get_membership(account_id, enterprise_id, auth_db)
            if product_entity_id:
                entity = self.repo._entity(account_id, enterprise_id, product_entity_id, auth_db)
                if entity["entity_type"] != "product":
                    raise CoreError("invalid_product", "Thông tin được chọn chưa phải sản phẩm.")
        files = [validate_attachment(item) for item in attachments]
        if sum(x["size"] for x in files) > MAX_TOTAL:
            raise CoreError("attachment_limit", "Tổng tệp mỗi lượt tối đa 6 MB.")
        request = {"text": text, "product_entity_id": product_entity_id,
                   "attachments": [{k: f[k] for k in ("filename", "media_type", "sha256")} for f in files]}
        for item in files:
            item["id"] = new_id("attachment")
        with self.repo._fact_transaction(db) as db:
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "v04_prepare", operation_id, request)
            if previous:
                return self._owned(account_id, enterprise_id, previous["id"], db)
            with tracing_context(enabled=False):
                state = self.graph.invoke({"text": text, "files": files}, config={"callbacks": []})
            state["intent"].setdefault("working_answers", working_answers(text, state["intent"]))
            # Documents supply independently reviewable observations. In their
            # accompanying instruction, only an explicit name declaration is
            # another name assertion; a natural mention such as "đọc tài liệu
            # Trà Sen để lập nháp" is task context, never a prefix alias.
            state["extracted"].extend(extract_business_text(text, include_name_mentions=not files))
            context = self.repo.get_context(account_id, enterprise_id, db=db)
            entities = context["entities"]
            enterprise = next((x for x in entities if x["entity_type"] == "enterprise"), None)
            enterprise = enterprise or {"id": "new_enterprise", "entity_id": "new_enterprise", "name": context["enterprise_name"], "version": 0, "values": {}}
            names = {product_name_key(f["value"]) for f in state["extracted"] if f["field"] == "name"}
            if len(names) > 1:
                raise CoreError("multiple_products_not_supported", "Các tệp có nhiều tên sản phẩm. 0.4A nhận một sản phẩm mỗi lượt; hãy gửi riêng từng sản phẩm để tránh gộp nhầm dữ kiện.")
            binding_text = text
            if files:
                declared_name = next((f["value"] for f in state["extracted"] if f["field"] == "name"), None)
                binding_text = "Tên sản phẩm: " + declared_name if declared_name else ""
            selected_product, binding = product_scope(self, account_id, enterprise_id, binding_text, db, product_entity_id)
            product = next((x for x in entities if x["id"] == selected_product), None) if selected_product else None
            # product_scope is the single binding authority. A second substring
            # scan here used to override its unbound/new/conflict decision,
            # including an unknown reference that merely contained a saved name.
            if product is None and any(f["entity_type"] == "product" for f in state["extracted"]):
                proposed_name = next((f["value"] for f in state["extracted"] if f["field"] == "name"), "Sản phẩm chờ xác nhận")
                product = {"id": "new_product", "entity_id": "new_product", "name": proposed_name, "version": 0, "values": {}}
            context = scoped_business_context(context, product)
            candidates, by_value = [], {}
            for raw in state["extracted"]:
                target = enterprise if raw["entity_type"] == "enterprise" else product
                field = raw["field"] + ("." + raw["value"]["period"] if raw["field"] == "revenue" else "")
                key = (target["id"], field, json_text(raw["value"]))
                if key in by_value:
                    by_value[key]["sources"].append(raw["source"])
                    continue
                current = target["values"].get(field)
                known = field in target["values"]
                candidate = {**raw, "id": new_id("candidate"), "entity_id": target["id"], "base_field": raw["field"],
                    "field": field, "sources": [raw["source"]], "status": "already_known" if known and (current == raw["value"] or raw["field"] == "name" and product_name_key(current) == product_name_key(raw["value"])) else "conflict" if known else "candidate"}
                if known:
                    candidate["current_value"] = current
                    candidate["conflict"] = {"kind": "ssot_value", "current_value": current, "incoming_value": raw["value"]} if not (current == raw["value"] or raw["field"] == "name" and product_name_key(current) == product_name_key(raw["value"])) else None
                candidates.append(candidate)
                by_value[key] = candidate
            groups = {}
            for candidate in candidates:
                groups.setdefault((candidate["entity_id"], candidate["field"]), []).append(candidate)
            for group in groups.values():
                if len(group) > 1:
                    for candidate in group:
                        candidate["status"] = "conflict"
                        candidate["conflict"] = {"kind": "document_disagreement", "other_candidate_ids": [x["id"] for x in group if x != candidate]}
            if len(candidates) > 40:
                raise CoreError("candidate_limit", "Mỗi lượt tối đa 40 dữ kiện; hãy chia nhỏ tài liệu.")
            questions = []
            if state["intent"]["primary"] == "needs_clarification" and not state["intent"].get("unsupported_request"):
                questions.append("Anh/chị muốn cập nhật hồ sơ, số hóa vận hành, cải thiện bao bì hay chuẩn bị xuất khẩu?")
            if product and product["id"] == "new_product" and not names:
                questions.append("Nêu tên sản phẩm trong chat để chuẩn bị nháp trước khi xác nhận các dữ kiện sản phẩm.")
            selected_entities = [enterprise] + ([product] if product else [])
            stamp = now_iso()
            payload = {"id": new_id("intake"), "enterprise_id": enterprise_id, "status": "awaiting_confirmation", "text": text,
                "prepare_operation_id": operation_id, "latest_intake_operation_id": operation_id,
                "intent": state["intent"], "plan": make_plan(state["intent"], files), "candidates": candidates,
                "attachments": state["attachments"], "enterprise_entity": {k: enterprise[k] for k in ("id", "name", "version")},
                "product": {k: product[k] for k in ("id", "name", "version")} if product else None,
                "product_binding": binding, "export_question_topics": detect_export_topics(text),
                "expected_entity_versions": {x["id"]: x["version"] for x in selected_entities},
                "questions": questions, "limitations": ["Đọc Excel thật; hiểu mục tiêu theo phạm vi thử nghiệm. Ảnh mẫu dùng kết quả giả lập, ảnh khác chưa được nhận dạng.",
                    "0.4A chuẩn bị hồ sơ và kế hoạch; chưa nghiên cứu chính sách hoặc xác nhận điều kiện được hỗ trợ."],
                "summary": f"Mình hiểu mục tiêu: {state['intent']['primary_label'].lower()}. Đã tìm thấy {len(candidates)} dữ kiện để anh/chị kiểm tra; chưa ghi vào hồ sơ.",
                "model_calls": 0, "provider_attempts": 0, "created_at": stamp,
                "origins": dict(BOUNDED_ORIGINS),
                "reused_context": reuse_metadata(context), "saved_context": context}
            if files:
                payload["document_instruction_sha256"] = hashlib.sha256(text.encode("utf-8")).hexdigest()
            payload["business_plan"] = business_plan(payload["intent"], business_values(context, payload["product"]))
            if not any(c["status"] != "already_known" for c in candidates):
                payload["status"] = "needs_clarification" if questions else "ready"
                payload["saved_context"] = context
                payload["plan"] = [t for t in payload["plan"] if t["id"] not in {"confirm_facts", "remember_facts"}]
                payload["summary"] = ("Mình chưa xác định được mục tiêu. Anh/chị nói rõ việc muốn được hỗ trợ nhé." if questions else
                    "Mình đã dùng lại hồ sơ đã xác nhận; không có dữ kiện mới cần nhập lại." if context["fact_refs"] else
                    "Mình hiểu mục tiêu, nhưng chưa có dữ kiện doanh nghiệp được xác nhận. Anh/chị có thể gửi ảnh hoặc Excel để bổ sung.")
                payload["next_steps"] = self._next_steps(payload)
            payload["summary"] = address_text(payload["summary"], payload["intent"])
            if payload["intent"].get("unsupported_reason_vi"):
                payload["summary"] = payload["intent"]["unsupported_reason_vi"]
            payload["questions"] = [address_text(question, payload["intent"]) for question in payload["questions"]]
            self.review_store.sync(db, account_id, enterprise_id, payload)
            db.execute("INSERT INTO v04_intakes VALUES (?,?,?,?,?,?,?)", (payload["id"], enterprise_id, account_id,
                       payload["status"], json_text(payload), stamp, stamp))
            for f in files:
                db.execute("INSERT INTO v04_attachments VALUES (?,?,?,?,?,?,?,?,?)", (f["id"], payload["id"], enterprise_id,
                    account_id, f["filename"], f["media_type"], f["sha256"], f["raw"], stamp))
            self.repo._save_operation(db, account_id, enterprise_id, "v04_prepare", operation_id, request_hash, {"id": payload["id"]})
            return payload

    def _create_entity(self, db, account_id, enterprise_id, kind, name, parent_id=None):
        require_valid_entity_name(name, kind)
        if kind == "product":
            self.repo._check_product_name(db, enterprise_id, name)
        entity_id = new_id("entity")
        db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) "
                   "VALUES(?,?,?,?,?,?,?)", (entity_id, enterprise_id, kind, name, parent_id, account_id, now_iso()))
        self.repo._remember_name(db, entity_id, name)
        self.repo._advance_revision(db, enterprise_id, account_id, [{"entity_id": entity_id, "field": "__created__"}])
        return entity_id

    def _confirmation_projection(self, payload, previous):
        """Pure extension hook; called inside the fact/review SQL unit of work."""
        return payload

    def confirm(self, account_id, enterprise_id, intake_id, selected_fact_ids, expected_entity_versions,
                operation_id, edits=None, conflict_choices=None, expected_review_revision=None,
                expected_proposal_hashes=None):
        edits = {} if edits is None else edits
        conflict_choices = {} if conflict_choices is None else conflict_choices
        if not isinstance(selected_fact_ids, list) or len(selected_fact_ids) > 40 or any(not isinstance(x, str) for x in selected_fact_ids) or len(set(selected_fact_ids)) != len(selected_fact_ids):
            raise CoreError("invalid_selection", "Chọn tối đa 40 dữ kiện, mỗi dữ kiện một lần.")
        if not selected_fact_ids:
            raise CoreError("empty_selection", "Hãy chọn ít nhất một dữ kiện muốn ghi nhớ.")
        if not isinstance(expected_entity_versions, dict) or not isinstance(edits, dict) or not isinstance(conflict_choices, dict):
            raise CoreError("invalid_confirmation", "Thông tin xác nhận chưa đúng định dạng.")
        if set(edits) - set(selected_fact_ids) or set(conflict_choices) - set(selected_fact_ids):
            raise CoreError("invalid_confirmation", "Chỉ sửa và giải quyết xung đột cho dữ kiện đã chọn.")
        request = {"id": intake_id, "selected": sorted(selected_fact_ids), "versions": expected_entity_versions,
                   "edits": edits, "choices": conflict_choices, "review_revision": expected_review_revision,
                   "proposal_hashes": expected_proposal_hashes}
        with self.repo.connection(write=True) as db:
            payload = self._owned(account_id, enterprise_id, intake_id, db)
            previous = copy.deepcopy(payload)
            if payload.get("review", {}).get("migration_required"):
                raise CoreError("review_migration_required", "Nháp cũ cần được chuyển đổi an toàn trước khi xác nhận.", 409)
            request_hash, previous_receipt = self.review_store.prior_receipt(db, enterprise_id, account_id, "confirm_selected", operation_id, request)
            if previous_receipt:
                # Read authorization is checked again, even for a known operation.
                receipt = self.review_store.receipt(db, enterprise_id, intake_id, account_id, operation_id)
                payload["confirmation_receipt"] = receipt
                return payload
            candidates = {x["id"]: x for x in payload["candidates"]}
            if set(selected_fact_ids) - candidates.keys():
                raise CoreError("invalid_selection", "Dữ kiện không thuộc lượt đang xác nhận.")
            heads = self.review_store.validate_heads(db, enterprise_id, payload, expected_review_revision, expected_proposal_hashes, selected_fact_ids)
            selected = [candidates[key] for key in selected_fact_ids]
            # Validate the complete command before materializing any entity.
            for candidate in selected:
                target = candidate["entity_id"]
                entity_type = target.removeprefix("new_") if target.startswith("new_") else self.repo._entity(account_id, enterprise_id, target, db)["entity_type"]
                spec = FIELD_SPECS.get(candidate.get("base_field"))
                if not spec or canonical_entity_type(entity_type) != spec[1] or canonical_entity_type(candidate.get("entity_type")) != spec[1] or not field_is_in_scope(entity_type, candidate["field"]):
                    raise CoreError("invalid_field_scope", "Dữ kiện từ nguồn không thuộc loại hồ sơ đang chọn; chưa lưu thay đổi.")
            targets = {x["entity_id"] for x in selected}
            for target in targets:
                expected = expected_entity_versions.get(target)
                if isinstance(expected, bool) or not isinstance(expected, int) or expected < 0 or expected != payload["expected_entity_versions"].get(target):
                    raise CoreError("version_conflict", "Phiên bản hồ sơ đã khác lúc đọc tệp. Hãy mở lại và đối chiếu trước khi lưu.", 409)
                if not target.startswith("new_") and self.repo._entity(account_id, enterprise_id, target, db)["version"] != expected:
                    raise CoreError("version_conflict", "Hồ sơ đã được cập nhật ở lượt khác. Hãy đọc tệp lại để đối chiếu; không ghi đè tự động.", 409)
            # Compatibility clients may include already-known fields in their
            # selection. They are not owner decisions or fact writes again.
            selected = [c for c in selected if c["decision_state"] != "covered_by_current"]
            targets = {c["entity_id"] for c in selected}
            if not selected:
                raise CoreError("no_pending_selection", "Các dữ kiện đã có trong hồ sơ; không có nháp mới để xác nhận.", 409)
            normalized, seen = [], set()
            for candidate in selected:
                key = (candidate["entity_id"], candidate["field"])
                if key in seen:
                    raise CoreError("unresolved_conflict", "Hai nguồn khác nhau cho cùng một dữ kiện. Chỉ chọn giá trị đúng.", 409)
                seen.add(key)
                choice = conflict_choices.get(candidate["id"])
                if choice not in {None, "incoming", "current"}:
                    raise CoreError("invalid_choice", "Cần chọn giữ giá trị hiện tại hoặc dùng giá trị từ tệp.")
                if candidate["status"] == "conflict" and choice is None:
                    raise CoreError("conflict_choice_required", "Dữ kiện xung đột cần lựa chọn rõ trước khi lưu.", 409)
                if choice == "current":
                    if "current_value" not in candidate:
                        raise CoreError("invalid_choice", "Chưa có giá trị hồ sơ để giữ; hãy chọn một nguồn đúng.")
                    normalized.append((candidate, None))
                    continue
                raw = edits.get(candidate["id"], candidate["value"])
                value, value_type = typed_value(candidate["base_field"], raw, candidate.get("unit"), candidate.get("period"))
                if candidate["base_field"] == "revenue" and value["period"] != candidate["value"]["period"]:
                    raise CoreError("period_change_requires_intake", "Đổi kỳ doanh thu cần sửa Excel và đọc lại để tránh ghi nhầm kỳ.")
                normalized.append((candidate, {"field": candidate["field"], "value": value, "value_type": value_type,
                    "source": {**candidate["source"], "intake_id": intake_id, "candidate_id": candidate["id"],
                        "owner_confirmed": True, "owner_edited": candidate["id"] in edits, "unit": candidate.get("unit"), "period": candidate.get("period"),
                        "original_value": candidate["value"],
                        "confirmed_unit": value["currency"] if candidate["base_field"] == "revenue" else value.split(" ", 1)[1] if candidate["base_field"] == "net_quantity" else candidate.get("unit"),
                        "confirmed_period": value["period"] if candidate["base_field"] == "revenue" else candidate.get("period"),
                        "additional_locators": candidate.get("sources", [candidate["source"]])[1:]}}))
            # A new parser cannot rewrite a frozen old proposal or its owner's
            # choices. New writes still must not promote a source-proven name
            # contaminated by an operating count. Exact receipt replay already
            # returned above; a genuinely different owner edit follows normal
            # identity/CAS/binding checks below.
            from .extraction import proven_product_name_boundary_error
            original_texts = [payload.get("text") or ""]
            loaded_original_messages = False
            for candidate, fact in normalized:
                if (not fact or fact["field"] != "name"
                        or product_name_key(fact["value"]) != product_name_key(candidate["value"])):
                    continue
                source_hash = (candidate.get("source") or {}).get("text_sha256")
                if (not loaded_original_messages and source_hash
                        and not any(hashlib.sha256(text.encode("utf-8")).hexdigest() == source_hash for text in original_texts)):
                    conversations = (db.execute("SELECT payload_json FROM v04_conversations WHERE enterprise_id=? AND owner_id=?",
                        (enterprise_id, account_id)) if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='v04_conversations'").fetchone() else [])
                    for row in conversations:
                        conversation = json.loads(row[0])
                        original_texts.extend(message["text"] for message in conversation.get("messages", [])
                            if message.get("role") == "user" and message.get("intake_id") == intake_id
                            and isinstance(message.get("text"), str))
                    loaded_original_messages = True
                if any(proven_product_name_boundary_error(text, candidate) for text in original_texts):
                    error = CoreError("product_name_boundary_review_required",
                        "Tên sản phẩm trong nháp cũ đang lẫn thông tin tồn hoặc bán hàng. Chị sửa đúng tên, hoặc bỏ nháp này và trích lại câu gốc; chưa ghi thay đổi.", 409)
                    error.details = {"kind": "product_name_review_required", "candidate_id": candidate["id"],
                                     "intake_id": intake_id, "ssot_changed": False}
                    raise error
            actual = {x: x for x in targets}
            if "new_product" in targets:
                name = next((fact["value"] for cand, fact in normalized if cand["entity_id"] == "new_product" and fact and fact["field"] == "name"), None)
                if not name:
                    raise CoreError("product_name_required", "Chọn và xác nhận tên sản phẩm trước khi lưu dữ kiện sản phẩm mới.")
                original_name = next(cand["value"] for cand, fact in normalized if cand["entity_id"] == "new_product" and fact and fact["field"] == "name")
                matches = matching_owned_products(self.repo, account_id, enterprise_id, name, db)
                if matches:
                    error = CoreError("product_binding_required", "Tên đã xác nhận khớp hồ sơ sản phẩm hiện có. Chị chọn hồ sơ đúng để tạo nháp mới, rồi xác nhận riêng; chưa ghi thay đổi.", 409)
                    error.details = {"kind": "product_binding_required", "requested_name": name,
                                     "matched_entities": matches, "intake_id": intake_id}
                    raise error
                actual["new_product"] = self._create_entity(db, account_id, enterprise_id, "product", name)
                if product_name_key(original_name) == product_name_key(name):
                    self.repo._remember_name(db, actual["new_product"], original_name)
            if "new_enterprise" in targets:
                if db.execute("SELECT id FROM v03_entities WHERE enterprise_id=? AND created_by=? AND entity_type='enterprise'", (enterprise_id, account_id)).fetchone():
                    raise CoreError("enterprise_created_concurrently", "Hồ sơ doanh nghiệp vừa được tạo trong lượt khác. Hãy đọc lại tệp để đối chiếu.", 409)
                actual["new_enterprise"] = self._create_entity(db, account_id, enterprise_id, "enterprise", payload["enterprise_entity"]["name"])
            command = new_id("review_command")
            # Owner edits append a proposal revision. Facts and receipt reference
            # this effective hash, never the unedited observation's hash.
            original_heads = dict(heads)
            for candidate, fact in normalized:
                row = heads[candidate["id"]]
                if fact and candidate["id"] in edits:
                    row = self.review_store.amend(db, enterprise_id, intake_id, row, candidate, fact["value"], account_id, command)
                    heads[candidate["id"]] = row
                if fact:
                    fact["source"].update(review_proposal_id=row["proposal_id"], review_proposal_hash=row["proposal_hash"])
                self.review_store.bind(db, enterprise_id, intake_id, row["draft_subject_ref"], actual[candidate["entity_id"]], candidate["entity_type"], {"command_id": command, "candidate_id": candidate["id"]})
            grouped = {}
            for candidate, fact in normalized:
                if fact:
                    grouped.setdefault(candidate["entity_id"], []).append(fact)
            for target, facts in grouped.items():
                self.repo.propose_or_apply_facts(account_id, enterprise_id, actual[target], facts, expected_entity_versions[target],
                    "review-facts-" + digest([command, target]), reason="Chủ tài khoản xác nhận dữ kiện", db=db)
            applied, dispositions = [], []
            for candidate, fact in normalized:
                row = heads[candidate["id"]]
                alternatives = [p for p in original_heads.values() if not p["decision_action"] and p["group_id"] == row["group_id"] and p["generation"] == row["generation"]]
                resolution = new_id("review_resolution")
                effective = [heads[p["candidate_id"]]["proposal_hash"] for p in alternatives]
                db.execute("INSERT INTO core_review_group_resolutions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (enterprise_id, intake_id, row["group_id"], row["generation"], resolution,
                    command, row["proposal_id"], "keep_current" if fact is None else "apply_winner", digest(sorted(p["proposal_hash"] for p in alternatives)), digest(sorted(effective)), 1, now_iso()))
                ref = db.execute("SELECT entity_id,field,assertion_id,resolution_id,version FROM v03_current_facts WHERE enterprise_id=? AND entity_id=? AND field=?",
                    (enterprise_id, actual[candidate["entity_id"]], candidate["field"])).fetchone()
                fact_ref = dict(ref) if ref else None
                action = "kept_current" if fact is None else "committed"
                self.review_store.decision(db, enterprise_id, intake_id, row, action, account_id, "owner_explicit_confirmation", command, resolution, row["proposal_id"], fact_ref)
                dispositions.append({"candidate_id": candidate["id"], "proposal_id": row["proposal_id"], "proposal_hash": row["proposal_hash"],
                    "effective_value": fact["value"] if fact else candidate["current_value"], "action": action})
                if fact_ref and fact:
                    applied.append({**fact_ref, "proposal_id": row["proposal_id"], "proposal_hash": row["proposal_hash"]})
                    candidate["confirmed_value"] = fact["value"]
                for alternative in alternatives:
                    if alternative["candidate_id"] == candidate["id"]:
                        continue
                    self.review_store.decision(db, enterprise_id, intake_id, alternative, "superseded", account_id, "competing_value_resolved", command, resolution, row["proposal_id"])
                    dispositions.append({"candidate_id": alternative["candidate_id"], "proposal_id": alternative["proposal_id"], "action": "superseded"})
            # Project all independent, unselected groups as still pending.
            self.review_store.project(db, account_id, enterprise_id, payload)
            payload["saved_context"] = self.repo.get_context(account_id, enterprise_id, db=db)
            for entity in payload["saved_context"]["entities"]:
                if entity["entity_type"] == "enterprise":
                    payload["enterprise_entity"] = {k: entity[k] for k in ("id", "name", "version")}
                if payload.get("product") and entity["id"] == actual.get(payload["product"]["id"], payload["product"]["id"]):
                    payload["product"] = {k: entity[k] for k in ("id", "name", "version")}
            payload["saved_context"] = scoped_business_context(payload["saved_context"], payload.get("product"))
            payload["expected_entity_versions"] = {e["id"]: e["version"] for e in payload["saved_context"]["entities"]}
            for candidate in payload["candidates"]:
                if candidate["status"] in {"candidate", "conflict"} and candidate["entity_id"].startswith("new_"):
                    payload["expected_entity_versions"][candidate["entity_id"]] = 0
            pending = payload["review"]["pending_candidate_ids"]
            payload["status"] = "awaiting_confirmation" if pending else "confirmed"
            stamp = now_iso()
            if pending:
                payload.setdefault("partial_confirmations", []).append({"operation_id": operation_id, "confirmed_at": stamp,
                    "selected_candidate_ids": list(selected_fact_ids), "owner_id": account_id, "remaining_candidate_ids": list(pending), "model_called": False})
            else:
                payload["confirmed_at"] = stamp
            pending_product = bool(payload.get("product") and payload["product"]["id"].startswith("new_"))
            payload["product_binding"] = ({"state": "new_product_draft", "declared_name": payload["product"]["name"], "confirmed": False} if pending_product else
                {"state": "owner_confirmed" if payload.get("product") else "unbound", "entity_id": (payload.get("product") or {}).get("id"), "confirmed": bool(payload.get("product"))})
            payload["reused_context"] = reuse_metadata(payload["saved_context"])
            for task in payload["plan"]:
                task["status"] = "awaiting_confirmation" if pending and task["id"] in {"confirm_facts", "remember_facts"} else "completed"
            payload["business_plan"] = business_plan(payload["intent"], business_values(payload["saved_context"], payload.get("product")))
            payload["summary"] = address_text(f"Đã ghi nhớ {len(applied)} dữ kiện anh/chị xác nhận." + (f" Còn {len(pending)} dữ kiện ở nháp chưa lưu; anh/chị có thể kiểm tra tiếp tại đây." if pending else " Lần sau mình sẽ dùng lại hồ sơ này."), payload["intent"])
            payload["next_steps"] = self._next_steps(payload)
            self._confirmation_projection(payload, previous)
            receipt = self.review_store.finish(db, account_id, enterprise_id, payload, operation_id, request_hash, command, "confirm_selected", dispositions, applied)
            payload["confirmation_receipt"] = receipt
            db.execute("UPDATE v04_intakes SET status=?,payload_json=?,updated_at=? WHERE id=?", (payload["status"], json_text(payload), now_iso(), intake_id))
            return payload

    def get_review_receipt(self, account_id, enterprise_id, intake_id, operation_id, command_kind="confirm_selected"):
        with self.repo.connection() as db:
            payload = self._owned(account_id, enterprise_id, intake_id, db)
            receipt = self.review_store.receipt(db, enterprise_id, intake_id, account_id, operation_id, command_kind)
            return {"receipt": receipt, "current_view": payload}

    def dismiss_candidates(self, account_id, enterprise_id, intake_id, candidate_ids, operation_id,
                           reason="owner_dismissed", expected_review_revision=None, expected_proposal_hashes=None):
        if not isinstance(candidate_ids, list) or not candidate_ids or len(candidate_ids) > 40 or any(not isinstance(x, str) for x in candidate_ids) or len(set(candidate_ids)) != len(candidate_ids):
            raise CoreError("invalid_selection", "Chọn 1–40 dữ kiện đang chờ để bỏ.")
        if reason not in {"owner_dismissed", "not_relevant", "incorrect_observation"}:
            raise CoreError("invalid_reason", "Cần lý do bỏ dữ kiện rõ ràng.")
        request = {"id": intake_id, "selected": sorted(candidate_ids), "reason": reason, "review_revision": expected_review_revision, "proposal_hashes": expected_proposal_hashes}
        with self.repo.connection(write=True) as db:
            payload = self._owned(account_id, enterprise_id, intake_id, db)
            request_hash, prior = self.review_store.prior_receipt(db, enterprise_id, account_id, "dismiss_candidates", operation_id, request)
            if prior:
                payload["confirmation_receipt"] = self.review_store.receipt(db, enterprise_id, intake_id, account_id, operation_id, "dismiss_candidates")
                return payload
            if payload.get("review", {}).get("migration_required"):
                raise CoreError("review_migration_required", "Nháp cũ cần chuyển đổi trước khi thay đổi.", 409)
            candidates = {c["id"]: c for c in payload["candidates"]}
            if set(candidate_ids) - candidates.keys():
                raise CoreError("invalid_selection", "Dữ kiện không thuộc lượt đang rà.")
            heads = self.review_store.validate_heads(db, enterprise_id, payload, expected_review_revision, expected_proposal_hashes, candidate_ids)
            command, decisions = new_id("review_command"), []
            for key in candidate_ids:
                p = heads[key]
                self.review_store.decision(db, enterprise_id, intake_id, p, "dismissed", account_id, reason, command)
                decisions.append({"candidate_id": key, "proposal_id": p["proposal_id"], "action": "dismissed"})
            receipt = self.review_store.finish(db, account_id, enterprise_id, payload, operation_id, request_hash, command, "dismiss_candidates", decisions, [])
            payload["status"] = "awaiting_confirmation" if payload["review"]["pending_candidate_ids"] else "confirmed"
            payload["confirmation_receipt"] = receipt
            db.execute("UPDATE v04_intakes SET status=?,payload_json=?,updated_at=? WHERE id=?", (payload["status"], json_text(payload), now_iso(), intake_id))
            return payload

    @staticmethod
    def _next_steps(payload):
        return next_steps(payload)
