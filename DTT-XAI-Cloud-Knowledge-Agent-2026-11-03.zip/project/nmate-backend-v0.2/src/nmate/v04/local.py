"""Local 0.4A intake preview. Never reads provider keys or permits paid calls."""
import argparse
from pathlib import Path

import uvicorn


def main():
    parser = argparse.ArgumentParser(description="nMate 0.4A: ảnh mẫu, Excel, intent và SSOT; không gọi AI có phí")
    parser.add_argument("--port", type=int, default=8025)
    parser.add_argument("--data-dir", type=Path,
                        default=Path(__file__).resolve().parents[3] / ".data-v03a-fake")
    parser.add_argument("--task-delay", type=float, default=.6)
    parser.add_argument("--cookie-namespace", default="nmate_v04a")
    args = parser.parse_args()

    from nmate.v03.local import block_paid_and_external_calls
    guards = block_paid_and_external_calls()
    from nmate.v03.app import create_app
    args.data_dir.mkdir(parents=True, exist_ok=True)
    app = create_app(args.data_dir / "enterprise.sqlite3", port=args.port,
                     task_delay=args.task_delay, cookie_namespace=args.cookie_namespace,
                     enable_v04=True, mode="attachment_intake_mock_vision_no_paid_calls")

    @app.get("/api/v04/qa-status")
    async def qa_status():
        return {"version": "0.4A", "vision_mode": "explicit_hash_fixture_only",
                "excel_mode": "bounded_real_xlsx_parser", "intent_mode": "bounded_deterministic",
                "paid_calls": 0, **app.state.telemetry, **guards}

    app.router.routes.insert(-1, app.router.routes.pop())
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning", access_log=False)


if __name__ == "__main__":
    main()
