"""Disposable, network-free PDF text reader with OS resource limits.

The parent sends original bytes only to this local child. No document content
is sent to a provider, interpreted as commands, or written to temporary files.
"""
from __future__ import annotations

import json
import os
import socket
import sys

MAX_BYTES = 5 * 1024 * 1024
MAX_PAGES = 20
MAX_CHARS = 64_000
MAX_STREAM_BYTES = 2 * 1024 * 1024


def limit_resources():
    if os.name == 'nt':
        import ctypes
        from ctypes import wintypes

        class Basic(ctypes.Structure):
            _fields_ = [('PerProcessUserTimeLimit', ctypes.c_longlong),
                        ('PerJobUserTimeLimit', ctypes.c_longlong), ('LimitFlags', wintypes.DWORD),
                        ('MinimumWorkingSetSize', ctypes.c_size_t), ('MaximumWorkingSetSize', ctypes.c_size_t),
                        ('ActiveProcessLimit', wintypes.DWORD), ('Affinity', ctypes.c_size_t),
                        ('PriorityClass', wintypes.DWORD), ('SchedulingClass', wintypes.DWORD)]

        class IO(ctypes.Structure):
            _fields_ = [(name, ctypes.c_ulonglong) for name in (
                'ReadOperationCount', 'WriteOperationCount', 'OtherOperationCount',
                'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount')]

        class Extended(ctypes.Structure):
            _fields_ = [('BasicLimitInformation', Basic), ('IoInfo', IO),
                        ('ProcessMemoryLimit', ctypes.c_size_t), ('JobMemoryLimit', ctypes.c_size_t),
                        ('PeakProcessMemoryUsed', ctypes.c_size_t), ('PeakJobMemoryUsed', ctypes.c_size_t)]

        api = ctypes.WinDLL('kernel32', use_last_error=True)
        api.CreateJobObjectW.restype = wintypes.HANDLE
        api.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        api.GetCurrentProcess.restype = wintypes.HANDLE
        api.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        api.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        job = api.CreateJobObjectW(None, None)
        info = Extended()
        info.BasicLimitInformation.LimitFlags = 0x100 | 0x2  # process memory and CPU time
        info.BasicLimitInformation.PerProcessUserTimeLimit = 8 * 10_000_000
        info.ProcessMemoryLimit = 512 * 1024 * 1024
        if not job or not api.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)) or not api.AssignProcessToJobObject(job, api.GetCurrentProcess()):
            raise RuntimeError('PDF_RESOURCE_LIMIT_UNAVAILABLE')
        return job  # keep the handle until process exit
    import resource
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
    resource.setrlimit(resource.RLIMIT_CPU, (8, 8))
    return None


def read_pdf(raw):
    from pypdf.errors import PdfReadError, ParseError
    try:
        return _read_pdf(raw)
    except (PdfReadError, ParseError):
        # These are parser rejections. Import/setup/internal failures are kept
        # distinct by main(), so a valid file is not rejected by infrastructure.
        return {'ok': False, 'code': 'invalid_pdf'}


def _read_pdf(raw):
    from io import BytesIO
    from pypdf import PdfReader
    if not raw.startswith(b'%PDF-'):
        return {'ok': False, 'code': 'invalid_pdf'}
    reader = PdfReader(BytesIO(raw), strict=True)
    if reader.is_encrypted:
        return {'ok': False, 'code': 'encrypted_pdf'}
    if len(reader.pages) > MAX_PAGES:
        return {'ok': False, 'code': 'pdf_page_limit'}
    pages, count = [], 0
    for number, page in enumerate(reader.pages, 1):
        stream = page.get_contents()
        if stream is not None and len(stream.get_data()) > MAX_STREAM_BYTES:
            return {'ok': False, 'code': 'pdf_resource_limit'}
        text = page.extract_text() or ''
        count += len(text)
        if count > MAX_CHARS:
            return {'ok': False, 'code': 'pdf_text_limit'}
        pages.append({'page_number': number, 'text': text})
    return {'ok': True, 'pages': pages, 'page_count': len(pages),
            'status': 'text_extracted' if any(p['text'].strip() for p in pages) else 'no_readable_text'}


def main():
    def deny(*_args, **_kwargs):
        raise OSError('PDF worker has no network capability')
    socket.socket = deny
    socket.create_connection = deny
    socket.getaddrinfo = deny
    try:
        resource_handle = limit_resources()
        raw = sys.stdin.buffer.read(MAX_BYTES + 1)
        result = {'ok': False, 'code': 'pdf_size_limit'} if len(raw) > MAX_BYTES else read_pdf(raw)
        del resource_handle  # OS handle remains open until this child exits
    except MemoryError:
        result = {'ok': False, 'code': 'pdf_resource_limit'}
    except Exception:
        result = {'ok': False, 'code': 'pdf_reader_unavailable'}
    sys.stdout.buffer.write(json.dumps(result, ensure_ascii=False).encode('utf-8'))


if __name__ == '__main__':
    main()
