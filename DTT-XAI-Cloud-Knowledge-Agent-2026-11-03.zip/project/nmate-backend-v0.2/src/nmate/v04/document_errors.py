"""Bounded disposition for definitively rejected local document inputs.

A parser rejection is not a transport/commit verdict. Only the authorized
command boundary may attach its independently proven ``not_started`` state.
"""
import base64
import binascii
import hashlib
import re


REJECTED_DOCUMENT_CODES = frozenset({
    'invalid_pdf', 'encrypted_pdf', 'pdf_page_limit', 'pdf_text_limit', 'pdf_size_limit',
})


def document_error_message(filename, message):
    """A caller-owned, validated filename helps humans; exact IDs remain authority."""
    if not isinstance(filename, str) or not 1 <= len(filename) <= 160 or any(c in filename for c in '/\\\x00'):
        return message
    display = re.sub(r'[\x00-\x1f\x7f]', ' ', filename).strip()
    prefix = f'Tệp “{display}”: '
    return message if not display or message.startswith(prefix) else prefix + message


def annotate_document_rejection(exc, item, operation_id, index, count, raw=None):
    """Identify the exact submitted input, without filename, original or text."""
    if exc.code not in REJECTED_DOCUMENT_CODES:
        return
    if raw is None:
        # Signature validation can fail before validate_attachment returns its
        # decoded result. It has already checked the request's 5 MB byte limit.
        from .extraction import MAX_FILE
        encoded = item.get('data_base64') if isinstance(item, dict) else None
        if not isinstance(encoded, str) or len(encoded) > ((MAX_FILE + 2) // 3) * 4:
            return
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (ValueError, binascii.Error):
            return
    if not isinstance(raw, bytes) or not raw:
        return
    # Called only after scope/permission checks, for an exact submitted input.
    # The public disposition deliberately remains filename-free and bounded.
    exc.args = (document_error_message(item.get('filename'), str(exc)),)
    exc.details = {'kind': 'document_attachment_rejected', 'operation_id': operation_id,
        'attachment_index': index, 'attachment_count': count,
        'attachment_sha256': hashlib.sha256(raw).hexdigest(),
        'disposition': 'remove_from_pending', 'reason': exc.code}


def public_document_rejection(exc):
    """Expose removal authority only for a proven preflight, never uncertainty."""
    detail = getattr(exc, 'details', None)
    if (exc.code not in REJECTED_DOCUMENT_CODES or getattr(exc, 'commit_state', None) != 'not_started'
            or not isinstance(detail, dict) or detail.get('kind') != 'document_attachment_rejected'
            or detail.get('reason') != exc.code or detail.get('disposition') != 'remove_from_pending'
            or not isinstance(detail.get('operation_id'), str) or not 8 <= len(detail['operation_id']) <= 128
            or type(detail.get('attachment_count')) is not int or not 1 <= detail['attachment_count'] <= 3
            or type(detail.get('attachment_index')) is not int
            or not 0 <= detail['attachment_index'] < detail['attachment_count']
            or not isinstance(detail.get('attachment_sha256'), str)
            or re.fullmatch('[0-9a-f]{64}', detail['attachment_sha256']) is None):
        return None
    return {key: detail[key] for key in ('kind', 'operation_id', 'attachment_index',
            'attachment_count', 'attachment_sha256', 'disposition', 'reason')}
