"""Safe, bounded local file parsing and explicitly simulated vision fixtures.

Spreadsheet text is data, never a tool instruction. Formula values and external
relationships are never evaluated. Unrecognized photos are not "read" by a model.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
from io import BytesIO
import json
from pathlib import Path, PurePosixPath
import re
import unicodedata
import warnings
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile

from PIL import Image, UnidentifiedImageError

from nmate.v03.core import CoreError
from nmate.v03.domain_validation import QUANTITY_UNITS, product_identity_key, require_valid_field
from nmate.v03.field_registry import INGESTION_FIELD_SPECS, FINANCE_CURRENCY_UNITS

MAX_FILE = 5 * 1024 * 1024
MAX_TOTAL = 6 * 1024 * 1024
XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def normalize(value):
    return "".join(c for c in unicodedata.normalize("NFD", str(value).casefold().replace("đ", "d"))
                   if unicodedata.category(c) != "Mn").strip()


def product_name_key(value):
    """Exact identity comparison without changing a stored display spelling.

    Case, Unicode composition and repeated whitespace are presentation details.
    Accents and every word remain significant: no prefix or fuzzy-name match.
    """
    return product_identity_key(value)


# Stable fields are deliberately small. A column with an unknown field cannot
# invent an SSOT schema or smuggle instructions into the orchestration layer.
FIELD_SPECS = INGESTION_FIELD_SPECS
ALIASES = {
    "ten co so": "trading_name", "ten giao dich": "trading_name", "trading name": "trading_name",
    "ten san pham": "name", "san pham": "name", "product name": "name",
    "ma san pham": "product_code", "ma hang": "product_code", "sku": "product_code",
    "luong tinh": "net_quantity", "khoi luong tinh": "net_quantity", "bao bi": "packaging",
    "thanh phan": "ingredients", "xuat xu": "origin_country", "quoc gia xuat xu": "origin_country",
    "quan ly ban hang": "sales_management", "quan ly ton kho": "inventory_management",
    "so lao dong": "employee_count", "so nhan vien": "employee_count", "doanh thu": "revenue", "annual_revenue": "revenue",
    "muc tieu": "business_goal",
}
# A field caption is not product identity, with or without a comma. Both
# explicitly declared and naturally mentioned names use this same boundary.
PRODUCT_KIND = r"(?:trà|tra|mứt|mut|bột|bot|bánh|banh|miến|mien|chanh)"
PRODUCT_NAME_END = (
    r"(?=\s+(?:đi|sang|gửi|muốn|xuất\s+khẩu|vào|tới|đến|cần|có\s+(?:cần|phải)|phải|thì|giúp|cải\s+thiện|"
    r"hộp|túi|gói|chai|FDA|nhãn|prior\s+notice|khối\s+lượng\s+tịnh|lượng\s+tịnh|net\s+weight|"
    r"thành\s+phần|xuất\s+xứ|bao\s+bì|mã(?:\s+(?:sản\s+phẩm|hàng))?|SKU)\b|"
    r"\s+\d{1,12}(?:[.,]\d{1,6})?\s*(?:kg|mg|g|ml|l|oz|lb|hộp|túi|gói|chai)\b|"
    r"\s+(?:(?:tồn\s+(?:trên\s+)?sổ|(?:đếm\s+)?thực\s+tế)\s*(?:là|:|：)?\s*\d)|[,;.:：\n?]|$)"
)
# Product identity ends before a business predicate, including a subordinate
# condition. A count, sales rate or decision verb is never part of a name.
# This grammar is shared by proposed identities and read-only references;
# callers must not derive an SSOT assertion merely from a product reference.
PRODUCT_OBSERVED_COUNT = (
    r"\d{1,12}(?:[.,]\d{1,6})?\s*"
    r"(?:kg|mg|g|ml|l|hộp|túi|gói|chai|thùng|cái|chiếc|sản\s+phẩm|sp)\b"
)
PRODUCT_OPERATION_END = (
    r"\s+(?:(?:khi|nếu|trong\s+khi)\s+)?(?:"
    r"(?:chỉ\s+)?còn\s+(?:(?:trong\s+)?kho\b|\d)|"
    r"(?:(?:hiện|đang)\s+)?tồn\s+(?:(?:hiện\s+tại|là|khoảng)\s+)?"
    r"(?::|：)?\s*" + PRODUCT_OBSERVED_COUNT + r"|"
    r"tồn\s*(?::|：)\s*" + PRODUCT_OBSERVED_COUNT + r"|"
    r"tồn\s+(?:kho|trên\s+sổ)\b|"
    r"(?:đã\s+|đang\s+)?bán\s+(?:được\s+|khoảng\s+)?\d|"
    r"sắp\s+hết\s+hàng\b|"
    r"(?:cần|nên)\s+(?:nhập|đặt)\b|"
    r"(?:nhập|đặt)\s+thêm\b|"
    r"(?:đếm\s+)?thực\s+tế\s*(?:là|:|：)?\s*\d)"
    r"|\s+để\s+(?:lập\s+(?:nháp|hồ\s+sơ)|cập\s+nhật\s+hồ\s+sơ|đối\s+chiếu|kiểm\s+tra|nghiên\s+cứu)\b"
)
PRODUCT_NAME_END = "(?=" + PRODUCT_OPERATION_END + ")|" + PRODUCT_NAME_END


def named_profile_lookup(text):
    """A bounded read-only lookup names a subject, never a new SSOT assertion.

    Deictic requests intentionally keep an explicitly selected/conversation
    profile. An unknown named subject cannot borrow that older selection.
    """
    if not isinstance(text, str) or len(text) > 4000:
        return None
    comparison = unicodedata.normalize("NFC", text)
    match = re.search(r"\b(?:xem|đọc)\s+(?:lại\s+)?hồ\s+sơ\s+(?P<value>[^,;.:：\n!?]{1,250}?)"
                      + "(?=(?:" + PRODUCT_OPERATION_END + r")|[,;.:：\n!?]|$)", comparison, re.IGNORECASE)
    if not match:
        return None
    value = match.group("value").strip()
    if comparison != text:
        # Compare composition, preserve the literal owner's spelling. Boundaries
        # occur between lexical tokens, not inside a composed grapheme.
        prefixes = {"start": comparison[:match.start("value")], "end": comparison[:match.end("value")]}
        offsets = {}
        for offset in range(len(text) + 1):
            prefix = unicodedata.normalize("NFC", text[:offset])
            for key, target in prefixes.items():
                if prefix == target:
                    offsets[key] = offset
            if len(offsets) == 2:
                break
        if len(offsets) == 2:
            value = text[offsets["start"]:offsets["end"]].strip()
    if normalize(value) in {"nay", "da chon", "dang chon", "vua chon", "hien tai", "cua chi", "cua toi"}:
        return None
    return value or None


def _name_assertion_role(text, match, *, explicit, facts):
    """Separate a private identity proposal from a read-only product mention.

    This is deliberately bounded grammar, not a product resolver. Only the
    resolver may bind an existing, authorized exact identity. Roles never
    establish an alias or a confirmed business fact.
    """
    if explicit:
        return "declared_identity"
    # A decimal point inside an observed quantity is not a sentence boundary.
    # Otherwise "tồn 30.5 kg" loses its unit before the shared predicate can
    # establish that this is a reference rather than a new identity proposal.
    boundaries = list(re.finditer(r"[;\n]|(?<!\d)\.(?!\d)", text))
    start = max((mark.end() for mark in boundaries if mark.end() <= match.start()), default=0)
    end = min((mark.start() for mark in boundaries if mark.start() >= match.end()), default=len(text))
    clause = normalize(text[start:end])
    if named_profile_lookup(text[start:end]):
        return "product_reference"
    # Facts associated with the subject make it a proposed identity, even when
    # the same sentence also asks FDA/label questions. It remains owner review.
    has_facts = any(item["field"] in {"product_code", "net_quantity", "packaging", "ingredients", "origin_country"}
                    and start <= item["source"]["start_offset"] < end for item in facts)
    if has_facts:
        return "subject_with_facts"
    if re.search(PRODUCT_OPERATION_END, text[start:end], re.IGNORECASE):
        # The same grammar that ends the identity span also establishes why
        # it is a read-only operating subject. A second keyword-only list used
        # to miss bare stock/sales counts and elevate that subject to a fact.
        return "product_reference"
    if re.search(r"\b(?:kiem ke|doi chieu|ton kho|ton tren so|nhap them|dat them|nhap hang|doc tai lieu|doc tep|doc file|bao bi|dong goi|nhan san pham)\b", clause):
        return "product_reference"
    return "intended_identity"


def _explicit_field_edit(text, match):
    """A literal edit command is a proposal, not an observed current value."""
    start = max((text.rfind(mark, 0, match.start()) for mark in ".;,\n"), default=-1) + 1
    prefix = normalize(text[start:match.start()])
    caption = text[match.start():match.start("value")]
    return bool(re.search(r"\b(?:doi|sua|chinh|cap nhat)(?:\s+(?:lai|gia tri|du kien|truong))*\s*$", prefix)
                and re.search(r"[:：]\s*$", caption))


def _field_is_requested_change(text, match, value):
    """A requested outcome is not a declaration of the current field value."""
    start = max((text.rfind(mark, 0, match.start()) for mark in ".;,\n"), default=-1) + 1
    prefix = normalize(text[start:match.start()])
    desired_action = re.search(r"\b(?:cai thien|toi uu|thiet ke|thay doi|doi|gop y|danh gia|ra soat)\b", prefix)
    # A command to prepare a known literal for owner review is distinct from a
    # goal to improve it. Past inspection can introduce an observed value too.
    if not desired_action and (re.search(r"\b(?:ghi nho|luu|bo sung|cap nhat)\b", prefix)
            or re.search(r"\b(?:da|vua)\s+(?:kiem tra|xem|xem lai)\b", prefix)):
        return False
    if (re.match(r"(?:can|nen|phai|co nen|co can|lam sao|the nao|la gi)\b", normalize(value))
            or re.search(r"\b(?:co phu hop|co can|co nen|the nao|loai nao|can thay doi|nen dung)\b", normalize(value))):
        return True
    if _explicit_field_edit(text, match):
        return False
    # Determine the action's target, rather than adding one filler phrase per
    # sentence. A named product introduced after an FDA/label question owns its
    # following literal attributes. A field named before that subject remains
    # the action target ("đổi sang bao bì ...", "cải thiện bảo quản ... bao bì").
    actions = list(re.finditer(
        r"\b(?:muon|nen|can|hay|xin|giup|hoi|tu van|cai thien|toi uu|thiet ke|thay doi|doi|"
        r"kiem tra|gop y|nhan xet|danh gia|ra soat|xem|xem lai|dong goi|tang|giam)\b", prefix))
    if not actions:
        return False
    after_action = prefix[actions[-1].end():]
    subject = re.search(r"\b(?:tra|mut|bot|banh|mien|chanh)\s+(?!(?:cuu|chinh sach|thong tin)\b)\w|"
                        r"\bsan pham\s*(?::|la)?\s+\w", after_action)
    if subject and not re.search(r"\b(?:bao bi|luong tinh|khoi luong tinh|thanh phan|xuat xu)\b",
                                 after_action[:subject.start()]):
        return False
    return True


def _quantity_is_business_measure(text, match):
    """Stock, sales and shipment mass are not the product's net content."""
    start = max((text.rfind(mark, 0, match.start()) for mark in ".;,\n"), default=-1) + 1
    prefix = normalize(text[start:match.start()])
    suffix = normalize(text[match.end():match.end() + 40])
    return bool(re.search(r"\b(?:ton|kho|kiem ke|dem|ban|nhap|dat|giao|lo hang|don hang|van chuyen)\b", prefix)
                or re.match(r"(?:moi|hang|mot|1)\s+(?:ngay|tuan|thang|quy|nam)\b", suffix))


def typed_value(field, value, unit=None, period=None):
    if field not in FIELD_SPECS:
        raise CoreError("unsupported_field", "Trường dữ kiện chưa được hỗ trợ trong mẫu 0.4A.")
    label, _entity, kind = FIELD_SPECS[field]
    if value is None or value == "":
        raise CoreError("empty_value", f"{label} chưa có giá trị; không tự xóa dữ kiện đã biết.")
    if kind == "integer":
        if isinstance(value, bool) or not re.fullmatch(r"\d{1,7}", str(value).strip()):
            raise CoreError("invalid_value", f"{label} cần là số nguyên không âm.")
        parsed = int(value)
        require_valid_field(field, parsed)
        return parsed, kind
    if kind == "object":
        if isinstance(value, dict):
            unit, period, amount = value.get("currency"), value.get("period"), value.get("amount")
        else:
            amount = value
        currency = str(unit or "").strip().upper()
        period = str(period or "").strip()
        if currency not in FINANCE_CURRENCY_UNITS or not re.fullmatch(r"20\d{2}(?:-(?:0[1-9]|1[0-2]|Q[1-4]))?", period):
            raise CoreError("ambiguous_financial_value", "Doanh thu cần đơn vị tiền tệ VND/USD/EUR/JPY và kỳ YYYY, YYYY-MM hoặc YYYY-Q1–Q4.")
        if isinstance(amount, bool) or not re.fullmatch(r"\d{1,15}(?:\.\d{1,2})?", str(amount).strip()):
            raise CoreError("ambiguous_financial_value", "Doanh thu cần số không âm, không có dấu phân cách hàng nghìn.")
        number = float(amount) if "." in str(amount) else int(amount)
        return {"amount": number, "currency": currency, "period": period}, kind
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise CoreError("invalid_value", f"{label} cần nội dung văn bản.")
    result = str(value).strip()
    if field == "net_quantity":
        # The value shown to the owner includes its unit. A numeric edit keeps
        # that unit; it must never become a dimensionless SSOT quantity.
        match = re.fullmatch(r"(\d{1,12}(?:[.,]\d{1,6})?)\s*([^\d\W_]+(?:\s+[^\d\W_]+)?)?", result)
        declared_unit = str(unit or "").strip()
        if not match or float(match.group(1).replace(",", ".")) <= 0:
            raise CoreError("invalid_quantity", "Lượng tịnh cần số lớn hơn 0 và đơn vị, ví dụ 100 g.")
        value_unit = match.group(2) or declared_unit
        if value_unit.casefold() not in QUANTITY_UNITS:
            raise CoreError("quantity_unit_required", "Lượng tịnh cần đơn vị rõ, ví dụ g, kg hoặc ml; hãy kiểm tra lại dữ kiện.")
        if declared_unit and normalize(declared_unit) != normalize(value_unit):
            raise CoreError("quantity_unit_conflict", "Đơn vị lượng tịnh khác đơn vị trong Excel; hãy sửa tệp và đọc lại để tránh nhầm đơn vị.")
        result = match.group(1) + " " + value_unit
    if not result or len(result) > (250 if field in {"name", "trading_name"} else 2000):
        raise CoreError("invalid_value", f"{label} quá dài hoặc chưa có nội dung.")
    require_valid_field(field, result)
    return result, "string"


def extract_enterprise_text(text):
    """Propose an explicitly self-declared trading name with exact provenance.

    Do not infer a legal name, registration, address or an enterprise rename.
    Unrelated businesses, hypothetical statements and ambiguous declarations
    produce no candidate. Product identity parsing remains a separate scope.
    """
    if not isinstance(text, str) or not text.strip() or len(text) > 4000:
        return []
    end = (r"(?=\s+(?:của\s+(?:tôi|chị|anh|em|mình)|ở|tại|đang|hiện|chuyên|muốn)\b"
           r"|\s*\(|[,;.:：\n?]|$)")
    patterns = [
        r"\b(?:tên\s+cơ\s+sở|tên\s+giao\s+dịch)\s*(?:là\s+|:\s*)(?P<value>[^,;.:：\n?]{1,250}?)" + end,
        r"\b(?:cơ\s+sở|công\s+ty|doanh\s+nghiệp|cửa\s+hàng|xưởng)\s+(?P<value>[^,;.:：\n?]{1,250}?)"
        r"(?=\s+của\s+(?:tôi|chị|anh|em|mình)(?:\s+(?:đang|hiện|ở|tại|chuyên|muốn)\b|\s*[,;.:：\n]|\s*$))",
        r"\b(?:tôi|chị|anh|em|mình)\s+là\s+chủ\s+(?:cơ\s+sở|công\s+ty|doanh\s+nghiệp|cửa\s+hàng|xưởng)\s+"
        r"(?P<value>[^,;.:：\n?]{1,250}?)" + end,
    ]
    found = []
    for pattern in patterns:
        for match in re.finditer(pattern, text, re.IGNORECASE):
            start = max((text.rfind(mark, 0, match.start()) for mark in ".;\n"), default=-1) + 1
            prefix = normalize(text[start:match.start()])
            if "?" in text[start:match.end()] or re.search(
                    r"\b(?:khong|chua|dung|neu|gia su|vi du|chang|co phai|cua ho|cua nguoi khac|hay dat|doi|de xuat|goi y)\b", prefix):
                continue
            value = match.group("value").strip()
            if not value or re.search(r"\b(?:la gi|ten gi|khong|chua|hay|hoac)\b", normalize(value)):
                continue
            # Keep a positive declaration separate from the subsequent question.
            # A question about a name alone is not an assertion of that name.
            tail = text[match.end():].split(".", 1)[0].split(";", 1)[0].split("\n", 1)[0]
            if tail.lstrip().startswith("?"):
                continue
            value, kind = typed_value("trading_name", value)
            found.append({"entity_type": "enterprise", "field": "trading_name",
                "label_vi": FIELD_SPECS["trading_name"][0], "value": value, "value_type": kind,
                "unit": None, "period": None, "confidence": "explicit_user_declaration_unverified",
                "note_vi": "Tên giao dịch do chủ cơ sở khai; không đổi tên pháp lý hoặc tên tài khoản.",
                "source": {"kind": "server_text_extract", "simulation": False,
                    "locator": "Tin nhắn hiện tại", "quote": match.group(0), "value_quote": value,
                    "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                    "start_offset": match.start(), "end_offset": match.end(),
                    "review_state": "owner_confirmation_required"}})
    values = {product_name_key(item["value"]) for item in found}
    return found[:1] if len(values) == 1 else []


def extract_business_text(text, *, include_name_mentions=True):
    """Independent enterprise and product observations for one private draft."""
    return extract_enterprise_text(text) + extract_product_text(text, include_name_mentions=include_name_mentions)


def proven_product_name_boundary_error(text, candidate):
    """Positive evidence for a pending old name, never a historical rewrite.

    A typed operational predicate crosses the stored name's literal span. The
    original message hash, quote and offsets must all agree. Absence from a new
    parser, unknown names, negations and explicit literal names prove nothing.
    This guard does not decide or archive a proposal; a new confirmation may
    ask the owner to correct it while preserving every original review record.
    """
    value, source = candidate.get("value"), candidate.get("source") or {}
    if (not isinstance(text, str) or len(text) > 4000 or candidate.get("field") != "name"
            or not isinstance(value, str) or not value
            or source.get("kind") != "server_text_extract"
            or source.get("text_sha256") != hashlib.sha256(text.encode("utf-8")).hexdigest()):
        return False
    start, end, quote = source.get("start_offset"), source.get("end_offset"), source.get("quote")
    if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text)
            or not isinstance(quote, str) or text[start:end].strip() != quote
            or source.get("value_quote", value) != value or quote.count(value) != 1):
        return False
    value_start = text.find(value, start, end)
    if value_start < 0:
        return False
    value_end = value_start + len(value)
    clause_start = max((mark.end() for mark in re.finditer(r"[;\n]|(?<!\d)\.(?!\d)", text[:value_start])), default=0)
    prefix = normalize(text[clause_start:value_start])
    if (source.get("assertion_role") == "declared_identity"
            or re.search(r"\b(?:ten san pham\s*(?:la|:)|(?:toi|chi|anh|em|minh)\s+co(?:\s+san pham)?)$", prefix)
            or re.search(r"\b(?:khong|chua|dung|neu|gia su|vi du|chang|co phai)\b", prefix)):
        return False
    for predicate in re.finditer(PRODUCT_OPERATION_END, text, re.IGNORECASE):
        if not value_start < predicate.start() < value_end or not re.search(r"\d", predicate.group(0)):
            continue
        name_prefix = text[value_start:predicate.start()].strip()
        if re.match(r"^" + PRODUCT_KIND + r"\s+\S", name_prefix, re.IGNORECASE):
            return True
    return False


def extract_product_text(text, *, include_name_mentions=True, include_product_references=False,
                         reject_multiple_products=False):
    """Read current-message literal proposals, never assistant prose.

    This bounded parser creates unconfirmed observations only. It does not
    interpret hypothetical examples, negated declarations, financial data,
    quantities without units or statements about several product names. Pure
    operational references are excluded from facts; the identity resolver may
    request their separate role without turning them into SSOT assertions.
    Offsets and original case provide inspectable private provenance.
    """
    if not isinstance(text, str) or not text.strip() or len(text) > 4000:
        return []
    if re.fullmatch(r"\s*tên\s+sản\s+phẩm\s*:\s*[^?]+\?\s*", text, re.IGNORECASE):
        return []
    explicit_name = r"(?:tên\s+sản\s+phẩm\s*(?:là\s*|:\s*)|(?:tôi|chị|anh|em|mình)\s+có\s+sản\s+phẩm\s+|(?:tôi|chị|anh|em|mình)\s+có\s+(?=" + PRODUCT_KIND + r"\b)|sản\s+phẩm\s*:\s*)(?P<value>[^,;.:：\n?]{1,250}?)" + "(?:" + PRODUCT_NAME_END + ")"
    patterns = {
        "product_code": r"\b(?:mã\s+(?:sản\s+phẩm|hàng)|mã|SKU)\s*(?::\s*|là\s+)?(?P<value>[A-Za-z0-9][A-Za-z0-9._/-]{1,63})\b",
        "ingredients": r"(?:thành\s+phần|ingredients)\s*(?:là\s*|:\s*)?(?P<value>[^;.\n]{1,2000}?)(?=,\s*(?:xuất\s+xứ|bao\s+bì|lượng\s+tịnh|khối\s+lượng)|[;.\n]|$)",
        "origin_country": r"(?:xuất\s+xứ|origin\s+country)\s*(?:là\s*|:\s*)?(?P<value>[^,;.\n]{1,200})",
        "packaging": r"bao\s+bì\s*(?:là\s*|:\s*)?(?P<value>[^,;.\n]{1,500})",
        "net_quantity": r"(?:lượng\s+tịnh|khối\s+lượng\s+tịnh|net\s+weight)\s*(?:là\s*|:\s*)?(?P<value>\d{1,12}(?:[.,]\d{1,6})?\s*(?:kg|mg|g|ml|l|oz|lb))\b",
    }
    found = []
    identity_subject_keys = set()
    ambiguous_product_subject = False

    def append(field, match, raw_value=None, group="value", *, explicit=False):
        nonlocal ambiguous_product_subject
        start = max((text.rfind(mark, 0, match.start()) for mark in ".;\n"), default=-1)+1
        prefix = normalize(text[start:match.start()])
        if ("?" in text[start:match.end()] or re.search(r"\b(?:khong|chua|dung|neu|gia su|vi du|chang|co phai)\b", prefix)):
            return
        raw_value = raw_value if raw_value is not None else match.group(group).strip()
        if not raw_value or raw_value.endswith("?"):
            return
        if field == "name" and not explicit and raw_value.casefold().startswith("tra "):
            # Unaccented product references retain their spelling/identity, but
            # the verb in "kiểm tra"/"tra cứu" is not a food noun. Inspecting
            # overlapping food heads still lets the later "Trà Sen" be read.
            if re.search(r"\b(?:kiem|thanh|dieu|truy|ra)\s*$", prefix) or re.match(
                    r"tra\s+(?:cuu|chinh\s+sach|thong\s+tin|ket\s+qua)\b", normalize(raw_value)):
                return
        if field in {"packaging", "ingredients", "origin_country", "net_quantity"} and _field_is_requested_change(text, match, raw_value):
            return
        if field == "name" and any(item["field"] != "name" and
                item["source"]["start_offset"] <= match.start() < item["source"]["end_offset"] for item in found):
            # Food words in an already classified ingredient/packaging/origin
            # span are values of that field, not a second product declaration.
            return
        if field == "name" and re.search(r"\b(?:co so|cong ty|doanh nghiep|cua hang|xuong|ten giao dich)\s*(?::|la)?\s*$", normalize(text[:match.start()])):
            # A business introduction may contain a food word in its legal or
            # trading name. It is not a second product declaration.
            return
        if field == "name" and re.search(r"\b(?:moi|hang)\s+(?:ngay|tuan|thang|quy|nam)\b|\b(?:mot|1)\s+thang\b", normalize(raw_value)):
            # A sales rate such as '300 hộp trà mỗi tháng' identifies a category,
            # not a named product. Do not turn it into a dossier/history title.
            return
        if field == "name" and re.fullmatch(PRODUCT_KIND + r"\s+(?:không|gì|nào|thế|sao|chưa|có)", raw_value, re.IGNORECASE):
            # A food category followed only by a question particle is not a
            # named identity ("giữ hương trà không?"). Longer literal names,
            # such as "Trà Không Độ", remain intact and owner-reviewable.
            return
        if field == "name" and re.search(r"\b(?:và|hoặc|hay)\s+" + PRODUCT_KIND + r"\b", raw_value, re.IGNORECASE):
            # One product per draft. An enumerated/alternative subject must
            # never become a single compound product or receive shared facts.
            # Only a valid subject span reaches here: food words in a declared
            # ingredient/packaging field were already excluded above.
            ambiguous_product_subject = True
            return
        if field == "packaging":
            simple_package = re.fullmatch(r"(?P<package>hộp|túi|gói|chai)\s+\d{1,12}(?:[.,]\d{1,6})?\s*(?:kg|mg|g|ml|l|oz|lb)", raw_value, re.IGNORECASE)
            if simple_package:
                raw_value = simple_package.group("package")
        try:
            value, value_type = typed_value(field, raw_value)
        except CoreError:
            return
        quote = match.group(0).strip()
        role = (_name_assertion_role(text, match, explicit=explicit, facts=found) if field == "name"
                else "explicit_field_edit" if _explicit_field_edit(text, match) else "declared_value")
        if field == "name":
            identity_subject_keys.add(product_name_key(value))
        if role == "product_reference" and not include_product_references:
            return
        found.append({"entity_type": "product", "field": field, "label_vi": FIELD_SPECS[field][0],
            "value": value, "value_type": value_type, "unit": None, "period": None,
            "confidence": ("explicit_user_declaration_unverified" if role in {"declared_identity", "declared_value"}
                           else "product_reference_not_assertion" if role == "product_reference"
                           else "explicit_field_edit_unverified" if role == "explicit_field_edit"
                           else "user_identity_proposal_unverified"),
            "source": {"kind": "server_text_extract", "simulation": False,
                       "locator": "Tin nhắn hiện tại", "quote": quote, "value_quote": raw_value,
                       "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                       "start_offset": match.start(), "end_offset": match.end(),
                       "assertion_role": role,
                       "review_state": "owner_confirmation_required"}})

    for field, pattern in patterns.items():
        for match in re.finditer(pattern, text, re.IGNORECASE):
            append(field, match)
    explicit_matches = list(re.finditer(explicit_name, text, re.IGNORECASE))
    for match in explicit_matches:
        append("name", match, explicit=True)
    # In a question, an explicitly named food is still only a proposed product
    # identity. Stop before destination, quantity and regulation words; never
    # infer ingredients, origin, eligibility or a confirmed SSOT identity.
    natural_matches = []
    if include_name_mentions:
        natural_name = r"(?P<value>" + PRODUCT_KIND + r"\s+[\wÀ-ỹ][^,;.:：\n?]{0,160}?)" + "(?:" + PRODUCT_NAME_END + ")"
        compiled_name = re.compile(natural_name, re.IGNORECASE)
        natural_matches = [match for head in re.finditer(r"\b" + PRODUCT_KIND + r"\b", text, re.IGNORECASE)
                           if (match := compiled_name.match(text, head.start())) is not None]
        for match in natural_matches:
            if any(item["field"] == "name" and item["source"]["start_offset"] <= match.start() < item["source"]["end_offset"]
                   for item in found):
                continue
            append("name", match)
    if any(item["field"] == "name" for item in found):
        for match in re.finditer(r"(?P<value>\d{1,12}(?:[.,]\d{1,6})?\s*(?:kg|mg|g|ml|l|oz|lb))\b", text, re.IGNORECASE):
            if not _quantity_is_business_measure(text, match):
                append("net_quantity", match)
    for match in re.finditer(r"(?P<package>hộp|túi|gói|chai)\s+(?P<value>\d{1,12}(?:[.,]\d{1,6})?\s*(?:kg|mg|g|ml|l|oz|lb))\b", text, re.IGNORECASE):
        if not _quantity_is_business_measure(text, match):
            append("net_quantity", match)
            append("packaging", match, match.group("package"))
    values = {}
    for item in found:
        value_key = product_name_key(item["value"]) if item["field"] == "name" else str(item["value"])
        values.setdefault(item["field"], set()).add(value_key)
    # Conflicting declarations are not silently resolved by a regular expression.
    if len(identity_subject_keys) > 1 or ambiguous_product_subject:
        if reject_multiple_products:
            raise CoreError("multiple_products_not_supported", "Chị đang nhắc nhiều sản phẩm. Mỗi lượt trích nhận một sản phẩm; chị gửi riêng từng sản phẩm để tránh gộp nhầm dữ kiện.", 409)
        return []
    result, seen = [], set()
    # Keep the established review order while parsing field spans first so
    # ingredients and packaging cannot masquerade as product identities.
    for item in sorted(found, key=lambda fact: fact["field"] != "name"):
        if item["field"] == "product_code" and not values.get("name"):
            continue
        key = (item["field"], product_name_key(item["value"]) if item["field"] == "name" else str(item["value"]))
        if len(values[item["field"]]) == 1 and key not in seen:
            result.append(item)
            seen.add(key)
    return result


def _xml(data):
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise CoreError("unsafe_workbook", "Không chấp nhận XML có khai báo thực thể.")
    try:
        return ET.fromstring(data)
    except ET.ParseError as exc:
        raise CoreError("invalid_workbook", "Cấu trúc Excel bị lỗi; hãy lưu lại dưới dạng .xlsx.") from exc


def parse_workbook(raw):
    """Read key/value rows, retaining the exact source sheet and value cell."""
    output, notices = [], []
    try:
        with ZipFile(BytesIO(raw)) as archive:
            entries = archive.infolist()
            if len(entries) > 100 or sum(x.file_size for x in entries) > 12 * 1024 * 1024:
                raise CoreError("workbook_limit", "Excel vượt giới hạn 100 phần hoặc 12 MB sau giải nén.")
            names = [x.filename for x in entries]
            if len(names) != len(set(names)) or any(x.flag_bits & 1 or x.file_size > 4 * 1024 * 1024 or
                    (x.file_size > 200000 and x.file_size > max(x.compress_size, 1) * 200) for x in entries):
                raise CoreError("unsafe_workbook", "Excel được mã hóa, trùng phần hoặc có tỉ lệ nén bất thường.")
            if any(PurePosixPath(n).is_absolute() or ".." in PurePosixPath(n).parts or "\\" in n for n in names):
                raise CoreError("unsafe_workbook", "Đường dẫn bên trong Excel không an toàn.")
            if any("vbaproject" in n.casefold() or "externallink" in n.casefold() or "embeddings/" in n.casefold() for n in names):
                raise CoreError("unsafe_workbook", "0.4A không nhận Excel có macro, liên kết ngoài hoặc đối tượng nhúng.")
            for name in names:
                if name.endswith(".rels"):
                    for item in _xml(archive.read(name)):
                        if item.get("TargetMode", "").casefold() == "external":
                            raise CoreError("unsafe_workbook", "Hãy bỏ liên kết ngoài khỏi Excel trước khi gửi.")
            if not {"xl/workbook.xml", "xl/_rels/workbook.xml.rels"}.issubset(names):
                raise CoreError("invalid_workbook", "Tệp chưa phải workbook .xlsx hợp lệ.")
            types = archive.read("[Content_Types].xml") if "[Content_Types].xml" in names else b""
            if b"macroEnabled" in types:
                raise CoreError("unsafe_workbook", "Không nhận workbook có macro.")
            strings = []
            if "xl/sharedStrings.xml" in names:
                for item in _xml(archive.read("xl/sharedStrings.xml")):
                    strings.append("".join(t.text or "" for t in item.iter("{" + NS["s"] + "}t")))
                if len(strings) > 4000:
                    raise CoreError("workbook_limit", "Excel có quá nhiều chuỗi văn bản.")
            rels = {r.get("Id"): r.get("Target", "") for r in _xml(archive.read("xl/_rels/workbook.xml.rels"))}
            sheets = _xml(archive.read("xl/workbook.xml")).findall("s:sheets/s:sheet", NS)
            if len(sheets) > 8:
                raise CoreError("workbook_limit", "0.4A nhận tối đa 8 trang tính.")
            count = 0
            for sheet in sheets:
                name = sheet.get("name", "Trang tính")
                target = rels.get(sheet.get("{" + REL + "}id"), "")
                path = target.lstrip("/") if target.startswith("/") else "xl/" + target
                if not path.startswith("xl/worksheets/") or path not in names:
                    raise CoreError("invalid_workbook", "Không đọc được đường dẫn trang tính.")
                if sheet.get("state", "visible") != "visible":
                    notices.append(f"Đã bỏ qua trang tính ẩn: {name}.")
                    continue
                rows = []
                for row in _xml(archive.read(path)).findall("s:sheetData/s:row", NS):
                    values = {}
                    for cell in row.findall("s:c", NS):
                        count += 1
                        if count > 2000:
                            raise CoreError("workbook_limit", "0.4A nhận tối đa 2.000 ô dữ liệu.")
                        ref = cell.get("r", "")
                        if not re.fullmatch(r"[A-Z]{1,3}[1-9]\d{0,5}", ref):
                            raise CoreError("invalid_workbook", "Địa chỉ ô Excel không hợp lệ.")
                        if cell.find("s:f", NS) is not None:
                            raise CoreError("formula_not_supported", "Excel có công thức. Hãy tạo bản sao chỉ chứa giá trị trước khi gửi; hệ thống không chạy công thức.")
                        kind = cell.get("t")
                        value = cell.findtext("s:v", default="", namespaces=NS)
                        if kind == "s":
                            try:
                                index = int(value)
                                if index < 0:
                                    raise ValueError
                                value = strings[index]
                            except (ValueError, IndexError) as exc:
                                raise CoreError("invalid_workbook", "Chỉ mục văn bản Excel bị lỗi.") from exc
                        elif kind == "inlineStr":
                            value = "".join(t.text or "" for t in cell.findall(".//s:t", NS))
                        elif kind in {"b", "e"}:
                            value = ""
                        if len(value) > 4000:
                            raise CoreError("workbook_limit", "Một ô Excel vượt 4.000 ký tự.")
                        values[re.sub(r"\d", "", ref)] = (value, ref)
                    if any(v[0].strip() for v in values.values()):
                        rows.append(values)
                if not rows:
                    continue
                header_aliases = {"doi tuong": "entity", "entity": "entity", "truong": "field", "field": "field",
                                  "gia tri": "value", "value": "value", "don vi": "unit", "unit": "unit", "ky": "period", "period": "period"}
                headers = {header_aliases.get(normalize(v[0])): key for key, v in rows[0].items() if normalize(v[0]) in header_aliases}
                if not {"field", "value"}.issubset(headers):
                    notices.append(f"Trang {name} chưa theo mẫu Trường / Giá trị; chưa tự suy diễn nội dung.")
                    continue
                for row in rows[1:]:
                    def val(key):
                        return row.get(headers.get(key), ("", ""))[0].strip()
                    key = normalize(val("field"))
                    field = key if key in FIELD_SPECS else ALIASES.get(key)
                    if not field:
                        if key:
                            notices.append(f"Chưa hỗ trợ trường “{val('field')[:80]}” tại {name}.")
                        continue
                    label, entity, _kind = FIELD_SPECS[field]
                    declared = normalize(val("entity"))
                    if declared and declared not in {entity, "doanh nghiep" if entity == "enterprise" else "san pham"}:
                        notices.append(f"Bỏ qua {label}: đối tượng tại {name} chưa đúng mẫu.")
                        continue
                    try:
                        value, value_type = typed_value(field, val("value"), val("unit"), val("period"))
                    except CoreError as exc:
                        notices.append(f"{name}, {row.get(headers['value'], ('', ''))[1]}: {exc}")
                        continue
                    output.append({"entity_type": entity, "field": field, "label_vi": label, "value": value,
                        "value_type": value_type, "unit": val("unit") or None, "period": val("period") or None,
                        "confidence": "parsed_literal", "source": {"kind": "spreadsheet", "sheet": name,
                        "cell": row[headers["value"]][1], "locator": f"{name}!{row[headers['value']][1]}",
                        "unit": val("unit") or None, "period": val("period") or None,
                        "unit_cell": row.get(headers.get("unit"), ("", None))[1],
                        "period_cell": row.get(headers.get("period"), ("", None))[1]}})
                    if len(output) > 40:
                        raise CoreError("candidate_limit", "Mỗi lượt nhận tối đa 40 dữ kiện; hãy chia nhỏ Excel.")
    except (BadZipFile, KeyError, OSError, RuntimeError) as exc:
        raise CoreError("invalid_workbook", "Không đọc được Excel. Hãy dùng bản .xlsx không mật khẩu.") from exc
    names = {fact["value"].strip().casefold() for fact in output if fact["field"] == "name"}
    if len(names) > 1:
        raise CoreError("multiple_products_not_supported", "Excel có nhiều sản phẩm. 0.4A nhận một sản phẩm mỗi lượt; hãy tách từng sản phẩm thành tệp riêng để tránh gộp nhầm dữ kiện.")
    return output, list(dict.fromkeys(notices))[:20]


def validate_attachment(item):
    if not isinstance(item, dict) or set(item) - {"filename", "media_type", "data_base64"}:
        raise CoreError("invalid_attachment", "Thông tin tệp chưa đúng định dạng.")
    filename, media_type = item.get("filename"), item.get("media_type")
    encoded = item.get("data_base64")
    if not isinstance(filename, str) or not filename.strip() or len(filename) > 160 or any(c in filename for c in "/\\\x00"):
        raise CoreError("invalid_filename", "Tên tệp không hợp lệ; không chứa đường dẫn.")
    if not isinstance(encoded, str) or len(encoded) > ((MAX_FILE + 2) // 3) * 4:
        raise CoreError("attachment_limit", "Mỗi tệp tối đa 5 MB.")
    try:
        raw = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise CoreError("invalid_attachment", "Dữ liệu tệp bị lỗi; hãy chọn lại tệp.") from exc
    if not raw or len(raw) > MAX_FILE:
        raise CoreError("attachment_limit", "Tệp cần có nội dung và không vượt 5 MB.")
    suffix = Path(filename).suffix.casefold()
    result = {"filename": filename, "media_type": media_type, "size": len(raw),
              "sha256": hashlib.sha256(raw).hexdigest(), "raw": raw}
    if suffix == '.csv':
        from .document_errors import document_error_message
        raise CoreError('unsupported_attachment', document_error_message(filename,
            'Chưa hỗ trợ đọc CSV. Chị mở tệp trong Excel và lưu thành .xlsx rồi đính kèm lại; đổi đuôi tệp không chuyển đổi định dạng.'))
    if suffix == ".xlsx" and media_type in {XLSX, "application/octet-stream", ""}:
        result["media_type"] = XLSX
        result["kind"] = "spreadsheet"
        return result
    if suffix == ".pdf" and media_type in {"application/pdf", "application/octet-stream", ""}:
        if not raw.startswith(b"%PDF-"):
            from .document_errors import document_error_message
            raise CoreError("invalid_pdf", document_error_message(filename, "Tệp không phải PDF hợp lệ. Chị kiểm tra lại tệp đã chọn."))
        result.update(media_type="application/pdf", kind="pdf")
        return result
    expected = {".png": ("PNG", "image/png"), ".jpg": ("JPEG", "image/jpeg"), ".jpeg": ("JPEG", "image/jpeg"), ".webp": ("WEBP", "image/webp")}
    if suffix not in expected or media_type != expected[suffix][1]:
        raise CoreError("unsupported_attachment", "Chị chọn ảnh PNG/JPEG/WebP, Excel .xlsx hoặc PDF văn bản.")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(BytesIO(raw)) as image:
                if image.format != expected[suffix][0] or image.width * image.height > 12_000_000 or getattr(image, "n_frames", 1) != 1:
                    raise CoreError("image_limit", "Ảnh cần một khung hình và tối đa 12 triệu điểm ảnh.")
                image.verify()
    except (UnidentifiedImageError, OSError, SyntaxError, Image.DecompressionBombWarning, Image.DecompressionBombError) as exc:
        raise CoreError("invalid_image", "Ảnh không hợp lệ hoặc quá lớn; hãy chụp/lưu lại.") from exc
    result["kind"] = "image"
    return result


def read_image_fixture(attachment, manifest_path=None):
    manifest_path = Path(manifest_path) if manifest_path else Path(__file__).with_name("vision_fixtures.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    match = manifest.get(attachment["sha256"])
    if not match:
        return [], ["Ảnh đã được lưu riêng tư. Chế độ giả lập chưa đọc nội dung ảnh này; không suy đoán thành phần, xuất xứ hoặc chứng nhận."]
    output = []
    for item in match.get("facts", []):
        field = item["field"]
        value, kind = typed_value(field, item["value"], item.get("unit"), item.get("period"))
        output.append({"entity_type": FIELD_SPECS[field][1], "field": field, "label_vi": FIELD_SPECS[field][0],
            "value": value, "value_type": kind, "unit": item.get("unit"), "period": item.get("period"),
            "confidence": "simulated_fixture", "source": {"kind": "simulated_vision", "simulation": True,
            "locator": item.get("locator", "Vùng chữ trong ảnh mẫu"), "bbox": item.get("bbox")}})
    return output, ["Đọc ảnh mẫu được giả lập theo đúng mã tệp; chưa gọi mô hình nhận dạng ảnh."]
