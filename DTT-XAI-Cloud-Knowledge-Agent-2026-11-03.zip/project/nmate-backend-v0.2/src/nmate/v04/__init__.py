"""Bounded 0.4A private document intake. No paid provider is reachable."""
