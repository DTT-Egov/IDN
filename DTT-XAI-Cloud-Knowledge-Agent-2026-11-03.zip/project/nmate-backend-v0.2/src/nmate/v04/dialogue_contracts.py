"""Exact historic schemas plus registry-derived bounded vision observations.

Historic variants are finite complete schemas, never fuzzy request matching.
The frozen old schema is used only to reconstruct hashes for authorized READ.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

from nmate.v03.field_registry import REGISTRY_VERSION, field_contract


LEGACY_SCHEMA_V2_SHA256 = "0736e11486b5d20de63cd65feb1caf2acc97ac2ec64e3328e18979dcfe272f81"


def legacy_dialogue_schema_v2(image_hashes=None):
    raw = (Path(__file__).with_name("data") / "dialogue_schema_v2.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != LEGACY_SCHEMA_V2_SHA256:
        raise ValueError("Historic dialogue schema checksum mismatch")
    schema = json.loads(raw)
    return _bind_images(schema, image_hashes)


def _bind_images(schema, image_hashes):
    if image_hashes is None:
        return schema
    if not isinstance(image_hashes, list) or any(not isinstance(value, str) for value in image_hashes):
        raise ValueError("Invalid schema image references")
    if image_hashes:
        vision = schema["$defs"]["VisionFact"]
        vision["properties"]["sha256"]["enum"] = list(image_hashes)
        for branch in vision.get("anyOf", []):
            branch["properties"]["sha256"]["enum"] = list(image_hashes)
        schema["properties"]["unread_image_sha256"]["items"]["enum"] = list(image_hashes)
    else:
        schema["properties"]["image_facts"]["maxItems"] = 0
        schema["properties"]["unread_image_sha256"]["maxItems"] = 0
    return schema


def dialogue_response_schema(image_hashes=None):
    """New dispatch schema, generated only for the already enabled five fields.

    Native provider transformations may move length/pattern constraints into
    descriptions. The existing server validator remains authoritative, including
    source quotes, image identity and typed_value; this is no egress permission.
    """
    schema = legacy_dialogue_schema_v2()
    schema["x-field-registry-version"] = REGISTRY_VERSION
    vision = schema["$defs"]["VisionFact"]
    branches = []
    for field in vision["properties"]["field"]["enum"]:
        contract = field_contract(field)
        if contract is None:
            raise ValueError("Vision field lacks registered contract")
        value = deepcopy(contract["value_schema"])
        if "anyOf" in value:
            value = next(deepcopy(part) for part in value["anyOf"] if part.get("type") == "string")
        if value.get("type") != "string":
            raise ValueError("Vision adapter only supports text observations")
        branch = deepcopy(vision)
        branch["properties"]["field"]["enum"] = [field]
        branch["properties"]["value"] = value
        branches.append(branch)
    vision["anyOf"] = branches
    return _bind_images(schema, image_hashes)


def exact_prior_dialogue_schemas(schema):
    """Prior V2 encodings only when the whole supplied static schema is known."""
    if not isinstance(schema, dict):
        return []
    candidates = [None, []]
    try:
        hashes = schema.get("$defs", {}).get("VisionFact", {}).get("properties", {}).get("sha256", {}).get("enum")
    except (AttributeError, TypeError):
        return []
    if isinstance(hashes, list) and hashes:
        candidates.append(hashes)
    for candidate in candidates:
        old = legacy_dialogue_schema_v2(candidate)
        if schema == dialogue_response_schema(candidate) or schema == old:
            return [old]
    return []
