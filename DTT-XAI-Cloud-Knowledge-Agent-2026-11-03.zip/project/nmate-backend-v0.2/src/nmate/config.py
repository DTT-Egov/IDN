from pathlib import Path
import re
from typing import Literal

from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="NMATE_", env_file=".env", extra="ignore", hide_input_in_errors=True)
    data_dir: Path = Path(".data")
    port: int = Field(default=8022, ge=1024, le=65535)
    mode: Literal["evidence_only", "llm"] = "evidence_only"
    model_provider: Literal["anthropic", "openai"] = "anthropic"
    model_name: str | None = Field(default=None, repr=False)
    simple_model: str = Field(default="claude-sonnet-5-5", repr=False)
    complex_model: str = Field(default="claude-opus-5-5", repr=False)
    openai_api_key: SecretStr | None = Field(default=None, validation_alias="OPENAI_API_KEY")
    anthropic_api_key: SecretStr | None = Field(default=None, validation_alias="ANTHROPIC_API_KEY")
    web_dir: Path = Path(__file__).resolve().parents[3] / "nmate-mvp-v0.1"
    run_timeout_seconds: float = Field(default=120, ge=1, le=300)
    max_active_runs: int = Field(default=5, ge=1, le=20)
    max_daily_runs: int = Field(default=30, ge=1, le=1000)

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    @property
    def model_configured(self) -> bool:
        return bool(self.provider_model_valid and self.selected_api_key and self.selected_api_key.get_secret_value()
                    and (self.model_provider != "anthropic" or self.routing_models_valid))

    @staticmethod
    def valid_model_identifier(value: str | None) -> bool:
        return bool(value and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}", value)
                    and "sk-" not in value.lower() and "bearer" not in value.lower())

    @property
    def provider_model_valid(self) -> bool:
        if not self.valid_model_identifier(self.model_name):
            return False
        return self.model_name.startswith("claude-") if self.model_provider == "anthropic" else not self.model_name.startswith("claude-")

    @property
    def safe_model_name(self) -> str | None:
        return self.model_name if self.provider_model_valid else None

    @property
    def routing_models_valid(self) -> bool:
        return all(self.valid_model_identifier(v) and v.startswith("claude-")
                   for v in (self.simple_model, self.complex_model))

    @property
    def safe_model_policy(self) -> dict:
        return {"simple": self.simple_model if self.valid_model_identifier(self.simple_model) else None,
                "complex": self.complex_model if self.valid_model_identifier(self.complex_model) else None}

    def api_key_for(self, provider: str) -> SecretStr | None:
        if provider == "anthropic":
            return self.anthropic_api_key
        if provider == "openai":
            return self.openai_api_key
        return None

    @property
    def selected_api_key(self) -> SecretStr | None:
        return self.api_key_for(self.model_provider)

    @property
    def credential_env_name(self) -> str:
        return "ANTHROPIC_API_KEY" if self.model_provider == "anthropic" else "OPENAI_API_KEY"
