"""Bounded local rules for model selection, not an LLM or legal classifier.

An explicit processing level always wins. Auto chooses complex processing only
for a defined specialist/contradiction/comparison/analysis signal. Missing case
facts and ordinary IOR/FSVP preparation do not independently justify escalation.
The decision changes model effort only; it does not expand workflow permissions,
certify a product, approve a source, or authorize shipping.
"""
from __future__ import annotations

import re
import unicodedata
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal

ROUTING_POLICY_VERSION = "0.2.1"
ProcessingLevel = Literal["auto", "standard", "complex"]
ResolvedLevel = Literal["standard", "complex"]
MAX_QUESTION_CHARS = 2000


@dataclass(frozen=True)
class RoutingDecision:
    model_name: str
    level: ResolvedLevel
    reason_code: str
    reason: str


_REASONS = {
    "EXPLICIT_COMPLEX": "Người dùng chọn mức xử lý phức tạp; dùng mô hình chuyên sâu đã cấu hình.",
    "EXPLICIT_STANDARD": "Người dùng chọn mức xử lý tiêu chuẩn; không tự nâng mức xử lý.",
    "CONTRADICTORY_PRODUCT_INFORMATION": (
        "Thông tin nhóm hàng khô và điều kiện bảo quản có dấu hiệu cần đối chiếu chuyên môn; "
        "việc chọn mô hình không xác nhận tính đúng của hồ sơ."
    ),
    "SPECIALIST_PRODUCT_GROUP": (
        "Thông tin sản phẩm có dấu hiệu thuộc nhóm hoặc quy trình cần chuyên gia rà riêng; "
        "kết quả vẫn chỉ phục vụ chuẩn bị, không xác nhận tuân thủ hay cho phép xuất hàng."
    ),
    "REQUEST_EVIDENCE_CONFLICT": (
        "Câu hỏi yêu cầu đối chiếu bằng chứng hoặc hướng dẫn mâu thuẫn; "
        "cần xử lý chuyên sâu và giữ bước rà soát của chuyên gia."
    ),
    "REQUEST_OPTIONS_COMPARISON": (
        "Câu hỏi yêu cầu so sánh phương án hoặc đánh đổi; dùng mức xử lý chuyên sâu "
        "trong phạm vi chuẩn bị hiện có."
    ),
    "MULTI_TOPIC_REGULATORY_ANALYSIS": (
        "Câu hỏi yêu cầu phân tích liên hệ nhiều chủ đề chuyên môn; "
        "không mở rộng sang quyết định thuế, tuân thủ hoặc thông quan."
    ),
    "ROUTINE_PREPARATION": (
        "Yêu cầu chuẩn bị thông thường; dữ liệu còn thiếu, kể cả IOR hoặc FSVP importer, "
        "không tự làm tăng mức xử lý."
    ),
}


def _fold(text: str) -> str:
    text = unicodedata.normalize("NFKD", text.casefold().replace("đ", "d"))
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())


def _bounded_text(value: Any, limit: int) -> str:
    return value[:limit] if isinstance(value, str) else ""


def _positive_signal(text: str, patterns: tuple[str, ...]) -> bool:
    """Ignore a short, directly negated keyword phrase; do not infer missing facts."""
    for pattern in patterns:
        for match in re.finditer(pattern, text):
            prefix = text[max(0, match.start() - 70):match.start()]
            if re.search(
                r"(?:\b(?:no|not|without|khong|chua|tranh)\b|\bdon['’]t\b)"
                r"(?:[ \t]+[\w-]+){0,4}[ \t]*$",
                prefix,
            ):
                continue
            return True
    return False


_COLD_CHAIN = (
    r"\b(?:refrigerated|refrigeration|frozen|chilled|cold[- ]chain)\b",
    r"\b(?:bao quan lanh|giu lanh|dong lanh|lam lanh bat buoc)\b",
)
_SPECIALIST_FOLDED = (
    r"\b(?:meat|beef|pork|poultry|chicken|fish|seafood|shellfish|shrimp|salmon|tuna|catfish)\b",
    r"\b(?:dairy|milk|whey|casein|cheese|yogurt|yoghurt)\b",
    r"\b(?:dietary supplements?|nutraceuticals?|juice|low[- ]acid|acidified|canned|retort)\b",
    r"\b(?:thit|thuy san|hai san|tom|bot sua|san pham tu sua|ca hoi|ca ngu|ca kho|san pham tu ca)\b",
    r"\b(?:thuc pham chuc nang|thuc pham bo sung|nuoc ep|acid thap|axit thap|do hop)\b",
)
_SPECIALIST_ACCENTED = (
    r"\bcá\b",  # Do not fold cá/cà/ca: ordinary 'ca thử nghiệm' is not fish.
    r"\bsữa\b",  # Do not fold sữa/sửa: 'sửa nhãn' is not a dairy product.
)
_CONFLICT_REQUEST = (
    r"\b(?:conflicting|contradictory|inconsistent)\s+(?:evidence|sources?|guidance|requirements?|information|documents?)\b",
    r"\b(?:reconcile|resolve|compare)\b.{0,70}\b(?:conflicting|contradictory|inconsistent)\b",
    r"\b(?:mau thuan|khong nhat quan|bang chung trai nguoc)\b",
)
_COMPARISON_REQUEST = (
    r"\b(?:trade[- ]?offs?|pros and cons|versus|vs)\b",
    r"\bcompar(?:e|ing|ison)\b.{0,60}\b(?:options?|alternatives?|costs?|incoterms?|routes?|scenarios?|exw|ddp|fob|cif|dap)\b",
    r"\b(?:so sanh|danh doi|uu nhuoc|can nhac phuong an)\b",
)
_ANALYTICAL_REQUEST = (
    r"\b(?:analy[sz]e|assess|evaluate|reconcile|implications?|interaction|interplay)\b",
    r"\b(?:phan tich|danh gia|doi chieu|tac dong|lien he|xac dinh dong thoi)\b",
)
_REGULATORY_TOPICS = (
    (r"\b(?:fsvp|foreign supplier verification)\b",),
    (r"\b(?:allergens?|label(?:ing|ling)?|ghi nhan|di ung|nutrition facts)\b",),
    (r"\b(?:haccp|preventive controls?|fsma|kiem soat phong ngua)\b",),
    (r"\b(?:hts|hs code|tariff|duties|fta|usmca|evfta|trade preferences?|ma hs|thue quan|quy tac xuat xu)\b",),
    (r"\b(?:incoterms?|exw|fob|cif|ddp|dap|landed cost|dieu kien giao hang)\b",),
)


def _product_text(case: Mapping[str, Any]) -> tuple[str, str, str]:
    product = case.get("product")
    product = product if isinstance(product, Mapping) else {}
    parts = [
        _bounded_text(product.get("family"), 100),
        _bounded_text(product.get("name"), 200),
        _bounded_text(product.get("processing_description"), 1000),
        _bounded_text(product.get("packaging"), 300),
    ]
    ingredients = product.get("ingredients")
    if isinstance(ingredients, list):
        parts.extend(_bounded_text(item, 200) for item in ingredients[:30])
    elif isinstance(ingredients, str):
        parts.append(ingredients[:2000])
    original = unicodedata.normalize("NFC", " ".join(parts).casefold())
    family = _bounded_text(product.get("family"), 100).strip().casefold()
    return original, _fold(original), family


def _validate_model_id(value: str) -> None:
    # Server configuration only. Never take a model ID from product/question text.
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,199}", value):
        raise ValueError("Configured model identifier is invalid")


def route_model(
    case: dict,
    question: str,
    processing_level: ProcessingLevel = "auto",
    *,
    simple_model: str = "claude-sonnet-5-5",
    complex_model: str = "claude-opus-5-5",
) -> RoutingDecision:
    """Return a deterministic local selection; no network, model call or mutation.

    Priority: explicit choice; contradictory dry/cold information; specialist
    product; requested evidence reconciliation; requested options comparison;
    analytical request across at least two topic groups; routine preparation.
    IOR plus FSVP, prior notice, missing fields and unknown certifications alone
    are routine. These lexical indicators are transparent heuristics, not a
    determination of product classification, regulatory applicability or safety.
    """
    if processing_level not in ("auto", "standard", "complex"):
        raise ValueError("processing_level must be auto, standard or complex")
    if not isinstance(case, Mapping):
        raise ValueError("case must be a mapping")
    _validate_model_id(simple_model)
    _validate_model_id(complex_model)

    def decision(level: ResolvedLevel, reason_code: str) -> RoutingDecision:
        return RoutingDecision(
            model_name=complex_model if level == "complex" else simple_model,
            level=level,
            reason_code=reason_code,
            reason=_REASONS[reason_code],
        )

    if processing_level == "complex":
        return decision("complex", "EXPLICIT_COMPLEX")
    if processing_level == "standard":
        return decision("standard", "EXPLICIT_STANDARD")

    original, product_text, family = _product_text(case)
    if family == "dry_food" and _positive_signal(product_text, _COLD_CHAIN):
        return decision("complex", "CONTRADICTORY_PRODUCT_INFORMATION")
    if _positive_signal(product_text, _SPECIALIST_FOLDED) or _positive_signal(original, _SPECIALIST_ACCENTED):
        return decision("complex", "SPECIALIST_PRODUCT_GROUP")
    query = _fold(_bounded_text(question, MAX_QUESTION_CHARS))
    if _positive_signal(query, _CONFLICT_REQUEST):
        return decision("complex", "REQUEST_EVIDENCE_CONFLICT")
    if _positive_signal(query, _COMPARISON_REQUEST):
        return decision("complex", "REQUEST_OPTIONS_COMPARISON")
    topics = sum(_positive_signal(query, group) for group in _REGULATORY_TOPICS)
    if topics >= 2 and _positive_signal(query, _ANALYTICAL_REQUEST):
        return decision("complex", "MULTI_TOPIC_REGULATORY_ANALYSIS")
    return decision("standard", "ROUTINE_PREPARATION")
