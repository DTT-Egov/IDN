"""Local-only developer identity. Replace with real identity/OAuth before a hosted pilot."""

import hashlib
import hmac
import os
import re
import secrets
import time
from contextvars import ContextVar
from pathlib import Path

from starlette.responses import JSONResponse

from .models import AppError, Principal
from .store import Store

current_principal: ContextVar[Principal | None] = ContextVar("nmate_principal", default=None)
# Console identity is separate from quarantined historical shared-browser data.
LOCAL_PRINCIPAL = Principal("local-console", "developer-console")


def sha(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class LocalAuth:
    def __init__(self, store: Store, data_dir: Path):
        self.store = store
        path = data_dir / "mcp-token.txt"
        if not path.exists():
            path.write_text(secrets.token_urlsafe(48), encoding="utf-8")
        self.developer_token = path.read_text(encoding="utf-8").strip()
        identity_path = data_dir / "browser-identity.key"
        try:
            descriptor = os.open(identity_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            pass
        else:
            with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
                stream.write(secrets.token_hex(48))
        self._identity_key = identity_path.read_bytes()
        if not re.fullmatch(rb"[a-f0-9]{96}", self._identity_key):
            raise RuntimeError("Local browser identity signing material is unavailable; refusing shared identity fallback")

    def create_device(self):
        value = "v1." + secrets.token_hex(32)
        return value + "." + hmac.new(self._identity_key, value.encode(), hashlib.sha256).hexdigest()

    def device_principal(self, cookie):
        if not isinstance(cookie, str) or not re.fullmatch(r"v1\.[a-f0-9]{64}\.[a-f0-9]{64}", cookie):
            return None
        value, signature = cookie.rsplit(".", 1)
        expected = hmac.new(self._identity_key, value.encode(), hashlib.sha256).hexdigest()
        if not secrets.compare_digest(signature, expected):
            return None
        identity = sha(value)
        return Principal("browser-" + identity, "profile-" + identity)

    @staticmethod
    def record_principal(record):
        return Principal(record["tenant"], record["subject"]) if record and record.get("tenant") and record.get("subject") else None

    def create_session(self, p: Principal = LOCAL_PRINCIPAL) -> dict:
        session_id, csrf, mcp_token = (secrets.token_urlsafe(32) for _ in range(3))
        with self.store.connection(write=True) as db:
            db.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
            db.execute("INSERT INTO sessions(id_hash,csrf,mcp_hash,expires,tenant,subject) VALUES(?,?,?,?,?,?)",
                       (sha(session_id), csrf, sha(mcp_token), time.time() + 8 * 3600, p.tenant_id, p.subject))
        # MCP bearer remains server-side; browser receives a separate HttpOnly session cookie.
        return {"session_id": session_id, "csrf": csrf, "mcp_token": mcp_token}

    def get_session(self, session_id: str | None):
        if not session_id:
            return None
        with self.store.connection() as db:
            row = db.execute("SELECT * FROM sessions WHERE id_hash=? AND expires>?",
                             (sha(session_id), time.time())).fetchone()
            record = dict(row) if row else None
            return record if self.record_principal(record) else None

    def verify_bearer(self, token: str | None) -> Principal | None:
        if not token:
            return None
        if secrets.compare_digest(token, self.developer_token):
            return LOCAL_PRINCIPAL
        with self.store.connection() as db:
            row = db.execute("SELECT tenant,subject FROM sessions WHERE mcp_hash=? AND expires>?",
                             (sha(token), time.time())).fetchone()
            return self.record_principal(dict(row)) if row else None


def principal() -> Principal:
    value = current_principal.get()
    if value is None:
        raise AppError("UNAUTHENTICATED", "Thiếu danh tính được xác thực.", 401)
    return value


class McpBearerMiddleware:
    def __init__(self, app, auth: LocalAuth):
        self.app, self.auth = app, auth

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope["headers"])
        header = headers.get(b"authorization", b"").decode("latin-1")
        token = header[7:] if header.startswith("Bearer ") else None
        p = self.auth.verify_bearer(token)
        if p is None:
            response = JSONResponse({"error": "invalid_local_developer_bearer"}, 401,
                                    headers={"WWW-Authenticate": "Bearer"})
            return await response(scope, receive, send)
        marker = current_principal.set(p)
        try:
            await self.app(scope, receive, send)
        finally:
            current_principal.reset(marker)
