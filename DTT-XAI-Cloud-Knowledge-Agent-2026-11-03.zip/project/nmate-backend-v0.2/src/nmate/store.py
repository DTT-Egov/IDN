"""SQLite business state for a single-machine preview; not an in-memory job queue."""

import hashlib
import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from .models import AppError, Principal


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical(value: dict) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: dict) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class Store:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS cases (
                  id TEXT PRIMARY KEY, tenant TEXT NOT NULL, version INTEGER NOT NULL, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs (
                  id TEXT PRIMARY KEY, tenant TEXT NOT NULL, case_id TEXT NOT NULL,
                  idem TEXT NOT NULL, payload_hash TEXT NOT NULL, body TEXT NOT NULL,
                  status TEXT NOT NULL, cancel INTEGER NOT NULL DEFAULT 0,
                  lease_owner TEXT, lease_until REAL, created TEXT NOT NULL,
                  UNIQUE(tenant,case_id,idem));
                CREATE INDEX IF NOT EXISTS run_queue ON runs(status,lease_until);
                CREATE TABLE IF NOT EXISTS artifacts (
                  id TEXT PRIMARY KEY, tenant TEXT NOT NULL, case_id TEXT NOT NULL,
                  run_id TEXT NOT NULL UNIQUE, body TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS sessions (
                  id_hash TEXT PRIMARY KEY, csrf TEXT NOT NULL, mcp_hash TEXT NOT NULL UNIQUE,
                  expires REAL NOT NULL);
                CREATE TABLE IF NOT EXISTS audit (
                  id INTEGER PRIMARY KEY, at TEXT NOT NULL, tenant TEXT NOT NULL,
                  actor TEXT NOT NULL, action TEXT NOT NULL, resource TEXT NOT NULL);
                PRAGMA user_version=1;
            """)
            columns = {row[1] for row in db.execute("PRAGMA table_info(sessions)")}
            for name in ("tenant", "subject"):
                if name not in columns:
                    db.execute(f"ALTER TABLE sessions ADD COLUMN {name} TEXT")

    @contextmanager
    def connection(self, *, write=False):
        db = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            if write:
                db.execute("BEGIN IMMEDIATE")
            yield db
            if write:
                db.commit()
        except BaseException:
            if write:
                db.rollback()
            raise
        finally:
            db.close()

    def _case(self, db, principal, case_id):
        row = db.execute("SELECT body FROM cases WHERE id=? AND tenant=?",
                         (case_id, principal.tenant_id)).fetchone()
        if not row:
            raise AppError("NOT_FOUND", "Không tìm thấy hồ sơ được phép đọc.", 404)
        return json.loads(row["body"])

    def _audit(self, db, p, action, resource):
        db.execute("INSERT INTO audit(at,tenant,actor,action,resource) VALUES(?,?,?,?,?)",
                   (now(), p.tenant_id, p.subject, action, resource))

    def create_case(self, p: Principal, data: dict) -> dict:
        if p.role != "business":
            raise AppError("FORBIDDEN", "Chỉ người dùng doanh nghiệp được xác nhận hồ sơ.", 403)
        with self.connection(write=True) as db:
            case = self._insert_case(db, p, data)
        return case

    def _insert_case(self, db, p, data):
        """Insert within the caller's transaction, including conversation launch."""
        case = {**data, "case_id": str(uuid.uuid4()), "version": 1, "created_at": now()}
        db.execute("INSERT INTO cases VALUES(?,?,?,?)",
                   (case["case_id"], p.tenant_id, 1, canonical(case)))
        self._audit(db, p, "case.create", case["case_id"])
        return case

    @staticmethod
    def _managed_conversations(db, tenant, case_id):
        if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='conversation_research_requests'").fetchone():
            return []  # Store is also usable without the conversation feature.
        return list(db.execute("SELECT DISTINCT c.id,c.owner,c.body FROM conversations c "
            "JOIN conversation_research_requests r ON r.conversation_id=c.id AND r.tenant=c.tenant "
            "WHERE r.tenant=? AND r.case_id=?", (tenant, case_id)))

    def _validate_conversation_launch(self, db, p, args):
        for row in self._managed_conversations(db, p.tenant_id, args["case_id"]):
            if row["owner"] != p.subject:
                raise AppError("NOT_FOUND", "Không tìm thấy hồ sơ được phép nghiên cứu.", 404)
            body = json.loads(row["body"])
            intent = body.get("pending_research_launch")
            if (body.get("pending_proposal") is not None or not intent
                    or body.get("case_id") != args["case_id"]
                    or body.get("case_version") != args["expected_case_version"]
                    or any(intent.get(key) != args.get(key) for key in intent)):
                raise AppError("RESEARCH_LAUNCH_MISMATCH", "Yêu cầu không khớp lượt nghiên cứu đã xác nhận; hãy đọc lại cuộc trao đổi.", 409)

    def _sync_conversation_research(self, db, p, run):
        """Publish run/artifact links in the SAME transaction as their records.

        Only the new server-managed launch path is affected; no browser follow-up
        link request, background reconciliation or model retry is necessary.
        """
        from .conversations.models import ConversationDTO

        for row in self._managed_conversations(db, p.tenant_id, run["case_id"]):
            body = json.loads(row["body"])
            links = body["research_links"]
            previous = next((item for item in links if item.get("run_id") == run["run_id"]), None)
            if previous is None:
                previous = next((item for item in links if item["case_id"] == run["case_id"]
                                 and item["case_version"] == run["profile_version"] and not item.get("run_id")), None)
            entry = {"case_id": run["case_id"], "case_version": run["profile_version"],
                "run_id": run["run_id"], "artifact_id": run.get("artifact_id"),
                "question": run["question"], "created_at": previous["created_at"] if previous else now(),
                "product_summary": {key: run["snapshot"]["product"][key] for key in ("sku", "name")}}
            if previous is not None:
                links[links.index(previous)] = entry
            else:
                links.append(entry)
            if body.get("case_id") == run["case_id"]:
                for key in ("case_id", "case_version", "run_id", "artifact_id"):
                    body[key] = entry[key]
                body["pending_research_launch"] = None
            body["version"] += 1
            body["updated_at"] = now()
            ConversationDTO.model_validate(body)
            db.execute("UPDATE conversations SET version=?,body=?,updated=? WHERE id=? AND tenant=?",
                       (body["version"], canonical(body), body["updated_at"], row["id"], p.tenant_id))
            self._audit(db, p, "conversation.research_synced", row["id"])

    def get_case(self, p: Principal, case_id: str) -> dict:
        with self.connection() as db:
            return self._case(db, p, case_id)

    @staticmethod
    def _interrupt_rows(db, where, params, code):
        error = canonical({"code": code, "message": "Lượt nghiên cứu bị gián đoạn; chưa tự chạy lại AI. Hãy kiểm tra và chủ động tạo lượt mới khi cần."})
        db.execute("UPDATE runs SET status='failed',lease_owner=NULL,lease_until=NULL,body=json_set(body,"
                   "'$.status','failed','$.stage','interrupted','$.error',json(?),'$.updated_at',?) WHERE " + where,
                   (error, now(), *params))

    def interrupt_incomplete_runs(self):
        """A new server never resumes a possibly paid in-flight/queued request."""
        with self.connection(write=True) as db:
            self._interrupt_rows(db, "status IN ('queued','running')", (), "RUN_INTERRUPTED")

    def _expire_leases(self, db, tenant=None):
        where, params = "status='running' AND (lease_until IS NULL OR lease_until<?)", (time.time(),)
        if tenant:
            where += " AND tenant=?"
            params += (tenant,)
        self._interrupt_rows(db, where, params, "LEASE_EXPIRED")

    def list_cases(self, p):
        with self.connection(write=True) as db:
            self._expire_leases(db, p.tenant_id)
            result = []
            for row in db.execute("SELECT id,version,json_extract(body,'$.product.sku') sku,"
                                  "json_extract(body,'$.product.name') name FROM cases WHERE tenant=? ORDER BY rowid DESC LIMIT 50", (p.tenant_id,)):
                run = db.execute("SELECT body FROM runs WHERE tenant=? AND case_id=? ORDER BY created DESC LIMIT 1",
                                 (p.tenant_id, row["id"])).fetchone()
                latest = json.loads(run[0]) if run else None
                result.append({"case_id": row["id"], "version": row["version"],
                    "product_summary": {"sku": row["sku"], "name": row["name"]},
                    "activity_state": self.run_activity(latest) if latest else {"status": "draft", "stage": "case_created", "run_id": None,
                         "run_status": None, "error_code": None, "artifact_id": None, "can_send": True}})
            return result

    @staticmethod
    def run_activity(run):
        status, error = run["status"], run.get("error") or {}
        states = {"queued": "research_queued", "running": "researching", "succeeded": "ready", "failed": "research_failed", "cancelled": "cancelled"}
        state = "interrupted" if run.get("stage") == "interrupted" else states.get(status, "error")
        return {"status": state, "run_id": run["run_id"], "run_status": status, "stage": run.get("stage"),
                "error_code": error.get("code"), "artifact_id": run.get("artifact_id"),
                "can_send": status not in ("queued", "running")}

    def replace_case(self, p: Principal, case_id: str, expected_version: int, data: dict) -> dict:
        if p.role != "business":
            raise AppError("FORBIDDEN", "Agent không được sửa hồ sơ đã xác nhận.", 403)
        with self.connection(write=True) as db:
            previous = self._case(db, p, case_id)
            if previous["version"] != expected_version:
                raise AppError("VERSION_CONFLICT", "Hồ sơ đã thay đổi; hãy tải lại.", 409)
            case = {**data, "case_id": case_id, "version": expected_version + 1,
                    "created_at": previous["created_at"], "updated_at": now()}
            db.execute("UPDATE cases SET version=?,body=? WHERE id=?",
                       (case["version"], canonical(case), case_id))
            self._audit(db, p, "case.replace", case_id)
        return case

    @staticmethod
    def check_scope(case: dict):
        product, shipment = case["product"], case["shipment"]
        if (product["family"] != "dry_food" or product["origin_country"] != "VN"
                or shipment["target_market"] != "US" or shipment["route"] != "importer"):
            raise AppError("OUT_OF_SCOPE", "Bản này hỗ trợ một SKU thực phẩm khô Việt Nam → Mỹ qua importer.")
        if not case["consent_research"]:
            raise AppError("CONSENT_REQUIRED", "Cần đồng ý xử lý hồ sơ cho nghiên cứu.", 403)

    def start(self, p: Principal, args: dict, *, mode: str, max_active: int, max_daily: int,
              model_name: str | None = None, model_provider: str = "openai", routing: dict | None = None) -> dict:
        payload_hash = digest({**args, "mode": mode, "model_name": model_name if mode == "llm" else None,
                               "model_provider": model_provider if mode == "llm" else None})
        with self.connection(write=True) as db:
            case = self._case(db, p, args["case_id"])
            for linked in self._managed_conversations(db, p.tenant_id, args["case_id"]):
                if linked["owner"] != p.subject:
                    raise AppError("NOT_FOUND", "Không tìm thấy hồ sơ được phép nghiên cứu.", 404)
            self.check_scope(case)
            if mode == "llm" and not case["consent_model"]:
                raise AppError("MODEL_CONSENT_REQUIRED", "Cần đồng ý gửi dữ kiện tối thiểu đến mô hình.", 403)
            row = db.execute("SELECT body,payload_hash FROM runs WHERE tenant=? AND case_id=? AND idem=?",
                             (p.tenant_id, args["case_id"], args["idempotency_key"])).fetchone()
            if row:
                if row["payload_hash"] != payload_hash:
                    raise AppError("IDEMPOTENCY_CONFLICT", "Khóa yêu cầu đã dùng cho nội dung khác.", 409)
                return json.loads(row["body"])
            self._validate_conversation_launch(db, p, args)
            if case["version"] != args["expected_case_version"]:
                raise AppError("VERSION_CONFLICT", "Hồ sơ đã thay đổi; hãy tải lại.", 409)
            self._expire_leases(db, p.tenant_id)
            if db.execute("SELECT 1 FROM runs WHERE tenant=? AND case_id=? AND status IN ('queued','running')",
                          (p.tenant_id, case["case_id"])).fetchone():
                raise AppError("RESEARCH_IN_PROGRESS", "Hồ sơ này đang được nghiên cứu; hãy đọc lại trạng thái, chưa tạo thêm lượt.", 409)
            active = db.execute("SELECT COUNT(*) FROM runs WHERE status IN ('queued','running')").fetchone()[0]
            daily = db.execute("SELECT COUNT(*) FROM runs WHERE substr(created,1,10)=?", (now()[:10],)).fetchone()[0]
            if active >= max_active or daily >= max_daily:
                raise AppError("RUN_LIMIT", "Đã đạt giới hạn lượt chạy của máy thử nghiệm.", 429)
            run = {"run_id": str(uuid.uuid4()), "agent_kind": "shipment_readiness", "agent_version": "0.2.0",
                   "case_id": case["case_id"], "profile_version": case["version"], "mode": mode,
                   "model_name": model_name if mode == "llm" else None,
                   "model_provider": model_provider if mode == "llm" else None,
                   "model_routing": routing,
                   "status": "queued", "stage": "queued", "cancel_requested": False,
                   "artifact_id": None, "error": None, "created_at": now(), "updated_at": now(),
                   "snapshot": case, "question": args["question"]}
            db.execute("INSERT INTO runs(id,tenant,case_id,idem,payload_hash,body,status,created) "
                       "VALUES(?,?,?,?,?,?,?,?)", (run["run_id"], p.tenant_id, case["case_id"],
                                                  args["idempotency_key"], payload_hash, canonical(run),
                                                  "queued", run["created_at"]))
            self._audit(db, p, "research.start", run["run_id"])
            self._sync_conversation_research(db, p, run)
            return run

    def get_run(self, p: Principal, run_id: str) -> dict:
        with self.connection(write=True) as db:
            self._expire_leases(db, p.tenant_id)
            row = db.execute("SELECT body FROM runs WHERE id=? AND tenant=?", (run_id, p.tenant_id)).fetchone()
            if not row:
                raise AppError("NOT_FOUND", "Không tìm thấy lượt nghiên cứu được phép đọc.", 404)
            return json.loads(row["body"])

    def list_runs(self, p: Principal) -> list[dict]:
        with self.connection(write=True) as db:
            self._expire_leases(db, p.tenant_id)
            return [json.loads(r["body"]) for r in db.execute(
                "SELECT body FROM runs WHERE tenant=? ORDER BY created DESC LIMIT 30", (p.tenant_id,))]

    def cancel(self, p: Principal, run_id: str) -> dict:
        with self.connection(write=True) as db:
            self._expire_leases(db, p.tenant_id)
            row = db.execute("SELECT body FROM runs WHERE id=? AND tenant=?", (run_id, p.tenant_id)).fetchone()
            if not row:
                raise AppError("NOT_FOUND", "Không tìm thấy lượt nghiên cứu được phép hủy.", 404)
            run = json.loads(row["body"])
            if run["status"] in ("queued", "running"):
                run["cancel_requested"] = True
                if run["status"] == "queued":
                    run.update(status="cancelled", stage="cancelled")
                run["updated_at"] = now()
                db.execute("UPDATE runs SET cancel=1,status=?,body=? WHERE id=?",
                           (run["status"], canonical(run), run_id))
                self._audit(db, p, "research.cancel_requested", run_id)
            return run

    def claim(self, owner: str) -> dict | None:
        with self.connection(write=True) as db:
            self._expire_leases(db)
            row = db.execute("SELECT * FROM runs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
            if not row:
                return None
            run = json.loads(row["body"])
            run.update(status="running", stage="starting",
                       updated_at=now())
            db.execute("UPDATE runs SET status='running',body=?,lease_owner=?,lease_until=? WHERE id=?",
                       (canonical(run), owner, time.time() + 10, run["run_id"]))
            return {**run, "tenant_id": row["tenant"]}

    def guard(self, run_id: str, owner: str):
        with self.connection() as db:
            row = db.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
            if not row or row["lease_owner"] != owner or row["lease_until"] < time.time():
                raise AppError("LEASE_LOST", "Lượt chạy đã được worker khác tiếp nhận.")
            if row["cancel"]:
                raise AppError("RUN_CANCELLED", "Đã dừng theo yêu cầu.")
            run = json.loads(row["body"])
            case = self._case(db, Principal(row["tenant"], "worker", "research"), row["case_id"])
            self.check_scope(case)
            if case["version"] != run["profile_version"]:
                raise AppError("PROFILE_CHANGED", "Hồ sơ đã thay đổi; hãy chạy nghiên cứu mới.")
            if run["mode"] == "llm" and not case["consent_model"]:
                raise AppError("MODEL_CONSENT_REQUIRED", "Đồng ý dùng mô hình đã được rút lại.")

    def progress(self, run_id: str, owner: str, stage: str | None = None):
        with self.connection(write=True) as db:
            row = db.execute("SELECT body FROM runs WHERE id=? AND lease_owner=? AND status='running' "
                             "AND lease_until>=? AND cancel=0", (run_id, owner, time.time())).fetchone()
            if not row:
                return
            run = json.loads(row["body"])
            run["updated_at"] = now()
            if stage:
                run["stage"] = stage
            db.execute("UPDATE runs SET body=?,lease_until=? WHERE id=? AND lease_owner=?",
                       (canonical(run), time.time() + 10, run_id, owner))

    def finish(self, run_id: str, owner: str, *, report: dict | None = None, error: dict | None = None):
        with self.connection(write=True) as db:
            row = db.execute("SELECT * FROM runs WHERE id=? AND lease_owner=? AND status='running'",
                             (run_id, owner)).fetchone()
            if not row or row["lease_until"] < time.time():
                return
            run = json.loads(row["body"])
            p = Principal(row["tenant"], "worker", "research")
            case = self._case(db, p, row["case_id"])
            # Recheck inside the same transaction as artifact publication.
            if row["cancel"]:
                run.update(status="cancelled", stage="cancelled", error=None)
            elif (not case["consent_research"] or case["version"] != run["profile_version"]
                  or (run["mode"] == "llm" and not case["consent_model"])):
                run.update(status="failed", stage="failed", error={"code": "PROFILE_OR_CONSENT_CHANGED",
                           "message": "Hồ sơ hoặc đồng ý đã thay đổi; không xuất bản kết quả."})
            elif error:
                run.update(status="failed", stage="failed", error=error)
            elif report is not None:
                artifact = {"artifact_id": str(uuid.uuid4()), "version": 1, "artifact_type": "shipment_preparation_plan",
                            "agent_kind": "shipment_readiness", "agent_version": "0.2.0",
                            "case_id": run["case_id"], "run_id": run_id, "profile_version": run["profile_version"],
                            "review_status": "draft", "created_at": now(), "report": report,
                            "model_provider": run.get("model_provider"), "model_name": run.get("model_name"),
                            "model_routing": run.get("model_routing")}
                artifact["content_sha256"] = digest(artifact)
                db.execute("INSERT INTO artifacts VALUES(?,?,?,?,?)", (artifact["artifact_id"], row["tenant"],
                           row["case_id"], run_id, canonical(artifact)))
                run.update(status="succeeded", stage="completed", artifact_id=artifact["artifact_id"])
            else:
                raise ValueError("report or error required")
            run["updated_at"] = now()
            db.execute("UPDATE runs SET status=?,body=?,lease_owner=NULL,lease_until=NULL WHERE id=?",
                       (run["status"], canonical(run), run_id))
            self._audit(db, p, f"research.{run['status']}", run_id)
            self._sync_conversation_research(db, p, run)

    def release(self, owner: str):
        with self.connection(write=True) as db:
            self._interrupt_rows(db, "lease_owner=? AND status='running'", (owner,), "RUN_INTERRUPTED")

    def get_artifact(self, p: Principal, artifact_id: str) -> dict:
        with self.connection() as db:
            row = db.execute("SELECT body,case_id FROM artifacts WHERE id=? AND tenant=?",
                             (artifact_id, p.tenant_id)).fetchone()
            if not row:
                raise AppError("NOT_FOUND", "Không tìm thấy kết quả được phép đọc.", 404)
            artifact = json.loads(row["body"])
            case = self._case(db, p, row["case_id"])
            artifact["stale"] = case["version"] != artifact["profile_version"]
            return artifact
