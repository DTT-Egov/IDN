"""SQL review aggregate. Facts remain in SSOT; review records never are facts.

The v04 JSON is a backwards-compatible read projection. Append-only proposals,
decisions and receipts below are authoritative for review lifecycle. A caller
must pass the same SQL transaction used for the fact commit.
"""
from __future__ import annotations

import hashlib
import json

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.field_scope import canonical_entity_type, field_is_in_scope


def digest(value):
    return hashlib.sha256(json_text(value).encode("utf-8")).hexdigest()


SCHEMA = """
CREATE UNIQUE INDEX IF NOT EXISTS v03_entities_tenant_identity ON v03_entities(enterprise_id,id);
CREATE TABLE IF NOT EXISTS core_review_workspaces (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, owner_id TEXT NOT NULL,
 engine_version TEXT NOT NULL DEFAULT 'workspace-review/2', revision INTEGER NOT NULL CHECK(revision>0),
 lifecycle TEXT NOT NULL CHECK(lifecycle IN ('open','partially_committed','settled','review_required')), source_manifest_hash TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id), FOREIGN KEY(enterprise_id) REFERENCES v03_enterprises(id),
 FOREIGN KEY(owner_id) REFERENCES v03_accounts(id));
CREATE TABLE IF NOT EXISTS core_review_proposals (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, proposal_id TEXT NOT NULL,
 candidate_id TEXT NOT NULL, proposal_revision INTEGER NOT NULL CHECK(proposal_revision>0), proposal_hash TEXT NOT NULL,
 group_id TEXT NOT NULL, generation INTEGER NOT NULL CHECK(generation>0), draft_subject_ref TEXT NOT NULL,
 observed_json TEXT NOT NULL, proposed_json TEXT NOT NULL, source_json TEXT NOT NULL,
 derived_from TEXT, recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,proposal_id),
 UNIQUE(enterprise_id,workspace_id,candidate_id,proposal_revision),
 FOREIGN KEY(enterprise_id,workspace_id) REFERENCES core_review_workspaces(enterprise_id,workspace_id),
 FOREIGN KEY(enterprise_id,workspace_id,derived_from) REFERENCES core_review_proposals(enterprise_id,workspace_id,proposal_id));
CREATE TABLE IF NOT EXISTS core_review_entity_bindings (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, draft_subject_ref TEXT NOT NULL,
 canonical_entity_id TEXT NOT NULL, entity_type TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision>0),
 evidence_json TEXT NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,draft_subject_ref),
 FOREIGN KEY(enterprise_id,workspace_id) REFERENCES core_review_workspaces(enterprise_id,workspace_id),
 FOREIGN KEY(enterprise_id,canonical_entity_id) REFERENCES v03_entities(enterprise_id,id));
CREATE TABLE IF NOT EXISTS core_review_command_receipts (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, command_id TEXT NOT NULL,
 actor_id TEXT NOT NULL, command_kind TEXT NOT NULL CHECK(command_kind IN ('confirm_selected','dismiss_candidates')), client_operation_id TEXT NOT NULL,
 request_hash TEXT NOT NULL, workspace_revision_after INTEGER NOT NULL,
 payload_json TEXT NOT NULL, result_hash TEXT NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,command_id),
 UNIQUE(enterprise_id,actor_id,command_kind,client_operation_id),
 FOREIGN KEY(enterprise_id,workspace_id) REFERENCES core_review_workspaces(enterprise_id,workspace_id));
CREATE TABLE IF NOT EXISTS core_review_group_resolutions (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, group_id TEXT NOT NULL,
 generation INTEGER NOT NULL, resolution_id TEXT NOT NULL, command_id TEXT NOT NULL,
 winner_proposal_id TEXT, action TEXT NOT NULL CHECK(action IN ('apply_winner','keep_current')), base_manifest_hash TEXT NOT NULL,
 effective_manifest_hash TEXT NOT NULL, binding_revision INTEGER NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,group_id,generation),
 UNIQUE(enterprise_id,workspace_id,resolution_id),
 FOREIGN KEY(enterprise_id,workspace_id) REFERENCES core_review_workspaces(enterprise_id,workspace_id),
 FOREIGN KEY(enterprise_id,workspace_id,command_id) REFERENCES core_review_command_receipts(enterprise_id,workspace_id,command_id) DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(enterprise_id,workspace_id,winner_proposal_id) REFERENCES core_review_proposals(enterprise_id,workspace_id,proposal_id));
CREATE TABLE IF NOT EXISTS core_review_decisions (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, decision_id TEXT NOT NULL,
 proposal_id TEXT NOT NULL, action TEXT NOT NULL CHECK(action IN ('committed','kept_current','dismissed','superseded','covered_by_current','legacy_archived')), actor_id TEXT NOT NULL, reason TEXT NOT NULL,
 command_id TEXT, resolution_id TEXT, winner_proposal_id TEXT, fact_ref_json TEXT,
 recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,decision_id), UNIQUE(enterprise_id,workspace_id,proposal_id),
 FOREIGN KEY(enterprise_id,workspace_id,proposal_id) REFERENCES core_review_proposals(enterprise_id,workspace_id,proposal_id),
 FOREIGN KEY(enterprise_id,workspace_id,command_id) REFERENCES core_review_command_receipts(enterprise_id,workspace_id,command_id) DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(enterprise_id,workspace_id,resolution_id) REFERENCES core_review_group_resolutions(enterprise_id,workspace_id,resolution_id) DEFERRABLE INITIALLY DEFERRED,
 FOREIGN KEY(enterprise_id,workspace_id,winner_proposal_id) REFERENCES core_review_proposals(enterprise_id,workspace_id,proposal_id));
CREATE TABLE IF NOT EXISTS core_review_ui_drafts (
 enterprise_id TEXT NOT NULL, workspace_id TEXT NOT NULL, actor_id TEXT NOT NULL,
 ui_revision INTEGER NOT NULL, base_workspace_revision INTEGER NOT NULL,
 payload_json TEXT NOT NULL, updated_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,workspace_id,actor_id),
 FOREIGN KEY(enterprise_id,workspace_id) REFERENCES core_review_workspaces(enterprise_id,workspace_id));
CREATE INDEX IF NOT EXISTS core_review_pending_groups ON core_review_proposals(enterprise_id,workspace_id,group_id,generation);
"""

TERMINAL_STATUS = {"committed": "confirmed", "kept_current": "kept_current", "dismissed": "dismissed",
                   "superseded": "superseded", "covered_by_current": "already_known", "legacy_archived": "legacy_archived"}


class ReviewStore:
    def __init__(self, repo):
        self.repo = repo
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)
            for table in ("proposals", "decisions", "group_resolutions", "command_receipts", "entity_bindings"):
                for verb in ("UPDATE", "DELETE"):
                    db.execute(f"CREATE TRIGGER IF NOT EXISTS core_review_{table}_no_{verb.lower()} "
                               f"BEFORE {verb} ON core_review_{table} BEGIN SELECT RAISE(ABORT,'immutable review record'); END")

    @staticmethod
    def workspace(db, enterprise, workspace):
        return db.execute("SELECT * FROM core_review_workspaces WHERE enterprise_id=? AND workspace_id=?", (enterprise, workspace)).fetchone()

    @staticmethod
    def heads(db, enterprise, workspace):
        return db.execute("SELECT p.*,d.action decision_action,d.reason decision_reason FROM core_review_proposals p LEFT JOIN core_review_decisions d "
            "ON d.enterprise_id=p.enterprise_id AND d.workspace_id=p.workspace_id AND d.proposal_id=p.proposal_id "
            "WHERE p.enterprise_id=? AND p.workspace_id=? AND NOT EXISTS (SELECT 1 FROM core_review_proposals newer "
            "WHERE newer.enterprise_id=p.enterprise_id AND newer.workspace_id=p.workspace_id AND newer.candidate_id=p.candidate_id "
            "AND newer.proposal_revision>p.proposal_revision) ORDER BY p.recorded_at,p.candidate_id", (enterprise, workspace)).fetchall()

    def sync(self, db, account, enterprise, payload, *, legacy=False):
        """Import observations only. Never resurrect a terminal legacy proposal."""
        workspace = payload["id"]
        row = self.workspace(db, enterprise, workspace)
        created = row is None
        if created:
            db.execute("INSERT INTO core_review_workspaces VALUES(?,?,?,?,?,?,?,?)", (enterprise, workspace, account,
                "workspace-review/2", 1, "open", digest({"attachments": payload.get("attachments", []),
                    "observations": [{k: c.get(k) for k in ("id", "entity_id", "field", "value", "source")} for c in payload.get("candidates", [])]}), now_iso()))
        prior = {p["candidate_id"]: p for p in self.heads(db, enterprise, workspace)}
        added = False
        for candidate in payload.get("candidates", []):
            if candidate["id"] in prior:
                continue
            subject = candidate["entity_id"]
            if not subject.startswith("new_"):
                matches = db.execute("SELECT draft_subject_ref FROM core_review_entity_bindings WHERE enterprise_id=? AND workspace_id=? AND canonical_entity_id=?",
                    (enterprise, workspace, subject)).fetchall()
                if len(matches) == 1:
                    subject = matches[0]["draft_subject_ref"]
            # Unit differences never manufacture independent slots for one
            # canonical field. Typed validators must resolve/deny them.
            group = "group_" + digest([subject, candidate["field"], candidate.get("period")])[:32]
            generation = db.execute("SELECT COALESCE(MAX(generation),0) FROM core_review_proposals WHERE enterprise_id=? AND workspace_id=? AND group_id=?",
                (enterprise, workspace, group)).fetchone()[0] or 1
            if db.execute("SELECT 1 FROM core_review_group_resolutions WHERE enterprise_id=? AND workspace_id=? AND group_id=? AND generation=?",
                (enterprise, workspace, group, generation)).fetchone():
                generation += 1
            derived = prior.get(candidate.get("derived_from_candidate_id"))
            proposal = self._append(db, enterprise, workspace, candidate, subject, group, generation,
                derived_from=derived["proposal_id"] if derived else None,
                value=candidate.get("confirmed_value") if legacy and candidate.get("status") == "confirmed" else None)
            added = True
            entity, invalid_target = None, False
            canonical_target = candidate["entity_id"]
            if not canonical_target.startswith("new_"):
                try:
                    entity = self.repo._entity(account, enterprise, canonical_target, db)
                    if canonical_entity_type(entity["entity_type"]) != canonical_entity_type(candidate.get("entity_type")) or not field_is_in_scope(entity["entity_type"], candidate["field"]):
                        raise CoreError("invalid_field_scope", "Legacy target requires review.", 409)
                    self.bind(db, enterprise, workspace, subject, canonical_target, entity["entity_type"], {"kind": "observed_owned_target"})
                except CoreError:
                    if not legacy:
                        raise
                    invalid_target = True
                    db.execute("UPDATE core_review_workspaces SET lifecycle='review_required' WHERE enterprise_id=? AND workspace_id=?", (enterprise, workspace))
            status = candidate.get("status")
            action = None
            fact_ref = None
            if invalid_target:
                action = "legacy_archived"
            elif status == "already_known":
                current = db.execute("SELECT a.value_json,c.* FROM v03_current_facts c JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                    "WHERE c.enterprise_id=? AND c.entity_id=? AND c.field=? AND a.value_state='known'", (enterprise, canonical_target, candidate["field"])).fetchone()
                incoming = candidate.get("value")
                exact = current and (current["value_json"] == json_text(incoming) or candidate["field"] == "name" and
                    isinstance(incoming, str) and isinstance(json.loads(current["value_json"]), str) and incoming.strip().casefold() == json.loads(current["value_json"]).strip().casefold())
                action = "covered_by_current" if exact else "legacy_archived"
                fact_ref = {k: current[k] for k in ("entity_id", "field", "assertion_id", "resolution_id", "version")} if exact else None
            elif status in {"confirmed", "kept_current"} and legacy:
                # An old JSON flag alone is insufficient evidence of a fact write.
                expected_value = candidate.get("confirmed_value", candidate.get("value"))
                verified = None
                for assertion in db.execute("SELECT a.*,r.id resolution_id FROM v03_fact_assertions a JOIN v03_fact_resolutions r "
                    "ON r.enterprise_id=a.enterprise_id AND r.entity_id=a.entity_id AND r.field=a.field AND r.assertion_id=a.id "
                    "WHERE a.enterprise_id=? AND a.entity_id=? AND a.field=? AND a.actor_id=? AND r.actor_id=? AND a.value_state='known'",
                    (enterprise, canonical_target, candidate["field"], account, account)):
                    source = json.loads(assertion["source_json"])
                    if source.get("intake_id") == workspace and source.get("candidate_id") == candidate["id"] and source.get("owner_confirmed") is True and assertion["value_json"] == json_text(expected_value):
                        verified = assertion
                        break
                action = "committed" if status == "confirmed" and verified is not None else "legacy_archived"
                if action == "committed":
                    fact_ref = {"entity_id": canonical_target, "field": candidate["field"], "assertion_id": verified["id"], "resolution_id": verified["resolution_id"], "verification_basis": "legacy_assertion_resolution_exact_match"}
            elif status not in {"candidate", "conflict"} or legacy and payload.get("status") == "confirmed":
                action = "legacy_archived"
            if action:
                self.decision(db, enterprise, workspace, proposal, action, account,
                    "legacy_invalid_target_quarantined" if invalid_target else "conservative_legacy_import" if legacy else "exact_current_comparison", fact_ref=fact_ref)
        if added and not created:
            db.execute("UPDATE core_review_workspaces SET revision=revision+1 WHERE enterprise_id=? AND workspace_id=?", (enterprise, workspace))
        self.project(db, account, enterprise, payload)
        db.execute("UPDATE core_review_workspaces SET lifecycle=? WHERE enterprise_id=? AND workspace_id=?",
            (payload["review"]["lifecycle"], enterprise, workspace))
        return payload

    @staticmethod
    def _append(db, enterprise, workspace, candidate, subject, group, generation, *, revision=1, derived_from=None, value=None):
        observation = {k: candidate.get(k) for k in ("value", "value_type", "unit", "period", "field", "base_field", "entity_type")}
        proposed = {**observation, "value": candidate.get("value") if value is None else value}
        source = {"source": candidate.get("source"), "sources": candidate.get("sources", [])}
        proposal_id = new_id("review_proposal")
        payload_hash = digest([subject, group, generation, proposed, source, derived_from])
        db.execute("INSERT INTO core_review_proposals VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (enterprise, workspace,
            proposal_id, candidate["id"], revision, payload_hash, group, generation, subject,
            json_text(observation), json_text(proposed), json_text(source), derived_from, now_iso()))
        return dict(db.execute("SELECT p.*,NULL decision_action FROM core_review_proposals p WHERE enterprise_id=? AND workspace_id=? AND proposal_id=?",
            (enterprise, workspace, proposal_id)).fetchone())

    def amend(self, db, enterprise, workspace, row, candidate, value, account, command):
        amended = self._append(db, enterprise, workspace, candidate, row["draft_subject_ref"], row["group_id"], row["generation"],
            revision=row["proposal_revision"] + 1, derived_from=row["proposal_id"], value=value)
        self.decision(db, enterprise, workspace, row, "superseded", account, "owner_amended_revision", command,
                      winner=amended["proposal_id"])
        return amended

    @staticmethod
    def bind(db, enterprise, workspace, subject, entity_id, entity_type, evidence):
        old = db.execute("SELECT * FROM core_review_entity_bindings WHERE enterprise_id=? AND workspace_id=? AND draft_subject_ref=?",
            (enterprise, workspace, subject)).fetchone()
        if old:
            if old["canonical_entity_id"] != entity_id or old["entity_type"] != entity_type:
                raise CoreError("binding_conflict", "Nháp đã gắn với hồ sơ khác; cần tạo đề xuất mới.", 409)
            return
        db.execute("INSERT INTO core_review_entity_bindings VALUES(?,?,?,?,?,?,?,?)", (enterprise, workspace, subject,
            entity_id, entity_type, 1, json_text(evidence), now_iso()))

    @staticmethod
    def decision(db, enterprise, workspace, proposal, action, account, reason, command=None, resolution=None, winner=None, fact_ref=None):
        db.execute("INSERT INTO core_review_decisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (enterprise, workspace, new_id("review_decision"),
            proposal["proposal_id"], action, account, reason, command, resolution, winner, json_text(fact_ref) if fact_ref else None, now_iso()))

    def project(self, db, account, enterprise, payload):
        row = self.workspace(db, enterprise, payload["id"])
        if row is None:
            payload["review"] = {"schema_version": "workspace-review/2", "workspace_id": payload["id"], "revision": 0,
                "lifecycle": "review_required", "pending_candidate_ids": [], "pending_group_count": 0, "proposal_hashes": {},
                "migration_required": True}
            for candidate in payload.get("candidates", []):
                candidate["decision_state"] = "legacy_archived"
                candidate["readiness"] = "needs_source_review"
            return payload
        if row["owner_id"] != account:
            raise CoreError("not_found", "Không tìm thấy nháp được phép xem.", 404)
        heads = self.heads(db, enterprise, payload["id"])
        by_id = {p["candidate_id"]: p for p in heads}
        bindings = {r["draft_subject_ref"]: r["canonical_entity_id"] for r in db.execute(
            "SELECT * FROM core_review_entity_bindings WHERE enterprise_id=? AND workspace_id=?", (enterprise, payload["id"]))}
        for entity_id in set(bindings.values()):
            self.repo._entity(account, enterprise, entity_id, db)
        pending, hashes = [], {}
        for candidate in payload.get("candidates", []):
            p = by_id.get(candidate["id"])
            if not p:
                continue
            observation = json.loads(p["observed_json"])
            expected_entity = bindings.get(p["draft_subject_ref"], p["draft_subject_ref"])
            if candidate.get("entity_id") not in {p["draft_subject_ref"], expected_entity}:
                raise CoreError("invalid_field_scope", "Nháp không khớp liên kết hồ sơ đã ghi nhận; chưa lưu thay đổi.", 409)
            if any(candidate.get(key) != observation.get(key) for key in ("field", "base_field", "entity_type", "value")):
                raise CoreError("review_projection_changed", "Nội dung nháp không khớp quan sát đã ghi nhận; cần kiểm tra lại.", 409)
            action = p["decision_action"]
            candidate["decision_state"] = action or "pending"
            candidate["review_decision_reason"] = p["decision_reason"]
            candidate["proposal_id"] = p["proposal_id"]
            candidate["proposal_hash"] = p["proposal_hash"]
            candidate["draft_subject_ref"] = p["draft_subject_ref"]
            candidate["entity_id"] = bindings.get(p["draft_subject_ref"], p["draft_subject_ref"])
            candidate["readiness"] = "needs_binding" if candidate["entity_id"].startswith("new_") and candidate["field"] != "name" and candidate["entity_type"] == "product" else "conflict" if candidate.get("conflict") else "ready"
            if action:
                candidate["status"] = TERMINAL_STATUS[action]
            else:
                candidate["status"] = "conflict" if candidate.get("conflict") else "candidate"
                pending.append(candidate["id"])
            hashes[candidate["id"]] = p["proposal_hash"]
        decided = any(p["decision_action"] in {"committed", "kept_current", "dismissed", "superseded"} for p in heads)
        lifecycle = "review_required" if row["lifecycle"] == "review_required" else "partially_committed" if pending and decided else "open" if pending else "settled"
        payload["review"] = {"schema_version": "workspace-review/2", "workspace_id": payload["id"], "revision": row["revision"],
            "lifecycle": lifecycle, "pending_candidate_ids": pending, "pending_group_count": len({p["group_id"] for p in heads if not p["decision_action"]}),
            "proposal_hashes": hashes}
        latest = db.execute("SELECT payload_json FROM core_review_command_receipts WHERE enterprise_id=? AND workspace_id=? "
            "ORDER BY workspace_revision_after DESC LIMIT 1", (enterprise, payload["id"])).fetchone()
        payload["latest_confirmation_receipt"] = json.loads(latest[0]) if latest else None
        return payload

    def validate_heads(self, db, enterprise, payload, expected_revision, expected_hashes, selected):
        review = payload["review"]
        if review["lifecycle"] == "review_required":
            raise CoreError("review_required", "Nháp cần đối chiếu nguồn hoặc liên kết hồ sơ trước khi xác nhận.", 409)
        if expected_revision is not None and (isinstance(expected_revision, bool) or not isinstance(expected_revision, int) or expected_revision != review["revision"]):
            raise CoreError("workspace_changed", "Nháp đã thay đổi ở lượt khác. Hãy xem bản mới trước khi xác nhận.", 409)
        if expected_hashes is not None:
            if not isinstance(expected_hashes, dict) or any(expected_hashes.get(key) != review["proposal_hashes"].get(key) for key in selected):
                raise CoreError("proposal_changed", "Nội dung nháp khác bản đã xem. Hãy đối chiếu trước khi xác nhận.", 409)
        heads = {p["candidate_id"]: dict(p) for p in self.heads(db, enterprise, payload["id"])}
        if set(selected) - heads.keys():
            raise CoreError("proposal_changed", "Dữ kiện chưa thuộc phiên bản nháp đã ghi nhận; hãy mở lại để đối chiếu.", 409)
        if any(heads[key]["decision_action"] not in {None, "covered_by_current"} for key in selected):
            raise CoreError("candidate_already_confirmed", "Dữ kiện đã có quyết định. Chỉ chọn phần nháp đang chờ.", 409)
        return heads

    @staticmethod
    def prior_receipt(db, enterprise, account, command_kind, operation, request):
        if not isinstance(operation, str) or not operation.strip() or len(operation) > 200:
            raise CoreError("invalid_operation", "Cần mã thao tác hợp lệ.")
        row = db.execute("SELECT * FROM core_review_command_receipts WHERE enterprise_id=? AND actor_id=? AND command_kind=? AND client_operation_id=?",
            (enterprise, account, command_kind, operation)).fetchone()
        request_hash = digest(request)
        if row and row["request_hash"] != request_hash:
            raise CoreError("idempotency_conflict", "Mã thao tác đã dùng cho nội dung khác.", 409)
        return request_hash, json.loads(row["payload_json"]) if row else None

    def receipt(self, db, enterprise, workspace, account, operation, command_kind="confirm_selected"):
        row = db.execute("SELECT payload_json FROM core_review_command_receipts WHERE enterprise_id=? AND workspace_id=? AND actor_id=? AND client_operation_id=? AND command_kind=?",
            (enterprise, workspace, account, operation, command_kind)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy biên nhận được phép xem.", 404)
        value = json.loads(row[0])
        for ref in value.get("applied_fact_refs", []):
            self.repo._entity(account, enterprise, ref["entity_id"], db)
        return value

    def finish(self, db, account, enterprise, payload, operation, request_hash, command, kind, decisions, applied):
        workspace = payload["id"]
        db.execute("UPDATE core_review_workspaces SET revision=revision+1 WHERE enterprise_id=? AND workspace_id=?", (enterprise, workspace))
        self.project(db, account, enterprise, payload)
        review = payload["review"]
        receipt = {"schema_version": "review-receipt/2", "command_id": command, "operation_id": operation,
            "command_kind": kind, "workspace_id": workspace, "workspace_revision_after": review["revision"],
            "actor_id": account, "decisions": decisions, "applied_fact_refs": applied,
            "applied_fact_count": len(applied), "remaining_candidate_ids_at_commit": review["pending_candidate_ids"],
            "remaining_group_count_at_commit": review["pending_group_count"], "model_calls": 0, "committed_at": now_iso()}
        receipt.update(receipt_id=command, selected_candidate_ids=[d["candidate_id"] for d in decisions if d["action"] != "superseded"],
            committed_candidate_ids=[d["candidate_id"] for d in decisions if d["action"] == "committed"], committed_fact_count=len(applied))
        receipt["result_hash"] = digest(receipt)
        db.execute("INSERT INTO core_review_command_receipts VALUES(?,?,?,?,?,?,?,?,?,?,?)", (enterprise, workspace, command,
            account, kind, operation, request_hash, review["revision"], json_text(receipt), receipt["result_hash"], receipt["committed_at"]))
        db.execute("UPDATE core_review_workspaces SET lifecycle=? WHERE enterprise_id=? AND workspace_id=?", (review["lifecycle"], enterprise, workspace))
        payload["latest_confirmation_receipt"] = receipt
        return receipt
