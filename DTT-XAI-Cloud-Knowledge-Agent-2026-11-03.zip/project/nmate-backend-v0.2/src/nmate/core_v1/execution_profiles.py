"""Server-owned public-policy profiles; a profile never grants spending rights.

DF-061: hard output budget includes thinking AND visible text. Tier experiments
must be separately approved, not inferred from an old grant's unused balance.
"""

from decimal import Decimal
from nmate.v03.core import CoreError

VERSION = "policy-execution/1"
TIERS = {"high": Decimal("1"), "medium": Decimal(".75"), "low": Decimal(".5")}
ROLES = {"standard": (250000, "low"), "complex": (500000, "medium")}


def compile_profile(role, tier, *, input_upper, price_version=None):
    if (
        not isinstance(role, str)
        or not isinstance(tier, str)
        or role not in ROLES
        or tier not in TIERS
        or type(input_upper) is not int
        or input_upper < 0
    ):
        raise CoreError("INVALID_EXECUTION_PROFILE", "Cấu hình ngân sách suy luận chưa hợp lệ.", 409)
    from .gateway import PRICE_PROFILES, PRICE_VERSION

    version = PRICE_VERSION if price_version is None else price_version
    if not isinstance(version, str) or version not in PRICE_PROFILES:
        raise CoreError("INVALID_EXECUTION_PROFILE", "Chưa biết bảng giá của cấu hình đã lưu.", 409)
    rates = PRICE_PROFILES[version][role]
    input_rate = Decimal(rates["input_rate"])
    output_rate = Decimal(rates["output_rate"])
    ceiling, effort = ROLES[role]
    cap = int(Decimal(ceiling) * TIERS[tier])
    capacity = min(16384, int((Decimal(cap) - input_upper * input_rate) // output_rate))
    if capacity < 1024:
        raise CoreError(
            "PROFILE_NOT_FEASIBLE", "Đầu vào không còn đủ dung lượng đầu ra trong trần phí; chưa gọi AI.", 409
        )
    return dict(
        version=VERSION,
        role=role,
        tier=tier,
        thinking="adaptive",
        effort=effort,
        price_version=version,
        cap_microusd=cap,
        input_upper_tokens=input_upper,
        max_output_tokens=capacity,
    )


def validate_profile(value, role, *, input_upper=None):
    if not isinstance(value, dict) or not isinstance(value.get("price_version"), str):
        raise CoreError("INVALID_EXECUTION_PROFILE", "Cấu hình thực thi chưa đúng hợp đồng.", 409)
    original = value.get("input_upper_tokens") if input_upper is None else input_upper
    expected = compile_profile(
        role, value.get("tier"), input_upper=original, price_version=value.get("price_version")
    )
    # Typed equality, including booleans vs numeric fields.
    from .runtime_schema import digest

    if digest(value) != digest(expected):
        raise CoreError("INVALID_EXECUTION_PROFILE", "Cấu hình thực thi khác cấu hình máy chủ đã ghim.", 409)
    return expected
