"""Explicit, local schema-only operator lifecycle; never reached from app/MCP.

No business migration is registered here. Existing review/alias repair commands
remain their own domain authority and are deliberately not called by this tool.
Plans carry exact source/dependency and before/after schema hashes. Apply uses
one SQLite transaction for additive DDL and its durable receipt. An interrupted
attempt rolls back; a committed attempt can return its original receipt even
if the external receipt file was never written. Restore is explicit and uses
the same OS runtime ownership lock as the main app.
"""
from __future__ import annotations

import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import uuid

from nmate.main.runtime_lock import EnterpriseRuntimeLock
from .runtime_schema import canonical, digest, open_readonly, schema_objects, verify_runtime_database
from .registered_migrations import REGISTERED_TRIGGERS, is_registered_trigger


LEDGER = "core_schema_migration_receipts"
LEDGER_SQL = """CREATE TABLE core_schema_migration_receipts (
 version TEXT PRIMARY KEY, plan_sha256 TEXT NOT NULL, receipt_json TEXT NOT NULL)
"""
VERSION = "schema-migration-plan/1"


class SchemaLifecycleError(RuntimeError):
    pass


def _stamp():
    return datetime.now(timezone.utc).isoformat()


def _schema(db):
    return [item for item in schema_objects(db) if item["name"] != LEDGER]


def _dependency_manifest(source_root, names):
    root = Path(source_root).resolve()
    files = {}
    try:
        names = list(names) if not isinstance(names, (str, bytes)) else None
    except TypeError:
        names = None
    if names is None or not names or any(not isinstance(name, str) for name in names):
        raise SchemaLifecycleError("Cần danh sách đường dẫn dependency rõ ràng.")
    for name in sorted(set(names)):
        original = root / name
        candidate = original.resolve()
        if Path(name).is_absolute() or not candidate.is_relative_to(root):
            raise SchemaLifecycleError("Dependency phải nằm trong source root đã chỉ định.")
        if not candidate.is_file() or any(part.is_symlink() for part in (original, *original.parents)
                                           if part.is_relative_to(root)):
            raise SchemaLifecycleError("Không đọc được dependency migration.")
        files[name] = hashlib.sha256(candidate.read_bytes()).hexdigest()
    engine = {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
              for name in ("schema_lifecycle.py", "runtime_schema.py", "registered_migrations.py")}
    return {"files": files, "engine": engine,
            "runtime": {"python": sys.version.split()[0], "sqlite": sqlite3.sqlite_version}}


def _validate_statements(statements):
    if not isinstance(statements, list) or not statements or len(statements) > 100:
        raise SchemaLifecycleError("Cần từ 1 đến 100 lệnh schema additive đã được rà soát.")
    for sql in statements:
        if not isinstance(sql, str) or len(sql) > 100_000 or LEDGER.casefold() in sql.casefold():
            raise SchemaLifecycleError("Lệnh migration không hợp lệ hoặc chạm ledger quản trị.")
        if not is_registered_trigger(sql) and not re.match(r"(?is)^\s*(CREATE\s+(?:UNIQUE\s+)?(?:TABLE|INDEX)\s+|"
                        r"ALTER\s+TABLE\s+\S+\s+ADD\s+(?:COLUMN\s+)?)", sql):
            raise SchemaLifecycleError("Runner chỉ nhận CREATE TABLE/INDEX, ALTER TABLE ADD COLUMN hoặc trigger bất biến đã đăng ký; "
                                       "không thay dữ kiện, alias, grants hay lịch sử nghiệp vụ.")
        if re.search(r"(?is)\bAS\s+SELECT\b", sql):
            raise SchemaLifecycleError("Không sao chép dữ liệu nghiệp vụ trong migration schema.")


def _authorizer(action, first, second, database, trigger):
    if action == sqlite3.SQLITE_CREATE_TRIGGER:
        registered = REGISTERED_TRIGGERS.get(first)
        return sqlite3.SQLITE_OK if registered and registered[0] == second else sqlite3.SQLITE_DENY
    allowed_schema_write = first in {"sqlite_master", "sqlite_temp_master"}
    if action in {sqlite3.SQLITE_INSERT, sqlite3.SQLITE_UPDATE, sqlite3.SQLITE_DELETE}:
        return sqlite3.SQLITE_OK if allowed_schema_write else sqlite3.SQLITE_DENY
    if action == sqlite3.SQLITE_SELECT:
        return sqlite3.SQLITE_DENY
    denied = {sqlite3.SQLITE_ATTACH, sqlite3.SQLITE_DETACH, sqlite3.SQLITE_DROP_TABLE,
              sqlite3.SQLITE_DROP_INDEX, sqlite3.SQLITE_CREATE_TRIGGER, sqlite3.SQLITE_DROP_TRIGGER,
              sqlite3.SQLITE_CREATE_VIEW, sqlite3.SQLITE_DROP_VIEW, sqlite3.SQLITE_CREATE_VTABLE,
              sqlite3.SQLITE_DROP_VTABLE, sqlite3.SQLITE_TRANSACTION, sqlite3.SQLITE_SAVEPOINT,
              sqlite3.SQLITE_PRAGMA}
    if action in denied or (action == sqlite3.SQLITE_FUNCTION and str(second).casefold() == "load_extension"):
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


def _execute(db, statements, *, after_statement=None):
    _validate_statements(statements)
    db.set_authorizer(_authorizer)
    try:
        for index, sql in enumerate(statements):
            db.execute(sql)  # executescript would implicitly commit; never use it.
            if after_statement:
                after_statement(index)
    finally:
        db.set_authorizer(None)


def _validate_plan(plan, source_root):
    if (not isinstance(plan, dict) or plan.get("schema_version") != VERSION
            or not isinstance(plan.get("version"), str)
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", plan["version"])):
        raise SchemaLifecycleError("Version migration không hợp lệ.")
    _validate_statements(plan.get("statements"))
    if plan.get("source") != _dependency_manifest(source_root, plan.get("source", {}).get("files", {})):
        raise SchemaLifecycleError("Checksum nguồn/dependency đã đổi; cần lập và rà kế hoạch mới.")
    if plan.get("plan_sha256") != digest({k: v for k, v in plan.items() if k != "plan_sha256"}):
        raise SchemaLifecycleError("Plan checksum không khớp; chưa sửa DB.")
    return plan


def create_plan(database, *, version, statements, source_root, dependency_files):
    """Read the original and rehearse exclusively in an in-memory backup."""
    _validate_statements(statements)
    source = _dependency_manifest(source_root, dependency_files)
    with closing(open_readonly(database)) as original, closing(sqlite3.connect(":memory:")) as rehearsal:
        original.backup(rehearsal)
        before = digest(_schema(rehearsal))
        rehearsal.execute("PRAGMA foreign_keys=ON")
        rehearsal.execute("BEGIN IMMEDIATE")
        try:
            _execute(rehearsal, statements)
            after = digest(_schema(rehearsal))
            if rehearsal.execute("PRAGMA foreign_key_check").fetchone():
                raise SchemaLifecycleError("Dry-run chưa đạt kiểm tra khóa ngoại.")
        finally:
            rehearsal.rollback()
    plan = {"schema_version": VERSION, "version": version, "statements": statements,
            "source": source, "before_schema_sha256": before, "after_schema_sha256": after,
            "required_receipts": [], "dry_run": {"passed": True, "original_writes": 0,
                                                   "provider_calls": 0}}
    plan["plan_sha256"] = digest(plan)
    return _validate_plan(plan, source_root)


def _validate_ledger(db):
    existing = db.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (LEDGER,)).fetchone()
    if existing:
        with closing(sqlite3.connect(":memory:")) as probe:
            probe.execute(LEDGER_SQL)
            expected = probe.execute("SELECT sql FROM sqlite_master WHERE name=?", (LEDGER,)).fetchone()[0]
        if existing[0] != expected:
            raise SchemaLifecycleError("Schema ledger migration khác phiên bản đã biết.")
    return bool(existing)


def apply_plan(database, plan, *, source_root, backup_path=None, after_statement=None, after_commit=None):
    """Explicit administrative apply, with no inference/HTTP or business DML."""
    _validate_plan(plan, source_root)  # Before lock/file creation or DB write.
    database = Path(database).resolve()
    if not database.is_file():
        raise SchemaLifecycleError("Cần DB hiện có; dùng init riêng cho DB mới.")
    with EnterpriseRuntimeLock(database), closing(sqlite3.connect(database, timeout=15)) as db:
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("BEGIN IMMEDIATE")
        try:
            has_ledger = _validate_ledger(db)
            prior = db.execute(f"SELECT plan_sha256,receipt_json FROM {LEDGER} WHERE version=?", (plan["version"],)).fetchone() if has_ledger else None
            if prior:
                if prior[0] != plan["plan_sha256"]:
                    raise SchemaLifecycleError("Version đã dùng với checksum khác; không ghi đè migration cũ.")
                db.rollback()
                return json.loads(prior[1])
            if digest(_schema(db)) != plan["before_schema_sha256"]:
                raise SchemaLifecycleError("Precondition schema đã đổi; cần dry-run và kế hoạch mới.")
            for required in plan.get("required_receipts", []):
                if not has_ledger or not db.execute(f"SELECT 1 FROM {LEDGER} WHERE version=? AND plan_sha256=?",
                                                   (required["version"], required["plan_sha256"])).fetchone():
                    raise SchemaLifecycleError("Thiếu migration dependency đã commit.")
            backup_path = (Path(backup_path) if backup_path else database.with_name(
                database.name + ".before-" + plan["version"] + "-" + uuid.uuid4().hex + ".sqlite3"))
            backup = backup_database(database, backup_path)
            if not has_ledger:
                db.execute(LEDGER_SQL)
            _execute(db, plan["statements"], after_statement=after_statement)
            if digest(_schema(db)) != plan["after_schema_sha256"] or db.execute("PRAGMA foreign_key_check").fetchone():
                raise SchemaLifecycleError("Postcondition migration chưa đạt; toàn bộ lượt đã rollback.")
            receipt = {"schema_version": "schema-migration-receipt/1", "version": plan["version"],
                       "plan_sha256": plan["plan_sha256"], "source": plan["source"],
                       "before_schema_sha256": plan["before_schema_sha256"],
                       "after_schema_sha256": plan["after_schema_sha256"], "committed_at": _stamp(),
                       "backup_sha256": backup["sha256"],
                       "backup_filename": backup_path.name,
                       "business_data_writes": 0, "provider_calls": 0}
            db.execute(f"INSERT INTO {LEDGER} VALUES(?,?,?)", (plan["version"], plan["plan_sha256"], canonical(receipt)))
            db.commit()
            if after_commit:
                after_commit()
            return receipt
        except BaseException:
            db.rollback()
            raise


def backup_database(database, destination):
    """Consistent explicit backup; output must be new and outside the DB sidecars."""
    source, target = Path(database).resolve(), Path(destination).resolve()
    if target in {source, *(Path(str(source) + suffix) for suffix in ("-wal", "-shm", "-journal"))} or target.exists():
        raise SchemaLifecycleError("Backup cần đường dẫn mới, khác DB và sidecar hiện hành.")
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".backup-" + uuid.uuid4().hex + ".sqlite3")
    # The caller holds the runtime lock across its complete backup/apply window.
    try:
        staging.open("xb").close()
        with closing(open_readonly(source)) as original, closing(sqlite3.connect(staging)) as saved:
            original.backup(saved)
            if saved.execute("PRAGMA integrity_check").fetchone()[0] != "ok" or saved.execute("PRAGMA foreign_key_check").fetchone():
                raise SchemaLifecycleError("Backup chưa đạt kiểm tra toàn vẹn.")
            checkpoint = saved.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            if checkpoint[0] or saved.execute("PRAGMA journal_mode=DELETE").fetchone()[0] != "delete":
                raise SchemaLifecycleError("Backup chưa tạo được snapshot offline.")
        if any(Path(str(staging) + suffix).exists() for suffix in ("-wal", "-shm", "-journal")):
            raise SchemaLifecycleError("Backup còn sidecar; chưa công bố snapshot.")
        os.link(staging, target)  # Exclusive publication; never replace an existing destination.
    finally:
        if staging.exists():
            staging.unlink()
    return {"schema_version": "schema-backup/1", "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
            "schema_sha256": _file_schema_hash(target), "provider_calls": 0}


def _file_schema_hash(path):
    with closing(open_readonly(path)) as db:
        return digest(schema_objects(db))


def restore_database(database, backup, *, expected_backup_sha256):
    """Explicit restore under runtime lock; never an automatic rollback policy."""
    target, source = Path(database).resolve(), Path(backup).resolve()
    if source == target or not target.is_file() or not source.is_file():
        raise SchemaLifecycleError("Restore cần DB hiện có và backup riêng.")
    with EnterpriseRuntimeLock(target), EnterpriseRuntimeLock(source), closing(open_readonly(source)) as saved:
        # A file hash cannot attest bytes still in a WAL. Our backup outputs
        # are offline DELETE-journal files; reject other inputs, never ignore WAL.
        if (saved.execute("PRAGMA journal_mode").fetchone()[0] == "wal"
                or any(Path(str(source) + suffix).exists() for suffix in ("-wal", "-shm", "-journal"))):
            raise SchemaLifecycleError("Backup phải là snapshot offline không có WAL/sidecar.")
        saved.execute("BEGIN")
        saved.execute("SELECT COUNT(*) FROM sqlite_master").fetchone()
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected_backup_sha256:
            raise SchemaLifecycleError("Checksum backup không khớp; chưa restore.")
        if saved.execute("PRAGMA integrity_check").fetchone()[0] != "ok" or saved.execute("PRAGMA foreign_key_check").fetchone():
            raise SchemaLifecycleError("Backup chưa đạt kiểm tra toàn vẹn.")
        with closing(sqlite3.connect(target)) as current:
            saved.backup(current)
            if current.execute("PRAGMA integrity_check").fetchone()[0] != "ok" or current.execute("PRAGMA foreign_key_check").fetchone():
                raise SchemaLifecycleError("Cần đối soát sau restore; không tự chạy runtime.")
        if hashlib.sha256(source.read_bytes()).hexdigest() != expected_backup_sha256:
            raise SchemaLifecycleError("Backup đã đổi khi restore; cần đối soát, không tự chạy runtime.")
    return {"schema_version": "schema-restore-receipt/1", "restored_schema_sha256": _file_schema_hash(target),
            "backup_sha256": expected_backup_sha256, "provider_calls": 0}


def initialize_new_database(database):
    """Existing constructor bootstrap, explicit only, atomic publish for new DB."""
    target = Path(database).resolve()
    if target.exists():
        raise SchemaLifecycleError("Init chỉ dùng cho DB mới; không khởi tạo lại dữ liệu đã có.")
    target.parent.mkdir(parents=True, exist_ok=True)
    staging = target.with_name(target.name + ".init-" + uuid.uuid4().hex + ".sqlite3")
    with EnterpriseRuntimeLock(target):
        if target.exists():
            raise SchemaLifecycleError("DB vừa được tạo bởi tiến trình khác; đã dừng init.")
        try:
            from nmate.main.app import make_main_app
            def denied(*args, **kwargs):
                raise SchemaLifecycleError("Init không được gọi provider.")
            make_main_app(staging, request_fn=denied, gateway_request_fn=denied,
                          refresh_sources=True, gateway_enabled=False)
            readiness = verify_runtime_database(staging)
            with closing(sqlite3.connect(staging)) as prepared:
                checkpoint = prepared.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                if checkpoint[0] or prepared.execute("PRAGMA journal_mode=DELETE").fetchone()[0] != "delete":
                    raise SchemaLifecycleError("DB khởi tạo chưa đóng checkpoint; chưa công bố runtime.")
            if any(Path(str(staging) + suffix).exists() for suffix in ("-wal", "-shm", "-journal")):
                raise SchemaLifecycleError("DB khởi tạo còn sidecar; chưa công bố runtime.")
            # Windows rename refuses an existing destination; target is also OS-locked.
            # Hard-link publishes exclusively on supported local filesystems;
            # unlike replace/rename on POSIX it can never overwrite a new DB.
            os.link(staging, target)
            return {"schema_version": "schema-initialization-receipt/1", "readiness": readiness,
                    "created_at": _stamp(), "provider_calls": 0, "business_accounts_created": 0,
                    "budget_grants_created": 0}
        finally:
            for file in (staging, Path(str(staging) + "-wal"), Path(str(staging) + "-shm")):
                if file.is_file():
                    try:
                        file.unlink()
                    except OSError:
                        # Preserve an unpublishable staging file if another
                        # handle still owns it. Never hide the original failure
                        # or delete a WAL beneath an outstanding connection.
                        break


def main(argv=None):
    parser = argparse.ArgumentParser(description="Quản trị schema local tường minh; không gọi AI hay cấp hạn mức.")
    commands = parser.add_subparsers(dest="command", required=True)
    for action in ("verify", "init"):
        sub = commands.add_parser(action)
        sub.add_argument("--database", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = verify_runtime_database(args.database) if args.command == "verify" else initialize_new_database(args.database)
    except (RuntimeError, OSError, sqlite3.DatabaseError) as exc:
        print(canonical({"ok": False, "error": str(exc)}), file=sys.stderr)
        return 2
    print(canonical({"ok": True, "result": result}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
