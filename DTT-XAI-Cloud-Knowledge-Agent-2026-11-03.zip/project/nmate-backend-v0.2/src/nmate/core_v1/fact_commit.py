"""One authorized SQL fact writer for profile, labels, intake and core proposals.

This service has no model/transport capability and never initializes schemas
inside a caller's transaction. Legacy private-owner authorization is retained;
staff can propose through CoreSSOTService but cannot commit through this port.
"""
from __future__ import annotations


class FactCommitService:
    def __init__(self, repo):
        self.repo = repo

    def commit(self, account_id, enterprise_id, entity_id, facts, expected_version,
               operation_id, *, actor=None, reason=None, db=None):
        with self.repo._fact_transaction(db) as connection:
            from nmate.v03.core import CoreError
            if actor is not None and actor != account_id and actor != {"account_id": account_id}:
                raise CoreError("actor_mismatch", "Không thể ghi thay chủ thể khác.", 403)
            if not isinstance(facts, list) or len(facts) > 100:
                raise CoreError("invalid_facts", "Cần danh sách tối đa 100 dữ kiện.")
            if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 0:
                raise CoreError("expected_version_required", "Cần phiên bản thông tin hiện đang sửa.", 409)
            access = None
            if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                                  "AND name='core_v1_resources'").fetchone():
                from .ssot import CoreSSOTService
                access = CoreSSOTService(self.repo, initialize=False)
                access.membership(account_id, enterprise_id, connection)
                access._require(connection, account_id, enterprise_id, entity_id)
            else:
                self.repo._entity(account_id, enterprise_id, entity_id, connection)
            # DF-046: exact replay is a read. Archive or loss of WRITE cannot
            # turn it into a new command; all fields in its immutable result
            # still require current READ. Nothing is saved on this branch.
            _request_hash, previous = self.repo._operation(connection, account_id, enterprise_id,
                "facts", operation_id, [entity_id, facts, expected_version, reason])
            if previous is not None:
                if access:
                    access.authorize_fact_receipt(connection, account_id, enterprise_id, previous)
                return previous
            # The existing repository gate is stricter than membership alone:
            # it requires active owner membership and that exact private entity.
            self.repo.require_active_entity(account_id, enterprise_id, entity_id, connection)
            if access:
                access.membership(account_id, enterprise_id, connection, owner=True)
                if isinstance(facts, list):
                    for fact in facts:
                        if isinstance(fact, dict) and isinstance(fact.get("field"), str):
                            access._require(connection, account_id, enterprise_id,
                                            entity_id, field=fact["field"])
            return self.repo._apply_authorized_facts(account_id, enterprise_id, entity_id,
                facts, expected_version, operation_id, actor=actor, reason=reason, db=connection)
