"""Authenticated MCP boundary for the shared core and private policy chat.

Budget approval and domain-role bootstrapping are deliberately operator-only.
No browser request can grant itself either capability.
"""
from __future__ import annotations

import base64
import json
import time
from typing import Annotated, Any, Literal

from pydantic import Field

from nmate.v03.core import CoreError, json_text, new_id, now_iso, require_valid_entity_name
from nmate.v03.mcp import Identifier, Operation, Result
from nmate.policy_v1.service import PolicyService, digest
from .gateway import ModelGateway
from .ssot import CoreSSOTService
from nmate.policy_v05.integration import Policy05Integration, POLICY05_TOOLS


CORE_TOOLS = {"core_list_entities", "core_create_entity", "core_get_context", "core_propose_facts", "core_confirm_facts", "core_list_proposals",
              "core_get_enterprise_profile", "core_open_enterprise_profile",
              "core_list_members", "core_add_member", "core_remove_member", "core_grant_resource", "core_revoke_resource",
              "core_gateway_status", "policy_prepare", "policy_get", "policy_list", "policy_start",
              "policy_review_member", "policy_publish_member", "policy_release_pack", "policy_propose_member",
              "policy_list_sources", "policy_refresh_source", "policy_review_queue", "policy_withdraw_member",
              "policy_register_source", "policy_add_snapshot", "policy_check_source",
              "policy_refresh_schedule", "policy_refresh_jobs", "policy_refresh_disable",
              "finance_stage_metrics", "finance_preview", "finance_authorize_egress", "finance_revoke_egress", "finance_parse_excel",
              "get_conversation", "list_conversations", "prepare_chat_draft"} | POLICY05_TOOLS


class CoreIntegration:
    tool_names = CORE_TOOLS

    def __init__(self, repo, missions, intake, *, api_key=None, request_fn=None, gateway_enabled=False):
        self.repo, self.intake = repo, intake
        self.core = CoreSSOTService(repo)
        from .enterprise_profile import EnterpriseProfileService
        self.enterprise_profiles = EnterpriseProfileService(repo, self.core)
        from .finance import FinanceService
        self.finance = FinanceService(repo, self.core)
        self.gateway = ModelGateway(repo, core=self.core, finance=self.finance, api_key=api_key,
                                    request_fn=request_fn, enabled=gateway_enabled)
        self.policy = PolicyService(repo, self.core, self.gateway)
        if not getattr(repo, "managed_runtime", False):
            self.policy.catalog.bootstrap_official_notice()
            self.policy.catalog.bootstrap_digital_source_pack()
        from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
        self.source_jobs = SourceRefreshJobs(self.policy.catalog)
        if not getattr(repo, "managed_runtime", False):
            self.source_jobs.bootstrap_official_notice()
        self._last_source_check = 0
        self.conversations = intake.conversations_factory(intake)
        self.legacy_adapter = None
        self.policy05 = Policy05Integration(self)

    def recover_interrupted(self):
        self.gateway.recover_interrupted()
        if self.legacy_adapter:
            self.legacy_adapter.recover()
        self.policy.recover_interrupted()

    def gateway_status(self, account, enterprise):
        result = self.gateway.status(account, enterprise, provision=False)
        if self.legacy_adapter:
            legacy = self.legacy_adapter.status(account, enterprise)
            result["legacy_paid_gate"] = legacy
            result["capability_gates"] = legacy["purposes"]
        return result

    async def execute_next(self):
        worked = await self.policy.execute_next()
        if not worked and time.monotonic()-self._last_source_check >= 30:
            self._last_source_check = time.monotonic()
            worked = await self.source_jobs.execute_next()
        return worked

    def create_entity(self, account, enterprise, entity_type, name, operation_id):
        if entity_type not in {"enterprise", "product"}:
            raise CoreError("INVALID_INPUT", "Loại hồ sơ chưa được hỗ trợ.")
        require_valid_entity_name(name,entity_type)
        with self.repo.connection(write=True) as db:
            self.core.membership(account, enterprise, db, owner=True)
            request_hash, prior = self.repo._operation(db, account, enterprise, "core_create_entity", operation_id, [entity_type, name.strip()])
            if prior is not None:
                return prior
            if entity_type == "product":
                self.repo._check_product_name(db, enterprise, name)
            entity_id = new_id("entity")
            stamp = now_iso()
            db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) VALUES(?,?,?,?,NULL,?,?)",
                       (entity_id, enterprise, entity_type, name.strip(), account, stamp))
            self.repo._remember_name(db, entity_id, name.strip())
            self.repo._advance_revision(db, enterprise, account, [{"entity_id": entity_id, "field": "__created__"}])
            value = {"id": entity_id, "entity_id": entity_id, "entity_type": entity_type, "name": name.strip(), "version": 0,
                     "facts": [], "message": "Đã tạo hồ sơ trống. Dữ kiện chỉ vào hồ sơ chuẩn sau khi chủ doanh nghiệp xác nhận."}
            self.repo._save_operation(db, account, enterprise, "core_create_entity", operation_id, request_hash, value)
            return value

    def _chat(self, db, account, enterprise, conversation_id):
        self.core.membership(account, enterprise, db)
        row = db.execute("SELECT payload_json FROM v04_conversations WHERE id=? AND enterprise_id=? AND owner_id=?",
                         (conversation_id, enterprise, account)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy cuộc trao đổi của tài khoản này.", 404)
        return json.loads(row[0])

    def prepare(self, account, enterprise, question, operation, conversation_id=None, product_entity_id=None, target_date=None):
        # The single service request commits the case and chat link together.
        # Closing a browser cannot leave a paid operation or a case to be linked later.
        with self.repo.connection() as db:
            self.core.membership(account, enterprise, db)
            if conversation_id:
                self._chat(db, account, enterprise, conversation_id)
            recorded = db.execute(
                "SELECT o.request_hash,m.request_json,m.id FROM pol_operations o JOIN pol_missions m ON m.id=o.mission_id "
                "AND m.enterprise_id=o.enterprise_id AND m.owner_id=o.account_id "
                "WHERE o.enterprise_id=? AND o.account_id=? AND o.kind='prepare' AND o.operation_id=?",
                (enterprise, account, operation)).fetchone()
            if recorded:
                # Implicit enterprise scope and default date are part of the
                # committed snapshot, not new user commands on receipt replay.
                request = json.loads(recorded["request_json"])
                selected = [entity_id for entity_id in request.get("entity_ids") or []
                            if db.execute("SELECT 1 FROM v03_entities WHERE id=? AND enterprise_id=? AND entity_type='product'",
                                          (entity_id, enterprise)).fetchone()]
                if (digest(request) != recorded["request_hash"]
                        or not isinstance(question, str) or question.strip() != request.get("question")
                        or conversation_id != request.get("conversation_id")
                        or selected != ([product_entity_id] if product_entity_id else [])
                        or target_date is not None and target_date != request.get("target_date")):
                    raise CoreError("idempotency_conflict", "Mã thao tác đã dùng cho câu hỏi hoặc phạm vi khác.", 409)
                case_id = recorded["id"]
            else:
                case_id = None
        if case_id:
            case = self.get_case(account, enterprise, case_id)
            return {"policy_case": case, "conversation_id": case.get("conversation_id")}
        if product_entity_id and not self.core.can_read(account, enterprise, product_entity_id):
            raise CoreError("not_found", "Không tìm thấy hồ sơ sản phẩm được phép sử dụng.", 404)
        from .enterprise_profile import bound_enterprise_profile_id
        with self.repo.connection() as db:
            bound = bound_enterprise_profile_id(self.core, db, account, enterprise)
        entities = ([bound] if bound else [e["id"] for e in self.core.list_entities(account, enterprise)
                    if e["entity_type"] in {"enterprise", "company"}])
        if product_entity_id:
            entities.append(product_entity_id)

        def commit(db, case):
            cid = conversation_id or new_id("conversation")
            stamp = now_iso()
            if conversation_id:
                chat = self._chat(db, account, enterprise, cid)
            else:
                chat = {"id": cid, "enterprise_id": enterprise, "owner_id": account, "title": question.strip()[:140],
                        "created_at": stamp, "updated_at": stamp, "messages": [], "intake_ids": [], "drafts": {},
                        "active_intake_id": None, "operation_ids": [], "mission_ids": []}
                db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)",
                           (cid, enterprise, account, json_text(chat), stamp, stamp))
            if len(chat["messages"]) >= 200:
                raise CoreError("conversation_limit", "Cuộc trao đổi đã dài; hãy mở chat mới để tiếp tục.")
            case["conversation_id"] = cid
            chat.setdefault("policy_case_ids", []).append(case["id"])
            chat.update(active_policy_case_id=case["id"], task_hint="hanoi_policy", latest_operation_id=operation)
            if operation not in chat["operation_ids"]:
                chat["operation_ids"].append(operation)
            chat["messages"].extend([
                {"id": new_id("message"), "role": "user", "text": question.strip(), "created_at": stamp,
                 "attachments": [], "kind": "message", "policy_case_id": case["id"]},
                {"id": new_id("message"), "role": "assistant", "text": case["lead_vi"], "created_at": stamp,
                 "attachments": [], "kind": "policy_result", "policy_case_id": case["id"]}])
            chat["updated_at"] = stamp
            db.execute("UPDATE v04_conversations SET payload_json=?,updated_at=? WHERE id=? AND enterprise_id=? AND owner_id=?",
                       (json_text(chat), stamp, cid, enterprise, account))

        case = self.policy.prepare(account, enterprise, question, operation, entity_ids=entities, target_date=target_date,
                                   conversation_id=conversation_id, on_commit=commit)
        # The first render and a later reload use the same authorized read
        # projection, including the separately labeled free source guide.
        return {"policy_case": self.get_case(account, enterprise, case["id"]),
                "conversation_id": case.get("conversation_id")}

    def _case_gate(self, account, enterprise, case):
        case = dict(case)
        gate = self.gateway.status(account, enterprise, provision=False)
        policy_intent = (case.get("scope_update") or {}).get("intent") or case.get("intent", {})
        preferred_role = "complex" if max(len(policy_intent.get("outcome_types", [])), len(policy_intent.get("goals", []))) > 1 else "standard"
        grants = [g for g in gate["grants"] if "hanoi_policy_synthesis" in g["purposes"] and g["remaining_calls"]
                  and preferred_role in g["roles"]]
        scope = case.get("scope_update") or case
        ready = case.get("status") == "prepared" and not case.get("is_historical") and scope.get("startable", True)
        approved = gate["approved"] and bool(grants) and ready
        selected = grants[0] if approved else None
        role = preferred_role
        profile = next(p for p in gate["profiles"] if p["role"] == role)
        gate_reason = ("Kế hoạch cũ chưa giữ đủ mục tiêu; cần lập lại kế hoạch miễn phí trước khi gửi Claude."
                       if scope.get("requires_reprepare") else
                       "Câu hỏi ngoài phạm vi, cần làm rõ mục tiêu hoặc chưa có nguồn phù hợp; chưa gửi Claude."
                       if scope.get("startable") is False else gate["reason_vi"])
        case["cost_gate"] = {**case.get("cost_gate", {}), "approved": approved, "reason_vi": gate_reason,
                             "estimated_calls": 1 if ready else None, "max_cost_usd": selected["max_cost_usd"]-selected["held_usd"] if selected else 0,
                             "model_id": profile["model"], "model_role": "complex" if role == "complex" else "simple",
                             "budget_grant_id": selected["id"] if selected else None}
        with self.repo.connection() as db:
            op = db.execute("SELECT operation_id FROM pol_operations WHERE enterprise_id=? AND account_id=? AND mission_id=? AND kind='prepare'",
                            (enterprise, account, case["id"])).fetchone()
            case["prepare_operation_id"] = op[0] if op else None
            attempts = [dict(r) for r in db.execute(
                "SELECT id,model,state,validation_state,publication_state,error_code,usage_json,actual_microusd,held_microusd,dispatched_at "
                "FROM core_model_attempts WHERE enterprise_id=? AND actor_id=? AND operation_id=? ORDER BY created_at,id",
                (enterprise, account, case.get("research_operation_id")))]
            for attempt in attempts:
                attempt["usage"] = json.loads(attempt.pop("usage_json") or "{}")
                attempt["estimated_usd"] = None if attempt["actual_microusd"] is None else attempt["actual_microusd"]/1e6
                attempt["held_usd"] = attempt.pop("held_microusd")/1e6
                attempt.pop("actual_microusd")
            case["cost"] = {"calls": attempts, "paid_calls": sum(bool(a["dispatched_at"]) for a in attempts),
                            "held_usd": sum(a["held_usd"] for a in attempts),
                            "billing_note_vi": "Lượt chưa rõ kết quả có thể đã tính phí; không tự gửi lại."}
            case["provider_calls"] = case["cost"]["paid_calls"]
        return case

    def get_case(self, account, enterprise, case_id):
        from .workspace_contract import resource_workspace_contract
        case = self._case_gate(account, enterprise, self.policy.get(account, enterprise, case_id))
        with self.repo.connection() as db:
            case["workspace_contract"] = resource_workspace_contract(self.repo, account, enterprise, case, db, kind="policy")
        return case

    def get_chat(self, account, enterprise, conversation_id):
        with self.repo.connection() as db:
            chat = self._chat(db, account, enterprise, conversation_id)
            role = self.core.membership(account, enterprise, db)["role"]
        if role == "owner":
            view = self.conversations.get(account, enterprise, conversation_id)
        else:
            # Collaboration never weakens the owner-private legacy read path.
            if chat.get("intake_ids") or chat.get("mission_ids"):
                raise CoreError("forbidden", "Tài khoản chưa được cấp quyền đọc phần tài liệu riêng này.", 403)
            view = {**chat, "intake": None, "missions": [], "model_calls": 0, "status": "ready", "cost": {"paid_calls": 0}}
        view["policy_cases"] = [self.get_case(account, enterprise, cid) for cid in chat.get("policy_case_ids", [])]
        view["active_policy_case_id"] = chat.get("active_policy_case_id")
        view["policy_drafts"] = [self.policy05.workbench.get_draft(account, enterprise, draft_id)
                                 for draft_id in chat.get("policy_draft_ids", [])]
        view["active_policy_draft_id"] = chat.get("active_policy_draft_id")
        policy_attempts = [a for c in view["policy_cases"] for a in c.get("cost", {}).get("calls", [])]
        view["model_calls"] = view.get("model_calls", 0)+sum(bool(a["dispatched_at"]) for a in policy_attempts)
        view["cost"] = {**view.get("cost", {}), "gateway_calls": policy_attempts,
                        "paid_calls": view.get("cost", {}).get("paid_calls", 0)+sum(bool(a["dispatched_at"]) for a in policy_attempts)}
        if chat.get("task_hint") == "hanoi_policy" and view["policy_cases"]:
            active = next((c for c in view["policy_cases"] if c["id"] == chat.get("active_policy_case_id")), view["policy_cases"][-1])
            effective = active.get("scope_update") or active
            view["status"] = (effective["result_status"] if effective.get("result_status") in {"unsupported", "needs_clarification"}
                              else active["status"])
            for message in view["messages"]:
                if message.get("kind") == "policy_result":
                    case = next((c for c in view["policy_cases"] if c["id"] == message.get("policy_case_id")), None)
                    if case:
                        message["text"] = case["lead_vi"]
            view["workspace_contract"] = active.get("workspace_contract")
        elif chat.get("task_hint") == "export_research" and view.get("missions"):
            active = next((mission for mission in view["missions"] if mission["id"] == view.get("active_mission_id")), view["missions"][-1])
            view["workspace_contract"] = active.get("workspace_contract")
        return view

    def list_chats(self, account, enterprise):
        with self.repo.connection() as db:
            self.core.membership(account, enterprise, db)
            ids = [r[0] for r in db.execute("SELECT id FROM v04_conversations WHERE enterprise_id=? AND owner_id=? ORDER BY updated_at DESC,id DESC LIMIT 50",
                                          (enterprise, account))]
        result = []
        for cid in ids:
            try:
                view = self.get_chat(account, enterprise, cid)
            except CoreError as exc:
                if exc.status_code in {403, 404}:
                    continue
                raise
            from nmate.main.history import history_metadata
            result.append({**{k: view.get(k) for k in ("id", "title", "created_at", "updated_at", "status", "task_hint",
                          "active_intake_id", "intake_ids", "mission_ids", "active_mission_id", "latest_operation_id", "operation_ids",
                          "policy_case_ids", "active_policy_case_id", "policy_draft_ids", "active_policy_draft_id",
                          "pending_operation_id", "operation_error")},
                           **history_metadata(view)})
        return result

    def register_tools(self, server, call):
        self.policy05.register_tools(server, call)
        for name in ("get_conversation", "list_conversations"):
            server.remove_tool(name)

        @server.tool(structured_output=True, description="Explicit free text-only chat draft preparation using a bounded local parser. No model, no research, no SSOT write. Owner must confirm proposed facts separately; retains owner-private conversation and draft IDs.")
        async def prepare_chat_draft(enterprise_id: Identifier, text: Annotated[str, Field(min_length=1, max_length=4000)],
                                     operation_id: Operation, conversation_id: Identifier | None = None,
                                     product_entity_id: Identifier | None = None, draft: dict[str, Any] | None = None,
                                     target_intake_id: Identifier | None = None,
                                     task_hint: Literal["profile_intake", "export_research", "sales_inventory"] | None = None) -> Result:
            def prepare(account):
                try:
                    if not hasattr(self.conversations, "prepare_chat_draft"):
                        raise CoreError("unsupported_operation", "Bản ứng dụng này chưa có bước chuẩn bị nháp chat miễn phí.", 409)
                    if draft:
                        if not isinstance(draft, dict) or not draft.get("intake_id"):
                            raise CoreError("invalid_draft", "Bản nháp chưa đúng định dạng.")
                        item = self.intake.get(account, enterprise_id, draft["intake_id"])
                        if (item.get("review") or {}).get("schema_version") == "workspace-review/2" and (
                                "base_review_revision" not in draft or "ui_revision" not in draft):
                            raise CoreError("CLIENT_UPGRADE_REQUIRED", "Tải lại app để lưu lựa chọn nháp có phiên bản. Nội dung đang sửa được giữ; chưa đổi hồ sơ.", 409)
                except CoreError as exc:
                    free = getattr(self.conversations, "free_conversations", None)
                    if free is not None:
                        free.annotate_free_failure(account, enterprise_id, operation_id, exc, "not_started")
                    raise
                value = self.conversations.prepare_chat_draft(account, enterprise_id, text, operation_id, conversation_id,
                                                             product_entity_id, draft, target_intake_id, task_hint=task_hint)
                return self.get_chat(account, enterprise_id, value["id"])
            return await call(prepare)

        @server.tool(structured_output=True, description="List only explicitly readable SSOT resources. Free; no private files are shared.")
        async def core_list_entities(enterprise_id: Identifier) -> Result:
            return await call(lambda a: {"entities": self.core.list_entities(a, enterprise_id)})

        @server.tool(structured_output=True, description="Read the explicit registered-enterprise to SSOT-profile link. Never initializes or confirms facts.")
        async def core_get_enterprise_profile(enterprise_id: Identifier) -> Result:
            return await call(lambda a: self.enterprise_profiles.get(a, enterprise_id))

        @server.tool(structured_output=True, description="Owner explicitly opens an empty business profile or links one exact existing enterprise profile. Atomic and idempotent; no facts or sharing grants.")
        async def core_open_enterprise_profile(enterprise_id: Identifier, operation_id: Operation,
                                               existing_entity_id: Identifier | None = None) -> Result:
            return await call(lambda a: self.enterprise_profiles.open(a, enterprise_id, operation_id,
                                                                     existing_entity_id=existing_entity_id))

        @server.tool(structured_output=True, description="Owner creates an empty enterprise/product resource. Idempotent; does not assert or confirm business facts.")
        async def core_create_entity(enterprise_id: Identifier, entity_type: str, name: str, operation_id: Operation) -> Result:
            return await call(lambda a: self.create_entity(a, enterprise_id, entity_type, name, operation_id))

        @server.tool(structured_output=True, description="Preview minimal authorized current context. Read-only; does not pin a durable snapshot or call a model.")
        async def core_get_context(enterprise_id: Identifier, entity_ids: list[str], field_keys: list[str] | None = None,
                                   target_date: str | None = None, known_at: str | None = None) -> Result:
            return await call(lambda a: self.core.get_context(a, enterprise_id, entity_ids, field_keys, target_date, known_at,
                                                            save_snapshot=False))

        @server.tool(structured_output=True, description="Submit a fact proposal. Does not update canonical SSOT; owner confirmation is mandatory.")
        async def core_propose_facts(enterprise_id: Identifier, entity_id: Identifier, facts: list[dict[str, Any]],
                                    expected_version: Annotated[int, Field(ge=0)], operation_id: Operation,
                                    source: dict | None = None, reason: str | None = None) -> Result:
            return await call(lambda a: self.core.propose_facts(a, enterprise_id, entity_id, facts, expected_version, operation_id, source, reason))

        @server.tool(structured_output=True, description="Owner-only explicit SSOT confirmation with version checks. Free; never grants financial egress.")
        async def core_confirm_facts(enterprise_id: Identifier, proposal_id: Identifier, expected_version: Annotated[int, Field(ge=0)],
                                    operation_id: Operation, proposal_hash: str | None = None,
                                    expected_field_versions: dict | None = None, expected_context_revision: int | None = None,
                                    reason: str | None = None) -> Result:
            return await call(lambda a: self.core.confirm_facts(a, enterprise_id, proposal_id, expected_version, operation_id,
                              proposal_hash, expected_field_versions, expected_context_revision, reason))

        @server.tool(structured_output=True, description="Read authorized pending and resolved proposals, without private provenance disclosure.")
        async def core_list_proposals(enterprise_id: Identifier, entity_id: str | None = None) -> Result:
            return await call(lambda a: {"proposals": self.core.list_proposals(a, enterprise_id, entity_id)})

        @server.tool(structured_output=True, description="Owner-only enterprise membership list.")
        async def core_list_members(enterprise_id: Identifier) -> Result:
            return await call(lambda a: {"members": self.core.list_members(a, enterprise_id)})

        @server.tool(structured_output=True, description="Owner adds an existing local account as staff; no resource is automatically shared.")
        async def core_add_member(enterprise_id: Identifier, username: str, operation_id: Operation) -> Result:
            return await call(lambda a: self.core.add_member(a, enterprise_id, username, operation_id=operation_id))

        @server.tool(structured_output=True, description="Owner revokes staff membership and resource grants.")
        async def core_remove_member(enterprise_id: Identifier, member_account_id: Identifier) -> Result:
            return await call(lambda a: self.core.remove_member(a, enterprise_id, member_account_id))

        @server.tool(structured_output=True, description="Owner explicitly scopes resource and field capabilities. Membership alone grants no access.")
        async def core_grant_resource(enterprise_id: Identifier, resource_id: Identifier, member_account_id: Identifier,
                                      capabilities: list[str] | None = None, field_keys: list[str] | None = None) -> Result:
            return await call(lambda a: self.core.grant_resource(a, enterprise_id, resource_id, member_account_id, capabilities, field_keys))

        @server.tool(structured_output=True, description="Owner revokes resource capabilities. Affects new reads and dispatch.")
        async def core_revoke_resource(enterprise_id: Identifier, resource_id: Identifier, member_account_id: Identifier,
                                       capabilities: list[str] | None = None, field_keys: list[str] | None = None) -> Result:
            return await call(lambda a: self.core.revoke_resource(a, enterprise_id, resource_id, member_account_id, capabilities, field_keys))

        @server.tool(structured_output=True, description="Read model profiles and approved D06 budgets. Cannot approve spending.")
        async def core_gateway_status(enterprise_id: Identifier) -> Result:
            return await call(lambda a: self.gateway_status(a, enterprise_id))

        @server.tool(structured_output=True, description="Stage bounded typed financial metrics at the server. Does not confirm SSOT, grant egress, or call Claude.")
        async def finance_stage_metrics(enterprise_id: Identifier, resource_id: Identifier, metrics: list[dict], operation_id: Operation) -> Result:
            return await call(lambda a: self.finance.stage_metrics(a, enterprise_id, resource_id, metrics, operation_id))

        @server.tool(structured_output=True, description="Read only authorized minimal financial metrics; original document is never included.")
        async def finance_preview(enterprise_id: Identifier, projection_id: Identifier) -> Result:
            return await call(lambda a: self.finance.preview_metrics(a, enterprise_id, projection_id))

        @server.tool(structured_output=True, description="Explicitly allow an exact metric manifest for one task/profile. Requires separate egress authority. Does not grant D06 budget.")
        async def finance_authorize_egress(enterprise_id: Identifier, projection_id: Identifier, operation_id: Operation,
                                           task_id: Identifier, purpose: str, model_profile: str, expires_at: str,
                                           metric_ids: list[str] | None = None) -> Result:
            return await call(lambda a: self.finance.grant_egress(a, enterprise_id, projection_id, operation_id, task_id,
                              purpose, model_profile, expires_at, metric_ids))

        @server.tool(structured_output=True, description="Revoke future metric egress; derivative-use blocking is a separate explicit choice.")
        async def finance_revoke_egress(enterprise_id: Identifier, grant_id: Identifier, block_derivatives: bool = False) -> Result:
            return await call(lambda a: self.finance.revoke_egress(a, enterprise_id, grant_id, block_derivatives))

        @server.tool(structured_output=True, description="Parse a bounded financial Excel template at the server only. Reject formulas/macros; never sends file content to Claude.")
        async def finance_parse_excel(enterprise_id: Identifier, resource_id: Identifier, data_base64: str, operation_id: Operation) -> Result:
            def parse(a):
                if len(data_base64) > 6_000_000:
                    raise CoreError("INPUT_LIMIT", "Tệp vượt giới hạn xử lý tại máy chủ.", 413)
                try:
                    raw = base64.b64decode(data_base64, validate=True)
                except (ValueError, TypeError):
                    raise CoreError("INVALID_INPUT", "Nội dung tệp chưa hợp lệ.") from None
                return self.finance.parse_excel(a, enterprise_id, resource_id, raw, operation_id)
            return await call(parse)

        @server.tool(structured_output=True, description="Free source discovery and bounded intent plan; commit private policy case and chat link atomically. Does not call Claude.")
        async def policy_prepare(enterprise_id: Identifier, question: Annotated[str, Field(min_length=1, max_length=6000)],
                                 operation_id: Operation, conversation_id: Identifier | None = None,
                                 product_entity_id: Identifier | None = None, target_date: str | None = None) -> Result:
            return await call(lambda a: self.prepare(a, enterprise_id, question, operation_id, conversation_id, product_entity_id, target_date))

        @server.tool(structured_output=True, description="Read a private policy case; no model call, retry or stale-evidence fallback.")
        async def policy_get(enterprise_id: Identifier, case_id: Identifier) -> Result:
            return await call(lambda a: {"policy_case": self.get_case(a, enterprise_id, case_id)})

        @server.tool(structured_output=True, description="List only this account's private policy cases.")
        async def policy_list(enterprise_id: Identifier) -> Result:
            return await call(lambda a: {"policy_cases": [self._case_gate(a, enterprise_id, c) for c in self.policy.list(a, enterprise_id)]})

        @server.tool(structured_output=True, description="Explicitly queue at most one Claude synthesis under a preapproved D06 grant. No paid retries.")
        async def policy_start(enterprise_id: Identifier, case_id: Identifier, operation_id: Operation,
                               budget_grant_id: Identifier, model_role: str = "complex", paid_consent: bool = False) -> Result:
            def start(a):
                if not paid_consent:
                    raise CoreError("PAID_CONSENT_REQUIRED", "Cần xác nhận đây là một lượt Claude có phí trong hạn mức đã duyệt.", 409)
                # The service reads an exact committed receipt before new-run
                # grant checks. Query readiness is not authority for either.
                return {"policy_case": self.policy.start(a, enterprise_id, case_id, operation_id, budget_grant_id, model_role)}
            return await call(start)

        @server.tool(structured_output=True, description="Read an account-private unified chat with authorized policy cases and legacy work.")
        async def get_conversation(enterprise_id: Identifier, conversation_id: Identifier) -> Result:
            return await call(lambda a: self.get_chat(a, enterprise_id, conversation_id))

        @server.tool(structured_output=True, description="Read only this account's chat history. Enterprise membership never shares chats.")
        async def list_conversations(enterprise_id: Identifier) -> Result:
            return await call(lambda a: self.list_chats(a, enterprise_id))

        @server.tool(structured_output=True, description="Read public source registry, provenance and freshness gates. Does not read enterprise documents.")
        async def policy_list_sources(enterprise_id: Identifier) -> Result:
            def read(a):
                self.core.membership(a, enterprise_id)
                return {"sources": self.policy.catalog.list_sources()}
            return await call(read)

        @server.tool(structured_output=True, description="Domain curator registers a public official source; enterprise-private resources cannot be referenced here.")
        async def policy_register_source(source_id: Identifier, title: str, agency: str, url: str, language: str = "vi",
                                         source_kind: str = "official_notice", metadata: dict | None = None) -> Result:
            return await call(lambda a: self.policy.catalog.register_source(a, source_id, title, agency, url, language, source_kind, metadata))

        @server.tool(structured_output=True, description="Domain curator imports a public source snapshot with immutable original bytes and exact canonical spans. No review or publication is implied.")
        async def policy_add_snapshot(source_id: Identifier, data_base64: str, canonical_text: str,
                                       published_at: str | None = None, complete_policy: bool = False,
                                       effective_from: str | None = None, effective_until: str | None = None) -> Result:
            def ingest(a):
                if len(data_base64) > 6_700_000 or len(canonical_text) > 1_000_000:
                    raise CoreError("INPUT_LIMIT", "Nguồn vượt giới hạn xử lý.", 413)
                try:
                    raw = base64.b64decode(data_base64, validate=True)
                except (ValueError, TypeError):
                    raise CoreError("INVALID_INPUT", "Nội dung nguồn chưa hợp lệ.") from None
                return self.policy.catalog.add_snapshot(a, source_id, raw, canonical_text, published_at=published_at,
                           complete_policy=complete_policy, effective_from=effective_from, effective_until=effective_until)
            return await call(ingest)

        @server.tool(structured_output=True, description="Domain curator records an evidenced source check. HTTP accessibility alone never establishes a currently open program.")
        async def policy_check_source(source_id: Identifier, result: str, current_until: str | None = None, rationale: str = "") -> Result:
            return await call(lambda a: self.policy.catalog.record_source_check(a, source_id, result=result, current_until=current_until, rationale=rationale))

        @server.tool(structured_output=True, description="Curator-only bounded HTTP refresh of a registered official source. No model call and no automatic rule publication.")
        async def policy_refresh_source(source_id: Identifier) -> Result:
            import asyncio
            return await call(lambda a: asyncio.to_thread(self.policy.catalog.refresh_source, a, source_id))

        @server.tool(structured_output=True, description="Curator explicitly schedules registered public source acquisition. No LLM or rule publication authority.")
        async def policy_refresh_schedule(source_id: Identifier, interval_seconds: int = 86400) -> Result:
            return await call(lambda a: self.source_jobs.schedule(a, source_id, interval_seconds=interval_seconds))

        @server.tool(structured_output=True, description="Curator reads durable source refresh due times and leases.")
        async def policy_refresh_jobs() -> Result:
            return await call(lambda a: {"jobs": self.source_jobs.list(a)})

        @server.tool(structured_output=True, description="Curator disables a source refresh schedule without changing reviews or history.")
        async def policy_refresh_disable(source_id: Identifier) -> Result:
            return await call(lambda a: self.source_jobs.disable(a, source_id))

        @server.tool(structured_output=True, description="Assigned domain reviewer reads unpublished or blocked knowledge members.")
        async def policy_review_queue() -> Result:
            return await call(lambda a: {"members": self.policy.catalog.list_review_queue(a)})

        @server.tool(structured_output=True, description="Domain publisher withdraws an exact member version and invalidates dependent policy results.")
        async def policy_withdraw_member(member_id: Identifier, expected_hash: str, rationale: str) -> Result:
            return await call(lambda a: self.policy.catalog.withdraw_member(a, member_id, expected_hash, rationale))

        @server.tool(structured_output=True, description="Domain curator proposes a typed rule/claim. Does not approve or publish it.")
        async def policy_propose_member(kind: str, policy_id: str, title_vi: str, payload: dict, evidence: list[dict],
                                         effective_from: str | None = None, effective_until: str | None = None) -> Result:
            return await call(lambda a: self.policy.catalog.propose_member(a, kind=kind, policy_id=policy_id, title_vi=title_vi,
                              payload=payload, evidence=evidence, effective_from=effective_from, effective_until=effective_until))

        @server.tool(structured_output=True, description="Assigned domain reviewer approves/rejects an exact member version; enterprise owner is not a reviewer by default.")
        async def policy_review_member(member_id: Identifier, expected_hash: str, approve: bool, rationale: str) -> Result:
            return await call(lambda a: self.policy.catalog.review_member(a, member_id, expected_hash, approve=approve, rationale=rationale))

        @server.tool(structured_output=True, description="Assigned domain publisher releases the reviewed exact version. No AI approval.")
        async def policy_publish_member(member_id: Identifier, expected_hash: str, review_event_id: Identifier) -> Result:
            return await call(lambda a: self.policy.catalog.publish_member(a, member_id, expected_hash, review_event_id))

        @server.tool(structured_output=True, description="Assigned domain publisher creates a versioned pack of published rules/claims.")
        async def policy_release_pack(title_vi: str, member_ids: list[str]) -> Result:
            return await call(lambda a: self.policy.catalog.release_pack(a, title_vi, member_ids))
