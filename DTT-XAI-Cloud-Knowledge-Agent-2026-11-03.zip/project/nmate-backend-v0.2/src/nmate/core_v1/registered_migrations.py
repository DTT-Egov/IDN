"""Reviewed, schema-only immutability guards; not a general trigger capability.

The operator lifecycle may create only these exact trigger definitions. No
trigger can perform business DML or change the target/event under the same name.
"""

REGISTERED_TRIGGERS = {
    "pol05_revisions_immutable": ("pol05_revisions", "CREATE TRIGGER IF NOT EXISTS pol05_revisions_immutable BEFORE UPDATE ON pol05_revisions BEGIN SELECT RAISE(ABORT,'immutable policy draft revision'); END;"),
    "pol05_revisions_no_delete": ("pol05_revisions", "CREATE TRIGGER IF NOT EXISTS pol05_revisions_no_delete BEFORE DELETE ON pol05_revisions BEGIN SELECT RAISE(ABORT,'immutable policy draft revision'); END;"),
    "pol05_approvals_immutable": ("pol05_approvals", "CREATE TRIGGER IF NOT EXISTS pol05_approvals_immutable BEFORE UPDATE ON pol05_approvals BEGIN SELECT RAISE(ABORT,'immutable policy draft approval'); END;"),
    "pol05_approvals_no_delete": ("pol05_approvals", "CREATE TRIGGER IF NOT EXISTS pol05_approvals_no_delete BEFORE DELETE ON pol05_approvals BEGIN SELECT RAISE(ABORT,'immutable policy draft approval'); END;"),
}

# Exact, finite definitions are shared with the opt-in knowledge schema. They
# only abort mutation; no DML or wildcard trigger capability is introduced.
from nmate.knowledge_v1.schema import TRIGGERS_M1
REGISTERED_TRIGGERS.update(TRIGGERS_M1)
from nmate.knowledge_v1.schema_m2 import TRIGGERS_M2
REGISTERED_TRIGGERS.update(TRIGGERS_M2)
from nmate.knowledge_v1.schema_m3 import TRIGGERS_M3
REGISTERED_TRIGGERS.update(TRIGGERS_M3)
from nmate.knowledge_v1.schema_m4 import TRIGGERS_M4
REGISTERED_TRIGGERS.update(TRIGGERS_M4)
from nmate.knowledge_v1.schema_m6 import TRIGGERS_M6
REGISTERED_TRIGGERS.update(TRIGGERS_M6)


def is_registered_trigger(sql):
    normalized = " ".join(sql.split())
    return any(normalized == definition for _, definition in REGISTERED_TRIGGERS.values())
