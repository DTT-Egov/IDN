"""Create a local credential file with a private ACL before writing its bytes.

Passwords never enter a command argument, environment variable or tool result.
The Windows file is created with an explicit one-user DACL in one operation.
"""
from __future__ import annotations

import csv
import os
from pathlib import Path
import re
import subprocess

from nmate.v03.core import CoreError


def _private_fd(path):
    if os.name != "nt":
        return os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_NOFOLLOW", 0), 0o600)
    import ctypes
    from ctypes import wintypes
    import msvcrt

    result = subprocess.run(["whoami.exe", "/user", "/fo", "csv", "/nh"], capture_output=True, text=True,
                            check=True, creationflags=subprocess.CREATE_NO_WINDOW)
    rows = list(csv.reader(result.stdout.strip().splitlines()))
    sid = rows[0][-1] if len(rows) == 1 and rows[0] else ""
    if not re.fullmatch(r"S-1-\d+(?:-\d+)+", sid):
        raise CoreError("credential_acl_failed", "Không xác định được người dùng Windows hiện hành; chưa ghi mật khẩu.")
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes = [
        wintypes.LPCWSTR, wintypes.DWORD, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(wintypes.DWORD)]
    advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW.restype = wintypes.BOOL
    kernel.CreateFileW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.c_void_p,
                                   wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE]
    kernel.CreateFileW.restype = wintypes.HANDLE
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    kernel.LocalFree.restype = ctypes.c_void_p
    kernel.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel.CloseHandle.restype = wintypes.BOOL

    class SecurityAttributes(ctypes.Structure):
        _fields_ = [("nLength", wintypes.DWORD), ("lpSecurityDescriptor", ctypes.c_void_p),
                    ("bInheritHandle", wintypes.BOOL)]

    descriptor = ctypes.c_void_p()
    if not advapi.ConvertStringSecurityDescriptorToSecurityDescriptorW(
            f"O:{sid}D:P(A;;FA;;;{sid})", 1, ctypes.byref(descriptor), None):
        raise CoreError("credential_acl_failed", "Chưa tạo được quyền riêng cho tệp mật khẩu; chưa ghi mật khẩu.")
    try:
        attributes = SecurityAttributes(ctypes.sizeof(SecurityAttributes), descriptor, False)
        # CREATE_NEW rejects every pre-existing path, including a link. Share
        # mode 0 keeps the handle private while credential bytes are written.
        handle = kernel.CreateFileW(str(path), 0x40000000, 0, ctypes.byref(attributes), 1, 0x80, None)
        if handle == ctypes.c_void_p(-1).value:
            code = ctypes.get_last_error()
            if code in {80, 183}:
                raise FileExistsError(str(path))
            raise OSError(code, "Không tạo được tệp mật khẩu có ACL riêng.")
        try:
            return msvcrt.open_osfhandle(handle, os.O_WRONLY | os.O_BINARY)
        except BaseException:
            kernel.CloseHandle(handle)
            raise
    finally:
        kernel.LocalFree(descriptor)


def write_local_credentials(target, username, password):
    path = Path(target).expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = _private_fd(path)
    except FileExistsError as exc:
        raise CoreError("credential_file_exists", "Tệp thông tin đăng nhập đã có; không ghi đè hoặc đặt lại mật khẩu.", 409) from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write("Tài khoản local nMate\nĐịa chỉ: http://127.0.0.1:8025/web/\n")
            stream.write(f"Tên đăng nhập: {username}\nMật khẩu: {password}\n")
            stream.write("Email là tên đăng nhập local; chưa xác minh quyền sở hữu email.\n")
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise
    return path
