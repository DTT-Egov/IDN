"""Legacy chat contracts carried by the governed one-shot Model Gateway.

The legacy ledger remains a compatibility view, never a second transport or
budget authority. Financial documents and unclassified vision have no dispatch
path here; this adapter deliberately supports only nonfinancial text and typed
business workbook facts.
"""
from __future__ import annotations

import asyncio
import copy
from datetime import date
import hashlib
import json
import math
import re
import unicodedata

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.source_rights import public_source_permitted
from nmate.v03.domain_validation import require_valid_field
from .gateway import PROFILES, token_cost
from .ssot import BUSINESS_FIELDS, FINANCE_FIELDS


_BUSINESS = BUSINESS_FIELDS | frozenset({
    "origin_country", "sales_management", "inventory_management", "business_goal",
    "statement_of_identity", "responsible_business", "facility_name", "facility_type",
    "nutrition_information", "processing_description", "fda_registration_status",
    "target_market", "date_marking", "storage_instructions", "ingredients_declaration",
})
_RAW = frozenset({"attachments", "data_base64", "base64", "image", "image_url", "raw_document",
                  "ocr_text", "sheet_dump", "document_bytes", "raw", "file_path"})
_PROVENANCE = frozenset({"source", "sources", "quote", "quote_original", "source_disagreement",
                         "filename", "file_name", "source_metadata", "extraction_metadata"})
_INPUT_KEYS = frozenset({
    "messages", "files", "parsed_xlsx_facts", "ssot", "previous_intent", "effective_context",
    "pending_candidates", "draft", "current_question", "selected_product_entity_id",
    "image_order_sha256", "selected_task_hint", "available_capabilities", "question",
    "selected_product", "allowed_outcomes", "outcome_semantics_vi", "previous_mission_context",
    "resolved_market", "product", "outcomes", "ssot_context", "reference_records", "coverage",
    "registered_missing_fields", "source_checks",
    "requested_action_count", "delivery_requirements", "supporting_requirements", "supporting_reference_records",
})
_FINANCIAL = re.compile(
    r"\b(?:doanh thu|loi nhuan|tai san|no phai tra|dong tien|bao cao tai chinh|bang can doi|"
    r"bang luong|tien luong|luong nhan vien|von dieu le|doanh so|lai rong|lo rong|thu nhap|"
    r"no vay|tien vay|chi phi|gia von|thu chi|von chu so huu|so du|ngan hang|tai khoan|bctc|bcdkt|revenue|profit|turnover|"
    r"cash flow|balance sheet|financial statement|payroll|salary|assets|debt|income|earnings|"
    r"gross margin|net margin|interest|expense|liabilities|equity|ebitda|ebit|owner equity)\b")


def _normalized(value):
    return "".join(c for c in unicodedata.normalize("NFKD", value.casefold().replace("đ", "d"))
                   if not unicodedata.combining(c))


def _base(field):
    return str(field).rsplit(".", 1)[-1].rsplit(":", 1)[-1]


class GovernedLegacyAdapter:
    """Attach to MainProvider as its sole new-dispatch implementation."""

    def __init__(self, repo, gateway, provider):
        self.repo, self.gateway, self.provider = repo, gateway, provider

    def recover(self):
        """Reconcile the compatibility ledger from durable gateway receipts only.

        Call during startup before workers. No HTTP or model request is made;
        accepted JSON is still subject to the existing business validators.
        """
        changed = 0
        with self.repo.connection(write=True) as db:
            for row in db.execute("SELECT * FROM v03_live_attempts WHERE state IN ('prepared','dispatching','outcome_unknown')").fetchall():
                receipt = db.execute("SELECT * FROM core_model_attempts WHERE enterprise_id=? AND actor_id=? AND operation_id=? AND task_id=?",
                    (row["enterprise_id"], row["account_id"], row["operation_id"], "legacy_"+row["kind"])).fetchone()
                if not receipt:
                    continue
                envelope = None
                if receipt["state"] == "response_received" and receipt["validation_state"] == "accepted":
                    envelope = {"data": json.loads(receipt["data_json"]), "attempt_id": row["id"],
                        "gateway_attempt_id": receipt["id"], "model": receipt["model"],
                        "usage": json.loads(receipt["usage_json"] or "{}"), "request_id": receipt["request_id"]}
                state = "succeeded" if envelope else (
                    "outcome_unknown" if receipt["state"] in {"dispatch_committed", "outcome_unknown"} else
                    "failed" if receipt["dispatched_at"] else "prepared")
                db.execute("UPDATE v03_live_attempts SET state=?,error_code=?,usage_json=?,response_json=?,request_id=?,finished_at=? WHERE id=?",
                    (state, None if envelope else receipt["error_code"], receipt["usage_json"],
                     json_text(envelope) if envelope else None, receipt["request_id"], now_iso(), row["id"]))
                changed += 1
        return changed

    def status(self, account_id, enterprise_id):
        gate = self.gateway.status(account_id, enterprise_id)
        purposes = {}
        for purpose in ("legacy_intake", "legacy_research"):
            grants = [g for g in gate["grants"] if purpose in g["purposes"] and g["remaining_calls"] > 0
                      and g["held_usd"] < g["max_cost_usd"]]
            purposes[purpose] = {"approved": gate["approved"] and bool(grants),
                "roles": sorted({role for g in grants for role in g["roles"]}),
                "remaining_calls": sum(g["remaining_calls"] for g in grants),
                "remaining_usd": round(sum(g["max_cost_usd"]-g["held_usd"] for g in grants), 6)}
        approved = any(p["approved"] for p in purposes.values())
        return {"approved": approved, "purposes": purposes,
                "reason_vi": "Đã có hạn mức D06 cho tác vụ Claude được duyệt." if approved else
                    "Chưa có hạn mức D06 cho tác vụ này. Đọc hồ sơ và kết quả cũ không gọi Claude.",
                "supports": ["nonfinancial_text", "typed_business_excel"],
                "vision_supported": False, "financial_egress_supported": False, "finance_supported": False}

    def authorize_recorded_envelope(self, account, enterprise, envelope, *, db=None, declared_payload=None,
                                    require_complete_lineage=False):
        """DF-029: copied compatibility output carries the original lineage ACL.

        Legacy native receipts without a gateway ID retain their original
        membership-only contract. Never invent dependencies for old rows.
        """
        gateway_id = envelope.get("gateway_attempt_id")
        if gateway_id:
            if db is None:
                with self.repo.connection() as connection:
                    return self.authorize_recorded_envelope(account, enterprise, envelope, db=connection,
                                                            declared_payload=declared_payload,
                                                            require_complete_lineage=require_complete_lineage)
            receipt = self.gateway.read_receipt(account, enterprise, gateway_id, db=db)
            if receipt["data"] != envelope.get("data") or receipt["model"] != envelope.get("model"):
                raise CoreError("RECORDED_RECEIPT_MISMATCH", "Bản sao kết quả không khớp biên nhận gốc. Không gọi AI.", 409)
            if declared_payload is not None:
                # Old manifests stay immutable. The exact matched command's
                # declared inputs still require READ today, including fields
                # omitted by a historical manifest projection. No value/type
                # normalization, new defaults, reservation or write occurs.
                dependencies = self._resource_dependencies(declared_payload)
                self.gateway._require_dependencies(db, account, enterprise,
                                                   {"resource_dependencies": dependencies})
            if require_complete_lineage:
                saved = db.execute("SELECT dependencies_json FROM core_model_attempts WHERE id=? AND enterprise_id=? AND actor_id=?",
                                   (gateway_id, enterprise, account)).fetchone()
                dependencies = json.loads(saved[0])
                for dependency in dependencies.get("resource_dependencies", []):
                    if dependency["fields"]:
                        continue
                    # The old selected-product projection could omit every
                    # input field from lineage. Its hash-only manifest cannot
                    # prove the output used merely an ID or a product name.
                    # Preserve old data; only intrinsic complete-resource READ
                    # can safely authorize an archive with that opaque scope.
                    resource = dependency["resource_id"]
                    self.gateway._require_resource(db, account, enterprise, resource)
                    entity = db.execute("SELECT created_by FROM v03_entities WHERE enterprise_id=? AND id=?",
                                        (enterprise, resource)).fetchone()
                    metadata = self.gateway.core._resource(db, enterprise, resource)
                    if entity is None and metadata and metadata["resource_type"] != "ssot_entity":
                        # Other resource kinds use whole-resource READ. This
                        # SSOT projection defect must not turn a lawful private
                        # document creator's READ into a new owner-role gate.
                        continue
                    membership = self.gateway.core.membership(account, enterprise, db)
                    explicit_revoke = db.execute("SELECT 1 FROM core_v1_grants WHERE enterprise_id=? AND resource_id=? AND account_id=? AND capability='read' AND revoked_at IS NOT NULL LIMIT 1",
                                                 (enterprise, resource, account)).fetchone()
                    if not entity or entity[0] != account or membership["role"] != "owner" or explicit_revoke:
                        raise CoreError("RECORDED_FIELD_LINEAGE_INCOMPLETE",
                            "Bản lưu cũ chưa có đủ phạm vi quyền dữ kiện. Cần chủ hồ sơ xem lại bản lưu này; không gọi AI.", 403)
        return envelope

    @staticmethod
    def _text(value):
        if not isinstance(value, str):
            return
        normalized = _normalized(value)
        if (_FINANCIAL.search(normalized) or
                re.search(r"\b(?:lãi|lỗ|vốn|tài chính)\b", unicodedata.normalize("NFC", value.casefold())) or
                re.search(r"\b(?:lai|lo)\s+[-+]?\d", normalized) or
                re.search(r"(?:[$€£¥₫]|\b(?:usd|vnd|eur|gbp|jpy|cny|aud))\s*[-+]?\d", normalized) or
                re.search(r"\b\d+(?:[.,]\d+)*\s*(?:usd|vnd|dong|trieu|ty)\b", normalized) or
                len(re.findall(r"\d+", value)) >= 6 and any(mark in value for mark in ("\n", "\t", "|", ";"))):
            raise CoreError("FINANCIAL_EGRESS_REQUIRED",
                "Nội dung có dữ liệu tài chính hoặc bảng số liệu chưa phân loại. Cần xử lý tại máy chủ và cho phép chỉ tiêu tối thiểu riêng; chưa gửi Claude.", 409)

    def _allowed_fields(self):
        financial = set(FINANCE_FIELDS)
        allowed = set(_BUSINESS)
        with self.repo.connection() as db:
            if db.execute("SELECT 1 FROM sqlite_master WHERE name='core_v1_field_definitions'").fetchone():
                for row in db.execute("SELECT field_key,sensitivity FROM core_v1_field_definitions"):
                    if row["sensitivity"] in {"finance", "restricted"}:
                        financial.add(row["field_key"])
        return allowed-financial, financial

    @staticmethod
    def _business_value(field, value):
        """Known field names alone cannot classify an arbitrary JSON document.

        Most current product fields are scalar text. The two supported
        structured forms below have closed keys and primitive value types;
        no generic amount/currency object or numeric spreadsheet can ride in a
        business fact. Unsupported shapes stay at the server for correction.
        """
        if value is None:
            return
        # The legacy transport DTO has two pre-existing closed object forms;
        # these are not canonical scalar SSOT facts. Preserve that adapter
        # boundary, while valid scalar/list forms use the shared fact contract.
        # Malformed shapes are rejected before grants or reservations.
        exact_field = field
        field = _base(field)
        if isinstance(value, str) and 0 <= len(value) <= (250 if field in {"name", "product_name", "product_code", "sku"} else 4000):
            require_valid_field(exact_field, value)
            return
        if field in {"ingredients", "certifications", "allergens"} and isinstance(value, list) and len(value) <= 60:
            if all(isinstance(item, str) and len(item) <= 500 for item in value):
                require_valid_field(exact_field, value)
                return
        if field in {"responsible_business", "manufacturer"} and isinstance(value, dict) and value:
            keys = {"name", "address", "role", "country", "identifier", "registration_number", "email", "phone"}
            if set(value).issubset(keys) and all(isinstance(item, str) and len(item) <= 2000 for item in value.values()):
                return
        if field == "nutrition_information" and isinstance(value, dict) and value:
            keys = {"serving_size", "energy_kj", "energy_kcal", "calories", "fat_g", "saturated_fat_g",
                    "carbohydrate_g", "sugars_g", "protein_g", "salt_g", "sodium_mg", "fibre_g", "fiber_g"}
            if set(value).issubset(keys) and all(
                isinstance(item, str) and len(item) <= 100 or
                isinstance(item, (int, float)) and not isinstance(item, bool) and math.isfinite(item) and 0 <= item <= 1e6
                for item in value.values()):
                return
        raise CoreError("BUSINESS_VALUE_TYPE_UNSUPPORTED",
            "Dữ kiện nghiệp vụ có cấu trúc chưa được phân loại an toàn để gửi Claude. Cần sửa về đúng kiểu dữ kiện hoặc dùng luồng chỉ tiêu tài chính; chưa tạo lượt có phí.", 409)

    def _public_records(self, records, *, compact=False):
        """Only already installed public excerpts can bypass private-text checks."""
        if not isinstance(records, list) or len(records) > 60:
            raise CoreError("INVALID_PUBLIC_REFERENCE", "Danh sách nguồn chưa đúng hợp đồng.", 409)
        projected = []
        described_pages = set()
        with self.repo.connection() as db:
            for item in records:
                if not isinstance(item, dict) or not isinstance(item.get("id"), str):
                    raise CoreError("INVALID_PUBLIC_REFERENCE", "Trích đoạn cần mã nguồn công khai đã lưu.", 409)
                row = db.execute("SELECT r.record_json,s.url,s.rights,s.title,s.publisher,s.accessed_at,s.source_date,s.version,s.freshness_state,s.text,s.content_sha256 FROM v03_domain_references r "
                                 "JOIN v03_domain_sources s ON s.id=r.source_id WHERE r.id=?", (item["id"],)).fetchone()
                if row is None or not public_source_permitted(row["rights"], row["url"]):
                    raise CoreError("INVALID_PUBLIC_REFERENCE", "Nguồn chưa được đăng ký là tài liệu công khai.", 409)
                canonical = json.loads(row["record_json"])
                if item.get("excerpt") != canonical.get("excerpt") or item.get("url", row["url"]) != row["url"]:
                    raise CoreError("INVALID_PUBLIC_REFERENCE", "Trích đoạn không khớp bản nguồn công khai đã lưu.", 409)
                if row["rights"] in {"official_reference_quotation_not_full_republication", "us_federal_government_public_reference"}:
                    excerpt = canonical.get("excerpt")
                    source = row["text"]
                    max_excerpt = 8000 if row["rights"] == "us_federal_government_public_reference" else 1200
                    if (not isinstance(excerpt, str) or not 1 <= len(excerpt) <= max_excerpt
                            or not isinstance(source, str) or len(excerpt) >= len(source)
                            or hashlib.sha256(excerpt.encode()).hexdigest() != canonical.get("excerpt_sha256")
                            or hashlib.sha256(source.encode()).hexdigest() != row["content_sha256"]
                            or re.sub(r"\s+", " ", excerpt).strip() not in re.sub(r"\s+", " ", source).strip()):
                        raise CoreError("INVALID_PUBLIC_REFERENCE", "Trích dẫn nguồn chính thức chưa khớp phạm vi trích đoạn đã đăng ký.", 409)
                # Runtime source gates stay server-owned; arbitrary nested metadata
                # or private prose cannot be smuggled through an official URL.
                keys = {"id", "title", "excerpt", "excerpt_sha256", "url", "topics", "language", "publisher",
                        "accessed_at", "source_date", "review_state", "freshness_state", "scope", "source_version",
                        "valid_from", "valid_until", "review_due_at", "applicability", "rights", "version"}
                public = {key: copy.deepcopy(canonical[key]) for key in keys if key in canonical}
                public.update({key: row[key] for key in ("url", "title", "publisher", "accessed_at", "source_date", "freshness_state")})
                public["source_version"] = row["version"]
                public["rights"] = row["rights"]
                if compact:
                    # A versioned research request needs citeable clauses and
                    # their scope, not repeated page URLs and presentation
                    # metadata. Validate the full canonical record above before
                    # projecting; never shorten a legal excerpt to fit budget.
                    public = {key: public[key] for key in (
                        "id", "excerpt", "topics", "source_version", "freshness_state",
                        "review_state", "source_date") if key in public and public[key] is not None}
                    # Page identity joins source checks. Keep a different name
                    # from Citation.source_id, whose namespace is excerpt IDs.
                    public["page_id"] = canonical.get("source_id")
                    if public["page_id"] not in described_pages:
                        public["publisher"] = row["publisher"]
                        described_pages.add(public["page_id"])
                    # Applicability/freshness are checked before projection.
                    # Keep edition identifiers, especially the recorded 2024
                    # statute; the UI retains all Vietnamese advisory notes.
                    for key, value in (("section", (canonical.get("locator") or {}).get("section")),):
                        if isinstance(value, str) and value:
                            self._text(value)
                            public[key] = value
                projected.append(public)
        return projected

    @staticmethod
    def _inventory_context(previous):
        """Closed nonfinancial working values, never a prior model transcript.

        A multi-line assistant calculation is untrusted prose, not a classified
        table. Keep it at the server and preserve continuity using only these
        grounded, typed inventory slots. All user text retains the strict scan.
        """
        if not isinstance(previous, dict) or previous.get("primary") != "digitize_operations" or previous.get("focus") != "inventory_accuracy":
            return None
        answers = previous.get("working_answers", {})
        slots = {"book_quantity", "physical_quantity", "quantity_unit", "count_date", "count_date_phrase", "count_date_proposed", "product_code"}
        if not isinstance(answers, dict) or set(answers) - slots - {"report_period", "report_dimension"}:
            raise CoreError("UNCLASSIFIED_INVENTORY_CONTEXT", "Ngữ cảnh kiểm kê có dữ kiện chưa được phân loại. Chưa gửi Claude.", 409)
        values = {}
        for key, value in answers.items():
            if key not in slots:
                continue
            if key in {"book_quantity", "physical_quantity"}:
                if isinstance(value, str) and re.fullmatch(r"\d{1,12}(?:[.,]\d{1,6})?", value):
                    value = float(value.replace(",", "."))
                valid = isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and 0 <= value <= 1e12
            elif key in {"count_date", "count_date_proposed"}:
                try:
                    valid = isinstance(value, str) and date.fromisoformat(value).isoformat() == value
                except ValueError:
                    valid = False
            elif key == "product_code":
                valid = isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,63}", value))
            elif key == "quantity_unit":
                valid = isinstance(value, str) and _normalized(value) in {"hop", "tui", "goi", "thung", "chai", "cai", "don vi", "kg", "g", "ml", "l"}
            else:
                valid = isinstance(value, str) and value in {"hôm qua", "hôm nay", "hom qua", "hom nay"}
            if not valid:
                raise CoreError("UNCLASSIFIED_INVENTORY_CONTEXT", "Dữ kiện kiểm kê chưa đúng kiểu an toàn. Chưa gửi Claude.", 409)
            values[key] = copy.deepcopy(value)
        term = previous.get("address_term", "bạn")
        if term not in {"bạn", "chị", "anh", "cô", "chú", "bác", "em"}:
            term = "bạn"
        return {"primary": "digitize_operations", "focus": "inventory_accuracy", "address_term": term,
                "working_answers": values, "context_classification": "nonfinancial_inventory_working_values_not_ssot"}

    def compile_payload(self, kind, payload):
        if kind not in {"intake", "research"} or not isinstance(payload, dict) or not isinstance(payload.get("input"), dict):
            raise CoreError("LIVE_KIND_INVALID", "Loại lượt Claude chưa được cho phép.")
        if not isinstance(payload.get("response_schema"), dict):
            raise CoreError("INVALID_MODEL_REQUEST", "Cần hợp đồng kết quả trước khi gửi Claude.")
        if self.provider.images.get():
            raise CoreError("VISION_EGRESS_NOT_ENABLED",
                "Ảnh chưa có luồng phân loại và quyền gửi được kiểm chứng trong lõi mới. Chưa gửi ảnh hoặc tạo lượt Claude; có thể gửi câu hỏi và Excel phi tài chính.", 409)
        inputs = payload["input"]
        if set(inputs)-_INPUT_KEYS:
            raise CoreError("UNSUPPORTED_MODEL_CONTEXT", "Đầu vào có phần chưa được phân loại để gửi Claude.", 409)
        delivery_keys = {"requested_action_count", "delivery_requirements", "supporting_requirements", "supporting_reference_records"}
        if kind != "research" and delivery_keys.intersection(inputs):
            raise CoreError("UNSUPPORTED_MODEL_CONTEXT", "Hợp đồng hành động và nguồn bổ sung chỉ thuộc bước nghiên cứu.", 409)
        requested_count = inputs.get("requested_action_count")
        if requested_count is not None and (type(requested_count) is not int or requested_count != 3):
            raise CoreError("UNSUPPORTED_MODEL_CONTEXT", "Số việc ưu tiên chưa đúng hợp đồng nghiên cứu.", 409)
        compact_references = (kind == "research" and isinstance(inputs.get("delivery_requirements"), dict)
                              and inputs["delivery_requirements"].get("version") == "research-actions/2")
        allowed, financial = self._allowed_fields()
        inventory = self._inventory_context(inputs.get("previous_intent")) if kind == "intake" else None
        withheld = set()

        def field_allowed(field):
            base = _base(field)
            if field in financial or base in financial or str(field).startswith(("finance.", "financial.", "revenue_", "assets_")):
                withheld.add(str(field))
                return False
            return base in allowed

        def project(value, *, strict_fields=False):
            if isinstance(value, list):
                output = []
                for item in value:
                    projected = project(item, strict_fields=strict_fields)
                    if projected is not None:
                        output.append(projected)
                return output
            if isinstance(value, dict):
                if "field" in value and not field_allowed(value["field"]):
                    if strict_fields:
                        raise CoreError("FINANCIAL_EGRESS_REQUIRED",
                            "Excel hoặc bản nháp có chỉ tiêu tài chính/chưa phân loại. Cần luồng cho phép chỉ tiêu tối thiểu riêng; chưa gửi Claude.", 409)
                    return None
                if "field" in value:
                    for item_key in ("value", "observed_value", "committed_value", "current_value", "effective_value"):
                        if item_key in value:
                            self._business_value(value["field"], value[item_key])
                output = {}
                for key, child in value.items():
                    if key.casefold() in _RAW and child:
                        raise CoreError("DATA_EGRESS_BLOCKED", "Không gửi tài liệu gốc hoặc dữ liệu OCR qua luồng hội thoại này.", 409)
                    if key in _PROVENANCE:
                        continue
                    if key in {"values", "shared_values", "market_values", "edits"} and isinstance(child, dict):
                        output[key] = {}
                        for field, item in child.items():
                            if field_allowed(field):
                                self._business_value(field, item)
                                output[key][field] = project(item)
                    elif key in financial or key.startswith(("finance.", "financial.", "revenue_", "assets_")):
                        withheld.add(key)
                    else:
                        if _base(key) in allowed:
                            self._business_value(key, child)
                        output[key] = project(child, strict_fields=strict_fields)
                return output
            if isinstance(value, str):
                self._text(value)
            return copy.deepcopy(value)

        safe = {}
        for key, value in inputs.items():
            if key == "previous_intent" and inventory is not None:
                safe[key] = project(inventory)
            elif key == "messages" and inventory is not None:
                # Retain the original indices used by grounded-answer validation.
                # Never exempt arbitrary old assistant text from financial checks:
                # it is omitted entirely, not reclassified as safe prose.
                history = []
                for message in value:
                    if isinstance(message, dict) and message.get("role") == "assistant":
                        index = message.get("index")
                        if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index <= 200:
                            raise CoreError("UNCLASSIFIED_INVENTORY_CONTEXT", "Chỉ số hội thoại chưa đúng hợp đồng kiểm kê. Chưa gửi Claude.", 409)
                        history.append({"role": "assistant", "index": index,
                            "text": "Lời trợ lý cũ được giữ tại máy chủ. Dùng working_answers có kiểu trong previous_intent và lời người dùng gốc để nối tiếp kiểm kê."})
                    else:
                        history.append(message)
                safe[key] = project(history)
            elif key in {"reference_records", "supporting_reference_records"}:
                safe[key] = self._public_records(value, compact=compact_references)
            elif key == "files":
                if any(not isinstance(f, dict) or f.get("kind") != "spreadsheet" for f in value):
                    raise CoreError("VISION_EGRESS_NOT_ENABLED", "Chưa có quyền gửi loại tài liệu này qua lõi mới. Chưa gọi Claude.", 409)
                safe[key] = [{name: f[name] for name in ("kind", "sha256", "previously_observed") if name in f} for f in value]
            elif key == "image_order_sha256":
                if value:
                    raise CoreError("VISION_EGRESS_NOT_ENABLED", "Chưa có quyền gửi ảnh qua lõi mới. Chưa gọi Claude.", 409)
                safe[key] = []
            elif key == "available_capabilities":
                capabilities = copy.deepcopy(value)
                if isinstance(capabilities.get("ssot_fields"), list):
                    capabilities["ssot_fields"] = [f for f in capabilities["ssot_fields"] if field_allowed(f)]
                safe[key] = project(capabilities)
            else:
                safe[key] = project(value, strict_fields=key in {"parsed_xlsx_facts", "draft"})
        return {"capability": "legacy_"+kind, "input": safe,
                "financial_context_policy": "No financial document, metric, OCR, private source excerpt or image was sent."}

    def _fresh_research_consent(self, db, account, enterprise, mission_id, grant_id):
        if not mission_id or not db.execute("SELECT 1 FROM sqlite_master WHERE name='main_research_authorizations'").fetchone():
            return
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='core_budget_pool_links'").fetchone():
            return
        pool = db.execute("SELECT p.created_at FROM core_budget_pools p JOIN core_budget_pool_links l ON l.pool_id=p.id "
                          "WHERE l.grant_id=? AND l.account_id=? AND l.enterprise_id=?",
                          (grant_id, account, enterprise)).fetchone()
        if pool is None:
            preview = self.gateway.budget_pool.resolve_preview(db, account, enterprise, grant_id,
                                                              purpose="legacy_research")
            if preview is None:
                return
            pool_created_at = preview["created_at"]
        else:
            pool_created_at = pool[0]
        authorization = db.execute("SELECT consent_at FROM main_research_authorizations WHERE mission_id=? AND account_id=? AND enterprise_id=?",
                                   (mission_id, account, enterprise)).fetchone()
        if authorization is None or authorization[0] < pool_created_at:
            raise CoreError("FRESH_PAID_CONSENT_REQUIRED",
                "Hồ sơ đã xếp hàng trước hạn mức D06 mới. Cần xác nhận một lượt nghiên cứu mới; ứng dụng không tự tiếp tục lượt cũ có phí.", 409)

    def _select_grant(self, account, enterprise, purpose, role, context, schema, instructions):
        gate = self.gateway.status(account, enterprise)
        wire = json_text({"input": context, "response_schema": schema, "purpose": purpose,
                          "task_instructions_vi": instructions})
        if len(wire.encode("utf-8")) > 30000:
            raise CoreError("INPUT_LIMIT", "Nội dung vượt mức 30 KB; chưa gửi Claude.", 413)
        hold = token_cost(8192+2*len(wire.encode("utf-8")), 4096, PROFILES[role])/1e6
        for grant in gate["grants"]:
            if gate["approved"] and purpose in grant["purposes"] and role in grant["roles"] and grant["remaining_calls"] > 0 and grant["max_cost_usd"]-grant["held_usd"]+1e-9 >= hold:
                return grant["id"]
        raise CoreError("BUDGET_NOT_GRANTED", "Chưa có đủ lượt và trần phí D06 cho đúng tác vụ, mô hình này. Chưa gửi Claude.", 409)

    @staticmethod
    def _resource_dependencies(context):
        """Seal only explicit entity/field lineage in the sanitized server DTO.

        No product is inferred from its display name or selected because it is
        the only product. The Gateway rechecks these refs before dispatch,
        publication and each receipt read, including compatibility-cache reads.
        """
        inputs, refs = context["input"], {}

        def add(resource, fields=()):
            if isinstance(resource, str) and resource:
                refs.setdefault(resource, set()).update(field for field in fields if isinstance(field, str))

        add(inputs.get("selected_product_entity_id"))
        for key in ("selected_product", "product"):
            item = inputs.get(key)
            if isinstance(item, dict):
                values = item.get("values")
                fields = list(values) if isinstance(values, dict) else []
                if "name" in item:
                    fields.append("name")
                facts = item.get("facts")
                fields.extend(fact["field"] for fact in (facts if isinstance(facts, list) else [])
                              if isinstance(fact, dict) and isinstance(fact.get("field"), str))
                add(item.get("entity_id", item.get("id")), fields)
        sections = [inputs.get("ssot"), inputs.get("ssot_context")]
        effective = inputs.get("effective_context")
        if isinstance(effective, dict):
            sections.append(effective.get("confirmed_ssot"))
        for section in sections:
            if not isinstance(section, dict):
                continue
            for item in section.get("entities", []):
                if isinstance(item, dict):
                    values = item.get("values", {})
                    add(item.get("id", item.get("entity_id")), values if isinstance(values, dict) else ())
            for fact in section.get("fact_refs", []):
                if isinstance(fact, dict):
                    add(fact.get("entity_id"), [fact.get("field")])
        return [{"resource_id": resource, "fields": sorted(fields)} for resource, fields in sorted(refs.items())]

    async def __call__(self, kind, payload, *, operation_id, account_id, enterprise_id, mission_id=None):
        original_hash = hashlib.sha256(json_text(payload).encode()).hexdigest()
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            old = db.execute("SELECT * FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND kind=? AND operation_id=?",
                (account_id, enterprise_id, kind, operation_id)).fetchone()
            if old:
                if old["request_hash"] != original_hash:
                    raise CoreError("LIVE_IDEMPOTENCY_CONFLICT", "Mã lượt đã dùng cho nội dung khác.", 409)
                if old["state"] == "succeeded" and old["response_json"]:
                    return self.authorize_recorded_envelope(account_id, enterprise_id,
                                                            json.loads(old["response_json"]), db=db,
                                                            declared_payload=payload)
                raise CoreError("LIVE_ATTEMPT_NOT_REPLAYED", "Lượt đã ghi nhận. Không tự gửi lại hoặc tạo lượt có phí mới.", 409)
        context = self.compile_payload(kind, payload)
        model = self.provider._model(kind, payload)
        role = next((key for key, profile in PROFILES.items() if profile["model"] == model), None)
        if role is None:
            raise CoreError("MODEL_NOT_CONFIGURED", "Mô hình chưa thuộc cấu hình đã duyệt.", 409)
        purpose, schema = "legacy_"+kind, payload["response_schema"]
        grant = self._select_grant(account_id, enterprise_id, purpose, role, context, schema, payload.get("instructions_vi", ""))
        attempt_id = new_id("claude")
        with self.repo.connection(write=True) as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            if kind == "research":
                self._fresh_research_consent(db, account_id, enterprise_id, mission_id, grant)
            if db.execute("SELECT 1 FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND kind=? AND operation_id=?",
                          (account_id, enterprise_id, kind, operation_id)).fetchone():
                raise CoreError("LIVE_ATTEMPT_NOT_REPLAYED", "Lượt đang xử lý; không gửi trùng Claude.", 409)
            db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,mission_id,model,state,created_at) "
                       "VALUES(?,?,?,?,?,?,?,?, 'prepared',?)", (attempt_id, account_id, enterprise_id, operation_id, kind, original_hash, mission_id, model, now_iso()))
        try:
            receipt = await self.gateway.call_once(account_id=account_id, enterprise_id=enterprise_id,
                operation_id=operation_id, task_id=purpose, purpose=purpose, role=role,
                context=context, output_schema=schema, budget_grant_id=grant, max_output_tokens=4096,
                task_instructions_vi=payload.get("instructions_vi", ""),
                resource_dependencies=self._resource_dependencies(context))
            with self.repo.connection(write=True) as db:
                self.repo.get_membership(account_id, enterprise_id, db)
                gateway_row = db.execute("SELECT request_id FROM core_model_attempts WHERE id=?", (receipt["attempt_id"],)).fetchone()
                envelope = {"data": receipt["data"], "attempt_id": attempt_id, "gateway_attempt_id": receipt["attempt_id"],
                    "model": receipt["model"], "usage": receipt.get("usage", {}),
                    "request_id": gateway_row[0] if gateway_row else None}
                db.execute("UPDATE v03_live_attempts SET state='succeeded',usage_json=?,response_json=?,request_id=?,finished_at=? WHERE id=?",
                    (json_text(envelope["usage"]), json_text(envelope), envelope["request_id"], now_iso(), attempt_id))
            return envelope
        except BaseException as exc:
            with self.repo.connection(write=True) as db:
                row = db.execute("SELECT * FROM core_model_attempts WHERE enterprise_id=? AND operation_id=? AND task_id=? ORDER BY created_at DESC LIMIT 1",
                                 (enterprise_id, operation_id, purpose)).fetchone()
                dispatched = bool(row and row["dispatched_at"])
                unknown = dispatched and (not row or row["state"] in {"dispatch_committed", "outcome_unknown"})
                state = "outcome_unknown" if unknown else "failed" if dispatched else "prepared"
                code = exc.code if isinstance(exc, CoreError) else "CALL_INTERRUPTED" if isinstance(exc, asyncio.CancelledError) else "MODEL_OUTCOME_UNKNOWN"
                db.execute("UPDATE v03_live_attempts SET state=?,error_code=?,usage_json=?,request_id=?,finished_at=? WHERE id=?",
                           (state, code, row["usage_json"] if row else None, row["request_id"] if row else None, now_iso(), attempt_id))
            raise

