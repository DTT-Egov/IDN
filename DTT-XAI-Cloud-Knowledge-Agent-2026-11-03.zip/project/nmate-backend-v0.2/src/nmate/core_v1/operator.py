"""Local-only administration; absent from browser and MCP tool registration.

Run ``python -m nmate.core_v1.operator --help``. The operator must already
possess the database file and an actual human approval reference. This tool
never enables inference, reads credentials or provisions a fictional expert.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import secrets
import sys

from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts
from .gateway import ModelGateway
from .local_credentials import write_local_credentials


SCHEMA = """
CREATE TABLE IF NOT EXISTS core_operator_approvals (
 approval_id TEXT NOT NULL,action TEXT NOT NULL,request_hash TEXT NOT NULL,state TEXT NOT NULL,
 result_json TEXT,created_at TEXT NOT NULL,finished_at TEXT,
 PRIMARY KEY(approval_id,action));
"""
KNOWLEDGE_ROLES = {"admin", "curator", "reviewer", "publisher"}


def _account(db, username):
    row = db.execute("SELECT id,username FROM v03_accounts WHERE username=? AND active=1", (username.strip().casefold(),)).fetchone()
    if row is None:
        raise CoreError("account_not_found", "Chưa tìm thấy tài khoản đang hoạt động.", 404)
    return dict(row)


def _approval(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{2,127}", value):
        raise CoreError("approval_required", "Cần mã phê duyệt cụ thể, tối đa 128 ký tự.")
    return value


def _prior(db, approval_id, action, payload):
    fingerprint = hashlib.sha256(json_text(payload).encode()).hexdigest()
    row = db.execute("SELECT * FROM core_operator_approvals WHERE approval_id=? AND action=?", (approval_id, action)).fetchone()
    if row:
        if row["request_hash"] != fingerprint:
            raise CoreError("approval_conflict", "Mã phê duyệt đã dùng cho phạm vi khác.", 409)
        if row["state"] == "completed":
            return fingerprint, json.loads(row["result_json"])
        raise CoreError("operator_outcome_pending", "Thao tác đang thực hiện hoặc cần đối soát. Không tự cấp thêm quyền/hạn mức.", 409)
    return fingerprint, None


def _finish(db, approval_id, action, fingerprint, result):
    db.execute("INSERT INTO core_operator_approvals VALUES(?,?,?,'completed',?,?,?) "
               "ON CONFLICT(approval_id,action) DO UPDATE SET state='completed',result_json=excluded.result_json,finished_at=excluded.finished_at",
               (approval_id, action, fingerprint, json_text(result), now_iso(), now_iso()))


def administer(repo, action, *, approval_id, username, role=None, enterprise_id=None, grant_id=None,
               max_calls=None, cap_usd=None, roles=None, purposes=None, expires_at=None,
               policy_id=None, source_ids=None, enterprise_name=None, credential_file=None):
    """Operator API for controlled local CLI use; no external calls or key reads."""
    approval_id = _approval(approval_id)
    if action not in {"account-create", "knowledge-grant", "knowledge-revoke", "budget-grant", "budget-revoke"}:
        raise CoreError("unsupported_action", "Thao tác quản trị chưa được hỗ trợ.")
    if not isinstance(username, str) or not username.strip():
        raise CoreError("account_required", "Cần tài khoản nhận hoặc bị thu hồi quyền.")
    username = LocalAccounts._username(username)
    if action.startswith("knowledge-"):
        if role not in KNOWLEDGE_ROLES:
            raise CoreError("invalid_role", "Vai trò quản trị tri thức không hợp lệ.")
        KnowledgeCatalog(repo)  # Schema only; no source bootstrap, model or HTTP.
    gateway = ModelGateway(repo, enabled=False) if action.startswith("budget-") else None
    with repo.connection(write=True) as db:
        db.executescript(SCHEMA)
    if action == "account-create":
        if not isinstance(credential_file, (str, Path)) or not str(credential_file).strip():
            raise CoreError("credential_file_required", "Cần đường dẫn tệp riêng để người dùng đọc thông tin đăng nhập trên máy.")
        target = Path(credential_file).expanduser()
        if target.is_symlink():
            raise CoreError("credential_file_exists", "Không dùng liên kết làm tệp thông tin đăng nhập.", 409)
        target = target.resolve()
        payload = {"username": username, "enterprise_name": enterprise_name, "credential_file": str(target)}
        created_file = None
        try:
            with repo.connection(write=True) as db:
                fingerprint, previous = _prior(db, approval_id, action, payload)
                if previous is not None:
                    return previous
                existing = db.execute("SELECT id,active FROM v03_accounts WHERE username=?", (username,)).fetchone()
                if existing:
                    result = {"approval_id": approval_id, "account_id": existing["id"], "username": username,
                              "status": "already_exists", "password_created": False, "credential_file": None,
                              "message": "Tài khoản đã tồn tại; không đặt lại mật khẩu hoặc tạo phiên đăng nhập."}
                else:
                    password = secrets.token_urlsafe(24)
                    account = LocalAccounts(repo).register(username, password, enterprise_name, db=db)
                    created_file = write_local_credentials(target, username, password)
                    result = {"approval_id": approval_id, "account_id": account["account_id"], "username": username,
                              "enterprise_id": account["enterprise_id"], "status": "created", "password_created": True,
                              "credential_file": str(created_file), "credential_file_access": "current_os_user_only",
                              "session_created": False, "email_verified": False,
                              "message": "Đã tạo tài khoản local; thông tin đăng nhập chỉ lưu trong tệp riêng trên máy. Chưa cấp vai trò hoặc duyệt quy tắc."}
                _finish(db, approval_id, action, fingerprint, result)
                return result
        except BaseException:
            if created_file is not None:
                created_file.unlink(missing_ok=True)
            raise
    payload = {"username": username.strip().casefold(), "role": role, "enterprise_id": enterprise_id,
               "grant_id": grant_id, "max_calls": max_calls, "cap_usd": str(cap_usd) if cap_usd is not None else None,
               "roles": sorted(roles or []), "purposes": sorted(purposes or []), "expires_at": expires_at}
    scoped_sources = None
    if policy_id is not None or source_ids is not None:
        if not action.startswith("knowledge-"):
            raise CoreError("invalid_knowledge_scope", "Phạm vi chương trình chỉ dùng để cấp hoặc thu hồi vai trò tri thức.")
        scoped_sources = KnowledgeCatalog._scope_targets(role, policy_id, source_ids)
        payload.update(policy_id=policy_id, source_ids=scoped_sources)
    with repo.connection(write=True) as db:
        account = _account(db, username)
        fingerprint, previous = _prior(db, approval_id, action, payload)
        if previous is not None:
            return previous
        if action.startswith("knowledge-"):
            if scoped_sources is not None:
                for source_id in scoped_sources:
                    if db.execute("SELECT 1 FROM pol_sources WHERE id=?", (source_id,)).fetchone() is None:
                        raise CoreError("source_not_found", "Chưa có nguồn trong phạm vi được giao.", 404)
                    if action == "knowledge-grant":
                        db.execute("INSERT INTO pol_knowledge_role_scopes VALUES(?,?,'hanoi_policy',?,?,?,?,NULL) "
                                   "ON CONFLICT(account_id,role,domain,policy_id,source_id) DO UPDATE SET "
                                   "granted_by=excluded.granted_by,granted_at=excluded.granted_at,revoked_at=NULL",
                                   (account["id"], role, policy_id, source_id, "operator:" + approval_id, now_iso()))
                    else:
                        db.execute("UPDATE pol_knowledge_role_scopes SET revoked_at=? WHERE account_id=? AND role=? "
                                   "AND domain='hanoi_policy' AND policy_id=? AND source_id=? AND revoked_at IS NULL",
                                   (now_iso(), account["id"], role, policy_id, source_id))
                result = {"approval_id": approval_id, "account_id": account["id"], "role": role, "domain": "hanoi_policy",
                          "policy_id": policy_id, "source_ids": scoped_sources, "scope": "program_sources",
                          "status": "granted" if action == "knowledge-grant" else "revoked", "rules_approved": False,
                          "message": "Đã cập nhật vai trò đúng chương trình/nguồn; không cấp vai trò toàn bộ và không duyệt hoặc phát hành quy tắc."}
                _finish(db, approval_id, action, fingerprint, result)
                return result
            if action == "knowledge-grant":
                db.execute("INSERT INTO pol_knowledge_roles VALUES(?,?,'hanoi_policy',?,?,NULL) "
                           "ON CONFLICT(account_id,role,domain) DO UPDATE SET granted_by=excluded.granted_by,granted_at=excluded.granted_at,revoked_at=NULL",
                           (account["id"], role, "operator:" + approval_id, now_iso()))
                status = "granted"
            else:
                db.execute("UPDATE pol_knowledge_roles SET revoked_at=? WHERE account_id=? AND role=? AND domain='hanoi_policy' AND revoked_at IS NULL",
                           (now_iso(), account["id"], role))
                status = "revoked"
            result = {"approval_id": approval_id, "account_id": account["id"], "role": role, "domain": "hanoi_policy", "status": status,
                      "message": "Đã cập nhật vai trò vận hành theo phê duyệt; không xác nhận tư cách chuyên gia hoặc mở quyền dữ liệu doanh nghiệp."}
            _finish(db, approval_id, action, fingerprint, result)
            return result
        if not isinstance(enterprise_id, str) or not enterprise_id:
            raise CoreError("enterprise_required", "Cần ID doanh nghiệp rõ ràng.")
        if action == "budget-revoke":
            row = db.execute("SELECT id FROM core_budget_grants WHERE id=? AND enterprise_id=? AND account_id=?",
                             (grant_id, enterprise_id, account["id"])).fetchone()
            if row is None:
                raise CoreError("budget_not_found", "Chưa tìm thấy hạn mức đúng tài khoản và doanh nghiệp.", 404)
            db.execute("UPDATE core_budget_grants SET state='revoked' WHERE id=?", (grant_id,))
            result = {"approval_id": approval_id, "grant_id": grant_id, "status": "revoked", "inference_enabled": False,
                      "message": "Đã chặn gửi tiếp. Các lượt đã gửi/chưa rõ phí vẫn giữ nguyên để đối soát."}
            _finish(db, approval_id, action, fingerprint, result)
            return result
        # Reserve the approval before using the existing budget API. A crash in
        # between leaves a visible pending approval, never an automatic duplicate.
        db.execute("INSERT INTO core_operator_approvals VALUES(?,?,?,'pending',NULL,?,NULL)",
                   (approval_id, action, fingerprint, now_iso()))
    result = gateway.authorize_budget(account["id"], enterprise_id, approval_id=approval_id, max_calls=max_calls,
                max_cost_usd=cap_usd, roles=roles, purposes=purposes, expires_at=expires_at)
    safe = {"approval_id": approval_id, "grant_id": result["id"], "status": "granted", "inference_enabled": False,
            "max_calls": max_calls, "cap_usd": str(cap_usd), "roles": sorted(roles), "purposes": sorted(purposes), "expires_at": expires_at,
            "message": "Đã ghi hạn mức. Lệnh này không bật hoặc gọi Claude; cần cấu hình vận hành và đồng ý từng lượt."}
    with repo.connection(write=True) as db:
        _finish(db, approval_id, action, fingerprint, safe)
    return safe


def parser():
    result = argparse.ArgumentParser(description="Quản trị cục bộ có mã phê duyệt; không gọi Claude.")
    result.add_argument("--db", required=True, help="Đường dẫn rõ tới DB hiện có; không tự tạo DB mới.")
    commands = result.add_subparsers(dest="action", required=True)
    account = commands.add_parser("account-create", help="Tạo tài khoản local và tệp đăng nhập riêng; không đặt lại tài khoản có sẵn.")
    account.add_argument("--approval-id", required=True)
    account.add_argument("--username", required=True)
    account.add_argument("--enterprise-name", required=True)
    account.add_argument("--credential-file", required=True)
    for action in ("knowledge-grant", "knowledge-revoke", "budget-grant", "budget-revoke"):
        sub = commands.add_parser(action)
        sub.add_argument("--approval-id", required=True)
        sub.add_argument("--username", required=True)
        if action.startswith("knowledge-"):
            sub.add_argument("--role", required=True, choices=sorted(KNOWLEDGE_ROLES))
            sub.add_argument("--policy-id")
            sub.add_argument("--source-ids", nargs="+")
        else:
            sub.add_argument("--enterprise-id", required=True)
            if action == "budget-grant":
                sub.add_argument("--max-calls", required=True, type=int)
                sub.add_argument("--cap-usd", required=True)
                sub.add_argument("--roles", required=True, nargs="+", choices=["standard", "complex"])
                sub.add_argument("--purposes", required=True, nargs="+")
                sub.add_argument("--expires-at", required=True)
            else:
                sub.add_argument("--grant-id", required=True)
    return result


def main(argv=None):
    args = vars(parser().parse_args(argv))
    target = Path(args.pop("db")).expanduser()
    if not target.is_file():
        print(json_text({"ok": False, "error": {"code": "database_required", "message": "Cần đường dẫn DB hiện có. Chưa thay đổi dữ liệu."}}), file=sys.stderr)
        return 2
    try:
        result = administer(CoreRepository(target.resolve()), **args)
    except CoreError as exc:
        print(json_text({"ok": False, "error": {"code": exc.code, "message": str(exc)}}), file=sys.stderr)
        return 2
    print(json_text({"ok": True, "result": result}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
