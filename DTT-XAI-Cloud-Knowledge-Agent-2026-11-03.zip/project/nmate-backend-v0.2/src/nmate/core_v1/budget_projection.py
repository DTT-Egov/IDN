"""Read-only D06 billing projection; encumbrance is not settled spending."""
from __future__ import annotations


def usage_projection(rows):
    rows = [row for row in rows if row["state"] != "cancelled_before_dispatch"]
    known = sum(row["actual_microusd"] or 0 for row in rows)
    encumbered = sum(row["held_microusd"] for row in rows)
    pending = [row for row in rows if row["actual_microusd"] is None and row["state"] in {"reserved", "dispatch_committed"}]
    uncertain = [row for row in rows if row["actual_microusd"] is None and row["state"] not in {"reserved", "dispatch_committed"}]
    reserved, unresolved = sum(row["held_microusd"] for row in pending), sum(row["held_microusd"] for row in uncertain)
    return {"known_spent_usd": known / 1e6, "actual_spent_usd": None if uncertain else known / 1e6,
            "reserved_usd": reserved / 1e6, "uncertain_usd": unresolved / 1e6,
            "uncertain_calls": len(uncertain), "has_unknown_cost": bool(uncertain),
            "encumbered_usd": encumbered / 1e6,
            "cost_basis": "ledger_usage_estimate_not_invoice",
            "billing_note_vi": "Chi phí tính từ usage và bảng giá đã lưu, chưa phải hóa đơn nhà cung cấp. Khoản giữ chỗ không phải tiền đã chi.",
            "cost_scope": "account_enterprise_history"}
