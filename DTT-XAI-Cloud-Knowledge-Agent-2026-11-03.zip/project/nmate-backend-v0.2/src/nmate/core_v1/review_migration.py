"""Explicit additive review migration; no fact, alias, grant or model writes."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import sys
import unicodedata

from nmate.v03.core import json_text, now_iso

POLICY = "legacy_parser_invalid:20261022-positive-boundary-v2"
POLICY_SOURCE_FILES = (
    "core_v1/review_migration.py", "main/draft_projection.py", "v04/extraction.py",
    "v03/domain_validation.py", "v03/field_scope.py",
)


def policy_source_provenance(source_root=None):
    """Describe the bounded classifier source bundle, not just wrapper bytecode.

    Existing frozen decisions keep their policy/reason. This evidence describes
    a new explicit migration run; it does not attest every runtime dependency
    or replace the immutable release manifest.
    """
    root = Path(source_root) if source_root is not None else Path(__file__).resolve().parents[1]
    manifest = {"policy": POLICY,
                "files": {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                          for name in POLICY_SOURCE_FILES},
                "runtime": {"python": sys.version.split()[0], "unicode": unicodedata.unidata_version}}
    payload = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return {"policy_source_hash": hashlib.sha256(payload.encode("utf8")).hexdigest(),
            "policy_source_hash_kind": "migration-classifier-source-bundle/1",
            "policy_source_manifest": manifest}


def migrate_review_architecture(repo):
    # Fail before constructing services or writing review schema if the source
    # evidence needed for this explicit migration cannot be obtained.
    provenance = policy_source_provenance()
    from nmate.v04.intake import IntakeService
    from nmate.main.draft_projection import project_excluded_legacy_draft

    service = IntakeService(repo)
    with repo.connection(write=True) as db:
        # Freeze only the old, narrow, owner-excluded parser errors before any
        # new projection is used. Never infer that all unchecked values were bad.
        exclusions, drafts = {}, []
        for row in db.execute("SELECT enterprise_id,owner_id,payload_json FROM v04_conversations").fetchall():
            conversation = json.loads(row["payload_json"])
            for workspace in conversation.get("intake_ids", []):
                record = db.execute("SELECT payload_json FROM v04_intakes WHERE id=? AND enterprise_id=? AND owner_id=?",
                                    (workspace, row["enterprise_id"], row["owner_id"])).fetchone()
                if not record:
                    continue
                raw = json.loads(record[0])
                projected = project_excluded_legacy_draft({**copy.deepcopy(conversation), "intake": raw})
                archived = ((projected.get("intake") or {}).get("draft_projection") or {}).get("archived_candidates", [])
                if archived:
                    exclusions[(row["enterprise_id"], row["owner_id"], workspace)] = {c["id"] for c in archived}
                if workspace in conversation.get("drafts", {}):
                    drafts.append((row["enterprise_id"], row["owner_id"], workspace, conversation["drafts"][workspace]))
        result = service.migrate_reviews(db=db)
        frozen = []
        for (enterprise, owner, workspace), ids in exclusions.items():
            heads = service.review_store.heads(db, enterprise, workspace)
            changed = False
            for head in heads:
                if head["candidate_id"] in ids and not head["decision_action"]:
                    service.review_store.decision(db, enterprise, workspace, head, "legacy_archived", owner, POLICY)
                    frozen.append({"enterprise_id": enterprise, "workspace_id": workspace,
                                   "candidate_id": head["candidate_id"], "proposal_hash": head["proposal_hash"],
                                   "policy": POLICY})
                    changed = True
            if changed:
                db.execute("UPDATE core_review_workspaces SET revision=revision+1 WHERE enterprise_id=? AND workspace_id=?",
                           (enterprise, workspace))
        imported_drafts = 0
        for enterprise, actor, workspace, draft in drafts:
            row = service.review_store.workspace(db, enterprise, workspace)
            if row and isinstance(draft, dict):
                saved = {key: draft.get(key, {}) for key in ("selected", "edits", "choices")}
                imported_drafts += db.execute("INSERT OR IGNORE INTO core_review_ui_drafts VALUES(?,?,?,?,?,?,?)",
                    (enterprise, workspace, actor, 1, row["revision"], json_text(saved), now_iso())).rowcount
        # Store derived lifecycle only; the legacy payload stays immutable here.
        for row in db.execute("SELECT enterprise_id,owner_id,payload_json FROM v04_intakes").fetchall():
            payload = json.loads(row["payload_json"])
            service.review_store.project(db, row["owner_id"], row["enterprise_id"], payload)
            db.execute("UPDATE core_review_workspaces SET lifecycle=? WHERE enterprise_id=? AND workspace_id=?",
                       (payload["review"]["lifecycle"], row["enterprise_id"], payload["id"]))
        return {**result, "exclusion_policy": POLICY, "frozen_exclusions": frozen,
                "ui_drafts_imported": imported_drafts, "model_calls": 0,
                **provenance}
