"""Governed one-shot model calls. No grant, no transport; no paid replay."""
from __future__ import annotations

import asyncio
import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_CEILING

from jsonschema import Draft202012Validator

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from .model_contract import canonical_request, SYSTEM_INSTRUCTIONS_V1
from .budget_projection import usage_projection


PRICE_VERSION = "anthropic-public-2026-10-19"
PRICE_SOURCE = "https://platform.claude.com/docs/en/about-claude/pricing"
PRICE_PROFILES = {PRICE_VERSION: {
    "standard": {"model": "claude-sonnet-5-5", "input_rate": "2", "output_rate": "10"},
    "complex": {"model": "claude-opus-5-5", "input_rate": "4", "output_rate": "20"},
}}
PROFILES = PRICE_PROFILES[PRICE_VERSION]
SCHEMA = """
CREATE TABLE IF NOT EXISTS core_budget_grants (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 account_id TEXT NOT NULL REFERENCES v03_accounts(id), approval_id TEXT NOT NULL,
 max_calls INTEGER NOT NULL CHECK(max_calls>0), cap_microusd INTEGER NOT NULL CHECK(cap_microusd>0),
 purposes_json TEXT NOT NULL, roles_json TEXT NOT NULL, expires_at TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS core_model_operations (
 enterprise_id TEXT NOT NULL, operation_id TEXT NOT NULL, actor_id TEXT NOT NULL,
 request_hash TEXT NOT NULL, purpose TEXT NOT NULL, resource_id TEXT,
 state TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,operation_id));
CREATE TABLE IF NOT EXISTS core_model_attempts (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL, operation_id TEXT NOT NULL,
 task_id TEXT NOT NULL, step_key TEXT NOT NULL, actor_id TEXT NOT NULL,
 grant_id TEXT NOT NULL REFERENCES core_budget_grants(id), profile_version TEXT NOT NULL,
 model TEXT NOT NULL, price_version TEXT NOT NULL, request_hash TEXT NOT NULL,
 input_upper_tokens INTEGER NOT NULL, max_output_tokens INTEGER NOT NULL,
 held_microusd INTEGER NOT NULL, actual_microusd INTEGER, state TEXT NOT NULL,
 validation_state TEXT NOT NULL DEFAULT 'not_started', publication_state TEXT NOT NULL DEFAULT 'not_published',
 raw_text TEXT, raw_sha256 TEXT, data_json TEXT, usage_json TEXT, request_id TEXT,
 dependencies_json TEXT NOT NULL DEFAULT '{}',
 error_code TEXT, created_at TEXT NOT NULL, dispatched_at TEXT, finished_at TEXT,
 UNIQUE(enterprise_id,operation_id,task_id,step_key),
 FOREIGN KEY(enterprise_id,operation_id) REFERENCES core_model_operations(enterprise_id,operation_id));
CREATE TABLE IF NOT EXISTS core_model_events (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL, attempt_id TEXT NOT NULL REFERENCES core_model_attempts(id),
 kind TEXT NOT NULL, detail_json TEXT NOT NULL, recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS core_model_request_manifests (
 attempt_id TEXT PRIMARY KEY REFERENCES core_model_attempts(id),
 contract_version TEXT NOT NULL, manifest_hash TEXT NOT NULL,
 manifest_json TEXT NOT NULL, recorded_at TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS core_model_request_manifest_immutable
 BEFORE UPDATE ON core_model_request_manifests
 BEGIN SELECT RAISE(ABORT,'immutable model request manifest'); END;
CREATE TRIGGER IF NOT EXISTS core_model_request_manifest_no_delete
 BEFORE DELETE ON core_model_request_manifests
 BEGIN SELECT RAISE(ABORT,'immutable model request manifest'); END;
"""


def digest(value):
    return hashlib.sha256(json_text(value).encode("utf-8")).hexdigest()


def money_micro(value):
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise CoreError("INVALID_BUDGET", "Hạn mức chi phí chưa hợp lệ.") from None
    if not amount.is_finite() or amount <= 0:
        raise CoreError("INVALID_BUDGET", "Hạn mức chi phí chưa hợp lệ.")
    return int((amount * 1_000_000).to_integral_value(rounding=ROUND_CEILING))


def token_cost(input_tokens, output_tokens, profile):
    return int((Decimal(input_tokens) * Decimal(profile["input_rate"]) +
                Decimal(output_tokens) * Decimal(profile["output_rate"])).to_integral_value(rounding=ROUND_CEILING))


class ModelGateway:
    """The enabled flag is operator-owned; browser/MCP arguments cannot enable it."""

    # Finite storage adapters share _execute_once; these are not wire inputs.
    scope_column = "enterprise_id"
    ledger_tables = {"grants":"core_budget_grants", "operations":"core_model_operations",
                     "attempts":"core_model_attempts", "manifests":"core_model_request_manifests"}

    def __init__(self, repo, *, core=None, api_key=None, request_fn=None, enabled=False, finance=None):
        self.repo, self.core, self.finance = repo, core, finance
        self._api_key, self.request_fn, self.enabled = api_key, request_fn, bool(enabled)
        if not getattr(repo,'managed_runtime',False):
            with repo.connection(write=True) as db:
                db.executescript(SCHEMA)
                if "dependencies_json" not in {r[1] for r in db.execute("PRAGMA table_info(core_model_attempts)")}:
                    db.execute("ALTER TABLE core_model_attempts ADD COLUMN dependencies_json TEXT NOT NULL DEFAULT '{}' ")
        from .budget_pool import BudgetPool
        if getattr(repo,'managed_runtime',False):
            # Managed repositories are opened only after whole-contract verification.
            # Constructor/status must not perform even IF-NOT-EXISTS schema writes.
            self.budget_pool=object.__new__(BudgetPool);self.budget_pool.repo=repo
        else: self.budget_pool = BudgetPool(repo)

    def _member(self, actor, enterprise, db):
        row = db.execute("SELECT m.role FROM v03_memberships m JOIN v03_accounts a ON a.id=m.account_id "
                         "WHERE m.account_id=? AND m.enterprise_id=? AND m.active=1 AND a.active=1",
                         (actor, enterprise)).fetchone()
        if not row:
            raise CoreError("RESOURCE_UNAVAILABLE", "Không tìm thấy tài nguyên được phép truy cập.", 404)
        return row[0]

    def status(self, account_id=None, enterprise_id=None, *, provision=False):
        """Pure quota/readiness projection, including available approved pools.

        ``provision`` remains a compatibility keyword only. Even callers that
        pass True cannot activate authority through a status query (DF-017/021).
        """
        grants, expired_grants, calls, held = [], [], 0, 0
        costs = usage_projection([])
        stamp = now_iso()
        if account_id and enterprise_id:
            with self.repo.connection() as db:
                role = self._member(account_id, enterprise_id, db)
                for row in db.execute("SELECT * FROM core_budget_grants WHERE account_id=? AND enterprise_id=? ORDER BY created_at,id",
                                      (account_id, enterprise_id)):
                    used = db.execute("SELECT COUNT(*),COALESCE(SUM(held_microusd),0) FROM core_model_attempts "
                                      "WHERE grant_id=? AND state!='cancelled_before_dispatch'", (row["id"],)).fetchone()
                    active = row["state"] == "active" and row["expires_at"] > stamp
                    cost = usage_projection(db.execute("SELECT * FROM core_model_attempts WHERE grant_id=?", (row["id"],)).fetchall())
                    item = {**cost, "cost_scope": "private_grant", "id": row["id"], "max_calls": row["max_calls"], "max_cost_usd": row["cap_microusd"] / 1e6,
                                   "remaining_calls": max(0, row["max_calls"]-used[0]), "held_usd": used[1]/1e6,
                                   "purposes": json.loads(row["purposes_json"]), "roles": json.loads(row["roles_json"]),
                                    "remaining_usd": max(0, row["cap_microusd"]-used[1])/1e6 if active else 0,
                                    "state": row["state"] if active or row["state"] != "active" else "expired",
                                    "expires_at": row["expires_at"]}
                    pooled = self.budget_pool.status_grant(db, row["id"])
                    if pooled:
                        item.update(pooled)
                        active = active and pooled["active"]
                    if active:
                        grants.append(item)
                    else:
                        item["remaining_calls"] = 0
                        expired_grants.append(item)
                calls, held = db.execute("SELECT COUNT(*),COALESCE(SUM(held_microusd),0) FROM core_model_attempts "
                                        "WHERE actor_id=? AND enterprise_id=? AND dispatched_at IS NOT NULL",
                                        (account_id, enterprise_id)).fetchone()
                costs = usage_projection(db.execute("SELECT * FROM core_model_attempts WHERE actor_id=? AND enterprise_id=?",
                                                   (account_id, enterprise_id)).fetchall())
                if self.enabled and role == "owner":
                    grants.extend(self.budget_pool.preview(db, account_id, enterprise_id))
        approved = self.enabled and any(g["remaining_calls"] and g["held_usd"] < g["max_cost_usd"] for g in grants)
        reason = "Đã có hạn mức cụ thể cho các tác vụ được duyệt." if approved else (
            "Đã dùng hết lượt hoặc hạn mức D06 đã duyệt; không tự gửi thêm Claude." if grants and all(not g["remaining_calls"] or g["held_usd"] >= g["max_cost_usd"] for g in grants) else
            "Hạn mức D06 trước đã hết hiệu lực hoặc đã đóng; cần phê duyệt mới, không tự cấp lại lượt." if expired_grants else
            "Không còn hạn mức D06 hiệu lực cho lượt mới; kết quả các lượt đã gửi vẫn được giữ." if calls else
            "Chưa duyệt D06 cho lượt Claude thật; các thao tác đọc hồ sơ và nguồn vẫn dùng được.")
        return {**costs, "approved": approved, "reason_vi": reason,
                "max_calls": sum(g["max_calls"] for g in grants) if self.enabled else 0,
                "max_cost_usd": sum(g["max_cost_usd"] for g in grants) if self.enabled else 0,
                "paid_calls": calls, "held_usd": held/1e6, "grants": grants, "expired_grants": expired_grants,
                "next_expiry_at": min((g["expires_at"] for g in grants), default=None),
                "reset_at": None, "reset_policy": "manual_D06_approval_only", "server_time": stamp,
                "budget_timezone": "Asia/Bangkok",
                "profiles": [{"role": k, "model": v["model"], "profile_version": k+"/1"} for k,v in PROFILES.items()],
                "price_version": PRICE_VERSION, "retry_policy": "no_paid_retry_fallback_or_escalation"}

    def authorize_budget(self, account_id, enterprise_id, *, approval_id, max_calls, max_cost_usd,
                         purposes, roles, expires_at):
        """Operator-only Python API, deliberately absent from public MCP tools."""
        if not approval_id or not isinstance(max_calls, int) or isinstance(max_calls, bool) or not 1 <= max_calls <= 100:
            raise CoreError("INVALID_BUDGET", "Cần mã phê duyệt và số lượt cụ thể.")
        if not purposes or not all(isinstance(p,str) and 1<=len(p)<=80 for p in purposes):
            raise CoreError("INVALID_BUDGET", "Cần phạm vi tác vụ được duyệt.")
        if not roles or set(roles)-set(PROFILES):
            raise CoreError("INVALID_BUDGET", "Vai trò mô hình chưa được phép.")
        try:
            expiry = datetime.fromisoformat(expires_at)
            if expiry.tzinfo is None or expiry <= datetime.now(timezone.utc):
                raise ValueError
        except (ValueError, TypeError):
            raise CoreError("INVALID_BUDGET", "Cần thời hạn phê duyệt hợp lệ.") from None
        with self.repo.connection(write=True) as db:
            if self._member(account_id, enterprise_id, db) != "owner":
                raise CoreError("FORBIDDEN", "Chủ doanh nghiệp cần cấp hạn mức riêng cho nhân viên.", 403)
            grant = new_id("budget")
            db.execute("INSERT INTO core_budget_grants VALUES(?,?,?,?,?,?,?,?,?,'active',?)",
                       (grant, enterprise_id, account_id, approval_id, max_calls, money_micro(max_cost_usd),
                        json_text(sorted(set(purposes))), json_text(sorted(set(roles))), expiry.astimezone(timezone.utc).isoformat(), now_iso()))
        return {"id": grant, "approval_id": approval_id, "enabled": self.enabled}

    def recover_interrupted(self):
        return self._recover_attempts('core_model_attempts')

    def recover_domain_interrupted(self):
        # Explicit offline operator action, never a status/read or retry.
        return self._recover_attempts('core_domain_model_attempts')

    def _recover_attempts(self,table):
        if table not in ('core_model_attempts','core_domain_model_attempts'): raise ValueError('Unknown ledger')
        with self.repo.connection(write=True) as db:
            unknown = db.execute(f"UPDATE {table} SET state='outcome_unknown',error_code='PROCESS_INTERRUPTED',"
                                 "finished_at=? WHERE state='dispatch_committed'", (now_iso(),)).rowcount
            db.execute(f"UPDATE {table} SET state='cancelled_before_dispatch',held_microusd=0,"
                       "error_code='PROCESS_INTERRUPTED_BEFORE_DISPATCH',finished_at=? WHERE state='reserved'", (now_iso(),))
            return unknown

    def _grant(self, db, actor, enterprise, grant_id, purpose, role):
        self._member(actor, enterprise, db)
        row = db.execute("SELECT * FROM core_budget_grants WHERE id=? AND enterprise_id=? AND account_id=?",
                         (grant_id, enterprise, actor)).fetchone()
        if not self.enabled or not row or row["state"] != "active" or row["expires_at"] <= now_iso():
            raise CoreError("BUDGET_NOT_GRANTED", "Chưa có phê duyệt D06 còn hiệu lực. Chưa gửi Claude.", 409)
        if purpose not in json.loads(row["purposes_json"]) or role not in json.loads(row["roles_json"]):
            raise CoreError("BUDGET_NOT_GRANTED", "Hạn mức không cho phép tác vụ hoặc mô hình này.", 409)
        self.budget_pool.check_grant(db, grant_id)
        return row

    def activate_budget(self, db, actor, enterprise, grant_id, purpose, role):
        """Explicit begin-command step; never used by query/receipt/dispatch.

        The existing write UoW and later guards govern the whole mutation.
        Existing private/pooled grants retain their exact IDs and restrictions.
        """
        member = self._member(actor, enterprise, db)
        if not self.enabled:
            raise CoreError("BUDGET_NOT_GRANTED", "Chưa có phê duyệt D06 còn hiệu lực. Chưa gửi Claude.", 409)
        if not db.execute("SELECT 1 FROM core_budget_grants WHERE id=? AND enterprise_id=? AND account_id=?",
                          (grant_id, enterprise, actor)).fetchone():
            if member != "owner":
                raise CoreError("BUDGET_NOT_GRANTED", "Hạn mức chung chưa cấp quyền cho tài khoản này. Chưa gửi Claude.", 409)
            self.budget_pool.activate(db, actor, enterprise, grant_id, purpose, role)
        return self._grant(db, actor, enterprise, grant_id, purpose, role)

    def _event(self, db, enterprise, attempt, kind, detail=None):
        db.execute("INSERT INTO core_model_events VALUES(?,?,?,?,?,?)",
                   (new_id("model_event"),enterprise,attempt,kind,json_text(detail or {}),now_iso()))

    def _seal_request_input(self,db,attempt,body,contract):
        # Enterprise callers already persist their owner-private intake input;
        # keep this legacy contract unchanged. Domain adapter seals public input
        # in the same reservation transaction, before any dispatch fence.
        return None

    def _require_resource(self, db, account, enterprise, resource):
        """Authorize in the caller's transaction, including final dispatch fence."""
        if resource:
            if self.core is None:
                raise CoreError("RESOURCE_AUTHORITY_UNAVAILABLE", "Chưa có bộ kiểm quyền hồ sơ cho lượt này. Chưa gửi Claude.", 409)
            self.core._require(db, account, enterprise, resource)

    def _require_dependencies(self, db, account, enterprise, dependencies):
        self._require_resource(db, account, enterprise, dependencies.get("resource_id"))
        for dependency in dependencies.get("resource_dependencies", []):
            resource = dependency["resource_id"]
            self._require_resource(db, account, enterprise, resource)
            for field in dependency["fields"]:
                self.core._require(db, account, enterprise, resource, field=field)
        self._require_public_wiki(db,account,dependencies,mode='history',export=False)

    def _require_public_wiki(self,db,actor,dependencies,*,mode,export):
        refs=dependencies.get('public_wiki_refs')
        if refs is None:return
        if not isinstance(refs,list) or not 1<=len(refs)<=20:
            raise CoreError('RECORDED_MANIFEST_MISMATCH','Căn cứ wiki đã lưu không đúng hợp đồng.',409)
        from nmate.knowledge_v1.serving import PublishedKnowledge
        from nmate.knowledge_v1.operator_m4 import require_m4
        require_m4(db)
        reader=object.__new__(PublishedKnowledge);reader.repo=self.repo
        proofs=[]
        for ref in refs:
            if mode=='current':proofs.append(reader._current_control_proofs(db,actor,ref,export=export))
            else:reader._read_reference(db,actor,ref,mode=mode,export=export)
        if proofs:return dict(schema_version='dispatch-authorizations/1',public_wiki_authorizations=proofs)

    @staticmethod
    def _dependencies(resource_id, egress_ids, resource_dependencies):
        if resource_id is not None and (not isinstance(resource_id, str) or not 1 <= len(resource_id) <= 128):
            raise CoreError("INVALID_MODEL_REQUEST", "Mã hồ sơ đầu vào chưa đúng hợp đồng.")
        result = {"resource_id": resource_id, "financial_egress_grant_ids": egress_ids or []}
        if resource_dependencies:
            if not isinstance(resource_dependencies, list) or len(resource_dependencies) > 100:
                raise CoreError("INVALID_MODEL_REQUEST", "Phạm vi dữ kiện đầu vào chưa đúng hợp đồng.")
            refs = {}
            for ref in resource_dependencies:
                if not isinstance(ref, dict) or set(ref) != {"resource_id", "fields"}:
                    raise CoreError("INVALID_MODEL_REQUEST", "Căn cứ hồ sơ cần mã và danh sách dữ kiện rõ ràng.")
                rid, fields = ref["resource_id"], ref["fields"]
                if (not isinstance(rid, str) or not 1 <= len(rid) <= 128 or not isinstance(fields, list)
                        or len(fields) > 100 or any(not isinstance(f, str) or not 1 <= len(f) <= 128 for f in fields)):
                    raise CoreError("INVALID_MODEL_REQUEST", "Căn cứ hồ sơ chưa đúng cấu trúc.")
                refs.setdefault(rid, set()).update(fields)
            result["resource_dependencies"] = [{"resource_id": rid, "fields": sorted(fields)} for rid, fields in sorted(refs.items())]
        elif resource_dependencies is not None and resource_dependencies != []:
            raise CoreError("INVALID_MODEL_REQUEST", "Phạm vi dữ kiện đầu vào chưa đúng hợp đồng.")
        return result

    def read_receipt(self, account_id, enterprise_id, attempt_id, *, db=None):
        """Read accepted output under current ACL; no grant/transport capability.

        Compatibility adapters must call this boundary rather than treating
        their copied envelope as independent permission to read derived data.
        D06 expiry or exhausted quota never prevents an otherwise lawful read.
        """
        if db is None:
            with self.repo.connection() as connection:
                return self.read_receipt(account_id, enterprise_id, attempt_id, db=connection)
        self._member(account_id, enterprise_id, db)
        row = db.execute("SELECT * FROM core_model_attempts WHERE id=? AND enterprise_id=? AND actor_id=?",
                         (attempt_id, enterprise_id, account_id)).fetchone()
        if row is None:
            raise CoreError("RESOURCE_UNAVAILABLE", "Không tìm thấy kết quả được phép đọc.", 404)
        if row["state"] != "response_received" or row["validation_state"] != "accepted" or not row["data_json"]:
            raise CoreError("LIVE_ATTEMPT_NOT_REPLAYED", "Lượt chưa có kết quả đã kiểm chứng để đọc lại. Không tự gửi Claude.", 409)
        dependencies = json.loads(row["dependencies_json"])
        saved_manifest = db.execute("SELECT * FROM core_model_request_manifests WHERE attempt_id=?", (attempt_id,)).fetchone()
        if saved_manifest:
            manifest = json.loads(saved_manifest["manifest_json"])
            scope_hash = digest([row["actor_id"], row["enterprise_id"], row["operation_id"], row["task_id"], row["step_key"]])
            if (digest(manifest) != saved_manifest["manifest_hash"]
                    or manifest.get("request_hash") != row["request_hash"]
                    or manifest.get("dependencies_sha256") != digest(dependencies)
                    or manifest.get("operation_scope_sha256") != scope_hash
                    or manifest.get("model") != row["model"]
                    or manifest.get("profile_version") != row["profile_version"]
                    or manifest.get("max_output_tokens") != row["max_output_tokens"]):
                raise CoreError("RECORDED_MANIFEST_MISMATCH", "Định danh hoặc quyền đầu vào không còn khớp biên nhận gốc. Không gọi AI.", 409)
        self._require_dependencies(db, account_id, enterprise_id, dependencies)
        egress_ids = dependencies.get("financial_egress_grant_ids", [])
        if egress_ids and self.finance is None:
            raise CoreError("DATA_EGRESS_AUTHORITY_UNAVAILABLE", "Chưa kiểm được quyền dùng kết quả có chỉ tiêu tài chính.", 409)
        if self.finance:
            self.finance.verify_publication(account_id, enterprise_id, egress_ids, db=db)
        return {"data": json.loads(row["data_json"]), "attempt_id": row["id"], "model": row["model"],
                "cached": True, "usage": json.loads(row["usage_json"] or "{}")}

    def mark_publication(self, account_id, enterprise_id, attempt_id, *, published, reason_code=None, db=None):
        """Internal capability verdict after schema validation, separate from receipt."""
        if db is None:
            with self.repo.connection(write=True) as connection:
                return self.mark_publication(account_id, enterprise_id, attempt_id, published=published,
                                             reason_code=reason_code, db=connection)
        if published:
            self._member(account_id, enterprise_id, db)
        row = db.execute("SELECT * FROM core_model_attempts WHERE id=? AND enterprise_id=? AND actor_id=?",
                         (attempt_id, enterprise_id, account_id)).fetchone()
        if row is None or (published and row["validation_state"] != "accepted"):
            raise CoreError("INVALID_PUBLICATION", "Kết quả chưa đủ hợp đồng để công bố.", 409)
        if published:
            self.read_receipt(account_id, enterprise_id, attempt_id, db=db)
        state = "published" if published else "blocked_business_validation"
        db.execute("UPDATE core_model_attempts SET publication_state=? WHERE id=?", (state, attempt_id))
        self._event(db, enterprise_id, attempt_id, state, {"reason_code": reason_code})

    async def call_once(self, *, account_id, enterprise_id, operation_id, task_id, role, purpose,
                        context, output_schema, budget_grant_id, financial_egress_grant_ids=None,
                        step_key="synthesis", resource_id=None, max_output_tokens=4096, task_instructions_vi="",
                        resource_dependencies=None,public_wiki_refs=None):
        # Existing enterprise identity and canonical request remain unchanged.
        return await self._execute_once(authority=self, account_id=account_id, scope_id=enterprise_id,
            operation_id=operation_id, task_id=task_id, role=role, purpose=purpose, context=context,
            output_schema=output_schema, budget_grant_id=budget_grant_id,
            financial_egress_grant_ids=financial_egress_grant_ids, step_key=step_key, resource_id=resource_id,
            max_output_tokens=max_output_tokens, task_instructions_vi=task_instructions_vi,
            resource_dependencies=resource_dependencies,public_wiki_refs=public_wiki_refs)

    def authorize_domain_budget(self, account_id, scope, **options):
        # Trusted local operator only; never registered as a browser/MCP tool.
        from .domain_gateway import authorize_domain_budget
        return authorize_domain_budget(self, account_id, scope, **options)

    def domain_status(self,account_id,scope,grant_id):
        from .domain_gateway import _account
        with self.repo.connection() as db:
            _account(db,account_id)
            row=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=? AND account_id=? AND scope_id=?',(grant_id,account_id,scope.key)).fetchone()
            if row is None: raise CoreError('RESOURCE_UNAVAILABLE','Không có hạn mức được phép.',404)
            attempts=db.execute('SELECT * FROM core_domain_model_attempts WHERE grant_id=?',(grant_id,)).fetchall()
            held=sum(a['held_microusd'] for a in attempts);count=sum(a['state']!='cancelled_before_dispatch' for a in attempts)
            return dict(grant_id=grant_id,scope=scope.key,max_calls=row['max_calls'],used_calls=count,
                cap_usd=row['cap_microusd']/1e6,held_usd=held/1e6,expires_at=row['expires_at'],
                state=row['state'] if row['expires_at']>now_iso() else 'expired',**usage_projection(attempts))

    async def call_domain_once(self, *, source_reader, account_id, scope, operation_id, task_id, role,
                               purpose, source_refs, output_schema, budget_grant_id,
                               max_output_tokens=4096, recipe="policy-knowledge-draft/1", execution_tier=None):
        from .domain_gateway import DomainAuthority
        authority=DomainAuthority(self,source_reader,account_id,scope,source_refs,recipe,role)
        authority.bind_slot(task_id,purpose,budget_grant_id)
        if (recipe.endswith('/2') or recipe=='policy-knowledge-package/1') and execution_tier is None:
            raise CoreError('EXECUTION_PROFILE_REQUIRED','Tác vụ mới cần cấu hình thực thi và hạn mức riêng được duyệt.',409)
        if execution_tier is not None:
            from nmate.knowledge_v1.demo_artifacts import kind_for,schema
            if recipe not in {'policy-knowledge-draft/2','policy-knowledge-critique/2','policy-knowledge-package/1'} or digest(output_schema)!=digest(schema(kind_for(task_id,recipe))):
                raise CoreError('INVALID_EXECUTION_PROFILE','Cấu hình mới cần đúng hợp đồng đầu ra đã ghim.',409)
        context=authority.compile_public_input()
        return await self._execute_once(authority=authority, account_id=account_id, scope_id=scope.key,
            operation_id=operation_id, task_id=task_id, role=role, purpose=purpose, context=context,
            output_schema=output_schema, budget_grant_id=budget_grant_id,
            max_output_tokens=max_output_tokens, task_instructions_vi=authority.instructions, execution_tier=execution_tier)

    def read_domain_receipt(self,source_reader,account_id,scope,attempt_id,*,export=False):
        from .domain_gateway import DomainAuthority
        with self.repo.connection() as db:
            row=db.execute('SELECT * FROM core_domain_model_attempts WHERE id=? AND actor_id=? AND scope_id=?',(attempt_id,account_id,scope.key)).fetchone()
            if row is None: raise CoreError('RESOURCE_UNAVAILABLE','Không có kết quả được phép.',404)
            try:
                dep=json.loads(row['dependencies_json'])
                if (not isinstance(dep,dict) or set(dep)!={'subject_kind','account_id','scope_kind','domain','policy_id','source_refs','recipe','prior_attempt_ids'} or
                    dep['subject_kind']!='account' or dep['scope_kind']!='public_domain' or dep['account_id']!=account_id or
                    dep['domain']!=scope.domain or dep['policy_id']!=scope.policy_id or not isinstance(dep['source_refs'],list) or
                    not isinstance(dep['prior_attempt_ids'],list) or len(dep['prior_attempt_ids'])>2 or
                    any(not isinstance(a,str) or a==attempt_id for a in dep['prior_attempt_ids'])): raise ValueError()
            except (TypeError,ValueError,KeyError): raise CoreError('RECORDED_MANIFEST_MISMATCH','Dependency đã lưu không đúng hợp đồng; cần đối soát.',409) from None
            port=DomainAuthority(self,source_reader,account_id,scope,dep['source_refs'],dep['recipe'],row['profile_version'].split('/')[0])
            port.task_id=row['task_id'];port.prior_ids=dep.get('prior_attempt_ids',[])
            return port.read_receipt(account_id,scope.key,attempt_id,db=db,export=export)

    def _require_dispatch_dependencies(self,db,actor,scope,dependencies):
        self._require_dependencies(db,actor,scope,dependencies)
        return self._require_public_wiki(db,actor,dependencies,mode='current',export=True)

    def _require_reservation_dependencies(self,db,actor,scope,dependencies):
        # Enterprise READ was already checked in this same reservation UoW.
        # Financial egress has its own existing verify_dispatch below.
        return self._require_public_wiki(db,actor,dependencies,mode='current',export=True)

    async def _execute_once(self, *, authority, account_id, scope_id, operation_id, task_id, role, purpose, context, output_schema, budget_grant_id, financial_egress_grant_ids=None, step_key='synthesis', resource_id=None, max_output_tokens=4096, task_instructions_vi='', resource_dependencies=None,public_wiki_refs=None,execution_tier=None):
        role = {'simple': 'standard', 'reasoning.standard': 'standard', 'reasoning.complex': 'complex'}.get(role, role)
        if role not in PROFILES or not isinstance(context, dict) or (not isinstance(output_schema, dict)):
            raise CoreError('INVALID_MODEL_REQUEST', 'Yêu cầu mô hình chưa đúng hợp đồng.')
        if any((not isinstance(v, str) or not 1 <= len(v) <= 128 for v in (operation_id, task_id, step_key, purpose))):
            raise CoreError('INVALID_MODEL_REQUEST', 'Mã tác vụ chưa hợp lệ.')
        if not isinstance(max_output_tokens, int) or isinstance(max_output_tokens, bool) or (not 256 <= max_output_tokens <= 4096):
            raise CoreError('INPUT_LIMIT', 'Giới hạn đầu ra chưa phù hợp với lượt được duyệt.')
        Draft202012Validator.check_schema(output_schema)
        if not isinstance(task_instructions_vi, str) or len(task_instructions_vi.encode('utf-8')) > 16000:
            raise CoreError('INVALID_MODEL_REQUEST', 'Chỉ dẫn tác vụ chưa đúng hợp đồng.')
        if financial_egress_grant_ids is not None and (not isinstance(financial_egress_grant_ids, list) or any((not isinstance(value, str) or not value or len(value) > 128 for value in financial_egress_grant_ids)) or len(set(financial_egress_grant_ids)) != len(financial_egress_grant_ids)):
            raise CoreError('INVALID_MODEL_REQUEST', 'Quyền gửi chỉ tiêu chưa đúng cấu trúc.')
        if financial_egress_grant_ids and self.finance is None:
            raise CoreError('DATA_EGRESS_AUTHORITY_UNAVAILABLE', 'Chưa có bộ kiểm quyền gửi chỉ tiêu tài chính. Chưa gửi Claude.', 409)
        payload = self.compile_payload(context, financial_egress_grant_ids)
        dependencies = authority._dependencies(resource_id, financial_egress_grant_ids, resource_dependencies)
        if public_wiki_refs is not None:
            if (authority is not self or not isinstance(public_wiki_refs,list) or len(public_wiki_refs)>20 or
                any(not isinstance(ref,dict) for ref in public_wiki_refs)):
                raise CoreError('INVALID_MODEL_REQUEST','Cần các căn cứ wiki công khai có kiểu; không gửi vào worker xây kho.')
            # Never add an implicit [] to old requests/receipts. New evidence
            # is sealed in the same canonical dependencies/manifest as SSOT.
            if public_wiki_refs:
                from nmate.knowledge_v1.serving import validate_reference_shape
                for ref in public_wiki_refs:validate_reference_shape(ref)
                dependencies['public_wiki_refs']=json.loads(json_text(public_wiki_refs))
        profile = PROFILES[role]
        def compile_request(execution_profile=None):
            return canonical_request(payload=payload, output_schema=output_schema, purpose=purpose, role=role, profile_version=role + '/1', model=profile['model'], max_output_tokens=max_output_tokens, dependencies=dependencies, instructions=task_instructions_vi,execution_profile=execution_profile)
        contract = compile_request()
        execution_profile=None
        if execution_tier is not None:
            if authority is self:
                raise CoreError('INVALID_EXECUTION_PROFILE','Cấu hình pilot chỉ dành cho tác vụ kho công khai đã duyệt.',409)
            from .execution_profiles import compile_profile
            # Fixed-point preflight: profile bytes themselves count toward the
            # same conservative input bound, hold and sealed request identity.
            for _ in range(10):
                upper=8192+2*len(contract['wire'].encode('utf-8'))
                selected=compile_profile(role,execution_tier,input_upper=upper)
                if selected==execution_profile:break
                execution_profile=selected;max_output_tokens=selected['max_output_tokens']
                contract=compile_request(execution_profile)
            else:raise CoreError('PROFILE_NOT_FEASIBLE','Chưa tính ổn định được ngân sách đầu ra; chưa gọi AI.',409)
            authority.execution_profile=execution_profile
        contract['manifest']['operation_scope_sha256'] = digest([account_id, scope_id, operation_id, task_id, step_key])
        contract['manifest_hash'] = digest(contract['manifest'])
        body, raw, request_hash = (contract['body'], contract['wire'], contract['request_hash'])
        if len(raw.encode('utf-8')) > 30000:
            raise CoreError('INPUT_LIMIT', 'Nội dung vượt mức 30 KB của vòng thử; chưa gửi Claude.', 413)
        input_upper = 8192 + 2 * len(raw.encode('utf-8'))
        hold = token_cost(input_upper, max_output_tokens, profile)
        with self.repo.connection(write=True) as db:
            authority._member(account_id, scope_id, db)
            authority._require_dependencies(db, account_id, scope_id, dependencies)
            old_op = db.execute(f"SELECT * FROM {authority.ledger_tables['operations']} WHERE {authority.scope_column}=? AND operation_id=?", (scope_id, operation_id)).fetchone()
            if old_op and (old_op['actor_id'] != account_id or old_op['purpose'] != purpose):
                raise CoreError('IDEMPOTENCY_CONFLICT', 'Mã lượt đã dùng cho tác vụ khác.', 409)
            old = db.execute(f"SELECT * FROM {authority.ledger_tables['attempts']} WHERE {authority.scope_column}=? AND operation_id=? AND task_id=? AND step_key=?", (scope_id, operation_id, task_id, step_key)).fetchone()
            if old:
                if old['request_hash'] != request_hash:
                    raise CoreError('IDEMPOTENCY_CONFLICT', 'Nội dung khác lượt đã lưu; không gửi lại.', 409)
                saved_manifest = db.execute(f"SELECT manifest_hash FROM {authority.ledger_tables['manifests']} WHERE attempt_id=?", (old['id'],)).fetchone()
                if saved_manifest and saved_manifest[0] != contract['manifest_hash']:
                    raise CoreError('RECORDED_CONTRACT_CHANGED', 'Hợp đồng đã khác lượt gốc. Chỉ mở kết quả đã lưu; không gửi lại Claude.', 409)
                if old['state'] == 'response_received' and old['validation_state'] == 'accepted':
                    return authority.read_receipt(account_id, scope_id, old['id'], db=db)
                raise CoreError('OUTCOME_UNKNOWN' if old['state'] == 'outcome_unknown' else 'LIVE_ATTEMPT_NOT_REPLAYED', 'Lượt đã ghi nhận; không tự gửi lại, đổi mô hình hoặc sửa bằng lượt có phí.', 409)
            grant = authority.activate_budget(db, account_id, scope_id, budget_grant_id, purpose, role)
            authority._require_reservation_dependencies(db,account_id,scope_id,dependencies)
            if self.request_fn is None and (not self._api_key):
                raise CoreError('MODEL_NOT_CONFIGURED', 'Claude chưa được cấu hình; chưa gửi yêu cầu.', 503)
            if authority.finance:
                authority.finance.verify_dispatch(account_id, scope_id, operation_id, task_id, purpose, role + '/1', payload, financial_egress_grant_ids or [], db=db)
            count, reserved = db.execute(f"SELECT COUNT(*),COALESCE(SUM(held_microusd),0) FROM {authority.ledger_tables['attempts']} WHERE grant_id=? AND state!='cancelled_before_dispatch'", (grant['id'],)).fetchone()
            if count >= grant['max_calls'] or reserved + hold > grant['cap_microusd']:
                raise CoreError('BUDGET_EXCEEDED', 'Không còn đủ lượt hoặc hạn mức dự trù; chưa gửi Claude.', 409)
            authority.budget_pool.check_reservation(db, grant['id'], hold)
            if not old_op:
                db.execute(f"INSERT INTO {authority.ledger_tables['operations']} VALUES(?,?,?,?,?,?,'reserved',?)", (scope_id, operation_id, account_id, request_hash, purpose, resource_id, now_iso()))
            attempt = new_id('model_attempt')
            db.execute(f"INSERT INTO {authority.ledger_tables['attempts']}(id,{authority.scope_column},operation_id,task_id,step_key,actor_id,grant_id,profile_version,model,price_version,request_hash,input_upper_tokens,max_output_tokens,held_microusd,state,created_at,dependencies_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,'reserved',?,?)", (attempt, scope_id, operation_id, task_id, step_key, account_id, grant['id'], role + '/1', profile['model'], PRICE_VERSION, request_hash, input_upper, max_output_tokens, hold, now_iso(), json_text(dependencies)))
            db.execute(f"INSERT INTO {authority.ledger_tables['manifests']} VALUES(?,?,?,?,?)", (attempt, contract['manifest']['contract_version'], contract['manifest_hash'], json_text(contract['manifest']), now_iso()))
            authority._seal_request_input(db,attempt,body,contract)
            authority._event(db, scope_id, attempt, 'reserved', {'hold_microusd': hold, 'profile_version': role + '/1'})
        try:
            with self.repo.connection(write=True) as db:
                authority._grant(db, account_id, scope_id, budget_grant_id, purpose, role)
                authorization_proofs=authority._require_dispatch_dependencies(db, account_id, scope_id, dependencies)
                if authority.finance:
                    authority.finance.verify_dispatch(account_id, scope_id, operation_id, task_id, purpose, role + '/1', payload, financial_egress_grant_ids or [], db=db)
                changed = db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET state='dispatch_committed',dispatched_at=? WHERE id=? AND state='reserved'", (now_iso(), attempt)).rowcount
                if changed != 1:
                    raise CoreError('LIVE_ATTEMPT_NOT_REPLAYED', 'Lượt đã được ghi nhận, không gửi thêm.', 409)
                authority._event(db, scope_id, attempt, 'dispatch_committed',authorization_proofs)
        except BaseException:
            with self.repo.connection(write=True) as db:
                db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET state='cancelled_before_dispatch',held_microusd=0,finished_at=? WHERE id=? AND state='reserved'", (now_iso(), attempt))
            raise
        try:
            fn = self.request_fn or self._request
            response = await fn(profile['model'], body, max_output_tokens)
        except BaseException as exc:
            with self.repo.connection(write=True) as db:
                db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET state='outcome_unknown',error_code=?,finished_at=? WHERE id=?", ('CANCELLED_AFTER_DISPATCH' if isinstance(exc, asyncio.CancelledError) else 'PROVIDER_OUTCOME_UNKNOWN', now_iso(), attempt))
                authority._event(db, scope_id, attempt, 'outcome_unknown')
            if isinstance(exc, asyncio.CancelledError):
                raise
            raise CoreError('OUTCOME_UNKNOWN', 'Lượt gửi chưa rõ kết quả/phí. Không tự gửi lại.', 502) from None
        malformed = not isinstance(response, dict) or not isinstance(response.get('text'), str)
        response = response if isinstance(response, dict) else {}
        if not isinstance(response.get('stop_reason'),(str,type(None))) or not isinstance(response.get('model'),(str,type(None))):
            malformed=True
        text = response.get('text') if isinstance(response.get('text'), str) else ''
        try: text.encode('utf-8')
        except UnicodeError:
            # Preserve an escaped representation for audit without allowing a
            # malformed response to strand a charged attempt before persistence.
            text=text.encode('utf-8',errors='backslashreplace').decode('utf-8');malformed=True
        usage = response.get('usage', {})
        usage = {k: v for k, v in usage.items() if k in {'input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens'} and isinstance(v, int) and (not isinstance(v, bool)) and (v >= 0)} if isinstance(usage, dict) else {}
        if any(v>2**31-1 for v in usage.values()): usage={};malformed=True
        request_id = response.get('request_id')
        if not isinstance(request_id, (str, type(None))) or len(request_id or '') > 200:
            request_id = None
        raw_hash = hashlib.sha256(text.encode('utf-8')).hexdigest()
        actual = self._usage_cost(usage, profile)
        with self.repo.connection(write=True) as db:
            db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET state='response_received',raw_text=?,raw_sha256=?,usage_json=?,request_id=?,actual_microusd=?,held_microusd=?,finished_at=? WHERE id=?", (text, raw_hash, json_text(usage), request_id, actual, actual if actual is not None else hold, now_iso(), attempt))
            stop=response.get('stop_reason')
            reported=response.get('model')
            completion=dict(schema_version='provider-completion/1',
                stop_reason=stop if isinstance(stop,str) and stop in {'end_turn','max_tokens','stop_sequence','tool_use','pause_turn','refusal'} else 'unknown',
                reported_model=reported if isinstance(reported,str) and reported in {p['model'] for p in PROFILES.values()} else 'unknown',
                visible_text_length=len(text),request_max_output_tokens=max_output_tokens,
                execution_profile_hash=digest(execution_profile) if execution_profile is not None else None,
                metadata_malformed=malformed)
            authority._event(db, scope_id, attempt, 'response_received', {'raw_sha256': raw_hash, 'usage_known': actual is not None,'completion':completion})
            if actual is not None and actual > hold:
                db.execute(f"UPDATE {authority.ledger_tables['grants']} SET state='needs_reconciliation' WHERE id=?", (budget_grant_id,))
                authority._event(db, scope_id, attempt, 'estimate_overrun', {'actual_microusd': actual})
        reason_code='OUTPUT_JSON_INVALID'
        try:
            if malformed:
                reason_code='PROVIDER_ENVELOPE_INVALID';raise ValueError()
            if response.get('model', profile['model']) != profile['model'] or execution_profile is not None and response.get('model')!=profile['model']:
                reason_code='PROVIDER_MODEL_MISMATCH';raise ValueError()
            if response.get('stop_reason') not in (None, 'end_turn') or execution_profile is not None and response.get('stop_reason')!='end_turn':
                reason_code='OUTPUT_INCOMPLETE' if response.get('stop_reason')=='max_tokens' else 'PROVIDER_STOP_UNSUPPORTED'
                raise ValueError()
            result = json.loads(text)
            reason_code='OUTPUT_SCHEMA_INVALID'
            Draft202012Validator(output_schema).validate(result)
            if execution_profile is not None:
                from nmate.knowledge_v1.demo_artifacts import validate_artifact,kind_for
                reason_code='ARTIFACT_GOAL_INCOMPLETE'
                validate_artifact(result,expected_kind=kind_for(task_id,payload['recipe']),prior_proposals=payload.get('prior_proposals'))
        except Exception:
            with self.repo.connection(write=True) as db:
                db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET validation_state='rejected',error_code='OUTPUT_REJECTED' WHERE id=?", (attempt,))
                authority._event(db, scope_id, attempt, 'output_rejected',{'reason_code':reason_code})
            raise CoreError('OUTPUT_REJECTED', 'Đã nhận phản hồi nhưng chưa đạt hợp đồng. Giữ bản gốc; không gọi AI lại.', 502) from None
        with self.repo.connection(write=True) as db:
            db.execute(f"UPDATE {authority.ledger_tables['attempts']} SET validation_state='accepted',data_json=? WHERE id=?", (json_text(result), attempt))
            authority._event(db, scope_id, attempt, 'schema_accepted')
        try:
            with self.repo.connection() as db:
                authority._member(account_id, scope_id, db)
                authority._require_dependencies(db, account_id, scope_id, dependencies)
                if authority.finance:
                    authority.finance.verify_publication(account_id, scope_id, financial_egress_grant_ids or [], db=db)
        except CoreError as exc:
            authority.mark_publication(account_id, scope_id, attempt, published=False, reason_code=exc.code)
            raise
        return {'data': result, 'attempt_id': attempt, 'model': profile['model'], 'cached': False, 'usage': usage, 'estimated_usd': None if actual is None else actual / 1000000.0, 'price_version': PRICE_VERSION}

    @staticmethod
    def compile_payload(context, egress_ids):
        """Financial text/chunks/images are never a back door around typed metrics."""
        from .finance import FinanceService, is_financial_field
        # This validation does not depend on an optional configured verifier.
        # Even without grants, an annotated metric (`field`/`metric_code`) must
        # not travel as ordinary prose or an unsealed arbitrary object.
        FinanceService._assert_no_raw(context)
        forbidden={"attachments","base64","data_base64","image","image_url","document_bytes","raw_document","original_document","ocr_text","sheet_dump","filename","file_name","file_path"}
        def walk(value):
            if isinstance(value,dict):
                for k,v in value.items():
                    if k.casefold() in forbidden:
                        raise CoreError("DATA_EGRESS_BLOCKED","Đầu vào chứa tài liệu thô; chỉ gửi chỉ tiêu tối thiểu đã cho phép.",409)
                    if (is_financial_field(k.casefold()) or k.casefold() in {"salary", "customer_list", "financial_statement"}) and not egress_ids:
                        raise CoreError("DATA_EGRESS_BLOCKED","Chỉ tiêu tài chính chưa có quyền gửi riêng.",409)
                    walk(v)
            elif isinstance(value,list):
                for v in value:
                    walk(v)
            elif isinstance(value,str) and len(value)>16000:
                raise CoreError("INPUT_LIMIT","Cần rút gọn đầu vào theo mục tiêu trước khi gửi.",413)
        walk(context)
        if context.get("financial_metrics") and not egress_ids:
            raise CoreError("DATA_EGRESS_BLOCKED","Chỉ tiêu tài chính chưa có quyền gửi riêng.",409)
        return json.loads(json_text(context))

    @staticmethod
    def _usage_cost(usage, profile):
        if not isinstance(usage,dict) or not all(isinstance(usage.get(k),int) and not isinstance(usage.get(k),bool)
                                               and usage[k]>=0 for k in ("input_tokens","output_tokens")):
            return None
        extra=sum(usage.get(k,0) for k in ("cache_read_input_tokens","cache_creation_input_tokens")
                  if isinstance(usage.get(k,0),int))
        return token_cost(usage["input_tokens"]+extra,usage["output_tokens"],profile)

    async def _request(self, model, body, max_tokens):
        if not self._api_key:
            raise CoreError("MODEL_NOT_CONFIGURED","Claude chưa được cấu hình; không tự đổi nhà cung cấp.",503)
        from anthropic import AsyncAnthropic, transform_schema
        import httpx2
        system=SYSTEM_INSTRUCTIONS_V1
        if body.get("task_instructions_vi"):
            system += "\nHợp đồng tác vụ từ máy chủ:\n" + body["task_instructions_vi"]
        async with httpx2.AsyncClient(trust_env=False,timeout=90) as http:
            async with AsyncAnthropic(api_key=self._api_key,base_url="https://api.anthropic.com",max_retries=0,
                                      timeout=90,http_client=http) as client:
                execution=body.get('execution_profile')
                role='complex' if model==PROFILES['complex']['model'] else 'standard'
                if execution is not None:
                    from .execution_profiles import validate_profile
                    validate_profile(execution,role)
                    if execution['max_output_tokens']!=max_tokens:raise CoreError('INVALID_EXECUTION_PROFILE','Trần token khác manifest.',409)
                response=await client.messages.create(model=model,max_tokens=max_tokens,thinking={"type":"adaptive"},
                    output_config={"effort":execution['effort'] if execution is not None else ('medium' if role=='complex' else 'low'),
                                   "format":{"type":"json_schema","schema":transform_schema(body["response_schema"])}},
                    system=system,messages=[{"role":"user","content":json_text(body["input"])}])
        return {"text":"".join(v.text for v in response.content if v.type=="text"),"model":response.model,
                "stop_reason":response.stop_reason,"request_id":getattr(response,"_request_id",None),
                "usage":response.usage.model_dump(mode="json")}
