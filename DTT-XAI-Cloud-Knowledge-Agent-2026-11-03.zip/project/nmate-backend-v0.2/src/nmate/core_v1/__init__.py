"""Additive shared core; legacy repositories remain authoritative."""
