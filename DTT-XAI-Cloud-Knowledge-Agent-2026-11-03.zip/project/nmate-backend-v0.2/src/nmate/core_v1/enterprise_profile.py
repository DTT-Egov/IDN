"""Explicit aggregate identity: registration container → one confirmed-fact profile.

Reads never create a profile or infer a link from a display name/order. Opening
is an owner command; it creates only metadata, or links an exact existing ID.
Business assertions still pass the existing proposal/confirmation authority.
"""
from nmate.v03.core import CoreError, new_id, now_iso, require_valid_entity_name
from nmate.v03.field_scope import canonical_entity_type


SCHEMA = """
CREATE TABLE IF NOT EXISTS core_v1_enterprise_profiles (
 enterprise_id TEXT PRIMARY KEY REFERENCES v03_enterprises(id),
 entity_id TEXT NOT NULL UNIQUE,
 linked_by TEXT NOT NULL REFERENCES v03_accounts(id),linked_at TEXT NOT NULL,
 version INTEGER NOT NULL DEFAULT 1 CHECK(version=1),
 FOREIGN KEY(enterprise_id,entity_id) REFERENCES v03_entities(enterprise_id,id));
"""


def bound_enterprise_profile_id(core, db, account, enterprise):
    """Resolve a new command's default; an unreadable binding never falls back."""
    core.membership(account, enterprise, db)
    row = db.execute('SELECT entity_id FROM core_v1_enterprise_profiles WHERE enterprise_id=?',
                     (enterprise,)).fetchone()
    if row is None:
        return None
    entity = core._entity(db, enterprise, row['entity_id'])
    core._require(db, account, enterprise, entity['id'])
    if canonical_entity_type(entity['entity_type']) != 'enterprise':
        raise CoreError('enterprise_profile_invalid', 'Liên kết hồ sơ cơ sở cần được quản trị đối soát.', 409)
    if entity['archived']:
        raise CoreError('entity_archived', 'Hồ sơ cơ sở đã cất; cần đối soát trước khi dùng cho việc mới.', 409)
    return entity['id']


class EnterpriseProfileService:
    def __init__(self, repo, core):
        self.repo, self.core = repo, core

    def _descriptor(self, db, account, enterprise):
        member = self.core.membership(account, enterprise, db)
        row = db.execute('SELECT entity_id FROM core_v1_enterprise_profiles WHERE enterprise_id=?',
                         (enterprise,)).fetchone()
        result = {'schema_version': 'registered-enterprise-profile/1', 'enterprise_id': enterprise,
                  'display_name': member['enterprise_name'], 'entity_id': None, 'entity': None,
                  'state': 'not_initialized', 'can_initialize': member['role'] == 'owner', 'candidates': []}
        if row is not None:
            result['can_initialize'] = False
            try:
                entity = self.core._entity(db, enterprise, row['entity_id'])
                self.core._require(db, account, enterprise, entity['id'])
            except CoreError as exc:
                if exc.status_code not in (403, 404):
                    raise
                result['state'] = 'unavailable'
                return result
            if canonical_entity_type(entity['entity_type']) != 'enterprise':
                raise CoreError('enterprise_profile_invalid', 'Liên kết hồ sơ cơ sở cần được quản trị đối soát.', 409)
            result.update(state='ready', entity_id=entity['id'],
                          entity=self.core._visible_entity(db, account, enterprise, entity))
            return result
        if member['role'] != 'owner':
            result.update(state='unavailable', can_initialize=False)
            return result
        for row in db.execute('SELECT * FROM v03_entities WHERE enterprise_id=? ORDER BY created_at,id', (enterprise,)):
            if canonical_entity_type(row['entity_type']) != 'enterprise':
                continue
            if self.repo.entity_lifecycle(db, enterprise, row['id'])['archived']:
                continue
            try:
                self.core._require(db, account, enterprise, row['id'])
            except CoreError as exc:
                if exc.status_code != 403:
                    raise
                continue
            entity = self.core._visible_entity(db, account, enterprise, dict(row))
            result['candidates'].append({key: entity[key] for key in ('id', 'name', 'version')})
        return result

    def get(self, account, enterprise):
        with self.repo.connection() as db:
            return self._descriptor(db, account, enterprise)

    def open(self, account, enterprise, operation_id, *, existing_entity_id=None):
        request = {'existing_entity_id': existing_entity_id}
        with self.repo.connection(write=True) as db:
            self.core.membership(account, enterprise, db)
            fingerprint, prior = self.repo._operation(db, account, enterprise, 'core_open_enterprise_profile', operation_id, request)
            if prior is not None:
                # Exact committed command needs current READ, not today's WRITE.
                self.core._entity(db, enterprise, prior['entity_id'])
                self.core._require(db, account, enterprise, prior['entity_id'])
                return {**self._descriptor(db, account, enterprise), 'command_receipt': prior}
            member = self.core.membership(account, enterprise, db, owner=True)
            linked = db.execute('SELECT entity_id FROM core_v1_enterprise_profiles WHERE enterprise_id=?',
                                (enterprise,)).fetchone()
            created = False
            if linked is not None:
                entity_id = linked['entity_id']
                self.core._require(db, account, enterprise, entity_id)
                entity = self.core._entity(db, enterprise, entity_id)
                if existing_entity_id is not None and existing_entity_id != entity_id:
                    raise CoreError('enterprise_profile_already_linked', 'Doanh nghiệp đã có hồ sơ chuẩn liên kết. Chưa hỗ trợ tự đổi hoặc gộp liên kết.', 409)
                if entity['archived']:
                    raise CoreError('entity_archived', 'Hồ sơ cơ sở đã cất; cần đối soát trước khi sửa.', 409)
            else:
                if existing_entity_id is not None:
                    entity = self.core._entity(db, enterprise, existing_entity_id)
                    self.core._require(db, account, enterprise, existing_entity_id)
                    if canonical_entity_type(entity['entity_type']) != 'enterprise':
                        raise CoreError('invalid_enterprise_entity', 'Chỉ liên kết hồ sơ cơ sở, không dùng hồ sơ sản phẩm.', 409)
                    if entity['archived']:
                        raise CoreError('entity_archived', 'Hồ sơ đã cất; cần chọn hồ sơ cơ sở đang dùng.', 409)
                    entity_id = entity['id']
                else:
                    if self._descriptor(db, account, enterprise)['candidates']:
                        raise CoreError('enterprise_profile_selection_required', 'Đã có hồ sơ cơ sở. Chị chọn đúng hồ sơ để liên kết; chưa tạo hồ sơ trùng.', 409)
                    require_valid_entity_name(member['enterprise_name'], 'enterprise')
                    entity_id, stamp = new_id('entity'), now_iso()
                    db.execute('INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) '
                               "VALUES(?,?,'enterprise',?,NULL,?,?)",
                               (entity_id, enterprise, member['enterprise_name'], account, stamp))
                    self.repo._remember_name(db, entity_id, member['enterprise_name'])
                    self.repo._advance_revision(db, enterprise, account, [{'entity_id': entity_id, 'field': '__created__'}])
                    created = True
                self.core._resource(db, enterprise, entity_id, create=True)
                db.execute('INSERT INTO core_v1_enterprise_profiles(enterprise_id,entity_id,linked_by,linked_at) VALUES(?,?,?,?)',
                           (enterprise, entity_id, account, now_iso()))
            receipt = {'schema_version': 'enterprise-profile-link-receipt/1', 'enterprise_id': enterprise,
                       'entity_id': entity_id, 'operation_id': operation_id, 'created': created,
                       'facts_confirmed': False}
            self.repo._save_operation(db, account, enterprise, 'core_open_enterprise_profile', operation_id, fingerprint, receipt)
            return {**self._descriptor(db, account, enterprise), 'command_receipt': receipt}
