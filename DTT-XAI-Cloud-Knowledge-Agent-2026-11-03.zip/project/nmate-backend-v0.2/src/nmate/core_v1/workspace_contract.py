"""Versioned query contracts shared by HTTP/MCP, never mutation authority."""
from __future__ import annotations

import copy

from nmate.v03.core import CoreError
from nmate.v03.field_registry import REGISTRY_VERSION, field_contract
from nmate.v03.intent_plan import compile_dialogue_plan


def current_product_reference(context, product):
    """Exact selected ID only; never resolve a display name from another item."""
    selected = (product or {}).get("id") or (product or {}).get("entity_id")
    entity = next((item for item in (context or {}).get("entities", []) if item.get("id") == selected), None)
    return {key: copy.deepcopy(entity[key]) for key in ("id", "name", "version", "entity_type") if key in entity} if entity else {}


def project_intake_plan(intake, *, values=None, context_revision=None, current_product=None):
    """Additive read projection; never persist a recomputed historical plan."""
    value = copy.deepcopy(intake)
    value["intent_plan"] = compile_dialogue_plan(value.get("intent") or {}, value.get("text") or "",
                                                 values=values, product=current_product if context_revision is not None else value.get("product"))
    value["intent_plan_basis"] = {"kind": "current_read_projection" if context_revision is not None else "prepared_read_projection", "context_revision": context_revision,
                                  "does_not_rewrite_saved_analysis": True}
    return value


def workspace_interaction(resource, *, kind, role, conversation=None):
    """Shared current-action policy for new and compatible legacy READ DTOs."""
    conversation = conversation or {}
    review = resource.get("review") or {}
    pending = list(review.get("pending_candidate_ids") or [])
    held = bool(review.get("migration_required") or review.get("lifecycle") == "review_required")
    error = conversation.get("operation_error") or resource.get("error")
    status = resource.get("status", "unknown")
    running = bool(conversation.get("pending_operation_id") or status in {"preparing", "queued", "running"}) and not error
    operation = {"state": "failed" if error or status == "failed" else "processing" if running else "idle",
                 "processing": running, "operation_id": conversation.get("pending_operation_id") or resource.get("research_operation_id")}
    receipt = resource.get("latest_confirmation_receipt") or {}
    allowed = []
    if kind == "intake" and pending and not held and role == "owner" and not running:
        allowed = ["confirm_selected", "dismiss_selected", "review_pending"]
    if held:
        action = {"kind": "review_required", "label_vi": "Đối chiếu nháp trước khi lưu"}
    elif running:
        action = {"kind": "read_status", "label_vi": "Đọc trạng thái lượt đã gửi"}
    elif error or status == "failed":
        action = {"kind": "read_error", "label_vi": "Xem phần chưa hoàn tất; không tự gửi lại"}
    elif kind == "intake" and pending:
        action = {"kind": "review_pending", "label_vi": f"Kiểm tra {len(pending)} dữ kiện còn lại"}
    elif resource.get("binding_warning"):
        action = {"kind": "select_product", "label_vi": "Chọn đúng sản phẩm để tiếp tục"}
    elif resource.get("is_historical") or status == "needs_revalidation":
        action = {"kind": "review_current_basis", "label_vi": "Rà lại căn cứ hiện hành"}
    else:
        action = {"kind": "continue_chat", "label_vi": "Tiếp tục trao đổi"}
    return {"review": {"pending_candidate_ids": pending, "pending_count": len(pending), "held": held},
            "operation": operation, "receipt_ref": receipt.get("receipt_id"),
            "primary_action": action, "allowed_actions": allowed}


def resource_workspace_contract(repo, account, enterprise, resource, db, *, kind, conversation=None):
    """One scoped read model after each domain's existing READ authorization.

    This DTO is a UI projection, never a bearer token or mutation authority.
    Current SSOT/review revisions, historical context and operation/receipt
    remain separate even when they are returned in the same HTTP/MCP response.
    """
    if kind not in {"intake", "research", "policy"}:
        raise CoreError("invalid_workspace_kind", "Loại công việc chưa được hỗ trợ.")
    if resource.get("enterprise_id", enterprise) != enterprise or resource.get("owner_id", account) != account:
        raise CoreError("forbidden", "Không tìm thấy công việc được phép xem.", 403)
    membership = repo.get_membership(account, enterprise, db)
    conversation = conversation or {}
    if (conversation.get("enterprise_id", enterprise) != enterprise or
            conversation.get("owner_id", account) != account):
        raise CoreError("forbidden", "Không tìm thấy cuộc trao đổi được phép xem.", 403)
    review = resource.get("review") or {}
    current_revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise,)).fetchone()[0]
    context = resource.get("context") or resource.get("saved_context") or {}
    ids = {(item.get("id") or item.get("entity_id")) for item in context.get("entities", []) if isinstance(item, dict)}
    product = resource.get("product") or {}
    ids.update([product.get("id") or product.get("entity_id"), (resource.get("enterprise_entity") or {}).get("id")])
    ids = sorted(value for value in ids if isinstance(value, str) and value and not value.startswith("new_"))
    for entity in ids:
        row = db.execute("SELECT enterprise_id FROM v03_entities WHERE id=?", (entity,)).fetchone()
        if row is None or row[0] != enterprise:
            raise CoreError("forbidden", "Căn cứ hồ sơ không thuộc công việc được phép xem.", 403)
    scope = {"account_id": account, "enterprise_id": enterprise, "conversation_id": conversation.get("id") or resource.get("conversation_id"),
             "workspace_id": resource["id"], "resource_kind": kind, "entity_ids": ids,
             "market_code": (resource.get("market") or {}).get("code")}
    interaction = workspace_interaction(resource, kind=kind, role=membership["role"], conversation=conversation)
    plan = resource.get("intent_plan") or (resource.get("research_scope") or {}).get("intent_plan")
    if kind == "intake" and not plan:
        plan = compile_dialogue_plan(resource.get("intent") or {}, resource.get("text") or "", product=product)
    fields = {item.get("field") for item in resource.get("candidates", []) if isinstance(item, dict)}
    contracts = {field: contract for field in sorted(value for value in fields if isinstance(value, str))
                 if (contract := field_contract(field)) is not None}
    return {"schema_version": "workspace-contract/1", "projection_only": True, "scope": scope,
            "revisions": {"workspace": review.get("revision", resource.get("version", 0)), "context": current_revision,
                          "saved_context": context.get("context_revision"), "conversation": conversation.get("revision", 0)},
            "binding": copy.deepcopy(resource.get("product_binding")),
            **interaction, "field_registry": {"version": REGISTRY_VERSION, "fields": contracts},
            "intent_plan": copy.deepcopy(plan), "billing": {"projection_model_calls": 0}}


