"""D05 server-local financial projections and exact-value Claude egress.

Original workbooks are parsed locally and never stored in a model payload.
Reading, confirming SSOT, authorizing egress and paying for inference are
separate permissions. This module has no provider or network dependency.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from io import BytesIO
import hashlib
import json
import re
from zipfile import ZipFile

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.field_registry import (FINANCE_METRIC_LABELS as METRIC_LABELS, FINANCE_COUNT_METRICS as COUNTS,
                                     FINANCE_NEGATIVE_METRICS as NEGATIVE_ALLOWED, FINANCE_CURRENCY_UNITS,
                                     FINANCE_PERSON_UNITS, FINANCE_DECIMAL_PATTERN, FINANCE_SCOPES)
from nmate.v04.extraction import MAX_FILE, NS, REL, _xml, normalize, parse_workbook


SCHEMA = """
CREATE TABLE IF NOT EXISTS core_finance_projections (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,resource_id TEXT NOT NULL,actor_id TEXT NOT NULL,
 metrics_json TEXT NOT NULL,metrics_hash TEXT NOT NULL,source_sha256 TEXT,created_at TEXT NOT NULL,
 FOREIGN KEY(enterprise_id,resource_id) REFERENCES core_v1_resources(enterprise_id,resource_id));
CREATE TABLE IF NOT EXISTS core_finance_egress_grants (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,projection_id TEXT NOT NULL REFERENCES core_finance_projections(id),
 resource_id TEXT NOT NULL,actor_id TEXT NOT NULL,task_id TEXT NOT NULL,purpose TEXT NOT NULL,model_profile TEXT NOT NULL,
 metric_ids_json TEXT NOT NULL,payload_json TEXT NOT NULL,payload_hash TEXT NOT NULL,
 expires_at TEXT NOT NULL,revoked_at TEXT,derivative_blocked_at TEXT,created_at TEXT NOT NULL,
 FOREIGN KEY(enterprise_id,resource_id) REFERENCES core_v1_resources(enterprise_id,resource_id));
CREATE TABLE IF NOT EXISTS core_finance_events (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,actor_id TEXT NOT NULL,event_type TEXT NOT NULL,
 resource_id TEXT NOT NULL,detail_json TEXT NOT NULL,recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS core_finance_dispatch_bindings (
 grant_id TEXT PRIMARY KEY REFERENCES core_finance_egress_grants(id),enterprise_id TEXT NOT NULL,
 operation_id TEXT NOT NULL,task_id TEXT NOT NULL,payload_hash TEXT NOT NULL,recorded_at TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS core_finance_projections_immutable BEFORE UPDATE ON core_finance_projections
 BEGIN SELECT RAISE(ABORT,'immutable financial projection'); END;
CREATE TRIGGER IF NOT EXISTS core_finance_projections_no_delete BEFORE DELETE ON core_finance_projections
 BEGIN SELECT RAISE(ABORT,'immutable financial projection'); END;
CREATE TRIGGER IF NOT EXISTS core_finance_grant_manifest_immutable BEFORE UPDATE OF
 enterprise_id,projection_id,resource_id,actor_id,task_id,purpose,model_profile,metric_ids_json,
 payload_json,payload_hash,expires_at,created_at ON core_finance_egress_grants
 BEGIN SELECT RAISE(ABORT,'immutable financial egress receipt'); END;
CREATE TRIGGER IF NOT EXISTS core_finance_egress_no_delete BEFORE DELETE ON core_finance_egress_grants
 BEGIN SELECT RAISE(ABORT,'immutable financial egress receipt'); END;
"""
METRIC_KEYS = {"metric_id", "metric_code", "value_decimal", "unit", "period_start", "period_end", "scope", "value_state"}
RAW_KEYS = {"raw_document", "document_bytes", "base64", "image", "image_url", "ocr_text", "sheet_dump",
            "data_base64", "raw_text", "filename", "file_name", "file_path", "attachments", "original_document"}


def is_financial_field(field):
    """Shared D05 classification, including qualified and legacy metric names.

    Field identity is the first dotted segment (not the final date/qualifier).
    No permission is inferred from this classifier; exact value grants remain
    authoritative at dispatch and current ACL remains authoritative on reads.
    """
    from nmate.v03.domain_validation import field_is_financial
    return field_is_financial(field)


def digest(value):
    return hashlib.sha256(json_text(value).encode()).hexdigest()


def instant(value):
    try:
        result = datetime.fromisoformat(value)
        if result.tzinfo is None:
            raise ValueError
        return result.astimezone(timezone.utc)
    except (ValueError, TypeError) as exc:
        raise CoreError("invalid_expiry", "Cần thời điểm hết hạn có múi giờ rõ ràng.") from exc


def _day(value):
    try:
        if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            raise ValueError
        return date.fromisoformat(value)
    except (ValueError, TypeError) as exc:
        raise CoreError("financial_period_required", "Chỉ tiêu cần kỳ báo cáo rõ theo ngày YYYY-MM-DD.") from exc


def _period(value):
    if not isinstance(value, str):
        raise CoreError("financial_period_required", "Excel cần kỳ báo cáo YYYY, YYYY-MM hoặc YYYY-Q1–Q4.")
    match = re.fullmatch(r"(20\d{2})(?:-(0[1-9]|1[0-2]|Q[1-4]))?", value)
    if not match:
        raise CoreError("financial_period_required", "Excel cần kỳ báo cáo YYYY, YYYY-MM hoặc YYYY-Q1–Q4.")
    year, part = int(match[1]), match[2]
    start_month = 1 if part is None else (int(part[1]) - 1) * 3 + 1 if part.startswith("Q") else int(part)
    end_month = 12 if part is None else start_month + 2 if part.startswith("Q") else start_month
    start = date(year, start_month, 1)
    # Period ends are exclusive.
    end = date(year + 1, 1, 1) if end_month == 12 else date(year, end_month + 1, 1)
    return start.isoformat(), end.isoformat()


class FinanceService:
    def __init__(self, repo, core):
        self.repo, self.core = repo, core
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)
            if getattr(repo, "managed_runtime", False):
                return
            db.executemany("INSERT OR IGNORE INTO core_v1_field_definitions VALUES(?,'finance','owner_required',1)",
                           [(key,) for key in METRIC_LABELS])

    @contextmanager
    def _connection(self, db=None, write=False):
        if db is not None:
            yield db
        else:
            with self.repo.connection(write=write) as connection:
                yield connection

    def _check(self, db, actor, enterprise, resource, metrics, egress=False):
        self.core.membership(actor, enterprise, db)
        for metric in metrics:
            code = metric["metric_code"]
            self.core._require(db, actor, enterprise, resource, "read", code)
            if not self.core.has_capability(actor, enterprise, resource, "read_finance", code, db):
                raise CoreError("financial_read_forbidden", "Chưa được cấp quyền xem các chỉ tiêu tài chính này.", 403)
            if egress and not self.core.has_capability(actor, enterprise, resource, "send_financial_metrics", code, db):
                raise CoreError("financial_egress_authority_required", "Quyền đọc hoặc xác nhận hồ sơ chưa cho phép gửi chỉ tiêu. Cần quyền gửi riêng cho đúng phạm vi.", 403)

    @staticmethod
    def _metric(value):
        if not isinstance(value, dict) or set(value) - {"metric_code", "key", "value", "value_decimal", "unit", "period_start", "period_end", "scope", "value_state"}:
            raise CoreError("invalid_financial_metric", "Chỉ nhận chỉ tiêu có cấu trúc; không nhận văn bản hoặc tài liệu gốc.")
        code = value.get("metric_code", value.get("key"))
        if code not in METRIC_LABELS:
            raise CoreError("unsupported_financial_metric", "Chỉ tiêu chưa thuộc danh sách tối thiểu được hỗ trợ.")
        start, end = _day(value.get("period_start")), _day(value.get("period_end"))
        if end <= start or (end - start).days > 3660:
            raise CoreError("invalid_financial_period", "Kỳ báo cáo phải có ngày kết thúc sau ngày bắt đầu, tối đa 10 năm.")
        unit = value.get("unit")
        if code in COUNTS:
            if unit not in FINANCE_PERSON_UNITS:
                raise CoreError("invalid_financial_unit", "Số lao động cần đơn vị người.")
            unit = "person"
        elif unit not in FINANCE_CURRENCY_UNITS:
            raise CoreError("invalid_financial_unit", "Chỉ tiêu tiền cần VND, USD, EUR hoặc JPY.")
        scope = value.get("scope", "enterprise")
        if scope not in FINANCE_SCOPES:
            raise CoreError("invalid_financial_scope", "Phạm vi báo cáo chưa được hỗ trợ.")
        state = value.get("value_state", "known")
        raw = value.get("value_decimal", value.get("value"))
        if state not in {"known", "unknown"} or (state == "unknown" and raw is not None):
            raise CoreError("invalid_financial_metric", "Trạng thái chỉ tiêu chưa hợp lệ.")
        canonical = None
        if state == "known":
            if isinstance(raw, bool) or not isinstance(raw, (str, int)) or not re.fullmatch(FINANCE_DECIMAL_PATTERN, str(raw)):
                raise CoreError("invalid_financial_number", "Giá trị cần số thập phân chính xác, không công thức hoặc dấu phân cách.")
            try:
                number = Decimal(str(raw))
            except InvalidOperation as exc:
                raise CoreError("invalid_financial_number", "Giá trị chỉ tiêu không hợp lệ.") from exc
            if not number.is_finite() or (number < 0 and code not in NEGATIVE_ALLOWED):
                raise CoreError("invalid_financial_number", "Chỉ tiêu này không được là số âm hoặc không hữu hạn.")
            if code in COUNTS and (number != number.to_integral_value() or number > 1_000_000):
                raise CoreError("invalid_financial_number", "Số lao động cần số nguyên không âm trong phạm vi hỗ trợ.")
            canonical = format(number, "f")
            if "." in canonical:
                canonical = canonical.rstrip("0").rstrip(".")
            if canonical == "-0":
                canonical = "0"
        return {"metric_id": new_id("metric"), "metric_code": code, "value_decimal": canonical,
                "unit": unit, "period_start": start.isoformat(), "period_end": end.isoformat(),
                "scope": scope, "value_state": state}

    def _event(self, db, enterprise, actor, kind, resource, detail):
        db.execute("INSERT INTO core_finance_events VALUES(?,?,?,?,?,?,?)", (new_id("finance_event"), enterprise,
                   actor, kind, resource, json_text(detail), now_iso()))

    def stage_metrics(self, account_id, enterprise_id, resource_id, metrics, operation_id, source_sha256=None):
        if not isinstance(metrics, list) or not 1 <= len(metrics) <= 20:
            raise CoreError("financial_metric_limit", "Mỗi lần chỉ nhận từ 1 đến 20 chỉ tiêu tối thiểu.")
        # Validation does not persist raw strings, filenames, worksheet dumps or files.
        normalized = [self._metric(value) for value in metrics]
        keys = [(m["metric_code"], m["period_start"], m["period_end"], m["scope"]) for m in normalized]
        if len(keys) != len(set(keys)):
            raise CoreError("duplicate_financial_metric", "Trùng chỉ tiêu trong cùng kỳ và phạm vi báo cáo.")
        if source_sha256 is not None and (not isinstance(source_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", source_sha256)):
            raise CoreError("invalid_source_hash", "Mã kiểm tra tài liệu không hợp lệ.")
        with self.repo.connection(write=True) as db:
            self.core.membership(account_id, enterprise_id, db)
            self._check(db, account_id, enterprise_id, resource_id, normalized)
            # Only existing resources can be associated; entity registration is additive.
            self.core._resource(db, enterprise_id, resource_id, create=True)
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "finance_stage", operation_id,
                                                         [resource_id, metrics, source_sha256])
            if previous is not None:
                return previous
            projection_id = new_id("financial_projection")
            db.execute("INSERT INTO core_finance_projections VALUES(?,?,?,?,?,?,?,?)", (projection_id, enterprise_id,
                       resource_id, account_id, json_text(normalized), digest(normalized), source_sha256, now_iso()))
            result = {"projection_id": projection_id, "resource_id": resource_id, "metrics": normalized,
                      "projection_hash": digest(normalized), "status": "working_metrics", "ssot_confirmed": False,
                      "original_sent": False, "model_called": False,
                      "message": "Đã xử lý tại máy chủ. Chưa gửi Claude và chưa cập nhật hồ sơ chuẩn."}
            self._event(db, enterprise_id, account_id, "metrics_staged", resource_id,
                        {"projection_id": projection_id, "metric_count": len(normalized), "source_sha256": source_sha256})
            self.repo._save_operation(db, account_id, enterprise_id, "finance_stage", operation_id, request_hash, result)
            return result

    def _projection(self, db, actor, enterprise, projection_id):
        row = db.execute("SELECT * FROM core_finance_projections WHERE id=? AND enterprise_id=?", (projection_id, enterprise)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy bộ chỉ tiêu được phép xem.", 404)
        metrics = json.loads(row["metrics_json"])
        self._check(db, actor, enterprise, row["resource_id"], metrics)
        return dict(row), metrics

    def preview_metrics(self, account_id, enterprise_id, projection_id):
        with self.repo.connection() as db:
            row, metrics = self._projection(db, account_id, enterprise_id, projection_id)
            return {"projection_id": projection_id, "projection_hash": row["metrics_hash"], "resource_id": row["resource_id"],
                    "metrics": [{**metric, "label_vi": METRIC_LABELS[metric["metric_code"]]} for metric in metrics],
                    "payload": {"financial_metrics": metrics}, "ssot_confirmed": False,
                    "message": "Chỉ các chỉ tiêu đã chọn mới được gửi; tài liệu gốc ở lại máy chủ."}

    def grant_egress(self, account_id, enterprise_id, projection_id, operation_id, task_id, purpose,
                     model_profile, expires_at, metric_ids=None):
        for value in (task_id, purpose):
            if not isinstance(value, str) or not 1 <= len(value) <= 128:
                raise CoreError("invalid_financial_scope", "Cần tác vụ và mục đích cụ thể.")
        if model_profile not in {"standard/1", "complex/1"}:
            raise CoreError("invalid_financial_model", "Chỉ cấp quyền cho đúng phiên bản cấu hình Claude đang hỗ trợ.")
        expiry = instant(expires_at)
        if expiry <= datetime.now(timezone.utc):
            raise CoreError("invalid_expiry", "Quyền gửi phải còn hiệu lực.")
        with self.repo.connection(write=True) as db:
            row, metrics = self._projection(db, account_id, enterprise_id, projection_id)
            if metric_ids is None:
                selected = metrics
            else:
                if not isinstance(metric_ids, list) or not metric_ids or len(metric_ids) != len(set(metric_ids)):
                    raise CoreError("invalid_financial_selection", "Cần chọn đúng các chỉ tiêu tối thiểu, không trùng.")
                selected = [m for m in metrics if m["metric_id"] in metric_ids]
                if len(selected) != len(metric_ids):
                    raise CoreError("invalid_financial_selection", "Chỉ tiêu không thuộc bản xem trước này.")
            if not selected or any(m["value_state"] != "known" for m in selected):
                raise CoreError("unknown_financial_metric", "Chỉ tiêu chưa rõ không được gửi như một giá trị đã biết.")
            self._check(db, account_id, enterprise_id, row["resource_id"], selected, egress=True)
            payload = {"financial_metrics": selected}
            request = [projection_id, task_id, purpose, model_profile, expiry.isoformat(), [m["metric_id"] for m in selected]]
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "finance_egress", operation_id, request)
            if previous is not None:
                return previous
            grant_id = new_id("financial_egress")
            db.execute("INSERT INTO core_finance_egress_grants VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (grant_id, enterprise_id,
                       projection_id, row["resource_id"], account_id, task_id, purpose, model_profile,
                       json_text([m["metric_id"] for m in selected]), json_text(payload), digest(payload), expiry.isoformat(), None, None, now_iso()))
            result = {"grant_id": grant_id, "projection_id": projection_id, "resource_id": row["resource_id"],
                      "payload": payload, "payload_hash": digest(payload), "task_id": task_id, "purpose": purpose,
                      "model_profile": model_profile, "expires_at": expiry.isoformat(), "original_sent": False,
                      "message": "Đã cho phép đúng tập chỉ tiêu này. Quyền này không cấp ngân sách hoặc xác nhận hồ sơ chuẩn."}
            self._event(db, enterprise_id, account_id, "egress_authorized", row["resource_id"],
                        {"grant_id": grant_id, "payload_hash": digest(payload), "task_id": task_id})
            self.repo._save_operation(db, account_id, enterprise_id, "finance_egress", operation_id, request_hash, result)
            return result

    @staticmethod
    def _assert_no_raw(payload):
        def walk(value, inside_metrics=False):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key.casefold() in RAW_KEYS:
                        raise CoreError("financial_original_blocked", "Không gửi tài liệu gốc, ảnh/OCR hoặc bảng tính qua mô hình.", 409)
                    if not inside_metrics and ((key != "financial_metrics" and is_financial_field(key))
                                               or (key in {"field", "metric_code"} and is_financial_field(child))):
                        raise CoreError("financial_unsealed_payload", "Chỉ tiêu tài chính phải nằm trong tập có cấu trúc đã cho phép.", 409)
                    walk(child, inside_metrics or key == "financial_metrics")
            elif isinstance(value, list):
                for child in value:
                    walk(child, inside_metrics)
        if not isinstance(payload, dict):
            raise CoreError("invalid_financial_payload", "Đầu vào mô hình cần đúng cấu trúc.")
        walk(payload)

    def verify_dispatch(self, account_id, enterprise_id, operation, task, purpose, profile, payload, grant_ids, db=None):
        self._assert_no_raw(payload)
        financial = payload.get("financial_metrics")
        if financial is None:
            if grant_ids:
                raise CoreError("financial_payload_mismatch", "Quyền gửi không khớp nội dung chỉ tiêu.", 409)
            with self._connection(db) as connection:
                self.core.membership(account_id, enterprise_id, connection)
            return {"allowed": True, "financial": False}
        if not isinstance(financial, list) or not financial or len(financial) > 20 or not isinstance(grant_ids, list) or not grant_ids or any(not isinstance(g, str) for g in grant_ids) or len(set(grant_ids)) != len(grant_ids):
            raise CoreError("financial_egress_required", "Cần tập chỉ tiêu tối thiểu và quyền gửi chính xác.", 409)
        if any(not isinstance(m, dict) or set(m) != METRIC_KEYS for m in financial):
            raise CoreError("financial_payload_mismatch", "Tập chỉ tiêu chứa trường thừa hoặc dữ liệu chưa được phép.", 409)
        with self._connection(db) as connection:
            self.core.membership(account_id, enterprise_id, connection)
            authorized = []
            for grant_id in grant_ids:
                row = connection.execute("SELECT * FROM core_finance_egress_grants WHERE id=? AND enterprise_id=? AND actor_id=?",
                                         (grant_id, enterprise_id, account_id)).fetchone()
                if row is None or row["revoked_at"] or row["derivative_blocked_at"] or instant(row["expires_at"]) <= datetime.now(timezone.utc):
                    raise CoreError("financial_egress_unavailable", "Quyền gửi hết hạn hoặc đã thu hồi. Chưa gửi Claude.", 409)
                if (row["task_id"], row["purpose"], row["model_profile"]) != (task, purpose, profile):
                    raise CoreError("financial_egress_scope_mismatch", "Quyền gửi không cho phép tác vụ, mục đích hoặc mô hình này.", 409)
                metrics = json.loads(row["payload_json"])["financial_metrics"]
                self._check(connection, account_id, enterprise_id, row["resource_id"], metrics, egress=True)
                projection, _ = self._projection(connection, account_id, enterprise_id, row["projection_id"])
                if digest(json.loads(projection["metrics_json"])) != projection["metrics_hash"]:
                    raise CoreError("financial_projection_changed", "Bản chỉ tiêu không còn khớp dấu kiểm tra.", 409)
                if digest({"financial_metrics": metrics}) != row["payload_hash"]:
                    raise CoreError("financial_grant_changed", "Quyền gửi không còn khớp nội dung đã xem.", 409)
                authorized.extend(metrics)
            if len({m["metric_id"] for m in authorized}) != len(authorized) or digest(authorized) != digest(financial):
                raise CoreError("financial_payload_mismatch", "Giá trị/kỳ/đơn vị hoặc thứ tự chỉ tiêu khác bản đã cho phép.", 409)
            # The Gateway passes its existing final pre-dispatch write transaction.
            # Seal the grant to that operation there; ordinary preview validation
            # has no mutation and cannot consume a grant by accident.
            if db is not None:
                for grant_id in grant_ids:
                    old = connection.execute("SELECT * FROM core_finance_dispatch_bindings WHERE grant_id=?", (grant_id,)).fetchone()
                    if old and (old["enterprise_id"], old["operation_id"], old["task_id"], old["payload_hash"]) != (enterprise_id, operation, task, digest(financial)):
                        raise CoreError("financial_grant_already_bound", "Quyền gửi đã gắn với một lượt cụ thể; không dùng lại cho lượt khác.", 409)
                    if not old:
                        connection.execute("INSERT INTO core_finance_dispatch_bindings VALUES(?,?,?,?,?,?)",
                                           (grant_id, enterprise_id, operation, task, digest(financial), now_iso()))
            return {"allowed": True, "financial": True, "payload_hash": digest({"financial_metrics": financial})}

    def verify_publication(self, account_id, enterprise_id, grant_ids, db=None):
        with self._connection(db) as connection:
            self.core.membership(account_id, enterprise_id, connection)
            for grant_id in grant_ids:
                row = connection.execute("SELECT * FROM core_finance_egress_grants WHERE id=? AND enterprise_id=? AND actor_id=?",
                                         (grant_id, enterprise_id, account_id)).fetchone()
                # Expiry/revoking egress alone does not retroactively prevent reading
                # a lawfully produced result. ACL/derivative blocks still apply now.
                if row is None or row["derivative_blocked_at"]:
                    raise CoreError("financial_derivative_unavailable", "Kết quả có chỉ tiêu bị hạn chế sử dụng hoặc không đúng quyền.", 403)
                self._check(connection, account_id, enterprise_id, row["resource_id"], json.loads(row["payload_json"])["financial_metrics"])
            return {"allowed": True}

    def revoke_egress(self, account_id, enterprise_id, grant_id, block_derivatives=False):
        with self.repo.connection(write=True) as db:
            row = db.execute("SELECT * FROM core_finance_egress_grants WHERE id=? AND enterprise_id=?", (grant_id, enterprise_id)).fetchone()
            if row is None:
                raise CoreError("not_found", "Không tìm thấy quyền gửi chỉ tiêu.", 404)
            self.core.membership(account_id, enterprise_id, db)
            resource = self.core._resource(db, enterprise_id, row["resource_id"])
            if row["actor_id"] != account_id and (not resource or resource["created_by"] != account_id):
                raise CoreError("forbidden", "Không được thu hồi quyền của tài nguyên khác.", 403)
            db.execute("UPDATE core_finance_egress_grants SET revoked_at=COALESCE(revoked_at,?),derivative_blocked_at="
                       "CASE WHEN ? THEN COALESCE(derivative_blocked_at,?) ELSE derivative_blocked_at END WHERE id=?",
                       (now_iso(), bool(block_derivatives), now_iso(), grant_id))
            self._event(db, enterprise_id, account_id, "egress_revoked", row["resource_id"],
                        {"grant_id": grant_id, "block_derivatives": bool(block_derivatives)})
            return {"grant_id": grant_id, "status": "revoked", "derivatives_blocked": bool(block_derivatives)}

    def parse_excel(self, account_id, enterprise_id, resource_id, raw, operation_id):
        """Read a bounded value-only key/value .xlsx template entirely locally."""
        if not isinstance(raw, bytes) or not raw or len(raw) > MAX_FILE:
            raise CoreError("financial_file_limit", "Excel cần có nội dung và không vượt 5 MB.")
        with self.repo.connection() as db:
            self.core._require(db, account_id, enterprise_id, resource_id)
            if not self.core.has_capability(account_id, enterprise_id, resource_id, "read_finance", db=db):
                raise CoreError("financial_read_forbidden", "Chưa được cấp quyền xử lý tài chính trong hồ sơ này.", 403)
        # Reuse existing bounded ZIP/XML security checks, never its float conversion.
        parse_workbook(raw)
        parsed = []
        aliases = {"doanh thu": "revenue", "doanh thu nam": "annual_revenue", "so lao dong": "employee_count",
                   "so nhan vien": "employee_count", "chi phi": "cost", "tong tai san": "assets", "loi nhuan": "profit"}
        with ZipFile(BytesIO(raw)) as archive:
            strings = []
            if "xl/sharedStrings.xml" in archive.namelist():
                strings = ["".join(t.text or "" for t in item.iter("{" + NS["s"] + "}t")) for item in _xml(archive.read("xl/sharedStrings.xml"))]
            rels = {item.get("Id"): item.get("Target", "") for item in _xml(archive.read("xl/_rels/workbook.xml.rels"))}
            sheets = _xml(archive.read("xl/workbook.xml")).findall("s:sheets/s:sheet", NS)
            for sheet in sheets:
                if sheet.get("state", "visible") != "visible":
                    continue
                target = rels.get(sheet.get("{" + REL + "}id"), "")
                path = target.lstrip("/") if target.startswith("/") else "xl/" + target
                rows = []
                for row in _xml(archive.read(path)).findall("s:sheetData/s:row", NS):
                    cells = {}
                    for cell in row.findall("s:c", NS):
                        value = cell.findtext("s:v", default="", namespaces=NS)
                        kind = cell.get("t")
                        if kind == "s":
                            value = strings[int(value)]
                        elif kind == "inlineStr":
                            value = "".join(t.text or "" for t in cell.findall(".//s:t", NS))
                        elif kind in {"b", "e"}:
                            value = ""
                        cells[re.sub(r"\d", "", cell.get("r", ""))] = value.strip()
                    if any(cells.values()):
                        rows.append(cells)
                if not rows:
                    continue
                headers = {normalize(value): key for key, value in rows[0].items()}
                def column(*names):
                    return next((headers[name] for name in names if name in headers), None)
                field_col, value_col = column("truong", "field"), column("gia tri", "value")
                unit_col, period_col = column("don vi", "unit"), column("ky", "period")
                if not field_col or not value_col or not unit_col or not period_col:
                    continue
                for row in rows[1:]:
                    raw_code = row.get(field_col, "")
                    code = raw_code if raw_code in METRIC_LABELS else aliases.get(normalize(raw_code))
                    if not code:
                        continue
                    start, end = _period(row.get(period_col))
                    parsed.append({"metric_code": code, "value": row.get(value_col), "unit": row.get(unit_col),
                                   "period_start": start, "period_end": end, "scope": "enterprise"})
        if not parsed:
            raise CoreError("financial_template_required", "Chưa có chỉ tiêu được hỗ trợ. Dùng mẫu Trường / Giá trị / Đơn vị / Kỳ; chưa gửi Claude.")
        return self.stage_metrics(account_id, enterprise_id, resource_id, parsed, operation_id,
                                  source_sha256=hashlib.sha256(raw).hexdigest())
