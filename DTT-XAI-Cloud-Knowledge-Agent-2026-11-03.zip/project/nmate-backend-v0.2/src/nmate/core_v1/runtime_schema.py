"""DF-041: runtime compatibility is a read; initialization is an operator step.

The contract contains public schema and seed identities only. It does not pin
enterprise data, a source's current version/freshness or policy publications.
Constructors used by fixtures/operators retain their explicit bootstrap mode;
the actual local runtime enters ``managed_runtime`` only around its factory.
"""
from __future__ import annotations

from contextlib import closing, contextmanager
from contextvars import ContextVar
import hashlib
import json
from pathlib import Path
import re
import sqlite3


_MANAGED = ContextVar("nmate_managed_runtime", default=False)
CONTRACT_PATH = Path(__file__).with_name("data") / "runtime_schema_20261026_v17.json"


class RuntimeSchemaError(RuntimeError):
    """Readiness failed before any constructor or automatic repair ran."""


def is_managed_runtime():
    return _MANAGED.get()


@contextmanager
def managed_runtime():
    token = _MANAGED.set(True)
    try:
        yield
    finally:
        _MANAGED.reset(token)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf8")).hexdigest()


def quote_identifier(name):
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise RuntimeSchemaError("Định danh trong hợp đồng schema không hợp lệ.")
    return '"' + name + '"'


def schema_objects(db):
    return [{"type": row[0], "name": row[1], "table": row[2], "sql": row[3]}
            for row in db.execute("SELECT type,name,tbl_name,sql FROM sqlite_master "
                                  "WHERE name NOT LIKE 'sqlite_%' AND sql IS NOT NULL ORDER BY type,name")]


def read_runtime_contract(path=None):
    try:
        contract = json.loads((Path(path) if path else CONTRACT_PATH).read_text(encoding="utf8"))
    except (OSError, ValueError) as exc:
        raise RuntimeSchemaError("Không đọc được hợp đồng schema của bản phát hành; chưa mở runtime.") from exc
    if contract.get("schema_version") != "runtime-schema-contract/1":
        raise RuntimeSchemaError("Phiên bản hợp đồng schema chưa được hỗ trợ.")
    return contract


def open_readonly(path):
    path = Path(path).expanduser().resolve()
    if not path.is_file():
        raise RuntimeSchemaError(
            "Chưa có DB đã khởi tạo. Hãy dùng công cụ quản trị schema `init` với DB mới; "
            "`python -m nmate.core_v1.schema_lifecycle init --database <DB mới>`. "
            "Runtime không tự tạo hay khởi tạo lại hồ sơ.")
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=15)
    db.execute("PRAGMA query_only=ON")
    db.execute("PRAGMA foreign_keys=ON")
    return db


def verify_runtime_database(path, *, contract_path=None):
    """Verify known DDL and immutable managed inputs, without repairing them."""
    contract = read_runtime_contract(contract_path)
    try:
        with closing(open_readonly(path)) as db:
            db.execute("BEGIN")
            objects = schema_objects(db)
            actual = {(item["type"], item["name"]): item for item in objects}
            required = {(item["type"], item["name"]): item for item in contract["required_objects"]}
            optional = {(item["type"], item["name"]): item for item in contract["optional_objects"]}
            missing = sorted(set(required) - set(actual))
            unexpected = sorted(set(actual) - set(required) - set(optional))
            changed = sorted(key for key in actual.keys() & (required.keys() | optional.keys())
                             if actual[key] != (required.get(key) or optional[key]))
            if missing or unexpected or changed:
                raise RuntimeSchemaError(
                    "DB thiếu hoặc khác schema của bản chạy này. Cần lập kế hoạch migration quản trị "
                    "và backup; runtime đã dừng trước khi sửa dữ liệu.")
            for rule in contract["required_seeds"]:
                table = quote_identifier(rule["table"])
                columns = ",".join(quote_identifier(column) for column in rule["columns"])
                condition = " AND ".join(quote_identifier(key) + "=?" for key in rule["keys"])
                for expected in rule["required_rows"]:
                    rows = db.execute(f"SELECT {columns} FROM {table} WHERE {condition}", expected["key"])
                    if not any(digest(list(row)) == expected["sha256"] for row in rows):
                        raise RuntimeSchemaError(
                            "Thiếu hoặc khác dữ liệu nguồn/registry đã khởi tạo. Cần kiểm tra bằng công cụ "
                            "quản trị; runtime không tự cài lại hay thay nguồn đã lưu.")
            if db.execute("PRAGMA quick_check").fetchone()[0] != "ok" or db.execute("PRAGMA foreign_key_check").fetchone():
                raise RuntimeSchemaError("DB chưa đạt kiểm tra toàn vẹn; cần đối soát quản trị trước khi chạy.")
            return {"schema_version": "runtime-schema-readiness/1", "ready": True,
                    "contract_version": contract["version"], "contract_sha256": digest(contract),
                    "schema_sha256": digest(objects),
                    "required_table_count": sum(item["type"] == "table" for item in required.values()),
                    "present_table_count": sum(item["type"] == "table" for item in objects),
                    "required_seed_count": sum(len(rule["required_rows"]) for rule in contract["required_seeds"]),
                    "writes": 0, "provider_calls": 0}
    except sqlite3.DatabaseError as exc:
        raise RuntimeSchemaError("Không đọc được DB để kiểm schema; chưa khởi tạo hay sửa dữ liệu.") from exc
