"""Explicit collaboration over the existing canonical v03 fact store.

Membership never shares a resource. All business-fact decisions require an
active owner; staff can only submit immutable proposals in an explicit scope.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import json

from nmate.v03.core import CoreError, causal_fact_rows, json_text, new_id, now_iso
from nmate.v03.field_scope import FIELD_ENTITY_TYPES, canonical_entity_type, field_is_in_scope, scope_contract, scope_issue
from nmate.v03.domain_validation import FINANCIAL_FIELD_BASES, field_is_financial, validate_field_value
from .enterprise_profile import SCHEMA as ENTERPRISE_PROFILE_SCHEMA


SCHEMA = """
CREATE UNIQUE INDEX IF NOT EXISTS v03_entities_enterprise_id ON v03_entities(enterprise_id,id);
CREATE TABLE IF NOT EXISTS core_v1_resources (
 enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id), resource_id TEXT NOT NULL,
 resource_type TEXT NOT NULL, created_by TEXT NOT NULL REFERENCES v03_accounts(id),
 acl_revision INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,resource_id));
CREATE TABLE IF NOT EXISTS core_v1_field_definitions (
 field_key TEXT PRIMARY KEY,sensitivity TEXT NOT NULL CHECK(sensitivity IN ('business','finance','restricted')),
 confirmation_policy TEXT NOT NULL CHECK(confirmation_policy='owner_required'),schema_version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS core_v1_egress_authorities (
 enterprise_id TEXT NOT NULL,resource_id TEXT NOT NULL,account_id TEXT NOT NULL REFERENCES v03_accounts(id),
 field_key TEXT NOT NULL,granted_by TEXT NOT NULL REFERENCES v03_accounts(id),granted_at TEXT NOT NULL,revoked_at TEXT,
 PRIMARY KEY(enterprise_id,resource_id,account_id,field_key),
 FOREIGN KEY(enterprise_id,resource_id) REFERENCES core_v1_resources(enterprise_id,resource_id));
CREATE TABLE IF NOT EXISTS core_v1_grants (
 enterprise_id TEXT NOT NULL,resource_id TEXT NOT NULL,account_id TEXT NOT NULL REFERENCES v03_accounts(id),
 capability TEXT NOT NULL CHECK(capability IN ('read','propose_fact','read_finance')),
 field_key TEXT NOT NULL, granted_by TEXT NOT NULL REFERENCES v03_accounts(id),
 granted_at TEXT NOT NULL,revoked_at TEXT,
 PRIMARY KEY(enterprise_id,resource_id,account_id,capability,field_key),
 FOREIGN KEY(enterprise_id,resource_id) REFERENCES core_v1_resources(enterprise_id,resource_id));
CREATE TABLE IF NOT EXISTS core_v1_acl_events (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,resource_id TEXT,actor_id TEXT NOT NULL,
 event_type TEXT NOT NULL,payload_json TEXT NOT NULL,recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS core_v1_observations (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,entity_id TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES v03_accounts(id),payload_json TEXT NOT NULL,payload_hash TEXT NOT NULL,
 source_json TEXT NOT NULL,recorded_at TEXT NOT NULL,
 FOREIGN KEY(enterprise_id,entity_id) REFERENCES v03_entities(enterprise_id,id));
CREATE TABLE IF NOT EXISTS core_v1_proposals (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,entity_id TEXT NOT NULL,
 observation_id TEXT NOT NULL REFERENCES core_v1_observations(id),actor_id TEXT NOT NULL,
 facts_json TEXT NOT NULL,payload_hash TEXT NOT NULL,expected_version INTEGER NOT NULL,
 field_versions_json TEXT NOT NULL,context_revision INTEGER NOT NULL,recorded_at TEXT NOT NULL,
 FOREIGN KEY(enterprise_id,entity_id) REFERENCES v03_entities(enterprise_id,id));
CREATE TABLE IF NOT EXISTS core_v1_decisions (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,proposal_id TEXT NOT NULL UNIQUE REFERENCES core_v1_proposals(id),
 actor_id TEXT NOT NULL,action TEXT NOT NULL CHECK(action IN ('confirmed','rejected')),
 reason TEXT NOT NULL,result_json TEXT NOT NULL,recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS core_v1_context_snapshots (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),account_id TEXT NOT NULL,
 payload_json TEXT NOT NULL,payload_hash TEXT NOT NULL,refs_json TEXT NOT NULL,
 authorization_json TEXT NOT NULL,recorded_at TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS core_v1_observations_immutable BEFORE UPDATE ON core_v1_observations
 BEGIN SELECT RAISE(ABORT,'immutable observation'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_proposals_immutable BEFORE UPDATE ON core_v1_proposals
 BEGIN SELECT RAISE(ABORT,'immutable proposal'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_decisions_immutable BEFORE UPDATE ON core_v1_decisions
 BEGIN SELECT RAISE(ABORT,'immutable decision'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_snapshots_immutable BEFORE UPDATE ON core_v1_context_snapshots
 BEGIN SELECT RAISE(ABORT,'immutable context snapshot'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_observations_no_delete BEFORE DELETE ON core_v1_observations
 BEGIN SELECT RAISE(ABORT,'immutable observation'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_proposals_no_delete BEFORE DELETE ON core_v1_proposals
 BEGIN SELECT RAISE(ABORT,'immutable proposal'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_decisions_no_delete BEFORE DELETE ON core_v1_decisions
 BEGIN SELECT RAISE(ABORT,'immutable decision'); END;
CREATE TRIGGER IF NOT EXISTS core_v1_snapshots_no_delete BEFORE DELETE ON core_v1_context_snapshots
 BEGIN SELECT RAISE(ABORT,'immutable context snapshot'); END;
"""

SCHEMA += ENTERPRISE_PROFILE_SCHEMA

FINANCE_FIELDS = FINANCIAL_FIELD_BASES  # Public compatibility alias for existing adapters.
# Exactly the same seed set as the previous union, with one metadata source.
# Registry membership does not classify extensions or grant resource access.
BUSINESS_FIELDS = frozenset(FIELD_ENTITY_TYPES.keys() - FINANCE_FIELDS)
BUSINESS_TIMEZONE = timezone(timedelta(hours=7))


def _digest(value):
    return hashlib.sha256(json_text(value).encode()).hexdigest()


def _instant(value):
    try:
        parsed = datetime.fromisoformat(value)
    except (ValueError, TypeError) as exc:
        raise CoreError("invalid_date", "Ngày hoặc thời điểm không hợp lệ.") from exc
    # Date-only business declarations use Hanoi's calendar; audit timestamps are
    # always recorded as instants with an explicit timezone.
    if isinstance(value, str) and len(value) == 10:
        parsed = parsed.replace(tzinfo=BUSINESS_TIMEZONE)
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)


def _finance(field):
    return field_is_financial(field)


class CoreSSOTService:
    def __init__(self, repo, *, initialize=True):
        self.repo = repo
        if not initialize:
            return
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)
            if getattr(repo, "managed_runtime", False):
                return
            db.executemany("INSERT OR IGNORE INTO core_v1_field_definitions VALUES(?,'business','owner_required',1)",
                           [(field,) for field in BUSINESS_FIELDS])
            db.executemany("INSERT OR IGNORE INTO core_v1_field_definitions VALUES(?,'finance','owner_required',1)",
                           [(field,) for field in FINANCE_FIELDS])

    def membership(self, account_id, enterprise_id, db=None, owner=False):
        if db is None:
            with self.repo.connection() as connection:
                return self.membership(account_id, enterprise_id, connection, owner)
        row = db.execute("SELECT m.*,e.name enterprise_name FROM v03_memberships m "
                         "JOIN v03_accounts a ON a.id=m.account_id JOIN v03_enterprises e ON e.id=m.enterprise_id "
                         "WHERE m.account_id=? AND m.enterprise_id=? AND m.active=1 AND a.active=1",
                         (account_id, enterprise_id)).fetchone()
        if row is None or row["role"] not in {"owner", "staff"} or (owner and row["role"] != "owner"):
            raise CoreError("forbidden", "Không có quyền thực hiện việc này trong doanh nghiệp.", 403)
        return dict(row)

    @staticmethod
    def _event(db, enterprise_id, actor, event, payload, resource_id=None):
        db.execute("INSERT INTO core_v1_acl_events VALUES(?,?,?,?,?,?,?)",
                   (new_id("acl"), enterprise_id, resource_id, actor, event, json_text(payload), now_iso()))

    def add_member(self, account_id, enterprise_id, username, role="staff", operation_id=None):
        if role != "staff":
            raise CoreError("invalid_role", "MVP chỉ cho phép thêm nhân viên; không cấp thêm quyền chủ doanh nghiệp.")
        if not isinstance(username, str) or not username.strip():
            raise CoreError("invalid_username", "Cần tên đăng nhập của tài khoản đã tồn tại.")
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db, owner=True)
            target = db.execute("SELECT id,username FROM v03_accounts WHERE username=? AND active=1",
                                (username.strip().casefold(),)).fetchone()
            if target is None:
                raise CoreError("not_found", "Chưa tìm thấy tài khoản hoạt động này.", 404)
            row = db.execute("SELECT role FROM v03_memberships WHERE account_id=? AND enterprise_id=?",
                             (target["id"], enterprise_id)).fetchone()
            if row and row["role"] == "owner":
                raise CoreError("invalid_role", "Không đổi vai trò chủ doanh nghiệp bằng thao tác thêm nhân viên.")
            request = [target["id"], role]
            if operation_id:
                request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "core_add_member", operation_id, request)
                if previous is not None:
                    return previous
            # Rejoining does not reactivate old grants; removal explicitly revokes them.
            db.execute("INSERT INTO v03_memberships VALUES(?,?,'staff',1) ON CONFLICT(account_id,enterprise_id) "
                       "DO UPDATE SET role='staff',active=1", (target["id"], enterprise_id))
            result = {"account_id": target["id"], "username": target["username"], "role": "staff", "active": True,
                      "enterprise_id": enterprise_id, "message": "Đã thêm nhân viên. Chưa chia sẻ hồ sơ hoặc tài liệu."}
            self._event(db, enterprise_id, account_id, "member_added", result)
            if operation_id:
                self.repo._save_operation(db, account_id, enterprise_id, "core_add_member", operation_id, request_hash, result)
            return result

    def list_members(self, account_id, enterprise_id):
        with self.repo.connection() as db:
            self.membership(account_id, enterprise_id, db, owner=True)
            return [dict(row) for row in db.execute("SELECT a.id account_id,a.username,m.role,m.active FROM v03_memberships m "
                    "JOIN v03_accounts a ON a.id=m.account_id WHERE m.enterprise_id=? ORDER BY a.username", (enterprise_id,))]

    def remove_member(self, account_id, enterprise_id, member_account_id):
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db, owner=True)
            target = self.membership(member_account_id, enterprise_id, db)
            if target["role"] == "owner":
                raise CoreError("invalid_role", "Không thu hồi chủ doanh nghiệp bằng thao tác này.")
            db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?", (member_account_id, enterprise_id))
            db.execute("UPDATE core_v1_grants SET revoked_at=? WHERE account_id=? AND enterprise_id=? AND revoked_at IS NULL",
                       (now_iso(), member_account_id, enterprise_id))
            db.execute("UPDATE core_v1_egress_authorities SET revoked_at=? WHERE account_id=? AND enterprise_id=? AND revoked_at IS NULL",
                       (now_iso(), member_account_id, enterprise_id))
            self._event(db, enterprise_id, account_id, "member_removed", {"account_id": member_account_id})
            return {"status": "revoked", "account_id": member_account_id}

    def _entity(self, db, enterprise_id, entity_id):
        row = db.execute("SELECT * FROM v03_entities WHERE enterprise_id=? AND id=?", (enterprise_id, entity_id)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy hồ sơ trong doanh nghiệp này.", 404)
        entity = {**dict(row), **self.repo.entity_lifecycle(db, enterprise_id, entity_id)}
        entity.update(self.repo.name_projection(db, enterprise_id, entity))
        if (entity.get("name_validation") or {}).get("display_only"):
            entity["can_select_for_ai"] = False
        return entity

    def _resource(self, db, enterprise_id, resource_id, create=False):
        row = db.execute("SELECT * FROM core_v1_resources WHERE enterprise_id=? AND resource_id=?",
                         (enterprise_id, resource_id)).fetchone()
        if row is None and create:
            entity = self._entity(db, enterprise_id, resource_id)
            db.execute("INSERT INTO core_v1_resources VALUES(?,?, 'ssot_entity',?,1,?)",
                       (enterprise_id, resource_id, entity["created_by"], entity["created_at"]))
            row = db.execute("SELECT * FROM core_v1_resources WHERE enterprise_id=? AND resource_id=?",
                             (enterprise_id, resource_id)).fetchone()
        return dict(row) if row else None

    def _can(self, db, account_id, enterprise_id, resource_id, capability="read", field=None):
        membership = self.membership(account_id, enterprise_id, db)
        # DF-029: legacy entity revocation is a deny override, including exact
        # receipt reads. Ownership or an explicit additive grant cannot undo it.
        # Archive is a different lifecycle and intentionally does not deny READ.
        entity = db.execute("SELECT created_by,acl FROM v03_entities WHERE enterprise_id=? AND id=?",
                            (enterprise_id, resource_id)).fetchone()
        if entity is not None and entity["acl"] != "private_owner":
            return False
        if capability == "send_financial_metrics":
            # D05: ownership/read permission never silently authorizes egress.
            query = "SELECT 1 FROM core_v1_egress_authorities WHERE enterprise_id=? AND resource_id=? AND account_id=? AND revoked_at IS NULL"
            args = [enterprise_id, resource_id, account_id]
            if field is not None:
                query += " AND field_key IN (?, '*')"
                args.append(field)
            return db.execute(query, args).fetchone() is not None
        resource = self._resource(db, enterprise_id, resource_id)
        if resource is None:
            return bool(entity and entity["created_by"] == account_id and membership["role"] == "owner")
        if resource["created_by"] == account_id:
            if resource["resource_type"] != "ssot_entity" or membership["role"] == "owner":
                return True
            # Losing owner WRITE does not revoke an explicit current READ
            # grant. Fall through to the same grant check as every staff actor.
        query = "SELECT 1 FROM core_v1_grants WHERE enterprise_id=? AND resource_id=? AND account_id=? " \
                "AND capability=? AND revoked_at IS NULL"
        args = [enterprise_id, resource_id, account_id, capability]
        if field is not None:
            query += " AND field_key IN (?, '*')"
            args.append(field)
        return db.execute(query, args).fetchone() is not None

    def _require(self, db, account_id, enterprise_id, resource_id, capability="read", field=None):
        if not self._can(db, account_id, enterprise_id, resource_id, capability, field):
            raise CoreError("forbidden", "Chưa được cấp quyền cho hồ sơ hoặc dữ kiện này.", 403)
        entity = db.execute("SELECT created_by FROM v03_entities WHERE enterprise_id=? AND id=?", (enterprise_id, resource_id)).fetchone()
        own = bool(entity and entity["created_by"] == account_id)
        definition = db.execute("SELECT sensitivity FROM core_v1_field_definitions WHERE field_key=?", (field,)).fetchone() if field else None
        # An unclassified field is not silently opened by a wildcard resource
        # grant. Its owner must explicitly assign that field or classify it.
        if field and not own and ((not definition and not _finance(field)) or (definition and definition["sensitivity"] == "restricted")):
            exact = db.execute("SELECT 1 FROM core_v1_grants WHERE enterprise_id=? AND resource_id=? AND account_id=? "
                               "AND capability=? AND field_key=? AND revoked_at IS NULL",
                               (enterprise_id, resource_id, account_id, capability, field)).fetchone()
            if not exact:
                raise CoreError("forbidden", "Dữ kiện mới chưa được phân loại và cấp phạm vi riêng.", 403)
        if field and (_finance(field) or (definition and definition["sensitivity"] == "finance")) and capability in {"read", "propose_fact"}:
            if not self._can(db, account_id, enterprise_id, resource_id, "read_finance", field):
                raise CoreError("forbidden", "Chưa được cấp quyền xem nhóm dữ kiện tài chính này.", 403)

    def can_read(self, account_id, enterprise_id, resource_id, field=None, db=None):
        """Boolean projection of the complete READ policy, in the caller's snapshot."""
        if db is None:
            with self.repo.connection() as connection:
                return self.can_read(account_id, enterprise_id, resource_id, field, connection)
        try:
            self._require(db, account_id, enterprise_id, resource_id, field=field)
        except CoreError:
            return False
        return True

    def authorize_fact_receipt(self, db, account_id, enterprise_id, receipt):
        """DF-046: authorize an exact receipt; never redact/rehash its payload."""
        self.membership(account_id, enterprise_id, db)
        entity_id = receipt["entity_id"]
        self._entity(db, enterprise_id, entity_id)
        self._require(db, account_id, enterprise_id, entity_id)
        # The stored result includes the full as-of fact projection, not merely
        # changed_fields. A narrower later grant cannot expose other old facts.
        for fact in receipt.get("facts", []):
            self._require(db, account_id, enterprise_id, entity_id, field=fact["field"])

    def has_capability(self, account_id, enterprise_id, resource_id, capability, field=None, db=None):
        if db is None:
            with self.repo.connection() as connection:
                return self.has_capability(account_id, enterprise_id, resource_id, capability, field, connection)
        try:
            return self._can(db, account_id, enterprise_id, resource_id, capability, field)
        except CoreError:
            return False

    def grant_resource(self, account_id, enterprise_id, resource_id, member_account_id,
                       capabilities=None, field_keys=None):
        capabilities = ["read"] if capabilities is None else capabilities
        field_keys = ["*"] if field_keys is None else field_keys
        if not isinstance(capabilities, list) or not capabilities or set(capabilities) - {"read", "propose_fact", "read_finance", "send_financial_metrics"}:
            raise CoreError("invalid_capability", "Nhân viên chỉ được xem hoặc đề xuất; không được xác nhận SSOT.")
        if not isinstance(field_keys, list) or not field_keys or len(field_keys) > 100 or any(not isinstance(f, str) or not f or len(f) > 100 for f in field_keys):
            raise CoreError("invalid_fields", "Cần phạm vi dữ kiện hợp lệ.")
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db, owner=True)
            self.membership(member_account_id, enterprise_id, db)
            resource = self._resource(db, enterprise_id, resource_id, create=True)
            if resource["created_by"] != account_id:
                raise CoreError("forbidden", "Không được tự chia sẻ tài nguyên riêng của người khác.", 403)
            for field in dict.fromkeys(field_keys):
                if "propose_fact" in capabilities and "read" not in capabilities and not self._can(db, member_account_id, enterprise_id, resource_id, "read", field):
                    raise CoreError("read_required", "Cần cấp quyền xem cùng phạm vi trước khi cho đề xuất.")
                for capability in dict.fromkeys(capabilities):
                    if capability == "send_financial_metrics":
                        db.execute("INSERT INTO core_v1_egress_authorities VALUES(?,?,?,?,?,?,NULL) "
                                   "ON CONFLICT(enterprise_id,resource_id,account_id,field_key) DO UPDATE SET "
                                   "granted_by=excluded.granted_by,granted_at=excluded.granted_at,revoked_at=NULL",
                                   (enterprise_id, resource_id, member_account_id, field, account_id, now_iso()))
                        continue
                    db.execute("INSERT INTO core_v1_grants VALUES(?,?,?,?,?,?,?,NULL) "
                               "ON CONFLICT(enterprise_id,resource_id,account_id,capability,field_key) DO UPDATE SET "
                               "granted_by=excluded.granted_by,granted_at=excluded.granted_at,revoked_at=NULL",
                               (enterprise_id, resource_id, member_account_id, capability, field, account_id, now_iso()))
            db.execute("UPDATE core_v1_resources SET acl_revision=acl_revision+1 WHERE enterprise_id=? AND resource_id=?", (enterprise_id, resource_id))
            result = {"resource_id": resource_id, "account_id": member_account_id, "capabilities": capabilities,
                      "field_keys": field_keys, "status": "granted"}
            self._event(db, enterprise_id, account_id, "resource_granted", result, resource_id)
            return result

    def revoke_resource(self, account_id, enterprise_id, resource_id, member_account_id,
                        capabilities=None, field_keys=None):
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db, owner=True)
            resource = self._resource(db, enterprise_id, resource_id)
            if not resource or resource["created_by"] != account_id:
                raise CoreError("forbidden", "Không có quyền thu hồi chia sẻ tài nguyên này.", 403)
            query = "UPDATE core_v1_grants SET revoked_at=? WHERE enterprise_id=? AND resource_id=? AND account_id=? AND revoked_at IS NULL"
            args = [now_iso(), enterprise_id, resource_id, member_account_id]
            for column, values in (("capability", capabilities), ("field_key", field_keys)):
                if values is not None:
                    if not isinstance(values, list) or not values or any(not isinstance(v, str) for v in values):
                        raise CoreError("invalid_scope", "Phạm vi thu hồi không hợp lệ.")
                    query += f" AND {column} IN ({','.join('?' for _ in values)})"
                    args.extend(values)
            db.execute(query, args)
            if capabilities is None or "send_financial_metrics" in capabilities:
                authority_query = "UPDATE core_v1_egress_authorities SET revoked_at=? WHERE enterprise_id=? AND resource_id=? AND account_id=? AND revoked_at IS NULL"
                authority_args = [now_iso(), enterprise_id, resource_id, member_account_id]
                if field_keys is not None:
                    authority_query += f" AND field_key IN ({','.join('?' for _ in field_keys)})"
                    authority_args.extend(field_keys)
                db.execute(authority_query, authority_args)
            db.execute("UPDATE core_v1_resources SET acl_revision=acl_revision+1 WHERE enterprise_id=? AND resource_id=?", (enterprise_id, resource_id))
            result = {"status": "revoked", "resource_id": resource_id, "account_id": member_account_id}
            self._event(db, enterprise_id, account_id, "resource_revoked", result, resource_id)
            return result

    @staticmethod
    def _safe_fact(fact, actor, entity):
        fact = dict(fact)
        if actor != entity["created_by"] and actor != fact["actor_id"]:
            # A fact grant must not expose file names, URLs, snippets or locators.
            fact["source"] = {"kind": "restricted_source", "details_restricted": True}
        return fact

    def _visible_entity(self, db, account_id, enterprise_id, entity, field_keys=None):
        # Listing supplies a raw SQL row; context supplies an already projected
        # row. Re-read the authoritative row in this same transaction rather
        # than treating a display fallback as canonical input on the second pass.
        entity = self._entity(db, enterprise_id, entity["id"])
        self._require(db, account_id, enterprise_id, entity["id"])
        facts = []
        for fact in self.repo._facts(db, enterprise_id, entity["id"]):
            if field_keys is not None and fact["field"] not in field_keys:
                continue
            try:
                self._require(db, account_id, enterprise_id, entity["id"], field=fact["field"])
            except CoreError:
                continue
            facts.append(self._safe_fact(fact, account_id, entity))
        invalid = []
        for fact in self.repo._facts(db, enterprise_id, entity["id"], include_invalid=True):
            issue = scope_issue(entity["entity_type"], fact)
            if issue is None or (field_keys is not None and fact["field"] not in field_keys):
                continue
            try:
                self._require(db, account_id, enterprise_id, entity["id"], field=fact["field"])
            except CoreError:
                continue
            invalid.append(self._safe_fact(issue, account_id, entity))
        result = {"id": entity["id"], "entity_id": entity["id"], "entity_type": entity["entity_type"],
                  "version": entity["version"], "name": entity["name"] if self.can_read(account_id, enterprise_id, entity["id"], field="name", db=db) else "Hồ sơ được chia sẻ",
                  "facts": facts, "values": {f["field"]: f["value"] for f in facts if f["value_state"] == "known" and f["freshness_state"] == "self_declared"},
                  "field_scope": scope_contract(entity["entity_type"]), "invalid_facts": invalid}
        result.update(self.repo.entity_lifecycle(db, enterprise_id, entity["id"]))
        result["can_select_for_ai"] = result["can_select_for_ai"] and entity["can_select_for_ai"]
        if entity.get("name_validation") and self.can_read(account_id, enterprise_id, entity["id"], field="name", db=db):
            result["name_validation"] = dict(entity["name_validation"])
        result["validation_issues"] = [{**issue, "value": fact["value"], "assertion_id": fact["assertion_id"], "version": fact["version"]}
            for fact in self.repo._facts(db, enterprise_id, entity["id"], include_invalid=True)
            if (field_keys is None or fact["field"] in field_keys) and self.can_read(account_id, enterprise_id, entity["id"], field=fact["field"], db=db)
            and fact["value_state"] == "known" and (issue := validate_field_value(fact["field"], fact["value"]))]
        return result

    def list_entities(self, account_id, enterprise_id, entity_type=None, include_archived=False):
        with self.repo.connection() as db:
            self.membership(account_id, enterprise_id, db)
            result = []
            for row in db.execute("SELECT * FROM v03_entities WHERE enterprise_id=? ORDER BY created_at,id", (enterprise_id,)):
                if not include_archived and self.repo.entity_lifecycle(db, enterprise_id, row["id"])["archived"]:
                    continue
                if (entity_type is None or canonical_entity_type(row["entity_type"]) == canonical_entity_type(entity_type)) and self._can(db, account_id, enterprise_id, row["id"]):
                    result.append(self._visible_entity(db, account_id, enterprise_id, dict(row)))
            return result

    def propose_facts(self, account_id, enterprise_id, entity_id, facts, expected_version,
                      operation_id, source=None, reason=None):
        if not isinstance(facts, list) or not 1 <= len(facts) <= 100:
            raise CoreError("invalid_facts", "Cần từ 1 đến 100 dữ kiện đề xuất.")
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 0:
            raise CoreError("expected_version_required", "Cần phiên bản hồ sơ đã xem.", 409)
        legacy_states = {"explicit_absent": "known_absent", "disputed": "conflicted"}
        translated = [{**value, "value_state": legacy_states.get(value.get("value_state"), value.get("value_state"))}
                      if isinstance(value, dict) and value.get("value_state") in legacy_states else value for value in facts]
        normalized = [fact for value in translated if (fact := self.repo._normalize_fact(value)) is not None]
        if not normalized or len({f["field"] for f in normalized}) != len(normalized):
            raise CoreError("invalid_facts", "Đề xuất cần dữ kiện rõ ràng, mỗi trường xuất hiện một lần.")
        # Intervals with exact bounds work; unbounded legacy facts stay current_only.
        request = [entity_id, normalized, expected_version, source, reason]
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db)
            entity = self._entity(db, enterprise_id, entity_id)
            if entity["archived"]:
                raise CoreError("entity_archived", "Hồ sơ đã lưu trữ; cần khôi phục trước khi đề xuất dữ kiện.", 409)
            self.repo._require_fact_scope(entity, normalized)
            for fact in normalized:
                self._require(db, account_id, enterprise_id, entity_id, "read", fact["field"])
                self._require(db, account_id, enterprise_id, entity_id, "propose_fact", fact["field"])
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "core_propose", operation_id, request)
            if previous is not None:
                return previous
            if entity["version"] != expected_version:
                raise CoreError("version_conflict", "Hồ sơ đã đổi. Hãy xem bản mới trước khi đề xuất.", 409)
            fields = {f["field"] for f in normalized}
            heads = {f["field"]: f["version"] for f in self.repo._facts(db, enterprise_id, entity_id) if f["field"] in fields}
            heads = {field: heads.get(field, 0) for field in fields}
            revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
            stamp, observation_id, proposal_id = now_iso(), new_id("observation"), new_id("proposal")
            observation_source = source or {"kind": "user_statement"}
            if not isinstance(observation_source, dict) or len(json_text(observation_source)) > 4000:
                raise CoreError("invalid_source", "Nguồn đề xuất không hợp lệ.")
            db.execute("INSERT INTO core_v1_observations VALUES(?,?,?,?,?,?,?,?)", (observation_id, enterprise_id, entity_id,
                       account_id, json_text(normalized), _digest(normalized), json_text(observation_source), stamp))
            db.execute("INSERT INTO core_v1_proposals VALUES(?,?,?,?,?,?,?,?,?,?,?)", (proposal_id, enterprise_id, entity_id,
                       observation_id, account_id, json_text(normalized), _digest(normalized), expected_version, json_text(heads), revision, stamp))
            result = {"proposal_id": proposal_id, "observation_id": observation_id, "entity_id": entity_id,
                      "status": "awaiting_owner", "facts": normalized, "proposal_hash": _digest(normalized),
                      "expected_version": expected_version, "expected_field_versions": heads, "context_revision": revision,
                      "message": "Đã lưu đề xuất; hồ sơ chuẩn chưa thay đổi. Chủ doanh nghiệp cần xác nhận."}
            self.repo._save_operation(db, account_id, enterprise_id, "core_propose", operation_id, request_hash, result)
            return result

    def list_proposals(self, account_id, enterprise_id, entity_id=None):
        with self.repo.connection() as db:
            member = self.membership(account_id, enterprise_id, db)
            result = []
            query = "SELECT p.*,d.action decision FROM core_v1_proposals p LEFT JOIN core_v1_decisions d ON d.proposal_id=p.id WHERE p.enterprise_id=?"
            args = [enterprise_id]
            if entity_id:
                query += " AND p.entity_id=?"
                args.append(entity_id)
            for row in db.execute(query + " ORDER BY p.recorded_at,p.id", args):
                entity = self._entity(db, enterprise_id, row["entity_id"])
                if member["role"] != "owner" and row["actor_id"] != account_id:
                    continue
                facts = json.loads(row["facts_json"])
                try:
                    for fact in facts:
                        self._require(db, account_id, enterprise_id, entity["id"], field=fact["field"])
                except CoreError:
                    continue
                if row["actor_id"] != account_id:
                    facts = [{**f, "source": {"kind": "restricted_source", "details_restricted": True}} for f in facts]
                invalid = [issue for fact in facts if (issue := scope_issue(entity["entity_type"], fact)) is not None]
                result.append({"proposal_id": row["id"], "entity_id": row["entity_id"], "facts": facts,
                               "proposal_hash": row["payload_hash"], "expected_version": row["expected_version"],
                               "expected_field_versions": json.loads(row["field_versions_json"]),
                               "context_revision": row["context_revision"],
                               "status": row["decision"] or ("invalid_scope" if invalid else "awaiting_owner"),
                               "invalid_facts": invalid,
                               "recorded_at": row["recorded_at"]})
            return result

    def confirm_facts(self, account_id, enterprise_id, proposal_id, expected_version, operation_id,
                      proposal_hash=None, expected_field_versions=None, expected_context_revision=None, reason=None):
        with self.repo.connection(write=True) as db:
            self.membership(account_id, enterprise_id, db)
            proposal = db.execute("SELECT * FROM core_v1_proposals WHERE enterprise_id=? AND id=?", (enterprise_id, proposal_id)).fetchone()
            if proposal is None:
                raise CoreError("not_found", "Không tìm thấy đề xuất trong doanh nghiệp này.", 404)
            entity = self._entity(db, enterprise_id, proposal["entity_id"])
            facts = json.loads(proposal["facts_json"])
            # A saved command result is still private data. Re-authorize reads
            # before replay, even though no new fact will be written.
            self._require(db, account_id, enterprise_id, entity["id"])
            for fact in facts:
                self._require(db, account_id, enterprise_id, entity["id"], field=fact["field"])
            expected = json.loads(proposal["field_versions_json"])
            request = [proposal_id, expected_version, proposal_hash, expected_field_versions, expected_context_revision, reason]
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "core_confirm", operation_id, request)
            if previous is not None:
                self.authorize_fact_receipt(db, account_id, enterprise_id, previous)
                return previous
            # New commands retain D04's owner-only confirmation and the legacy
            # private-resource gate. A receipt read grants no new WRITE.
            self.membership(account_id, enterprise_id, db, owner=True)
            if entity["created_by"] != account_id:
                raise CoreError("forbidden", "Chỉ chủ hồ sơ được xác nhận dữ kiện này.", 403)
            self.repo._entity(account_id, enterprise_id, entity["id"], db)
            self.repo._require_fact_scope(entity, facts)
            if db.execute("SELECT 1 FROM core_v1_decisions WHERE proposal_id=?", (proposal_id,)).fetchone():
                raise CoreError("proposal_resolved", "Đề xuất này đã có quyết định; không áp dụng lại.", 409)
            if proposal_hash is not None and proposal_hash != proposal["payload_hash"]:
                raise CoreError("proposal_conflict", "Nội dung đề xuất không khớp bản đã xem.", 409)
            if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 0:
                raise CoreError("expected_version_required", "Cần phiên bản hồ sơ đã xem.", 409)
            supplied = expected if expected_field_versions is None else expected_field_versions
            if supplied != expected:
                raise CoreError("fact_version_conflict", "Phiên bản dữ kiện không khớp đề xuất đã xem.", 409)
            current = {f["field"]: f["version"] for f in self.repo._facts(db, enterprise_id, entity["id"])}
            conflicts = [field for field, version in expected.items() if current.get(field, 0) != version]
            if conflicts:
                raise CoreError("fact_version_conflict", "Dữ kiện liên quan đã đổi: " + ", ".join(conflicts) + ". Hãy xem và đề xuất lại.", 409)
            if expected_version != entity["version"] and expected_field_versions is None:
                raise CoreError("version_conflict", "Hồ sơ đã đổi; cần đối chiếu phiên bản từng dữ kiện.", 409)
            if expected_context_revision is not None and (not isinstance(expected_context_revision, int) or expected_context_revision < proposal["context_revision"]):
                raise CoreError("context_revision_conflict", "Phiên bản ngữ cảnh đã xem không hợp lệ.", 409)
            current_revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
            if expected_context_revision is not None and (isinstance(expected_context_revision, bool) or expected_context_revision > current_revision):
                raise CoreError("context_revision_conflict", "Phiên bản ngữ cảnh đã xem không hợp lệ.", 409)
            # Retain private source material in the immutable observation. The owner
            # confirms values as self-declared; this does not grant source-file access.
            confirmed = [{**f, "source": {"kind": "owner_confirmed_proposal", "proposal_id": proposal_id,
                          "observation_id": proposal["observation_id"], "details_restricted": True}} for f in facts]
            result = self.repo.propose_or_apply_facts(account_id, enterprise_id, entity["id"], confirmed,
                      entity["version"], "core-canonical-" + _digest(operation_id), reason=reason or "Chủ doanh nghiệp xác nhận đề xuất", db=db)
            result.update({"proposal_id": proposal_id, "status": "confirmed", "verification_state": "self_declared"})
            db.execute("INSERT INTO core_v1_decisions VALUES(?,?,?,?,?,?,?,?)", (new_id("decision"), enterprise_id,
                       proposal_id, account_id, "confirmed", reason or "Chủ doanh nghiệp xác nhận", json_text(result), now_iso()))
            self.repo._save_operation(db, account_id, enterprise_id, "core_confirm", operation_id, request_hash, result)
            return result

    def get_context(self, account_id, enterprise_id, entity_ids, field_keys=None, target_date=None, known_at=None,
                    save_snapshot=True):
        if not isinstance(entity_ids, list) or len(entity_ids) > 100 or any(not isinstance(v, str) for v in entity_ids):
            raise CoreError("entity_scope_required", "Cần chọn rõ các hồ sơ dùng cho công việc.")
        if field_keys is not None and (not isinstance(field_keys, list) or len(field_keys) > 100 or any(not isinstance(v, str) for v in field_keys)):
            raise CoreError("invalid_fields", "Danh sách trường ngữ cảnh không hợp lệ.")
        now = now_iso()
        known = _instant(known_at or now)
        target = _instant(target_date or now)
        if known > _instant(now):
            raise CoreError("invalid_known_at", "Không thể dùng tri thức tại thời điểm tương lai.")
        with self.repo.connection(write=save_snapshot) as db:
            member = self.membership(account_id, enterprise_id, db)
            entities, refs, auth_refs = [], [], []
            for entity_id in dict.fromkeys(entity_ids):
                entity = self._entity(db, enterprise_id, entity_id)
                # Check current READ before exposing an identity-validation
                # state. A guessed private resource never reveals its status.
                visible = self._visible_entity(db, account_id, enterprise_id, entity, field_keys)
                self.repo.require_usable_ai_identity(entity)
                if not entity["can_select_for_ai"]:
                    raise CoreError("entity_archived", "Hồ sơ đã lưu trữ; chưa dùng cho một lượt AI mới.", 409)
                # Invalid legacy declarations are only shown in the profile
                # review view. Neither their values nor provenance enter AI context.
                visible.pop("invalid_facts", None)
                # Exact system-time reconstruction uses only owner-selected assertion
                # versions; unselected observations never enter context.
                rows = db.execute("SELECT a.*,r.id resolution_id,r.recorded_at resolution_at,r.previous_assertion_id FROM v03_fact_assertions a "
                                  "JOIN v03_fact_resolutions r ON r.assertion_id=a.id "
                                  "WHERE a.enterprise_id=? AND a.entity_id=? ORDER BY r.recorded_at,r.id",
                                  (enterprise_id, entity_id)).fetchall()
                versions, selected, timeline = {}, {}, {}
                for row in causal_fact_rows(rows):
                    versions[row["field"]] = versions.get(row["field"], 0) + 1
                    if _instant(row["resolution_at"]) <= known:
                        selected[row["field"]] = (dict(row), versions[row["field"]])
                        timeline.setdefault(row["field"], []).append((dict(row), versions[row["field"]]))
                fields = field_keys if field_keys is not None else [f["field"] for f in visible["facts"]]
                facts, values = [], {}
                for field in fields:
                    self._require(db, account_id, enterprise_id, entity_id, field=field)
                    if not field_is_in_scope(entity["entity_type"], field):
                        continue
                    # Replaying owner decisions yields an interval projection, not
                    # another fact authority: a future or disjoint interval never
                    # erases an earlier declaration that covers the requested date.
                    current_target = target.astimezone(BUSINESS_TIMEZONE).date() == _instant(now).astimezone(BUSINESS_TIMEZONE).date()
                    record = None
                    for candidate, field_version in timeline.get(field, []):
                        bounded = bool(candidate["valid_from"] and candidate["valid_to"])
                        covers = ((not candidate["valid_from"] or target >= _instant(candidate["valid_from"])) and
                                  (not candidate["valid_to"] or target < _instant(candidate["valid_to"])))
                        if (bounded and covers) or (not bounded and current_target and covers):
                            record = (candidate, field_version)
                    if record is None:
                        record = selected.get(field)
                    if record is None:
                        facts.append({"field": field, "value": None, "value_state": "unknown", "version": 0,
                                      "freshness_state": "unknown", "verification_state": "self_declared"})
                        refs.append({"entity_id": entity_id, "field": field, "version": 0, "assertion_id": None})
                        continue
                    row, version = record
                    bounded = bool(row["valid_from"] and row["valid_to"])
                    valid = ((not row["valid_from"] or target >= _instant(row["valid_from"])) and
                             (not row["valid_to"] or target < _instant(row["valid_to"])))
                    # A date-less declaration means current-only, not effective since
                    # forever. For old target dates return an explicit unknown.
                    temporal_ok = valid and (bounded or current_target)
                    fact = {"field": field, "value": json.loads(row["value_json"]) if temporal_ok else None,
                            "value_state": row["value_state"] if temporal_ok else "unknown",
                            "version": version, "assertion_id": row["id"], "resolution_id": row["resolution_id"],
                            "source": json.loads(row["source_json"]), "actor_id": row["actor_id"],
                            "valid_from": row["valid_from"], "valid_to": row["valid_to"],
                            "temporal_basis": "interval" if bounded else "current_only",
                            "freshness_state": "self_declared" if temporal_ok else "unknown_for_target_date",
                            "verification_state": "self_declared"}
                    if fact["value_state"] == "known" and validate_field_value(field, fact["value"]):
                        fact.update(value=None, value_state="unknown", freshness_state="invalid_value")
                    facts.append(self._safe_fact(fact, account_id, entity))
                    if temporal_ok and fact["value_state"] == "known":
                        values[field] = fact["value"]
                    refs.append({"entity_id": entity_id, "field": field, "version": version, "assertion_id": row["id"]})
                # Metadata name must not reveal a later fact in historical snapshots.
                if "name" in values:
                    visible["name"] = values["name"]
                elif known_at is not None or target_date is not None:
                    visible["name"] = "Hồ sơ đã chọn"
                visible["facts"], visible["values"] = facts, values
                entities.append(visible)
                resource = self._resource(db, enterprise_id, entity_id)
                auth_refs.append({"entity_id": entity_id, "acl_revision": resource["acl_revision"] if resource else 1})
            revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
            payload = {"enterprise_id": enterprise_id, "enterprise_name": member["enterprise_name"],
                       "context_revision": revision, "context_revision_id": f"{enterprise_id}:{revision}",
                       "entities": entities, "fact_refs": refs,
                       "as_of": target.isoformat(), "known_at": known.isoformat(), "resolver_version": "core-v1-sql-1",
                       "verification_state": "self_declared"}
            payload["context_hash"] = _digest(payload)
            if save_snapshot:
                snapshot_id = new_id("context")
                db.execute("INSERT INTO core_v1_context_snapshots VALUES(?,?,?,?,?,?,?,?)", (snapshot_id, enterprise_id,
                           account_id, json_text(payload), payload["context_hash"], json_text(refs), json_text(auth_refs), now))
                payload["context_snapshot_id"] = snapshot_id
            return payload

    def get_snapshot(self, account_id, enterprise_id, snapshot_id):
        with self.repo.connection() as db:
            self.membership(account_id, enterprise_id, db)
            row = db.execute("SELECT * FROM core_v1_context_snapshots WHERE id=? AND enterprise_id=? AND account_id=?",
                             (snapshot_id, enterprise_id, account_id)).fetchone()
            if row is None:
                raise CoreError("not_found", "Không tìm thấy ngữ cảnh được phép xem.", 404)
            payload = json.loads(row["payload_json"])
            for entity in payload["entities"]:
                self._require(db, account_id, enterprise_id, entity["id"])
            for ref in json.loads(row["refs_json"]):
                self._require(db, account_id, enterprise_id, ref["entity_id"], field=ref["field"])
                entity = self._entity(db, enterprise_id, ref["entity_id"])
                if not field_is_in_scope(entity["entity_type"], ref["field"]):
                    raise CoreError("context_scope_changed", "Bản ngữ cảnh cũ có dữ kiện sai phạm vi; cần tạo lại ngữ cảnh hợp lệ.", 409)
            payload["context_snapshot_id"] = snapshot_id
            return payload
