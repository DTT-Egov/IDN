"""An operator-approved local-app budget shared across all owner accounts.

Provisioning a scoped child grant never replenishes the common pool. Counts
and ambiguous monetary holds are checked inside the Gateway reservation write
transaction; new accounts, enterprises and process restarts share the same cap.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from .gateway import PROFILES, money_micro
from .budget_projection import usage_projection


SCHEMA = """
CREATE TABLE IF NOT EXISTS core_budget_pools (
 id TEXT PRIMARY KEY, approval_id TEXT NOT NULL, role TEXT NOT NULL,
 max_calls INTEGER NOT NULL CHECK(max_calls>0), cap_microusd INTEGER NOT NULL CHECK(cap_microusd>0),
 purposes_json TEXT NOT NULL, expires_at TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL, UNIQUE(approval_id,role));
CREATE TABLE IF NOT EXISTS core_budget_pool_links (
 grant_id TEXT PRIMARY KEY REFERENCES core_budget_grants(id),
 pool_id TEXT NOT NULL REFERENCES core_budget_pools(id),
 account_id TEXT NOT NULL REFERENCES v03_accounts(id), enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 created_at TEXT NOT NULL, UNIQUE(pool_id,account_id,enterprise_id));
CREATE INDEX IF NOT EXISTS core_budget_pool_links_pool ON core_budget_pool_links(pool_id);
"""


class BudgetPool:
    def __init__(self, repo):
        self.repo = repo
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)

    def authorize(self, approval_id, role, max_calls, cap_usd, purposes, expires_at):
        """Operator-only; the MCP/browser never exposes this method."""
        if not isinstance(approval_id, str) or not 1 <= len(approval_id) <= 200 or role not in PROFILES:
            raise CoreError("INVALID_BUDGET", "Cần mã phê duyệt và mô hình cụ thể.")
        if not isinstance(max_calls, int) or isinstance(max_calls, bool) or not 1 <= max_calls <= 100:
            raise CoreError("INVALID_BUDGET", "Cần số lượt đã được duyệt.")
        if not isinstance(purposes, (list, tuple)) or not purposes or any(not isinstance(p, str) or not 1 <= len(p) <= 80 for p in purposes):
            raise CoreError("INVALID_BUDGET", "Cần phạm vi tác vụ cụ thể.")
        try:
            expiry = datetime.fromisoformat(expires_at)
            if expiry.tzinfo is None or expiry <= datetime.now(timezone.utc):
                raise ValueError()
        except (TypeError, ValueError):
            raise CoreError("INVALID_BUDGET", "Thời hạn phê duyệt phải còn hiệu lực.") from None
        expiry_text = expiry.astimezone(timezone.utc).isoformat()
        cap, scopes = money_micro(cap_usd), json_text(sorted(set(purposes)))
        with self.repo.connection(write=True) as db:
            row = db.execute("SELECT * FROM core_budget_pools WHERE approval_id=? AND role=?", (approval_id, role)).fetchone()
            if row:
                if (row["max_calls"], row["cap_microusd"], row["purposes_json"], row["expires_at"]) != (max_calls, cap, scopes, expiry_text):
                    raise CoreError("BUDGET_APPROVAL_CONFLICT", "Phê duyệt đã lưu không được đổi hoặc tự gia hạn; cần phê duyệt mới.", 409)
                return {"id": row["id"], "approval_id": approval_id, "role": role, "state": row["state"]}
            pool_id = new_id("budget_pool")
            db.execute("INSERT INTO core_budget_pools VALUES(?,?,?,?,?,?,?,'active',?)",
                       (pool_id, approval_id, role, max_calls, cap, scopes, expiry_text, now_iso()))
        return {"id": pool_id, "approval_id": approval_id, "role": role, "state": "active"}

    def provision(self, account_id, enterprise_id):
        """Explicit operator/command activation, never called by a query.

        Kept for existing operator tooling. New begin commands activate only
        their selected approval in the same write transaction as the command.
        """
        result = []
        with self.repo.connection(write=True) as db:
            self.repo.get_membership(account_id, enterprise_id, db)  # owner-only legacy membership gate
            for pool in db.execute("SELECT * FROM core_budget_pools WHERE state='active' AND expires_at>? ORDER BY created_at,id", (now_iso(),)).fetchall():
                existing = db.execute("SELECT grant_id FROM core_budget_pool_links WHERE pool_id=? AND account_id=? AND enterprise_id=?",
                                      (pool["id"], account_id, enterprise_id)).fetchone()
                if existing:
                    result.append(existing[0])
                    continue
                usage = self._usage(db, pool["id"])
                if usage["calls"] >= pool["max_calls"] or usage["held"] >= pool["cap_microusd"]:
                    continue
                result.append(self._create_child(db, pool, account_id, enterprise_id))
        return result

    @staticmethod
    def _child_id(pool_id, account_id, enterprise_id):
        # A deterministic *reference*, not a grant of authority. Existing
        # historical links retain their exact original random grant IDs.
        raw = json_text(["budget-child/1", pool_id, account_id, enterprise_id])
        return "budget_" + hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _create_child(self, db, pool, account_id, enterprise_id):
        grant_id, stamp = self._child_id(pool["id"], account_id, enterprise_id), now_iso()
        db.execute("INSERT INTO core_budget_grants VALUES(?,?,?,?,?,?,?,?,?,'active',?)",
                   (grant_id, enterprise_id, account_id, pool["approval_id"], pool["max_calls"], pool["cap_microusd"],
                    pool["purposes_json"], json_text([pool["role"]]), pool["expires_at"], stamp))
        db.execute("INSERT INTO core_budget_pool_links VALUES(?,?,?,?,?)",
                   (grant_id, pool["id"], account_id, enterprise_id, stamp))
        return grant_id

    def preview(self, db, account_id, enterprise_id):
        """Owner-scoped available approvals with no grant/link/reservation write.

        Linked grants are projected by Gateway.status instead, including an
        exhausted, revoked or narrowed child. Reading cannot recreate them.
        """
        self.repo.get_membership(account_id, enterprise_id, db)
        result = []
        for pool in db.execute("SELECT * FROM core_budget_pools WHERE state='active' AND expires_at>? ORDER BY created_at,id",
                               (now_iso(),)).fetchall():
            if db.execute("SELECT 1 FROM core_budget_pool_links WHERE pool_id=? AND account_id=? AND enterprise_id=?",
                          (pool["id"], account_id, enterprise_id)).fetchone():
                continue
            projection = self._status_pool(db, pool)
            result.append({**projection, "id": self._child_id(pool["id"], account_id, enterprise_id),
                           "purposes": json.loads(pool["purposes_json"]), "roles": [pool["role"]],
                           "activation_required": True})
        return result

    def activate(self, db, account_id, enterprise_id, grant_id, purpose, role):
        """Resolve only the selected eligible preview inside a begin write UoW.

        The caller supplies the existing write transaction; failed guards roll
        back the child together with the command. No external call occurs here.
        """
        pool = self.resolve_preview(db, account_id, enterprise_id, grant_id, purpose=purpose, role=role)
        if pool is None:
            raise CoreError("BUDGET_NOT_GRANTED", "Hạn mức không còn hiệu lực cho đúng chủ tài khoản, tác vụ và mô hình. Chưa gửi Claude.", 409)
        if not self._status_pool(db, pool)["approved"]:
            raise CoreError("BUDGET_EXCEEDED", "Đã hết số lượt hoặc trần phí chung D06. Chưa gửi Claude.", 409)
        return self._create_child(db, pool, account_id, enterprise_id)

    def resolve_preview(self, db, account_id, enterprise_id, grant_id, *, purpose=None, role=None):
        """Read the exact live approval behind a scoped unactivated reference.

        Used for fresh-consent checks as well as activation. This lookup itself
        neither creates a link nor treats a reference as dispatch authority.
        """
        self.repo.get_membership(account_id, enterprise_id, db)
        for pool in db.execute("SELECT * FROM core_budget_pools WHERE state='active' AND expires_at>? ORDER BY created_at,id",
                               (now_iso(),)).fetchall():
            if grant_id != self._child_id(pool["id"], account_id, enterprise_id):
                continue
            if role is not None and role != pool["role"] or purpose is not None and purpose not in json.loads(pool["purposes_json"]):
                break
            linked = db.execute("SELECT grant_id FROM core_budget_pool_links WHERE pool_id=? AND account_id=? AND enterprise_id=?",
                                (pool["id"], account_id, enterprise_id)).fetchone()
            # A preexisting historical link is authoritative; no second grant.
            if linked:
                break
            return pool
        return None

    @staticmethod
    def _usage(db, pool_id):
        row = db.execute("SELECT COUNT(*),COALESCE(SUM(a.held_microusd),0) FROM core_model_attempts a "
                         "JOIN core_budget_pool_links l ON l.grant_id=a.grant_id "
                         "WHERE l.pool_id=? AND a.state!='cancelled_before_dispatch'", (pool_id,)).fetchone()
        return {"calls": row[0], "held": row[1]}

    def _pool(self, db, grant_id):
        return db.execute("SELECT p.*,l.account_id AS linked_account,l.enterprise_id AS linked_enterprise "
                          "FROM core_budget_pools p JOIN core_budget_pool_links l ON l.pool_id=p.id WHERE l.grant_id=?",
                          (grant_id,)).fetchone()

    def check_grant(self, db, grant_id):
        """Called under the existing Gateway transaction, including dispatch CAS."""
        pool = self._pool(db, grant_id)
        if pool is None:
            return None  # A separately approved private grant remains separately governed.
        grant = db.execute("SELECT * FROM core_budget_grants WHERE id=?", (grant_id,)).fetchone()
        valid = pool["state"] == "active" and pool["expires_at"] > now_iso() and grant is not None
        if valid:
            valid = (grant["account_id"] == pool["linked_account"] and grant["enterprise_id"] == pool["linked_enterprise"]
                     and grant["approval_id"] == pool["approval_id"] and grant["max_calls"] <= pool["max_calls"]
                     and grant["cap_microusd"] <= pool["cap_microusd"] and grant["expires_at"] <= pool["expires_at"]
                     and json.loads(grant["roles_json"]) == [pool["role"]]
                     and set(json.loads(grant["purposes_json"])).issubset(json.loads(pool["purposes_json"])))
        if not valid:
            raise CoreError("BUDGET_NOT_GRANTED", "Hạn mức chung đã đóng, hết hạn hoặc không còn khớp phê duyệt. Chưa gửi Claude.", 409)
        return pool

    def check_reservation(self, db, grant_id, hold):
        if not isinstance(hold, int) or isinstance(hold, bool) or hold < 0:
            raise CoreError("INVALID_BUDGET", "Khoản dự trù chưa hợp lệ.")
        pool = self.check_grant(db, grant_id)
        if pool is None:
            return
        used = self._usage(db, pool["id"])
        if used["calls"] >= pool["max_calls"] or used["held"]+hold > pool["cap_microusd"]:
            raise CoreError("BUDGET_EXCEEDED", "Đã hết số lượt hoặc trần phí chung D06. Đổi tài khoản không tạo thêm hạn mức; chưa gửi Claude.", 409)

    def status_grant(self, db, grant_id):
        """Global remaining amounts only; never reveals other owners or activity."""
        pool = self._pool(db, grant_id)
        if pool is None:
            return None
        return self._status_pool(db, pool)

    def _status_pool(self, db, pool):
        """One read projection for existing children and unactivated approvals."""
        used = self._usage(db, pool["id"])
        active = pool["state"] == "active" and pool["expires_at"] > now_iso()
        remaining = max(0, pool["max_calls"]-used["calls"]) if active else 0
        cost = usage_projection(db.execute("SELECT a.* FROM core_model_attempts a JOIN core_budget_pool_links l ON l.grant_id=a.grant_id WHERE l.pool_id=?",
                                           (pool["id"],)).fetchall())
        return {**cost, "cost_scope": "shared_approved_pool", "pooled": True,
                "state": pool["state"] if active or pool["state"] != "active" else "expired", "active": active,
                "approved": active and remaining > 0 and used["held"] < pool["cap_microusd"],
                "max_calls": pool["max_calls"], "remaining_calls": remaining,
                "max_cost_usd": pool["cap_microusd"]/1e6, "held_usd": used["held"]/1e6,
                "remaining_usd": max(0, pool["cap_microusd"]-used["held"])/1e6 if active else 0,
                "cap_microusd": pool["cap_microusd"], "held_microusd": used["held"],
                "expires_at": pool["expires_at"]}

