"""Explicit, bounded API model clients; never discovers subscription credentials."""
from __future__ import annotations

import re
from typing import Literal

ModelProvider = Literal["openai", "anthropic"]
ANTHROPIC_API_BASE = "https://api.anthropic.com"
OPENAI_API_BASE = "https://api.openai.com/v1"


class ModelProviderError(ValueError):
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def validate_model_configuration(provider: str, model_name: str | None, api_key: str | None) -> None:
    """Validate supplied server configuration without reading env/files or revealing it."""
    if provider not in ("openai", "anthropic"):
        raise ModelProviderError("MODEL_PROVIDER_UNSUPPORTED", "Unsupported model API provider")
    if (
        not isinstance(model_name, str)
        or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}", model_name)
        or model_name.startswith(("sk-", "Bearer"))
    ):
        raise ModelProviderError("MODEL_NAME_INVALID", "An explicit valid API model name is required")
    if not isinstance(api_key, str) or not api_key.strip():
        raise ModelProviderError("MODEL_CREDENTIALS_MISSING", "An explicit server API key is required")
    if provider == "anthropic" and api_key.lstrip().startswith(("sk-ant-oat", "Bearer ")):
        raise ModelProviderError(
            "MODEL_CREDENTIALS_INVALID", "Claude API mode requires an API key, not a subscription/OAuth token"
        )


def classify_model_error(exc: Exception) -> ModelProviderError:
    """Map SDK status/type to a safe code without returning provider error bodies."""
    status = getattr(exc, "status_code", None)
    if status in (401, 403):
        return ModelProviderError("MODEL_AUTHENTICATION_FAILED", "The configured API credential was rejected")
    if status == 404:
        return ModelProviderError("MODEL_NOT_FOUND", "The configured API model/resource was not found")
    if status == 429:
        return ModelProviderError("MODEL_RATE_LIMITED", "The model API is rate limited")
    if status in (408, 504) or "timeout" in type(exc).__name__.lower():
        return ModelProviderError("MODEL_TIMEOUT", "The model API call timed out")
    if "connection" in type(exc).__name__.lower():
        return ModelProviderError("MODEL_UNAVAILABLE", "Unable to connect to the model API")
    if isinstance(status, int) and status >= 500:
        return ModelProviderError("MODEL_UNAVAILABLE", "The model API is unavailable")
    if status == 400:
        return ModelProviderError("MODEL_REQUEST_REJECTED", "The model API rejected the configured request")
    return ModelProviderError("MODEL_OUTPUT_INVALID", "Model call/output failed; no fallback report was published")


def create_chat_model(provider: ModelProvider, model_name: str, api_key: str):
    """Create one API adapter with a 4k output cap, no retry and a 45-second timeout.

    Both clients receive explicit credentials. This module does not read .env,
    Claude Code token stores, browser sessions, subscription auth or CLI config.
    It does not enable built-in remote tools, extended thinking or sampling knobs.
    """
    validate_model_configuration(provider, model_name, api_key)
    try:
        if provider == "anthropic":
            from langchain_anthropic import ChatAnthropic

            return ChatAnthropic(
                model=model_name, api_key=api_key, base_url=ANTHROPIC_API_BASE,
                max_tokens=4000, max_retries=0, timeout=45,
            )
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            model=model_name, api_key=api_key, base_url=OPENAI_API_BASE,
            max_tokens=4000, max_retries=0, timeout=45,
        )
    except Exception:
        # SDK validation/import errors must never expose credential-bearing objects.
        raise ModelProviderError("MODEL_UNAVAILABLE", "Unable to initialize the configured model API adapter") from None
