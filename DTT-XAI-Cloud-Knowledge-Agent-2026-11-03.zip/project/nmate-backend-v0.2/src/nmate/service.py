import asyncio
import logging
import uuid

from .config import Settings
from .models import AppError, Principal, StartInput
from .store import Store

logger = logging.getLogger(__name__)


def public_run(run: dict) -> dict:
    result = {key: value for key, value in run.items() if key not in ("snapshot", "tenant_id", "case_summary")}
    snapshot = run.get("snapshot")
    product = snapshot.get("product") if isinstance(snapshot, dict) else None
    if isinstance(product, dict):
        summary = {key: product[key] for key in ("sku", "name")
                   if isinstance(product.get(key), str) and product[key].strip()}
        if summary:
            result["case_summary"] = summary
    return result


class ResearchService:
    def __init__(self, store: Store, settings: Settings, checkpointer, *, graph_factory=None):
        if graph_factory is None:
            from .agents.shipment.graph import build_graph
            graph_factory = build_graph
        self.store, self.settings, self.checkpointer = store, settings, checkpointer
        self.graph_factory = graph_factory
        self.graph_factories = {"shipment_readiness": graph_factory}
        self.owner = str(uuid.uuid4())
        self.worker_task: asyncio.Task | None = None

    def start(self, principal: Principal, args: StartInput) -> dict:
        if self.settings.mode == "llm" and not self.settings.model_configured:
            raise AppError("MODEL_NOT_CONFIGURED", f"Chưa cấu hình model phù hợp và {self.settings.credential_env_name} trên server.", 503)
        model_name = self.settings.model_name
        routing = None
        if self.settings.mode == "llm" and self.settings.model_provider == "anthropic":
            from .model_routing import ROUTING_POLICY_VERSION, route_model
            case = self.store.get_case(principal, args.case_id)
            decision = route_model(case, args.question, args.processing_level,
                                   simple_model=self.settings.simple_model, complex_model=self.settings.complex_model)
            model_name = decision.model_name
            routing = {"policy_version": ROUTING_POLICY_VERSION, "requested_level": args.processing_level,
                       "selected_level": decision.level, "reason_code": decision.reason_code, "reason": decision.reason}
        return public_run(self.store.start(principal, args.model_dump(), mode=self.settings.mode,
                          max_active=self.settings.max_active_runs, max_daily=self.settings.max_daily_runs,
                          model_name=model_name, model_provider=self.settings.model_provider, routing=routing))

    def get_run(self, p: Principal, run_id: str) -> dict:
        return public_run(self.store.get_run(p, run_id))

    def cancel(self, p: Principal, run_id: str) -> dict:
        return public_run(self.store.cancel(p, run_id))

    async def start_worker(self):
        if self.worker_task is None:
            self.worker_task = asyncio.create_task(self._worker(), name="nmate-shipment-worker")

    async def stop_worker(self):
        if self.worker_task:
            self.worker_task.cancel()
            await asyncio.gather(self.worker_task, return_exceptions=True)
            self.worker_task = None
        self.store.release(self.owner)

    async def _worker(self):
        while True:
            run = self.store.claim(self.owner)
            if run:
                await self.execute_claimed(run)
            else:
                await asyncio.sleep(0.15)

    async def execute_claimed(self, run: dict):
        run_id = run["run_id"]

        async def guard():
            self.store.guard(run_id, self.owner)

        async def monitor():
            counter = 0
            while True:
                await guard()
                if counter % 10 == 0:
                    self.store.progress(run_id, self.owner)
                counter += 1
                await asyncio.sleep(0.2)

        async def pipeline():
            await guard()
            factory = self.graph_factories.get(run["agent_kind"])
            if factory is None:
                raise AppError("AGENT_NOT_AVAILABLE", "Workflow này chưa được triển khai.")
            provider = run.get("model_provider") or "openai"  # Legacy LLM runs were OpenAI-only.
            key = self.settings.api_key_for(provider)
            if run["mode"] == "llm" and not key:
                raise AppError("MODEL_CREDENTIAL_UNAVAILABLE", "Thiếu khóa của nhà cung cấp đã chọn cho lượt chạy; không chuyển sang nhà cung cấp khác.")
            graph = factory(self.checkpointer, mode=run["mode"],
                    model_name=run.get("model_name"),
                    model_provider=provider,
                    api_key=key.get_secret_value() if key and run["mode"] == "llm" else None, guard=guard)
            config = {"configurable": {"thread_id": run_id}, "recursion_limit": 12}
            snapshot = await graph.aget_state(config)
            if snapshot.values.get("report") and not snapshot.next:
                return snapshot.values["report"]
            initial = None if snapshot.values else {"case": run["snapshot"], "question": run["question"]}
            async for update in graph.astream(initial, config, stream_mode="updates"):
                await guard()
                if update:
                    self.store.progress(run_id, self.owner, next(iter(update)))
            final = await graph.aget_state(config)
            return final.values["report"]

        tasks = []
        try:
            async with asyncio.timeout(self.settings.run_timeout_seconds):
                job = asyncio.create_task(pipeline())
                watcher = asyncio.create_task(monitor())
                tasks = [job, watcher]
                done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                if watcher in done:
                    await watcher
                report = await job
                await guard()
                self.store.finish(run_id, self.owner, report=report)
        except asyncio.CancelledError:
            raise  # stop_worker terminally interrupts the reservation; it never resumes paid work automatically.
        except TimeoutError:
            self.store.finish(run_id, self.owner, error={"code": "RUN_TIMEOUT", "message": "Lượt chạy vượt thời gian cho phép."})
        except Exception as exc:
            code = getattr(exc, "code", "RESEARCH_FAILED")
            message = exc.message if isinstance(exc, AppError) else "Không hoàn thành nghiên cứu; hãy xem cấu hình/nguồn và thử lại."
            # Never return SDK exception strings, prompts or credentials to clients.
            logger.warning("research failed code=%s run=%s exception_type=%s", code, run_id, type(exc).__name__)
            self.store.finish(run_id, self.owner, error={"code": code, "message": message})
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            if tasks:
                await asyncio.gather(*tasks, return_exceptions=True)
