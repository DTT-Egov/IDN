import json
from typing import Annotated, Any, Literal

from mcp.server import MCPServer
from mcp.types import CallToolResult, TextContent
from pydantic import BaseModel, ConfigDict, Field

from .auth import principal
from .models import AppError, ArtifactInput, CaseInput, RunInput, StartInput, success
from .service import ResearchService

TOOL_NAMES = {
    "nmate_shipment_readiness_start", "nmate_research_get", "nmate_research_cancel",
    "nmate_artifact_get", "nmate_case_get",
}


class ToolError(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str
    message: str


class ToolEnvelope(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ok: bool
    data: dict[str, Any] | None = None
    error: ToolError | None = None


CaseId = Annotated[str, Field(min_length=1, max_length=128)]
Version = Annotated[int, Field(ge=1)]
RequestKey = Annotated[str, Field(min_length=8, max_length=128)]
Question = Annotated[str, Field(min_length=1, max_length=2000)]
McpResult = Annotated[CallToolResult, ToolEnvelope]


def create_mcp(service: ResearchService) -> MCPServer:
    server = MCPServer("nMate Research", version="0.2.0",
        instructions="Local developer preview. Shipment preparation only; all reports are unreviewed drafts. "
                     "Market and partner agents are planned and are not available tools.")

    def call(operation):
        try:
            payload = success(operation())
        except AppError as exc:
            payload = exc.envelope()
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload, ensure_ascii=False))],
                              structured_content=payload, is_error=not payload["ok"])

    @server.tool(structured_output=True, description="Start bounded US dry-food shipment preparation research from a confirmed case "
                 "snapshot. Returns durable run_id. Requires consent. No customs clearance or compliance certification.")
    async def nmate_shipment_readiness_start(case_id: CaseId, expected_case_version: Version,
                                             idempotency_key: RequestKey,
                                             question: Question = "Cần chuẩn bị gì cho lô hàng thử nghiệm?",
                                             processing_level: Literal["auto", "standard", "complex"] = "auto") -> McpResult:
        args = StartInput(case_id=case_id, expected_case_version=expected_case_version,
                          idempotency_key=idempotency_key, question=question, processing_level=processing_level)
        return call(lambda: service.start(principal(), args))

    @server.tool(structured_output=True, description="Read an authorized research run by explicit run_id, including progress and artifact_id.")
    async def nmate_research_get(run_id: CaseId) -> McpResult:
        return call(lambda: service.get_run(principal(), RunInput(run_id=run_id).run_id))

    @server.tool(structured_output=True, description="Request cancellation. cancel_requested=true does not mean the worker has stopped; "
                 "poll until terminal status. A completed draft is not deleted.")
    async def nmate_research_cancel(run_id: CaseId) -> McpResult:
        return call(lambda: service.cancel(principal(), RunInput(run_id=run_id).run_id))

    @server.tool(structured_output=True, description="Read an authorized immutable draft artifact with evidence, gaps, candidate source "
                 "review status and stale flag. Research success is not human approval.")
    async def nmate_artifact_get(artifact_id: CaseId) -> McpResult:
        return call(lambda: service.store.get_artifact(principal(), ArtifactInput(artifact_id=artifact_id).artifact_id))

    @server.tool(structured_output=True, description="Read an authorized confirmed case snapshot. User-provided parties remain unverified.")
    async def nmate_case_get(case_id: CaseId) -> McpResult:
        return call(lambda: service.store.get_case(principal(), CaseInput(case_id=case_id).case_id))

    return server
