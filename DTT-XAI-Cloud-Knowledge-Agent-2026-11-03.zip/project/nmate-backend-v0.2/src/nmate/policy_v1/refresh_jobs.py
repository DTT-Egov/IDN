"""Durable daily HTTP acquisition, without model/notification/review authority."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

from nmate.v03.core import CoreError, json_text, new_id, now_iso

SCHEMA = """
CREATE TABLE IF NOT EXISTS pol_refresh_jobs (
 id TEXT PRIMARY KEY,source_id TEXT NOT NULL UNIQUE REFERENCES pol_sources(id),
 enabled INTEGER NOT NULL DEFAULT 1,state TEXT NOT NULL DEFAULT 'scheduled',
 interval_seconds INTEGER NOT NULL CHECK(interval_seconds>=3600),next_due_at TEXT NOT NULL,
 lease_id TEXT,lease_until TEXT,failure_count INTEGER NOT NULL DEFAULT 0,
 authorized_by TEXT NOT NULL,authorization_basis TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_refresh_job_events (
 id TEXT PRIMARY KEY,job_id TEXT NOT NULL REFERENCES pol_refresh_jobs(id),lease_id TEXT NOT NULL,
 status TEXT NOT NULL,result_json TEXT NOT NULL,recorded_at TEXT NOT NULL);
"""


class SourceRefreshJobs:
    def __init__(self, catalog):
        self.catalog, self.repo = catalog, catalog.repo
        with self.repo.connection(write=True) as db:
            db.executescript(SCHEMA)

    def schedule(self, actor_id, source_id, *, interval_seconds=86400):
        if not isinstance(interval_seconds, int) or isinstance(interval_seconds, bool) or interval_seconds < 3600:
            raise CoreError("invalid_refresh_interval", "Nhịp kiểm nguồn tối thiểu một giờ; mặc định mỗi ngày.")
        with self.repo.connection(write=True) as db:
            self.catalog._authority(db, actor_id, "curator")
            source = db.execute("SELECT * FROM pol_sources WHERE id=? AND usage_scope='public'", (source_id,)).fetchone()
            if not source:
                raise CoreError("not_found", "Chưa có nguồn chính thức công khai này.", 404)
            self.catalog._url(source["url"])
            self._insert(db, source_id, actor_id, "explicit_curator_schedule", interval_seconds, now_iso())
        return {"source_id": source_id, "interval_seconds": interval_seconds, "provider_calls": 0}

    def bootstrap_official_notice(self):
        """User-approved source acquisition design; does not invent an expert reviewer."""
        source = self.catalog.get_source("HN-NOTICE-2026-14")
        with self.repo.connection(write=True) as db:
            snapshot = db.execute("SELECT retrieved_at FROM pol_source_snapshots WHERE id=?", (source["current_snapshot_id"],)).fetchone()
            retrieved = datetime.fromisoformat(snapshot["retrieved_at"])
            next_due = (retrieved + timedelta(days=1)).astimezone(timezone.utc).isoformat()
            self._insert(db, source["id"], "system:source-acquisition", "approved_design_official_source_acquisition", 86400, next_due)

    @staticmethod
    def _insert(db, source_id, actor, basis, interval, next_due):
        db.execute("INSERT OR IGNORE INTO pol_refresh_jobs VALUES(?,?,1,'scheduled',?,?,NULL,NULL,0,?,?,?)",
                   (new_id("refresh_job"), source_id, interval, next_due, actor, basis, now_iso()))

    def list(self, actor_id):
        with self.repo.connection() as db:
            self.catalog._authority(db, actor_id, "curator")
            return [dict(row) for row in db.execute("SELECT * FROM pol_refresh_jobs ORDER BY next_due_at")]

    def disable(self, actor_id, source_id):
        with self.repo.connection(write=True) as db:
            self.catalog._authority(db, actor_id, "curator")
            db.execute("UPDATE pol_refresh_jobs SET enabled=0,updated_at=? WHERE source_id=?", (now_iso(), source_id))
        return {"source_id": source_id, "enabled": False}

    async def execute_next(self):
        now = now_iso()
        with self.repo.connection(write=True) as db:
            # Repeating an interrupted HTTP fetch is free and cannot publish a rule.
            db.execute("UPDATE pol_refresh_jobs SET state='scheduled',lease_id=NULL,lease_until=NULL "
                       "WHERE state='running' AND lease_until<=?", (now,))
            job = db.execute("SELECT * FROM pol_refresh_jobs WHERE enabled=1 AND state='scheduled' AND next_due_at<=? "
                             "ORDER BY next_due_at LIMIT 1", (now,)).fetchone()
            if not job:
                return None
            lease_id = new_id("http_lease")
            until = (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()
            db.execute("UPDATE pol_refresh_jobs SET state='running',lease_id=?,lease_until=?,updated_at=? WHERE id=? AND state='scheduled'",
                       (lease_id, until, now, job["id"]))
        try:
            result = await asyncio.to_thread(self.catalog.refresh_source, "system:source-acquisition", job["source_id"], internal_job_id=job["id"])
        except Exception as exc:
            result = {"source_id": job["source_id"], "state": "unavailable", "reason_code": getattr(exc, "code", "SOURCE_REFRESH_FAILED"), "provider_calls": 0}
            with self.repo.connection(write=True) as db:
                source = db.execute("SELECT current_snapshot_id FROM pol_sources WHERE id=?", (job["source_id"],)).fetchone()
                self.catalog._observation(db, "system:source-acquisition", job["source_id"], source[0], "job_failed", "unavailable", None, result["reason_code"])
        failed = result.get("state") == "unavailable"
        failures = job["failure_count"] + 1 if failed else 0
        interval = min(job["interval_seconds"], 900 * (2 ** min(failures - 1, 6))) if failed else job["interval_seconds"]
        due = (datetime.now(timezone.utc) + timedelta(seconds=interval)).isoformat()
        with self.repo.connection(write=True) as db:
            changed = db.execute("UPDATE pol_refresh_jobs SET state='scheduled',next_due_at=?,lease_id=NULL,lease_until=NULL,"
                                 "failure_count=?,updated_at=? WHERE id=? AND lease_id=? AND enabled=1",
                                 (due, failures, now_iso(), job["id"], lease_id)).rowcount
            db.execute("INSERT INTO pol_refresh_job_events VALUES(?,?,?,?,?,?)", (new_id("refresh_event"), job["id"], lease_id,
                       "recorded" if changed else "stale_lease", json_text(result), now_iso()))
        return result
