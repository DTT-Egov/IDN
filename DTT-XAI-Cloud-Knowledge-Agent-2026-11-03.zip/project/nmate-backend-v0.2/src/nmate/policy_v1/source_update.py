"""Read-only public-source addendum to a stored policy answer.

No inference, financial projection, SSOT write, approval or publication. Stored
Claude selections, legal outcomes and provider receipts remain byte-for-byte
unchanged. The addendum is visibly a separate acquisition/guide layer.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


PACK_PATH = Path(__file__).parent / "data/hanoi_digital_source_pack.json"
NOTICE_ID = "HN-NOTICE-2026-14"
ATTACHMENT_ID = "HN-NOTICE-2026-14-ATTACHMENT"
POLICY_ID = "HN-DIGITAL-CONSULTING-2026"
PROGRAM_SOURCE_IDS = frozenset({NOTICE_ID, ATTACHMENT_ID, "VN-DECREE-80-2021-SCAN", "VN-CIRCULAR-06-2022-GAZETTE"})
GUIDE_PAGES = {ATTACHMENT_ID: {9}, "VN-DECREE-80-2021-SCAN": {6}, "VN-CIRCULAR-06-2022-GAZETTE": {6}}


def _quote(chunk, source_id):
    text = chunk["text_original"]
    # The contact cell is the one passage used by this business guide. Keep
    # the exact original substring, including line breaks, for verification.
    if source_id == ATTACHMENT_ID and "Bà Lương Mỹ Hạnh" in text:
        start = text.rfind("(i) Trung tâm", 0, text.index("Bà Lương Mỹ Hạnh"))
        end = text.index("(ii) Công ty", start)
        return text[start:end].strip()
    if source_id == "VN-CIRCULAR-06-2022-GAZETTE" and "Điều 5. Hướng dẫn" in text:
        start = text.index("Điều 5. Hướng dẫn")
        end = text.index("2. Đối v", start)
        return text[start:end].strip()
    return text


def build_source_update(catalog, payload):
    intent = (payload.get("scope_update") or {}).get("intent") or payload.get("intent", {})
    goals = intent.get("goals") or [intent.get("goal")]
    if intent.get("goal") != goals[0]:
        return None
    if not set(goals).intersection({"digital_inventory", "digital_transformation"}):
        return None
    if not any(source.get("source_id", source.get("id")) in {NOTICE_ID, ATTACHMENT_ID}
               for source in payload.get("sources", [])):
        return None
    pack = json.loads(PACK_PATH.read_text(encoding="utf8"))
    sources = []
    with catalog.repo.connection() as db:
        active_roles = {row[0] for row in db.execute("SELECT DISTINCT r.role FROM pol_knowledge_roles r "
            "JOIN v03_accounts a ON a.id=r.account_id WHERE r.domain='hanoi_policy' "
            "AND r.revoked_at IS NULL AND a.active=1 AND r.role IN ('reviewer','publisher','admin')")}
        has_reviewer = bool(active_roles & {"reviewer", "admin"})
        has_publisher = bool(active_roles & {"publisher", "admin"})
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='pol_knowledge_role_scopes'").fetchone():
            scoped_sources = {}
            for row in db.execute("SELECT r.account_id,r.role,r.source_id FROM pol_knowledge_role_scopes r "
                "JOIN v03_accounts a ON a.id=r.account_id WHERE r.domain='hanoi_policy' AND r.policy_id=? "
                "AND r.revoked_at IS NULL AND a.active=1 AND r.role IN ('reviewer','publisher')", (POLICY_ID,)):
                scoped_sources.setdefault(row["role"], {}).setdefault(row["account_id"], set()).add(row["source_id"])
            has_reviewer = has_reviewer or any(PROGRAM_SOURCE_IDS <= sources for sources in scoped_sources.get("reviewer", {}).values())
            has_publisher = has_publisher or any(PROGRAM_SOURCE_IDS <= sources for sources in scoped_sources.get("publisher", {}).values())
        for document in pack["documents"]:
            source = db.execute("SELECT s.*,p.id snapshot_id,p.raw_sha256,p.text_sha256,g.availability,g.checked_at "
                "FROM pol_sources s JOIN pol_source_snapshots p ON p.id=s.current_snapshot_id "
                "LEFT JOIN pol_source_gates g ON g.source_id=s.id WHERE s.id=?", (document["source_id"],)).fetchone()
            # Do not use an old packaged contact when acquisition has changed,
            # withdrawn or failed, or the catalog no longer matches its bytes.
            if (not source or source["availability"] in {"changed", "superseded", "unavailable"} or
                    source["raw_sha256"] != document["raw_sha256"] or
                    source["text_sha256"] != document["canonical_text_sha256"]):
                if document["source_id"] == ATTACHMENT_ID:
                    return None
                continue
            chunks = []
            for row in db.execute("SELECT * FROM pol_chunks WHERE snapshot_id=? ORDER BY ordinal", (source["snapshot_id"],)):
                chunk = dict(row)
                locator = json.loads(chunk["locator_json"])
                if locator.get("page") not in GUIDE_PAGES.get(document["source_id"], set()):
                    continue
                # The guide uses the contact passage at page 9. The remaining
                # attachment pages remain available as explicitly labeled text.
                quote = _quote(chunk, document["source_id"])
                if not quote or quote not in chunk["text_original"]:
                    continue
                chunks.append({"chunk_id": chunk["id"], "source_id": source["id"],
                    "source_snapshot_id": source["snapshot_id"], "quote_original": quote,
                    "quote_original_hash": hashlib.sha256(quote.encode()).hexdigest(),
                    "span_hash": chunk["span_hash"], "locator": locator})
            if not chunks:
                continue
            # Show the contact cell first, not a full repeated multi-column page.
            if source["id"] == ATTACHMENT_ID:
                chunks.sort(key=lambda c: c["locator"]["page"] != 9)
            sources.append({"id": source["id"], "source_id": source["id"], "title": source["title"],
                "agency": source["agency"], "url": source["url"], "language": "vi",
                "source_snapshot_id": source["snapshot_id"], "checked_at": document["retrieved_at"],
                "publication_date": document["published_at"], "availability": source["availability"],
                "review_status": "Nguồn đọc thêm; chưa duyệt thành quy tắc tư vấn", "legal_currency": "not_verified",
                "identity_note_vi": document["identity_note_vi"], "all_pages_extracted": document["all_pages_extracted"],
                "excerpt_vi": chunks[0]["quote_original"], "excerpt_original": chunks[0]["quote_original"],
                "chunks": chunks, "provider_used": False})
    attachment = next((s for s in sources if s["id"] == ATTACHMENT_ID), None)
    contact_citation = next((c for c in attachment["chunks"] if c["locator"]["page"] == 9), None) if attachment else None
    if not contact_citation or not all(term in contact_citation["quote_original"] for term in
                                      ("Bà Lương Mỹ Hạnh", "0919140820", "hanhluong940@gmail.com")):
        return None
    inventory = "digital_inventory" in goals
    need = "quy trình quản lý kho và theo dõi nhập–xuất–tồn" if inventory else "quy trình vận hành và chuyển đổi số của doanh nghiệp"
    topic = "số hóa kho" if inventory else "chuyển đổi số"
    uncovered_goals = [goal for goal in goals if goal not in {"digital_inventory", "digital_transformation"}]
    gap = (" Phần phát triển thị trường / xuất khẩu chưa có nguồn chương trình riêng trong danh mục này."
           if "market_development" in uncovered_goals else "")
    if "equipment_purchase" in uncovered_goals:
        gap += " Nguồn tư vấn này chưa chứng minh có hỗ trợ mua thiết bị."
    questions = [
        "Phụ lục 03 chương trình tư vấn giải pháp chuyển đổi số năm 2026 còn nhận hồ sơ và còn chỉ tiêu không?",
        f"Nhu cầu tư vấn {need} có thuộc phạm vi chương trình đang tiếp nhận không?",
        "Xin xác nhận mẫu tờ khai, giấy tờ cần cho trường hợp này và kênh nộp đang áp dụng; có đường dẫn thủ tục cụ thể không?",
    ]
    action = {"kind": "prepare_program_enquiry", "title_vi": "Xác minh chương trình trước khi chuẩn bị hồ sơ",
        "description_vi": f"Đầu mối trong tài liệu công bố: bà Lương Mỹ Hạnh, Trung tâm Xúc tiến đầu tư và Hỗ trợ doanh nghiệp Hà Nội. Hỏi tình trạng tiếp nhận và phạm vi tư vấn {topic} trước; chưa có kết luận doanh nghiệp đủ điều kiện." + gap,
        "button_label_vi": "Xem cách xác minh và chuẩn bị trao đổi",
        "source_ids": [ATTACHMENT_ID], "citations": [contact_citation],
        "contact": {"name_vi": "Bà Lương Mỹ Hạnh", "phone": "0919140820", "email": "hanhluong940@gmail.com",
                    "verification_state": "published_contact_not_currently_confirmed"},
        "questions_vi": questions,
        "draft_message_vi": f"Chào anh/chị, doanh nghiệp tôi muốn tìm hiểu chương trình tư vấn giải pháp chuyển đổi số tại Phụ lục 03 năm 2026 để cải thiện {need}. Xin anh/chị xác nhận chương trình còn chỉ tiêu, nhu cầu này có thuộc phạm vi tiếp nhận, và mẫu/kênh nộp hiện hành. Tôi đang tìm hiểu trước, chưa coi đây là hồ sơ được duyệt. Cảm ơn anh/chị.",
        "automatic_submission": False, "automatic_contact": False, "provider_calls": 0}
    authority_status = ("Chờ rà căn cứ và phát hành quy tắc đúng phiên bản" if has_reviewer and has_publisher else
                        "Chưa có người " + " và người ".join(
                            [label for label, present in (("rà", has_reviewer), ("phát hành", has_publisher)) if not present]) + " được phân công")
    # A charged/failed attempt is not a saved Claude answer. The service sets
    # provider_used only after a validated answer has been published.
    saved_model = payload.get("provider_used") is True
    attempted_model = bool(payload.get("provider_attempted") or payload.get("provider_calls") or payload.get("provider_receipt"))
    scope = ("Hướng dẫn từ nguồn mới đọc thêm, không gọi Claude. Giữ nguyên kết quả Claude đã lưu; " if saved_model else
             "Hướng dẫn từ nguồn đã lưu, không gọi thêm Claude. Lượt trước chưa có kết quả Claude được công bố; " if attempted_model else
             "Hướng dẫn từ nguồn đã lưu, chưa gọi Claude; ")
    return {"schema_version": "policy-source-update/1", "method": "deterministic_official_source_update/1",
        "provider_used": False, "provider_calls": 0, "checked_at": pack["recorded_at"],
        "lead_vi": f"Đã đọc thêm Phụ lục 03 và căn cứ liên quan: có đầu mối để hỏi về tư vấn {topic}. Bước tiếp theo là xác minh còn chỉ tiêu và phạm vi tiếp nhận." + gap,
        "scope_vi": scope + "chưa xác nhận đủ điều kiện, mức hỗ trợ hoặc hồ sơ nộp chính thức." + gap,
        "covered_goals": [goal for goal in goals if goal in {"digital_inventory", "digital_transformation"}],
        "uncovered_goals": uncovered_goals, "saved_model_result_present": saved_model,
        "source_ids": [s["id"] for s in sources], "sources": sources, "business_next_action": action,
        "pending_system_work": [
            {"title_vi": "Xác minh văn bản áp dụng và quy tắc điều kiện", "reason_vi": "PDF đính kèm để trống số/ngày/chữ ký. Cần bản có căn cứ áp dụng và rà sửa đổi Nghị định 80/2021, Thông tư 06/2022 trước khi duyệt điều kiện/checklist.", "status_vi": authority_status},
            {"title_vi": "Xác nhận tình trạng tiếp nhận", "reason_vi": "Thông báo ghi đến khi đủ chỉ tiêu; chưa có xác nhận còn chỉ tiêu tại ngày hỏi.", "status_vi": "Chưa xác minh"}],
        "eligibility_state": "awaiting_rule_review", "application_status": "unknown",
        "authority_state": {"reviewer_assigned": has_reviewer, "publisher_assigned": has_publisher,
                            "rule_approval_inferred": False},
        "does_not_replace_saved_claude": True, "changes_legal_verdict": False}
