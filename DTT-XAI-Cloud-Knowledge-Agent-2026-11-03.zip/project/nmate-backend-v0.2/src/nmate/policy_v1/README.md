# Lõi chính sách Hà Nội — lát cắt triển khai

`PolicyService(repo, core, gateway)` dùng kho SQL hiện có. Không có graph/vector database hoặc embedding. `prepare/get/list` không gọi mô hình. `start` chỉ đưa một công việc vào hàng đợi sau kiểm đúng hạn mức, tác vụ, model và liên kết chat; `execute_next` chạy DAG LangGraph cố định qua Model Gateway. Tải lại không gửi lại yêu cầu; một hồ sơ đã chạy không tự tạo lượt có phí mới.

API chuẩn bị có `conversation_id` và callback nội bộ `on_commit(db, payload)` để ghi chat–hồ sơ–operation cùng một giao dịch. Callback không là đối số MCP có thể cung cấp từ client. Tài nguyên chính sách là riêng theo tài khoản trong doanh nghiệp; quyền đọc SSOT không mở chat. Mỗi lần mở báo cáo kiểm lại toàn bộ **refs đã dùng**, gồm quyền nhóm trường hiện tại.

`KnowledgeCatalog` quản lý nguồn công cộng, bytes/hash, extraction, đoạn/nguyên văn/locator/hash, FTS5 và alias tiếng Việt. Tri thức doanh nghiệp không được đưa vào chỉ mục công cộng. Các cạnh SQL ghi quy tắc–dữ kiện, quy tắc–nguồn và pack–phiên bản; FTS là chỉ mục dựng lại được. Nguyên bản khác tiếng Việt không được trình bày như bản dịch; có cổng bản dịch manual gắn đúng hash và duyệt riêng.

DSL hữu hạn dùng bốn trạng thái `met/not_met/unknown/conflict`, giữ `null`, `false`, `0`, scope, đơn vị, kỳ và số thập phân riêng. Rules/typed claims phải có scope và căn cứ chính cho từng điều kiện/mục. Review, publication, pack release và source-current gates là các bước độc lập. Không bootstrap vai chuyên gia hoặc sự kiện duyệt. D07-A chặn riêng member/outcome phụ thuộc; phần độc lập vẫn chạy. Báo cáo lịch sử giữ nguyên, bổ sung cảnh báo hiện hành khi nguồn/quy tắc đổi.

## Nguồn thật và ranh giới hiện tại

`data/notice_2026_14.html` là bytes thực lấy từ cổng Hỗ trợ doanh nghiệp Hà Nội ngày 19/10/2026. JSON đi kèm giữ URL, thời điểm, raw hash và text extraction. Thông báo và các đoạn phụ lục đã lưu chỉ được dùng trong phạm vi đã đọc, có snapshot/chunk/hash. Chưa có quy tắc/claim/pack được chuyên gia thật duyệt để kết luận riêng về điều kiện, mức tiền, giấy tờ hoặc chỉ tiêu còn lại. Thông tin chương trình tư vấn không đồng nghĩa hỗ trợ mua thiết bị.

`SourceRefreshJobs` có lịch HTTP mỗi ngày cho nguồn thông báo đã đăng ký, lease/recovery và backoff lỗi bền vững. Service principal chỉ được lấy nguồn trong job đã cấp; không có quyền duyệt/phát hành, không gọi mô hình/dịch/OCR hoặc gửi thông báo ra ngoài. Nguồn mới/đổi trở về hàng chờ rà; HTTP 200 không xác nhận hiệu lực hay đang nhận hồ sơ.

**D05:** lượt policy synthesis hiện chưa nối manifest tài chính đã cho phép. Vì vậy, câu hỏi có tài chính, dữ liệu dạng bảng dán vào chat hoặc bất kỳ điều kiện dẫn xuất từ facts tài chính/hạn chế đều dừng trước Gateway. Không gửi cả `met/not_met` của chỉ tiêu tài chính ngầm. Các bước parser/preview/egress tài chính của lõi được triển khai riêng, không được coi là đã nối vào prompt này.

**D06:** không có ngân sách hay provider dispatch tự phát. Tests dùng request function/fixture có nhãn trong DB tạm; không phải kiểm chất lượng Claude thật. Không có tự retry, model fallback hoặc nâng model sau lỗi có phí. Lỗi sau yêu cầu Gateway giữ trạng thái phí chưa rõ cho đến khi xem ledger; không ghi “chưa gọi Claude” như kết luận chắc chắn.

Hợp đồng `policy-model-analysis/2`: Claude chọn bằng chứng phù hợp từng ý, xếp thứ tự công việc nghiên cứu và chọn câu hỏi SSOT còn thiếu từ tập ứng viên được kiểm soát. Các quyết định thực được lưu và hiển thị trong `model_analysis`; server dựng trích dẫn bằng toàn bộ đoạn nguồn bất biến. Kết luận pháp lý vẫn theo các cổng quy tắc/nguồn, với `changes_legal_verdict=false`. Không buộc Claude chép lại văn xuôi canonical như hợp đồng v1, và không cho mô hình tự phát hành quyền lợi pháp lý.

Câu hỏi gốc luôn ở SQL/chat riêng; prompt chỉ chứa mục tiêu/outcomes và phân loại doanh nghiệp phi tài chính hữu hạn. Các nhóm alias loại hình, tỉnh đăng ký và ngành hoạt động được đọc từ SSOT doanh nghiệp với refs gốc, không ghi lại dữ kiện. Xung đột/thiếu quyền đọc thì fail closed; dữ kiện pháp lý trên sản phẩm không được coi là dữ kiện doanh nghiệp. DSL giữ nguyên giá trị khai báo; phân loại enum cho mô hình không tạo ra tương đương pháp lý.

Nghiệm thu Claude thật được ghi riêng trong [walkthrough app chính](<../../../../../REFERENCE_LINKS.md#ref-0001>), gồm receipt, usage và giới hạn. Đây vẫn là nghiên cứu có phạm vi, chưa phải nghiên cứu pháp lý mở.
