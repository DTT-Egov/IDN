"""Canonical public-source retrieval and reviewed knowledge graph on SQLite.

Only public domain material belongs here. Private enterprise context stays in
the core repository and is never indexed or promoted by these operations.
"""
from __future__ import annotations

from datetime import date, datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import re
import socket
import ipaddress
import unicodedata
from urllib.parse import urlsplit

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from .rules import evaluate, expression_fields, validate_expression
from .knowledge_graph import DomainGraph, GOALS, validate_member_payload


def digest(value):
    raw = value if isinstance(value, bytes) else json_text(value).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def normalize(value):
    value = unicodedata.normalize("NFD", value.casefold().replace("đ", "d"))
    return " ".join(re.findall(r"[a-z0-9]+", "".join(c for c in value if not unicodedata.combining(c))))


SCHEMA = """
CREATE TABLE IF NOT EXISTS pol_knowledge_roles (
 account_id TEXT NOT NULL REFERENCES v03_accounts(id), role TEXT NOT NULL,
 domain TEXT NOT NULL DEFAULT 'hanoi_policy', granted_by TEXT NOT NULL,
 granted_at TEXT NOT NULL, revoked_at TEXT, PRIMARY KEY(account_id,role,domain));
CREATE TABLE IF NOT EXISTS pol_knowledge_role_scopes (
 account_id TEXT NOT NULL REFERENCES v03_accounts(id),role TEXT NOT NULL CHECK(role IN ('reviewer','publisher')),
 domain TEXT NOT NULL DEFAULT 'hanoi_policy',policy_id TEXT NOT NULL,
 source_id TEXT NOT NULL REFERENCES pol_sources(id),granted_by TEXT NOT NULL,granted_at TEXT NOT NULL,revoked_at TEXT,
 PRIMARY KEY(account_id,role,domain,policy_id,source_id));
CREATE TABLE IF NOT EXISTS pol_sources (
 id TEXT PRIMARY KEY, title TEXT NOT NULL, agency TEXT NOT NULL, url TEXT NOT NULL,
 domain TEXT NOT NULL, jurisdiction TEXT NOT NULL, language TEXT NOT NULL,
 source_kind TEXT NOT NULL, usage_scope TEXT NOT NULL CHECK(usage_scope='public'),
 metadata_json TEXT NOT NULL, current_snapshot_id TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_source_snapshots (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id),
 raw_bytes BLOB NOT NULL, raw_sha256 TEXT NOT NULL, canonical_text TEXT NOT NULL,
 text_sha256 TEXT NOT NULL, extraction_version TEXT NOT NULL, mime_type TEXT NOT NULL,
 retrieved_at TEXT NOT NULL, published_at TEXT, effective_from TEXT, effective_until TEXT,
 complete_policy INTEGER NOT NULL DEFAULT 0, acceptance_state TEXT NOT NULL,
 UNIQUE(source_id,raw_sha256,text_sha256,extraction_version));
CREATE TABLE IF NOT EXISTS pol_source_gates (
 source_id TEXT PRIMARY KEY REFERENCES pol_sources(id), availability TEXT NOT NULL,
 checked_at TEXT NOT NULL, current_until TEXT, reason_code TEXT NOT NULL,
 observation_id TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS pol_source_observations (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id),
 snapshot_id TEXT, actor_id TEXT NOT NULL, trigger_kind TEXT NOT NULL,
 result TEXT NOT NULL, details_json TEXT NOT NULL, checked_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_chunks (
 id TEXT PRIMARY KEY, snapshot_id TEXT NOT NULL REFERENCES pol_source_snapshots(id),
 ordinal INTEGER NOT NULL, start_offset INTEGER NOT NULL, end_offset INTEGER NOT NULL,
 text_original TEXT NOT NULL, quote_hash TEXT NOT NULL, locator_json TEXT NOT NULL,
 span_hash TEXT NOT NULL, UNIQUE(snapshot_id,ordinal));
CREATE VIRTUAL TABLE IF NOT EXISTS pol_chunks_fts USING fts5(chunk_id UNINDEXED, search_text);
CREATE TABLE IF NOT EXISTS pol_translations (
 id TEXT PRIMARY KEY,chunk_id TEXT NOT NULL REFERENCES pol_chunks(id),
 original_quote_hash TEXT NOT NULL,text_vi TEXT NOT NULL,text_hash TEXT NOT NULL,
 method TEXT NOT NULL,actor_id TEXT NOT NULL,review_state TEXT NOT NULL,
 reviewed_by TEXT,recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_aliases (
 phrase TEXT PRIMARY KEY, expansions_json TEXT NOT NULL, version TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_members (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('rule','claim')),
 policy_id TEXT NOT NULL, title_vi TEXT NOT NULL, payload_json TEXT NOT NULL,
 evidence_json TEXT NOT NULL, content_hash TEXT NOT NULL, review_state TEXT NOT NULL,
 publication_state TEXT NOT NULL, availability TEXT NOT NULL, effective_from TEXT,
 effective_until TEXT, created_by TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_review_events (
 id TEXT PRIMARY KEY, member_id TEXT NOT NULL REFERENCES pol_members(id),
 content_hash TEXT NOT NULL, actor_id TEXT NOT NULL, decision TEXT NOT NULL,
 rationale TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_publication_events (
 id TEXT PRIMARY KEY, member_id TEXT NOT NULL REFERENCES pol_members(id),
 content_hash TEXT NOT NULL, review_event_id TEXT NOT NULL REFERENCES pol_review_events(id),
 actor_id TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_packs (
 id TEXT PRIMARY KEY, title_vi TEXT NOT NULL, manifest_json TEXT NOT NULL,
 manifest_hash TEXT NOT NULL, publication_state TEXT NOT NULL,
 availability TEXT NOT NULL, release_event_id TEXT, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_release_events (
 id TEXT PRIMARY KEY, pack_id TEXT NOT NULL REFERENCES pol_packs(id),
 manifest_hash TEXT NOT NULL, actor_id TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pol_graph_edges (
 from_kind TEXT NOT NULL, from_id TEXT NOT NULL, relation TEXT NOT NULL,
 to_kind TEXT NOT NULL, to_id TEXT NOT NULL, dependency_hash TEXT NOT NULL,
 PRIMARY KEY(from_kind,from_id,relation,to_kind,to_id));
CREATE TABLE IF NOT EXISTS pol_retrieval_runs (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 account_id TEXT NOT NULL REFERENCES v03_accounts(id), mission_id TEXT,
 query_hash TEXT NOT NULL, query_json TEXT NOT NULL, result_json TEXT NOT NULL,
 created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS pol_edges_to ON pol_graph_edges(to_kind,to_id);
CREATE TRIGGER IF NOT EXISTS pol_snapshots_immutable BEFORE UPDATE ON pol_source_snapshots
 BEGIN SELECT RAISE(ABORT,'immutable source snapshot'); END;
CREATE TRIGGER IF NOT EXISTS pol_chunks_immutable BEFORE UPDATE ON pol_chunks
 BEGIN SELECT RAISE(ABORT,'immutable source chunk'); END;
CREATE TRIGGER IF NOT EXISTS pol_member_content_immutable BEFORE UPDATE OF kind,policy_id,title_vi,payload_json,evidence_json,content_hash,effective_from,effective_until ON pol_members
 BEGIN SELECT RAISE(ABORT,'immutable knowledge version'); END;
CREATE TRIGGER IF NOT EXISTS pol_reviews_immutable BEFORE UPDATE ON pol_review_events
 BEGIN SELECT RAISE(ABORT,'immutable review event'); END;
CREATE TRIGGER IF NOT EXISTS pol_publications_immutable BEFORE UPDATE ON pol_publication_events
 BEGIN SELECT RAISE(ABORT,'immutable publication event'); END;
CREATE TRIGGER IF NOT EXISTS pol_releases_immutable BEFORE UPDATE ON pol_release_events
 BEGIN SELECT RAISE(ABORT,'immutable release event'); END;
"""


class KnowledgeCatalog:
    def __init__(self, repo):
        self.repo = repo
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)
            if getattr(repo, "managed_runtime", False):
                return
            aliases = {
                "so hoa kho": ["chuyen doi so", "tu van", "giai phap"],
                "quan ly kho": ["chuyen doi so", "tu van"],
                "mua may": ["thiet bi", "may moc"],
                "ho so": ["dang ky", "phu luc", "nop"],
                "con nhan": ["thoi han", "chi tieu", "tiep nhan"],
            }
            for phrase, expansions in aliases.items():
                db.execute("INSERT OR IGNORE INTO pol_aliases VALUES(?,?,?)", (phrase, json_text(expansions), "hanoi-alias/1"))

    @staticmethod
    def _has_global_authority(db, actor_id, role):
        row = db.execute("SELECT 1 FROM pol_knowledge_roles r JOIN v03_accounts a ON a.id=r.account_id "
                         "WHERE r.account_id=? AND r.role IN (?, 'admin') AND r.domain='hanoi_policy' "
                         "AND r.revoked_at IS NULL AND a.active=1", (actor_id, role)).fetchone()
        return row is not None

    @staticmethod
    def _authority(db, actor_id, role):
        if not KnowledgeCatalog._has_global_authority(db, actor_id, role):
            raise CoreError("knowledge_forbidden", "Chưa được cấp vai trò quản trị tri thức này.", 403)

    @staticmethod
    def _member_authority(db, actor_id, role, member):
        if KnowledgeCatalog._has_global_authority(db, actor_id, role):
            return
        # A scoped reviewer/publisher has no authority over shared sources,
        # other programs or a member that mixes in unassigned evidence.
        required = {item["source_id"] for item in json.loads(member["evidence_json"])}
        assigned = {row[0] for row in db.execute("SELECT r.source_id FROM pol_knowledge_role_scopes r "
            "JOIN v03_accounts a ON a.id=r.account_id WHERE r.account_id=? AND r.role=? "
            "AND r.domain='hanoi_policy' AND r.policy_id=? AND r.revoked_at IS NULL AND a.active=1",
            (actor_id, role, member["policy_id"]))}
        if not required or not required <= assigned:
            raise CoreError("knowledge_forbidden", "Chưa được cấp vai trò đúng chương trình và toàn bộ nguồn của phiên bản này.", 403)

    @staticmethod
    def _scope_targets(role, policy_id, source_ids):
        if (role not in {"reviewer", "publisher"} or not isinstance(policy_id, str) or
                not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{2,127}", policy_id) or
                not isinstance(source_ids, list) or not 1 <= len(source_ids) <= 20 or
                any(not isinstance(value, str) or not value or len(value) > 200 for value in source_ids)):
            raise CoreError("invalid_knowledge_scope", "Cần vai trò rà/phát hành, mã chương trình và danh sách nguồn rõ ràng.")
        return sorted(set(source_ids))

    def grant_role(self, actor_id, account_id, role, *, policy_id=None, source_ids=None):
        if role not in {"curator", "reviewer", "publisher"}:
            raise CoreError("invalid_role", "Vai trò chưa được hỗ trợ.")
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "admin")
            if policy_id is not None or source_ids is not None:
                sources = self._scope_targets(role, policy_id, source_ids)
                for source_id in sources:
                    if db.execute("SELECT 1 FROM pol_sources WHERE id=?", (source_id,)).fetchone() is None:
                        raise CoreError("source_not_found", "Chưa có nguồn trong phạm vi được giao.", 404)
                    db.execute("INSERT INTO pol_knowledge_role_scopes VALUES(?,?,'hanoi_policy',?,?,?,?,NULL) "
                               "ON CONFLICT(account_id,role,domain,policy_id,source_id) DO UPDATE SET "
                               "granted_by=excluded.granted_by,granted_at=excluded.granted_at,revoked_at=NULL",
                               (account_id, role, policy_id, source_id, actor_id, now_iso()))
                return {"account_id": account_id, "role": role, "policy_id": policy_id, "source_ids": sources, "scope": "program_sources"}
            db.execute("INSERT INTO pol_knowledge_roles VALUES(?,?,'hanoi_policy',?,?,NULL) "
                       "ON CONFLICT(account_id,role,domain) DO UPDATE SET granted_by=excluded.granted_by,"
                       "granted_at=excluded.granted_at,revoked_at=NULL", (account_id, role, actor_id, now_iso()))
        return {"account_id": account_id, "role": role}

    @staticmethod
    def _url(url):
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.username or parsed.password or parsed.port not in {None, 443}:
            raise CoreError("invalid_source_url", "Nguồn công khai phải là HTTPS, không chứa khóa hoặc tài khoản.")
        if not parsed.hostname or not (parsed.hostname == "hanoi.gov.vn" or parsed.hostname.endswith(".hanoi.gov.vn") or
                                     parsed.hostname == "chinhphu.vn" or parsed.hostname.endswith(".chinhphu.vn")):
            raise CoreError("source_not_allowlisted", "Chỉ tiếp nhận nguồn chính thức đã được cho phép.")
        if any(key in parsed.query.casefold() for key in ("token=", "secret=", "api_key=", "password=")):
            raise CoreError("invalid_source_url", "URL nguồn chứa thông tin xác thực.")

    def register_source(self, actor_id, source_id, title, agency, url, language="vi", source_kind="official_notice", metadata=None):
        self._url(url)
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "curator")
            self._register(db, source_id, title, agency, url, language, source_kind, metadata or {})
        return self.get_source(source_id)

    @staticmethod
    def _register(db, source_id, title, agency, url, language, source_kind, metadata):
        existing = db.execute("SELECT * FROM pol_sources WHERE id=?", (source_id,)).fetchone()
        values = (source_id, title, agency, url, "hanoi_policy", "VN-HN", language, source_kind, "public", json_text(metadata), None, now_iso())
        if existing:
            if existing["url"] != url or existing["title"] != title:
                raise CoreError("source_identity_conflict", "Nguồn đã tồn tại với định danh khác.", 409)
        else:
            db.execute("INSERT INTO pol_sources VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", values)

    def get_source(self, source_id):
        with self.repo.connection() as db:
            row = db.execute("SELECT s.*,g.availability,g.checked_at,g.current_until,g.reason_code FROM pol_sources s "
                             "LEFT JOIN pol_source_gates g ON g.source_id=s.id WHERE s.id=?", (source_id,)).fetchone()
            if not row:
                raise CoreError("not_found", "Không tìm thấy nguồn.", 404)
            return {**dict(row), "metadata": json.loads(row["metadata_json"])}

    @staticmethod
    def source_control_ref(db,source_id):
        """Current public source identity and operational observation, separately.

        A repeated successful check is not a new legal document/review. Never
        choose authority by timestamp or UUID; use the catalog's current heads.
        """
        row=db.execute("SELECT s.id,s.url,s.language,s.domain,s.jurisdiction,s.usage_scope,s.metadata_json,s.current_snapshot_id,"
            "p.source_id AS snapshot_source_id,p.raw_sha256,p.text_sha256 FROM pol_sources s LEFT JOIN pol_source_snapshots p ON p.id=s.current_snapshot_id WHERE s.id=?",(source_id,)).fetchone()
        if not row or row['usage_scope']!='public' or row['domain']!='hanoi_policy' or row['jurisdiction']!='VN-HN':
            raise CoreError('public_evidence_missing','Không có nguồn công khai đúng phạm vi.',409)
        if row['current_snapshot_id'] and row['snapshot_source_id']!=source_id:
            raise CoreError('knowledge_integrity_error','Head nguồn gốc không khớp snapshot.',409)
        identity={k:row[k] for k in ('id','url','language','domain','jurisdiction','current_snapshot_id','raw_sha256','text_sha256')}
        identity['metadata_hash']=digest(row['metadata_json'])
        gate=db.execute('SELECT source_id,availability,observation_id,version,current_until FROM pol_source_gates WHERE source_id=?',(source_id,)).fetchone()
        from nmate.knowledge_v1.source_control import enabled,current
        proof=current(db,source_id) if enabled(db) else dict(anchored=False)
        return dict(identity=identity,gate=dict(gate) if gate else None,control_proof=proof)

    def list_sources(self):
        with self.repo.connection() as db:
            ids = [row[0] for row in db.execute("SELECT id FROM pol_sources ORDER BY id")]
        return [self.get_source(identity) for identity in ids]

    def list_review_queue(self, actor_id):
        with self.repo.connection() as db:
            if not self._has_global_authority(db, actor_id, "reviewer") and not db.execute(
                "SELECT 1 FROM pol_knowledge_role_scopes r JOIN v03_accounts a ON a.id=r.account_id "
                "WHERE r.account_id=? AND r.role='reviewer' AND r.domain='hanoi_policy' AND r.revoked_at IS NULL AND a.active=1",
                (actor_id,)).fetchone():
                raise CoreError("knowledge_forbidden", "Chưa được cấp vai trò rà tri thức.", 403)
            result = []
            for row in db.execute("SELECT * FROM pol_members WHERE review_state!='approved' OR availability!='usable' ORDER BY created_at"):
                try:
                    self._member_authority(db, actor_id, "reviewer", row)
                except CoreError:
                    continue
                result.append({**dict(row), "payload": json.loads(row["payload_json"]), "evidence": json.loads(row["evidence_json"])})
            return result

    def add_translation(self, actor_id, chunk_id, text_vi):
        if not isinstance(text_vi, str) or not text_vi.strip() or len(text_vi) > 12000:
            raise CoreError("invalid_translation", "Bản dịch phải có nội dung tiếng Việt trong giới hạn.")
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "curator")
            chunk = db.execute("SELECT * FROM pol_chunks WHERE id=?", (chunk_id,)).fetchone()
            if not chunk:
                raise CoreError("not_found", "Không tìm thấy đoạn nguồn.", 404)
            translation_id = new_id("translation")
            db.execute("INSERT INTO pol_translations VALUES(?,?,?,?,?,? ,?,'draft',NULL,?)", (
                translation_id, chunk_id, chunk["quote_hash"], text_vi.strip(), digest(text_vi.strip()), "manual_no_model",
                actor_id, now_iso()))
            return {"translation_id": translation_id, "review_state": "draft"}

    def review_translation(self, actor_id, translation_id, expected_hash):
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "reviewer")
            row = db.execute("SELECT t.*,c.quote_hash FROM pol_translations t JOIN pol_chunks c ON c.id=t.chunk_id WHERE t.id=?", (translation_id,)).fetchone()
            if not row or row["text_hash"] != expected_hash or row["original_quote_hash"] != row["quote_hash"]:
                raise CoreError("translation_version_conflict", "Bản dịch không khớp đúng nguyên bản/phiên bản đã xem.", 409)
            db.execute("UPDATE pol_translations SET review_state='approved',reviewed_by=? WHERE id=?", (actor_id, translation_id))
            db.execute("INSERT INTO pol_chunks_fts(chunk_id,search_text) VALUES(?,?)", (row["chunk_id"], normalize(row["text_vi"])))
            return {"translation_id": translation_id, "review_state": "approved"}

    def refresh_source(self, actor_id, source_id, *, internal_job_id=None):
        """Bounded official HTTP refresh only; no OCR, translation, model, publication or scheduler side effect."""
        import httpx
        from bs4 import BeautifulSoup

        with self.repo.connection() as db:
            if internal_job_id is None:
                self._authority(db, actor_id, "curator")
            else:
                # Service acquisition is deliberately separate from review/approval authority.
                exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='pol_refresh_jobs'").fetchone()
                job = db.execute("SELECT * FROM pol_refresh_jobs WHERE id=? AND source_id=? AND enabled=1 AND state='running'",
                                 (internal_job_id, source_id)).fetchone() if exists else None
                if actor_id != "system:source-acquisition" or not job or not self._future(job["lease_until"]):
                    raise CoreError("knowledge_forbidden", "Tác vụ cập nhật nguồn chưa được cấp phạm vi.", 403)
        source = self.get_source(source_id)
        url = source["url"]
        body, mime_type = b"", ""
        try:
            with httpx.Client(timeout=15, follow_redirects=False, trust_env=False) as client:
                for _ in range(4):
                    self._url(url)
                    host = urlsplit(url).hostname
                    addresses = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
                    if not addresses or any(not ipaddress.ip_address(info[4][0]).is_global for info in addresses):
                        raise CoreError("unsafe_source_address", "Nguồn không trỏ tới địa chỉ Internet công khai.")
                    with client.stream("GET", url, headers={"Accept": "text/html,text/plain,application/pdf"}) as response:
                        if response.status_code in {301, 302, 303, 307, 308}:
                            from urllib.parse import urljoin
                            url = urljoin(url, response.headers.get("location", ""))
                            continue
                        response.raise_for_status()
                        mime_type = response.headers.get("content-type", "").split(";", 1)[0].strip()
                        if mime_type not in {"text/html", "text/plain", "application/pdf"}:
                            raise CoreError("unsupported_source_format", "Định dạng nguồn chưa được hỗ trợ.")
                        chunks, size = [], 0
                        for part in response.iter_bytes():
                            size += len(part)
                            if size > 5_000_000:
                                raise CoreError("source_too_large", "Nguồn vượt giới hạn 5 MB.")
                            chunks.append(part)
                        body = b"".join(chunks)
                        break
                if not body:
                    raise CoreError("source_redirect_limit", "Nguồn chuyển hướng quá số lần cho phép.")
        except (httpx.HTTPError, OSError, CoreError) as exc:
            with self.repo.connection(write=True) as db:
                self._observation(db, actor_id, source_id, source["current_snapshot_id"], "fetch_failed", "unavailable", None,
                                  getattr(exc, "code", "HTTP_SOURCE_UNAVAILABLE"))
            return {"source_id": source_id, "state": "unavailable", "reason_code": getattr(exc, "code", "HTTP_SOURCE_UNAVAILABLE")}
        if mime_type == "application/pdf":
            # An unparsed annex must not become complete legal evidence just because bytes were downloaded.
            with self.repo.connection(write=True) as db:
                self._observation(db, actor_id, source_id, source["current_snapshot_id"], "extraction_required", "snapshot_only", None,
                                  "PDF_EXTRACTION_REVIEW_REQUIRED")
            return {"source_id": source_id, "state": "extraction_required", "raw_sha256": digest(body), "provider_calls": 0}
        soup = BeautifulSoup(body, "html.parser") if mime_type == "text/html" else None
        if soup:
            for unwanted in soup.select("script,style,nav,footer,form"):
                unwanted.decompose()
            content = soup.select_one(".news-detail-content") or soup.select_one("article") or soup.select_one("main")
            if content is None:
                with self.repo.connection(write=True) as db:
                    self._observation(db, actor_id, source_id, source["current_snapshot_id"], "extraction_required", "snapshot_only", None,
                                      "ARTICLE_BOUNDARY_REVIEW_REQUIRED")
                return {"source_id": source_id, "state": "extraction_required", "provider_calls": 0}
            paragraphs = [p.get_text(" ", strip=True) for p in content.find_all(["p", "h2", "h3", "li"]) if p.get_text(" ", strip=True)]
            text = "\n\n".join(paragraphs)
        else:
            text = body.decode("utf-8", errors="strict")
        if not body or not text.strip():
            raise CoreError("invalid_snapshot", "Nguồn chưa đọc được nội dung.")
        with self.repo.connection(write=True) as db:
            snapshot = self._snapshot(db, actor_id, source_id, body, text, now_iso(), None, False, None, None, mime_type)
            if snapshot.get("unchanged"):
                gate = db.execute("SELECT * FROM pol_source_gates WHERE source_id=?", (source_id,)).fetchone()
                availability = gate["availability"] if gate else "snapshot_only"
                until = gate["current_until"] if gate else None
                if availability == "unavailable":
                    availability, until = "snapshot_only", None
                # HTTP success is an acquisition observation, not a renewed legal review.
                self._observation(db, actor_id, source_id, snapshot["snapshot_id"], "http_unchanged", availability, until,
                                  "HTTP_RECOVERED_LEGAL_CHECK_REQUIRED" if availability == "snapshot_only" else "HTTP_UNCHANGED_NO_LEGAL_RENEWAL")
        return {"source_id": source_id, "state": "snapshot_only", "provider_calls": 0, **snapshot}

    def add_snapshot(self, actor_id, source_id, raw_bytes, canonical_text, *, retrieved_at=None, published_at=None,
                     complete_policy=False, effective_from=None, effective_until=None, mime_type="text/html"):
        if not isinstance(raw_bytes, bytes) or not raw_bytes or not canonical_text.strip() or len(raw_bytes) > 5_000_000:
            raise CoreError("invalid_snapshot", "Nguồn chưa đọc được hoặc vượt giới hạn tiếp nhận.")
        self._period(effective_from, effective_until)
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "curator")
            return self._snapshot(db, actor_id, source_id, raw_bytes, canonical_text, retrieved_at or now_iso(),
                                  published_at, complete_policy, effective_from, effective_until, mime_type)

    def _snapshot(self, db, actor_id, source_id, raw_bytes, text, retrieved_at, published_at,
                  complete_policy, effective_from, effective_until, mime_type, *,
                  extraction_version="html-text/1", paragraph_locators=None):
        from nmate.knowledge_v1.source_control import before_write
        before_write(db,source_id)
        source = db.execute("SELECT * FROM pol_sources WHERE id=?", (source_id,)).fetchone()
        if not source:
            raise CoreError("not_found", "Chưa đăng ký nguồn.", 404)
        raw_hash, text_hash = digest(raw_bytes), hashlib.sha256(text.encode()).hexdigest()
        existing = db.execute("SELECT id FROM pol_source_snapshots WHERE source_id=? AND raw_sha256=? AND text_sha256=? "
                              "AND extraction_version=?", (source_id, raw_hash, text_hash, extraction_version)).fetchone()
        if existing:
            return {"snapshot_id": existing["id"], "unchanged": True}
        snapshot_id = new_id("snapshot")
        db.execute("INSERT INTO pol_source_snapshots VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
            snapshot_id, source_id, raw_bytes, raw_hash, text, text_hash, extraction_version, mime_type,
            retrieved_at, published_at, effective_from, effective_until, int(complete_policy), "accepted"))
        # Paragraph boundaries preserve negation/definitions and offsets in the canonical extraction.
        index = 0
        for ordinal, paragraph in enumerate(text.split("\n\n")):
            if not paragraph:
                index += 2
                continue
            start, end = index, index + len(paragraph)
            locator = {"type": "paragraph", "ordinal": ordinal, "start": start, "end": end,
                       "extraction_version": extraction_version}
            if paragraph_locators is not None:
                locator.update(paragraph_locators[ordinal])
            chunk_id = new_id("chunk")
            span_hash = digest({"snapshot_id": snapshot_id, "locator": locator, "quote_original": paragraph})
            db.execute("INSERT INTO pol_chunks VALUES(?,?,?,?,?,?,?,?,?)", (
                chunk_id, snapshot_id, ordinal, start, end, paragraph,
                hashlib.sha256(paragraph.encode()).hexdigest(), json_text(locator), span_hash))
            db.execute("INSERT INTO pol_chunks_fts(chunk_id,search_text) VALUES(?,?)", (chunk_id, normalize(source["title"] + " " + paragraph)))
            index = end + 2
        previous = source["current_snapshot_id"]
        db.execute("UPDATE pol_sources SET current_snapshot_id=? WHERE id=?", (snapshot_id, source_id))
        self._observation(db, actor_id, source_id, snapshot_id, "accepted_snapshot", "snapshot_only", None,
                          "SOURCE_CHANGED_REVIEW_REQUIRED" if previous else "LEGAL_CURRENCY_NOT_VERIFIED", checked_at=retrieved_at,
                          _snapshot_transition=True)
        if previous:
            self._invalidate_source(db, source_id)
        return {"snapshot_id": snapshot_id, "raw_sha256": raw_hash, "text_sha256": text_hash, "unchanged": False}

    @staticmethod
    def _invalidate_source(db, source_id):
        ids = [r[0] for r in db.execute("SELECT from_id FROM pol_graph_edges WHERE from_kind IN ('rule','claim') "
                                     "AND to_kind='source' AND to_id=?", (source_id,))]
        for member_id in ids:
            db.execute("UPDATE pol_members SET availability='needs_review' WHERE id=?", (member_id,))

    @staticmethod
    def _observation(db, actor_id, source_id, snapshot_id, result, availability, current_until, reason, checked_at=None,
                     _snapshot_transition=False):
        from nmate.knowledge_v1.source_control import before_write,append_observation
        if not _snapshot_transition:before_write(db,source_id)
        stamp, observation_id = checked_at or now_iso(), new_id("observation")
        db.execute("INSERT INTO pol_source_observations VALUES(?,?,?,?,?,?,?,?)", (
            observation_id, source_id, snapshot_id, actor_id, "manual", result, json_text({"reason_code": reason}), stamp))
        db.execute("INSERT INTO pol_source_gates VALUES(?,?,?,?,?,?,1) ON CONFLICT(source_id) DO UPDATE SET "
                   "availability=excluded.availability,checked_at=excluded.checked_at,current_until=excluded.current_until,"
                   "reason_code=excluded.reason_code,observation_id=excluded.observation_id,version=pol_source_gates.version+1",
                   (source_id, availability, stamp, current_until, reason, observation_id))
        append_observation(db,source_id)
        return observation_id

    def record_source_check(self, actor_id, source_id, *, result, current_until=None, rationale=""):
        """Current legal coverage must be explicitly verified by scoped reviewer, never from HTTP 200."""
        allowed = {"verified_current", "unavailable", "changed", "superseded", "snapshot_only"}
        if result not in allowed or not rationale.strip():
            raise CoreError("invalid_source_check", "Cần trạng thái kiểm và lý do có căn cứ.")
        if result == "verified_current" and (not current_until or not self._future(current_until)):
            raise CoreError("invalid_source_check", "Lần kiểm hiện hành cần hạn rà rõ, còn trong tương lai.")
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "reviewer")
            source = db.execute("SELECT * FROM pol_sources WHERE id=?", (source_id,)).fetchone()
            if not source:
                raise CoreError("not_found", "Không tìm thấy nguồn.", 404)
            observation = self._observation(db, actor_id, source_id, source["current_snapshot_id"], result, result,
                                            current_until, rationale)
            if result in {"changed", "superseded"}:
                self._invalidate_source(db, source_id)
        return {"observation_id": observation, "availability": result}

    def retrieve(self, query, *, target_date=None, purpose="source_discovery", limit=12, db=None, goal=None):
        if db is None:
            with self.repo.connection() as connection:
                return self.retrieve(query, target_date=target_date, purpose=purpose, limit=limit, db=connection, goal=goal)
        normalized = normalize(query)
        words = set(normalized.split())
        for row in db.execute("SELECT * FROM pol_aliases"):
            if row["phrase"] in normalized:
                words.update(" ".join(json.loads(row["expansions_json"])).split())
        stopwords = {"toi", "minh", "cua", "co", "va", "la", "gi", "cho", "can", "muon", "ha", "noi", "khong", "tra", "sen"}
        words -= stopwords
        match = " OR ".join('"' + word + '"' for word in sorted(words))
        rows = []
        if match:
            rows = db.execute("SELECT c.*,s.id source_id,s.title,s.agency,s.url,s.language,s.metadata_json,"
                              "p.published_at,p.retrieved_at,p.complete_policy,p.text_sha256,p.effective_from,p.effective_until,"
                              "g.availability,g.checked_at,g.current_until,g.reason_code "
                              "FROM pol_chunks_fts f JOIN pol_chunks c ON c.id=f.chunk_id "
                              "JOIN pol_source_snapshots p ON p.id=c.snapshot_id JOIN pol_sources s ON s.id=p.source_id "
                              "LEFT JOIN pol_source_gates g ON g.source_id=s.id "
                              "WHERE pol_chunks_fts MATCH ? AND s.current_snapshot_id=p.id AND s.usage_scope='public' "
                              "AND s.domain='hanoi_policy' AND s.jurisdiction='VN-HN' AND p.acceptance_state='accepted'", (match,)).fetchall()
        candidates, seen = [], set()
        domain_graph = DomainGraph(db, self, target_date=target_date)
        for row in rows:
            if row["id"] in seen:
                continue
            seen.add(row["id"])
            item = dict(row)
            item["score"] = len(words & set(normalize(item["text_original"]).split()))
            item["locator"] = json.loads(item.pop("locator_json"))
            item["metadata"] = json.loads(item.pop("metadata_json"))
            collection = item["metadata"].get("retrieval_collection")
            if collection:
                # The PDF archive retains all pages. This curated collection
                # indexes only the registered program's relevant pages, so
                # appendix 04 cannot become evidence for appendix 03 merely
                # because both mention digital transformation.
                if goal is not None and goal not in collection["goal_types"]:
                    continue
                if item["locator"].get("page") not in collection["pages"]:
                    continue
            item["source_snapshot_id"], item["chunk_id"] = item["snapshot_id"], item["id"]
            item["quote_original"] = item["text_original"]
            translation = domain_graph.approved_translation(item["id"], item["quote_hash"])
            item["rendered_vi"] = item["text_original"] if item["language"] == "vi" else translation["text_vi"] if translation else "Chưa có bản dịch tiếng Việt đã duyệt. Có thể xem nguyên bản nguồn."
            item["translation_id"] = translation["id"] if translation else None
            item["translation_status"] = "not_needed" if item["language"] == "vi" else "approved" if translation else "translation_required"
            item["knowledge_dependency"] = domain_graph.source_dependency(item["chunk_id"], item["translation_id"])
            item["legal_currency"] = "not_verified"
            item["usable_for_assessment"] = self._source_gate(item, target_date or date.today().isoformat()) is None
            if item["usable_for_assessment"]:
                item["legal_currency"] = "verified_current"
            if purpose == "reviewed_policy_assessment" and not item["usable_for_assessment"]:
                continue
            candidates.append(item)
        candidates.sort(key=lambda item: (-item.pop("score"), item["source_id"], item["ordinal"]))
        return candidates[:max(1, min(limit, 30))]

    @staticmethod
    def _future(value):
        try:
            parsed = datetime.fromisoformat(value)
            if parsed.tzinfo is None:
                raise ValueError
            return parsed > datetime.now(timezone.utc)
        except (ValueError, TypeError):
            return False

    @staticmethod
    def _period(start, until):
        try:
            first = date.fromisoformat(start) if start else None
            last = date.fromisoformat(until) if until else None
            if first and last and first >= last:
                raise ValueError
        except (ValueError, TypeError) as exc:
            raise CoreError("invalid_effective_period", "Khoảng hiệu lực phải là ngày ISO và kết thúc sau ngày bắt đầu.") from exc

    @staticmethod
    def _source_gate(source, target_date):
        if source.get("availability") != "verified_current" or not source.get("current_until") or not KnowledgeCatalog._future(source["current_until"]):
            return "SOURCE_CURRENT_CHECK_REQUIRED"
        if not source.get("complete_policy"):
            return "COMPANION_DOCUMENT_REQUIRED"
        if not source.get("effective_from"):
            return "LEGAL_EFFECTIVE_PERIOD_UNKNOWN"
        if target_date < source["effective_from"] or (source.get("effective_until") and target_date >= source["effective_until"]):
            return "OUTSIDE_EFFECTIVE_PERIOD"
        return None

    def bind_evidence(self, chunk_id, quote_original, *, role="primary", supports_id=None):
        with self.repo.connection() as db:
            return self._bind_evidence(db, chunk_id, quote_original, role, supports_id)

    @staticmethod
    def _bind_evidence(db, chunk_id, quote, role="primary", supports_id=None):
        row = db.execute("SELECT c.*,p.source_id FROM pol_chunks c JOIN pol_source_snapshots p ON p.id=c.snapshot_id WHERE c.id=?", (chunk_id,)).fetchone()
        if not row or role not in {"primary", "supporting"} or not quote or quote not in row["text_original"]:
            raise CoreError("evidence_mismatch", "Trích dẫn không khớp nguyên văn nguồn.")
        return {"chunk_id": chunk_id, "source_snapshot_id": row["snapshot_id"], "source_id": row["source_id"],
                "quote_original": quote, "quote_original_hash": hashlib.sha256(quote.encode()).hexdigest(),
                "span_hash": row["span_hash"], "role": role, "supports_id": supports_id}

    def propose_member(self, actor_id, *, kind, policy_id, title_vi, payload, evidence, effective_from=None, effective_until=None):
        self._period(effective_from, effective_until)
        covered_ids = validate_member_payload(kind, payload)
        scope = payload.get("scope", {})
        if scope.get("jurisdiction") != "VN-HN" or not scope.get("goal_types") or not set(scope["goal_types"]) <= GOALS:
            raise CoreError("invalid_policy_scope", "Quy tắc cần địa bàn và mục tiêu hỗ trợ được khai rõ.")
        if kind == "rule":
            if not payload.get("conditions") or len(payload["conditions"]) > 30:
                raise CoreError("invalid_rule", "Quy tắc cần điều kiện hữu hạn.")
            for condition in payload["conditions"]:
                validate_expression(condition["expression"])
                if not condition.get("id"):
                    raise CoreError("invalid_rule", "Điều kiện cần định danh.")
        elif kind == "claim":
            if payload.get("claim_type") not in {"preparation", "procedure", "application_window", "amount"}:
                raise CoreError("invalid_claim", "Loại khẳng định chưa được hỗ trợ.")
            if not payload.get("items") or len(payload["items"]) > 30 or any(not item.get("id") or not item.get("text_vi") for item in payload["items"]):
                raise CoreError("invalid_claim", "Mỗi mục cần định danh và nội dung.")
            if payload.get("applies_when"):
                validate_expression(payload["applies_when"])
            if payload["claim_type"] == "application_window":
                try:
                    checked = datetime.fromisoformat(payload["application_checked_at"])
                    until = datetime.fromisoformat(payload["window_valid_until"])
                    current = datetime.now(timezone.utc)
                    if checked.tzinfo is None or until.tzinfo is None or not checked <= current < until or until > checked + timedelta(days=1):
                        raise ValueError
                    if payload.get("application_status") not in {"open", "closed", "not_yet_open", "unknown"}:
                        raise ValueError
                    if payload.get("application_status") == "open" and payload.get("quota_verified") is not True:
                        raise ValueError
                except (KeyError, ValueError, TypeError) as exc:
                    raise CoreError("invalid_window_claim", "Cửa tiếp nhận cần lần kiểm có múi giờ, hạn kiểm tối đa 24 giờ và căn cứ chỉ tiêu rõ.") from exc
        else:
            raise CoreError("invalid_member", "Chỉ hỗ trợ rule hoặc claim.")
        with self.repo.connection(write=True) as db:
            self._authority(db, actor_id, "curator")
            for previous_id in payload.get("supersedes_member_ids", []):
                previous = self._member(db, previous_id)
                if previous["kind"] != kind or previous["policy_id"] != policy_id:
                    raise CoreError("invalid_supersession", "Chỉ thay thế phiên bản cùng chương trình và cùng loại tri thức.")
            bindings = [self._bind_evidence(db, e["chunk_id"], e["quote_original"], e.get("role", "primary"), e.get("supports_id")) for e in evidence]
            if kind == "claim" and payload["claim_type"] == "application_window":
                for binding in bindings:
                    gate = self._binding_source(db, binding)
                    if not gate.get("current_until") or datetime.fromisoformat(payload["window_valid_until"]) > datetime.fromisoformat(gate["current_until"]):
                        raise CoreError("invalid_window_claim", "Hạn kiểm cửa tiếp nhận vượt hạn kiểm nguồn hiện hành.")
            ids = covered_ids
            if any(not any(e["supports_id"] == cid and e["role"] == "primary" for e in bindings) for cid in ids):
                raise CoreError("evidence_coverage_gap", "Mỗi điều kiện/mục cần căn cứ chính riêng.")
            member_id = new_id(kind)
            content_hash = digest({"kind": kind, "policy_id": policy_id, "title_vi": title_vi, "payload": payload,
                                   "evidence": bindings, "effective_from": effective_from, "effective_until": effective_until})
            db.execute("INSERT INTO pol_members VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                member_id, kind, policy_id, title_vi, json_text(payload), json_text(bindings), content_hash,
                "draft", "draft", "awaiting_review", effective_from, effective_until, actor_id, now_iso()))
            for binding in bindings:
                for to_kind, key in (("source", "source_id"), ("snapshot", "source_snapshot_id"), ("chunk", "chunk_id")):
                    db.execute("INSERT OR IGNORE INTO pol_graph_edges VALUES(?,?,?,?,?,?)", (kind, member_id, "depends_on", to_kind, binding[key], binding["span_hash"]))
            for field in expression_fields(payload["applies_when"]) if payload.get("applies_when") else set():
                db.execute("INSERT OR IGNORE INTO pol_graph_edges VALUES(?,?,?,?,?,?)", (kind, member_id, "requires_fact", "field", field, content_hash))
            for condition in payload.get("conditions", []):
                for field in expression_fields(condition["expression"]):
                    db.execute("INSERT OR IGNORE INTO pol_graph_edges VALUES(?,?,?,?,?,?)", (kind, member_id, "requires_fact", "field", field, content_hash))
            for exception in payload.get("exceptions", []):
                for field in expression_fields(exception["expression"]):
                    db.execute("INSERT OR IGNORE INTO pol_graph_edges VALUES(?,?,?,?,?,?)", (kind, member_id, "exception_requires_fact", "field", field, content_hash))
            return {"member_id": member_id, "content_hash": content_hash, "review_state": "draft"}

    def review_member(self, actor_id, member_id, expected_hash, *, approve, rationale):
        if not rationale.strip():
            raise CoreError("review_reason_required", "Cần ghi căn cứ duyệt.")
        with self.repo.connection(write=True) as db:
            member = self._member(db, member_id, expected_hash)
            self._member_authority(db, actor_id, "reviewer", member)
            if approve:
                validate_member_payload(member["kind"], json.loads(member["payload_json"]))
            if approve and not member["effective_from"]:
                raise CoreError("effective_period_required", "Chưa xác định ngày hiệu lực quy tắc.")
            for binding in json.loads(member["evidence_json"]):
                source = self._binding_source(db, binding)
                reason = self._source_gate(source, date.today().isoformat())
                if approve and reason:
                    raise CoreError(reason.lower(), "Nguồn chưa đủ điều kiện duyệt quy tắc.", 409)
            review_id = new_id("review")
            db.execute("INSERT INTO pol_review_events VALUES(?,?,?,?,?,?,?)", (review_id, member_id, expected_hash, actor_id,
                       "approved" if approve else "rejected", rationale, now_iso()))
            db.execute("UPDATE pol_members SET review_state=?,availability=? WHERE id=?", (
                "approved" if approve else "rejected", "usable" if approve else "blocked", member_id))
            return {"review_event_id": review_id, "review_state": "approved" if approve else "rejected"}

    @staticmethod
    def _member(db, member_id, expected_hash=None):
        row = db.execute("SELECT * FROM pol_members WHERE id=?", (member_id,)).fetchone()
        if not row:
            raise CoreError("not_found", "Không tìm thấy phiên bản tri thức.", 404)
        if expected_hash and row["content_hash"] != expected_hash:
            raise CoreError("knowledge_hash_conflict", "Phiên bản khác bản đã xem.", 409)
        return dict(row)

    @staticmethod
    def _binding_source(db, binding):
        row = db.execute("SELECT p.*,g.availability,g.checked_at,g.current_until,s.current_snapshot_id FROM pol_source_snapshots p "
                         "JOIN pol_sources s ON s.id=p.source_id LEFT JOIN pol_source_gates g ON g.source_id=p.source_id WHERE p.id=? "
                         "AND s.usage_scope='public' AND s.domain='hanoi_policy' AND s.jurisdiction='VN-HN' AND p.acceptance_state='accepted'",
                         (binding["source_snapshot_id"],)).fetchone()
        if not row or row["current_snapshot_id"] != binding["source_snapshot_id"]:
            raise CoreError("source_version_changed", "Phiên bản nguồn đã đổi; cần rà lại.", 409)
        # Verify the exact stored citation again, not only the supplied hash.
        checked = KnowledgeCatalog._bind_evidence(db, binding["chunk_id"], binding["quote_original"], binding["role"], binding.get("supports_id"))
        if checked != binding:
            raise CoreError("evidence_mismatch", "Căn cứ đã thay đổi.", 409)
        return dict(row)

    def publish_member(self, actor_id, member_id, expected_hash, review_event_id):
        with self.repo.connection(write=True) as db:
            member = self._member(db, member_id, expected_hash)
            self._member_authority(db, actor_id, "publisher", member)
            validate_member_payload(member["kind"], json.loads(member["payload_json"]))
            review = db.execute("SELECT * FROM pol_review_events WHERE id=? AND member_id=? AND content_hash=? AND decision='approved'",
                                (review_event_id, member_id, expected_hash)).fetchone()
            if not review or member["review_state"] != "approved" or member["availability"] != "usable":
                raise CoreError("review_required", "Cần đúng phiên bản đã duyệt còn sử dụng được.", 409)
            self._member_authority(db, review["actor_id"], "reviewer", member)
            for evidence in json.loads(member["evidence_json"]):
                if self._source_gate(self._binding_source(db, evidence), date.today().isoformat()):
                    raise CoreError("source_not_current", "Nguồn cần kiểm lại trước phát hành.", 409)
            event_id = new_id("publication")
            db.execute("INSERT INTO pol_publication_events VALUES(?,?,?,?,?,?)", (event_id, member_id, expected_hash, review_event_id, actor_id, now_iso()))
            db.execute("UPDATE pol_members SET publication_state='published' WHERE id=?", (member_id,))
            return {"publication_event_id": event_id, "member_id": member_id}

    def release_pack(self, actor_id, title_vi, member_ids):
        if not member_ids or len(set(member_ids)) != len(member_ids):
            raise CoreError("invalid_manifest", "Danh sách phiên bản phát hành không hợp lệ.")
        with self.repo.connection(write=True) as db:
            manifest = []
            for member_id in member_ids:
                member = self._member(db, member_id)
                self._member_authority(db, actor_id, "publisher", member)
                validate_member_payload(member["kind"], json.loads(member["payload_json"]))
                if member["review_state"] != "approved" or member["publication_state"] != "published" or member["availability"] != "usable":
                    raise CoreError("member_not_publishable", "Bộ tri thức chứa phiên bản chưa sẵn sàng.", 409)
                publication = db.execute("SELECT id FROM pol_publication_events WHERE member_id=? AND content_hash=? ORDER BY created_at DESC LIMIT 1",
                                         (member_id, member["content_hash"])).fetchone()
                if not publication:
                    raise CoreError("publication_required", "Thiếu sự kiện phát hành phiên bản.", 409)
                for binding in json.loads(member["evidence_json"]):
                    if self._source_gate(self._binding_source(db, binding), date.today().isoformat()):
                        raise CoreError("source_not_current", "Nguồn cần kiểm lại trước phát hành bộ.", 409)
                manifest.append({"member_id": member_id, "content_hash": member["content_hash"], "publication_event_id": publication["id"]})
            pack_id, release_id = new_id("pack"), new_id("release")
            manifest.sort(key=lambda member: member["member_id"])
            manifest_hash = digest(manifest)
            db.execute("INSERT INTO pol_packs VALUES(?,?,?,?,?,?,?,?)", (
                pack_id, title_vi, json_text(manifest), manifest_hash, "published", "usable", release_id, now_iso()))
            db.execute("INSERT INTO pol_release_events VALUES(?,?,?,?,?)", (release_id, pack_id, manifest_hash, actor_id, now_iso()))
            for member in manifest:
                db.execute("INSERT INTO pol_graph_edges VALUES(?,?,?,?,?,?)", ("pack", pack_id, "contains", "member", member["member_id"], member["content_hash"]))
            return {"pack_version_id": pack_id, "release_event_id": release_id, "manifest_hash": manifest_hash}

    def withdraw_member(self, actor_id, member_id, expected_hash, rationale):
        if not rationale.strip():
            raise CoreError("review_reason_required", "Cần lý do rút phiên bản tri thức.")
        with self.repo.connection(write=True) as db:
            member = self._member(db, member_id, expected_hash)
            self._member_authority(db, actor_id, "reviewer", member)
            event_id = new_id("review")
            db.execute("INSERT INTO pol_review_events VALUES(?,?,?,?,?,?,?)", (
                event_id, member_id, member["content_hash"], actor_id, "withdrawn", rationale, now_iso()))
            db.execute("UPDATE pol_members SET availability='withdrawn' WHERE id=?", (member_id,))
            return {"member_id": member_id, "availability": "withdrawn", "review_event_id": event_id}

    def assess(self, facts, *, target_date=None, outcome_types=None, goal=None):
        target_date = target_date or date.today().isoformat()
        findings = []
        with self.repo.connection() as db:
            graph = DomainGraph(db, self, target_date=target_date)
            for record in graph.records():
                pack, member = record["pack"], record["member"]
                try:
                    payload = json.loads(member["payload_json"])
                    if not isinstance(payload, dict):
                        payload = {}
                except (ValueError, TypeError):
                    payload = {}
                scope = payload.get("scope", {})
                goals = scope.get("goal_types", []) if isinstance(scope, dict) else []
                if goal and goal not in goals and "general" not in goals:
                    continue
                if outcome_types and member["kind"] == "rule" and "eligibility" not in outcome_types:
                    continue
                if outcome_types and member["kind"] == "claim" and payload.get("claim_type") not in outcome_types:
                    continue
                reason = record["reason"]
                try:
                    bindings = json.loads(member["evidence_json"])
                    if not isinstance(bindings, list):
                        bindings = []
                except (ValueError, TypeError):
                    bindings = []
                conditions = [{"condition_id": c["id"], "title_vi": c.get("title_vi", c["id"]),
                               **evaluate(c["expression"], facts)} for c in payload.get("conditions", [])] if not reason else []
                applies = evaluate(payload["applies_when"], facts) if not reason and payload.get("applies_when") else None
                if not reason and member["kind"] == "rule" and applies:
                    conditions.insert(0, {"condition_id": "applies_when", "title_vi": "Phạm vi áp dụng", **applies})
                exceptions = [{"condition_id": c["id"], "title_vi": c.get("title_vi", c["id"]),
                    **evaluate({"not": c["expression"]}, facts)} for c in payload.get("exceptions", [])] if not reason else []
                if member["kind"] == "rule":
                    conditions.extend([{**item, "condition_id": "exception:" + item["condition_id"]} for item in exceptions])
                elif exceptions and any(item["state"] != "met" for item in exceptions):
                    reason = "MEMBER_EXCEPTION_NOT_CLEARED"
                findings.append({"member_id": member["id"], "kind": member["kind"], "policy_id": member["policy_id"],
                                 "pack_version_id": pack["id"], "pack_release_event_id": pack["release_event_id"],
                                 "policy_version": record["policy_ref"], "knowledge_dependency": graph.member_dependency(record),
                                 "title_vi": member["title_vi"], "content_hash": member["content_hash"],
                                 "status": "blocked" if reason else "assessed", "reason_code": reason,
                                 "conditions": conditions, "applies_when": applies,
                                 "payload": payload if not reason else None, "evidence": bindings})
        return findings

    def domain_graph(self, *, target_date=None):
        """Rebuild the reusable public projection without touching SSOT/cache/model."""
        with self.repo.connection() as db:
            return DomainGraph(db, self, target_date=target_date).project()

    def dependencies(self, kind, identity):
        with self.repo.connection() as db:
            return [dict(row) for row in db.execute("SELECT * FROM pol_graph_edges WHERE (from_kind=? AND from_id=?) "
                                                  "OR (to_kind=? AND to_id=?)", (kind, identity, kind, identity))]

    def bootstrap_official_notice(self):
        """Install bytes actually downloaded from the official portal; never installs a rule/approval."""
        directory = Path(__file__).parent / "data"
        metadata = json.loads((directory / "notice_2026_14.json").read_text(encoding="utf-8"))
        raw = (directory / "notice_2026_14.html").read_bytes()
        if digest(raw) != metadata["raw_sha256"]:
            raise CoreError("seed_hash_mismatch", "Bản nguồn tham chiếu không khớp hash.")
        self._url(metadata["url"])
        with self.repo.connection(write=True) as db:
            self._register(db, metadata["source_id"], metadata["title"], metadata["agency"], metadata["url"], "vi", "official_notice",
                           {"discovery_only": True, "companion_documents_unread": True,
                            "application_window": "until_quota_unknown", "scope": "consulting_digital_transformation",
                            "policy_id": "HN-DIGITAL-CONSULTING-2026"})
            return self._snapshot(db, "system:verified-public-import", metadata["source_id"], raw, metadata["canonical_text"],
                                  metadata["retrieved_at"], metadata["published_at"], False, None, None, "text/html")

    def bootstrap_digital_source_pack(self):
        """Accept immutable public bytes/extractions, never legal review or release.

        The portal attachment is unsigned; the decree is only partially
        transcribed. Even a fully extracted PDF cannot be a reviewed rule.
        Import is idempotent and preserves every previous notice snapshot.
        """
        directory = Path(__file__).parent / "data"
        pack = json.loads((directory / "hanoi_digital_source_pack.json").read_text(encoding="utf8"))
        prepared = []
        for document in pack["documents"]:
            self._url(document["url"])
            raw = (directory / document["filename"]).read_bytes()
            text = document["canonical_text"]
            if (digest(raw) != document["raw_sha256"] or
                    hashlib.sha256(text.encode()).hexdigest() != document["canonical_text_sha256"] or
                    len(text.split("\n\n")) != len(document["pages"])):
                raise CoreError("seed_hash_mismatch", "Bản nguồn hoặc trích xuất theo trang không khớp hash.")
            prepared.append((document, raw, text))
        installed = []
        with self.repo.connection(write=True) as db:
            for document, raw, text in prepared:
                collection = {"policy_id": "HN-DIGITAL-CONSULTING-2026", "goal_types": ["digital_inventory"],
                              "pages": ({"HN-NOTICE-2026-14-ATTACHMENT": [2, 9, 10, 11],
                                         "VN-DECREE-80-2021-SCAN": [6],
                                         "VN-CIRCULAR-06-2022-GAZETTE": [6]}[document["source_id"]])}
                self._register(db, document["source_id"], document["title"], document["agency"], document["url"],
                    "vi", "official_attachment", {"discovery_only": True, "policy_id": "HN-DIGITAL-CONSULTING-2026",
                        "scope": "consulting_digital_transformation", "all_pages_extracted": document["all_pages_extracted"],
                        "identity_note_vi": document["identity_note_vi"], "companion_documents_unread": True,
                        "application_window": "until_quota_unknown", "legal_currency": "not_verified",
                        "retrieval_collection": collection})
                # Enrich the collection metadata on repeat deployment without
                # rewriting immutable source bytes or changing any legal gate.
                stored_metadata = json.loads(db.execute("SELECT metadata_json FROM pol_sources WHERE id=?",
                                                       (document["source_id"],)).fetchone()[0])
                if stored_metadata.get("retrieval_collection") != collection:
                    stored_metadata["retrieval_collection"] = collection
                    db.execute("UPDATE pol_sources SET metadata_json=? WHERE id=?",
                               (json_text(stored_metadata), document["source_id"]))
                installed.append(self._snapshot(db, "system:verified-public-import", document["source_id"], raw, text,
                    document["retrieved_at"], document["published_at"], False, document["effective_from"], None,
                    "application/pdf", extraction_version=document["extraction_version"],
                    paragraph_locators=[{"type": "pdf_page", "page": page["page"],
                                         **({"section": page["section"]} if page.get("section") else {})}
                                        for page in document["pages"]]))
        return {"schema_version": pack["schema_version"], "snapshots": installed, "provider_calls": 0,
                "review_events_created": 0, "publication_events_created": 0}
