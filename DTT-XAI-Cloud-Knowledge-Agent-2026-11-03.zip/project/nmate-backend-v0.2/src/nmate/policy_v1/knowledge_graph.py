"""Typed, rebuildable public-domain projection over the authoritative SQL rows.

This module never writes, indexes enterprise inputs, chooses a newer rule by a
timestamp, or turns a downloaded source into a reviewed policy. Typed refs and
dependency fingerprints are deliberately distinct from enterprise SSOT refs.
"""
from __future__ import annotations

from datetime import date
import json

from nmate.v03.core import CoreError, json_text
from nmate.v03.knowledge_graph import GRAPH_VERSION, digest, ref
from .rules import expression_fields, validate_expression

MEMBER_VERSION = "reviewed-domain-member/1"
GOALS = {"digital_inventory", "digital_transformation", "equipment_purchase", "market_development", "general",
         "workforce_training", "trademark_protection", "ocop_program"}
CLAIMS = {"preparation", "procedure", "application_window", "amount"}


def validate_member_payload(kind, payload):
    """One discriminator/condition contract for commands and read projections.

    Unknown legacy rows are blocked for new use, never rewritten during reads.
    Content already stored before this version remains available in its receipt.
    """
    if not isinstance(payload, dict):
        raise CoreError("invalid_member_shape", "Nội dung phiên bản tri thức phải là đối tượng có kiểu.")
    scope = payload.get("scope", {})
    if (not isinstance(scope, dict) or scope.get("jurisdiction") != "VN-HN"
            or not isinstance(scope.get("goal_types"), list) or not scope["goal_types"]
            or any(not isinstance(goal, str) or goal not in GOALS for goal in scope["goal_types"])):
        raise CoreError("invalid_policy_scope", "Quy tắc cần địa bàn và mục tiêu hỗ trợ được khai rõ.")
    if set(scope) - {"jurisdiction", "goal_types", "entity_types", "market_codes"}:
        raise CoreError("invalid_policy_scope", "Phạm vi tri thức công khai có trường chưa được hỗ trợ.")
    if kind == "rule":
        if "claim_type" in payload or "items" in payload:
            raise CoreError("invalid_member_shape", "Quy tắc điều kiện không được mang kiểu khẳng định hoặc danh mục giấy tờ.")
        entries = payload.get("conditions")
        code = "invalid_rule"
    elif kind == "claim":
        if "conditions" in payload:
            raise CoreError("invalid_member_shape", "Khẳng định không được thay thế quy tắc điều kiện.")
        if payload.get("claim_type") not in CLAIMS:
            raise CoreError("invalid_claim", "Loại khẳng định chưa được hỗ trợ.")
        entries = payload.get("items")
        code = "invalid_claim"
    else:
        raise CoreError("invalid_member", "Chỉ hỗ trợ rule hoặc claim.")
    if not isinstance(entries, list) or not 1 <= len(entries) <= 30:
        raise CoreError(code, "Mỗi phiên bản cần từ một đến ba mươi mục có định danh.")
    ids = []
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("id"), str) or not entry["id"].strip():
            raise CoreError(code, "Mỗi mục cần định danh rõ ràng.")
        ids.append(entry["id"])
        if kind == "rule":
            validate_expression(entry.get("expression"))
        elif not isinstance(entry.get("text_vi"), str) or not entry["text_vi"].strip():
            raise CoreError(code, "Mỗi khẳng định cần nội dung tiếng Việt.")
    if payload.get("applies_when") is not None:
        validate_expression(payload["applies_when"])
    exceptions = payload.get("exceptions", [])
    if not isinstance(exceptions, list) or len(exceptions) > 30:
        raise CoreError("invalid_exception", "Ngoại lệ cần danh sách biểu thức hữu hạn.")
    for item in exceptions:
        if not isinstance(item, dict) or not isinstance(item.get("id"), str) or not item["id"].strip():
            raise CoreError("invalid_exception", "Ngoại lệ cần định danh riêng.")
        ids.append(item["id"])
        validate_expression(item.get("expression"))
    if len(set(ids)) != len(ids):
        raise CoreError("invalid_member_shape", "Định danh điều kiện, mục và ngoại lệ phải khác nhau.")
    supersedes = payload.get("supersedes_member_ids", [])
    if (not isinstance(supersedes, list) or len(supersedes) > 30
            or any(not isinstance(value, str) or not value.strip() for value in supersedes)
            or len(set(supersedes)) != len(supersedes)):
        raise CoreError("invalid_supersession", "Danh sách phiên bản được thay thế cần định danh chính xác, không lặp.")
    return ids


class DomainGraph:
    """A read-only unit-of-work projection, not a second source of authority."""

    def __init__(self, db, catalog, *, target_date=None):
        self.db, self.catalog = db, catalog
        self.target_date = target_date or date.today().isoformat()

    def approved_translation(self, chunk_id, quote_hash):
        return self.db.execute("SELECT * FROM pol_translations WHERE chunk_id=? AND original_quote_hash=? "
            "AND review_state='approved' ORDER BY recorded_at DESC LIMIT 1", (chunk_id, quote_hash)).fetchone()

    def source_dependency(self, chunk_id, translation_id=None):
        row = self.db.execute(
            "SELECT c.*,p.source_id,p.text_sha256,p.raw_sha256,p.extraction_version,p.acceptance_state,"
            "p.complete_policy,p.effective_from,p.effective_until,s.title,s.agency,s.url,s.language,s.metadata_json,"
            "s.current_snapshot_id,g.availability,g.checked_at,g.current_until,g.reason_code,g.version gate_version "
            "FROM pol_chunks c JOIN pol_source_snapshots p ON p.id=c.snapshot_id JOIN pol_sources s ON s.id=p.source_id "
            "LEFT JOIN pol_source_gates g ON g.source_id=s.id WHERE c.id=? AND s.usage_scope='public' "
            "AND s.domain='hanoi_policy' AND s.jurisdiction='VN-HN'", (chunk_id,)).fetchone()
        if not row:
            raise CoreError("public_evidence_missing", "Không có trích đoạn công khai đúng phạm vi.", 409)
        item = dict(row)
        translation = self.db.execute("SELECT id,original_quote_hash,text_hash,review_state FROM pol_translations "
            "WHERE id=? AND chunk_id=?", (translation_id, chunk_id)).fetchone() if translation_id else None
        state = {key: item[key] for key in ("title", "agency", "url", "language", "metadata_json", "current_snapshot_id",
            "availability", "checked_at", "current_until", "reason_code", "gate_version", "acceptance_state",
            "complete_policy", "effective_from", "effective_until", "raw_sha256", "extraction_version")}
        source_version = digest({key: item[key] for key in ("title", "agency", "url", "language", "metadata_json", "current_snapshot_id",
            "availability", "checked_at", "current_until", "reason_code", "gate_version")})
        state["assessment_blocker"] = self.catalog._source_gate(item, self.target_date)
        state["translation"] = dict(translation) if translation else None
        selected = self.approved_translation(chunk_id, item["quote_hash"])
        state["selected_translation"] = ({key: selected[key] for key in ("id", "original_quote_hash", "text_hash", "review_state")}
                                           if selected and item["language"] != "vi" else None)
        refs = [ref("public_source", item["source_id"], source_version),
                ref("source_snapshot", item["snapshot_id"], item["text_sha256"]),
                ref("source_excerpt", chunk_id, item["span_hash"])]
        if translation:
            refs.append(ref("reviewed_translation", translation["id"], digest(dict(translation))))
        return {"schema_version": GRAPH_VERSION, "target_date": self.target_date, "refs": refs,
                "dependency_hash": digest({"version": GRAPH_VERSION, "target_date": self.target_date, "refs": refs, "state": state})}

    def pack_entries(self):
        """Validate the exact release lineage, never infer it from an ID prefix."""
        for row in self.db.execute("SELECT * FROM pol_packs WHERE publication_state='published' AND availability='usable' ORDER BY id"):
            pack = dict(row)
            try:
                manifest = json.loads(pack["manifest_json"])
            except (TypeError, ValueError):
                continue
            release = self.db.execute("SELECT * FROM pol_release_events WHERE id=? AND pack_id=? AND manifest_hash=?",
                (pack["release_event_id"], pack["id"], pack["manifest_hash"])).fetchone()
            if (not isinstance(manifest, list) or not release or digest(manifest) != pack["manifest_hash"]
                    or any(not isinstance(entry, dict) or not {"member_id", "content_hash", "publication_event_id"} <= entry.keys()
                           or any(not isinstance(entry.get(key), str) or not entry[key] for key in ("member_id", "content_hash", "publication_event_id")) for entry in manifest)
                    or len({entry["member_id"] for entry in manifest}) != len(manifest)):
                continue
            yield pack, manifest

    def member_reason(self, member, entry):
        if (entry["content_hash"] != member["content_hash"] or member["review_state"] != "approved"
                or member["publication_state"] != "published" or member["availability"] != "usable"):
            return "MEMBER_REVIEW_REQUIRED"
        publication = self.db.execute("SELECT p.*,r.decision,r.member_id reviewed_member_id,r.content_hash reviewed_hash "
            "FROM pol_publication_events p JOIN pol_review_events r ON r.id=p.review_event_id "
            "WHERE p.id=? AND p.member_id=? AND p.content_hash=?", (entry["publication_event_id"], member["id"], member["content_hash"])).fetchone()
        if (not publication or publication["decision"] != "approved" or publication["reviewed_member_id"] != member["id"]
                or publication["reviewed_hash"] != member["content_hash"]):
            return "MEMBER_PUBLICATION_LINEAGE_INVALID"
        try:
            payload, bindings = json.loads(member["payload_json"]), json.loads(member["evidence_json"])
            validate_member_payload(member["kind"], payload)
            expected = digest({"kind": member["kind"], "policy_id": member["policy_id"], "title_vi": member["title_vi"],
                "payload": payload, "evidence": bindings, "effective_from": member["effective_from"], "effective_until": member["effective_until"]})
            if expected != member["content_hash"]:
                return "MEMBER_CONTENT_HASH_INVALID"
            ids = [item["id"] for item in payload.get("conditions", payload.get("items", []))] + [item["id"] for item in payload.get("exceptions", [])]
            if not bindings or any(not any(binding.get("supports_id") == identity and binding.get("role") == "primary" for binding in bindings) for identity in ids):
                return "MEMBER_EVIDENCE_COVERAGE_INVALID"
            for binding in bindings:
                reason = self.catalog._source_gate(self.catalog._binding_source(self.db, binding), self.target_date)
                if reason:
                    return reason
        except (CoreError, TypeError, ValueError, KeyError):
            return "MEMBER_CONTRACT_INVALID"
        if (not member["effective_from"] or self.target_date < member["effective_from"]
                or (member["effective_until"] and self.target_date >= member["effective_until"])):
            return "MEMBER_OUTSIDE_EFFECTIVE_PERIOD"
        return None

    def _declared_supersession(self, record):
        """A later source failure/withdrawal must not silently revive old law.

        An explicit, already published/released replacement remains lineage.
        Its own current advice is still independently gated by member_reason.
        """
        member, entry = record["member"], record["entry"]
        if (member["publication_state"] != "published" or not member["effective_from"]
                or self.target_date < member["effective_from"] or entry["content_hash"] != member["content_hash"]):
            return []
        publication = self.db.execute("SELECT p.id FROM pol_publication_events p JOIN pol_review_events r ON r.id=p.review_event_id "
            "WHERE p.id=? AND p.member_id=? AND p.content_hash=? AND r.member_id=p.member_id AND r.content_hash=p.content_hash "
            "AND r.decision='approved'", (entry["publication_event_id"], member["id"], member["content_hash"])).fetchone()
        try:
            payload, bindings = json.loads(member["payload_json"]), json.loads(member["evidence_json"])
            validate_member_payload(member["kind"], payload)
            expected = digest({"kind": member["kind"], "policy_id": member["policy_id"], "title_vi": member["title_vi"],
                "payload": payload, "evidence": bindings, "effective_from": member["effective_from"], "effective_until": member["effective_until"]})
            return payload.get("supersedes_member_ids", []) if publication and expected == member["content_hash"] else []
        except (CoreError, TypeError, ValueError):
            return []

    def records(self):
        records = []
        for pack, manifest in self.pack_entries():
            policy_versions = {}
            for entry in manifest:
                row = self.db.execute("SELECT * FROM pol_members WHERE id=?", (entry["member_id"],)).fetchone()
                if row:
                    member = dict(row)
                    policy_versions.setdefault(member["policy_id"], []).append(ref(member["kind"] + "_version", member["id"], member["content_hash"]))
            for entry in manifest:
                row = self.db.execute("SELECT * FROM pol_members WHERE id=?", (entry["member_id"],)).fetchone()
                if not row:
                    continue
                member = dict(row)
                policy_version = digest(sorted(policy_versions[member["policy_id"]], key=lambda value: (value["kind"], value["id"])))
                records.append({"pack": pack, "entry": entry, "member": member,
                    "policy_ref": ref("policy_version", member["policy_id"], policy_version),
                    "reason": self.member_reason(member, entry)})
        # Supersession is an explicit immutable statement in a reviewed,
        # published and released successor. Dates/UUIDs never choose a winner;
        # withdrawal/expiry of that successor cannot silently revive its past.
        replacements = {}
        for record in records:
            member = record["member"]
            for identity in self._declared_supersession(record):
                previous = self.db.execute("SELECT kind,policy_id FROM pol_members WHERE id=?", (identity,)).fetchone()
                if previous and previous["kind"] == member["kind"] and previous["policy_id"] == member["policy_id"]:
                    replacements.setdefault(identity, []).append(member["id"])
        for record in records:
            record["superseded_by"] = sorted(set(replacements.get(record["member"]["id"], [])))
            if record["superseded_by"]:
                record["reason"] = record["reason"] or "MEMBER_SUPERSEDED"
        return records

    def member_dependency(self, record):
        member, pack = record["member"], record["pack"]
        try:
            bindings = json.loads(member["evidence_json"])
            if not isinstance(bindings, list):
                bindings = []
        except (TypeError, ValueError):
            bindings = []
        refs = [ref("pack_version", pack["id"], pack["manifest_hash"]), record["policy_ref"],
                ref(member["kind"] + "_version", member["id"], member["content_hash"]),
                ref("publication", record["entry"]["publication_event_id"], member["content_hash"])]
        sources = []
        for binding in bindings:
            if not isinstance(binding, dict):
                continue
            try:
                sources.append(self.source_dependency(binding["chunk_id"]))
            except (CoreError, KeyError, TypeError):
                sources.append({"unavailable_excerpt_id": binding.get("chunk_id")})
        state = {key: member[key] for key in ("review_state", "publication_state", "availability", "effective_from", "effective_until")}
        return {"schema_version": GRAPH_VERSION, "refs": refs, "target_date": self.target_date,
                "dependency_hash": digest({"version": GRAPH_VERSION, "refs": refs, "sources": sources, "state": state,
                                           "target_date": self.target_date, "reason": record["reason"], "superseded_by": record["superseded_by"]})}

    def project(self):
        nodes, edges = {}, []

        def node(reference, **attributes):
            key = (reference["kind"], reference["id"], reference["version"])
            nodes[key] = {"ref": reference, **attributes}

        def edge(left, relation, right, **attributes):
            edges.append({"from": left, "relation": relation, "to": right, **attributes})

        # Unreviewed public sources are discovery nodes, not implicit claims.
        # Only this public-policy table family is read; enterprise/document
        # tables and values can never enter a reusable projection.
        for chunk in self.db.execute("SELECT c.id,s.current_snapshot_id,c.snapshot_id FROM pol_chunks c "
                "JOIN pol_source_snapshots p ON p.id=c.snapshot_id JOIN pol_sources s ON s.id=p.source_id "
                "WHERE s.usage_scope='public' AND s.domain='hanoi_policy' AND s.jurisdiction='VN-HN' ORDER BY c.id"):
            dependency = self.source_dependency(chunk["id"])
            source_ref, snapshot_ref, excerpt_ref = dependency["refs"][:3]
            for reference in (source_ref, snapshot_ref, excerpt_ref):
                node(reference)
            edge(excerpt_ref, "excerpt_of", snapshot_ref)
            edge(snapshot_ref, "snapshot_of", source_ref)
            if chunk["snapshot_id"] == chunk["current_snapshot_id"]:
                edge(source_ref, "has_current_snapshot", snapshot_ref, basis="source.current_snapshot_id")
            elif chunk["current_snapshot_id"]:
                current = self.db.execute("SELECT id,text_sha256 FROM pol_source_snapshots WHERE id=?",
                                          (chunk["current_snapshot_id"],)).fetchone()
                if current:
                    current_ref = ref("source_snapshot", current["id"], current["text_sha256"])
                    node(current_ref)
                    edge(current_ref, "supersedes_snapshot", snapshot_ref, basis="source.current_snapshot_id")

        for record in self.records():
            member, pack = record["member"], record["pack"]
            try:
                payload = json.loads(member["payload_json"])
                validate_member_payload(member["kind"], payload)
            except (CoreError, ValueError, TypeError):
                payload = {}
            pack_ref = ref("pack_version", pack["id"], pack["manifest_hash"])
            policy_ref = record["policy_ref"]
            member_ref = ref(member["kind"] + "_version", member["id"], member["content_hash"])
            node(pack_ref, state=pack["availability"])
            node(policy_ref, logical_policy_id=member["policy_id"])
            node(member_ref, member_contract=MEMBER_VERSION, status="blocked" if record["reason"] else "usable",
                 reason_code=record["reason"], scope=payload.get("scope"), applies_when=payload.get("applies_when"),
                 effective_from=member["effective_from"], effective_until=member["effective_until"],
                 exceptions=payload.get("exceptions", []), claim_type=payload.get("claim_type"))
            edge(pack_ref, "contains_policy_version", policy_ref)
            edge(policy_ref, "contains_member_version", member_ref)
            try:
                bindings = json.loads(member["evidence_json"])
            except (TypeError, ValueError):
                bindings = []
            for binding in bindings if isinstance(bindings, list) else []:
                if not isinstance(binding, dict):
                    continue
                try:
                    dep = self.source_dependency(binding["chunk_id"])
                except (CoreError, KeyError, TypeError):
                    continue
                source_ref, snapshot_ref, excerpt_ref = dep["refs"][:3]
                for reference in (source_ref, snapshot_ref, excerpt_ref):
                    node(reference)
                edge(member_ref, "cites", excerpt_ref, basis_role=binding["role"], supports_id=binding.get("supports_id"),
                     quote_hash=binding["quote_original_hash"], scope=payload.get("scope"),
                     applies_when=payload.get("applies_when"), effective_from=member["effective_from"], effective_until=member["effective_until"])
                edge(excerpt_ref, "excerpt_of", snapshot_ref)
                edge(snapshot_ref, "snapshot_of", source_ref)
                current = self.db.execute("SELECT p.id,p.text_sha256 FROM pol_sources s JOIN pol_source_snapshots p "
                    "ON p.id=s.current_snapshot_id WHERE s.id=?", (source_ref["id"],)).fetchone()
                if current and current["id"] != snapshot_ref["id"]:
                    current_ref = ref("source_snapshot", current["id"], current["text_sha256"])
                    node(current_ref)
                    edge(current_ref, "supersedes_snapshot", snapshot_ref, basis="source.current_snapshot_id")
            for condition in [*payload.get("conditions", []), *payload.get("exceptions", [])]:
                try:
                    fields = expression_fields(condition["expression"])
                except (CoreError, KeyError, TypeError):
                    continue
                for field in sorted(fields):
                    field_ref = ref("domain_field_requirement", field, MEMBER_VERSION)
                    node(field_ref)
                    edge(member_ref, "exception_requires_fact" if condition in payload.get("exceptions", []) else "requires_fact", field_ref,
                         condition_id=condition["id"], expression=condition["expression"])
            if payload.get("applies_when"):
                for field in sorted(expression_fields(payload["applies_when"])):
                    field_ref = ref("domain_field_requirement", field, MEMBER_VERSION)
                    node(field_ref)
                    edge(member_ref, "applies_when_requires_fact", field_ref, expression=payload["applies_when"])
            for previous in payload.get("supersedes_member_ids", []):
                row = self.db.execute("SELECT kind,policy_id,content_hash FROM pol_members WHERE id=?", (previous,)).fetchone()
                if row and row["policy_id"] == member["policy_id"] and row["kind"] == member["kind"]:
                    edge(member_ref, "supersedes_member_version", ref(row["kind"] + "_version", previous, row["content_hash"]),
                         effective_from=member["effective_from"], declared_only=True,
                         active=previous in self._declared_supersession(record))
        values = sorted(nodes.values(), key=lambda value: json_text(value["ref"]))
        edges = sorted({json_text(value): value for value in edges}.values(), key=json_text)
        return {"schema_version": GRAPH_VERSION, "target_date": self.target_date, "domain": "hanoi_policy", "jurisdiction": "VN-HN",
                "nodes": values, "edges": edges, "projection_hash": digest({"nodes": values, "edges": edges}),
                "authority": "existing_public_policy_sql_records", "rebuildable": True, "writes": 0, "provider_calls": 0}
