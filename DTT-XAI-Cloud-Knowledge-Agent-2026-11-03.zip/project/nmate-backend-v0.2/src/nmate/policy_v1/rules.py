"""Finite, non-executable four-state policy condition language."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
import math

from nmate.v03.core import CoreError

OPS = {"eq", "ne", "in", "contains", "gte", "gt", "lte", "lt", "present"}


def validate_expression(expression, depth=0):
    if not isinstance(expression, dict) or depth > 8:
        raise CoreError("invalid_condition", "Điều kiện phải là biểu thức hữu hạn, tối đa 8 cấp.")
    if set(expression) & {"all", "any", "not"}:
        if len(expression) != 1:
            raise CoreError("invalid_condition", "Không trộn toán tử điều kiện.")
        key = next(iter(expression))
        children = [expression[key]] if key == "not" else expression[key]
        if not isinstance(children, list) or not 1 <= len(children) <= 30:
            raise CoreError("invalid_condition", "Nhóm điều kiện không hợp lệ.")
        for child in children:
            validate_expression(child, depth + 1)
        return
    if not set(expression) <= {"field", "op", "value", "entity_type", "unit", "period"}:
        raise CoreError("invalid_condition", "Có trường hoặc toán tử chưa được hỗ trợ.")
    if not isinstance(expression.get("field"), str) or not expression["field"] or expression.get("op") not in OPS:
        raise CoreError("invalid_condition", "Cần field và toán tử thuộc danh mục.")
    if expression["op"] != "present" and "value" not in expression:
        raise CoreError("invalid_condition", "Điều kiện thiếu giá trị đối chiếu.")
    if expression["op"] == "in" and not isinstance(expression.get("value"), list):
        raise CoreError("invalid_condition", "Toán tử in cần một danh sách.")


def expression_fields(expression):
    validate_expression(expression)
    if "field" in expression:
        return {expression["field"]}
    result = set()
    for key, value in expression.items():
        for child in ([value] if key == "not" else value):
            result |= expression_fields(child)
    return result


def _decimal(value):
    # Floats have already lost decimal precision; financial thresholds require exact strings.
    if isinstance(value, (bool, float)) or value is None:
        raise InvalidOperation
    if isinstance(value, dict):
        value = value.get("amount", value.get("value"))
    result = Decimal(str(value))
    if not result.is_finite() or (isinstance(value, float) and not math.isfinite(value)):
        raise InvalidOperation
    return result


def evaluate(expression, facts):
    """Facts are approved context facts only; an absent value is never false/zero."""
    validate_expression(expression)
    if "field" not in expression:
        key = next(iter(expression))
        items = [expression[key]] if key == "not" else expression[key]
        results = [evaluate(item, facts) for item in items]
        states = [item["state"] for item in results]
        if key == "not":
            state = {"met": "not_met", "not_met": "met"}.get(states[0], states[0])
        elif "conflict" in states:
            state = "conflict"
        elif key == "all":
            state = "not_met" if "not_met" in states else "unknown" if "unknown" in states else "met"
        else:
            state = "met" if "met" in states else "unknown" if "unknown" in states else "not_met"
        return {"state": state, "children": results,
                "missing_fact_keys": sorted({f for item in results for f in item.get("missing_fact_keys", [])}),
                "fact_version_refs": [ref for item in results for ref in item.get("fact_version_refs", [])]}
    field = expression["field"]
    candidates = [fact for fact in facts if fact.get("field") == field and
                  (not expression.get("entity_type") or fact.get("entity_type") == expression["entity_type"])]
    usable = [fact for fact in candidates if fact.get("value_state", "known") == "known" and
              fact.get("temporal_state", "current") == "current"]
    refs = [{k: fact.get(k) for k in ("entity_id", "field", "version", "assertion_id")} for fact in candidates]
    result = {"field": field, "state": "unknown", "missing_fact_keys": [field], "fact_version_refs": refs}
    if any(fact.get("value_state") in {"disputed", "conflicted"} for fact in candidates):
        return {**result, "state": "conflict", "reason_code": "FACT_DISPUTED"}
    if expression["op"] == "present" and any(fact.get("value_state") in {"explicit_absent", "known_absent"} for fact in candidates):
        return {**result, "state": "not_met", "missing_fact_keys": [], "reason_code": "CONFIRMED_ABSENT"}
    if not usable:
        return {**result, "reason_code": "CONFIRMED_FACT_REQUIRED"}
    if len({repr(fact.get("value")) for fact in usable}) > 1:
        return {**result, "state": "conflict", "reason_code": "FACT_SCOPE_AMBIGUOUS"}
    fact = usable[0]
    value, expected, op = fact.get("value"), expression.get("value"), expression["op"]
    if value is None:
        return {**result, "reason_code": "CONFIRMED_FACT_REQUIRED"}
    if expression.get("unit") and fact.get("unit") != expression["unit"]:
        return {**result, "reason_code": "UNIT_MISMATCH"}
    if expression.get("period") and fact.get("period") != expression["period"]:
        return {**result, "reason_code": "PERIOD_MISMATCH"}
    try:
        if op == "present":
            met = True
        elif op in {"gte", "gt", "lte", "lt"}:
            left, right = _decimal(value), _decimal(expected)
            met = {"gte": left >= right, "gt": left > right, "lte": left <= right, "lt": left < right}[op]
        elif op == "eq":
            met = type(value) is type(expected) and value == expected
        elif op == "ne":
            met = type(value) is type(expected) and value != expected
        elif op == "in":
            met = any(type(value) is type(item) and value == item for item in expected)
        else:
            if not isinstance(value, (str, list)):
                return {**result, "reason_code": "VALUE_TYPE_MISMATCH"}
            met = expected in value
    except (InvalidOperation, TypeError, ValueError):
        return {**result, "reason_code": "VALUE_TYPE_MISMATCH"}
    return {**result, "state": "met" if met else "not_met", "missing_fact_keys": []}
