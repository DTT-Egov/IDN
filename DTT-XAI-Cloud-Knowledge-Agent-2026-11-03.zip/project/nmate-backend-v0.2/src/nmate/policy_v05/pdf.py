"""Print the authorized, exact policy-draft version without a model call."""
from io import BytesIO

from nmate.v03.label_pdf import register_fonts, _text
from nmate.v03.core import CoreError
from .workbench import BODY_FIELDS


BODY_LABELS = {
    "enterprise_summary": "Thông tin cơ sở",
    "enterprise": "Thông tin cơ sở", "situation": "Tình hình và nhu cầu",
    "needs": "Nhu cầu đề nghị", "request": "Nội dung đề nghị", "impact": "Ảnh hưởng",
    "facts": "Dữ kiện đã xác nhận", "background": "Thông tin liên quan",
    "requested_support": "Hỗ trợ mong muốn", "proposed_solution": "Kiến nghị cụ thể",
    "evidence": "Bằng chứng được cung cấp", "statement": "Nội dung chủ cơ sở cung cấp",
    "recipient": "Nơi dự kiến nhận", "missing_information": "Thông tin cần bổ sung",
    "subject": "Về việc", "introduction": "Thông tin mở đầu", "requested_actions": "Đề nghị",
    "context": "Thông tin cơ sở", "requests": "Các đề nghị", "limitations": "Giới hạn",
}
BODY_ORDER = ("enterprise_summary", "requested_support", "situation", "impact", "request")
assert set(BODY_ORDER) == BODY_FIELDS


def _plain(value):
    if isinstance(value, list):
        return "\n".join(_plain(item) for item in value)
    if isinstance(value, dict):
        return "\n".join(f"{BODY_LABELS.get(key, key)}: {_plain(item)}" for key, item in value.items())
    return str(value) if value is not None else "Chưa có thông tin"


def render_policy_draft(draft):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer

    if not isinstance(draft.get("body"), dict) or set(draft["body"]) - BODY_FIELDS:
        raise CoreError("PDF_DRAFT_SCHEMA_CHANGED", "Bản nháp có trường chưa được bản PDF này hỗ trợ. Chị mở lại bản xem trước để đối chiếu.", 409)
    register_fonts()
    stream = BytesIO()
    doc = SimpleDocTemplate(stream, pagesize=A4, leftMargin=20*mm, rightMargin=20*mm,
        topMargin=18*mm, bottomMargin=20*mm, title=draft["title"], author="nMate")
    body = ParagraphStyle("PolicyText", fontName="nMateText", fontSize=10.5, leading=16, spaceAfter=8,
                          textColor=colors.HexColor("#14213a"), splitLongWords=True)
    heading = ParagraphStyle("PolicyHeading", parent=body, fontName="nMateHeading", fontSize=12, leading=17)
    title = ParagraphStyle("PolicyTitle", parent=heading, fontSize=19, leading=25, spaceAfter=12)
    small = ParagraphStyle("PolicySmall", parent=body, fontSize=9, leading=13)
    items = [Paragraph(_text(draft["title"]), title),
             Paragraph("BẢN NHÁP — Chưa gửi tới iHanoi hoặc cơ quan tiếp nhận.", heading),
             Paragraph(_text(f"Phiên bản {draft['version']} · Bản tự soạn từ lời đề nghị và hồ sơ được phép sử dụng; chưa phải quyết định hỗ trợ."), small)]
    approval = draft.get('approval') or {}
    exact_approval = (draft.get('status') == 'approved' and approval.get('type') == 'draft_content_only'
                      and approval.get('approved_version') == draft['version']
                      and bool(draft.get('content_hash')) and approval.get('content_hash') == draft['content_hash'])
    if exact_approval:
        items.append(Paragraph(_text(f"Đã duyệt nội dung phiên bản {draft['version']} · Chưa gửi. Lần duyệt này chỉ áp dụng đúng nội dung phiên bản này."), small))
    else:
        items.append(Paragraph("Phiên bản này chưa được duyệt nội dung.", small))
        if draft.get('previous_approval_id'):
            items.append(Paragraph("Lần duyệt trước không áp dụng cho phiên bản này.", small))
    if draft.get("kind") == "request_guidance":
        items.append(Paragraph("Đề nghị hướng dẫn: chưa xác minh đủ chương trình, mẫu và đợt tiếp nhận để lập hồ sơ đăng ký chính thức.", small))
    if draft.get("is_historical"):
        items.append(Paragraph("Bản nháp lịch sử — cần đối chiếu trước khi dùng mới.", heading))
    for warning in draft.get("current_warnings_vi", []):
        items.append(Paragraph(_text(warning), small))
    for key in BODY_ORDER:
        if key in draft["body"]:
            value = draft["body"][key]
            items.extend([Paragraph(_text(BODY_LABELS[key]), heading),
                          Paragraph(_text(_plain(value) if value not in (None, "") else "[Chưa cung cấp]"), body)])
    checklist = draft.get("checklist") or []
    if checklist:
        items.extend([Spacer(1, 3*mm), Paragraph("Cần đối chiếu trước khi gửi", heading)])
        for item in checklist:
            text = (item.get("label_vi") or item.get("label") or item.get("title_vi") or _plain(item)) if isinstance(item, dict) else str(item)
            items.append(Paragraph(_text("• " + text), body))
    items.append(Paragraph("Duyệt nội dung bản nháp không phải đồng ý chia sẻ hoặc xác nhận cơ quan đã nhận. Bản này không tự thay đổi hồ sơ chuẩn.", small))

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("nMateText", 8)
        canvas.drawString(20*mm, 12*mm, f"nMate · Bản nháp · Phiên bản {draft['version']} · Trang {document.page}")
        canvas.restoreState()

    doc.build(items, onFirstPage=footer, onLaterPages=footer)
    return stream.getvalue()
