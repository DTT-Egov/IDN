"""Durable policy-work drafts, without policy authority or a model transport.

DF-027: source discovery never establishes eligibility, an open intake or an
official application form. DF-029/032/046: each saved derivative retains exact
input lineage; replay is a current-authorized READ, not a fresh mutation.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re

from nmate.core_v1.ssot import CoreSSOTService
from nmate.core_v1.enterprise_profile import bound_enterprise_profile_id
from nmate.policy_v1.service import GOAL_LABELS, intent_goals, resolve_intent
from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.domain_validation import base_field_key
from nmate.v03.field_scope import canonical_entity_type


SCHEMA = """
CREATE TABLE IF NOT EXISTS pol05_drafts (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 owner_id TEXT NOT NULL REFERENCES v03_accounts(id),version INTEGER NOT NULL CHECK(version>0),
 status TEXT NOT NULL CHECK(status IN ('draft','approved')),conversation_id TEXT,
 payload_json TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 UNIQUE(enterprise_id,id));
CREATE INDEX IF NOT EXISTS pol05_drafts_owner ON pol05_drafts(enterprise_id,owner_id,created_at);
CREATE TABLE IF NOT EXISTS pol05_revisions (
 enterprise_id TEXT NOT NULL,draft_id TEXT NOT NULL,version INTEGER NOT NULL,
 content_hash TEXT NOT NULL,payload_json TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 recorded_at TEXT NOT NULL,PRIMARY KEY(enterprise_id,draft_id,version),
 FOREIGN KEY(enterprise_id,draft_id) REFERENCES pol05_drafts(enterprise_id,id));
CREATE TABLE IF NOT EXISTS pol05_approvals (
 id TEXT PRIMARY KEY,enterprise_id TEXT NOT NULL,draft_id TEXT NOT NULL,version INTEGER NOT NULL,
 owner_id TEXT NOT NULL REFERENCES v03_accounts(id),payload_json TEXT NOT NULL,recorded_at TEXT NOT NULL,
 UNIQUE(enterprise_id,draft_id,version),
 FOREIGN KEY(enterprise_id,draft_id,version) REFERENCES pol05_revisions(enterprise_id,draft_id,version));
CREATE TRIGGER IF NOT EXISTS pol05_revisions_immutable BEFORE UPDATE ON pol05_revisions
 BEGIN SELECT RAISE(ABORT,'immutable policy draft revision'); END;
CREATE TRIGGER IF NOT EXISTS pol05_revisions_no_delete BEFORE DELETE ON pol05_revisions
 BEGIN SELECT RAISE(ABORT,'immutable policy draft revision'); END;
CREATE TRIGGER IF NOT EXISTS pol05_approvals_immutable BEFORE UPDATE ON pol05_approvals
 BEGIN SELECT RAISE(ABORT,'immutable policy draft approval'); END;
CREATE TRIGGER IF NOT EXISTS pol05_approvals_no_delete BEFORE DELETE ON pol05_approvals
 BEGIN SELECT RAISE(ABORT,'immutable policy draft approval'); END;
"""

BODY_FIELDS = frozenset({'enterprise_summary', 'requested_support', 'situation', 'impact', 'request'})
ENTERPRISE_FIELDS = frozenset({'name', 'trading_name', 'legal_name', 'legal_form', 'enterprise_type', 'province',
                              'registration_province', 'industry', 'business_sector', 'address'})
PRODUCT_FIELDS = frozenset({'name', 'sku', 'product_code'})
KINDS = frozenset({'participation_request', 'business_petition'})
ARTIFACT_CONTRACT_VERSION = 'policy-artifact/2'


def request_details(question):
    """Copy affirmative request spans; never infer facts, impact or eligibility.

    Topic classification is intentionally left to the shared resolver. These
    offsets bind the concrete requested action to the original statement so an
    artifact cannot replace it with only a broad topic label (DF-024/026).
    """
    candidates = []
    verbs = r'(?:kiến nghị|đề nghị|mong muốn|muốn|xin)'
    actor = r'(?:(?:chị|anh|tôi|mình|em|chúng tôi)\s+)?'
    polarity = r'(?:(?:chỉ|không|chưa|đừng|chẳng)\s+)*'
    joining = r'(?:đồng thời|nhưng|còn|và|mà(?:\s+còn)?)'
    next_directive = actor + polarity + verbs + r'\b'
    # Both affirmative and negated directives start a new clause. Otherwise a
    # later "không đề nghị" can erase an earlier affirmative "muốn". Numeric
    # commas/dots remain within the original exact request span.
    boundary = re.compile(r'[;!?\n]+|\.(?=\s|$)|,\s*(?=' + joining + r'\b|' + next_directive + r')'
                          r'|\s+(?=' + joining + r'\s+' + next_directive + r')', re.I)
    marker = re.compile(r'\b(kiến nghị|đề nghị|mong muốn|muốn|xin)(?:\s*[:：]\s*|\s+)', re.I)
    offset = 0
    clauses = []
    for match in boundary.finditer(question):
        clauses.append((offset, match.start()))
        offset = match.end()
    clauses.append((offset, len(question)))
    for start, end in clauses:
        clause = question[start:end]
        matches = list(marker.finditer(clause))
        if not matches:
            continue
        # "muốn kiến nghị ..." contains a soft desire and an explicit petition;
        # keep the innermost explicit request, not a duplicate of both.
        strong = [item for item in matches if item.group(1).casefold() in {'kiến nghị', 'đề nghị'}]
        chosen = strong[-1] if strong else matches[-1]
        prefix = clause[:chosen.start()]
        # An affirmative restart is local to the clause, not a blanket removal
        # of a negation earlier in the user's statement.
        prefix = re.split(r'\b(?:nhưng|mà|chỉ)\b', prefix, flags=re.I)[-1]
        if re.search(r'\b(?:không|chưa|đừng|chẳng)\b', prefix, re.I):
            continue
        span_start, span_end = start + chosen.end(), end
        while span_start < span_end and question[span_start].isspace():
            span_start += 1
        while span_end > span_start and question[span_end - 1] in ' \t\r\n,;.!?':
            span_end -= 1
        if span_start < span_end:
            candidates.append({'text': question[span_start:span_end], 'source': 'question',
                               'start': span_start, 'end': span_end})
    # Explicit requests have no global precedence over a separate affirmative
    # desire. Every retained clause is a distinct supported source statement.
    return candidates


def artifact_checklist(kind):
    shared = {'id': 'review_facts', 'label_vi': 'Kiểm tra thông tin cơ sở và nội dung đề nghị', 'status': 'needs_review'}
    if kind == 'business_petition':
        return [shared,
                {'id': 'review_petition', 'label_vi': 'Kiểm tra điều kiến nghị cụ thể, tình hình và bằng chứng thực tế nếu có', 'status': 'needs_review'},
                {'id': 'review_destination', 'label_vi': 'Kiểm tra nơi nhận kiến nghị và phạm vi công khai trước khi gửi', 'status': 'not_verified'}]
    return [shared,
            {'id': 'verify_programme', 'label_vi': 'Xác minh chương trình, mẫu và đợt tiếp nhận nếu muốn đăng ký', 'status': 'not_verified'},
            {'id': 'review_destination', 'label_vi': 'Kiểm tra nơi nhận đề nghị hướng dẫn và phạm vi công khai trước khi gửi', 'status': 'not_verified'}]


def digest(value):
    return hashlib.sha256(json_text(value).encode('utf8')).hexdigest()


def content_hash(payload):
    """Seal the view the owner approves; exclude operation/projection metadata."""
    return digest({key: payload.get(key) for key in (
        'id', 'enterprise_id', 'owner_id', 'version', 'kind', 'requested_kind', 'question',
        'title', 'body', 'needs', 'purposes', 'checklist', 'context_manifest', 'sharing',
        'program_readiness', 'limitations_vi', 'policy_case_id', 'conversation_id',
        'artifact_contract_version', 'request_details')})


class PolicyWorkbench:
    def __init__(self, repo, core=None, policy=None, *, initialize=True):
        self.repo = repo
        self.core = core or CoreSSOTService(repo)
        self.policy = policy
        self.before_write = None
        # The managed runtime verifies an operator migration before construction;
        # it may not silently add tables or bootstrap an authority/source.
        if initialize and not getattr(repo, 'managed_runtime', False):
            with repo.connection(write=True) as db:
                db.executescript(SCHEMA)

    @staticmethod
    def _text(value, label, *, maximum=6000, empty=False):
        if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
            raise CoreError('invalid_policy_draft', f'{label} cần có nội dung hợp lệ, tối đa {maximum} ký tự.')
        return value.strip()

    @staticmethod
    def _version(value):
        if not isinstance(value, int) or isinstance(value, bool) or value < 1:
            raise CoreError('version_conflict', 'Cần phiên bản bản nháp chị đã xem.', 409)

    def _conversation(self, db, account, enterprise, conversation_id):
        if conversation_id is None:
            return
        if not isinstance(conversation_id, str) or not db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='v04_conversations'").fetchone():
            raise CoreError('not_found', 'Không tìm thấy cuộc trao đổi được phép dùng.', 404)
        if not db.execute('SELECT 1 FROM v04_conversations WHERE id=? AND enterprise_id=? AND owner_id=?',
                          (conversation_id, enterprise, account)).fetchone():
            raise CoreError('not_found', 'Không tìm thấy cuộc trao đổi được phép dùng.', 404)

    def _read_authority(self, db, account, enterprise, payload):
        self.core.membership(account, enterprise, db)
        if payload.get('enterprise_id') != enterprise or payload.get('owner_id') != account:
            raise CoreError('not_found', 'Không tìm thấy bản nháp được phép xem.', 404)
        self._conversation(db, account, enterprise, payload.get('conversation_id'))
        manifest = payload['context_manifest']
        for entity in manifest.get('entities', []):
            self.core._entity(db, enterprise, entity['entity_id'])
            self.core._require(db, account, enterprise, entity['entity_id'])
            for field in entity['fields']:
                self.core._require(db, account, enterprise, entity['entity_id'], field=field)
        if payload.get('policy_case_id'):
            if self.policy is None:
                raise CoreError('policy_case_unavailable', 'Chưa kiểm tra được quyền đọc căn cứ chính sách.', 409)
            self.policy.get(account, enterprise, payload['policy_case_id'])

    def _row(self, db, account, enterprise, draft_id):
        self.core.membership(account, enterprise, db)
        row = db.execute('SELECT * FROM pol05_drafts WHERE enterprise_id=? AND owner_id=? AND id=?',
                         (enterprise, account, draft_id)).fetchone()
        if row is None:
            raise CoreError('not_found', 'Không tìm thấy bản nháp được phép xem.', 404)
        payload = json.loads(row['payload_json'])
        self._read_authority(db, account, enterprise, payload)
        return row, payload

    def _operation(self, db, account, enterprise, kind, operation_id, request):
        self.core.membership(account, enterprise, db)
        fingerprint, previous = self.repo._operation(db, account, enterprise, 'policy05_' + kind, operation_id, request)
        if previous is not None:
            self._read_authority(db, account, enterprise, previous)
        return fingerprint, previous

    def _entities(self, db, account, enterprise, enterprise_entity_id, product_entity_id, policy_case_id, conversation_id):
        if policy_case_id:
            if self.policy is None:
                raise CoreError('policy_case_unavailable', 'Chưa kiểm tra được hồ sơ chính sách đã chọn.', 409)
            case = self.policy.get(account, enterprise, policy_case_id)
            bound_conversation = case.get('conversation_id')
            if conversation_id and bound_conversation and conversation_id != bound_conversation:
                raise CoreError('context_scope_conflict', 'Hồ sơ chính sách thuộc cuộc trao đổi khác; chị mở đúng cuộc trao đổi để tiếp tục.', 409)
            conversation_id = conversation_id or bound_conversation
            self._conversation(db, account, enterprise, conversation_id)
            case_enterprises = [entity['id'] for entity in case.get('context', {}).get('entities', [])
                                if canonical_entity_type(entity.get('entity_type')) == 'enterprise']
            case_products = [entity['id'] for entity in case.get('context', {}).get('entities', [])
                             if canonical_entity_type(entity.get('entity_type')) == 'product']
            if enterprise_entity_id and case_enterprises and enterprise_entity_id not in case_enterprises:
                raise CoreError('context_scope_conflict', 'Hồ sơ cơ sở khác căn cứ của cuộc trao đổi chính sách.', 409)
            if enterprise_entity_id is None and len(case_enterprises) == 1:
                enterprise_entity_id = case_enterprises[0]
            elif enterprise_entity_id is None and len(case_enterprises) > 1:
                # Ambiguous case lineage is a terminal binding result. A
                # canonical profile linked later is a default for an unbound
                # request, never evidence to replace one of these case inputs.
                raise CoreError('enterprise_entity_required',
                                'Có nhiều hồ sơ cơ sở trong căn cứ của cuộc trao đổi chính sách. Chị chọn đúng hồ sơ trong căn cứ này để chuẩn bị bản nháp.', 409)
            if product_entity_id and case_products and product_entity_id not in case_products:
                raise CoreError('context_scope_conflict', 'Sản phẩm khác căn cứ của hồ sơ chính sách; chị mở đúng hồ sơ để tiếp tục.', 409)
            if product_entity_id is None and len(case_products) == 1:
                product_entity_id = case_products[0]
            elif product_entity_id is None and len(case_products) > 1:
                raise CoreError('product_entity_required', 'Có nhiều sản phẩm trong căn cứ; chị chọn đúng sản phẩm để chuẩn bị bản nháp.', 409)
        if enterprise_entity_id is None:
            # An explicit canonical profile is the default of a NEW command,
            # after any case-specific binding. Its denied READ must not fall
            # through to a different visible profile (DF-008/009/032/046).
            enterprise_entity_id = bound_enterprise_profile_id(self.core, db, account, enterprise)
        if enterprise_entity_id is None:
            visible = [row['id'] for row in db.execute('SELECT * FROM v03_entities WHERE enterprise_id=?', (enterprise,))
                       if canonical_entity_type(row['entity_type']) == 'enterprise'
                       and not self.repo.entity_lifecycle(db, enterprise, row['id'])['archived']
                       and self.core._can(db, account, enterprise, row['id'])]
            if len(visible) > 1:
                raise CoreError('enterprise_entity_required', 'Có nhiều hồ sơ cơ sở. Chị chọn đúng hồ sơ để chuẩn bị bản nháp.', 409)
            enterprise_entity_id = visible[0] if visible else None
        selected = []
        for identity, expected_type, allowed in [(enterprise_entity_id, 'enterprise', ENTERPRISE_FIELDS),
                                                  (product_entity_id, 'product', PRODUCT_FIELDS)]:
            if identity is None:
                continue
            entity = self.core._entity(db, enterprise, identity)
            self.core._require(db, account, enterprise, identity)
            if canonical_entity_type(entity['entity_type']) != expected_type:
                code = 'invalid_enterprise_entity' if expected_type == 'enterprise' else 'invalid_product_entity'
                raise CoreError(code, 'Loại hồ sơ đã chọn không đúng phạm vi cơ sở/sản phẩm.')
            if entity['archived']:
                raise CoreError('entity_archived', 'Hồ sơ đã cất; cần chọn hồ sơ đang dùng để tạo bản nháp mới.', 409)
            self.repo.require_usable_ai_identity(entity)
            fields = set(allowed)
            # Registry classifies qualifiers; original exact keys stay unchanged.
            fields.update(row[0] for row in db.execute('SELECT field FROM v03_current_facts WHERE enterprise_id=? AND entity_id=?',
                                                      (enterprise, identity)) if base_field_key(row[0]) in allowed)
            readable = []
            for field in sorted(fields):
                try:
                    self.core._require(db, account, enterprise, identity, field=field)
                except CoreError as exc:
                    if exc.status_code != 403:
                        raise
                else:
                    readable.append(field)
            selected.append({'entity_id': identity, 'entity_type': expected_type, 'fields': readable})
        return selected, enterprise_entity_id, product_entity_id, conversation_id

    def _context(self, account, enterprise, selected):
        snapshots = [self.core.get_context(account, enterprise, [item['entity_id']], item['fields'], save_snapshot=False)
                     for item in selected]
        entities = [entity for snapshot in snapshots for entity in snapshot['entities']]
        refs = [ref for snapshot in snapshots for ref in snapshot['fact_refs']]
        compact = [{'id': entity['id'], 'entity_type': entity['entity_type'], 'name': entity['name'],
                    'values': entity['values'], 'facts': [{key: fact.get(key) for key in (
                        'field', 'value', 'value_state', 'version', 'assertion_id', 'resolution_id',
                        'freshness_state', 'valid_from', 'valid_to')} for fact in entity['facts']]}
                   for entity in entities]
        return {'entities': compact, 'fact_refs': refs, 'dependency_hash': digest({'entities': compact, 'fact_refs': refs})}

    @staticmethod
    def _summary(context):
        company = next((entity for entity in context['entities'] if canonical_entity_type(entity['entity_type']) == 'enterprise'), None)
        if company is None:
            return 'Chưa có hồ sơ cơ sở được xác nhận; cần bổ sung trước khi gửi cho nơi tiếp nhận.'
        values = company['values']
        # The canonical exact keys have distinct meanings. A confirmed trading
        # name never becomes a legal name; an entity's metadata is neither.
        parts = []
        if values.get('trading_name'):
            parts.append('Tên giao dịch đã xác nhận: ' + str(values['trading_name']))
        if values.get('legal_name'):
            parts.append('Tên pháp lý đã xác nhận: ' + str(values['legal_name']))
        elif values.get('trading_name'):
            parts.append('Tên pháp lý chưa có dữ kiện xác nhận')
        if values.get('name'):
            parts.append('Tên cơ sở đã xác nhận: ' + str(values['name']))
        if not parts:
            parts = ['Hồ sơ cơ sở: ' + company['name'], 'Tên cơ sở/pháp lý chưa có dữ kiện xác nhận']
        for aliases in [('legal_form', 'enterprise_type'), ('province', 'registration_province')]:
            known = [values[field] for field in aliases if field in values]
            if known and len({json_text(value) for value in known}) == 1:
                parts.append(str(known[0]))
            elif aliases[0] == 'legal_form':
                parts.append('Loại hình pháp lý chưa có dữ kiện xác nhận')
        return ' · '.join(parts)

    @staticmethod
    def _needs(intent, kind):
        # A topic can support different artifacts. The remaining verification
        # work follows the artifact's purpose, never a registration default.
        reason = ('Cần kiểm tra điều kiến nghị cụ thể, nơi nhận và bằng chứng thực tế được cung cấp trước khi gửi kiến nghị.'
                  if kind == 'business_petition' else
                  'Cần kiểm chương trình, đối tượng và đợt tiếp nhận trước khi xác định điều kiện hoặc đăng ký.')
        return [{'need_id': goal, 'label_vi': GOAL_LABELS[goal], 'status': 'needs_verification',
                 'reason_vi': reason}
                for goal in intent_goals(intent)]

    def create_draft(self, account_id, enterprise_id, question, kind, operation_id,
                     conversation_id=None, policy_case_id=None, product_entity_id=None,
                     enterprise_entity_id=None, on_commit=None):
        question = self._text(question, 'Câu hỏi')
        if kind not in KINDS:
            raise CoreError('invalid_draft_kind', 'Chọn chuẩn bị tham gia hoặc phản ánh/kiến nghị.')
        request = {'question': question, 'kind': kind, 'conversation_id': conversation_id,
                   'policy_case_id': policy_case_id, 'product_entity_id': product_entity_id,
                   'enterprise_entity_id': enterprise_entity_id}
        # Exact replay precedes resolving implicit defaults or new WRITE rules.
        with self.repo.connection() as db:
            fingerprint, previous = self._operation(db, account_id, enterprise_id, 'create', operation_id, request)
            if previous is not None:
                return previous
            self._conversation(db, account_id, enterprise_id, conversation_id)
            selected, company, product, conversation_id = self._entities(db, account_id, enterprise_id, enterprise_entity_id,
                                                                         product_entity_id, policy_case_id, conversation_id)
        intent = resolve_intent(question)
        if intent.get('request_scope') == 'unsupported' or set(intent.get('purpose_types', [])).intersection({'formal_complaint', 'denunciation'}):
            raise CoreError('unsupported_policy_request', 'Yêu cầu này cần kênh chuyên trách; chưa tạo thành kiến nghị doanh nghiệp trong bản này.')
        context = self._context(account_id, enterprise_id, selected)
        stamp, identity = now_iso(), new_id('policy05')
        effective = 'request_guidance' if kind == 'participation_request' else 'business_petition'
        needs = self._needs(intent, effective)
        need_summary = '; '.join(need['label_vi'] for need in needs)
        subject = ('Đề nghị tư vấn hỗ trợ: ' if effective == 'request_guidance' else 'Kiến nghị: ') + need_summary
        # One original user statement, then visibly neutral draft language. No
        # fabricated event, loss, entitlement, opening date or official form.
        request_text = ('Đề nghị hướng dẫn chương trình, đối tượng, đợt tiếp nhận, mẫu và cách tham gia phù hợp với nhu cầu: '
                        if effective == 'request_guidance' else
                        'Đề nghị xem xét nhu cầu và hướng dẫn đầu mối phản hồi: ') + need_summary + '.'
        details = request_details(question)
        if details:
            request_text = ('Đề nghị hướng dẫn theo nội dung chủ cơ sở nêu: ' if effective == 'request_guidance' else
                            'Đề nghị xem xét kiến nghị cụ thể của chủ cơ sở: ') + '; '.join(item['text'] for item in details) + '.'
        body = {'enterprise_summary': self._summary(context), 'requested_support': need_summary,
                'situation': question, 'impact': '', 'request': request_text}
        manifest = {'schema_version': 'policy-draft-context/1', 'enterprise_entity_id': company,
                    'product_entity_id': product, 'entities': selected, 'fact_refs': context['fact_refs'],
                    'dependency_hash': context['dependency_hash'], 'confirmed_fact_count': sum(
                        fact['value_state'] == 'known' for entity in context['entities'] for fact in entity['facts'])}
        payload = {'schema_version': 'policy-workbench/1', 'id': identity, 'draft_id': identity,
                   'enterprise_id': enterprise_id, 'owner_id': account_id, 'version': 1, 'status': 'draft',
                   'requested_kind': kind, 'kind': effective, 'question': question, 'title': subject[:250],
                   'conversation_id': conversation_id, 'policy_case_id': policy_case_id, 'body': body,
                   'needs': needs, 'purposes': list(intent.get('purpose_types', [])), 'context_manifest': manifest,
                   'context': context, 'approval': None, 'previous_approval_id': None,
                   'artifact_contract_version': ARTIFACT_CONTRACT_VERSION, 'request_details': details,
                   'checklist': artifact_checklist(effective),
                   'program_readiness': {'application_open': None, 'eligibility': 'not_assessed', 'official_form_verified': False},
                   'sharing': {'destination_id': 'ihanoi_business_petition', 'destination_label_vi': 'iHanoi — Doanh nghiệp kiến nghị',
                               'publication': 'unknown', 'requires_owner_approval': True, 'external_send_available': False},
                   'limitations_vi': [('Đây là bản kiến nghị tự soạn từ nội dung chủ cơ sở cung cấp, chưa phải kết quả xử lý hoặc chấp thuận.'
                                       if effective == 'business_petition' else
                                       'Đây là bản nháp tự soạn, chưa phải mẫu đăng ký chính thức hoặc kết luận đủ điều kiện.'),
                                      'Chưa gửi cho cơ quan nào. Cần kiểm API, nơi nhận và phạm vi công khai của iHanoi trước khi gửi.'],
                   'provider_used': False, 'provider_calls': 0, 'created_at': stamp, 'updated_at': stamp}
        with self.repo.connection(write=True) as db:
            fingerprint, previous = self._operation(db, account_id, enterprise_id, 'create', operation_id, request)
            if previous is not None:
                return previous
            self._read_authority(db, account_id, enterprise_id, payload)
            if self.before_write is not None:
                self.before_write(db, account_id, enterprise_id, payload)
            self._require_current(db, account_id, enterprise_id, payload)
            if on_commit is not None:
                on_commit(db, payload)
                self._conversation(db, account_id, enterprise_id, payload.get('conversation_id'))
            payload['content_hash'] = content_hash(payload)
            db.execute('INSERT INTO pol05_drafts VALUES(?,?,?,?,?,?,?,?,?)', (identity, enterprise_id, account_id, 1, 'draft',
                       payload.get('conversation_id'), json_text(payload), stamp, stamp))
            self._revision(db, payload, account_id)
            self.repo._save_operation(db, account_id, enterprise_id, 'policy05_create', operation_id, fingerprint, payload)
        return payload

    def _revision(self, db, payload, account):
        db.execute('INSERT INTO pol05_revisions VALUES(?,?,?,?,?,?,?)', (payload['enterprise_id'], payload['id'], payload['version'],
                   payload['content_hash'], json_text(payload), account, now_iso()))

    def _require_current(self, db, account, enterprise, payload):
        self._read_authority(db, account, enterprise, payload)
        if payload.get('artifact_contract_version') != ARTIFACT_CONTRACT_VERSION:
            raise CoreError('draft_contract_outdated',
                            'Bản nháp theo hợp đồng trước, chưa có đầy đủ căn cứ đang dùng. Chị tạo bản nháp mới để sửa hoặc duyệt; bản cũ được giữ nguyên.', 409)
        for item in payload['context_manifest']['entities']:
            entity = self.core._entity(db, enterprise, item['entity_id'])
            if entity['archived']:
                raise CoreError('entity_archived', 'Hồ sơ căn cứ đã cất; bản cũ vẫn xem được nhưng chưa duyệt để dùng mới.', 409)
        latest = self._context(account, enterprise, payload['context_manifest']['entities'])
        if latest['dependency_hash'] != payload['context_manifest']['dependency_hash']:
            raise CoreError('context_changed', 'Dữ kiện cơ sở đã đổi. Chị lập bản nháp mới theo hồ sơ hiện hành trước khi duyệt.', 409)

    def get_draft(self, account_id, enterprise_id, draft_id):
        with self.repo.connection() as db:
            payload = self._row(db, account_id, enterprise_id, draft_id)[1]
            return self._project_read(db, account_id, enterprise_id, payload)

    def _project_read(self, db, account, enterprise, payload):
        """Currentness is a READ projection, never a rewrite of old content."""
        warnings = []
        if payload.get('artifact_contract_version') != ARTIFACT_CONTRACT_VERSION:
            warnings.append('Bản nháp theo hợp đồng trước, chưa có đầy đủ căn cứ đang dùng. Bản cũ giữ nguyên nội dung; chị tạo bản nháp mới để sửa hoặc duyệt.')
        selected = payload['context_manifest']['entities']
        archived = any(self.core._entity(db, enterprise, item['entity_id'])['archived'] for item in selected)
        if archived:
            warnings.append('Hồ sơ căn cứ đã cất. Bản này giữ thông tin lúc lập; chưa dùng để duyệt hoặc gửi mới.')
        else:
            try:
                latest = self._context(account, enterprise, selected)
            except CoreError as exc:
                if exc.status_code in {403, 404}:
                    raise
                warnings.append('Chưa đối chiếu được hồ sơ hiện hành. Bản này giữ thông tin lúc lập; cần rà lại trước khi duyệt.')
            else:
                if latest['dependency_hash'] != payload['context_manifest']['dependency_hash']:
                    warnings.append('Dữ kiện cơ sở đã đổi. Bản này giữ thông tin lúc lập; chị tạo bản nháp mới để dùng hồ sơ hiện hành.')
        if payload.get('policy_case_id') and self.policy is not None:
            case = self.policy.get(account, enterprise, payload['policy_case_id'])
            warnings.extend(case.get('current_warnings_vi', []))
        if not warnings:
            return payload
        return {**payload, 'is_historical': True, 'current_warnings_vi': list(dict.fromkeys(warnings))}

    def list_drafts(self, account_id, enterprise_id, conversation_id=None):
        with self.repo.connection() as db:
            self.core.membership(account_id, enterprise_id, db)
            self._conversation(db, account_id, enterprise_id, conversation_id)
            rows = db.execute('SELECT payload_json FROM pol05_drafts WHERE enterprise_id=? AND owner_id=? ORDER BY created_at DESC,id',
                              (enterprise_id, account_id)).fetchall()
            result = []
            for row in rows:
                payload = json.loads(row['payload_json'])
                if conversation_id and payload.get('conversation_id') != conversation_id:
                    continue
                try:
                    self._read_authority(db, account_id, enterprise_id, payload)
                except CoreError as exc:
                    if exc.status_code in {403, 404}:
                        continue
                    raise
                result.append(self._project_read(db, account_id, enterprise_id, payload))
            return result

    def update_draft(self, account_id, enterprise_id, draft_id, expected_version, body, operation_id, title=None):
        self._version(expected_version)
        if not isinstance(body, dict) or not body or set(body) - BODY_FIELDS:
            raise CoreError('invalid_policy_draft', 'Chỉ sửa các trường nội dung bản nháp được hỗ trợ.')
        body = {key: self._text(value, 'Nội dung', empty=key not in {'requested_support', 'request'}) for key, value in body.items()}
        if title is not None:
            title = self._text(title, 'Tiêu đề', maximum=250)
        request = {'draft_id': draft_id, 'expected_version': expected_version, 'body': body, 'title': title}
        with self.repo.connection(write=True) as db:
            fingerprint, previous = self._operation(db, account_id, enterprise_id, 'update', operation_id, request)
            if previous is not None:
                return previous
            _, payload = self._row(db, account_id, enterprise_id, draft_id)
            if self.before_write is not None:
                self.before_write(db, account_id, enterprise_id, payload)
            if payload['version'] != expected_version:
                raise CoreError('version_conflict', 'Bản nháp đã đổi. Chị xem phiên bản mới trước khi lưu.', 409)
            self._require_current(db, account_id, enterprise_id, payload)
            payload['body'].update(body)
            if title is not None:
                payload['title'] = title
            payload['version'] += 1
            if 'request' in body:
                # An authenticated edit replaces the proposed request. Keep
                # its provenance separate from extracted original-question
                # spans; previous immutable revisions retain those spans.
                payload['request_details'] = [{'source': 'draft_edit', 'actor_id': account_id,
                                               'version': payload['version'], 'text': body['request']}]
            payload['status'] = 'draft'
            payload['previous_approval_id'] = (payload.get('approval') or {}).get('approval_id') or payload.get('previous_approval_id')
            payload['approval'] = None
            payload['updated_at'] = now_iso()
            payload['content_hash'] = content_hash(payload)
            db.execute('UPDATE pol05_drafts SET version=?,status=?,payload_json=?,updated_at=? WHERE id=? AND enterprise_id=? AND version=?',
                       (payload['version'], 'draft', json_text(payload), payload['updated_at'], draft_id, enterprise_id, expected_version))
            self._revision(db, payload, account_id)
            self.repo._save_operation(db, account_id, enterprise_id, 'policy05_update', operation_id, fingerprint, payload)
        return payload

    def approve_draft(self, account_id, enterprise_id, draft_id, expected_version, content_hash, sharing_consent, operation_id):
        self._version(expected_version)
        request = {'draft_id': draft_id, 'expected_version': expected_version, 'content_hash': content_hash, 'sharing_consent': sharing_consent}
        with self.repo.connection(write=True) as db:
            fingerprint, previous = self._operation(db, account_id, enterprise_id, 'approve', operation_id, request)
            if previous is not None:
                return previous
            self.core.membership(account_id, enterprise_id, db, owner=True)
            _, payload = self._row(db, account_id, enterprise_id, draft_id)
            if self.before_write is not None:
                self.before_write(db, account_id, enterprise_id, payload)
            if payload['version'] != expected_version:
                raise CoreError('version_conflict', 'Bản nháp đã đổi; chị xem lại trước khi duyệt.', 409)
            if content_hash != payload['content_hash']:
                raise CoreError('content_conflict', 'Nội dung cần duyệt không khớp bản chị đang xem.', 409)
            if sharing_consent is not True:
                raise CoreError('sharing_consent_required', 'Chị cần xác nhận đã kiểm nội dung bản nháp này trước khi duyệt.')
            self._require_current(db, account_id, enterprise_id, payload)
            if payload.get('approval'):
                raise CoreError('draft_already_approved', 'Phiên bản này đã duyệt; chị đọc lại trạng thái hoặc sửa thành bản mới.', 409)
            stamp, approval_id = now_iso(), new_id('policy05approval')
            approval = {'approval_id': approval_id, 'type': 'draft_content_only', 'actor_id': account_id,
                        'approved_version': expected_version, 'content_hash': payload['content_hash'],
                        'context_hash': payload['context_manifest']['dependency_hash'],
                        'destination_id': payload['sharing']['destination_id'], 'publication': payload['sharing']['publication'],
                        'authorizes_external_send': False, 'recorded_at': stamp,
                        'scope_vi': 'Chủ cơ sở duyệt đúng nội dung bản nháp. Chưa cấp phép gửi ra ngoài hoặc xác nhận đăng ký.'}
            db.execute('INSERT INTO pol05_approvals VALUES(?,?,?,?,?,?,?)', (approval_id, enterprise_id, draft_id,
                       expected_version, account_id, json_text(approval), stamp))
            payload.update(status='approved', approval=approval, updated_at=stamp)
            db.execute('UPDATE pol05_drafts SET status=?,payload_json=?,updated_at=? WHERE id=? AND enterprise_id=?',
                       ('approved', json_text(payload), stamp, draft_id, enterprise_id))
            self.repo._save_operation(db, account_id, enterprise_id, 'policy05_approve', operation_id, fingerprint, payload)
        return payload

    def authorize_submission(self, db, account_id, enterprise_id, draft_id, expected_version=None, expected_hash=None):
        """Root's coordinator uses this gate; it never grants external authority."""
        self.core.membership(account_id, enterprise_id, db, owner=True)
        _, payload = self._row(db, account_id, enterprise_id, draft_id)
        self._require_current(db, account_id, enterprise_id, payload)
        if expected_version is not None and expected_version != payload['version']:
            raise CoreError('version_conflict', 'Bản nháp đã đổi; cần xem lại trước khi gửi.', 409)
        if expected_hash is not None and expected_hash != payload['content_hash']:
            raise CoreError('content_conflict', 'Nội dung gửi không khớp bản nháp.', 409)
        approval = payload.get('approval') or {}
        if (payload['status'] != 'approved' or approval.get('approved_version') != payload['version']
                or approval.get('content_hash') != payload['content_hash']):
            raise CoreError('draft_approval_required', 'Chủ cơ sở cần duyệt đúng phiên bản bản nháp trước khi chuẩn bị gửi.', 409)
        return copy.deepcopy(payload)

    def export_payload(self, account_id, enterprise_id, draft_id):
        payload = self.get_draft(account_id, enterprise_id, draft_id)
        return {**copy.deepcopy(payload), 'watermark_vi': 'BẢN NHÁP — CHƯA GỬI',
                'provider_calls': 0, 'export_kind': 'self_prepared_draft',
                'approval_note_vi': 'Duyệt nội dung không thay việc cơ quan tiếp nhận hoặc chấp thuận.'}
