"""Owner-private policy workbench exposed through the existing MCP authority.

No model transport, budget or public filing authority is created here.
"""
from __future__ import annotations

from typing import Annotated, Literal

from pydantic import Field

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.mcp import Identifier, Operation, Result

from .workbench import PolicyWorkbench


POLICY05_TOOLS = {
    "policy05_create_draft", "policy05_get_draft", "policy05_list_drafts",
    "policy05_update_draft", "policy05_approve_draft", "policy05_get_submission", "policy05_submit_draft",
}


def integration_status():
    # This release has no business API specification, credentials or authorized
    # recipient binding. MiniApp management OpenAPI is not a filing API.
    return {"schema_version": "ihanoi-capability/1", "state": "not_configured", "can_submit": False,
            "mode": "unconnected", "provider_calls": 0,
            "reason_vi": "Chưa kết nối API tiếp nhận iHanoi. Có thể chuẩn bị và tải bản nháp; chưa gửi hồ sơ."}


class Policy05Integration:
    def __init__(self, parent):
        self.parent, self.repo, self.core = parent, parent.repo, parent.core
        self.workbench = PolicyWorkbench(self.repo, self.core, policy=parent.policy)
        self.workbench.before_write = lambda db, a, e, draft: self._writable(db, a, e, draft.get("conversation_id"))

    def _writable(self, db, account, enterprise, conversation_id):
        from nmate.main.workspace_management import assert_chat_writable
        assert_chat_writable(db, account, enterprise, conversation_id)

    def create(self, account, enterprise, question, kind, operation_id, *, conversation_id=None,
               policy_case_id=None, product_entity_id=None, enterprise_entity_id=None):
        if policy_case_id:
            case = self.parent.get_case(account, enterprise, policy_case_id)
            linked = case.get("conversation_id")
            if conversation_id and conversation_id != linked:
                raise CoreError("POLICY_SCOPE_CONFLICT", "Kết quả chính sách thuộc cuộc trao đổi khác.", 409)
            conversation_id = linked
        if conversation_id:
            with self.repo.connection() as db:
                self.parent._chat(db, account, enterprise, conversation_id)

        def on_commit(db, draft):
            cid = conversation_id or new_id("conversation")
            stamp = now_iso()
            if conversation_id:
                chat = self.parent._chat(db, account, enterprise, cid)
                self._writable(db, account, enterprise, cid)
            else:
                chat = {"id": cid, "enterprise_id": enterprise, "owner_id": account, "title": question.strip()[:140],
                        "created_at": stamp, "updated_at": stamp, "messages": [], "intake_ids": [], "drafts": {},
                        "active_intake_id": None, "operation_ids": [], "mission_ids": []}
                db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)",
                           (cid, enterprise, account, json_text(chat), stamp, stamp))
            if len(chat["messages"]) >= 198:
                raise CoreError("conversation_limit", "Cuộc trao đổi đã dài; mở chat mới để tiếp tục.", 409)
            draft["conversation_id"] = cid
            ids = chat.setdefault("policy_draft_ids", [])
            if draft["id"] not in ids:
                ids.append(draft["id"])
            chat.update(active_policy_draft_id=draft["id"], task_hint="hanoi_policy", latest_operation_id=operation_id)
            if operation_id not in chat["operation_ids"]:
                chat["operation_ids"].append(operation_id)
            if not any(m.get("role") == "user" and m.get("text") == question.strip() for m in chat["messages"][-2:]):
                chat["messages"].append({"id": new_id("message"), "role": "user", "text": question.strip(),
                                         "created_at": stamp, "attachments": [], "kind": "message"})
            chat["messages"].append({"id": new_id("message"), "role": "assistant",
                "text": "Đã chuẩn bị bản nháp để chị xem và sửa. Chưa gửi tới iHanoi hoặc cơ quan nào.",
                "created_at": stamp, "attachments": [], "kind": "policy05_draft", "policy_draft_id": draft["id"]})
            chat["updated_at"] = stamp
            db.execute("UPDATE v04_conversations SET payload_json=?,updated_at=? WHERE id=? AND enterprise_id=? AND owner_id=?",
                       (json_text(chat), stamp, cid, enterprise, account))

        draft = self.workbench.create_draft(account, enterprise, question, kind, operation_id,
            conversation_id=conversation_id, policy_case_id=policy_case_id, product_entity_id=product_entity_id,
            enterprise_entity_id=enterprise_entity_id, on_commit=on_commit)
        return {"policy_draft": draft, "conversation_id": draft.get("conversation_id")}

    def assert_writable(self, account, enterprise, draft_id):
        draft = self.workbench.get_draft(account, enterprise, draft_id)
        with self.repo.connection() as db:
            self._writable(db, account, enterprise, draft.get("conversation_id"))
        return draft

    def submission(self, account, enterprise, draft_id):
        draft = self.workbench.get_draft(account, enterprise, draft_id)
        return {"draft_id": draft["id"], "version": draft["version"], "state": "not_submitted",
                "external_reference": None, "integration": integration_status(), "provider_calls": 0,
                "message_vi": "Bản nháp chưa gửi. Chưa có biên nhận hoặc phản hồi từ iHanoi."}

    def register_tools(self, server, call):
        @server.tool(structured_output=True, description="Prepare an owner-private policy draft, atomically linked to chat. Free; no SSOT write, no model, no external submission.")
        async def policy05_create_draft(enterprise_id: Identifier, question: Annotated[str, Field(min_length=1, max_length=6000)],
                kind: Literal["participation_request", "business_petition"], operation_id: Operation,
                conversation_id: Identifier | None = None, policy_case_id: Identifier | None = None,
                product_entity_id: Identifier | None = None, enterprise_entity_id: Identifier | None = None) -> Result:
            return await call(lambda a: self.create(a, enterprise_id, question, kind, operation_id,
                conversation_id=conversation_id, policy_case_id=policy_case_id, product_entity_id=product_entity_id,
                enterprise_entity_id=enterprise_entity_id))

        @server.tool(structured_output=True, description="Read the exact private policy draft with current input READ checks. No model call.")
        async def policy05_get_draft(enterprise_id: Identifier, draft_id: Identifier) -> Result:
            return await call(lambda a: {"policy_draft": self.workbench.get_draft(a, enterprise_id, draft_id)})

        @server.tool(structured_output=True, description="List only this user's policy drafts; membership does not share chat or documents.")
        async def policy05_list_drafts(enterprise_id: Identifier, conversation_id: Identifier | None = None) -> Result:
            return await call(lambda a: {"policy_drafts": self.workbench.list_drafts(a, enterprise_id, conversation_id=conversation_id)})

        @server.tool(structured_output=True, description="Edit a policy draft with CAS; invalidates prior content approval. Does not change SSOT.")
        async def policy05_update_draft(enterprise_id: Identifier, draft_id: Identifier,
                expected_version: Annotated[int, Field(ge=1)], body: dict, operation_id: Operation, title: str | None = None) -> Result:
            def update(a):
                return {"policy_draft": self.workbench.update_draft(a, enterprise_id, draft_id, expected_version,
                                                                   body, operation_id, title=title)}
            return await call(update)

        @server.tool(structured_output=True, description="Owner approves exact draft content only. This is not SSOT confirmation, paid-model consent, sharing or external-send permission.")
        async def policy05_approve_draft(enterprise_id: Identifier, draft_id: Identifier,
                expected_version: Annotated[int, Field(ge=1)], content_hash: str,
                sharing_consent: bool, operation_id: Operation) -> Result:
            def approve(a):
                return {"policy_draft": self.workbench.approve_draft(a, enterprise_id, draft_id, expected_version,
                    content_hash, sharing_consent, operation_id)}
            return await call(approve)

        @server.tool(structured_output=True, description="Read submission status only. Never retries or dispatches a model or government request.")
        async def policy05_get_submission(enterprise_id: Identifier, draft_id: Identifier) -> Result:
            return await call(lambda a: {"submission": self.submission(a, enterprise_id, draft_id)})

        @server.tool(structured_output=True, description="Guarded future iHanoi filing capability. This release is unconfigured and never dispatches externally.")
        async def policy05_submit_draft(enterprise_id: Identifier, draft_id: Identifier,
                expected_version: Annotated[int, Field(ge=1)], operation_id: Operation) -> Result:
            def blocked(a):
                self.workbench.get_draft(a, enterprise_id, draft_id)
                raise CoreError("IHANOI_NOT_CONFIGURED", integration_status()["reason_vi"], 409)
            return await call(blocked)
