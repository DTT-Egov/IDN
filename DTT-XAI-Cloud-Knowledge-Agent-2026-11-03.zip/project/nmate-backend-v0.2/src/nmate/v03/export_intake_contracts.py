"""Canonical current export intake and finite exact historic READ variants.

Only schema outcome bounds/enum and the matching server-owned allowed_outcomes
projection vary by parser version. Identity, question, previous context, market,
instructions and every other byte continue to participate in the full hash.
Historic declarations never plan work or authorize a new model call.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

from .export_intake_legacy import (v1_allowed_intake_outcomes, v1_explicit_requested_outcomes,
                                   v2_allowed_intake_outcomes, v2_explicit_requested_outcomes)


CURRENT_EXPORT_INTAKE_CONTRACT = "export-intake/3"
STATIC_SHA256 = "4ee294a726e0f95b95ad32e8034b0ce771a38dd33d3c23462ef0c869d300dfe0"
_INPUT_KEYS = {"question", "selected_product", "allowed_outcomes", "outcome_semantics_vi",
               "previous_mission_context", "resolved_market"}


def static_contract():
    raw = (Path(__file__).with_name("data") / "export_intake_contract_v1.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != STATIC_SHA256:
        raise ValueError("Export intake static contract checksum mismatch")
    return json.loads(raw)


def _build_payload(question, selected_product, previous_context, resolved_market, *, version):
    contract = static_contract()
    code = resolved_market.get("code") if isinstance(resolved_market, dict) else None
    previous_outcomes = [outcome["id"] for outcome in previous_context.get("outcomes", [])] if previous_context else []
    if version == 1:
        allowed_fn, explicit_fn = v1_allowed_intake_outcomes, v1_explicit_requested_outcomes
    elif version == 2:
        allowed_fn, explicit_fn = v2_allowed_intake_outcomes, v2_explicit_requested_outcomes
    elif version == 3:
        from .research_scope import allowed_intake_outcomes, explicit_requested_outcomes
        allowed_fn, explicit_fn = allowed_intake_outcomes, explicit_requested_outcomes
    else:
        raise ValueError("Unknown export intake contract")
    allowed = allowed_fn(question, code, previous_outcomes=previous_outcomes)
    explicit = explicit_fn(question, code)
    schema = contract["base_schema"]
    schema["$defs"]["IntakeOutcome"]["properties"]["id"]["enum"] = explicit or allowed
    if explicit:
        schema["properties"]["outcomes"].update(minItems=len(explicit), maxItems=len(explicit))
    return {"instructions_vi": contract["instructions_vi"], "response_schema": schema,
            "input": {"question": question, "selected_product": deepcopy(selected_product),
                      "allowed_outcomes": explicit or allowed, "outcome_semantics_vi": contract["outcome_semantics_vi"],
                      "previous_mission_context": deepcopy(previous_context), "resolved_market": deepcopy(resolved_market)}}


def build_export_intake_payload(question, selected_product, previous_context, resolved_market):
    """The sole new-dispatch builder has no caller-selectable old version."""
    return _build_payload(question, selected_product, previous_context, resolved_market, version=3)


def historic_export_intake_payloads(payload):
    """Reconstruct old complete requests only from a complete known current one.

    Returning a prior candidate is not permission: MainProvider's recorded_only
    READ still requires operation/account/enterprise identity, an exact stored
    full hash, an accepted response and current input ACL. No field is removed
    to obtain a match; unknown schema/prompt/shape only returns the given body.
    """
    variants = [deepcopy(payload)]
    if not isinstance(payload, dict) or set(payload) != {"instructions_vi", "response_schema", "input"}:
        return variants
    inputs = payload.get("input")
    if not isinstance(inputs, dict) or set(inputs) != _INPUT_KEYS or not isinstance(inputs["question"], str):
        return variants
    values = inputs["question"], inputs["selected_product"], inputs["previous_mission_context"], inputs["resolved_market"]
    try:
        current = build_export_intake_payload(*values)
    except (TypeError, ValueError, KeyError, AttributeError):
        return variants
    if payload != current:
        return variants
    for version in (2, 1):
        prior = _build_payload(*values, version=version)
        if prior not in variants:
            variants.append(prior)
    return variants
