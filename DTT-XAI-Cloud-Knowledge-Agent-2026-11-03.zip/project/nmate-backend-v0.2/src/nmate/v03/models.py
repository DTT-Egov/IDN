"""Small typed contracts for the bounded, paid-free 0.3A research workflow."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class Outcome(Contract):
    id: Literal["registration", "label", "certification", "prior_notice", "clarification"]
    title: str
    origin: Literal["requested", "supporting"] = "requested"
    question_part: str


class Intent(Contract):
    scope: Literal["us_food", "export_food", "unsupported"]
    market_code: str | None = None
    market_candidates: list[str] = Field(default_factory=list)
    outcomes: list[Outcome] = Field(min_length=1, max_length=6)
    ambiguities: list[str] = Field(default_factory=list)
    interpretation_mode: Literal["bounded_templates_no_paid_calls"] = "bounded_templates_no_paid_calls"


class PlanTask(Contract):
    id: str
    title: str
    outcome_ids: list[str] = Field(min_length=1)
    capability_id: str
    depends_on: list[str] = Field(default_factory=list)
    status: str = "planned"


class Plan(Contract):
    revision: int = Field(default=1, ge=1)
    tasks: list[PlanTask] = Field(min_length=1, max_length=12)
    hash: str
    template_version: str = "us-food-v03a-1"

    @model_validator(mode="after")
    def acyclic(self):
        ids = {task.id for task in self.tasks}
        if len(ids) != len(self.tasks):
            raise ValueError("Duplicate task IDs")
        done = set()
        while len(done) < len(ids):
            ready = {task.id for task in self.tasks if task.id not in done and set(task.depends_on) <= done}
            if not ready:
                raise ValueError("Unresolved or cyclic dependency")
            done |= ready
        return self


class LabelField(Contract):
    id: str
    label_en: str
    label_vi: str
    value: str | None = Field(default=None, max_length=2000)
    state: Literal["needs_input", "needs_scope_check", "self_declared", "needs_review"]
    help_vi: str
    source_ids: list[str] = Field(default_factory=list)
    basis_refs: dict[str, dict] = Field(default_factory=dict)
    provenance: dict | None = None
    conflict: dict | None = None
    choice: Literal["draft", "ssot", "edited"] | None = None


class LabelWorkbook(Contract):
    schema_version: str = "food-label-workbook-v1"
    product_reference: str
    market_code: str = "US"
    market_name_vi: str = "Mỹ"
    label_language: str = "en"
    review_status: Literal["draft_unreviewed"] = "draft_unreviewed"
    fields: list[LabelField] = Field(min_length=1, max_length=12)
    parent_artifact_ref: dict | None = None
    source_review_required: bool = False
    limitations_vi: str = "Khung nội dung tham khảo; chưa rà đầy đủ phạm vi áp dụng và chưa duyệt để in."
