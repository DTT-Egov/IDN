"""Printable draft from an authorized label revision, never regulatory approval."""
from __future__ import annotations

from functools import lru_cache
from io import BytesIO
from pathlib import Path
import re
from xml.sax.saxutils import escape

from .core import CoreError


@lru_cache(maxsize=1)
def register_fonts():
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
    folder = Path(__file__).parent / 'data/pdf_fonts'
    pdfmetrics.registerFont(TTFont('nMateText', str(folder / 'IBMPlexSans-Regular.ttf')))
    pdfmetrics.registerFont(TTFont('nMateHeading', str(folder / 'IBMPlexSans-SemiBold.ttf')))
    pdfmetrics.registerFont(UnicodeCIDFont('HeiseiKakuGo-W5'))
    return True


def _text(value):
    # Values are plain text, never ReportLab markup, images, links or commands.
    text = str(value or '').replace('\r\n', '\n').replace('\r', '\n')
    text = ''.join(char for char in text if char in '\n\t' or ord(char) >= 32)
    from reportlab.pdfbase import pdfmetrics
    supported = pdfmetrics.getFont('nMateText').face.charToGlyph
    if any(char not in '\n\t' and ord(char) not in supported and not re.fullmatch(r'[\u2e80-\u9fff\uf900-\ufaff\u3040-\u30ff]',char) for char in text):
        raise CoreError('PDF_FONT_UNSUPPORTED', 'Một số ký tự chưa xuất PDF đúng phông. Chị dùng bản xem trước để in hoặc sửa các ký tự đó; chưa tạo tệp lỗi.', 409)
    text = escape(text).replace('\n', '<br/>')
    return re.sub(r'([\u2e80-\u9fff\uf900-\ufaff\u3040-\u30ff]+)',
                  r'<font name="HeiseiKakuGo-W5">\1</font>', text)


def render_label_pdf(artifact):
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer
    from .domain_validation import validate_field_value

    for field in artifact.get('fields', []):
        if field.get('value') is not None and (issue := validate_field_value(field['id'], field['value'])):
            raise CoreError('INVALID_LABEL_VALUE', issue['message_vi'] + ' Chị sửa và lưu nhãn trước khi tải PDF.', 409)
    if artifact.get('validation_issues'):
        raise CoreError('INVALID_LABEL_VALUE', 'Bản nhãn có dữ kiện chưa hợp lệ. Chị sửa và lưu bản mới trước khi tải PDF.', 409)
    register_fonts()
    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=A4, leftMargin=20*mm, rightMargin=20*mm,
                                 topMargin=19*mm, bottomMargin=20*mm,
                                 title='Khung nhãn sản phẩm - bản nháp', author='nMate')
    body = ParagraphStyle('body', fontName='nMateText', fontSize=10.5, leading=15, textColor=colors.HexColor('#15253B'),
                          alignment=TA_LEFT, splitLongWords=True, spaceAfter=3*mm)
    heading = ParagraphStyle('heading', parent=body, fontName='nMateHeading', fontSize=11, leading=15, spaceAfter=2*mm)
    title = ParagraphStyle('title', parent=heading, fontSize=20, leading=25, spaceAfter=4*mm)
    small = ParagraphStyle('small', parent=body, fontSize=8.5, leading=12, spaceAfter=2*mm, textColor=colors.HexColor('#566477'))
    market = artifact.get('market_name_vi') or artifact.get('market_code') or 'Chưa xác định'
    flows = [Paragraph(_text(f'Khung nhãn - {market}'), title),
             Paragraph('BẢN NHÁP CHƯA DUYỆT - dùng để đối chiếu và trao đổi, chưa dùng làm nhãn thương mại.', heading),
             Paragraph(_text(artifact.get('product_reference') or 'Sản phẩm chưa có tên'), body),
             Paragraph(_text(f"Phiên bản nhãn {artifact.get('version', 1)} · Ngôn ngữ nhãn: " +
                              {'en':'tiếng Anh','de':'tiếng Đức','ja':'tiếng Nhật'}.get(artifact.get('label_language'), 'chưa xác định')), small),
             Spacer(1, 3*mm)]
    for field in artifact.get('fields', []):
        label = field.get('label_vi') or field.get('id')
        original = field.get('label_en')
        value = field.get('value')
        flows.extend([KeepTogether([Paragraph(_text(label), heading),
                                   Paragraph(_text(original or ''), small)]),
                      Paragraph(_text(value if value not in (None, '') else '[Chưa có dữ kiện hoặc chưa xác định phạm vi áp dụng]'), body)])
        if field.get('help_vi'):
            flows.append(Paragraph(_text(field['help_vi']), small))
        flows.append(Spacer(1, 2*mm))
    flows.extend([Spacer(1, 3*mm), Paragraph(_text(artifact.get('limitations_vi') or
        'Dữ kiện do doanh nghiệp khai. Chưa xác nhận đáp ứng quy định hoặc điều kiện nhập khẩu.'), small),
        Paragraph('Bản PDF chỉ gồm nội dung đã lưu. Các thay đổi chưa lưu trên màn hình chưa có trong tệp.', small)])

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont('nMateText', 8)
        canvas.setFillColor(colors.HexColor('#566477'))
        canvas.drawString(20*mm, 12*mm, f"nMate · Bản nháp · Trang {doc.page}")
        canvas.restoreState()
    document.build(flows, onFirstPage=footer, onLaterPages=footer)
    return buffer.getvalue()
