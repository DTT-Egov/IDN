"""Bounded public market packs, independent of private enterprise findings.

Nothing in this module retrieves a source or invokes a model. An observation is
an explicit local input, and source change blocks reuse before any later review.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

from .core import CoreError, json_text, new_id, now_iso
from .evidence import evidence_date, record_applicability
from .markets import get_market
from .authority_hosts import AUTHORITY_HOSTS
from .source_rights import public_source_permitted


CATALOG_SCHEMA = """
CREATE TABLE IF NOT EXISTS v03_domain_sources (
 id TEXT PRIMARY KEY, url TEXT NOT NULL, title TEXT NOT NULL, publisher TEXT NOT NULL,
 content_sha256 TEXT NOT NULL, text TEXT NOT NULL, accessed_at TEXT NOT NULL,
 source_date TEXT, version INTEGER NOT NULL DEFAULT 1,
 freshness_state TEXT NOT NULL DEFAULT 'recorded_snapshot', observed_hash TEXT,
 invalidated_at TEXT, rights TEXT NOT NULL DEFAULT 'public_reference');
CREATE TABLE IF NOT EXISTS v03_domain_references (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES v03_domain_sources(id),
 record_json TEXT NOT NULL, review_state TEXT NOT NULL DEFAULT 'reference_unreviewed');
CREATE TABLE IF NOT EXISTS v03_source_observations (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES v03_domain_sources(id),
 observed_hash TEXT NOT NULL, changed INTEGER NOT NULL, actor_id TEXT NOT NULL,
 enterprise_id TEXT NOT NULL, recorded_at TEXT NOT NULL, source_version INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS v03_domain_metrics (
 enterprise_id TEXT PRIMARY KEY REFERENCES v03_enterprises(id), lookup_count INTEGER NOT NULL DEFAULT 0,
 reuse_hits INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS v03_domain_pack_installations (
 pack_id TEXT PRIMARY KEY, content_sha256 TEXT NOT NULL, installed_at TEXT NOT NULL,
 policy_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v03_domain_reference_supersessions (
 old_reference_id TEXT NOT NULL REFERENCES v03_domain_references(id),
 new_reference_id TEXT NOT NULL REFERENCES v03_domain_references(id),
 pack_id TEXT NOT NULL REFERENCES v03_domain_pack_installations(pack_id),
 effective_since TEXT NOT NULL, reason_vi TEXT NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(old_reference_id,new_reference_id));
"""

_ALIASES = {"registration": "facility_registration", "fda_registration": "facility_registration",
            "labeling": "food_label", "label": "food_label", "food_labeling": "food_label"}


class DomainCatalog:
    def __init__(self, repo):
        self.repo = repo
        packs = [json.loads((Path(__file__).parent / "data" / name).read_text(encoding="utf-8"))
                 for name in ("fda_references.json", "multimarket_references.json", "authority_expansion_20261019.json")]
        with repo.connection(write=True) as db:
            db.executescript(CATALOG_SCHEMA)
            if not getattr(repo, "managed_runtime", False):
                for pack in packs:
                    self._install_pack(db, pack)

    @staticmethod
    def _install_pack(db, pack):
        sources = {source["id"]: source for source in pack["sources"]}
        allowed_hosts = AUTHORITY_HOSTS
        def normalized(value):
            return re.sub(r"\s+", " ", value).strip()

        for source in pack["sources"]:
            if hashlib.sha256(source["text"].encode()).hexdigest() != source["content_sha256"]:
                raise CoreError("catalog_integrity", "Bản nguồn đóng gói không khớp dấu kiểm tra.", 500)
            parsed = urlsplit(source["url"])
            if parsed.scheme != "https" or parsed.hostname not in allowed_hosts or parsed.username or parsed.password:
                raise CoreError("catalog_integrity", "Nguồn nằm ngoài phạm vi công khai cho phép.", 500)
            db.execute("INSERT OR IGNORE INTO v03_domain_sources "
                       "(id,url,title,publisher,content_sha256,text,accessed_at,source_date,rights) VALUES (?,?,?,?,?,?,?,?,?)", (
                           source["id"], source["url"], source["title"], source["publisher"], source["content_sha256"],
                           source["text"], source["accessed_at"], source.get("source_date"), source.get("rights", "public_reference")))
            original = db.execute("SELECT content_sha256,url FROM v03_domain_sources WHERE id=?", (source["id"],)).fetchone()
            if original["content_sha256"] != source["content_sha256"] or original["url"] != source["url"]:
                raise CoreError("catalog_integrity", "Mã nguồn đã lưu không được thay nội dung; cần tạo phiên bản nguồn mới.", 500)
        for record in pack["records"]:
            if hashlib.sha256(record["excerpt"].encode()).hexdigest() != record["excerpt_sha256"]:
                raise CoreError("catalog_integrity", "Trích đoạn không khớp dấu kiểm tra.", 500)
            source = sources.get(record["source_id"])
            # The legacy FDA pack preserves original line breaks separately.
            # Only whitespace normalization is accepted for installation;
            # citation publication still requires exact stored excerpt text.
            if source is None or normalized(record["excerpt"]) not in normalized(source["text"]):
                raise CoreError("catalog_integrity", "Trích đoạn không thuộc bản nguồn đóng gói.", 500)
            db.execute("INSERT OR IGNORE INTO v03_domain_references(id,source_id,record_json) VALUES (?,?,?)",
                       (record["id"], record["source_id"], json_text(record)))
        if pack.get("pack_id"):
            pack_hash = hashlib.sha256(json_text(pack).encode()).hexdigest()
            installed = db.execute("SELECT content_sha256 FROM v03_domain_pack_installations WHERE pack_id=?", (pack["pack_id"],)).fetchone()
            if installed and installed[0] != pack_hash:
                raise CoreError("catalog_integrity", "Gói nguồn đã cài không được ghi đè; cần mã phiên bản mới.", 500)
            stamp = now_iso()
            db.execute("INSERT OR IGNORE INTO v03_domain_pack_installations VALUES(?,?,?,?)", (
                pack["pack_id"], pack_hash, stamp, json_text({"historical_sources_unchanged": True,
                "historical_missions_unchanged": True, "no_legal_review_claim": True})))
            for replacement in pack.get("supersessions", []):
                db.execute("INSERT OR IGNORE INTO v03_domain_reference_supersessions VALUES(?,?,?,?,?,?)", (
                    replacement["old_reference_id"], replacement["new_reference_id"], pack["pack_id"],
                    pack["effective_since"], replacement["reason_vi"], stamp))

    def lookup_domain(self, topics, account_id=None, enterprise_id=None, *, market_code="US", as_of_date=None):
        if isinstance(topics, str):
            topics = [topics]
        if not isinstance(topics, (list, tuple)) or len(topics) > 30 or any(not isinstance(t, str) for t in topics):
            raise CoreError("invalid_topics", "Chủ đề tham chiếu không hợp lệ.")
        if (account_id is None) != (enterprise_id is None):
            raise CoreError("forbidden", "Cần đầy đủ chủ thể và doanh nghiệp để đọc chỉ số riêng.", 403)
        market = get_market(market_code)
        as_of = evidence_date(as_of_date).isoformat()
        requested = list(dict.fromkeys(_ALIASES.get(t, t) if t != "fda_registration" or market["code"] == "US" else t
                                       for t in topics))
        with self.repo.connection(write=account_id is not None) as db:
            if account_id is not None:
                self.repo.get_membership(account_id, enterprise_id, db)
            records, refs, supported, affected = [], {}, set(), set()
            for row in db.execute("SELECT r.record_json,r.review_state,s.* FROM v03_domain_references r "
                                  "JOIN v03_domain_sources s ON s.id=r.source_id ORDER BY r.id"):
                if not public_source_permitted(row["rights"], row["url"]):
                    continue
                record = json.loads(row["record_json"])
                if record.get("introduced_on", "0001-01-01") > as_of:
                    continue
                if db.execute("SELECT 1 FROM v03_domain_reference_supersessions WHERE old_reference_id=? AND effective_since<=?", (record["id"], as_of)).fetchone():
                    continue
                # Scope precedes topic matching: a US label record must never
                # contribute hits, coverage or source dependencies for Germany.
                jurisdiction = record.get("scope", {}).get("jurisdiction")
                jurisdictions = [jurisdiction] if isinstance(jurisdiction, str) else jurisdiction
                if not isinstance(jurisdictions, list) or not jurisdictions or not set(jurisdictions).issubset(set(market["jurisdictions"])):
                    continue
                matching = set(requested).intersection(record["topics"])
                if not matching:
                    continue
                record.update({"freshness_state": row["freshness_state"], "review_state": row["review_state"]})
                reason = record_applicability(record, market["code"], as_of)
                reusable = reason is None
                if reusable:
                    supported.update(matching)
                else:
                    affected.update(matching)
                record.update({"source_version": row["version"], "content_sha256": row["content_sha256"],
                               "source_date": row["source_date"], "accessed_at": row["accessed_at"],
                               "checked_at": row["accessed_at"], "freshness_state": row["freshness_state"],
                               "review_state": row["review_state"], "reusable": reusable,
                               "rights": row["rights"], "authority_state": "reference_only",
                               "market_code": market["code"], "jurisdictions": jurisdictions,
                               "excerpt_original": record["excerpt"],
                               "original_language": record.get("original_language", record.get("language", "en")),
                               "language": record.get("original_language", record.get("language", "en")),
                               "applicability_state": reason or "bounded_reference", "as_of_date": as_of,
                               "pack_version": record.get("pack_version", market["pack_version"])})
                if reason:
                    record["freshness_state"] = "needs_revalidation"
                records.append(record)
                # A known unusable reference remains visible as a coverage gap,
                # but is not a dependency of work that is forbidden to use it.
                # If another record from this source is reusable, that record
                # still binds the source and later changes invalidate the plan.
                if reusable:
                    refs[row["id"]] = {"source_id": row["id"], "version": row["version"], "content_sha256": row["content_sha256"]}
            hits = sum(1 for r in records if r["reusable"])
            metrics = {"lookup_count": 1, "reuse_hits": hits, "scope": "this_lookup"}
            if account_id is not None:
                db.execute("INSERT INTO v03_domain_metrics(enterprise_id,lookup_count,reuse_hits) VALUES (?,1,?) "
                           "ON CONFLICT(enterprise_id) DO UPDATE SET lookup_count=lookup_count+1,reuse_hits=reuse_hits+excluded.reuse_hits",
                           (enterprise_id, hits))
                saved = db.execute("SELECT lookup_count,reuse_hits FROM v03_domain_metrics WHERE enterprise_id=?", (enterprise_id,)).fetchone()
                metrics = {**dict(saved), "scope": "this_enterprise", "this_lookup_hits": hits}
            supported.difference_update(affected)
            missing = [t for t in requested if t not in supported]
            return {"records": records, "source_refs": list(refs.values()), "market": market,
                    "market_code": market["code"], "as_of_date": as_of,
                    "coverage": {"requested": requested, "supported": [t for t in requested if t in supported],
                                 "missing": missing, "state": "supported_reference" if not missing else "partial" if supported else "no_support_found",
                                 "scope_note": f"Chỉ phản ánh gói nguồn đã lưu cho {market['name_vi']}; chưa thẩm định đầy đủ sửa đổi, ngoại lệ và mọi nghĩa vụ cho từng sản phẩm."},
                    "metrics": metrics, "network_calls": 0, "model_calls": 0,
                    "review_state": "reference_unreviewed", "freshness_state": "needs_revalidation" if any(not r["reusable"] for r in records) else "recorded_snapshot"}

    lookup = lookup_domain

    def domain_graph(self, *, market_code, as_of_date=None, reference_ids=None, db=None):
        """Typed READ view only; never added to a paid canonical request.

        Callers projecting a saved result can pass its exact excerpt IDs and
        the same SQL read snapshot. Rights withdrawal denies derived reads;
        expiry/supersession remains an honest current-use blocker.
        """
        from .knowledge_graph import project_export_graph
        if db is not None:
            return project_export_graph(db, market_code=market_code, as_of_date=as_of_date, reference_ids=reference_ids)
        with self.repo.connection() as connection:
            return project_export_graph(connection, market_code=market_code, as_of_date=as_of_date, reference_ids=reference_ids)

    def observe_source(self, account_id, enterprise_id, source_id, observed_hash, operation_id):
        if not isinstance(observed_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", observed_hash):
            raise CoreError("invalid_hash", "Cần mã SHA-256 hợp lệ của bản nguồn được quan sát.")
        with self.repo.connection(write=True) as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            request_hash, previous = self.repo._operation(db, account_id, enterprise_id, "source_observation", operation_id,
                                                         [source_id, observed_hash])
            if previous is not None:
                return previous
            row = db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (source_id,)).fetchone()
            if not row:
                raise CoreError("not_found", "Không tìm thấy nguồn tham chiếu.", 404)
            changed = observed_hash != row["content_sha256"]
            version = row["version"] + (changed and observed_hash != row["observed_hash"])
            observation_id, stamp = new_id("observation"), now_iso()
            freshness = row["freshness_state"]
            if changed:
                # The snapshot and draft claims remain as-of. A manually supplied
                # hash cannot bless replacement content or undo an invalidation.
                freshness = freshness if freshness in {"revoked", "withdrawn"} else "needs_revalidation"
                db.execute("UPDATE v03_domain_sources SET observed_hash=?,version=?,freshness_state=?,"
                           "invalidated_at=? WHERE id=?", (observed_hash, version, freshness, stamp, source_id))
                for enterprise in db.execute("SELECT id FROM v03_enterprises"):
                    self.repo.invalidate_dependencies(db, enterprise["id"], "source", source_id,
                                                      "Nguồn tham chiếu đã thay đổi, cần rà lại")
            db.execute("INSERT INTO v03_source_observations VALUES (?,?,?,?,?,?,?,?)", (
                observation_id, source_id, observed_hash, int(changed), account_id, enterprise_id, stamp, version))
            result = {"observation_id": observation_id, "source_id": source_id, "source_version": version,
                      "changed": changed, "freshness_state": freshness,
                      "network_calls": 0, "model_calls": 0}
            self.repo._save_operation(db, account_id, enterprise_id, "source_observation", operation_id, request_hash, result)
            return result

    def get_source(self, source_id):
        """Public saved snapshot only; never includes observations or case usage."""
        with self.repo.connection() as db:
            row = db.execute("SELECT id,url,title,publisher,content_sha256,text,accessed_at,source_date,version,"
                             "freshness_state,rights FROM v03_domain_sources WHERE id=?", (source_id,)).fetchone()
            if not row or not public_source_permitted(row["rights"], row["url"]):
                raise CoreError("not_found", "Không tìm thấy nguồn tham chiếu.", 404)
            return dict(row)
