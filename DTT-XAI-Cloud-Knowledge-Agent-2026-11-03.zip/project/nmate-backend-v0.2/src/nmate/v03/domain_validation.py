"""Shared business-value constraints at write and derived-read boundaries.

Validation never corrects an old observation or changes display spelling.
"""
from __future__ import annotations

from decimal import Decimal
import re
import unicodedata
from .field_registry import (FIELD_VALUE_KINDS, FINANCIAL_FIELD_BASES, MASS_UNITS, QUANTITY_UNITS,
                             QUANTITY_NUMBER_PATTERN,
                             VALUE_CONTRACT_VERSION as FIELD_VALUE_CONTRACT_VERSION,
                             base_field_key, field_contract, field_is_financial)

__all__ = ["FIELD_VALUE_KINDS", "FINANCIAL_FIELD_BASES", "MASS_UNITS", "QUANTITY_UNITS",
           "FIELD_VALUE_CONTRACT_VERSION", "base_field_key", "field_is_financial", "field_value_contract",
           "product_identity_key", "validate_field_value", "require_valid_field", "field_advisories"]


def field_value_contract(field):
    """Serializable validation metadata, not permission to use/write a field."""
    result = field_contract(field)
    if result is None:
        return None
    kind = result["kind"]
    if kind in {"quantity", "mass"}:
        result.update(json_type="string", minimum_exclusive=0,
                      units=sorted(MASS_UNITS if kind == "mass" else QUANTITY_UNITS))
    elif kind == "count":
        result.update(json_type="integer", minimum=0, boolean_allowed=False)
    elif kind == "product_code":
        result.update(json_type="string", min_length=1, max_length=64,
                      separators="-_./", boundary="alphanumeric")
    else:
        result["json_schema"] = result["value_schema"]
    return result


def product_identity_key(name):
    return " ".join(unicodedata.normalize("NFC", str(name)).casefold().split())


def validate_field_value(field, value):
    """Return a field issue or None; null clearing is handled by the caller."""
    key = base_field_key(field)
    kind = FIELD_VALUE_KINDS.get(key)
    code = message = None
    if kind in {"quantity", "mass"}:
        match = re.fullmatch("(" + QUANTITY_NUMBER_PATTERN + r")\s*([A-Za-zµμ]+(?:\s+[A-Za-z]+)?)", value.strip()) if isinstance(value, str) else None
        units = MASS_UNITS if kind == "mass" else QUANTITY_UNITS
        if not match or Decimal(match.group(1).replace(",", ".")) <= 0 or match.group(2).casefold() not in units:
            code, message = "invalid_quantity", "Lượng tịnh cần số lớn hơn 0 và đơn vị khối lượng rõ ràng, ví dụ 100 g hoặc 0,1 kg."
            if key == "net_quantity":
                message = "Lượng tịnh cần số lớn hơn 0 và đơn vị rõ ràng, ví dụ 100 g, 0,1 kg hoặc 250 ml; không dùng tên bao bì thay đơn vị."
    elif kind == "product_code":
        text = unicodedata.normalize("NFC", value) if isinstance(value, str) else ""
        if not (1 <= len(text) <= 64 and text[0].isalnum() and text[-1].isalnum()
                and all(char.isalnum() or char in "-_./" for char in text)):
            code, message = "invalid_product_code", "Mã sản phẩm cần 1–64 chữ hoặc số; có thể dùng dấu - _ . / ở giữa, không có khoảng trắng."
    elif kind == "count":
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            code, message = "invalid_count", "Số lao động cần là số nguyên không âm."
    elif kind in {"text", "name", "text_or_list"}:
        limit = 250 if kind == "name" else 2000
        values = value if kind == "text_or_list" and isinstance(value, list) else [value]
        if (kind == "text_or_list" and isinstance(value, list) and len(value) > 30) or any(
                not isinstance(text, str) or not text.strip() or len(text) > limit for text in values):
            code, message = "invalid_field_value", f"Dữ kiện cần nội dung văn bản từ 1 đến {limit} ký tự."
        if kind == "name" and code:
            # Match the established exact-name boundary while extending it to qualifiers.
            code, message = "invalid_name", "Tên hồ sơ cần có nội dung và không vượt 250 ký tự."
    elif kind == "financial_observation":
        if isinstance(value, bool) or not isinstance(value, (str, int, float, dict, list)):
            code, message = "invalid_field_value", "Dữ kiện tài chính cần giá trị quan sát có kiểu; quyền gửi chỉ tiêu được kiểm riêng."
    return {"field": field, "code": code, "message_vi": message} if code else None


def field_advisories(field, value):
    """Display before confirmation; no conversion, rejection or extra egress."""
    if FIELD_VALUE_KINDS.get(base_field_key(field)) not in {"quantity", "mass"} or validate_field_value(field, value):
        return []
    unit = re.sub(r"^[\d.,]+\s*", "", value.strip()).casefold()
    if unit == "oz":
        return [{"field": field, "code": "ounce_mass", "level": "warning",
                 "message_vi": "oz là ounce khối lượng, khác fl oz đo thể tích. Hãy kiểm tra đơn vị trước khi xác nhận; hệ thống giữ nguyên giá trị."}]
    if unit == "fl oz":
        return [{"field": field, "code": "ounce_volume", "level": "warning",
                 "message_vi": "fl oz là ounce thể tích, khác oz đo khối lượng. Hãy kiểm tra đơn vị trước khi xác nhận; hệ thống giữ nguyên giá trị."}]
    return []


def require_valid_field(field, value):
    issue = validate_field_value(field, value)
    if issue:
        from .core import CoreError
        raise CoreError(issue["code"], issue["message_vi"])
