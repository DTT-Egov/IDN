"""Frozen, read-only parser contracts for reconstructing exact prior hashes.

These declarations are not used for new planning, dispatch or validation. New
commands use research_scope; this finite registry preserves historical bytes.
"""
import re
import unicodedata
from types import MappingProxyType


def _normalize_text(value):
    text = unicodedata.normalize('NFKD', str(value or '').casefold()).replace('đ', 'd')
    return ' '.join(''.join((c for c in text if not unicodedata.combining(c))).split())

_V1_PATTERNS = MappingProxyType({'label': '\\b(?:nhan|label|labelling|labeling|bao bi)\\b', 'registration': '\\b(?:dang ky|co so|facility|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|food business)\\b', 'prior_notice': '\\b(?:thong bao truoc|prior\\s*notice)\\b', 'certification': '\\b(?:chung nhan|chung chi|certification|certificate)\\b'})

def v1_intent_text(text):
    """Preserve Vietnamese meaning before accent folding for semantic matching."""
    value = unicodedata.normalize('NFC', str(text or '')).casefold()
    value = re.sub('\\b(?:chứng|chung)\\s+(?:nhận|nhan)\\b', 'certificate', value)

    def distinguish(match):
        word = match.group()
        if word == 'chị':
            return 'ownerfemale'
        if word == 'nhãn':
            return 'label'
        if _normalize_text(word) == 'nhan' and word != 'nhan':
            return 'nonlabelword'
        return word
    value = _normalize_text(re.sub('\\b\\w+\\b', distinguish, value))
    return re.sub('\\b(?:xac nhan|tiep nhan|chap nhan|ghi nhan|cong nhan|nhan vien|nhan su|nhan luc|nhan hang|nhan duoc|nhan loi|nhan tien|nhan xet|nguyen nhan|ca nhan|benh nhan)\\b', 'nonlabelword', value)

def v1_quote_supports_outcome(outcome_id, quote, market_code, *, previous_outcomes=()):
    value = v1_intent_text(quote)
    if outcome_id == 'clarification':
        return True
    if outcome_id == 'prior_notice' and market_code != 'US':
        return False
    pattern = _V1_PATTERNS.get(outcome_id)
    if pattern and re.search(pattern, value):
        return True
    if outcome_id == 'registration' and market_code in {'DE', 'JP'} and re.search('\\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\\b', value):
        return True
    return outcome_id in previous_outcomes and bool(re.search('\\b(?:ngoai le do|noi dung do|viec do|tiep tuc|nghien cuu tiep|sua tiep|ban nhap)\\b', value))

def v1_allowed_intake_outcomes(text, market_code, *, previous_outcomes=()):
    value = v1_intent_text(text)
    focused = re.split('\\b(?:chi hoi|chi can|chi muon|only ask|only need)\\b', value)
    value = focused[-1] if len(focused) > 1 else value
    result = []
    for oid, pattern in _V1_PATTERNS.items():
        if not v1_quote_supports_outcome(oid, value, market_code, previous_outcomes=previous_outcomes):
            continue
        positive = re.sub('\\b(?:khong hoi|khong can|khong muon|da xong|da hoan tat)\\b[^,;.?!]*', '', value)
        positive = re.sub(pattern + '[^,;.?!]{0,25}\\b(?:da xong|da lam xong|da hoan tat)\\b', '', positive)
        if v1_quote_supports_outcome(oid, positive, market_code, previous_outcomes=previous_outcomes):
            result.append(oid)
    return result + ['clarification']

def v1_explicit_requested_outcomes(text, market_code):
    """Mandatory tasks require an asked clause, not a background keyword.

    The broader allowlist remains useful for candidate interpretation. A
    factory location does not ask for registration; a packaging description
    does not ask for label research. Only this stricter projection can bind
    tasks or constrain a paid response to a mandatory outcome count.
    """
    candidates = set(v1_allowed_intake_outcomes(text, market_code)) - {'clarification'}
    value = v1_intent_text(text)
    focused = re.split('\\b(?:chi hoi|chi can|chi muon|only ask|only need)\\b', value)
    value = focused[-1]
    anchors = {'registration': '\\b(?:dang ky|registration|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|facility registration|food business)\\b', 'label': '\\b(?:nhan|label|labelling|labeling)\\b|\\bbao bi\\b.{0,50}\\b(?:ghi|noi dung|thong tin)\\b', 'prior_notice': _V1_PATTERNS['prior_notice'], 'certification': _V1_PATTERNS['certification']}
    if market_code in {'DE', 'JP'}:
        anchors['registration'] += '|\\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\\b'
    ask_lead = '\\b(?:hoi|tim hieu|nghien cuu|huong dan|chuan bi|ra soat|kiem tra|tu van|cho biet|giai thich|review|check|what|how|who|when)\\b'
    question_form = '\\b(?:co phai|co can|ai|khi nao|bao gio|gi|nao|khong)\\b'
    result = set()
    parts = re.split('([,;.!?\\n])', value)
    for index in range(0, len(parts), 2):
        clause = parts[index].strip()
        delimiter = parts[index + 1] if index + 1 < len(parts) else ''
        if not clause:
            continue
        lead = re.search(ask_lead, clause)
        if lead and (not re.search(question_form, clause[:lead.start()])):
            clause = clause[lead.start():]
        possible = set(v1_allowed_intake_outcomes(clause, market_code)) & candidates
        marked = bool(re.search(ask_lead, clause) or re.search(question_form, clause) or delimiter == '?')
        declarative = bool(re.search('\\b(?:da|dang(?!\\s+ky\\b)|hien tai|la|duoc)\\b', clause))
        imperative = bool(re.match('^(?:hay\\s+)?dang ky\\b', clause)) and (not declarative)
        for oid in possible:
            anchor = anchors.get(oid)
            if not anchor or not re.search(anchor, clause):
                continue
            if marked or imperative:
                result.add(oid)
    return [oid for oid in _V1_PATTERNS if oid in result]

_V2_PATTERNS = MappingProxyType({'label': '\\b(?:nhan|label|labelling|labeling|bao bi)\\b', 'registration': '\\b(?:dang ky|co so|facility|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|food business)\\b', 'prior_notice': '\\b(?:thong bao truoc|prior\\s*notice)\\b', 'certification': '\\b(?:chung nhan|chung chi|certification|certificate)\\b'})

def v2_intent_text(text):
    """Preserve Vietnamese meaning before accent folding for semantic matching."""
    value = unicodedata.normalize('NFC', str(text or '')).casefold()
    value = re.sub('\\b(?:chứng|chung)\\s+(?:nhận|nhan)\\b', 'certificate', value)

    def distinguish(match):
        word = match.group()
        if word == 'chị':
            return 'ownerfemale'
        if word == 'nhãn':
            return 'label'
        if _normalize_text(word) == 'nhan' and word != 'nhan':
            return 'nonlabelword'
        return word
    value = _normalize_text(re.sub('\\b\\w+\\b', distinguish, value))
    return re.sub('\\b(?:xac nhan|tiep nhan|chap nhan|ghi nhan|cong nhan|nhan vien|nhan su|nhan luc|nhan hang|nhan duoc|nhan loi|nhan tien|nhan xet|nguyen nhan|ca nhan|benh nhan)\\b', 'nonlabelword', value)

def v2_quote_supports_outcome(outcome_id, quote, market_code, *, previous_outcomes=()):
    value = v2_intent_text(quote)
    if outcome_id == 'clarification':
        return True
    if outcome_id == 'prior_notice' and market_code != 'US':
        return False
    pattern = _V2_PATTERNS.get(outcome_id)
    if pattern and re.search(pattern, value):
        return True
    if outcome_id == 'registration' and market_code in {'DE', 'JP'} and re.search('\\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\\b', value):
        return True
    return outcome_id in previous_outcomes and bool(re.search('\\b(?:ngoai le do|noi dung do|viec do|tiep tuc|nghien cuu tiep|sua tiep|ban nhap)\\b', value))

def v2_split_intent_clauses(value):
    """One bounded polarity boundary, shared by included/excluded goals.

    A conjunction only starts a new clause when it introduces a new request
    operator. Keep 'không hỏi nhãn và thông báo trước' together; split 'đăng
    ký FDA và không hỏi nhãn', without rewriting the original user quote.
    """
    operator = '(?:(?:ownerfemale|toi|anh|em|minh)\\s+)?(?:khong|chua|can|muon|hoi|tim hieu|nghien cuu|bo qua|loai tru|only|do not|need|want)\\b'
    return [part.strip() for part in re.split('[,;.!?\\n]|\\b(?:nhung|tuy nhien)\\b|\\bma\\b(?=\\s+' + operator + ')|\\b(?:va|and|but)\\b(?=\\s+' + operator + ')', value) if part.strip()]

def v2_allowed_intake_outcomes(text, market_code, *, previous_outcomes=()):
    value = v2_intent_text(text)
    focused = re.split('\\b(?:chi hoi|chi can|chi muon|only ask|only need)\\b', value)
    value = focused[-1] if len(focused) > 1 else value
    result = []
    for oid, pattern in _V2_PATTERNS.items():
        if not v2_quote_supports_outcome(oid, value, market_code, previous_outcomes=previous_outcomes):
            continue
        positive = ' ; '.join((re.sub('\\b(?:khong hoi|khong can|khong muon|bo qua|loai tru|do not research|exclude|da xong|da hoan tat)\\b.*', '', clause) for clause in v2_split_intent_clauses(value)))
        positive = re.sub(pattern + '[^,;.?!]{0,25}\\b(?:da xong|da lam xong|da hoan tat)\\b', '', positive)
        if v2_quote_supports_outcome(oid, positive, market_code, previous_outcomes=previous_outcomes):
            result.append(oid)
    return result + ['clarification']

def v2_explicit_requested_outcomes(text, market_code):
    """Mandatory tasks require an asked clause, not a background keyword.

    The broader allowlist remains useful for candidate interpretation. A
    factory location does not ask for registration; a packaging description
    does not ask for label research. Only this stricter projection can bind
    tasks or constrain a paid response to a mandatory outcome count.
    """
    candidates = set(v2_allowed_intake_outcomes(text, market_code)) - {'clarification'}
    value = v2_intent_text(text)
    focused = re.split('\\b(?:chi hoi|chi can|chi muon|only ask|only need)\\b', value)
    value = focused[-1]
    anchors = {'registration': '\\b(?:dang ky|registration|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|facility registration|food business)\\b', 'label': '\\b(?:nhan|label|labelling|labeling)\\b|\\bbao bi\\b.{0,50}\\b(?:ghi|noi dung|thong tin)\\b', 'prior_notice': _V2_PATTERNS['prior_notice'], 'certification': _V2_PATTERNS['certification']}
    if market_code in {'DE', 'JP'}:
        anchors['registration'] += '|\\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\\b'
    ask_lead = '\\b(?:hoi|tim hieu|nghien cuu|huong dan|chuan bi|ra soat|kiem tra|tu van|cho biet|giai thich|review|check|what|how|who|when)\\b'
    question_form = '\\b(?:co phai|co can|ai|khi nao|bao gio|gi|nao|khong)\\b'
    result = set()
    parts = re.split('([,;.!?\\n])', value)
    clauses = []
    for index in range(0, len(parts), 2):
        subclauses = v2_split_intent_clauses(parts[index])
        clauses.extend(((clause, parts[index + 1] if index + 1 < len(parts) and subindex == len(subclauses) - 1 else '') for subindex, clause in enumerate(subclauses)))
    for clause, delimiter in clauses:
        if not clause:
            continue
        lead = re.search(ask_lead, clause)
        lead_prefix = clause[:lead.start()] if lead else ''
        historical_lead = bool(lead and re.search('\\b(?:da|dang|vua|hien tai)\\b', lead_prefix) and (not re.search('\\b(?:gio|bay gio|nay|can|muon|hoi)\\b', lead_prefix)))
        if lead and (not historical_lead) and (not re.search(question_form, lead_prefix)):
            clause = clause[lead.start():]
        possible = set(v2_allowed_intake_outcomes(clause, market_code)) & candidates
        marked = bool(re.search(ask_lead, clause) and (not historical_lead) or re.search(question_form, clause) or delimiter == '?')
        declarative = bool(re.search('\\b(?:da|dang(?!\\s+ky\\b)|hien tai|la|duoc)\\b', clause))
        imperative = bool(re.match('^(?:hay\\s+)?dang ky\\b|^(?:(?:ownerfemale|toi|anh|em|minh)\\s+)?(?:can|muon)\\s+(?:dang ky|tim hieu|nghien cuu|hoi|ra soat|kiem tra|chuan bi)\\b', clause)) and (not declarative)
        for oid in possible:
            anchor = anchors.get(oid)
            if not anchor or not re.search(anchor, clause):
                continue
            if marked or imperative:
                result.add(oid)
    return [oid for oid in _V2_PATTERNS if oid in result]

CONTRACT_SOURCE_SHA256 = MappingProxyType({'1': 'c38eb7172a818a2482b4ba5abb9c7dbb89f56455c36919d4547fa43311c3eefb', '2': 'a1d15322374b1e9b74d76d84918276f6d91dd900ea1005e4c955c317c0b87d85'})
