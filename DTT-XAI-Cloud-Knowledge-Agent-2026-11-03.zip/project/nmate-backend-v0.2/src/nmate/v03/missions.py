"""Intent-bound plans, private persisted tasks and editable label revisions.

This slice uses bounded templates and recorded public references, not a live
model. No provider SDK, paid fallback, network fetch or retry is reachable here.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import re
import unicodedata

from .catalog import DomainCatalog
from .core import CoreError, json_text, new_id, now_iso
from .field_scope import LABEL_FACT_ALIASES
from .models import Intent, LabelField, LabelWorkbook, Outcome, Plan, PlanTask
from .drafts import DEPENDENCIES, basis, reconcile, values as context_values
from .evidence import bind_answer_citations, outcome_topic
from .markets import MARKETS, detect_markets, get_market, market_title
from .workflow import build_graph
from .label_document import render_label_document
from .goal_readiness import project_goal_readiness, read_authority_records, mission_source_dependencies, readiness_snapshot_valid
from .domain_validation import require_valid_field, validate_field_value
from langsmith import tracing_context

logger = logging.getLogger(__name__)


SCHEMA = """
CREATE TABLE IF NOT EXISTS v03_missions (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 owner_id TEXT NOT NULL REFERENCES v03_accounts(id), status TEXT NOT NULL,
 stale_reason TEXT, version INTEGER NOT NULL DEFAULT 1,
 payload_json TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v03_dependencies (
 mission_id TEXT NOT NULL REFERENCES v03_missions(id), enterprise_id TEXT NOT NULL,
 dependency_kind TEXT NOT NULL, dependency_key TEXT NOT NULL, dependency_version TEXT NOT NULL,
 PRIMARY KEY(mission_id,dependency_kind,dependency_key));
CREATE TABLE IF NOT EXISTS v03_mission_operations (
 enterprise_id TEXT NOT NULL, account_id TEXT NOT NULL, kind TEXT NOT NULL,
 operation_id TEXT NOT NULL, request_hash TEXT NOT NULL, mission_id TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,account_id,kind,operation_id));
CREATE TABLE IF NOT EXISTS v03_task_attempts (
 mission_id TEXT NOT NULL REFERENCES v03_missions(id), task_id TEXT NOT NULL,
 attempt INTEGER NOT NULL DEFAULT 1, state TEXT NOT NULL, result_json TEXT,
 started_at TEXT, ended_at TEXT, PRIMARY KEY(mission_id,task_id,attempt));
CREATE TABLE IF NOT EXISTS v03_artifact_revisions (
 id TEXT NOT NULL, mission_id TEXT NOT NULL REFERENCES v03_missions(id),
 enterprise_id TEXT NOT NULL, version INTEGER NOT NULL, data_json TEXT NOT NULL,
 actor_id TEXT NOT NULL, content_hash TEXT NOT NULL, created_at TEXT NOT NULL,
 PRIMARY KEY(id,version));
CREATE INDEX IF NOT EXISTS v03_missions_enterprise ON v03_missions(enterprise_id,owner_id,created_at);
CREATE TABLE IF NOT EXISTS v03_product_markets (
 enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id), owner_id TEXT NOT NULL REFERENCES v03_accounts(id),
 product_id TEXT NOT NULL REFERENCES v03_entities(id), market_code TEXT NOT NULL,
 entity_id TEXT NOT NULL UNIQUE REFERENCES v03_entities(id), created_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,owner_id,product_id,market_code));
"""

RELEVANT_FIELDS = (
    "name", "target_market", "ingredients", "net_quantity", "statement_of_identity",
    "responsible_business", "facility_activity", "facility_name", "facility_address",
    "facility_type", "allergens", "nutrition_information", "processing_description",
    "packaging", "origin_country", "fda_registration_status",
)
FIELD_SPECS = (
    ("statement_of_identity", "Statement of identity", "Tên thực phẩm tiếng Anh", "Nhập tên thực phẩm; không dùng tên thương hiệu thay cho tên mô tả khi chưa rà.", "needs_input"),
    ("net_quantity", "Net quantity", "Lượng tịnh và đơn vị", "Nhập lượng tịnh thực tế, kèm đơn vị; chưa suy ra từ kích thước hộp.", "needs_input"),
    ("ingredients", "Ingredients", "Thành phần", "Điền theo công thức thực tế và rà thứ tự trình bày; tên Trà Sen không chứng minh công thức.", "needs_input"),
    ("responsible_business", "Responsible business", "Đơn vị chịu trách nhiệm và địa chỉ", "Nhập tên, địa chỉ và vai trò của đơn vị; chưa tự dịch tên pháp nhân.", "needs_input"),
    ("nutrition_information", "Nutrition information", "Thông tin dinh dưỡng", "Cần xác định phạm vi yêu cầu/ngoại lệ và căn cứ; không tự coi trà được miễn.", "needs_scope_check"),
    ("allergens", "Allergen information", "Thông tin dị nguyên", "Xác nhận từ thành phần và quy trình; để trống không có nghĩa là không có dị nguyên.", "needs_scope_check"),
)
NON_US_MARKET = r"\b(?:eu|chau au|nhat|japan|canada|uc|australia|singapore|trung quoc|china)\b"
MARKET_FIELDS = frozenset({"statement_of_identity", "responsible_business", "nutrition_information", "allergen_declaration", "fda_registration_status", "date_marking", "storage_instructions", "ingredients_declaration"})
MARKET_LABEL_FIELDS = MARKET_FIELDS | LABEL_FACT_ALIASES.keys()
FACILITY_FIELDS = frozenset({"facility_activity", "facility_type", "facility_name", "facility_address"})
SHARED_FIELDS = tuple(field for field in RELEVANT_FIELDS if field not in MARKET_FIELDS | FACILITY_FIELDS and field != "target_market")
LANGUAGE_NAMES = {"en": "tiếng Anh", "de": "tiếng Đức", "ja": "tiếng Nhật"}
CLARIFICATION = "Anh/chị muốn tìm hiểu điều kiện nhập khẩu hay chuẩn bị nhãn?"
DESTINATION_MARKER = r"\b(?:(?:sang|di|xuat (?:sang|di)|xuat khau (?:sang|di)|gui(?: (?:sang|den))?|ban (?:sang|tai))\s+(?!tiep\b|ho so\b|nhan\b|buoc\b|them\b|thong tin\b|ban nhap\b)|thi truong(?:\s+(?:la|thanh|den|sang))?\s+(?!nay\b|do\b|da\b|truoc\b|hien tai\b))"


def market_of(mission):
    # Persisted 0.3A missions were exclusively US. Never use this compatibility
    # rule to resolve a new question, only to read an already stored old mission.
    return (mission.get("market") or {}).get("code") or mission.get("intent", {}).get("market_code") or ("US" if mission.get("intent", {}).get("scope") == "us_food" else None)


def resolve_market(text, explicit=None, previous=None):
    detected = detect_markets(text)
    normalized = normalize(text)
    chosen = get_market(explicit)["code"] if explicit is not None else None
    selection = re.search(r"\bchon thi truong\s+(.+?)\s+cho luot nay[.!?\s]*$", normalized)
    if selection:
        selected_codes = detect_markets(selection.group(1))
        if len(selected_codes) == 1 and selected_codes[0] in MARKETS and (chosen is None or chosen == selected_codes[0]):
            detected = selected_codes
    # Inspect the actual destination phrase separately from historical/product
    # mentions. A known old market must not mask an unrecognized new country.
    destination_phrases = list(re.finditer(DESTINATION_MARKER, normalized))
    if destination_phrases and not selection:
        destination = re.split(r"[.;!?]|\b(?:tu|can|muon|cho|nhung|voi|kem|chuan bi)\b", normalized[destination_phrases[-1].end():], maxsplit=1)[0].strip()
        destination_codes = detect_markets(destination)
        if destination:
            detected = destination_codes or ["OTHER"]
    # A clear new-destination clause can contrast with historical dossiers.
    # Without that signal, multiple markets need one explicit choice.
    transitions = list(re.finditer(r"\b(?:gio|bay gio|lan nay|hien tai)\b", normalized))
    if transitions:
        transition = transitions[-1]
        old_part, new_part = normalized[:transition.start()], normalized[transition.end():]
        new_codes = detect_markets(new_part)
        if re.search(r"\b(?:da|truoc|cu)\b", old_part) and re.search(DESTINATION_MARKER, new_part):
            detected = new_codes or ["OTHER"]
    if not detected and re.search(DESTINATION_MARKER, normalized):
        detected = ["OTHER"]
    # FDA alone denotes the old bounded US use case; a stated destination wins.
    if not detected and not previous and explicit is None and re.search(r"\bfda\b", normalized):
        detected = ["US"]
    if len(detected) > 1:
        if chosen in detected:
            return chosen, [chosen], []
        return None, detected, ["Mỗi hồ sơ nghiên cứu áp dụng cho một thị trường. Anh/chị chọn Mỹ, Đức (EU) hay Nhật Bản cho lượt này?"]
    if detected == ["EU"]:
        if chosen == "DE":
            return chosen, [chosen], []
        return None, detected, ["EU gồm nhiều quốc gia. Anh/chị muốn xuất sang nước nào? 0.3B hiện có gói Đức (EU)."]
    if detected == ["OTHER"]:
        return None, detected, ["Thị trường vừa nêu chưa có gói nguồn trong 0.3B. Hiện có Mỹ, Đức (EU) và Nhật Bản; không áp quy định Mỹ thay thế."]
    if detected and chosen and detected[0] != chosen:
        return None, detected + [chosen], ["Thị trường trong câu hỏi khác thị trường đang chọn. Anh/chị xác nhận lại trước khi nghiên cứu."]
    code = detected[0] if detected else chosen or previous
    if code not in MARKETS:
        return None, [], ["Anh/chị muốn xuất sang Mỹ, Đức (EU) hay Nhật Bản? Cần xác nhận thị trường cho hồ sơ này."]
    return code, [code], []


def field_specs(market_code):
    specs = list(FIELD_SPECS)
    if market_code == "US":
        return specs
    translated = {
        "DE": (("Bezeichnung des Lebensmittels", "Tên thực phẩm tiếng Đức"), ("Nettofüllmenge", "Lượng tịnh và đơn vị"),
               ("Zutaten", "Thành phần — cần rà bản tiếng Đức"), ("Verantwortlicher Lebensmittelunternehmer", "Đơn vị chịu trách nhiệm tại EU và địa chỉ"),
               ("Nährwertdeklaration", "Thông tin dinh dưỡng"), ("Allergene", "Thông tin dị nguyên")),
        "JP": (("名称", "Tên thực phẩm tiếng Nhật"), ("内容量", "Lượng tịnh và đơn vị"),
               ("原材料名", "Thành phần — cần rà bản tiếng Nhật"), ("食品関連事業者", "Đơn vị chịu trách nhiệm tại Nhật và địa chỉ"),
               ("栄養成分表示", "Thông tin dinh dưỡng"), ("アレルゲン", "Thông tin dị nguyên")),
    }[market_code]
    for index, (key, _en, _vi, hint, state) in enumerate(specs):
        native, label = translated[index]
        if key == "statement_of_identity":
            hint = f"Nhập tên thực phẩm {LANGUAGE_NAMES[get_market(market_code)['label_language']]}; chưa tự dịch tên hoặc xác nhận bản dịch pháp lý."
        if key == "responsible_business":
            hint = "Nhập đúng đơn vị, địa chỉ và vai trò tại thị trường này; không lấy đại diện của thị trường khác."
        if key in {"ingredients", "net_quantity"}:
            hint += " Dữ kiện sản phẩm dùng chung được giữ nguyên, chưa dịch hay xác nhận phù hợp thị trường này."
        if key == "ingredients":
            native, label = "Nguyên liệu gốc chưa dịch", "Thành phần sản phẩm đã khai · dùng chung"
            hint = "Chỉ đọc từ công thức gốc trong hồ sơ sản phẩm. Muốn sửa công thức, sửa rõ dữ kiện sản phẩm dùng chung; cách ghi trên nhãn được lưu ở ô riêng của thị trường."
        specs[index] = (key, native, label, hint, state)
    specs.insert(3, ("ingredients_declaration", "Zutaten (Kennzeichnung)" if market_code == "DE" else "原材料名（表示）",
        f"Cách ghi thành phần trên nhãn {LANGUAGE_NAMES[get_market(market_code)['label_language']]}",
        "Nhập cách ghi thành phần dành riêng cho thị trường này. Chưa tự dịch công thức hoặc coi bản dịch đã đúng thứ tự, thuật ngữ và cách nhấn mạnh dị nguyên.", "needs_input"))
    specs.extend([
        ("date_marking", "Mindesthaltbarkeitsdatum / Verbrauchsdatum" if market_code == "DE" else "期限表示", "Hạn dùng và cách thể hiện ngày", "Nhập ngày/cách ghi được xác nhận từ hồ sơ lô và hạn sử dụng; không tự suy ra hạn dùng từ tên sản phẩm.", "needs_input"),
        ("storage_instructions", "Aufbewahrungshinweise" if market_code == "DE" else "保存方法", "Hướng dẫn bảo quản", "Nhập điều kiện bảo quản thực tế; cần rà nội dung và ngôn ngữ áp dụng tại thị trường này.", "needs_input"),
    ])
    return specs


def digest(value):
    return hashlib.sha256(json_text(value).encode("utf-8")).hexdigest()


def normalize(value):
    return "".join(c for c in unicodedata.normalize("NFD", value.lower().replace("đ", "d")) if unicodedata.category(c) != "Mn")


def interpret(text):
    lowered = normalize(text)
    outcomes = []
    def requested(pattern, value=lowered):
        for match in re.finditer(pattern, value):
            prefix = re.split(r"[.;,\n]|\b(?:nhung|ma|con|chi|va)\b", value[max(0, match.start()-90):match.start()])[-1]
            if not re.search(r"\b(?:(?:khong|dung|chua)\s+(?:(?:can|muon)\s+)?(?:nghien cuu|tim hieu|hoi(?: ve)?|xem|lam|chuan bi)(?:\s+lai)?(?:\s+ve)?|bo qua)\s*$", prefix):
                return True
        return False

    if requested(r"dang ky|registration|dieu kien nhap khau|thu tuc nhap khau|thong bao nhap khau") or (not re.search(r"dang ky|registration", lowered) and requested(r"co so fda")):
        outcomes.append(Outcome(id="registration", title="Điều kiện nhập khẩu và cơ sở", question_part=text))
    label_words = re.sub(r"chung\s+nhan", "", lowered)
    if requested(r"\b(?:nhan|label|labeling)\b", label_words):
        outcomes.append(Outcome(id="label", title="Chuẩn bị nhãn theo thị trường", question_part=text))
    if requested(r"thong bao truoc|prior notice"):
        outcomes.append(Outcome(id="prior_notice", title="Thông báo trước lô hàng", question_part=text))
    if requested(r"chung nhan|certification"):
        outcomes.append(Outcome(id="certification", title="Yêu cầu chứng nhận", question_part=text))
    if not outcomes:
        outcomes = [Outcome(id="clarification", title="Làm rõ mục tiêu", question_part=text)]
    code, candidates, ambiguities = resolve_market(text)
    for outcome in outcomes:
        if code and outcome.id in {"registration", "label"}:
            outcome.title = market_title(outcome.id, code)
    if outcomes[0].id == "clarification":
        ambiguities.append(CLARIFICATION)
    return Intent(scope="us_food" if code == "US" else "export_food" if code else "unsupported",
                  market_code=code, market_candidates=candidates, outcomes=outcomes, ambiguities=ambiguities)


def product_name(text):
    match = re.search(r"(?:tôi|em|anh|chị|mình|doanh nghiệp)\s+có\s+(.+?)(?=\s+(?:gửi|xuất|cần|muốn|sang|đi)\b|[.;\n]|$)", text, re.IGNORECASE)
    if match:
        return match.group(1).strip(" ,:")[:200]
    return None


def make_plan(intent):
    tasks = []
    code = intent.market_code or "unresolved"
    for outcome in intent.outcomes:
        oid = outcome.id
        if oid == "registration":
            tasks.append(PlanTask(id="registration-research", title=outcome.title, outcome_ids=[oid], capability_id=f"export_{code.lower()}.facility_registration"))
        elif oid == "label":
            tasks.extend([
                PlanTask(id="label-research", title=f"Đối chiếu nội dung nhãn cho {MARKETS.get(code, {}).get('name_vi', 'thị trường cần xác nhận')}", outcome_ids=[oid], capability_id=f"export_{code.lower()}.food_label"),
                PlanTask(id="label-workbook", title=outcome.title, outcome_ids=[oid], capability_id="artifact.food_label_workbook", depends_on=["label-research"]),
            ])
        elif outcome_topic(oid, code) == "prior_notice":
            tasks.append(PlanTask(id="prior_notice-research", title=outcome.title,
                                  outcome_ids=[oid], capability_id="export_us.prior_notice"))
        else:
            tasks.append(PlanTask(id=f"{oid}-gap", title=f"Xác định phạm vi còn thiếu: {outcome.title.lower()}", outcome_ids=[oid], capability_id="coverage.explicit_gap"))
    raw = [t.model_dump() for t in tasks]
    return Plan(tasks=tasks, hash=digest({"intent": intent.model_dump(), "tasks": raw}), template_version=MARKETS.get(code, {}).get("pack_version", "unresolved-market-v03b"))


class MissionService:
    def __init__(self, repo, *, task_delay=0.0):
        self.repo = repo
        self.catalog = DomainCatalog(repo)
        self.task_delay = task_delay
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)

    def _interpret_request(self, user_text):
        return interpret(user_text), product_name(user_text)

    def _compose_publication(self, mission, answers, actions, artifacts):
        return bind_answer_citations(answers, mission["knowledge"]["records"], expected_market_code=market_of(mission)), actions, artifacts

    def _market_profile(self, account, enterprise, product, code):
        """One private market entity per canonical product, never a copied label."""
        with self.repo.connection(write=True) as db:
            entity = self.repo._entity(account, enterprise, product, db)
            row = db.execute("SELECT entity_id FROM v03_product_markets WHERE enterprise_id=? AND owner_id=? AND product_id=? AND market_code=?", (enterprise, account, product, code)).fetchone()
            if row:
                return self.repo._entity(account, enterprise, row["entity_id"], db)
            profile_id = new_id("entity")
            stamp = now_iso()
            db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) VALUES(?,?,?,?,?,?,?)", (profile_id, enterprise, "market", f"{get_market(code)['name_vi']} · {entity['name']}"[:250], product, account, stamp))
            db.execute("INSERT INTO v03_product_markets VALUES(?,?,?,?,?,?)", (enterprise, account, product, code, profile_id, stamp))
            self.repo._advance_revision(db, enterprise, account, [{"entity_id": profile_id, "field": "__created__", "market_code": code}])
            # A product assertion is never silently reinterpreted as a confirmed
            # market declaration. Old rows remain in audit/quarantine; drafts
            # keep their original revisions for an explicit owner decision.
            return self.repo._entity(account, enterprise, profile_id, db)

    def _linked_facility(self, account, enterprise, product_id, db):
        if not product_id:
            return None
        self.repo._entity(account, enterprise, product_id, db)
        rows = db.execute("SELECT id FROM v03_entities WHERE enterprise_id=? AND created_by=? "
                          "AND parent_entity_id=? AND entity_type IN ('facility','production_facility') "
                          "AND acl='private_owner' ORDER BY id", (enterprise, account, product_id)).fetchall()
        if len(rows) > 1:
            raise CoreError("facility_selection_required", "Sản phẩm có nhiều cơ sở được liên kết; cần chọn đúng cơ sở trước khi dùng hoặc sửa dữ kiện.", 409)
        return self.repo._entity(account, enterprise, rows[0]["id"], db) if rows else None

    def _facility_binding_valid(self, account, enterprise, context, db=None):
        binding = context.get("facility_binding")
        if binding is None:
            return True  # Stored pre-binding reports remain historical snapshots.
        if db is None:
            with self.repo.connection() as connection:
                return self._facility_binding_valid(account, enterprise, context, connection)
        current = self._linked_facility(account, enterprise, binding["product_entity_id"], db)
        return binding["entity_id"] == (current["id"] if current else None)

    def _context(self, account, enterprise, product_id, profile_id=None, db=None, include_archived=False):
        if db is None:
            # Product and market profile form one consistent read snapshot.
            with self.repo.connection() as connection:
                return self._context(account, enterprise, product_id, profile_id, db=connection, include_archived=include_archived)
        # Exclude old scalar target_market and old product-level scoped fields.
        shared = self.repo.get_context(account, enterprise, [product_id] if product_id else [], fields=list(SHARED_FIELDS), db=db, include_archived=include_archived)
        scoped = self.repo.get_context(account, enterprise, [profile_id] if profile_id else [], fields=sorted(MARKET_FIELDS), db=db, include_archived=include_archived)
        facility = self._linked_facility(account, enterprise, product_id, db)
        facility_context = self.repo.get_context(account, enterprise, [facility["id"]] if facility else [],
                                                 fields=sorted(FACILITY_FIELDS), db=db, include_archived=include_archived)
        context = {**shared, "entities": shared["entities"] + scoped["entities"] + facility_context["entities"],
                   "fact_refs": shared["fact_refs"] + scoped["fact_refs"] + facility_context["fact_refs"]}
        context["shared_values"] = shared["entities"][0]["values"] if shared["entities"] else {}
        context["market_values"] = scoped["entities"][0]["values"] if scoped["entities"] else {}
        context["facility_values"] = facility_context["entities"][0]["values"] if facility_context["entities"] else {}
        context["facility_binding"] = {"product_entity_id": product_id, "entity_id": facility["id"] if facility else None}
        context["values"] = {**context["shared_values"], **context["facility_values"], **context["market_values"]}
        context["label_fact_aliases"] = dict(LABEL_FACT_ALIASES)
        for label_field, canonical in LABEL_FACT_ALIASES.items():
            # Product allergen facts inform review, but cannot fill a translated
            # label declaration or imply that no declaration is required.
            context["values"].pop(label_field, None)
            if canonical in context["market_values"]:
                context["values"][label_field] = context["market_values"][canonical]
        context["context_hash"] = digest(context["fact_refs"])
        return context

    def _row(self, account_id, enterprise_id, mission_id, db):
        self.repo.get_membership(account_id, enterprise_id, db)
        row = db.execute("SELECT * FROM v03_missions WHERE id=? AND enterprise_id=? AND owner_id=?", (mission_id, enterprise_id, account_id)).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy hội thoại trong doanh nghiệp này.", 404)
        return row

    def _operation(self, db, account, enterprise, kind, operation, request):
        if not isinstance(operation, str) or not 1 <= len(operation) <= 128:
            raise CoreError("invalid_operation", "Thiếu mã thao tác hợp lệ.")
        row = db.execute("SELECT * FROM v03_mission_operations WHERE enterprise_id=? AND account_id=? AND kind=? AND operation_id=?", (enterprise, account, kind, operation)).fetchone()
        if row and row["request_hash"] != digest(request):
            raise CoreError("idempotency_conflict", "Mã thao tác đã dùng cho nội dung khác.", 409)
        return row

    def _remember(self, db, account, enterprise, kind, operation, request, mission_id):
        db.execute("INSERT INTO v03_mission_operations VALUES(?,?,?,?,?,?)", (enterprise, account, kind, operation, digest(request), mission_id))

    def prepare(self, account_id, enterprise_id, user_text, operation_id, product_entity_id=None, continuation_mission_id=None, market_code=None):
        if not isinstance(user_text, str) or not 1 <= len(user_text.strip()) <= 4000:
            raise CoreError("invalid_question", "Nhập câu hỏi từ 1 đến 4.000 ký tự.")
        user_text = user_text.strip()
        request = {"text": user_text, "product_entity_id": product_entity_id}
        if market_code is not None:
            request["market_code"] = market_code
        if continuation_mission_id is not None:
            request["continuation_mission_id"] = continuation_mission_id
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            old = self._operation(db, account_id, enterprise_id, "prepare", operation_id, request)
            if old:
                return self.get(account_id, enterprise_id, old["mission_id"])
        previous = None
        if continuation_mission_id:
            previous = self.get(account_id, enterprise_id, continuation_mission_id)
            if not previous.get("product"):
                raise CoreError("missing_product", "Hội thoại trước chưa có hồ sơ sản phẩm để tiếp tục.")
            if product_entity_id and product_entity_id != previous["product"]["entity_id"]:
                raise CoreError("continuation_product_mismatch", "Không thể lấy bản nháp của sản phẩm khác.", 409)
            product_entity_id = previous["product"]["entity_id"]
        intent, name = self._interpret_request(user_text)
        # Resolve a new question from its explicit destination, an explicit UI
        # selection, or this authorized continuation. Product preferences never
        # silently turn an unknown/new destination into the US.
        code, detected, market_ambiguities = resolve_market(user_text, market_code, market_of(previous) if previous else None)
        original = interpret(user_text)
        market_messages = set(original.ambiguities) - {CLARIFICATION}
        intent.ambiguities = [a for a in intent.ambiguities if a not in market_messages]
        intent.ambiguities.extend(market_ambiguities)
        intent.market_code, intent.market_candidates = code, detected
        intent.scope = "us_food" if code == "US" else "export_food" if code else "unsupported"
        for outcome in intent.outcomes:
            if code and outcome.id in {"registration", "label"}:
                outcome.title = market_title(outcome.id, code)
        candidates = self.repo.find_entities_by_name(account_id, enterprise_id, name) if name else []
        if product_entity_id:
            entity = self.repo.get_entity(account_id, enterprise_id, product_entity_id)
            if entity.get("archived"):
                raise CoreError("entity_archived", "Hồ sơ sản phẩm đã lưu trữ; khôi phục trước khi lập kế hoạch mới.", 409)
            if entity["entity_type"] != "product":
                raise CoreError("invalid_entity", "Cần chọn đúng sản phẩm.")
            # A selected dossier remains the identity anchor when the owner
            # uses its shorter name in chat. An exact competing dossier wins
            # the ambiguity check; this never creates an alias or changes SSOT.
            short_reference = bool(name and not candidates and normalize(entity["name"]).strip().startswith(normalize(name).strip() + " "))
            if name and entity["id"] not in {e["id"] for e in candidates} and not short_reference:
                intent.ambiguities.append("Tên sản phẩm trong câu hỏi khác sản phẩm đang chọn; cần chọn đúng hồ sơ.")
        else:
            entity = candidates[0] if len(candidates) == 1 else None
            if len(candidates) > 1:
                intent.ambiguities.append("Tên này khớp nhiều hồ sơ hoặc tên trước đây; cần chọn đúng sản phẩm để tiếp tục.")
            if entity is None and name and not candidates:
                entity = self.repo.create_entity(account_id, enterprise_id, "product", name, operation_id=f"mission-entity:{operation_id}")
            if entity is None and not candidates:
                intent.ambiguities.append("Cần nêu tên sản phẩm hoặc chọn sản phẩm đã có.")
        existing_fields = {f["field"] for f in entity.get("facts", []) if f["value_state"] == "known" and f["field"] in SHARED_FIELDS} if entity else set()
        if entity and not entity.get("facts"):
            self.repo.propose_or_apply_facts(account_id, enterprise_id, entity["id"], [
                {"field": "name", "value": entity["name"], "source": {"kind": "user_message", "quote": user_text}},
            ], entity["version"], f"mission-facts:{operation_id}")
        profile = self._market_profile(account_id, enterprise_id, entity["id"], code) if entity and code else None
        context = self._context(account_id, enterprise_id, entity["id"] if entity else None, profile["id"] if profile else None)
        entity_context = context["entities"][0] if entity else None
        context["reused_shared_fact_count"] = len(existing_fields.intersection(context["shared_values"]))
        context["reused_market_fact_count"] = len(context["market_values"])
        context["reused_facility_fact_count"] = len(context["facility_values"])
        context["reused_fact_count"] = context["reused_shared_fact_count"] + context["reused_market_fact_count"] + context["reused_facility_fact_count"]
        topics = list(dict.fromkeys(topic for outcome in intent.outcomes
                                   if (topic := outcome_topic(outcome.id, code)) is not None)) if code else []
        knowledge = self.catalog.lookup_domain(topics if code else [], account_id, enterprise_id, market_code=code or "US")
        if not code:
            # Empty coverage is explicit; no US records leak into a question
            # whose destination has not been resolved.
            knowledge["records"], knowledge["source_refs"] = [], []
            knowledge["market"], knowledge["market_code"] = None, None
        plan = make_plan(intent)
        plan.hash = digest({"plan": plan.model_dump(), "enterprise_id": enterprise_id,
                            "fact_refs": context["fact_refs"], "source_refs": knowledge["source_refs"]})
        mission_id, stamp = new_id("mission"), now_iso()
        product = {"entity_id": entity_context["id"], "name": entity_context["values"].get("name", entity_context["name"]), "version": entity_context["version"]} if entity_context else None
        value = {"id": mission_id, "enterprise_id": enterprise_id, "owner_id": account_id,
                 "question": user_text, "mode": "bounded_templates_no_paid_calls", "intent": intent.model_dump(),
                 "product": product, "plan": plan.model_dump(), "context": context, "knowledge": knowledge,
                 "market": get_market(code) if code else None,
                 "market_profile": {"entity_id": profile["id"], "version": context["entities"][1]["version"], "market_code": code,
                                    "values": context["market_values"], "facts": context["entities"][1]["facts"]} if profile else None,
                 "continuation_mission_id": continuation_mission_id,
                 "product_candidates": [{"entity_id": e["id"], "name": e["name"], "version": e["version"]} for e in candidates] if len(candidates) > 1 else [],
                 "answers": [], "actions": [], "artifacts": [], "cost": {"paid_calls": 0, "provider_attempts": 0},
                 "created_at": stamp, "updated_at": stamp}
        # This is a separate bounded checklist, not an extra requested outcome
        # or permission for another paid model call. Old plans are never
        # backfilled on read; only newly prepared plans acquire this snapshot.
        if code == "US":
            with self.repo.connection() as readiness_db:
                readiness = project_goal_readiness(value, read_authority_records(readiness_db, code))
            if readiness is not None:
                value["goal_readiness_snapshot"] = readiness
                value["readiness_source_refs"] = readiness["source_refs"]
                value["plan"]["hash"] = digest({"explicit_plan_hash": plan.hash, "readiness": readiness})
        status = "waiting_input" if intent.scope == "unsupported" or intent.ambiguities else "planned"
        with self.repo.connection(write=True) as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            old = self._operation(db, account_id, enterprise_id, "prepare", operation_id, request)
            if old:
                mission_id = old["mission_id"]
            else:
                db.execute("INSERT INTO v03_missions(id,enterprise_id,owner_id,status,payload_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (mission_id, enterprise_id, account_id, status, json_text(value), stamp, stamp))
                for task in plan.tasks:
                    db.execute("INSERT INTO v03_task_attempts(mission_id,task_id,state) VALUES(?,?,?)", (mission_id, task.id, "planned"))
                refs = {f'{ref["entity_id"]}:{ref["field"]}': ref["version"] for ref in context["fact_refs"]}
                for ref in context["fact_refs"]:
                    key = f'{ref["entity_id"]}:{ref["field"]}'
                    db.execute("INSERT INTO v03_dependencies VALUES(?,?,?,?,?)", (mission_id, enterprise_id, "fact", key, str(refs.get(key, 0))))
                if entity:
                    db.execute("INSERT INTO v03_dependencies VALUES(?,?,?,?,?)", (mission_id, enterprise_id,
                        "facility_binding", entity["id"], context["facility_binding"]["entity_id"] or "none"))
                for ref in mission_source_dependencies(value):
                    db.execute("INSERT INTO v03_dependencies VALUES(?,?,?,?,?)", (mission_id, enterprise_id, "source", ref["source_id"], str(ref["version"])))
                self._remember(db, account_id, enterprise_id, "prepare", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)

    def start(self, account_id, enterprise_id, mission_id, operation_id):
        current = self.get(account_id, enterprise_id, mission_id)
        if (current.get("product") or {}).get("archived"):
            raise CoreError("entity_archived", "Sản phẩm đã lưu trữ; cần khôi phục trước khi bắt đầu nghiên cứu.", 409)
        if current["status"] == "needs_revalidation":
            with self.repo.connection(write=True) as db:
                self._row(account_id, enterprise_id, mission_id, db)
                db.execute("UPDATE v03_missions SET status='needs_revalidation',stale_reason=?,updated_at=? WHERE id=?", ("Dữ kiện hoặc nguồn đã đổi; cần đối chiếu trước khi thực thi.", now_iso(), mission_id))
            raise CoreError("context_changed", "Dữ kiện hoặc nguồn đã đổi; cần kế hoạch mới, không tự chạy lại.", 409)
        with self.repo.connection(write=True) as db:
            row = self._row(account_id, enterprise_id, mission_id, db)
            request = {"mission_id": mission_id, "version": 1}
            old = self._operation(db, account_id, enterprise_id, "start", operation_id, request)
            if not old:
                if row["status"] == "planned":
                    db.execute("UPDATE v03_missions SET status='queued',updated_at=? WHERE id=? AND status='planned'", (now_iso(), mission_id))
                elif row["status"] not in ("queued", "running", "completed", "completed_partial"):
                    raise CoreError("mission_not_ready", "Hồ sơ đã đổi hoặc còn thiếu mục tiêu; cần lập kế hoạch mới, không tự chạy lại.", 409)
                self._remember(db, account_id, enterprise_id, "start", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)

    def _internal(self, mission_id):
        with self.repo.connection() as db:
            row = db.execute("SELECT * FROM v03_missions WHERE id=?", (mission_id,)).fetchone()
            if not row:
                raise CoreError("not_found", "Không tìm thấy công việc.", 404)
            value = json.loads(row["payload_json"])
            value.update(status=row["status"], version=row["version"], stale_reason=row["stale_reason"])
            return value

    def execution_guard(self, mission_id):
        mission = self._internal(mission_id)
        if mission["status"] != "running":
            raise CoreError("context_changed", "Dữ kiện hoặc nguồn đã đổi. Kết quả cần đối chiếu lại trước khi dùng.", 409)
        checked = self.repo.validate_context(mission["owner_id"], mission["enterprise_id"], mission["context"]["fact_refs"], mission_source_dependencies(mission))
        with self.repo.connection() as source_db:
            readiness_current = readiness_snapshot_valid(mission, source_db)
        with self.repo.connection() as lifecycle_db:
            self.repo.require_active_entity(mission["owner_id"], mission["enterprise_id"], mission["product"]["entity_id"], lifecycle_db)
        if not checked["valid"] or not readiness_current or not self._facility_binding_valid(mission["owner_id"], mission["enterprise_id"], mission["context"]):
            with self.repo.connection(write=True) as db:
                db.execute("UPDATE v03_missions SET status='needs_revalidation',stale_reason=?,updated_at=? WHERE id=?", ("Dữ kiện, quyền hoặc phiên bản nguồn đã thay đổi.", now_iso(), mission_id))
            raise CoreError("context_changed", "Dữ kiện, quyền hoặc nguồn đã đổi; không công bố như kết quả hiện hành.", 409)
        return mission

    async def execute_next(self):
        with self.repo.connection(write=True) as db:
            row = db.execute("SELECT id FROM v03_missions WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
            if not row:
                return False
            mission_id = row["id"]
            db.execute("UPDATE v03_missions SET status='running',updated_at=? WHERE id=? AND status='queued'", (now_iso(), mission_id))
        await self.execute(mission_id)
        return True

    async def execute(self, mission_id):
        mission = self._internal(mission_id)
        try:
            with tracing_context(enabled=False):
                await build_graph(self, mission).ainvoke({"mission_id": mission_id, "task_results": {}}, {"recursion_limit": 24})
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Paid-free mission execution stopped: %s", mission_id)
            with self.repo.connection(write=True) as db:
                db.execute("UPDATE v03_missions SET status='failed',stale_reason=?,updated_at=? WHERE id=? AND status='running'", ("Lượt giả lập bị dừng; không có lượt AI có phí. Có thể xem dữ kiện và lập kế hoạch mới.", now_iso(), mission_id))
                db.execute("UPDATE v03_task_attempts SET state='failed',ended_at=? WHERE mission_id=? AND state='running'", (now_iso(), mission_id))

    def recover_interrupted(self):
        with self.repo.connection(write=True) as db:
            count = db.execute("UPDATE v03_missions SET status='failed',stale_reason=?,updated_at=? WHERE status='running'", ("Máy chủ đã khởi động lại khi đang xử lý. Lượt giả lập đã dừng, không tự chạy lại.", now_iso())).rowcount
            db.execute("UPDATE v03_task_attempts SET state='failed',ended_at=? WHERE state='running'", (now_iso(),))
        return count

    async def execute_task(self, mission_id, task, previous):
        mission = self.execution_guard(mission_id)
        with self.repo.connection(write=True) as db:
            db.execute("UPDATE v03_task_attempts SET state='running',started_at=? WHERE mission_id=? AND task_id=? AND state='planned'", (now_iso(), mission_id, task["id"]))
        if self.task_delay:
            await asyncio.sleep(self.task_delay)
        self.execution_guard(mission_id)
        capability = task["capability_id"]
        records = mission["knowledge"]["records"]
        if capability in tuple(f"export_{code.lower()}.{topic}" for code in MARKETS for topic in ("facility_registration", "food_label")) + ("export_us.prior_notice",):
            topic = capability.rsplit(".", 1)[1]
            selected = [r for r in records if topic in r["topics"] and r.get("reusable") is True]
            result = {"kind": "reference_findings", "records": selected, "status": "succeeded" if selected else "blocked_source", "review_state": "reference_unreviewed"}
        elif capability == "artifact.food_label_workbook":
            values = context_values(mission["context"])
            code = market_of(mission)
            market = get_market(code)
            source_ids = [r["id"] for r in previous["label-research"]["records"]]
            prior = self._compatible_label(mission)
            fields = []
            for key, english, vietnamese, hint, state in field_specs(code):
                value = values.get(key)
                if isinstance(value, list):
                    value = ", ".join(str(item) for item in value)
                reused_raw = value is not None and code != "US" and key in {"ingredients", "net_quantity"}
                fields.append(LabelField(id=key, label_en=english, label_vi=vietnamese, value=str(value) if value is not None else None, state="needs_review" if reused_raw else "self_declared" if value is not None else state, help_vi=hint, source_ids=source_ids, basis_refs=basis(mission["context"], DEPENDENCIES[key]), provenance={"kind": "enterprise_ssot", "verification_state": "self_declared", "scope": "shared_product" if key not in MARKET_LABEL_FIELDS else "market_profile", "translation_state": "original_user_value_untranslated" if reused_raw else "user_supplied"} if value is not None else None))
            parent_ref = {"artifact_id": prior["id"], "version": prior["version"], "mission_id": prior["mission_id"], "market_code": code, "basis": "same_product_same_market_label_fields"} if prior else None
            data = LabelWorkbook(schema_version="food-label-workbook-v1" if code == "US" else "food-label-workbook-v2-multimarket", product_reference=mission["product"]["name"], market_code=code, market_name_vi=market["name_vi"], label_language=market["label_language"], fields=fields, parent_artifact_ref=parent_ref).model_dump()
            if prior:
                # New schema slots must appear when continuing an older saved
                # workbook; its original revision remains untouched.
                prior_fields, excluded = {}, []
                for field in prior["fields"]:
                    issue = validate_field_value(field["id"], field["value"]) if field.get("value") is not None else None
                    if issue:
                        excluded.append({"field": field["id"], "code": issue["code"]})
                    else:
                        prior_fields[field["id"]] = field
                data["fields"] = [{**field, **prior_fields.get(field["id"], {})} for field in data["fields"]]
                data = reconcile(data, prior["basis_context"], mission["context"], fill_missing=True)
                if excluded:
                    data["parent_artifact_ref"]["excluded_invalid_fields"] = excluded
                    data["limitations_vi"] += " Một số ô nhãn cũ chưa hợp lệ nên không được dùng lại; ô chưa có dữ kiện hợp lệ cần được bổ sung. Bản cũ được giữ nguyên để đối chiếu và sửa."
                for field in data["fields"]:
                    field["source_ids"] = source_ids
            result = {"kind": "food_label_workbook", "data": data, "status": "succeeded"}
        else:
            result = {"kind": "explicit_gap", "status": "blocked_source", "message": "Bộ tri thức 0.3B chưa có căn cứ đã được kiểm cho câu hỏi này; không suy ra từ nguồn đăng ký hoặc nhãn."}
        with self.repo.connection(write=True) as db:
            db.execute("UPDATE v03_task_attempts SET state=?,result_json=?,ended_at=? WHERE mission_id=? AND task_id=? AND state='running'", (result["status"], json_text(result), now_iso(), mission_id, task["id"]))
        return result

    def _compatible_label(self, mission):
        """Carry private user work; reconcile each field instead of all context."""
        with self.repo.connection() as db:
            self.repo._entity(mission["owner_id"], mission["enterprise_id"], mission["product"]["entity_id"], db)
            if not self._facility_binding_valid(mission["owner_id"], mission["enterprise_id"], mission["context"], db):
                raise CoreError("context_changed", "Cơ sở liên quan đã đổi trước khi lưu kết quả.", 409)
            requested_parent = mission.get("continuation_mission_id")
            rows = db.execute("SELECT id,payload_json FROM v03_missions WHERE enterprise_id=? AND owner_id=? AND id<>? ORDER BY updated_at DESC", (mission["enterprise_id"], mission["owner_id"], mission["id"])).fetchall()
            visited = {mission["id"]}
            ordered = []
            parent_id = requested_parent
            while parent_id:
                if parent_id in visited or len(visited) > 20:
                    raise CoreError("continuation_invalid", "Chuỗi hội thoại cần được chọn lại trước khi lấy bản nháp.", 409)
                visited.add(parent_id)
                parent = self._row(mission["owner_id"], mission["enterprise_id"], parent_id, db)
                previous = json.loads(parent["payload_json"])
                if (previous.get("product") or {}).get("entity_id") != mission["product"]["entity_id"]:
                    raise CoreError("continuation_product_mismatch", "Không thể lấy bản nháp của sản phẩm khác.", 409)
                if market_of(previous) == market_of(mission):
                    ordered.append(parent)
                if market_of(previous) == market_of(mission) and any(a["kind"] == "food_label_workbook" for a in previous["artifacts"]):
                    break
                parent_id = previous.get("continuation_mission_id")
            ordered.extend(row for row in rows if row["id"] not in visited)
            for row in ordered:
                prior = json.loads(row["payload_json"])
                if (prior.get("product") or {}).get("entity_id") != mission["product"]["entity_id"]:
                    continue
                if market_of(prior) != market_of(mission):
                    continue
                artifact = next((a for a in prior["artifacts"] if a["kind"] == "food_label_workbook"), None)
                if artifact:
                    return {**artifact, "mission_id": row["id"], "basis_context": prior["context"]}
        return None

    def publish(self, mission_id, results):
        mission = self.execution_guard(mission_id)
        answers, actions, artifacts = [], [], []
        values = context_values(mission["context"])
        code = market_of(mission)
        market = get_market(code)
        language = LANGUAGE_NAMES[market["label_language"]]
        for outcome in mission["intent"]["outcomes"]:
            oid = outcome["id"]
            if oid == "registration":
                records = results["registration-research"]["records"]
                needed = ("facility_activity", "facility_type") if code == "US" else ("facility_activity", "facility_type", "responsible_business")
                field_names = {"facility_activity": "hoạt động cơ sở", "facility_type": "loại hình cơ sở", "responsible_business": f"đơn vị nhập khẩu/chịu trách nhiệm tại {market['name_vi']}"}
                missing = [key for key in needed if not values.get(key)]
                if missing:
                    names = [field_names[key] for key in missing]
                    missing_names = ", ".join(names[:-1]) + " và " + names[-1] if len(names) > 1 else names[0]
                    condition = f"Chưa thể kết luận cho doanh nghiệp vì thiếu {missing_names}."
                    action_title = f"Bổ sung {missing_names}"
                else:
                    condition = f"Đã ghi nhận cơ sở do doanh nghiệp khai: {values['facility_activity']}; {values['facility_type']}. Cần rà ngoại lệ trước khi kết luận áp dụng riêng."
                    action_title = "Rà ngoại lệ theo cơ sở đã khai báo"
                general = {
                    "US": "Theo trích đoạn FDA đã lưu, cơ sở sản xuất/chế biến, đóng gói hoặc lưu giữ thực phẩm tiêu thụ tại Mỹ thường thuộc diện đăng ký, trừ ngoại lệ.",
                    "DE": "Theo trích đoạn EU/Đức đã lưu, thực phẩm nhập khẩu phải đáp ứng yêu cầu luật thực phẩm liên quan; doanh nghiệp trong chuỗi cần bảo đảm truy xuất và làm rõ đơn vị chịu trách nhiệm.",
                    "JP": "Theo trích đoạn MHLW đã lưu, nhập khẩu thực phẩm để bán hoặc dùng trong kinh doanh tại Nhật thuộc luồng thông báo nhập khẩu; cần làm rõ nhà nhập khẩu và phạm vi kiểm tra của trạm kiểm dịch.",
                }[code]
                details = {
                    "US": "Quy tắc tham chiếu bao gồm cơ sở trong và ngoài Hoa Kỳ. Cần đối chiếu ngoại lệ và dữ kiện của đúng cơ sở. Đăng ký cơ sở không phải chứng nhận hay phê duyệt sản phẩm.",
                    "DE": "Đức là nước EU được chọn cho hồ sơ này. Cần đối chiếu nhóm hàng, chủ thể trong EU, đăng ký cơ sở thuộc phạm vi của chủ thể đó và các ngoại lệ; không suy ra một giấy phép chung cho mọi thực phẩm hay mọi quốc gia EU.",
                    "JP": "Cần đối chiếu nhà nhập khẩu, mục đích lô hàng, thành phần và quy trình; thông báo nhập khẩu không tự chứng minh sản phẩm đã được phê duyệt hoặc miễn kiểm tra. Chưa xác định hồ sơ chi tiết và thời hạn riêng cho lô Trà Sen.",
                }[code]
                answers.append({"outcome_id": oid, "title": outcome["title"], "status": "answered_general" if records else "blocked_source",
                    "text": f"{general} {condition}" if records else f"Chưa có nguồn phù hợp cho {market['name_vi']} còn được phép dùng lại; không lấy quy định thị trường khác thay thế.",
                    "details_vi": details + " Trích đoạn và bản dịch là tài liệu tham khảo chưa được chuyên gia duyệt, không xác nhận toàn bộ nghĩa vụ hiện hành.",
                    "source_ids": [r["id"] for r in records], "missing_fields": missing})
                actions.append({"id": "supply-facility", "title": action_title, "kind": "supply_facts" if missing else "review_sources", "outcome_ids": [oid], "status": "suggested", "reason": "Để xem xét phạm vi áp dụng riêng, không chỉ quy tắc chung."})
            elif oid == "label":
                records = results["label-research"]["records"]
                draft = results["label-workbook"]["data"]
                artifact = self._artifact(new_id("label"), 1, draft)
                artifacts.append(artifact)
                answers.append({"outcome_id": oid, "title": outcome["title"], "status": "artifact_ready",
                    "text": f"Đã tạo khung nhãn {language} cho {market['name_vi']} bên dưới, kèm hướng dẫn tiếng Việt. Ô chưa xác nhận được để trống; dữ kiện sản phẩm dùng chung được giữ nguyên, chưa tự dịch hoặc xác nhận phù hợp thị trường. Đây là bản nháp chưa được duyệt để in.",
                    "details_vi": f"Các ô cần rà gồm tên thực phẩm {language}, lượng tịnh và đơn vị, thành phần thực tế, tên/địa chỉ/vai trò đơn vị chịu trách nhiệm tại {market['name_vi']}, thông tin dinh dưỡng và dị nguyên. Đây là khung làm việc, chưa xác nhận danh sách đầy đủ hoặc áp dụng riêng cho sản phẩm; không sao chép nhãn của thị trường khác.",
                    "source_ids": [r["id"] for r in records], "missing_fields": [f["id"] for f in draft["fields"] if f["value"] is None]})
                actions.append({"id": "edit-label", "title": f"Điền và lưu khung nhãn {language}", "kind": "edit_label", "outcome_ids": [oid], "status": "suggested", "reason": f"Giữ nguyên ô chưa xác nhận; nhãn được lưu riêng cho {market['name_vi']} trong doanh nghiệp."})
            elif oid == "prior_notice" and code == "US":
                records = results.get("prior_notice-research", {}).get("records", [])
                answers.append({"outcome_id": oid, "title": outcome["title"],
                    "status": "answered_general" if records else "blocked_source",
                    "text": "Đã có trích đoạn FDA về thông báo trước lô hàng. Cần đối chiếu người nộp, hình thức vận chuyển và thời điểm đến trước khi lập lịch nộp riêng cho lô Trà Sen." if records else "Chưa có trích đoạn FDA được phép dùng để trả lời thông báo trước của lô hàng này.",
                    "details_vi": "\n\n".join(r["excerpt_vi"] for r in records) if records else "Chưa kết luận người nộp hoặc thời hạn; không dùng nguồn đăng ký cơ sở thay thế.",
                    "source_ids": [r["id"] for r in records], "missing_fields": []})
                actions.append({"id": "review-prior-notice", "title": "Đối chiếu người nộp và lịch đến của lô hàng",
                                "kind": "review_sources", "outcome_ids": [oid], "status": "suggested",
                                "reason": "Áp dụng đúng thời hạn theo phương thức vận chuyển và thông tin của lô hàng."})
            else:
                answers.append({"outcome_id": oid, "title": outcome["title"], "status": "blocked_source", "text": f"Gói tri thức {market['name_vi']} trong 0.3B hiện chưa đủ căn cứ cho ý này. Kết quả về thủ tục hoặc nhãn không thay cho câu trả lời; chưa có kết luận riêng cho sản phẩm.", "source_ids": [], "missing_fields": []})
        answers, actions, artifacts = self._compose_publication(mission, answers, actions, artifacts)
        mission.update(answers=answers, actions=actions, artifacts=artifacts, updated_at=now_iso())
        with self.repo.connection(write=True) as db:
            self._row(mission["owner_id"], mission["enterprise_id"], mission_id, db)
            current = db.execute("SELECT status FROM v03_missions WHERE id=?", (mission_id,)).fetchone()
            if current["status"] != "running":
                raise CoreError("context_changed", "Kết quả cần đối chiếu lại.", 409)
            self.repo._entity(mission["owner_id"], mission["enterprise_id"], mission["product"]["entity_id"], db)
            for ref in mission["context"]["fact_refs"]:
                current_fact = db.execute("SELECT version,assertion_id FROM v03_current_facts WHERE enterprise_id=? AND entity_id=? AND field=?", (mission["enterprise_id"], ref["entity_id"], ref["field"])).fetchone()
                valid = (current_fact is None and ref["version"] == 0) or (current_fact is not None and current_fact["version"] == ref["version"] and current_fact["assertion_id"] == ref["assertion_id"])
                if not valid:
                    raise CoreError("context_changed", "Dữ kiện đã thay đổi trước khi lưu kết quả.", 409)
            if not readiness_snapshot_valid(mission, db):
                raise CoreError("context_changed", "Nguồn kiểm tra phụ thuộc đã thay đổi trước khi lưu kết quả.", 409)
            for ref in mission_source_dependencies(mission):
                source = db.execute("SELECT version,content_sha256,freshness_state FROM v03_domain_sources WHERE id=?", (ref["source_id"],)).fetchone()
                if not source or source["version"] != ref["version"] or source["content_sha256"] != ref["content_sha256"] or source["freshness_state"] not in {"recorded_snapshot", "reviewed_current"}:
                    raise CoreError("context_changed", "Nguồn đã thay đổi trước khi lưu kết quả.", 409)
            # The write lock serializes publication against fact/source invalidation.
            for artifact in artifacts:
                self._insert_artifact(db, mission, artifact)
            db.execute("UPDATE v03_missions SET status='completed_partial',payload_json=?,updated_at=? WHERE id=? AND status='running'", (json_text(mission), now_iso(), mission_id))

    @staticmethod
    def _artifact(artifact_id, version, data):
        for field in data.get("fields", []):
            if field.get("id") == "net_quantity" and field.get("value") is not None:
                require_valid_field("net_quantity", field["value"])
        data = LabelWorkbook.model_validate(data).model_dump()
        conflicts = [{"field": f["id"], **f["conflict"]} for f in data["fields"] if f.get("conflict")]
        status = "needs_review" if conflicts or data["source_review_required"] else "needs_input" if any(f["value"] is None for f in data["fields"]) else "ready_for_review"
        return {"id": artifact_id, "kind": "food_label_workbook", "version": version, "status": status,
                "conflicts": conflicts, **data, **render_label_document(data), "content_hash": digest(data)}

    @staticmethod
    def _insert_artifact(db, mission, artifact):
        db.execute("INSERT INTO v03_artifact_revisions VALUES(?,?,?,?,?,?,?,?)", (artifact["id"], mission["id"], mission["enterprise_id"], artifact["version"], json_text(artifact), mission["owner_id"], artifact["content_hash"], now_iso()))

    def get(self, account_id, enterprise_id, mission_id):
        with self.repo.connection() as db:
            row = self._row(account_id, enterprise_id, mission_id, db)
            value = json.loads(row["payload_json"])
            product = value.get("product")
            profile = value.get("market_profile")
            if product:
                self.repo._entity(account_id, enterprise_id, product["entity_id"], db)
            if profile:
                self.repo._entity(account_id, enterprise_id, profile["entity_id"], db)
            value.update(status=row["status"], version=row["version"], stale_reason=row["stale_reason"], updated_at=row["updated_at"])
            states = {r["task_id"]: r["state"] for r in db.execute("SELECT task_id,state FROM v03_task_attempts WHERE mission_id=?", (mission_id,))}
            for task in value["plan"]["tasks"]:
                task["status"] = states[task["id"]]
        checked = self.repo.validate_context(account_id, enterprise_id, value["context"]["fact_refs"], mission_source_dependencies(value))
        with self.repo.connection() as source_db:
            readiness_current = readiness_snapshot_valid(value, source_db)
        if (not checked["valid"] or not readiness_current or not self._facility_binding_valid(account_id, enterprise_id, value["context"])) and value["status"] in ("planned", "queued", "running", "completed", "completed_partial"):
            value["status"] = "needs_revalidation"
            value["stale_reason"] = value["stale_reason"] or "Dữ kiện hoặc nguồn của bản này đã đổi; kết quả giữ theo phiên bản cũ và cần rà lại."
        if product:
            current = self._context(account_id, enterprise_id, product["entity_id"], profile["entity_id"] if profile else None, include_archived=True) if "market" in value else self.repo.get_context(account_id, enterprise_id, [product["entity_id"]], fields=list(RELEVANT_FIELDS), include_archived=True)
            entity = current["entities"][0]
            value["product"] = {**product, "snapshot_version": product.get("snapshot_version", product["version"]),
                                "snapshot_name": product.get("snapshot_name", product["name"]),
                                "name": entity["name"], "version": entity["version"],
                                "lifecycle_state": entity.get("lifecycle_state", "active"), "archived": entity.get("archived", False)}
            if entity.get("archived"):
                value["status"] = "needs_revalidation"
                value["stale_reason"] = "Sản phẩm đã lưu trữ; kết quả cũ được giữ, khôi phục trước khi dùng cho lượt AI mới."
            value["current_context"] = current
            if profile:
                market_entity = current["entities"][1]
                value["market_profile"] = {**profile, "snapshot_version": profile.get("snapshot_version", profile["version"]),
                    "version": market_entity["version"], "values": market_entity["values"], "facts": market_entity["facts"]}
            source_stale = any(r["kind"] == "source" for r in checked["reasons"])
            decorated = []
            for artifact in value["artifacts"]:
                if artifact["kind"] != "food_label_workbook":
                    decorated.append(artifact)
                    continue
                data = reconcile({k: artifact[k] for k in LabelWorkbook.model_fields if k in artifact}, value["context"], current)
                data["source_review_required"] = source_stale or data.get("source_review_required", False)
                conflicts = [{"field": f["id"], **f["conflict"]} for f in data["fields"] if f.get("conflict")]
                decorated.append({**artifact, **data, "conflicts": conflicts,
                                  "status": "needs_review" if conflicts or source_stale else artifact["status"]})
            value["artifacts"] = decorated
        return self._public(value)

    @staticmethod
    def _public(value):
        value.pop("owner_id", None)
        value["needs_revalidation"] = value["status"] == "needs_revalidation"
        value["outcomes"] = [{**a, "id": a["outcome_id"], "answer": a["text"]} for a in value["answers"]]
        value["label"] = next((a for a in value["artifacts"] if a["kind"] == "food_label_workbook"), None)
        if value["label"]:
            value["label"] = {**value["label"], "fields": [{**f, "key": f["id"], "hint": f["help_vi"]} for f in value["label"]["fields"]]}
            issues = [{**issue, "saved_value": field["value"]} for field in value["label"]["fields"]
                      if field["id"] == "net_quantity" and field.get("value") is not None and (issue := validate_field_value("net_quantity", field["value"]))]
            value["label"].update(validation_issues=issues, can_export_document=not issues)
        if value.get("market") is None and market_of(value):
            value["market"] = get_market(market_of(value))
        value["sources"] = [{**r, "excerpt_original": r["excerpt"], "excerpt_en": r["excerpt"] if r.get("original_language", "en") == "en" else None, "checked_at": r.get("accessed_at")} for r in value["knowledge"]["records"]]
        value["plan"]["steps"] = value["plan"]["tasks"]
        value["plan"]["summary"] = " → ".join(o["title"] for o in value["intent"]["outcomes"])
        value["context_version"] = value["context"].get("context_revision")
        value["reused_fact_count"] = value["context"].get("reused_fact_count", 0)
        value["knowledge"]["reused_count"] = value["knowledge"].get("metrics", {}).get("reuse_hits", 0)
        return value

    def list(self, account_id, enterprise_id):
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            ids = [r["id"] for r in db.execute("SELECT id FROM v03_missions WHERE enterprise_id=? AND owner_id=? ORDER BY created_at DESC LIMIT 100", (enterprise_id, account_id))]
        visible = []
        for item in ids:
            try:
                visible.append(self.get(account_id, enterprise_id, item))
            except CoreError as exc:
                if exc.status_code not in (403, 404):
                    raise
        return visible

    def update_label(self, account_id, enterprise_id, mission_id, artifact_id, fields, expected_version, operation_id):
        if not isinstance(fields, dict) or not fields or any(k not in DEPENDENCIES for k in fields):
            raise CoreError("invalid_fields", "Chỉ sửa các trường có trong khung nhãn.")
        if any(v is not None and (not isinstance(v, str) or len(v) > 2000) for v in fields.values()):
            raise CoreError("invalid_fields", "Giá trị nhãn phải là chữ, tối đa 2.000 ký tự mỗi ô.")
        request = {"mission_id": mission_id, "artifact_id": artifact_id, "fields": fields, "expected_version": expected_version}
        with self.repo.connection(write=True) as db:
            row = self._row(account_id, enterprise_id, mission_id, db)
            old = self._operation(db, account_id, enterprise_id, "update_label", operation_id, request)
            mission = json.loads(row["payload_json"])
            if market_of(mission) in {"DE", "JP"} and "ingredients" in fields:
                raise CoreError("shared_formula_edit_required", "Thành phần gốc chỉ đọc trong khung nhãn. Hãy sửa công thức ở dữ kiện sản phẩm dùng chung; cách ghi nhãn được lưu riêng theo thị trường.", 409)
            self.repo._entity(account_id, enterprise_id, mission["product"]["entity_id"], db)
            if not old:
                artifact = next((a for a in mission["artifacts"] if a["id"] == artifact_id), None)
                if not artifact:
                    raise CoreError("not_found", "Không tìm thấy khung nhãn.", 404)
                if artifact["version"] != expected_version:
                    raise CoreError("version_conflict", "Khung nhãn đã đổi ở nơi khác. Tải lại trước khi lưu.", 409)
                data = {k: artifact[k] for k in LabelWorkbook.model_fields if k in artifact}
                if any(key not in {field["id"] for field in data["fields"]} for key in fields):
                    raise CoreError("invalid_fields", "Chỉ sửa các trường có trong khung nhãn của thị trường này.")
                for field in data["fields"]:
                    if field["id"] in fields:
                        field["value"] = fields[field["id"]].strip() or None if fields[field["id"]] is not None else None
                        field["state"] = "self_declared" if field["value"] is not None else next(f[4] for f in field_specs(market_of(mission)) if f[0] == field["id"])
                revised = self._artifact(artifact_id, artifact["version"] + 1, data)
                mission["artifacts"] = [revised if a["id"] == artifact_id else a for a in mission["artifacts"]]
                for answer in mission["answers"]:
                    if answer["outcome_id"] == "label":
                        answer["missing_fields"] = [f["id"] for f in revised["fields"] if f["value"] is None]
                self._insert_artifact(db, mission, revised)
                db.execute("UPDATE v03_missions SET payload_json=?,version=version+1,updated_at=? WHERE id=?", (json_text(mission), now_iso(), mission_id))
                self._remember(db, account_id, enterprise_id, "update_label", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)

    def update_facts(self, account_id, enterprise_id, mission_id, facts, expected_version, operation_id, expected_market_profile_version=None):
        mission = self.get(account_id, enterprise_id, mission_id)
        if not mission["product"]:
            raise CoreError("missing_product", "Chưa chọn sản phẩm.")
        if not isinstance(facts, list) or any(not isinstance(item, dict) for item in facts):
            raise CoreError("invalid_facts", "Cần danh sách dữ kiện có tên trường và giá trị.")
        for item in facts:
            if item.get("value") is not None and not item.get("explicit_clear"):
                require_valid_field(item.get("field"), item["value"])
        aliases = {"product_name": "name", "net_weight": "net_quantity", **LABEL_FACT_ALIASES}
        facts = [{**item, "field": aliases.get(item.get("field"), item.get("field"))} for item in facts]
        if any(item.get("field") == "target_market" for item in facts):
            raise CoreError("market_selection_required", "Thị trường thuộc từng hồ sơ nghiên cứu. Hãy nêu thị trường trong chat, không thay một thị trường chung của sản phẩm.")
        if market_of(mission) != "US" and any(item.get("field") == "fda_registration_status" for item in facts):
            raise CoreError("invalid_market_field", "Tình trạng đăng ký FDA chỉ thuộc hồ sơ thị trường Mỹ; chưa lưu thay đổi.")
        scoped = [item for item in facts if item.get("field") in MARKET_FIELDS]
        facility_facts = [item for item in facts if item.get("field") in FACILITY_FIELDS]
        shared = [item for item in facts if item.get("field") not in MARKET_FIELDS | FACILITY_FIELDS]
        profile = mission.get("market_profile")
        if scoped and not profile:
            raise CoreError("market_selection_required", "Cần xác nhận thị trường trước khi lưu dữ kiện riêng của thị trường.")
        if scoped and (not isinstance(expected_market_profile_version, int) or isinstance(expected_market_profile_version, bool) or expected_market_profile_version < 0):
            raise CoreError("expected_market_version_required", "Cần phiên bản hồ sơ thị trường hiện đang sửa.", 409)
        request = {"mission_id": mission_id, "facts": facts, "expected_version": expected_version,
                   "expected_market_profile_version": expected_market_profile_version}
        with self.repo.connection(write=True) as db:
            self._row(account_id, enterprise_id, mission_id, db)
            old = self._operation(db, account_id, enterprise_id, "update_facts", operation_id, request)
            if not old:
                entity = self.repo._entity(account_id, enterprise_id, mission["product"]["entity_id"], db)
                if not isinstance(expected_version, int) or isinstance(expected_version, bool) or entity["version"] != expected_version:
                    raise CoreError("version_conflict", "Hồ sơ sản phẩm vừa thay đổi. Chưa lưu gì; hãy xem bản mới trước khi lưu.", 409)
                if scoped:
                    market_entity = self.repo._entity(account_id, enterprise_id, profile["entity_id"], db)
                    if market_entity["version"] != expected_market_profile_version:
                        raise CoreError("version_conflict", "Hồ sơ thị trường vừa thay đổi. Chưa lưu gì; hãy xem bản mới trước khi lưu.", 409)
                if shared:
                    self.repo.propose_or_apply_facts(account_id, enterprise_id, entity["id"], shared, expected_version, f"shared:{operation_id}", db=db)
                if facility_facts:
                    normalized = [fact for item in facility_facts if (fact := self.repo._normalize_fact(item)) is not None]
                    facility = self._linked_facility(account_id, enterprise_id, entity["id"], db)
                    if normalized and facility is None:
                        # Creation is only reachable from this explicit owner
                        # confirmation, never GET, prepare, source refresh or AI.
                        facility_id, stamp = new_id("entity"), now_iso()
                        name = next((fact["value"] for fact in normalized if fact["field"] == "facility_name" and
                                     fact["value_state"] == "known" and isinstance(fact["value"], str)), None)
                        db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) "
                                   "VALUES(?,?,'facility',?,?,?,?)", (facility_id, enterprise_id,
                                   (name or "Cơ sở · " + entity["name"])[:250], entity["id"], account_id, stamp))
                        self.repo._remember_name(db, facility_id, name or "Cơ sở · " + entity["name"])
                        self.repo._advance_revision(db, enterprise_id, account_id, [{"entity_id": facility_id, "field": "__created__"}])
                        facility = self.repo._entity(account_id, enterprise_id, facility_id, db)
                        self.repo._touch_facility_product(db, enterprise_id, account_id, facility, binding_changed=True)
                    if normalized:
                        declarations = [{**item, "source": {**(item.get("source") or {"kind": "user_statement"}),
                                         "scope": "facility", "product_entity_id": entity["id"],
                                         "confirmation_operation_id": operation_id}} for item in normalized]
                        self.repo.propose_or_apply_facts(account_id, enterprise_id, facility["id"], declarations,
                                                        facility["version"], f"facility:{operation_id}", db=db)
                if scoped:
                    declarations = [{**item, "source": {**(item.get("source") or {"kind": "user_statement"}), "market_code": market_of(mission), "scope": "market_profile"}} for item in scoped]
                    self.repo.propose_or_apply_facts(account_id, enterprise_id, profile["entity_id"], declarations, expected_market_profile_version, f"market:{operation_id}", db=db)
                self._remember(db, account_id, enterprise_id, "update_facts", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)

    def update_label_progress(self, account_id, enterprise_id, mission_id, artifact_id, fields,
                              remember_fields, expected_artifact_version, expected_entity_version,
                              operation_id, conflict_choices=None, expected_market_profile_version=None):
        """One explicit user save: draft revision and chosen self-declared facts."""
        allowed = set(DEPENDENCIES)
        if not isinstance(fields, dict) or any(k not in allowed for k in fields):
            raise CoreError("invalid_fields", "Chỉ sửa các trường có trong khung nhãn.")
        if any(v is not None and (not isinstance(v, str) or len(v) > 2000) for v in fields.values()):
            raise CoreError("invalid_fields", "Mỗi ô nhãn là chữ, tối đa 2.000 ký tự.")
        if not isinstance(remember_fields, list) or any(not isinstance(k, str) or k not in allowed for k in remember_fields) or len(set(remember_fields)) != len(remember_fields):
            raise CoreError("invalid_memory_selection", "Chọn rõ từng ô cần ghi nhớ, không chọn trùng.")
        choices = {} if conflict_choices is None else conflict_choices
        if not isinstance(choices, dict) or any(k not in allowed or v not in {"draft", "ssot", "edited"} for k, v in choices.items()):
            raise CoreError("invalid_conflict_choice", "Chọn giữ bản nháp, dùng hồ sơ hoặc tự sửa cho từng ô mâu thuẫn.")
        for version, minimum in ((expected_artifact_version, 1), (expected_entity_version, 0)):
            if not isinstance(version, int) or isinstance(version, bool) or version < minimum:
                raise CoreError("expected_version_required", "Cần phiên bản nhãn và hồ sơ hiện đang sửa.", 409)
        request = {"mission_id": mission_id, "artifact_id": artifact_id, "fields": fields,
                   "remember_fields": remember_fields, "expected_artifact_version": expected_artifact_version,
                   "expected_entity_version": expected_entity_version, "conflict_choices": choices}
        if expected_market_profile_version is not None:
            request["expected_market_profile_version"] = expected_market_profile_version
        with self.repo.connection(write=True) as db:
            row = self._row(account_id, enterprise_id, mission_id, db)
            mission = json.loads(row["payload_json"])
            if market_of(mission) in {"DE", "JP"} and "ingredients" in (set(fields) | set(remember_fields) | set(choices)):
                raise CoreError("shared_formula_edit_required", "Không ghi cách diễn đạt trên nhãn đè lên công thức gốc. Sửa cách ghi thành phần trong ô riêng của thị trường; sửa công thức qua dữ kiện sản phẩm dùng chung.", 409)
            entity = self.repo._entity(account_id, enterprise_id, mission["product"]["entity_id"], db)
            profile = mission.get("market_profile")
            market_entity = self.repo._entity(account_id, enterprise_id, profile["entity_id"], db) if profile else None
            old = self._operation(db, account_id, enterprise_id, "update_label_progress", operation_id, request)
            if not old:
                artifact = next((a for a in mission["artifacts"] if a["id"] == artifact_id), None)
                if not artifact:
                    raise CoreError("not_found", "Không tìm thấy khung nhãn trong hội thoại này.", 404)
                if artifact["version"] != expected_artifact_version or entity["version"] != expected_entity_version:
                    raise CoreError("version_conflict", "Nhãn hoặc hồ sơ vừa thay đổi ở nơi khác. Chưa lưu gì; xem bản mới trước khi lưu.", 409)
                scoped_keys = [key for key in remember_fields if key in MARKET_LABEL_FIELDS]
                if scoped_keys and (not isinstance(expected_market_profile_version, int) or isinstance(expected_market_profile_version, bool) or expected_market_profile_version < 0 or not market_entity):
                    raise CoreError("expected_market_version_required", "Cần xác nhận thị trường và phiên bản hồ sơ thị trường trước khi ghi nhớ ô riêng của thị trường.", 409)
                if expected_market_profile_version is not None and (not market_entity or market_entity["version"] != expected_market_profile_version):
                    raise CoreError("version_conflict", "Hồ sơ thị trường vừa thay đổi. Chưa lưu gì; hãy xem bản mới trước khi lưu.", 409)
                current = self._context(account_id, enterprise_id, entity["id"], profile["entity_id"] if profile else None, db=db) if "market" in mission else self.repo.get_context(account_id, enterprise_id, [entity["id"]], fields=list(RELEVANT_FIELDS), db=db)
                data = reconcile({k: artifact[k] for k in LabelWorkbook.model_fields if k in artifact}, mission["context"], current)
                if (set(fields) | set(remember_fields) | set(choices)) - {field["id"] for field in data["fields"]}:
                    raise CoreError("invalid_fields", "Chỉ sửa các trường có trong khung nhãn của thị trường này.")
                touched = set(fields) | set(remember_fields) | set(choices)
                for field in data["fields"]:
                    key = field["id"]
                    conflict = field.get("conflict")
                    if conflict and key in touched and key not in choices:
                        raise CoreError("label_conflict_requires_choice", "Bản nháp khác hồ sơ đã lưu. Chọn giữ bản nháp, dùng hồ sơ hoặc tự sửa trước khi lưu ô đó.", 409)
                    if key in choices:
                        choice = choices[key]
                        if choice == "edited" and key not in fields:
                            raise CoreError("invalid_conflict_choice", "Cần nhập giá trị mới cho ô đã chọn tự sửa.")
                        if conflict and choice in {"draft", "ssot"}:
                            value = conflict["draft_value" if choice == "draft" else "ssot_value"]
                        else:
                            value = fields.get(key, field["value"])
                    elif key in fields:
                        choice, value = "edited", fields[key]
                    else:
                        continue
                    field.update(value=value.strip() or None if isinstance(value, str) else value,
                                 conflict=None, choice=choice, basis_refs=basis(current, DEPENDENCIES[key]),
                                 provenance={"kind": "user_draft", "actor_id": account_id, "verification_state": "self_declared"})
                    field["state"] = "self_declared" if field["value"] is not None else next(f[4] for f in field_specs(market_of(mission)) if f[0] == key)
                by_key = {f["id"]: f for f in data["fields"]}
                if any(by_key[key]["value"] is None for key in remember_fields):
                    raise CoreError("empty_memory_selection", "Ô trống chỉ lưu trong bản nháp; không tự xóa dữ kiện doanh nghiệp đã biết.", 409)
                if remember_fields:
                    declarations = [{"field": LABEL_FACT_ALIASES.get(key, key), "value": by_key[key]["value"], "source": {
                        "kind": "user_selected_draft", "mission_id": mission_id, "artifact_id": artifact_id,
                        "artifact_version": artifact["version"] + 1, "field": key,
                        "quote": by_key[key]["value"], "selection": "remember_fields",
                        "verification_state": "self_declared"}} for key in remember_fields]
                    shared_declarations = [item for item in declarations if item["field"] not in MARKET_FIELDS]
                    scoped_declarations = [{**item, "source": {**item["source"], "market_code": market_of(mission), "scope": "market_profile"}} for item in declarations if item["field"] in MARKET_FIELDS]
                    if shared_declarations:
                        self.repo.propose_or_apply_facts(account_id, enterprise_id, entity["id"], shared_declarations,
                            expected_entity_version, f"label-memory-shared:{operation_id}",
                            reason="Chủ tài khoản chọn ghi nhớ dữ kiện sản phẩm dùng chung; chưa xác minh bên ngoài.", db=db)
                    if scoped_declarations:
                        self.repo.propose_or_apply_facts(account_id, enterprise_id, profile["entity_id"], scoped_declarations,
                            expected_market_profile_version, f"label-memory-market:{operation_id}",
                            reason="Chủ tài khoản chọn ghi nhớ dữ kiện riêng của thị trường; chưa xác minh bên ngoài.", db=db)
                    after = self._context(account_id, enterprise_id, entity["id"], profile["entity_id"] if profile else None, db=db)
                    for key in remember_fields:
                        by_key[key]["basis_refs"] = basis(after, DEPENDENCIES[key])
                        by_key[key]["provenance"] = {"kind": "user_selected_draft", "verification_state": "self_declared"}
                revised = self._artifact(artifact_id, artifact["version"] + 1, data)
                mission["artifacts"] = [revised if a["id"] == artifact_id else a for a in mission["artifacts"]]
                mission["draft_save"] = {"remembered_fields": remember_fields, "artifact_version": revised["version"], "verification_state": "self_declared"}
                for answer in mission["answers"]:
                    if answer["outcome_id"] == "label":
                        answer["missing_fields"] = [f["id"] for f in revised["fields"] if f["value"] is None]
                self._insert_artifact(db, mission, revised)
                db.execute("UPDATE v03_missions SET payload_json=?,version=version+1,updated_at=? WHERE id=?", (json_text(mission), now_iso(), mission_id))
                self._remember(db, account_id, enterprise_id, "update_label_progress", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)
