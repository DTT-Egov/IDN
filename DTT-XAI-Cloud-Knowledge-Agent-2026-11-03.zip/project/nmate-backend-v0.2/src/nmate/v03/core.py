"""Enterprise-owned, versioned facts with explicit provenance and private ACLs."""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import heapq
import json
from pathlib import Path
import re
import sqlite3
import uuid

from .field_scope import ENTITY_ALIASES, ENTITY_TYPES, canonical_entity_type, field_is_in_scope, scope_contract, scope_issue
from .domain_validation import product_identity_key, require_valid_field, validate_field_value
from .field_registry import FactActionError, classify_fact_action


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix):
    return f"{prefix}_{uuid.uuid4().hex}"


def json_text(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _instant(value):
    parsed = datetime.fromisoformat(value)
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)


def _fact_freshness(valid_from, valid_to):
    current = datetime.now(timezone.utc)
    if valid_to and _instant(valid_to) <= current:
        return "expired"
    if valid_from and _instant(valid_from) > current:
        return "not_yet_effective"
    return "self_declared"


def require_valid_entity_name(name, entity_type=None):
    """One bounded name contract for every public/private entity writer."""
    noun = {"product": "Tên sản phẩm", "enterprise": "Tên doanh nghiệp"}.get(
        canonical_entity_type(entity_type), "Tên hồ sơ")
    if not isinstance(name, str) or not name.strip() or len(name) > 250:
        raise CoreError("invalid_name", f"{noun} cần có từ 1 đến 250 ký tự.")


def causal_fact_rows(rows):
    """Order owner resolutions by their assertion chain, never random IDs.

    Timestamps sort independent ready events only. A successor cannot precede
    its recorded predecessor even when the clock has the same microsecond.
    This is a read projection; no assertion, timestamp or receipt is rewritten.
    """
    records = [dict(row) for row in rows]
    by_id = {row["id"]: row for row in records}
    if len(by_id) != len(records):
        raise CoreError("fact_history_invalid", "Lịch sử dữ kiện có liên kết trùng; chưa dựng được ngữ cảnh tin cậy.", 409)
    children, degree, ready = {}, {}, []

    def order_key(row):
        stamp = row.get("resolution_at", row.get("decision_at", row["recorded_at"]))
        return _instant(stamp), row["id"]

    for row in records:
        previous = row.get("previous_assertion_id")
        degree[row["id"]] = int(bool(previous))
        if previous:
            parent = by_id.get(previous)
            if parent is None or any(parent.get(key) != row.get(key) for key in ("enterprise_id", "entity_id", "field")):
                raise CoreError("fact_history_invalid", "Lịch sử dữ kiện thiếu hoặc sai liên kết trước đó; chưa dựng được ngữ cảnh tin cậy.", 409)
            children.setdefault(previous, []).append(row["id"])
        else:
            heapq.heappush(ready, (*order_key(row), row))
    result = []
    while ready:
        _stamp, _id, row = heapq.heappop(ready)
        result.append(row)
        for child_id in children.get(row["id"], []):
            degree[child_id] -= 1
            if degree[child_id] == 0:
                child = by_id[child_id]
                heapq.heappush(ready, (*order_key(child), child))
    if len(result) != len(records):
        raise CoreError("fact_history_invalid", "Lịch sử dữ kiện có vòng liên kết; chưa dựng được ngữ cảnh tin cậy.", 409)
    return result


class CoreError(ValueError):
    def __init__(self, code, message, status_code=400):
        super().__init__(message)
        self.code = code
        self.status_code = status_code


SCHEMA = """
CREATE TABLE IF NOT EXISTS v03_accounts (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS v03_enterprises (
 id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL DEFAULT 'local-v03', name TEXT NOT NULL,
 context_revision INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v03_memberships (
 account_id TEXT NOT NULL REFERENCES v03_accounts(id),
 enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 role TEXT NOT NULL DEFAULT 'owner', active INTEGER NOT NULL DEFAULT 1,
 PRIMARY KEY(account_id,enterprise_id));
CREATE TABLE IF NOT EXISTS v03_sessions (
 token_hash TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES v03_accounts(id),
 csrf_hash TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v03_entities (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 entity_type TEXT NOT NULL, name TEXT NOT NULL, parent_entity_id TEXT REFERENCES v03_entities(id),
 version INTEGER NOT NULL DEFAULT 0, created_by TEXT NOT NULL REFERENCES v03_accounts(id),
 created_at TEXT NOT NULL, acl TEXT NOT NULL DEFAULT 'private_owner');
CREATE TABLE IF NOT EXISTS v03_fact_assertions (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 entity_id TEXT NOT NULL REFERENCES v03_entities(id), field TEXT NOT NULL, value_json TEXT,
 value_type TEXT NOT NULL, value_state TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 source_json TEXT NOT NULL, certainty TEXT NOT NULL DEFAULT 'self_declared',
 valid_from TEXT, valid_to TEXT, recorded_at TEXT NOT NULL, explicit_clear INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS v03_fact_resolutions (
 id TEXT PRIMARY KEY, enterprise_id TEXT NOT NULL, entity_id TEXT NOT NULL,
 field TEXT NOT NULL, assertion_id TEXT NOT NULL REFERENCES v03_fact_assertions(id),
 previous_assertion_id TEXT, actor_id TEXT NOT NULL, action TEXT NOT NULL,
 policy_version TEXT NOT NULL DEFAULT 'owner-explicit-v1', reason TEXT, recorded_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS v03_current_facts (
 enterprise_id TEXT NOT NULL, entity_id TEXT NOT NULL REFERENCES v03_entities(id), field TEXT NOT NULL,
 assertion_id TEXT NOT NULL REFERENCES v03_fact_assertions(id),
 resolution_id TEXT NOT NULL REFERENCES v03_fact_resolutions(id), version INTEGER NOT NULL,
 PRIMARY KEY(enterprise_id,entity_id,field));
CREATE TABLE IF NOT EXISTS v03_context_revisions (
 enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id), revision INTEGER NOT NULL,
 actor_id TEXT NOT NULL, changed_fields_json TEXT NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,revision));
CREATE TABLE IF NOT EXISTS v03_operations (
 enterprise_id TEXT NOT NULL, account_id TEXT NOT NULL, kind TEXT NOT NULL,
 operation_id TEXT NOT NULL, request_hash TEXT NOT NULL, response_json TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,account_id,kind,operation_id));
CREATE INDEX IF NOT EXISTS v03_assertions_entity ON v03_fact_assertions(enterprise_id,entity_id,field);
CREATE INDEX IF NOT EXISTS v03_entity_enterprise ON v03_entities(enterprise_id);
CREATE UNIQUE INDEX IF NOT EXISTS v03_entities_enterprise_id ON v03_entities(enterprise_id,id);
CREATE TABLE IF NOT EXISTS v03_entity_names (
 entity_id TEXT NOT NULL REFERENCES v03_entities(id), name_key TEXT NOT NULL,
 name TEXT NOT NULL, PRIMARY KEY(entity_id,name_key));
CREATE TABLE IF NOT EXISTS v03_entity_lifecycle (
 entity_id TEXT PRIMARY KEY REFERENCES v03_entities(id), enterprise_id TEXT NOT NULL REFERENCES v03_enterprises(id),
 state TEXT NOT NULL CHECK(state IN ('active','archived')), revision INTEGER NOT NULL CHECK(revision>0),
 changed_at TEXT NOT NULL, changed_by TEXT NOT NULL REFERENCES v03_accounts(id), reason TEXT,
 FOREIGN KEY(enterprise_id,entity_id) REFERENCES v03_entities(enterprise_id,id),
 FOREIGN KEY(changed_by,enterprise_id) REFERENCES v03_memberships(account_id,enterprise_id));
CREATE TABLE IF NOT EXISTS v03_entity_lifecycle_events (
 id TEXT PRIMARY KEY, entity_id TEXT NOT NULL REFERENCES v03_entities(id), enterprise_id TEXT NOT NULL,
 state TEXT NOT NULL CHECK(state IN ('active','archived')), entity_version INTEGER NOT NULL CHECK(entity_version>=0),
 lifecycle_revision INTEGER NOT NULL CHECK(lifecycle_revision>0), actor_id TEXT NOT NULL, reason TEXT, recorded_at TEXT NOT NULL,
 FOREIGN KEY(enterprise_id,entity_id) REFERENCES v03_entities(enterprise_id,id),
 FOREIGN KEY(actor_id,enterprise_id) REFERENCES v03_memberships(account_id,enterprise_id));
"""


class CoreRepository:
    def __init__(self, db_path):
        from nmate.core_v1.runtime_schema import is_managed_runtime
        self.managed_runtime = is_managed_runtime()
        self.db_path = str(db_path)
        self._memory_anchor = None
        self._uri = self.db_path == ":memory:"
        if self._uri:
            self.db_path = f"file:v03_{uuid.uuid4().hex}?mode=memory&cache=shared"
            self._memory_anchor = self._connect()
        else:
            Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with self.connection(write=True) as db:
            db.executescript(SCHEMA)

    def migrate_name_aliases(self):
        """Explicit legacy repair; never called by construction or read paths."""
        with self.connection(write=True) as db:
            before = db.execute("SELECT COUNT(*) FROM v03_entity_names").fetchone()[0]
            for row in db.execute("SELECT id,name FROM v03_entities").fetchall():
                self._remember_name(db, row["id"], row["name"])
            for row in db.execute("SELECT entity_id,value_json FROM v03_fact_assertions WHERE field='name' AND value_state='known'").fetchall():
                name = json.loads(row["value_json"])
                if isinstance(name, str) and name.strip():
                    self._remember_name(db, row["entity_id"], name)
            # Restore an edited document name only when the original observation,
            # owner decision and canonical assertion agree. This explicit repair
            # never treats arbitrary source metadata as an alias declaration.
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='v04_intakes'").fetchone():
                rows = db.execute("SELECT a.*,e.created_by FROM v03_fact_assertions a "
                    "JOIN v03_entities e ON e.id=a.entity_id AND e.enterprise_id=a.enterprise_id "
                    "JOIN v03_fact_resolutions r ON r.assertion_id=a.id AND r.entity_id=a.entity_id "
                    "AND r.enterprise_id=a.enterprise_id AND r.actor_id=a.actor_id "
                    "WHERE a.field='name' AND a.value_state='known' AND a.actor_id=e.created_by").fetchall()
                for row in rows:
                    source = json.loads(row["source_json"])
                    original = source.get("original_value")
                    if not (source.get("owner_confirmed") is True and source.get("owner_edited") is True
                            and isinstance(original, str) and original.strip() and source.get("candidate_id")
                            and source.get("intake_id")
                            and product_identity_key(original) == product_identity_key(json.loads(row["value_json"]))):
                        continue
                    stored = db.execute("SELECT payload_json FROM v04_intakes WHERE id=? AND enterprise_id=? AND owner_id=?",
                        (source["intake_id"], row["enterprise_id"], row["actor_id"])).fetchone()
                    if not stored:
                        continue
                    candidate = next((c for c in json.loads(stored[0]).get("candidates", [])
                                      if c.get("id") == source["candidate_id"]), None)
                    if (candidate and candidate.get("field") == "name" and candidate.get("entity_id") == row["entity_id"]
                            and candidate.get("status") == "confirmed" and candidate.get("value") == original
                            and candidate.get("confirmed_value") == json.loads(row["value_json"])):
                        self._remember_name(db, row["entity_id"], original)
            return {"aliases_added": db.execute("SELECT COUNT(*) FROM v03_entity_names").fetchone()[0] - before}

    def _connect(self):
        db = sqlite3.connect(self.db_path, timeout=15, uri=self._uri)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA busy_timeout=15000")
        return db

    @contextmanager
    def connection(self, write=False):
        db = self._connect()
        try:
            db.execute("BEGIN IMMEDIATE" if write else "BEGIN")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    @contextmanager
    def _fact_transaction(self, db=None):
        if db is not None:
            yield db
        else:
            with self.connection(write=True) as connection:
                yield connection

    @contextmanager
    def _context_transaction(self, db=None):
        if db is not None:
            yield db
        else:
            with self.connection() as connection:
                yield connection

    @staticmethod
    def _remember_name(db, entity_id, name):
        db.execute("INSERT OR IGNORE INTO v03_entity_names VALUES(?,?,?)", (entity_id, name.strip().casefold(), name))

    def get_membership(self, account_id, enterprise_id, db=None):
        if db is None:
            with self.connection() as conn:
                return self.get_membership(account_id, enterprise_id, conn)
        row = db.execute(
            "SELECT m.*,e.name enterprise_name FROM v03_memberships m "
            "JOIN v03_accounts a ON a.id=m.account_id JOIN v03_enterprises e ON e.id=m.enterprise_id "
            "WHERE m.account_id=? AND m.enterprise_id=? AND m.active=1 AND a.active=1",
            (account_id, enterprise_id),
        ).fetchone()
        if row is None:
            raise CoreError("forbidden", "Không có quyền truy cập doanh nghiệp này.", 403)
        # 0.3A intentionally has no team-sharing path. A membership alone does not
        # elevate a non-owner into the private-owner resource policy.
        if row["role"] != "owner":
            raise CoreError("forbidden", "Thông tin hiện chỉ dành cho chủ tài khoản.", 403)
        return dict(row)

    def _entity(self, account_id, enterprise_id, entity_id, db):
        self.get_membership(account_id, enterprise_id, db)
        row = db.execute(
            "SELECT * FROM v03_entities WHERE id=? AND enterprise_id=?",
            (entity_id, enterprise_id),
        ).fetchone()
        if row is None:
            raise CoreError("not_found", "Không tìm thấy thông tin trong doanh nghiệp này.", 404)
        if row["acl"] != "private_owner" or row["created_by"] != account_id:
            raise CoreError("forbidden", "Không có quyền truy cập thông tin này.", 403)
        result = dict(row)
        result.update(self.entity_lifecycle(db, enterprise_id, entity_id))
        result.update(self.name_projection(db, enterprise_id, result))
        if (result.get("name_validation") or {}).get("display_only"):
            result["can_select_for_ai"] = False
        return result

    @staticmethod
    def name_projection(db, enterprise_id, entity):
        """Read a current identity label without reviving or repairing history.

        An invalid selected name cannot fall back to an older assertion as a
        fact. A valid row label can remain visible for repair only. There is no
        write, alias update, truncation, conversion or time-order guessing.
        """
        row_name = entity.get("name")
        row_invalid = validate_field_value("name", row_name) is not None
        name = db.execute("SELECT a.value_json,a.value_state,a.valid_from,a.valid_to FROM v03_current_facts c "
                          "JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                          "WHERE c.enterprise_id=? AND c.entity_id=? AND c.field='name'",
                          (enterprise_id, entity["id"])).fetchone()
        effective = name and name["value_state"] == "known" and _fact_freshness(name["valid_from"], name["valid_to"]) == "self_declared"
        current_invalid = False
        if effective:
            value = json.loads(name["value_json"])
            current_invalid = validate_field_value("name", value) is not None
            if not current_invalid:
                result = {"name": value}
                if row_invalid:
                    result["name_validation"] = {"code": "invalid_name", "display_only": False,
                        "display_source": "current_assertion", "invalid_sources": ["entity_label"],
                        "message_vi": "Tên lưu trong metadata cũ không hợp lệ; đang dùng tên hiện hành đã xác nhận. Lịch sử giữ nguyên."}
                return result
        if not row_invalid and not current_invalid:
            return {"name": row_name}
        return {"name": "Hồ sơ cần sửa tên" if row_invalid else row_name,
                "name_validation": {"code": "invalid_name", "display_only": True,
                    "display_source": "placeholder" if row_invalid else "entity_label_for_repair",
                    "invalid_sources": (["entity_label"] if row_invalid else []) + (["current_assertion"] if current_invalid else []),
                    "message_vi": "Tên hồ sơ hiện hành không hợp lệ. Tên đang hiển thị chỉ để đối chiếu; cần xác nhận tên đúng trước khi dùng hồ sơ cho AI."}}

    @staticmethod
    def require_usable_ai_identity(entity):
        """AI eligibility is separate from READ, lifecycle and repair WRITE."""
        if (entity.get("name_validation") or {}).get("display_only"):
            raise CoreError("invalid_name", "Tên hồ sơ hiện hành không hợp lệ. Chị sửa và xác nhận tên trước khi dùng hồ sơ cho AI; chưa gửi Claude.", 409)

    @staticmethod
    def entity_lifecycle(db, enterprise_id, entity_id):
        row = db.execute("SELECT * FROM v03_entity_lifecycle WHERE entity_id=? AND enterprise_id=?", (entity_id, enterprise_id)).fetchone()
        archived = bool(row and row["state"] == "archived")
        parent = db.execute("SELECT l.state FROM v03_entities e JOIN v03_entity_lifecycle l ON l.entity_id=e.parent_entity_id "
                            "WHERE e.id=? AND e.enterprise_id=?", (entity_id, enterprise_id)).fetchone()
        return {"lifecycle_state": "archived" if archived else "active", "archived": archived,
                "can_select_for_ai": not archived and not (parent and parent["state"] == "archived"), "lifecycle_revision": row["revision"] if row else 0,
                "lifecycle_changed_at": row["changed_at"] if row else None}

    def require_active_entity(self, account_id, enterprise_id, entity_id, db):
        entity = self._entity(account_id, enterprise_id, entity_id, db)
        parent_archived = entity.get("parent_entity_id") and self.entity_lifecycle(db, enterprise_id, entity["parent_entity_id"])["archived"]
        if entity["archived"] or parent_archived:
            raise CoreError("entity_archived", "Hồ sơ này đã lưu trữ. Khôi phục hồ sơ trước khi sửa hoặc dùng cho một lượt AI mới.", 409)
        return entity

    @staticmethod
    def _check_product_name(db, enterprise_id, name, exclude_entity_id=None):
        key = product_identity_key(name)
        for row in db.execute("SELECT e.id,e.name,l.state,a.value_json,a.value_state,a.valid_from,a.valid_to FROM v03_entities e "
                              "LEFT JOIN v03_entity_lifecycle l ON l.entity_id=e.id "
                              "LEFT JOIN v03_current_facts c ON c.entity_id=e.id AND c.field='name' "
                              "LEFT JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                              "WHERE e.enterprise_id=? AND e.entity_type='product'", (enterprise_id,)):
            current_name = row["name"]
            if row["value_state"] == "known" and _fact_freshness(row["valid_from"], row["valid_to"]) == "self_declared":
                value = json.loads(row["value_json"])
                if isinstance(value, str) and value.strip():
                    current_name = value
            if row["id"] != exclude_entity_id and row["state"] != "archived" and product_identity_key(current_name) == key:
                raise CoreError("product_name_exists", "Đã có sản phẩm cùng tên trong doanh nghiệp. Chọn hồ sơ hiện có hoặc dùng một tên sản phẩm khác; không tự gộp hồ sơ.", 409)

    @staticmethod
    def _operation(db, account_id, enterprise_id, kind, operation_id, request):
        if not isinstance(operation_id, str) or not operation_id.strip() or len(operation_id) > 200:
            raise CoreError("invalid_operation", "Cần mã thao tác hợp lệ.")
        request_hash = hashlib.sha256(json_text(request).encode()).hexdigest()
        row = db.execute(
            "SELECT request_hash,response_json FROM v03_operations WHERE enterprise_id=? "
            "AND account_id=? AND kind=? AND operation_id=?",
            (enterprise_id, account_id, kind, operation_id),
        ).fetchone()
        if row:
            if row["request_hash"] != request_hash:
                raise CoreError("idempotency_conflict", "Mã thao tác đã dùng cho nội dung khác.", 409)
            return request_hash, json.loads(row["response_json"])
        return request_hash, None

    @staticmethod
    def _save_operation(db, account_id, enterprise_id, kind, operation_id, request_hash, response):
        db.execute("INSERT INTO v03_operations VALUES (?,?,?,?,?,?)", (
            enterprise_id, account_id, kind, operation_id, request_hash, json_text(response)))

    def _advance_revision(self, db, enterprise_id, account_id, fields):
        db.execute("UPDATE v03_enterprises SET context_revision=context_revision+1 WHERE id=?", (enterprise_id,))
        revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
        db.execute("INSERT INTO v03_context_revisions VALUES (?,?,?,?,?)", (
            enterprise_id, revision, account_id, json_text(fields), now_iso()))
        return revision

    def _touch_facility_product(self, db, enterprise_id, account_id, entity, *, binding_changed=False):
        """Advance the legacy aggregate CAS token, never invent product facts.

        An explicitly linked facility is part of the product dossier read by
        legacy mission editors. Their expected_version must detect a facility
        edit even though all facility assertions remain on the facility entity.
        """
        if canonical_entity_type(entity["entity_type"]) != "facility" or not entity.get("parent_entity_id"):
            return None
        parent = self._entity(account_id, enterprise_id, entity["parent_entity_id"], db)
        if parent["entity_type"] != "product":
            return None
        db.execute("UPDATE v03_entities SET version=version+1 WHERE id=? AND enterprise_id=?", (parent["id"], enterprise_id))
        revision = self._advance_revision(db, enterprise_id, account_id, [{
            "entity_id": parent["id"], "field": "__facility_context__", "facility_entity_id": entity["id"],
            "change_kind": "explicit_facility_binding" if binding_changed else "facility_fact_change"}])
        if binding_changed:
            self.invalidate_dependencies(db, enterprise_id, "facility_binding", parent["id"],
                                         "Doanh nghiệp đã xác nhận cơ sở liên quan; cần rà theo dữ kiện cơ sở.")
        return revision

    def create_entity(self, account_id, enterprise_id, entity_type, name, parent_entity_id=None, operation_id=None):
        if canonical_entity_type(entity_type) not in ENTITY_TYPES:
            raise CoreError("invalid_entity_type", "Loại thông tin chưa được hỗ trợ.")
        require_valid_entity_name(name, entity_type)
        request = [entity_type, name, parent_entity_id]
        with self.connection(write=True) as db:
            self.get_membership(account_id, enterprise_id, db)
            if operation_id:
                request_hash, previous = self._operation(db, account_id, enterprise_id, "create_entity", operation_id, request)
                if previous:
                    self._entity(account_id, enterprise_id, previous["id"], db)
                    return previous
            if parent_entity_id:
                self.require_active_entity(account_id, enterprise_id, parent_entity_id, db)
            if canonical_entity_type(entity_type) == "product":
                self._check_product_name(db, enterprise_id, name)
            entity_id = new_id("entity")
            db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,parent_entity_id,created_by,created_at) "
                       "VALUES (?,?,?,?,?,?,?)", (entity_id, enterprise_id, entity_type, name, parent_entity_id, account_id, now_iso()))
            self._remember_name(db, entity_id, name)
            self._advance_revision(db, enterprise_id, account_id, [{"entity_id": entity_id, "field": "__created__"}])
            result = self._entity(account_id, enterprise_id, entity_id, db)
            self._touch_facility_product(db, enterprise_id, account_id, result, binding_changed=True)
            result["entity_id"] = entity_id
            if operation_id:
                self._save_operation(db, account_id, enterprise_id, "create_entity", operation_id, request_hash, result)
            return result

    def get_entity(self, account_id, enterprise_id, entity_id):
        with self.connection() as db:
            result = self._entity(account_id, enterprise_id, entity_id, db)
            result["entity_id"] = result["id"]
            result["facts"] = self._facts(db, enterprise_id, entity_id)
            result.update(self._scope_view(db, enterprise_id, result))
            return result

    def list_entities(self, account_id, enterprise_id, entity_type=None, include_archived=False):
        with self.connection() as db:
            self.get_membership(account_id, enterprise_id, db)
            query = "SELECT * FROM v03_entities WHERE enterprise_id=? AND created_by=? AND acl='private_owner'"
            args = [enterprise_id, account_id]
            if entity_type:
                canonical = canonical_entity_type(entity_type)
                aliases = sorted({canonical, *(alias for alias, target in ENTITY_ALIASES.items() if target == canonical)})
                query += " AND entity_type IN (" + ",".join("?" for _ in aliases) + ")"
                args.extend(aliases)
            result = []
            for row in db.execute(query + " ORDER BY created_at,id", args):
                item = self._entity(account_id, enterprise_id, row["id"], db)
                if item["archived"] and not include_archived:
                    continue
                item["entity_id"] = item["id"]
                item["facts"] = self._facts(db, enterprise_id, item["id"])
                item.update(self._scope_view(db, enterprise_id, item))
                result.append(item)
            return result

    def find_entities_by_name(self, account_id, enterprise_id, name, entity_type="product"):
        if not isinstance(name, str) or not name.strip():
            return []
        candidates = self.list_entities(account_id, enterprise_id, entity_type)
        with self.connection() as db:
            aliases = {r["entity_id"] for r in db.execute("SELECT n.entity_id,n.name_key FROM v03_entity_names n "
                "JOIN v03_entities e ON e.id=n.entity_id WHERE e.enterprise_id=? AND e.created_by=? "
                "AND e.acl='private_owner'", (enterprise_id, account_id)) if product_identity_key(r["name_key"]) == product_identity_key(name)}
        return [e for e in candidates if product_identity_key(e["name"]) == product_identity_key(name) or e["id"] in aliases]

    def archive_entity(self, account_id, enterprise_id, entity_id, expected_version, operation_id, reason=None):
        return self._change_entity_lifecycle(account_id, enterprise_id, entity_id, expected_version, operation_id, "archived", reason)

    def restore_entity(self, account_id, enterprise_id, entity_id, expected_version, operation_id, reason=None):
        return self._change_entity_lifecycle(account_id, enterprise_id, entity_id, expected_version, operation_id, "active", reason)

    def _change_entity_lifecycle(self, account_id, enterprise_id, entity_id, expected_version, operation_id, state, reason):
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 0:
            raise CoreError("expected_version_required", "Cần phiên bản hồ sơ hiện đang xem.", 409)
        if reason is not None and (not isinstance(reason, str) or len(reason) > 500):
            raise CoreError("invalid_reason", "Lý do cần tối đa 500 ký tự.")
        with self.connection(write=True) as db:
            entity = self._entity(account_id, enterprise_id, entity_id, db)
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='core_v1_resources'").fetchone():
                from nmate.core_v1.ssot import CoreSSOTService
                CoreSSOTService(self, initialize=False)._require(db, account_id, enterprise_id, entity_id)
            if entity["entity_type"] != "product":
                raise CoreError("invalid_entity_type", "Thao tác này chỉ dành cho hồ sơ sản phẩm.")
            request_hash, previous = self._operation(db, account_id, enterprise_id, "entity_" + state, operation_id,
                                                     [entity_id, expected_version, reason])
            if previous is not None:
                current = self._entity(account_id, enterprise_id, entity_id, db)
                current.update(entity_id=entity_id, facts=self._facts(db, enterprise_id, entity_id), **self._scope_view(db, enterprise_id, current))
                current["lifecycle_receipt"] = previous["lifecycle_receipt"]
                return current
            if entity["version"] != expected_version:
                raise CoreError("version_conflict", "Hồ sơ đã đổi. Xem bản mới trước khi lưu trữ hoặc khôi phục.", 409)
            if state == "active":
                self._check_product_name(db, enterprise_id, entity["name"], entity_id)
            if entity["lifecycle_state"] != state:
                stamp, revision = now_iso(), entity["lifecycle_revision"] + 1
                db.execute("INSERT INTO v03_entity_lifecycle VALUES(?,?,?,?,?,?,?) ON CONFLICT(entity_id) DO UPDATE SET "
                           "state=excluded.state,revision=excluded.revision,changed_at=excluded.changed_at,changed_by=excluded.changed_by,reason=excluded.reason",
                           (entity_id, enterprise_id, state, revision, stamp, account_id, reason))
                db.execute("UPDATE v03_entities SET version=version+1 WHERE id=? AND enterprise_id=?", (entity_id, enterprise_id))
                db.execute("INSERT INTO v03_entity_lifecycle_events VALUES(?,?,?,?,?,?,?,?,?)",
                           (new_id("lifecycle"), entity_id, enterprise_id, state, expected_version + 1, revision, account_id, reason, stamp))
                self._advance_revision(db, enterprise_id, account_id, [{"entity_id": entity_id, "field": "__lifecycle__", "state": state}])
                # No transcript, fact or assertion is deleted. In-flight plans
                # see a durable context invalidation before any publication.
                for row in db.execute("SELECT DISTINCT field FROM v03_current_facts WHERE entity_id=?", (entity_id,)):
                    self.invalidate_dependencies(db, enterprise_id, "fact", f"{entity_id}:{row['field']}", "Hồ sơ sản phẩm đã đổi trạng thái lưu trữ.")
            result = self._entity(account_id, enterprise_id, entity_id, db)
            result.update(entity_id=entity_id, facts=self._facts(db, enterprise_id, entity_id), **self._scope_view(db, enterprise_id, result))
            result["lifecycle_receipt"] = {"operation_id": operation_id, "state_at_commit": state,
                                           "entity_version_at_commit": result["version"], "lifecycle_revision": result["lifecycle_revision"]}
            self._save_operation(db, account_id, enterprise_id, "entity_" + state, operation_id, request_hash, result)
            return result

    def entity_versions(self, account_id, enterprise_id, entity_id):
        with self.connection() as db:
            entity = self._entity(account_id, enterprise_id, entity_id, db)
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='core_v1_resources'").fetchone():
                from nmate.core_v1.ssot import CoreSSOTService
                access = CoreSSOTService(self, initialize=False)
                access._require(db, account_id, enterprise_id, entity_id)
                for field in db.execute("SELECT DISTINCT field FROM v03_fact_assertions WHERE enterprise_id=? AND entity_id=?", (enterprise_id, entity_id)):
                    access._require(db, account_id, enterprise_id, entity_id, field=field[0])
            events, versions = [], {}
            history_rows = db.execute("SELECT a.*,r.id resolution_id,r.previous_assertion_id,r.action,r.reason,r.recorded_at AS decision_at "
                                  "FROM v03_fact_assertions a JOIN v03_fact_resolutions r ON r.assertion_id=a.id "
                                  "WHERE a.enterprise_id=? AND a.entity_id=?", (enterprise_id, entity_id)).fetchall()
            for row in causal_fact_rows(history_rows):
                previous = db.execute("SELECT value_json FROM v03_fact_assertions WHERE id=? AND enterprise_id=? AND entity_id=?",
                                      (row["previous_assertion_id"], enterprise_id, entity_id)).fetchone()
                versions[row["field"]] = versions.get(row["field"], 0) + 1
                events.append({"event_id": row["resolution_id"], "kind": "fact_" + row["action"], "recorded_at": row["decision_at"],
                    "actor_id": row["actor_id"], "field": row["field"], "from_value": json.loads(previous[0]) if previous else None,
                    "to_value": json.loads(row["value_json"]), "value_state": row["value_state"], "assertion_id": row["id"],
                    "resolution_id": row["resolution_id"], "version": versions[row["field"]], "version_kind": "field_version", "reason": row["reason"]})
            for row in db.execute("SELECT * FROM v03_entity_lifecycle_events WHERE enterprise_id=? AND entity_id=? ORDER BY recorded_at,id", (enterprise_id, entity_id)):
                events.append({"event_id": row["id"], "kind": "product_" + ("archived" if row["state"] == "archived" else "restored"),
                    "recorded_at": row["recorded_at"], "actor_id": row["actor_id"], "field": "__lifecycle__", "from_value": None,
                    "to_value": row["state"], "version": row["entity_version"], "version_kind": "entity_version", "reason": row["reason"],
                    "value_state": "known", "assertion_id": None, "resolution_id": None})
            return {"entity_id": entity_id, "current_version": entity["version"], "lifecycle_state": entity["lifecycle_state"],
                    "events": sorted(events, key=lambda item: (item["recorded_at"], item["version"], item["event_id"]), reverse=True),
                    "current_facts": self._facts(db, enterprise_id, entity_id, include_invalid=True)}

    @staticmethod
    def _normalize_fact(item):
        if not isinstance(item, dict):
            raise CoreError("invalid_fact", "Dữ kiện cần là một bản ghi.")
        field = item.get("field")
        if not isinstance(field, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]{0,99}", field):
            raise CoreError("invalid_field", "Tên trường dữ kiện không hợp lệ.")
        value = item.get("value")
        try:
            action = classify_fact_action(item)
        except FactActionError as exc:
            raise CoreError(exc.code, exc.message_vi) from exc
        state, clear = action.value_state, action.explicit_clear
        if action.action == "noop":
            return None
        if clear:
            value = None
        if field == "name" and state == "known":
            require_valid_entity_name(value)
        if state == "known":
            require_valid_field(field, value)
        inferred = ("null" if value is None else "boolean" if isinstance(value, bool) else
                    "integer" if isinstance(value, int) else "number" if isinstance(value, float) else
                    "string" if isinstance(value, str) else "list" if isinstance(value, list) else
                    "object" if isinstance(value, dict) else None)
        value_type = item.get("value_type", inferred)
        compatible = value_type == inferred or (value_type == "number" and inferred == "integer")
        if value_type == "date" and inferred == "string":
            try:
                datetime.fromisoformat(value)
                compatible = True
            except ValueError:
                pass
        if inferred is None or (value is not None and not compatible):
            raise CoreError("invalid_type", "Giá trị không đúng kiểu dữ kiện đã khai.")
        if value is None:
            value_type = "null"
        try:
            encoded = json_text(value)
        except (ValueError, TypeError) as exc:
            raise CoreError("invalid_value", "Dữ kiện phải là giá trị JSON hữu hạn.") from exc
        if len(encoded.encode()) > 32000:
            raise CoreError("fact_too_large", "Dữ kiện vượt giới hạn lưu trữ.")
        for key in ("valid_from", "valid_to"):
            if item.get(key) is not None:
                try:
                    datetime.fromisoformat(item[key])
                except (ValueError, TypeError) as exc:
                    raise CoreError("invalid_date", "Ngày hiệu lực không hợp lệ.") from exc
        if item.get("valid_from") and item.get("valid_to") and _instant(item["valid_from"]) >= _instant(item["valid_to"]):
            raise CoreError("invalid_date", "Ngày kết thúc phải sau ngày bắt đầu.")
        source = item.get("source") or {"kind": "user_statement", "locator": "explicit_fact_update"}
        if not isinstance(source, dict) or len(json_text(source)) > 4000:
            raise CoreError("invalid_source", "Nguồn dữ kiện không hợp lệ.")
        return {"field": field, "value": value, "value_type": value_type, "value_state": state,
                "explicit_clear": clear, "source": source, "valid_from": item.get("valid_from"),
                "valid_to": item.get("valid_to")}

    def propose_or_apply_facts(self, account_id, enterprise_id, entity_id, facts, expected_version,
                               operation_id, actor=None, reason=None, db=None):
        """The only public fact-write boundary, shared by imports and adapters."""
        from nmate.core_v1.fact_commit import FactCommitService
        return FactCommitService(self).commit(account_id, enterprise_id, entity_id, facts,
            expected_version, operation_id, actor=actor, reason=reason, db=db)

    def _apply_authorized_facts(self, account_id, enterprise_id, entity_id, facts, expected_version,
                                operation_id, actor=None, reason=None, db=None):
        if actor is not None and actor != account_id and actor != {"account_id": account_id}:
            raise CoreError("actor_mismatch", "Không thể ghi thay chủ thể khác.", 403)
        if not isinstance(facts, list) or len(facts) > 100:
            raise CoreError("invalid_facts", "Cần danh sách tối đa 100 dữ kiện.")
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 0:
            raise CoreError("expected_version_required", "Cần phiên bản thông tin hiện đang sửa.", 409)
        request = [entity_id, facts, expected_version, reason]
        with self._fact_transaction(db) as db:
            entity = self._entity(account_id, enterprise_id, entity_id, db)
            request_hash, previous = self._operation(db, account_id, enterprise_id, "facts", operation_id, request)
            if previous is not None:
                return previous
            normalized = [fact for item in facts if (fact := self._normalize_fact(item)) is not None]
            if len({item["field"] for item in normalized}) != len(normalized):
                raise CoreError("duplicate_field", "Mỗi thao tác chỉ sửa một lần cho mỗi trường.")
            self._require_fact_scope(entity, normalized)
            if entity["version"] != expected_version:
                raise CoreError("version_conflict", "Thông tin vừa được thay đổi. Hãy xem bản mới trước khi lưu.", 409)
            if canonical_entity_type(entity["entity_type"]) == "product":
                for item in normalized:
                    if item["field"] == "name" and item["value_state"] == "known":
                        if product_identity_key(item["value"]) != product_identity_key(entity["name"]):
                            self._check_product_name(db, enterprise_id, item["value"], entity_id)
            changed = []
            for item in normalized:
                old = db.execute("SELECT c.*,a.value_json,a.value_type,a.value_state,a.valid_from,a.valid_to "
                                 "FROM v03_current_facts c JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                                 "WHERE c.enterprise_id=? AND c.entity_id=? AND c.field=?",
                                 (enterprise_id, entity_id, item["field"])).fetchone()
                if old and old["value_state"] == "known" and item["value"] is None and not item["explicit_clear"]:
                    raise CoreError("explicit_clear_required", "Cần xác nhận xóa rõ ràng để thay giá trị đã biết bằng trạng thái trống.", 409)
                # Reconfirmation does not change dependency versions. Provenance of
                # a changed declaration is always recorded, never attributed to AI.
                same = old and all(old[k] == v for k, v in {
                    "value_json": json_text(item["value"]), "value_type": item["value_type"],
                    "value_state": item["value_state"], "valid_from": item["valid_from"], "valid_to": item["valid_to"]}.items())
                if same:
                    continue
                assertion_id, resolution_id = new_id("assertion"), new_id("resolution")
                stamp = now_iso()
                db.execute("INSERT INTO v03_fact_assertions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
                    assertion_id, enterprise_id, entity_id, item["field"], json_text(item["value"]),
                    item["value_type"], item["value_state"], account_id, json_text(item["source"]),
                    "self_declared", item["valid_from"], item["valid_to"], stamp, int(item["explicit_clear"])))
                db.execute("INSERT INTO v03_fact_resolutions VALUES (?,?,?,?,?,?,?,?,?,?,?)", (
                    resolution_id, enterprise_id, entity_id, item["field"], assertion_id,
                    old["assertion_id"] if old else None, account_id,
                    "clear" if item["explicit_clear"] else "supersede" if old else "select",
                    "owner-explicit-v1", reason or "Cập nhật rõ ràng từ chủ tài khoản", stamp))
                field_version = old["version"] + 1 if old else 1
                db.execute("INSERT INTO v03_current_facts VALUES (?,?,?,?,?,?) "
                           "ON CONFLICT(enterprise_id,entity_id,field) DO UPDATE SET "
                           "assertion_id=excluded.assertion_id,resolution_id=excluded.resolution_id,version=excluded.version",
                           (enterprise_id, entity_id, item["field"], assertion_id, resolution_id, field_version))
                if item["field"] == "name" and item["value_state"] == "known":
                    self._remember_name(db, entity_id, entity["name"])
                    self._remember_name(db, entity_id, item["value"])
                    # A future/expired declaration is audit data, not the
                    # current identity label. Do not materialize it early.
                    if _fact_freshness(item["valid_from"], item["valid_to"]) == "self_declared":
                        db.execute("UPDATE v03_entities SET name=? WHERE id=?", (item["value"], entity_id))
                changed.append({"entity_id": entity_id, "field": item["field"], "version": field_version})
                self.invalidate_dependencies(db, enterprise_id, "fact", f"{entity_id}:{item['field']}",
                                             "Dữ kiện doanh nghiệp đã thay đổi")
            if changed:
                db.execute("UPDATE v03_entities SET version=version+1 WHERE id=?", (entity_id,))
                revision = self._advance_revision(db, enterprise_id, account_id, changed)
                revision = self._touch_facility_product(db, enterprise_id, account_id, entity) or revision
            else:
                revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
            result = {"entity_id": entity_id, "version": expected_version + bool(changed),
                      "context_revision": revision, "changed_fields": changed,
                      "facts": self._facts(db, enterprise_id, entity_id), "status": "applied"}
            self._save_operation(db, account_id, enterprise_id, "facts", operation_id, request_hash, result)
            return result

    @staticmethod
    def _require_fact_scope(entity, facts):
        invalid = [fact["field"] for fact in facts if not field_is_in_scope(entity["entity_type"], fact["field"])]
        if invalid:
            raise CoreError("invalid_field_scope", "Dữ kiện không thuộc loại hồ sơ đang chọn: " + ", ".join(invalid) +
                            ". Hãy chọn đúng hồ sơ; không tự chuyển giá trị sang hồ sơ khác.")

    @staticmethod
    def _scope_view(db, enterprise_id, entity):
        invalid = [issue for fact in CoreRepository._facts(db, enterprise_id, entity["id"], include_invalid=True)
                   if (issue := scope_issue(entity["entity_type"], fact)) is not None]
        issues = [{**issue, "assertion_id": fact["assertion_id"], "version": fact["version"], "value": fact["value"]}
                  for fact in CoreRepository._facts(db, enterprise_id, entity["id"], include_invalid=True)
                  if fact["value_state"] == "known" and (issue := validate_field_value(fact["field"], fact["value"]))]
        return {"field_scope": scope_contract(entity["entity_type"]), "invalid_facts": invalid, "validation_issues": issues}

    @staticmethod
    def _facts(db, enterprise_id, entity_id, include_invalid=False):
        entity = db.execute("SELECT entity_type FROM v03_entities WHERE enterprise_id=? AND id=?",
                            (enterprise_id, entity_id)).fetchone()
        rows = db.execute("SELECT a.*,c.version,c.resolution_id FROM v03_current_facts c "
                          "JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                          "WHERE c.enterprise_id=? AND c.entity_id=? ORDER BY a.field", (enterprise_id, entity_id))
        result = []
        for row in rows:
            if not include_invalid and (entity is None or not field_is_in_scope(entity["entity_type"], row["field"])):
                continue
            fact = dict(row)
            fact["assertion_id"] = fact.pop("id")
            fact["value"] = json.loads(fact.pop("value_json"))
            fact["source"] = json.loads(fact.pop("source_json"))
            fact["verification_state"] = "self_declared"
            fact["freshness_state"] = _fact_freshness(fact["valid_from"], fact["valid_to"])
            fact["explicit_clear"] = bool(fact["explicit_clear"])
            if not include_invalid and fact["value_state"] == "known" and validate_field_value(fact["field"], fact["value"]):
                continue
            result.append(fact)
        return result

    def get_context(self, account_id, enterprise_id, entity_ids=None, fields=None, db=None, include_archived=False):
        with self._context_transaction(db) as db:
            membership = self.get_membership(account_id, enterprise_id, db)
            explicit_selection = entity_ids is not None
            if entity_ids is None:
                entity_ids = [row[0] for row in db.execute("SELECT id FROM v03_entities WHERE enterprise_id=? "
                              "AND created_by=? AND acl='private_owner'", (enterprise_id, account_id))]
            entities, refs = [], []
            for entity_id in dict.fromkeys(entity_ids):
                entity = self._entity(account_id, enterprise_id, entity_id, db)
                if (entity.get("name_validation") or {}).get("display_only"):
                    if explicit_selection:
                        self.require_usable_ai_identity(entity)
                    continue
                if not entity["can_select_for_ai"] and not include_archived:
                    if explicit_selection:
                        raise CoreError("entity_archived", "Hồ sơ đã lưu trữ; cần khôi phục trước khi dùng ngữ cảnh cho AI.", 409)
                    continue
                facts = [f for f in self._facts(db, enterprise_id, entity_id) if fields is None or f["field"] in fields]
                entity["entity_id"], entity["facts"] = entity_id, facts
                entity["values"] = {f["field"]: f["value"] for f in facts if f["value_state"] == "known" and f["freshness_state"] == "self_declared"}
                entities.append(entity)
                refs.extend({"entity_id": entity_id, "field": f["field"], "version": f["version"],
                             "assertion_id": f["assertion_id"]} for f in facts)
                invalid_current = [f for f in self._facts(db, enterprise_id, entity_id, include_invalid=True)
                                   if field_is_in_scope(entity["entity_type"], f["field"]) and f["value_state"] == "known"
                                   and validate_field_value(f["field"], f["value"]) and (fields is None or f["field"] in fields)]
                refs.extend({"entity_id": entity_id, "field": f["field"], "version": f["version"],
                             "assertion_id": f["assertion_id"], "usage": "excluded_invalid"} for f in invalid_current)
                if fields is not None:
                    present = {f["field"] for f in facts + invalid_current}
                    refs.extend({"entity_id": entity_id, "field": field, "version": 0, "assertion_id": None}
                                for field in fields if field not in present and field_is_in_scope(entity["entity_type"], field))
            revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise_id,)).fetchone()[0]
            fingerprint = hashlib.sha256(json_text(refs).encode()).hexdigest()
            return {"enterprise_id": enterprise_id, "enterprise_name": membership["enterprise_name"],
                    "context_revision": revision, "entities": entities, "fact_refs": refs,
                    "context_hash": fingerprint, "as_of": now_iso(), "verification_state": "self_declared"}

    def get_fact_history(self, account_id, enterprise_id, entity_id, field=None):
        with self.connection() as db:
            self._entity(account_id, enterprise_id, entity_id, db)
            sql = "SELECT a.*,r.action,r.reason,r.previous_assertion_id FROM v03_fact_assertions a " \
                  "JOIN v03_fact_resolutions r ON r.assertion_id=a.id WHERE a.enterprise_id=? AND a.entity_id=?"
            args = [enterprise_id, entity_id]
            if field:
                sql += " AND a.field=?"
                args.append(field)
            result = []
            for row in db.execute(sql + " ORDER BY a.recorded_at,a.id", args):
                item = dict(row)
                item["value"] = json.loads(item.pop("value_json"))
                item["source"] = json.loads(item.pop("source_json"))
                result.append(item)
            return result

    def validate_context(self, account_id, enterprise_id, fact_refs=None, source_refs=None):
        reasons = []
        with self.connection() as db:
            self.get_membership(account_id, enterprise_id, db)
            for ref in fact_refs or []:
                entity = self._entity(account_id, enterprise_id, ref["entity_id"], db)
                if not entity["can_select_for_ai"]:
                    reasons.append({"kind": "fact", "key": f"{ref['entity_id']}:{ref['field']}",
                                    "reason": "invalid_name" if (entity.get("name_validation") or {}).get("display_only") else "entity_archived"})
                    continue
                if not field_is_in_scope(entity["entity_type"], ref["field"]):
                    reasons.append({"kind": "fact", "key": f"{ref['entity_id']}:{ref['field']}",
                                    "reason": "invalid_entity_scope"})
                    continue
                row = db.execute("SELECT c.version,c.assertion_id,a.valid_from,a.valid_to,a.value_json,a.value_state FROM v03_current_facts c "
                                 "JOIN v03_fact_assertions a ON a.id=c.assertion_id "
                                 "WHERE c.enterprise_id=? AND c.entity_id=? AND c.field=?",
                                 (enterprise_id, ref["entity_id"], ref["field"])).fetchone()
                if row is None and ref.get("version") == 0 and ref.get("assertion_id") is None:
                    continue
                if not row or row["version"] != ref.get("version") or (ref.get("assertion_id") and row["assertion_id"] != ref["assertion_id"]):
                    reasons.append({"kind": "fact", "key": f"{ref['entity_id']}:{ref['field']}", "reason": "version_changed"})
                elif row["value_state"] == "known" and validate_field_value(ref["field"], json.loads(row["value_json"])) and ref.get("usage") != "excluded_invalid":
                    reasons.append({"kind": "fact", "key": f"{ref['entity_id']}:{ref['field']}", "reason": "invalid_value"})
                elif _fact_freshness(row["valid_from"], row["valid_to"]) != "self_declared":
                    reasons.append({"kind": "fact", "key": f"{ref['entity_id']}:{ref['field']}",
                                    "reason": _fact_freshness(row["valid_from"], row["valid_to"])})
            if source_refs:
                exists = db.execute("SELECT 1 FROM sqlite_master WHERE name='v03_domain_sources'").fetchone()
                for ref in source_refs:
                    row = db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (ref["source_id"],)).fetchone() if exists else None
                    if not row or row["version"] != ref.get("version") or row["content_sha256"] != ref.get("content_sha256") or row["freshness_state"] not in {"recorded_snapshot", "reviewed_current"}:
                        reasons.append({"kind": "source", "key": ref["source_id"], "reason": "source_changed"})
        return {"valid": not reasons, "reasons": reasons}

    @staticmethod
    def invalidate_dependencies(db, enterprise_id, kind, key, reason):
        tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if {"v03_dependencies", "v03_missions"} <= tables:
            db.execute("UPDATE v03_missions SET status='needs_revalidation',stale_reason=? WHERE enterprise_id=? "
                       "AND id IN (SELECT mission_id FROM v03_dependencies WHERE enterprise_id=? "
                       "AND dependency_kind=? AND dependency_key=?)",
                       (reason, enterprise_id, enterprise_id, kind, key))
