"""Server-owned intent boundaries and pre-dispatch source scope. No model calls."""
import re
import unicodedata

from .evidence import outcome_topic
from .markets import market_title, normalize_text
from .intent_plan import compile_export_plan


_PATTERNS = {
    "label": r"\b(?:nhan|label|labelling|labeling|bao bi)\b",
    "registration": r"\b(?:dang ky|co so|facility|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|food business)\b",
    "prior_notice": r"\b(?:thong bao truoc|prior\s*notice)\b",
    "certification": r"\b(?:chung nhan|chung chi|certification|certificate)\b",
}


def _intent_text(text):
    """Preserve Vietnamese meaning before accent folding for semantic matching."""
    value = unicodedata.normalize("NFC", str(text or "")).casefold()
    value = re.sub(r"\b(?:chứng|chung)\s+(?:nhận|nhan)\b", "certificate", value)

    def distinguish(match):
        word = match.group()
        # "chị cần làm" is an owner's self-reference, whereas "chỉ cần"
        # narrows a request. Folding both to "chi can" erased the preceding
        # FDA/label questions before source lookup and schema construction.
        if word == "chị":
            return "ownerfemale"
        if word == "nhãn":
            return "label"
        if word == "những":
            return "pluralquantifier"
        if word == "nhưng":
            return "contrastconnector"
        if normalize_text(word) == "nhan" and word != "nhan":
            return "nonlabelword"
        return word

    value = normalize_text(re.sub(r"\b\w+\b", distinguish, value))
    # Unaccented "nhan" remains useful for "nhan san pham", but common
    # confirmation/person/receipt phrases do not establish a label request.
    return re.sub(r"\b(?:xac nhan|tiep nhan|chap nhan|ghi nhan|cong nhan|"
                  r"nhan vien|nhan su|nhan luc|nhan hang|nhan duoc|nhan loi|"
                  r"nhan tien|nhan xet|nguyen nhan|ca nhan|benh nhan)\b",
                  "nonlabelword", value)


def quote_supports_outcome(outcome_id, quote, market_code, *, previous_outcomes=()):
    value = _intent_text(quote)
    if outcome_id == "clarification":
        return True
    if outcome_id == "prior_notice" and market_code != "US":
        return False
    pattern = _PATTERNS.get(outcome_id)
    if pattern and re.search(pattern, value):
        return True
    if outcome_id == "registration" and market_code in {"DE", "JP"} and re.search(r"\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\b", value):
        return True
    # Bounded conversational reference, never a generic sentence that can be
    # assigned arbitrarily to three unrelated research tasks.
    return (outcome_id in previous_outcomes and bool(re.search(
        r"\b(?:ngoai le do|noi dung do|viec do|tiep tuc|nghien cuu tiep|sua tiep|ban nhap)\b", value)))


def _clause_boundary_pattern():
    operator = r"(?:(?:gio|bay gio|nay)\s+)?(?:(?:ownerfemale|toi|anh|em|minh)\s+)?(?:khong|chua|can|muon|hoi|tim hieu|nghien cuu|bo qua|loai tru|only|do not|need|want)\b"
    # Unaccented 'nhung' is ambiguous. Treat it as contrast only with an
    # explicit following operator; 'nhung gi' must retain its question marker.
    return (r"[,;.!?\n]|\b(?:contrastconnector|tuy nhien)\b|\bnhung\b(?=\s+" + operator +
            r")|\bma\b(?=\s+" + operator + r")|\b(?:va|and|but)\b(?=\s+" + operator + r")")


def split_intent_clauses(value):
    """One bounded polarity boundary, shared by included/excluded goals.

    A conjunction only starts a new clause when it introduces a new request
    operator. Keep 'không hỏi nhãn và thông báo trước' together; split 'đăng
    ký FDA và không hỏi nhãn', without rewriting the original user quote.
    """
    return [part.strip() for part in re.split(_clause_boundary_pattern(), value) if part.strip()]


def request_clause_rows(value):
    """Keep comma-list adjacency, never carry an operator across a sentence."""
    parts = re.split(r"([,;.!?\n])", value)
    for index in range(0, len(parts), 2):
        clauses = split_intent_clauses(parts[index])
        leading_boundary = bool(re.match(_clause_boundary_pattern(), parts[index].lstrip()))
        for subindex, clause in enumerate(clauses):
            before = "operator" if subindex or leading_boundary else parts[index - 1] if index else ""
            after = parts[index + 1] if index + 1 < len(parts) and subindex == len(clauses) - 1 else ""
            yield clause, before, after


def topic_list_tail(clause, patterns):
    """Only nominal topic items inherit a preceding comma-list operator.

    Facts, quantities, a new subject/verb, a negative operator or a completed
    activity break the list. A final presentation preference is not a topic.
    """
    value = re.sub(r"\b(?:(?:va|kem|cung)\s+)?(?:ba|3)\s+(?:viec|buoc)\b.*$", "", clause)
    if re.match(r"^(?:(?:gio|bay gio|nay)\s+)?(?:(?:ownerfemale|toi|anh|em|minh)\s+)?(?:can|muon|hoi|tim hieu|nghien cuu|bo qua|loai tru|khong|chua)\b", value):
        return False
    if not any(re.search(pattern, value) for pattern in patterns.values()):
        return False
    for pattern in patterns.values():
        value = re.sub(pattern, " ", value)
    modifiers = {"va", "and", "cung", "voi", "ve", "them", "noi", "dung", "yeu", "cau", "quy", "dinh",
                 "thu", "tuc", "cho", "cua", "theo", "lo", "hang", "dau", "tien", "fda", "thuc", "pham",
                 "san", "tieng", "anh", "duc", "nhat", "eu", "can", "thiet", "pluralquantifier", "cac"}
    return set(re.findall(r"\w+", value)) <= modifiers


def negative_request_clauses(value, patterns):
    """Apply the same bounded comma-list grammar to an exclusion operator."""
    active_negative_list = False
    negative_operator = r"\b(?:khong hoi|khong can|khong muon|chua hoi|chua can|chua muon|bo qua|loai tru|do not (?:research|ask|need|want)|exclude)\b"
    for clause, before, _after in request_clause_rows(value):
        direct = re.search(negative_operator, clause)
        inherited = active_negative_list and before == "," and topic_list_tail(clause, patterns)
        negative = clause[direct.start():] if direct else clause if inherited else ""
        positive = clause[:direct.start()] if direct else "" if inherited else clause
        active_negative_list = bool(negative and any(re.search(pattern, negative) for pattern in patterns.values()))
        yield clause, positive, negative


def allowed_intake_outcomes(text, market_code, *, previous_outcomes=()):
    value = _intent_text(text)
    # Explicit focus supersedes historical preamble, e.g. "nhãn đã xong;
    # tôi chỉ hỏi ai nộp thông báo trước". This does not manufacture outcomes.
    focused = re.split(r"\b(?:chi hoi|chi can|chi muon|only ask|only need)\b", value)
    value = focused[-1] if len(focused) > 1 else value
    result = []
    for oid, pattern in _PATTERNS.items():
        if not quote_supports_outcome(oid, value, market_code, previous_outcomes=previous_outcomes):
            continue
        positive = " ; ".join(re.sub(r"\b(?:da xong|da hoan tat)\b.*", "", positive)
                              for _clause, positive, _negative in negative_request_clauses(value, _PATTERNS))
        # Remove resolved clauses with the target before the resolution verb.
        positive = re.sub(pattern + r"[^,;.?!]{0,25}\b(?:da xong|da lam xong|da hoan tat)\b", "", positive)
        if quote_supports_outcome(oid, positive, market_code, previous_outcomes=previous_outcomes):
            result.append(oid)
    return result + ["clarification"]


def explicit_requested_outcomes(text, market_code):
    """Mandatory tasks require an asked clause, not a background keyword.

    The broader allowlist remains useful for candidate interpretation. A
    factory location does not ask for registration; a packaging description
    does not ask for label research. Only this stricter projection can bind
    tasks or constrain a paid response to a mandatory outcome count.
    """
    candidates = set(allowed_intake_outcomes(text, market_code)) - {"clarification"}
    value = _intent_text(text)
    focused = re.split(r"\b(?:chi hoi|chi can|chi muon|only ask|only need)\b", value)
    value = focused[-1]
    anchors = {
        "registration": r"\b(?:dang ky|registration|dieu kien nhap khau|yeu cau nhap khau|thu tuc nhap khau|import requirements|facility registration|food business)\b",
        "label": r"\b(?:nhan|label|labelling|labeling)\b|\bbao bi\b.{0,50}\b(?:ghi|noi dung|thong tin)\b",
        "prior_notice": _PATTERNS["prior_notice"],
        "certification": _PATTERNS["certification"],
    }
    if market_code in {"DE", "JP"}:
        anchors["registration"] += r"|\b(?:thong bao nhap khau|import notification|khai bao nhap khau)\b"
    ask_lead = r"\b(?:hoi|tim hieu|nghien cuu|huong dan|chuan bi|ra soat|kiem tra|tu van|cho biet|giai thich|review|check|what|how|who|when)\b"
    question_form = r"\b(?:co phai|co can|ai|khi nao|bao gio|gi|nao|khong)\b"
    result = set()
    # Keep each delimiter: a question mark belongs to its own clause, never to
    # a preceding descriptive sentence or packaging clause before a comma.
    active_request_list = False
    for clause, before, delimiter in request_clause_rows(value):
        if not clause:
            continue
        original_clause = clause
        lead = re.search(ask_lead, clause)
        lead_prefix = clause[:lead.start()] if lead else ""
        historical_lead = bool(lead and re.search(r"\b(?:da|dang|vua|hien tai)\b", lead_prefix)
                               and not re.search(r"\b(?:gio|bay gio|nay|can|muon|hoi)\b", lead_prefix))
        if lead and not historical_lead and not re.search(question_form, lead_prefix):
            clause = clause[lead.start():]
        possible = set(allowed_intake_outcomes(clause, market_code)) & candidates
        marked = bool(re.search(ask_lead, clause) and not historical_lead or re.search(question_form, clause) or delimiter == "?")
        declarative = bool(re.search(r"\b(?:da|dang(?!\s+ky\b)|hien tai|la|duoc)\b", clause))
        # "Đăng ký ..." can be an imperative. A bare noun such as "nhãn"
        # can equally introduce a factual description, so do not force it.
        current_clause = re.sub(r"^(?:gio|bay gio|nay)\s+", "", clause)
        imperative = bool(re.match(r"^(?:hay\s+)?dang ky\b|^(?:(?:ownerfemale|toi|anh|em|minh)\s+)?(?:can|muon)\s+(?:dang ky|tim hieu|nghien cuu|hoi|ra soat|kiem tra|chuan bi)\b", current_clause)) and not declarative
        negated = bool(re.search(r"\b(?:khong hoi|khong can|khong muon|chua hoi|chua can|chua muon|bo qua|loai tru|exclude|do not)\b", original_clause))
        inherited = ((active_request_list and before == "," or len(focused) > 1 and before == "") and not declarative and not negated
                     and topic_list_tail(original_clause, anchors))
        selected = []
        for oid in possible:
            anchor = anchors.get(oid)
            if not anchor or not re.search(anchor, clause):
                continue
            if marked or imperative or inherited:
                result.add(oid)
                selected.append(oid)
        # A new operator, background fact or non-topic comma item closes the
        # preceding request list. Do not turn a product fact into a research ask.
        active_request_list = bool(selected) and not declarative and not negated
    return [oid for oid in _PATTERNS if oid in result]


def project_research_scope(mission):
    market = (mission.get("market") or {}).get("code")
    coverage = mission.get("knowledge", {}).get("coverage", {})
    supported_topics = set(coverage.get("supported", []))
    supported, blocked = [], []
    for outcome in mission.get("intent", {}).get("outcomes", []):
        oid = outcome["id"]
        title = market_title(oid, market) if market else outcome.get("title", oid)
        item = {"outcome_id": oid, "title": title}
        topic = outcome_topic(oid, market) if market else None
        if topic and topic in supported_topics:
            supported.append(item)
        else:
            blocked.append({**item, "message": "Chưa có đủ trích đoạn nguồn chính thức có thể dùng cho ý này. Lượt nghiên cứu sẽ nêu rõ phần chưa trả lời; không dùng kiến thức riêng của AI thay nguồn."})
    plan = compile_export_plan(mission)
    source_status = "partial" if supported and blocked else "ready" if supported else "blocked"
    # Independent source-ready research may proceed under D07. That is not a
    # promise that every goal/supporting requirement of the whole plan is ready.
    status = "partial" if supported and plan["completeness"]["status"] != "planned" else source_status
    return {"status": status, "source_readiness_status": source_status,
            "supported_outcomes": supported, "blocked_outcomes": blocked,
            "can_start_research": bool(supported),
            "intent_plan": plan,
            "plan_completeness_status": plan["completeness"]["status"],
            "can_start_scope": "independent_supported_requested_outcomes_only",
            "source_policy": "recorded_authority_excerpts_with_explicit_network_checks"}
