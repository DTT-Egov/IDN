"""Explicit, additive installation of the curated US readiness reference pack.

This command is separate from GET, provider calls and constructor seeding.
It never rewrites an old source, paid response, enterprise fact or mission.
Stop the local runtime first: the CLI takes the same database ownership lock.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from .catalog import DomainCatalog
from .core import CoreRepository, json_text


PACK_PATH = Path(__file__).parent / "data" / "us_readiness_20261022.json"


def install_readiness_pack(repo):
    """One atomic, repeatable installation. Caller owns the runtime boundary."""
    pack = json.loads(PACK_PATH.read_text(encoding="utf-8"))
    if not pack.get("pack_id") or pack.get("effective_since") != "2026-10-22":
        raise ValueError("Unexpected readiness pack identity")
    # The catalog may initialize its existing schema/seed packs for a new test
    # database. The readiness expansion itself is never a constructor effect.
    DomainCatalog(repo)
    with repo.connection(write=True) as db:
        before = {table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in (
            "v03_domain_sources", "v03_domain_references", "v03_domain_pack_installations",
            "v03_domain_reference_supersessions")}
        DomainCatalog._install_pack(db, pack)
        after = {table: db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] for table in before}
    return {"pack_id": pack["pack_id"], "content_sha256": hashlib.sha256(json_text(pack).encode()).hexdigest(),
            "inserted_rows": {key: after[key] - before[key] for key in before},
            "historical_sources_unchanged": True, "enterprise_ssot_unchanged": True,
            "paid_calls": 0, "legal_review": "reference_unreviewed"}


def main():
    parser = argparse.ArgumentParser(description="Install curated US readiness references without model calls")
    parser.add_argument("--database", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    if not args.apply:
        parser.error("Use --apply to explicitly install the reference expansion")
    if not args.database.is_file():
        parser.error("Database must already exist")
    from nmate.main.runtime_lock import EnterpriseRuntimeLock
    with EnterpriseRuntimeLock(args.database):
        result = install_readiness_pack(CoreRepository(args.database))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
