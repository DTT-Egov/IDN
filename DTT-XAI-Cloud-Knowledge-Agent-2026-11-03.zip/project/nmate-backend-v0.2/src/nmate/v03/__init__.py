"""Local 0.3A enterprise context and public reference library.

This package has no model-provider or network dependency.
"""

from .core import CoreError, CoreRepository
from .identity import LocalAccounts
from .catalog import DomainCatalog

__all__ = ["CoreError", "CoreRepository", "LocalAccounts", "DomainCatalog"]
