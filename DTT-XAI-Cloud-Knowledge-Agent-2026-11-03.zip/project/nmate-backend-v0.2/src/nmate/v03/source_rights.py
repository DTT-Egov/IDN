"""Qualified public-reference rights shared by retrieval, graph and egress.

This is a necessary public-source classification, never private READ authority
or a legal eligibility approval. Content hashes, excerpt bounds, freshness and
current resource grants remain separate checks at their existing boundaries.
"""
from .core import CoreError

PUBLIC_SOURCE_RIGHTS_VERSION = "public-source-rights/1"
PUBLIC_SOURCE_RIGHTS = frozenset({"public_reference", "official_reference_quotation_not_full_republication",
                                  "us_federal_government_public_reference"})
FEDERAL_AUTHORITY_HOSTS = frozenset({"www.fda.gov", "www.ecfr.gov", "www.govinfo.gov"})


def public_source_permitted(rights, url):
    if not isinstance(rights, str) or rights not in PUBLIC_SOURCE_RIGHTS or not isinstance(url, str):
        return False
    # Reuse the existing HTTPS/port/userinfo/fragment/authority allowlist guard.
    # Import lazily: this policy does not construct a refresher or do I/O.
    from .source_refresh import authority_host
    try:
        host = authority_host(url)
    except (CoreError, ValueError, TypeError):
        return False
    return rights != "us_federal_government_public_reference" or host in FEDERAL_AUTHORITY_HOSTS
