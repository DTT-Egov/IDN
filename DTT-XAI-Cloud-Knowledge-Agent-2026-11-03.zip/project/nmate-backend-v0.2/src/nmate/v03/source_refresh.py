"""One-shot checks of fixed authority URLs; never a model or a legal review.

The packaged excerpt identity remains stable only while the exact original
wording is still present. Whitespace normalization is the sole equivalence.
Fresh network observations are separate from the original saved snapshot.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import re
from xml.etree import ElementTree
from urllib.parse import urljoin, urlsplit

import httpx
from bs4 import BeautifulSoup

from nmate.agents.shipment.sources import SourceRetrievalError, validate_public_dns
from .core import CoreError, json_text, new_id, now_iso
from .markets import get_market
from .authority_hosts import AUTHORITY_HOSTS


ALLOWED_HOSTS = AUTHORITY_HOSTS
SCHEMA = """
CREATE TABLE IF NOT EXISTS v03_authority_network_checks (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES v03_domain_sources(id),
 checked_at TEXT NOT NULL, state TEXT NOT NULL, result_json TEXT NOT NULL,
 text TEXT, text_sha256 TEXT, body_sha256 TEXT);
CREATE INDEX IF NOT EXISTS v03_authority_network_checks_source
 ON v03_authority_network_checks(source_id,checked_at);
"""


def authority_host(url):
    parsed = urlsplit(url)
    try:
        valid_port = parsed.port in (None, 443)
    except ValueError:
        valid_port = False
    host = (parsed.hostname or "").lower()
    if (parsed.scheme != "https" or host not in ALLOWED_HOSTS or not valid_port
            or parsed.username is not None or parsed.password is not None or parsed.fragment):
        raise CoreError("authority_unsafe_url", "Địa chỉ nguồn nằm ngoài danh sách cơ quan chính thức cho phép.")
    return host


def normalized_text(text):
    return re.sub(r"\s+", " ", text).strip()


class AuthoritySourceRefresher:
    def __init__(self, repo, catalog, *, request_fn=None, dns_guard=None,
                 timeout_seconds=12.0, max_bytes=2_000_000, max_redirects=2, total_timeout_seconds=15.0):
        if not 0 < timeout_seconds <= 30 or not 1024 <= max_bytes <= 3_000_000 or not 0 <= max_redirects <= 3:
            raise ValueError("Authority retrieval limits exceed supported bounds")
        self.repo, self.catalog = repo, catalog
        self.request_fn = request_fn
        self.dns_guard = dns_guard or validate_public_dns
        self.timeout_seconds, self.max_bytes, self.max_redirects = timeout_seconds, max_bytes, max_redirects
        if not 0 < total_timeout_seconds <= 15:
            raise ValueError("The complete authority check is limited to 15 seconds")
        self.total_timeout_seconds = total_timeout_seconds
        self._locks = {}
        with repo.connection(write=True) as db:
            db.executescript(SCHEMA)

    async def _request(self, url):
        # A fresh client carries no enterprise cookies, credentials or proxy
        # configuration. HTTP redirects are validated individually below.
        async with httpx.AsyncClient(timeout=self.timeout_seconds, trust_env=False, follow_redirects=False,
                                     headers={"User-Agent": "NMate-Authority-Check/0.4", "Accept-Encoding": "identity"}) as client:
            async with client.stream("GET", url) as response:
                headers = dict(response.headers)
                size = headers.get("content-length", "")
                if size.isdigit() and int(size) > self.max_bytes:
                    raise CoreError("authority_body_limit", "Nguồn vượt giới hạn tải.")
                body = bytearray()
                async for chunk in response.aiter_bytes():
                    body.extend(chunk)
                    if len(body) > self.max_bytes:
                        raise CoreError("authority_body_limit", "Nguồn vượt giới hạn tải.")
                return response.status_code, headers, bytes(body)

    async def _fetch(self, source, request_counter=None):
        url = source["url"]
        async with asyncio.timeout(self.timeout_seconds):
            for hop in range(self.max_redirects + 1):
                host = authority_host(url)
                await self.dns_guard(host)
                if request_counter is not None:
                    request_counter[0] += 1
                status, headers, body = await (self.request_fn or self._request)(url)
                headers = {str(key).lower(): value for key, value in headers.items()}
                if status in (301, 302, 303, 307, 308):
                    location = headers.get("location")
                    if not location or hop == self.max_redirects:
                        raise CoreError("authority_redirect_limit", "Nguồn chuyển hướng quá giới hạn.")
                    url = urljoin(url, location)
                    authority_host(url)
                    continue
                if status != 200:
                    raise CoreError(f"authority_http_{status}", "Cơ quan nguồn chưa trả nội dung có thể đọc.")
                if len(body) > self.max_bytes:
                    raise CoreError("authority_body_limit", "Nguồn vượt giới hạn tải.")
                content_type = headers.get("content-type", "").lower()
                xml = "xml" in content_type and host == "laws.e-gov.go.jp" and urlsplit(url).path.startswith("/api/1/lawdata/")
                if not xml and not any(value in content_type for value in ("text/html", "text/plain", "application/xhtml+xml")):
                    # The backend currently has no PDF text extractor. Never
                    # mark a downloaded PDF as verified without reading it.
                    raise CoreError("authority_unsupported_content", "Định dạng nguồn cần được đọc và rà thủ công.")
                if xml:
                    # Only the official law text; never binary ImageData or
                    # an external entity. Parsing is bounded by the body cap.
                    if b"<!DOCTYPE" in body.upper() or b"<!ENTITY" in body.upper():
                        raise CoreError("authority_unsafe_xml", "Bản XML chứa khai báo ngoài phạm vi đọc an toàn.")
                    try:
                        root = ElementTree.fromstring(body)
                        law = root.find(".//LawFullText")
                        if law is None:
                            raise ValueError("No law text")
                        text = normalized_text(" ".join(law.itertext()))
                    except (ElementTree.ParseError, ValueError):
                        raise CoreError("authority_invalid_xml", "Chưa đọc được văn bản luật gốc từ XML chính thức.") from None
                elif "text/plain" in content_type:
                    text = body.decode("utf-8", errors="strict")
                else:
                    soup = BeautifulSoup(body, "html.parser")
                    title = soup.title.get_text(" ", strip=True).casefold() if soup.title else ""
                    for tag in soup(["script", "style", "noscript", "iframe", "form", "nav", "header", "footer"]):
                        tag.decompose()
                    regions = [soup.find("main") or soup.find("article") or soup.body or soup]
                    if source["id"] == "fda_us_agent":
                        regions.extend(panel for panel in soup.select(".fda-accordion-panel") if regions[0] not in panel.parents)
                    text = "\n".join(region.get_text("\n", strip=True) for region in regions)
                    prefix = normalized_text(text[:1000]).casefold()
                    if (any(marker in title for marker in ("access denied", "just a moment", "request rejected", "captcha"))
                            or any(marker in prefix for marker in ("verify you are human", "enable javascript and cookies", "pardon the interruption"))):
                        raise CoreError("authority_access_challenge", "Trang nguồn đang chặn truy cập tự động; chưa đối chiếu được nội dung.")
                if len(normalized_text(text)) < 50:
                    raise CoreError("authority_empty_content", "Trang nguồn chưa có nội dung đủ để đối chiếu.")
                return {"url": url, "text": text, "text_sha256": hashlib.sha256(text.encode()).hexdigest(),
                        "body_sha256": hashlib.sha256(body).hexdigest()}
        raise CoreError("authority_redirect_limit", "Nguồn chuyển hướng quá giới hạn.")

    async def _fetch_batch(self, sources):
        """Three connections, one attempt per URL, 15 seconds for the batch."""
        semaphore = asyncio.Semaphore(3)
        request_counter = [0]

        async def one(source):
            async with semaphore:
                try:
                    return await self._fetch(source, request_counter)
                except (CoreError, SourceRetrievalError, OSError, httpx.HTTPError, TimeoutError, UnicodeError) as exc:
                    return exc

        unique = {source["url"]: source for source in sources}
        tasks = {url: asyncio.create_task(one(source)) for url, source in unique.items()}
        if not tasks:
            return {}, 0
        try:
            _, pending = await asyncio.wait(tasks.values(), timeout=self.total_timeout_seconds)
            for task in pending:
                task.cancel()
            await asyncio.gather(*pending, return_exceptions=True)
            return ({url: CoreError("authority_batch_timeout", "Đã hết thời gian đọc nguồn; không tự thử lại.")
                     if task.cancelled() else task.result() for url, task in tasks.items()}, request_counter[0])
        finally:
            for task in tasks.values():
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks.values(), return_exceptions=True)

    async def refresh(self, account_id, enterprise_id, market_code, topics):
        market = get_market(market_code)
        lock = self._locks.setdefault(market["code"], asyncio.Lock())
        async with lock:
            self.repo.get_membership(account_id, enterprise_id)
            knowledge = self.catalog.lookup_domain(topics, account_id, enterprise_id, market_code=market["code"])
            source_ids = sorted({record["source_id"] for record in knowledge["records"]})
            results = []
            sources = [self.catalog.get_source(source_id) for source_id in source_ids]
            fetched_by_url, http_requests = await self._fetch_batch(sources)
            for source_id in source_ids:
                source = self.catalog.get_source(source_id)
                with self.repo.connection() as db:
                    # All excerpts attached to a refreshed source must remain
                    # present; a narrow question cannot bless a missing clause.
                    records = [json.loads(row[0]) for row in db.execute(
                        "SELECT record_json FROM v03_domain_references WHERE source_id=?", (source_id,))]
                checked_at = now_iso()
                fetched = None
                try:
                    fetched = fetched_by_url[source["url"]]
                    if isinstance(fetched, Exception):
                        cached_error, fetched = fetched, None
                        raise cached_error
                    text = normalized_text(fetched["text"])
                    missing = [record["id"] for record in records if normalized_text(record["excerpt"]) not in text]
                    state = "excerpt_changed" if missing else "exact_excerpts_present"
                    result = {"source_id": source_id, "title": source["title"], "url": fetched["url"],
                              "checked_at": checked_at, "state": state, "missing_reference_ids": missing,
                              "body_sha256": fetched["body_sha256"], "text_sha256": fetched["text_sha256"]}
                except (CoreError, SourceRetrievalError, OSError, httpx.HTTPError, TimeoutError, UnicodeError) as exc:
                    result = {"source_id": source_id, "title": source["title"], "url": source["url"],
                              "checked_at": checked_at, "state": "unavailable",
                              "error_code": getattr(exc, "code", "authority_unavailable"), "missing_reference_ids": []}
                self.repo.get_membership(account_id, enterprise_id)
                with self.repo.connection(write=True) as db:
                    db.execute("INSERT INTO v03_authority_network_checks VALUES(?,?,?,?,?,?,?,?)",
                               (new_id("netcheck"), source_id, checked_at, result["state"], json_text(result),
                                fetched["text"] if fetched else None, fetched["text_sha256"] if fetched else None,
                                fetched["body_sha256"] if fetched else None))
                    if result["state"] == "excerpt_changed":
                        # Preserve both old and observed source text; invalidate
                        # rather than editing excerpts to fit new legislation.
                        row = db.execute("SELECT freshness_state FROM v03_domain_sources WHERE id=?", (source_id,)).fetchone()
                        if row[0] not in {"revoked", "withdrawn", "needs_revalidation"}:
                            db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation',version=version+1,invalidated_at=? WHERE id=?",
                                       (checked_at, source_id))
                            for enterprise in db.execute("SELECT id FROM v03_enterprises").fetchall():
                                self.repo.invalidate_dependencies(db, enterprise[0], "source", source_id,
                                    "Đối chiếu Internet không còn thấy nguyên văn trích đoạn; cần rà nguồn trước khi dùng lại.")
                results.append(result)
            return {"market_code": market["code"], "network_refresh": True,
                    "policy": "single_attempt_exact_excerpt_presence_no_legal_approval",
                    "sources": results, "network_source_checks": len(results), "source_urls_checked": len(fetched_by_url),
                    "http_requests": http_requests,
                    "note_vi": "Đã thử đọc nguồn chính thức. Chỉ kiểm sự hiện diện của nguyên văn đã lưu; không xác nhận toàn bộ quy định hiện hành. Nguồn không đọc được giữ rõ ngày bản cũ, không coi là vừa kiểm chứng."}

    def latest_checks(self, source_ids):
        with self.repo.connection() as db:
            values = []
            for source_id in sorted(set(source_ids)):
                row = db.execute("SELECT result_json FROM v03_authority_network_checks WHERE source_id=? ORDER BY checked_at DESC,id DESC LIMIT 1", (source_id,)).fetchone()
                if row:
                    values.append(json.loads(row[0]))
            return values
