"""Versioned field/entity bindings for canonical SSOT projections.

This registry changes neither assertions nor owner decisions. Old assertions
outside a registered field's scope remain in audit, but cannot be facts in a
current/context projection. Opaque extension fields retain their existing ACL;
the registry does not invent semantics or make them public.
"""
from __future__ import annotations

from .domain_validation import base_field_key, field_is_financial
from .field_registry import (ENTITY_ALIASES as ENTITY_ALIASES, ENTITY_TYPES as ENTITY_TYPES,
                             FIELD_ENTITY_TYPES as FIELD_ENTITY_TYPES, LABEL_FACT_ALIASES as LABEL_FACT_ALIASES,
                             REGISTRY_VERSION as FIELD_REGISTRY_VERSION,
                             SCOPE_COMPATIBILITY_VERSION as REGISTRY_VERSION)


def canonical_entity_type(entity_type):
    return ENTITY_ALIASES.get(entity_type, entity_type) if isinstance(entity_type, str) else None


def allowed_entity_types(field):
    # Financial observations are stored as e.g. revenue.2025; periods cannot
    # accidentally escape the base field's entity restriction.
    if not isinstance(field, str):
        return frozenset()
    direct = FIELD_ENTITY_TYPES.get(field)
    if direct is not None:
        return direct
    base = base_field_key(field)
    if base in FIELD_ENTITY_TYPES:
        return FIELD_ENTITY_TYPES[base]
    if field_is_financial(field):
        return frozenset({"enterprise", "financial_period"})
    return None


def field_is_in_scope(entity_type, field):
    allowed = allowed_entity_types(field)
    entity_type = canonical_entity_type(entity_type)
    return entity_type in ENTITY_TYPES and (allowed is None or entity_type in allowed)


def scope_issue(entity_type, fact):
    if field_is_in_scope(entity_type, fact["field"]):
        return None
    return {**fact, "scope_state": "invalid_entity_scope",
            "allowed_entity_types": sorted(allowed_entity_types(fact["field"]) or []),
            "message": "Dữ kiện cũ thuộc loại hồ sơ khác; không dùng trong hồ sơ chuẩn hoặc ngữ cảnh AI. "
                       "Lịch sử được giữ nguyên, không tự chuyển giá trị sang hồ sơ khác."}


def scope_contract(entity_type):
    canonical = canonical_entity_type(entity_type)
    return {"registry_version": REGISTRY_VERSION, "field_registry_version": FIELD_REGISTRY_VERSION, "entity_type": canonical,
            "allowed_fields": sorted(field for field, types in FIELD_ENTITY_TYPES.items() if canonical in types),
            "unregistered_fields": "explicit_field_grant_required"}
