"""Run the isolated 0.3B preview, with outbound/provider calls blocked in process."""
import argparse
from pathlib import Path
import socket

import uvicorn


def block_paid_and_external_calls():
    counters = {"provider_attempts_blocked": 0, "external_connections_blocked": 0}
    connect = socket.socket.connect
    connect_ex = socket.socket.connect_ex
    getaddrinfo = socket.getaddrinfo
    allowed = {"127.0.0.1", "localhost", "::1"}

    def check(host):
        if isinstance(host, bytes):
            host = host.decode("ascii", "replace")
        if host not in allowed:
            counters["external_connections_blocked"] += 1
            raise RuntimeError("0.3B giả lập chặn kết nối bên ngoài máy.")

    def guarded_connect(sock, address):
        if sock.family in (socket.AF_INET, socket.AF_INET6):
            check(address[0])
        return connect(sock, address)

    def guarded_connect_ex(sock, address):
        if sock.family in (socket.AF_INET, socket.AF_INET6):
            check(address[0])
        return connect_ex(sock, address)

    def guarded_getaddrinfo(host, *args, **kwargs):
        check(host)
        return getaddrinfo(host, *args, **kwargs)

    def provider_blocked(*args, **kwargs):
        counters["provider_attempts_blocked"] += 1
        raise RuntimeError("0.3B giả lập không cho phép gọi mô hình có phí.")

    # Importing a constructor is free. Patching catches accidental future dispatch.
    import anthropic
    import openai
    import langchain_anthropic
    import langchain_openai
    for module, names in ((anthropic, ("Anthropic", "AsyncAnthropic")),
                          (openai, ("OpenAI", "AsyncOpenAI")),
                          (langchain_anthropic, ("ChatAnthropic",)),
                          (langchain_openai, ("ChatOpenAI",))):
        for name in names:
            setattr(module, name, provider_blocked)
    socket.socket.connect = guarded_connect
    socket.socket.connect_ex = guarded_connect_ex
    socket.getaddrinfo = guarded_getaddrinfo
    return counters


def main():
    parser = argparse.ArgumentParser(description="nMate 0.3B · đa thị trường · giả lập · không gọi AI có phí")
    parser.add_argument("--port", type=int, default=8024)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[3] / ".data-v03a-fake")
    parser.add_argument("--task-delay", type=float, default=.8)
    args = parser.parse_args()
    guards = block_paid_and_external_calls()
    from .app import create_app
    args.data_dir.mkdir(parents=True, exist_ok=True)
    app = create_app(args.data_dir / "enterprise.sqlite3", port=args.port, task_delay=args.task_delay)
    app.state.telemetry.update(guards)

    @app.get("/api/v03/qa-status")
    async def qa_status():
        return {"mode": "bounded_templates_no_paid_calls", "paid_calls": 0,
                **app.state.telemetry, **guards}

    # Routes must precede the terminal MCP mount.
    app.router.routes.insert(-1, app.router.routes.pop())
    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning", access_log=False)


if __name__ == "__main__":
    main()
