"""Bounded goal prerequisites and delivery checks, without model or network calls.

An explicit research answer and a useful market-entry checklist are different
contracts. This read model never invents a user quote for a prerequisite, claims
that a rule applies to a particular facility, or rewrites a saved paid result.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re

from .evidence import record_applicability, evidence_date
from .markets import normalize_text
from .intent_plan import broad_export_goal, assess_recorded_action_briefs


POLICY_VERSION = "us-food-market-entry-readiness/1"
_TITLES = {
    "facility_registration": "Hoạt động cơ sở và đăng ký FDA",
    "food_label": "Nội dung nhãn thực phẩm",
    "prior_notice": "Thông báo trước lô hàng (Prior Notice)",
    "fsvp_importer": "Bên nhập khẩu chịu trách nhiệm FSVP",
    "origin_marking": "Ghi xuất xứ và ngoại lệ dành cho trà",
}
_FACETS = {
    "facility_registration": ("scope", "exceptions", "activity_definitions", "us_agent"),
    "food_label": ("core_fields", "nutrition", "allergens"),
    "prior_notice": ("scope", "submitter", "timing", "exceptions", "international_mail_update"),
    "fsvp_importer": ("importer_definition", "scope_exceptions"),
    "origin_marking": ("general_marking", "tea_exception"),
}
_LEGACY_FACETS = {
    "FDA_REGISTRATION_RULES_VI_20261018_DRAFT": ("scope", "exceptions"),
    "FDA_US_AGENT_VI_20261018_DRAFT": ("us_agent",),
    "FDA_LABEL_CORE_VI_20261018_DRAFT": ("core_fields",),
    "FDA_LABEL_NUTRITION_VI_20261018_DRAFT": ("nutrition",),
    "FDA_ALLERGEN_DECLARATION_VI_20261018_DRAFT": ("allergens",),
    "FDA_PRIOR_NOTICE_SCOPE_VI_20261019_V1": ("scope",),
    "FDA_PRIOR_NOTICE_SUBMITTER_VI_20261019_V1": ("submitter",),
    "FDA_PRIOR_NOTICE_TIMING_VI_20261019_V1": ("timing",),
}
_WHY = {
    "facility_registration": "Cần biết hoạt động và loại hình cơ sở trước khi xét phạm vi đăng ký hoặc ngoại lệ.",
    "food_label": "Cần công thức và nội dung nhãn thực tế trước khi chuẩn bị bản nhãn cho Mỹ.",
    "prior_notice": "Kế hoạch lô hàng cần người phụ trách thông báo và lịch vận chuyển; đăng ký cơ sở không thay thông báo từng lô.",
    "fsvp_importer": "Cần đối chiếu bên nhập khẩu và phạm vi FSVP; đại diện đăng ký cơ sở tại Mỹ không mặc nhiên là bên nhập khẩu FSVP.",
    "origin_marking": "Xuất xứ thực tế và loại sản phẩm cần được đối chiếu với quy tắc ghi xuất xứ, kể cả ngoại lệ có thể liên quan tới trà.",
}


def market_entry_goal(question, market_code):
    """Conservative goal recognition; a label-only question does not grow scope."""
    if market_code != "US":
        return None
    return broad_export_goal(question, market_code)


def read_authority_records(db, market_code="US"):
    """Read installed immutable excerpts; no catalog constructor or metrics write."""
    if market_code != "US":
        return []
    rows = db.execute("SELECT r.record_json,r.review_state,s.id AS page_id,s.url,s.title,s.publisher,"
                      "s.text,s.content_sha256,s.accessed_at,s.version,s.freshness_state "
                      "FROM v03_domain_references r JOIN v03_domain_sources s ON s.id=r.source_id ORDER BY r.id")
    records = []
    as_of = evidence_date().isoformat()
    for row in rows:
        try:
            item = json.loads(row["record_json"])
        except (TypeError, ValueError):
            continue
        if not isinstance(item, dict) or not isinstance(item.get("excerpt"), str):
            continue
        if item.get("introduced_on", "0001-01-01") > as_of:
            continue
        if db.execute("SELECT 1 FROM v03_domain_reference_supersessions WHERE old_reference_id=? AND effective_since<=?", (item.get("id"), as_of)).fetchone():
            continue
        item.update(review_state=row["review_state"], freshness_state=row["freshness_state"],
                    source_id=row["page_id"], source_version=row["version"], url=row["url"],
                    title=item.get("title", row["title"]), publisher=row["publisher"], accessed_at=row["accessed_at"],
                    content_sha256=row["content_sha256"])
        if record_applicability(item, "US") is not None:
            continue
        if hashlib.sha256(item["excerpt"].encode()).hexdigest() != item.get("excerpt_sha256"):
            continue
        def normalized(value):
            return re.sub(r"\s+", " ", value).strip()
        if hashlib.sha256(row["text"].encode()).hexdigest() != row["content_sha256"] or normalized(item["excerpt"]) not in normalized(row["text"]):
            continue
        records.append(item)
    return records


def _citation(record):
    return {"reference_id": record["id"], "source_id": record["source_id"],
            "source_version": record.get("source_version"), "excerpt_sha256": record.get("excerpt_sha256"),
            "content_sha256": record.get("content_sha256"),
            "quote_original": record["excerpt"], "quote_vi": record.get("excerpt_vi", ""),
            "url": record.get("url"), "title_vi": record.get("title_vi", record.get("title", "Nguồn tham chiếu")),
            "conditions_vi": record.get("conditions_vi", ""),
            "section": (record.get("locator") or {}).get("section", ""),
            "readiness_facets": list(record.get("readiness_facets", _LEGACY_FACETS.get(record.get("id"), ()))),
            "accessed_at": record.get("accessed_at"), "review_state": record.get("review_state", "reference_unreviewed")}


def project_goal_readiness(mission, records):
    if (mission.get("intent") or {}).get("scope") != "us_food":
        return None
    goal = market_entry_goal(mission.get("question"), (mission.get("market") or {}).get("code"))
    if goal is None:
        return None
    requested = {item.get("id") for item in (mission.get("intent") or {}).get("outcomes", []) if isinstance(item, dict)}
    tea_product = bool(re.search(r"\b(?:tra|tea)\b", normalize_text((mission.get("product") or {}).get("name", ""))))
    context = mission.get("current_context") or mission.get("context") or {}
    current_values = context.get("values", {}) if isinstance(context, dict) else {}
    current_values = current_values if isinstance(current_values, dict) else {}
    requirements = []
    for key, title in _TITLES.items():
        if key in goal["excluded_requirement_ids"]:
            continue
        relevant = [record for record in records if key in record.get("topics", []) and record_applicability(record, "US") is None]
        if key == "origin_marking" and not tea_product:
            relevant = [record for record in relevant if "tea_exception" not in record.get("readiness_facets", []) or "general_marking" in record.get("readiness_facets", [])]
        required_facets = _FACETS[key] if key != "origin_marking" or tea_product else ("general_marking",)
        if key == "origin_marking" and not tea_product:
            title = "Đối chiếu quy tắc ghi xuất xứ"
        facets = sorted({facet for record in relevant for facet in record.get("readiness_facets", _LEGACY_FACETS.get(record.get("id"), ())) if facet in required_facets})
        missing = [facet for facet in required_facets if facet not in facets]
        summaries = list(dict.fromkeys(str((record.get("excerpt_vi") if key == "prior_notice" and "timing" in record.get("readiness_facets", ()) else record.get("readiness_summary_vi")) or record.get("excerpt_vi") or "").strip()
                                      for record in relevant if record.get("readiness_summary_vi") or record.get("excerpt_vi")))
        answer = "\n\n".join(summary for summary in summaries if summary)
        if not answer:
            answer = "Chưa có đủ trích đoạn tiếng Việt có căn cứ để hướng dẫn nội dung này. Cần bổ sung nguồn chính thức; chưa kết luận nghĩa vụ áp dụng."
        summary_items = [{"facet": facet, "label_vi": {"submitter": "Ai có thể nộp", "timing": "Khi nào phải đối chiếu", "exceptions": "Phạm vi và ngoại lệ"}[facet],
                          "text_vi": (record.get("excerpt_vi") if facet == "timing" else record.get("readiness_summary_vi")) or record.get("excerpt_vi", ""), "reference_ids": [record["id"]]}
                         for record in relevant for facet in record.get("readiness_facets", _LEGACY_FACETS.get(record.get("id"), ()))
                         if key == "prior_notice" and facet in {"submitter", "timing", "exceptions"} and (record.get("readiness_summary_vi") or record.get("excerpt_vi"))]
        requirements.append({"id": key, "origin": "requested" if {"facility_registration": "registration", "food_label": "label", "prior_notice": "prior_notice"}.get(key) in requested else "supporting",
            "title_vi": title, "status": "needs_source" if missing else "reference_available",
            "answer_vi": answer, "why_vi": "Cần đối chiếu xuất xứ thực tế và quy tắc ghi xuất xứ; chưa kết luận từ tên sản phẩm hoặc địa chỉ doanh nghiệp." if key == "origin_marking" and not tea_product else _WHY[key], "applicability": "not_assessed",
            "citations": [_citation(record) for record in relevant],
            "summary_items": summary_items,
            "coverage": {"required_facets": list(required_facets), "available_facets": facets, "missing_facets": missing},
            "limits_vi": "Hướng dẫn từ trích đoạn đã lưu, chưa phải kết luận pháp lý cho cơ sở hoặc lô hàng. " + ("Còn thiếu căn cứ cho một số phần; không coi phần đã có là đủ mọi nghĩa vụ." if missing else "Cần kiểm tra dữ kiện, ngoại lệ và thông tin hiện hành trước khi thực hiện.")})
    by_id = {item["id"]: item for item in requirements}
    actions = []
    specs = [
        ("prepare-facility", ["facility_registration"], "Chủ cơ sở", "Đối chiếu hoạt động, loại hình và địa chỉ cơ sở; bổ sung phần hồ sơ còn thiếu", "Một bản mô tả cơ sở: nơi " + ("sản xuất/ướp trà" if tea_product else "sản xuất/chế biến") + ", đóng gói, lưu kho; tên và địa chỉ; tình trạng đăng ký và đại diện tại Mỹ nếu có. Dùng lại dữ kiện đã xác nhận, chỉ bổ sung hoặc sửa phần cần thiết."),
        ("prepare-label", ["food_label", "origin_marking"], "Chủ cơ sở và người phụ trách sản phẩm", "Lập bản nháp nội dung nhãn từ công thức và bao bì thực tế", "Một bảng nháp ghi công thức thành phần, lượng tịnh, đơn vị chịu trách nhiệm; đánh dấu phần dị nguyên, dinh dưỡng và xuất xứ còn phải đối chiếu, chưa duyệt để in."),
        ("prepare-shipment", ["prior_notice", "fsvp_importer"], "Chủ cơ sở cùng bên nhập khẩu hoặc đơn vị giao nhận", "Chốt đầu mối nhập khẩu và thu thập lịch lô hàng để đối chiếu thông báo trước", "Một bảng phân công: bên nhập khẩu dự kiến, người kiểm tra trách nhiệm FSVP, người dự kiến nộp Prior Notice, phương thức vận chuyển, cảng đến và ngày giờ đến; mục chưa biết ghi rõ chưa xác nhận."),
    ]
    for action_id, keys, owner, title, deliverable in specs:
        available = [by_id[key] for key in keys if key in by_id]
        # Preparatory work is grounded by actual excerpts, never three filler
        # cards merely because the owner asked for a particular number.
        if not available or not any(item["citations"] for item in available):
            continue
        if action_id == "prepare-shipment" and "prior_notice" not in by_id:
            continue
        ui_action = {"prepare-facility": {"kind": "supply_facility_facts", "field_keys": ["facility_activity", "facility_type", "facility_name", "facility_address"]},
                     "prepare-label": {"kind": "edit_label", "field_keys": ["ingredients", "net_quantity", "responsible_business", "nutrition_information", "allergens"]},
                     "prepare-shipment": {"kind": "review_importer_shipping", "requirement_ids": [item["id"] for item in available]}}[action_id]
        field_keys = ui_action.get("field_keys", [])
        reused_keys = [key for key in field_keys if current_values.get(key) not in (None, "")]
        missing_keys = [key for key in field_keys if key not in reused_keys]
        if action_id == "prepare-facility":
            ui_action["field_keys"] = missing_keys
        actions.append({"id": action_id, "priority": len(actions) + 1, "owner_vi": owner,
                        "title_vi": title, "deliverable_vi": deliverable,
                        "ui_action": ui_action,
                        "reused_fact_keys": reused_keys, "missing_fact_keys": missing_keys,
                        "requirement_ids": [item["id"] for item in available],
                        "source_refs": _source_refs(available)})
    return {"schema_version": "goal-readiness/1", "policy_version": POLICY_VERSION,
            "mission_id": mission.get("id"), "market_code": "US",
            "goal": goal, "requirements": requirements, "first_actions": actions,
            "origin": "server_bounded_authority_guidance", "does_not_change_saved_claude": True,
            "does_not_determine_legal_applicability": True,
            "source_refs": _source_refs(requirements)}


def _source_refs(requirements):
    return list({(c["reference_id"], c.get("source_version")): {"reference_id": c["reference_id"], "source_id": c["source_id"],
                 "source_version": c.get("source_version"), "version": c.get("source_version"), "content_sha256": c.get("content_sha256")}
                 for item in requirements for c in item["citations"]}.values())


def mission_source_dependencies(mission):
    refs = [*(mission.get("knowledge") or {}).get("source_refs", []), *mission.get("readiness_source_refs", [])]
    return list({ref["source_id"]: ref for ref in refs}.values())


def readiness_snapshot_valid(mission, db):
    """Version/hash/freshness and supersession protect future paid inputs."""
    refs = mission.get("readiness_source_refs", [])
    if not refs:
        return True
    current = {record["id"]: record for record in read_authority_records(db, (mission.get("market") or {}).get("code"))}
    return all((record := current.get(ref.get("reference_id"))) is not None
               and record.get("source_id") == ref.get("source_id")
               and record.get("source_version") == ref.get("version")
               and record.get("content_sha256") == ref.get("content_sha256") for ref in refs)


def project_delivery_status(mission, actions=None):
    """Missing action detail is a delivery gap, never rejection of paid answers."""
    requested = (mission.get("intent") or {}).get("requested_action_count")
    if requested != 3:
        requested = None
    values = deepcopy(mission.get("actions", []) if actions is None else actions)
    values = values if isinstance(values, list) else []
    known_basis = {record.get("id") for record in (mission.get("knowledge") or {}).get("records", []) if isinstance(record, dict)}
    known_basis.update(ref.get("reference_id") for ref in (mission.get("goal_readiness_snapshot") or {}).get("source_refs", []) if isinstance(ref, dict))
    gaps, actionable = [], []
    priorities = [action.get("priority") for action in values if isinstance(action, dict)]
    for action in values:
        if not isinstance(action, dict):
            continue
        missing = [field for field in ("priority", "owner_vi", "deliverable_vi", "basis_source_ids") if not action.get(field)]
        priority = action.get("priority")
        if not isinstance(priority, int) or isinstance(priority, bool) or not 1 <= priority <= 3 or priorities.count(priority) != 1:
            if "priority" not in missing:
                missing.append("priority")
        if any(not isinstance(action.get(field), str) or not action[field].strip() for field in ("owner_vi", "deliverable_vi")):
            missing.extend(field for field in ("owner_vi", "deliverable_vi") if field not in missing and (not isinstance(action.get(field), str) or not action[field].strip()))
        if not isinstance(action.get("basis_source_ids"), list) or any(source_id not in known_basis for source_id in action.get("basis_source_ids", [])):
            if "basis_source_ids" not in missing:
                missing.append("basis_source_ids")
        if missing:
            gaps.append({"action_id": action.get("id"), "missing_fields": missing, "reason_vi": "Việc đề xuất chưa có đủ thứ tự, người phụ trách, đầu ra hoặc căn cứ để thực hiện."})
        else:
            actionable.append(action)
    if requested and len(actionable) < requested:
        gaps.append({"reason": "requested_actions_incomplete", "reason_vi": "Câu trả lời đã được giữ; phần ba việc đầu tiên chưa đủ chi tiết để coi là đã giao đủ.", "missing_count": requested - len(actionable)})
    return {"schema_version": "research-delivery/1", "requested_action_count": requested,
            "action_count": len(values), "actionable_count": len(actionable),
            "status": "not_requested" if requested is None else "partial" if gaps else "complete",
            "gaps": gaps if requested else [], "does_not_invalidate_answers": True,
            "status_scope": "legacy_priority_owner_deliverable_basis_fields",
            "action_brief_acceptance": assess_recorded_action_briefs(mission, values)}
