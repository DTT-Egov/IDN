"""Exact public authorities shared by pack installation and source refresh."""

AUTHORITY_HOSTS = frozenset({
    "www.fda.gov", "eur-lex.europa.eu", "www.gesetze-im-internet.de",
    "www.caa.go.jp", "www.mhlw.go.jp", "food.ec.europa.eu", "laws.e-gov.go.jp",
    "www.ecfr.gov", "www.govinfo.gov",
})
