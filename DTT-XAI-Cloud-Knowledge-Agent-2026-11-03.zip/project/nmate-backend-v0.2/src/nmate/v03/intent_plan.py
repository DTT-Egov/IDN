"""Versioned, server-owned planning read model shared by bounded agents.

DF-015/022/024/025/026: a requested goal, a supporting check, an available
source and a completed action are different facts. This module performs no
SQL, network, model call, identity resolution or SSOT mutation. Its projection
never changes the canonical request of an already recorded paid operation.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .evidence import outcome_topic, record_applicability


VERSION = "intent-plan/1"
REGISTRY_VERSION = "bounded-requirements/2026-10-22"


class PlanContract(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True, allow_inf_nan=False)


class Goal(PlanContract):
    id: str
    title_vi: str
    origin: Literal["requested", "supporting"] = "requested"
    quote: str
    requirement_ids: list[str] = Field(default_factory=list)


class IntentEnvelope(PlanContract):
    schema_version: Literal["intent-envelope/1"] = "intent-envelope/1"
    question: str
    domain: Literal["export", "operations", "policy", "profile", "packaging", "unsupported", "clarification"]
    focus: str | None = None
    market_codes: list[str] = Field(default_factory=list)
    product_ref: dict = Field(default_factory=dict)
    goals: list[Goal] = Field(default_factory=list)
    exclusions: list[str] = Field(default_factory=list)
    ambiguities: list[str] = Field(default_factory=list)
    known_inputs: dict = Field(default_factory=dict)
    requested_action_count: int | None = None
    provenance: Literal["server_bounded_projection"] = "server_bounded_projection"


class Requirement(PlanContract):
    id: str
    goal_ids: list[str]
    title_vi: str
    origin: Literal["requested", "supporting"]
    why_vi: str
    applicability: Literal["not_assessed"] = "not_assessed"
    source_status: Literal["reference_available", "needs_source", "not_required"]
    source_refs: list[dict] = Field(default_factory=list)
    required_inputs: list[str] = Field(default_factory=list)
    missing_inputs: list[str] = Field(default_factory=list)


class Task(PlanContract):
    id: str
    requirement_id: str
    goal_ids: list[str]
    title_vi: str
    capability_id: str
    depends_on: list[str] = Field(default_factory=list)
    status: Literal["ready_to_prepare", "needs_input", "needs_source", "unsupported"]
    acceptance_vi: str = Field(min_length=1)


class ActionBrief(PlanContract):
    id: str
    priority: int = Field(ge=1)
    title_vi: str = Field(min_length=1)
    owner_vi: str = Field(min_length=1)
    requirement_ids: list[str]
    task_ids: list[str]
    input_keys: list[str]
    reused_input_keys: list[str]
    missing_input_keys: list[str]
    deliverable_vi: str = Field(min_length=1)
    acceptance_vi: str = Field(min_length=1)
    next_step_vi: str = Field(min_length=1)
    basis_refs: list[dict]
    status: Literal["ready_to_prepare", "needs_input", "needs_source"]
    preparation_only: Literal[True] = True


class ActionDelivery(PlanContract):
    schema_version: Literal["plan-delivery/1"] = "plan-delivery/1"
    requested_count: int | None
    prepared_count: int = Field(ge=0)
    missing_count: int = Field(ge=0)
    status: Literal["not_requested", "partial", "ready"]
    reason_vi: str = Field(min_length=1)


class PlanProjection(PlanContract):
    schema_version: Literal["intent-plan/1"] = VERSION
    registry_version: Literal["bounded-requirements/2026-10-22"] = REGISTRY_VERSION
    intent: IntentEnvelope
    requirements: list[Requirement]
    tasks: list[Task]
    outcomes: list[dict]
    first_actions: list[ActionBrief]
    delivery: ActionDelivery
    completeness: dict
    plan_hash: str = ""
    does_not_change_saved_model_request: Literal[True] = True
    does_not_determine_legal_applicability: Literal[True] = True

    @model_validator(mode="after")
    def relationships(self):
        goals = {item.id for item in self.intent.goals}
        requirements = {item.id for item in self.requirements}
        task_ids = {item.id for item in self.tasks}
        if len(goals) != len(self.intent.goals) or len(requirements) != len(self.requirements) or len(task_ids) != len(self.tasks):
            raise ValueError("Duplicate plan identity")
        if requirements.intersection(self.intent.exclusions):
            raise ValueError("Excluded requirement entered plan")
        for goal in self.intent.goals:
            if not set(goal.requirement_ids) <= requirements:
                raise ValueError("Goal has unknown requirement")
            if goal.quote and goal.quote not in self.intent.question:
                raise ValueError("Goal lacks original question provenance")
        for item in self.requirements:
            if not item.goal_ids or not set(item.goal_ids) <= goals:
                raise ValueError("Requirement has unknown goal")
            if any(item.id not in goal.requirement_ids for goal in self.intent.goals if goal.id in item.goal_ids):
                raise ValueError("Requirement and goal edges disagree")
            if not set(item.missing_inputs) <= set(item.required_inputs):
                raise ValueError("Missing input is outside requirement")
        done = set()
        while len(done) < len(task_ids):
            ready = {item.id for item in self.tasks if item.id not in done and set(item.depends_on) <= done}
            if not ready:
                raise ValueError("Unresolved or cyclic plan dependency")
            done |= ready
        for item in self.tasks:
            if item.requirement_id not in requirements or not item.goal_ids or not set(item.goal_ids) <= goals:
                raise ValueError("Task has unknown requirement or goal")
            requirement = next(req for req in self.requirements if req.id == item.requirement_id)
            if set(item.goal_ids) != set(requirement.goal_ids):
                raise ValueError("Task does not serve its requirement goals")
        if [item.priority for item in self.first_actions] != list(range(1, len(self.first_actions) + 1)):
            raise ValueError("Action priority must be a unique sequence")
        requested = self.intent.requested_action_count
        prepared = len(self.first_actions)
        missing = max((requested or 0) - prepared, 0)
        delivery_status = "not_requested" if requested is None else "partial" if missing else "ready"
        if (self.delivery.requested_count, self.delivery.prepared_count, self.delivery.missing_count, self.delivery.status) != (requested, prepared, missing, delivery_status):
            raise ValueError("Action delivery does not match the displayed preparation count")
        for item in self.first_actions:
            if not item.task_ids or not item.requirement_ids or not set(item.task_ids) <= task_ids or not set(item.requirement_ids) <= requirements:
                raise ValueError("Action has unknown task or requirement")
            if any(task.requirement_id not in item.requirement_ids for task in self.tasks if task.id in item.task_ids):
                raise ValueError("Action does not serve its requirement")
            if set(item.reused_input_keys) & set(item.missing_input_keys) or set(item.reused_input_keys) | set(item.missing_input_keys) != set(item.input_keys):
                raise ValueError("Action input lifecycle is inconsistent")
        return self


def intent_text(text):
    """Use the same owner/label/quantifier/contrast roles as requested intent."""
    from .research_scope import _intent_text
    return _intent_text(text)


_TOPIC_PATTERNS = {
    "facility_registration": r"\b(?:dang ky|registration|co so fda|us agent|dieu kien nhap khau|thu tuc nhap khau|thong bao nhap khau|import notification)\b",
    "food_label": r"\b(?:label|nhan|labelling|labeling)\b",
    "prior_notice": r"\b(?:thong bao truoc|prior notice)\b",
    "fsvp_importer": r"\b(?:fsvp|trach nhiem (?:ben |nha )?nhap khau)\b",
    "origin_marking": r"\b(?:xuat xu|country of origin|origin marking)\b",
    "certification": r"\b(?:chung nhan|certification|certificate)\b",
}


def excluded_requirements(question):
    from .research_scope import negative_request_clauses
    value = intent_text(question)
    result = []
    for key, pattern in _TOPIC_PATTERNS.items():
        for clause, _positive, negative in negative_request_clauses(value, _TOPIC_PATTERNS):
            if negative and re.search(pattern, negative):
                result.append(key)
            elif re.search(pattern + r"[^,;.!?]{0,30}\b(?:da xong|da hoan tat)\b", clause):
                result.append(key)
    return list(dict.fromkeys(result))


def broad_export_goal(question, market_code):
    """A bounded preparation objective, not a finding that laws apply."""
    if market_code not in {"US", "DE", "JP"}:
        return None
    folded = intent_text(question)
    if re.search(r"\b(?:chi hoi|chi can|chi muon|only ask|only need|label only|prior notice only)\b", folded):
        return None
    commercial = re.search(r"\b(?:muon|du dinh|chuan bi|can|se|want|plan|prepare|need)\b.{0,90}\b(?:ban|xuat khau|xuat|gui|dua hang|lo hang|sell|export|ship)\b", folded)
    first_steps = re.search(r"\b(?:ba|3)\s+(?:viec|buoc)(?:\s+(?:gi|nao|nen lam|can lam|can))?\s+(?:dau tien|truoc|uu tien)\b|\b(?:lo hang dau(?: tien)?|lan dau xuat|first shipment|first steps|bat dau tu dau|chuan bi (?:nhung |cac |pluralquantifier )?(?:gi|viec gi)|what (?:do i |should i |must i )?(?:need|prepare))\b", folded)
    if not commercial or not first_steps:
        return None
    return {"id": f"{market_code.lower()}_food_market_entry", "basis_quote": question,
            "interpretation": "bounded_goal_prerequisites", "excluded_requirement_ids": excluded_requirements(question)}


_EXPORT = {
    "US": [("facility_registration", "Đối chiếu hoạt động cơ sở và phạm vi đăng ký FDA", ["facility_activity", "facility_type", "facility_address"]),
           ("food_label", "Chuẩn bị nội dung nhãn cho Mỹ", ["ingredients", "net_quantity", "responsible_business"]),
           ("prior_notice", "Đối chiếu thông báo trước của lô hàng", ["transport_mode", "port_of_arrival", "arrival_datetime", "prior_notice_submitter"]),
           ("fsvp_importer", "Làm rõ đầu mối và trách nhiệm bên nhập khẩu", ["importer_name", "importer_role"]),
           ("origin_marking", "Đối chiếu xuất xứ và ngoại lệ theo loại hàng", ["country_of_origin", "product_category"])],
    "DE": [("facility_registration", "Đối chiếu điều kiện nhập thực phẩm vào Đức (EU)", ["product_category", "ingredients", "country_of_origin"]),
           ("food_label", "Chuẩn bị nội dung nhãn cho Đức (EU)", ["ingredients", "net_quantity", "responsible_business"]),
           ("eu_operator", "Làm rõ đơn vị chịu trách nhiệm thông tin thực phẩm tại EU", ["importer_name", "importer_role"]),
           ("eu_import_controls", "Đối chiếu phân loại hàng và điều kiện kiểm soát tại cửa khẩu", ["product_category", "ingredients", "country_of_origin"])],
    "JP": [("facility_registration", "Đối chiếu thông báo nhập thực phẩm vào Nhật Bản", ["product_category", "ingredients", "importer_name"]),
           ("food_label", "Chuẩn bị nội dung nhãn cho Nhật Bản", ["ingredients", "net_quantity", "responsible_business"]),
           ("jp_importer", "Làm rõ đơn vị nhập khẩu tại Nhật Bản", ["importer_name", "importer_role"]),
           ("jp_product_scope", "Đối chiếu loại sản phẩm và kiểm dịch có thể liên quan", ["product_category", "processing_method", "country_of_origin"])],
}
_OUTCOME_REQUIREMENT = {"registration": "facility_registration", "label": "food_label", "certification": "certification", "prior_notice": "prior_notice"}


def _finish(envelope, requirements, tasks, actions, outcomes):
    blockers = [{"requirement_id": item.id, "reason": "needs_source", "title_vi": item.title_vi}
                for item in requirements if item.source_status == "needs_source"]
    missing = [{"requirement_id": item.id, "fields": item.missing_inputs} for item in requirements if item.missing_inputs]
    covered = {item["goal_id"] for item in outcomes}
    uncovered = [goal.id for goal in envelope.goals if goal.id not in covered]
    shown_actions = actions[:envelope.requested_action_count or 3]
    requested, prepared = envelope.requested_action_count, len(shown_actions)
    missing_count = max((requested or 0) - prepared, 0)
    delivery_status = "not_requested" if requested is None else "partial" if missing_count else "ready"
    reason = (f"Mình mới chuẩn bị được {prepared}/{requested} việc theo phạm vi đang hỏi; còn thiếu {missing_count} việc so với yêu cầu. Các việc này mới ở bước chuẩn bị."
              if missing_count else f"Mình đã chuẩn bị đủ {requested} việc theo số lượng yêu cầu; dữ kiện và nguồn vẫn cần kiểm tra trước khi thực hiện."
              if requested is not None else "Đây là các việc chuẩn bị theo nhu cầu; chưa xác nhận công việc đã hoàn tất.")
    delivery = ActionDelivery(requested_count=requested, prepared_count=prepared, missing_count=missing_count,
                              status=delivery_status, reason_vi=reason)
    plan = PlanProjection(intent=envelope, requirements=requirements, tasks=tasks, outcomes=outcomes,
        first_actions=shown_actions, delivery=delivery, completeness={
            "status": "unsupported" if envelope.domain == "unsupported" else "needs_clarification" if uncovered or envelope.ambiguities or not envelope.goals else "partial" if blockers or missing or missing_count else "planned",
            "blockers": blockers, "missing_inputs": missing, "uncovered_goal_ids": uncovered,
            "action_count_gap": {"reason": "requested_actions_incomplete", "requested_count": requested,
                                 "prepared_count": prepared, "missing_count": missing_count, "reason_vi": reason} if missing_count else None,
            "correctness_assessment": "not_performed", "does_not_mark_research_or_actions_complete": True})
    raw = plan.model_dump(exclude={"plan_hash"})
    plan.plan_hash = hashlib.sha256(json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return plan.model_dump()


_PREPARATION = {
    "facility_registration": ("Ghi hoạt động, loại hình và địa chỉ cơ sở để đối chiếu", "Một bảng ghi nơi sản xuất/chế biến, đóng gói, lưu kho; loại hình và địa chỉ cơ sở; mục chưa biết để chờ xác nhận."),
    "food_label": ("Gom công thức và dữ kiện thành bản nháp nội dung nhãn", "Một bản nháp có công thức thành phần, lượng tịnh và đơn vị chịu trách nhiệm; dị nguyên, dinh dưỡng và xuất xứ chưa kiểm chứng được đánh dấu chờ rà, chưa duyệt để in."),
    "prior_notice": ("Lập bảng lịch lô hàng và đề nghị xác nhận người nộp thông báo", "Một bảng gồm phương thức vận chuyển, cảng đến, ngày giờ đến dự kiến và người dự kiến nộp thông báo; các mục chưa xác nhận được ghi rõ, chưa thực hiện nộp hồ sơ."),
    "fsvp_importer": ("Xác nhận đầu mối nhập khẩu và người kiểm tra trách nhiệm FSVP", "Một bảng tên, liên hệ và vai trò được đầu mối nhập khẩu xác nhận; chưa coi đại diện đăng ký cơ sở là bên nhập khẩu FSVP."),
    "origin_marking": ("Ghi xuất xứ thực tế và loại sản phẩm để rà quy tắc ghi xuất xứ", "Một bảng xuất xứ nguyên liệu, nơi chế biến và loại sản phẩm; ngoại lệ hoặc nội dung phải ghi vẫn để chờ đối chiếu nguồn."),
    "inventory_context": ("Giữ ngày kiểm kê và đúng mã cho hai số tồn đã nêu", "Một dòng kiểm kê có mã, ngày, tồn trên sổ, đếm thực tế và đơn vị; không ghi các số làm việc này thành hồ sơ chuẩn."),
    "inventory_reconciliation": ("Chuẩn bị phiếu nhập và xuất của mã đang kiểm kê", "Một danh sách phiếu nhập, xuất, điều chỉnh trong cùng kỳ để đối chiếu chênh lệch; chưa suy nguyên nhân từ hai số tồn."),
    "sales_period": ("Giữ số bán cùng tháng đã nêu, bổ sung đơn vị nếu còn thiếu", "Một dòng số bán với kỳ gốc và đơn vị; tháng 9 không được đổi thành tốc độ bán mỗi tháng."),
    "sales_transactions": ("Chuẩn bị bảng giao dịch đúng kỳ và mã sản phẩm", "Một bảng ngày bán, mã, số lượng, đơn vị và hàng trả lại để đối chiếu; chưa tạo báo cáo từ một số tổng chưa đối chiếu."),
    "DE:facility_registration": ("Gom thành phần, loại hàng và xuất xứ để rà điều kiện nhập vào Đức", "Một bảng loại sản phẩm, công thức và xuất xứ thực tế để đối chiếu điều kiện nhập EU/Đức; chưa suy rằng mọi hàng có cùng yêu cầu cơ sở hoặc chứng nhận."),
    "JP:facility_registration": ("Gom hồ sơ thực phẩm và đầu mối nhập khẩu tại Nhật", "Một bảng loại sản phẩm, thành phần và đơn vị nhập dự kiến để đối chiếu thủ tục Nhật Bản; không áp thủ tục FDA hoặc Prior Notice của Mỹ."),
}


def _action(requirement, task, priority, *, owner="Chủ cơ sở", label=None, preparation_key=None):
    source_blocked = requirement.source_status == "needs_source"
    default_output = "Một bảng đối chiếu " + requirement.title_vi.lower() + "; phần chưa có dữ kiện hoặc nguồn được đánh dấu rõ, chưa duyệt để thực hiện."
    title, output = _PREPARATION.get(preparation_key or requirement.id, (requirement.title_vi, default_output))
    return ActionBrief(id="action:" + requirement.id, priority=priority, title_vi=label or title,
        owner_vi=owner, requirement_ids=[requirement.id], task_ids=[task.id],
        input_keys=requirement.required_inputs, reused_input_keys=[key for key in requirement.required_inputs if key not in requirement.missing_inputs],
        missing_input_keys=requirement.missing_inputs, deliverable_vi=output,
        acceptance_vi=task.acceptance_vi,
        next_step_vi=("Bổ sung và kiểm tra nguồn chính thức trước khi kết luận; phần chuẩn bị dữ kiện có thể tiếp tục." if source_blocked else
                      "Đối chiếu dữ kiện, phạm vi và ngoại lệ trước khi xác nhận bước thực hiện."),
        basis_refs=requirement.source_refs, status="needs_input" if requirement.missing_inputs else "needs_source" if source_blocked else "ready_to_prepare")


def compile_export_plan(mission):
    """Read-only, bounded plan; explicit paid outcomes remain unchanged.

    Supporting checks are candidates from the versioned market registry and
    always have applicability=not_assessed. Availability is taken from scoped
    records or already-authorized readiness citations, never a keyword alone.
    """
    question = str(mission.get("question") or "")
    market = (mission.get("market") or {}).get("code")
    intent = mission.get("intent") or {}
    excluded = excluded_requirements(question)
    broad = broad_export_goal(question, market) if intent.get("scope") != "unsupported" else None
    requested = list(dict.fromkeys(_OUTCOME_REQUIREMENT[item["id"]] for item in intent.get("outcomes", [])
                                  if item.get("id") in _OUTCOME_REQUIREMENT))
    requested = [key for key in requested if key not in excluded]
    definitions = {key: (title, fields) for key, title, fields in _EXPORT.get(market, [])}
    definitions["certification"] = ("Đối chiếu chứng nhận theo sản phẩm và thị trường", ["product_category", "ingredients"])
    keys = list(dict.fromkeys([*requested, *(key for key, *_ in _EXPORT.get(market, []) if broad)]))
    keys = [key for key in keys if key not in excluded]
    # Prior Notice is not a cross-market synonym for every import procedure.
    if market != "US" and "prior_notice" in keys:
        definitions["prior_notice"] = ("Làm rõ thủ tục được gọi là Prior Notice ngoài Mỹ", [])
    context = mission.get("current_context") or mission.get("context") or {}
    known = deepcopy(context.get("values") or {})
    for entity in context.get("entities", []):
        for key, value in (entity.get("values") or {}).items():
            known.setdefault(key, value)
    goals = [Goal(id=f"export:{key}", title_vi=definitions.get(key, (key, []))[0], quote=question, requirement_ids=[key]) for key in requested]
    if broad:
        goals.append(Goal(id=broad["id"], title_vi="Chuẩn bị lô hàng đầu tiên theo thị trường", quote=question, requirement_ids=keys))
    ambiguities = list(intent.get("ambiguities") or [])
    if not market:
        ambiguities.append("Chưa xác nhận thị trường; không dùng gói Mỹ thay thị trường chưa rõ.")
    if not goals:
        ambiguities.append("Chưa có mục tiêu nghiên cứu đủ rõ; cần một câu làm rõ, chưa coi là nghiên cứu đã xong.")
    envelope = IntentEnvelope(question=question, domain="export", market_codes=[market] if market else [],
        product_ref=deepcopy(mission.get("product") or {}), goals=goals, exclusions=excluded,
        ambiguities=list(dict.fromkeys(ambiguities)), known_inputs=known,
        requested_action_count=3 if intent.get("requested_action_count") == 3 or re.search(r"\b(?:ba|3) (?:viec|buoc).*\b(?:dau tien|uu tien)\b", intent_text(question)) else None)
    records = (mission.get("knowledge") or {}).get("records", [])
    readiness_snapshot = mission.get("goal_readiness_snapshot") or {}
    readiness = {item.get("id"): item for item in readiness_snapshot.get("requirements", [])} if readiness_snapshot.get("market_code") == market else {}
    requirements, tasks, actions, outcomes = [], [], [], []
    answers = {item.get("outcome_id"): item for item in mission.get("answers", [])}
    for key in keys:
        title, fields = definitions.get(key, (key, []))
        outcome_id = next((oid for oid, rid in _OUTCOME_REQUIREMENT.items() if rid == key), None)
        topic = outcome_topic(outcome_id, market) if outcome_id else key
        refs = [{"kind": "reference_excerpt", "reference_id": item["id"], "source_id": item.get("source_id"),
                 "source_version": item.get("source_version"), "excerpt_sha256": item.get("excerpt_sha256")}
                for item in records if isinstance(item, dict) and topic and topic in item.get("topics", [])
                and market in {"US", "DE", "JP"} and record_applicability(item, market) is None]
        supporting = readiness.get(key) or {}
        refs.extend({"kind": "reference_excerpt", "reference_id": ref["reference_id"], "source_id": ref.get("source_id"),
                     "source_version": ref.get("source_version"), "excerpt_sha256": ref.get("excerpt_sha256")}
                    for ref in supporting.get("citations", []) if ref.get("reference_id"))
        refs = list({(ref["reference_id"], ref.get("source_version")): ref for ref in refs}.values())
        source_status = "reference_available" if refs and supporting.get("status") != "needs_source" else "needs_source"
        requirement = Requirement(id=key, goal_ids=[goal.id for goal in goals if key in goal.requirement_ids], title_vi=title,
            origin="requested" if key in requested else "supporting",
            why_vi=("Câu hỏi yêu cầu trực tiếp nội dung này." if key in requested else
                    f"Mục tiêu chuẩn bị lô đầu tiên cần đối chiếu thêm theo registry {REGISTRY_VERSION}; đây chưa phải kết luận nghĩa vụ áp dụng."),
            source_status=source_status, source_refs=refs, required_inputs=fields,
            missing_inputs=[field for field in fields if field not in known or known[field] is None or known[field] == ""])
        requirements.append(requirement)
        task = Task(id="prepare:" + key, requirement_id=key, goal_ids=requirement.goal_ids,
            title_vi=title, capability_id=f"export_{(market or 'unresolved').lower()}.{key}",
            status="needs_source" if source_status == "needs_source" else "needs_input" if requirement.missing_inputs else "ready_to_prepare",
            acceptance_vi="Có bảng dữ kiện của đúng sản phẩm/thị trường và từng điểm cần kiểm chứng; không ghi hoàn tất khi còn thiếu nguồn hoặc phạm vi áp dụng.")
        tasks.append(task)
        actions.append(_action(requirement, task, len(actions) + 1,
                               preparation_key=f"{market}:{key}" if key == "facility_registration" and market in {"DE", "JP"} else None))
    for goal in goals:
        related = [item for item in requirements if goal.id in item.goal_ids]
        oid = next((oid for oid, rid in _OUTCOME_REQUIREMENT.items() if goal.id == "export:" + rid), None)
        answer = answers.get(oid, {})
        outcomes.append({"goal_id": goal.id, "requirement_ids": [item.id for item in related],
            "answer_status": answer.get("status", "not_researched"),
            "source_status": "reference_available" if related and all(item.source_status == "reference_available" for item in related) else "needs_source",
            "correctness": "not_assessed_by_plan", "complete": False})
    return _finish(envelope, requirements, tasks, actions, outcomes)


_OPERATING = {
    "inventory_accuracy": [("inventory_context", "Giữ số tồn sổ và đếm thực tế cùng ngày, đúng mã", ["book_quantity", "physical_quantity", "count_date", "product_code"]),
                           ("inventory_reconciliation", "Đối chiếu phiếu nhập, xuất để tìm nguyên nhân chênh lệch", ["book_quantity", "physical_quantity", "count_date", "product_code"])],
    "sales_reporting": [("sales_period", "Giữ số bán cùng kỳ đã nêu", ["recent_sales_quantity", "sales_period"]),
                        ("sales_transactions", "Đối chiếu bảng giao dịch của kỳ và mã sản phẩm", ["sales_period", "product_code"])],
    "restocking_planning": [("available_stock", "Xác nhận tồn có thể bán của đúng mã", ["available_quantity", "available_quantity_unit", "product_code"]),
                            ("sales_rate", "Chuẩn bị số bán theo kỳ và đơn vị", ["recent_sales_quantity", "recent_sales_quantity_unit", "sales_period"]),
                            ("supplier_lead_time", "Xác nhận thời gian nhận hàng; chưa tính lượng nên nhập", ["supplier_lead_days"])],
}

_SLOT_KEYS = {
    "inventory_accuracy": {"book_quantity", "physical_quantity", "quantity_unit", "count_date", "count_date_phrase", "count_date_proposed", "product_code"},
    "sales_reporting": {"recent_sales_quantity", "recent_sales_quantity_unit", "quantity_unit", "sales_period", "sales_period_kind", "report_period", "report_dimension", "product_code", "reported_stock_quantity", "reported_stock_unit", "reported_stock_quote"},
    "restocking_planning": {"available_quantity", "available_quantity_unit", "recent_sales_quantity", "recent_sales_quantity_unit", "quantity_unit", "sales_period", "sales_period_kind", "supplier_lead_days", "product_code"},
}


def scoped_working_inputs(intent, previous):
    """A focus change cannot revive a prior business task's operational slots."""
    allowed = _SLOT_KEYS.get(intent.get("focus"), set()) if not intent.get("unsupported_request") else set()
    return {key: deepcopy(value) for key, value in (previous or {}).items() if key in allowed}


def compile_dialogue_plan(intent, question, values=None, product=None):
    """Projection for workspace views, not an extension to provider schemas.

    Working answers belong to one focus and retain zero. Old unrelated slot
    keys are ignored even if a legacy caller passes them after a focus switch.
    """
    primary, focus = intent.get("primary"), intent.get("focus")
    if primary == "export_readiness":
        from .research_scope import explicit_requested_outcomes
        codes = intent.get("market_codes") or []
        market = codes[0] if len(codes) == 1 else None
        return compile_export_plan({"question": question, "market": {"code": market}, "product": product,
            "intent": {"scope": "export_food", "outcomes": [{"id": oid} for oid in explicit_requested_outcomes(question, market)]},
            "context": {"values": values or {}}, "knowledge": {}})
    unsupported = intent.get("unsupported_request")
    domain = "unsupported" if unsupported else "operations" if primary == "digitize_operations" else {
        "understand_business": "profile", "improve_packaging": "packaging"}.get(primary, "clarification")
    definitions = list(_OPERATING.get(focus, [])) if domain == "operations" else []
    if focus == 'sales_reporting' and 'reported_stock_quantity' in (intent.get('working_answers') or {}):
        definitions.append(('sales_stock_context', 'Giữ riêng số tồn đã nêu; xác nhận thời điểm trước khi đối chiếu',
                            ['reported_stock_quantity', 'reported_stock_unit', 'product_code']))
    allowed = {field for _, _, fields in definitions for field in fields}
    known = {key: deepcopy(value) for key, value in (intent.get("working_answers") or {}).items() if key in allowed}
    goals = [Goal(id=focus, title_vi=intent.get("primary_label") or focus, quote=question, requirement_ids=[key for key, *_ in definitions])] if definitions else []
    envelope = IntentEnvelope(question=question, domain=domain, focus=focus, product_ref=deepcopy(product or {}),
        goals=goals, known_inputs=known, ambiguities=[str(unsupported)] if unsupported else [])
    requirements, tasks, actions = [], [], []
    for key, title, fields in definitions:
        requirement = Requirement(id=key, goal_ids=[focus], title_vi=title, origin="requested",
            why_vi="Dữ liệu làm việc của tác vụ hiện tại; chưa phải dữ kiện đã xác nhận trong hồ sơ.",
            source_status="not_required", required_inputs=fields,
            missing_inputs=[field for field in fields if field not in known or known[field] is None or known[field] == ""])
        requirements.append(requirement)
        task = Task(id="prepare:" + key, requirement_id=key, goal_ids=[focus], title_vi=title,
            capability_id="operations." + focus, depends_on=[tasks[-1].id] if tasks else [],
            status="needs_input" if requirement.missing_inputs else "ready_to_prepare",
            acceptance_vi="Đúng mã, kỳ và đơn vị; số đã nêu được giữ, phần chưa có chỉ hỏi một lần; chưa kết luận nguyên nhân hoặc lượng đặt hàng khi chưa đối chiếu.")
        tasks.append(task)
        actions.append(_action(requirement, task, len(actions) + 1))
    outcomes = [{"goal_id": goal.id, "requirement_ids": goal.requirement_ids,
                 "answer_status": "prepared_working_inputs", "source_status": "not_required", "complete": False} for goal in goals]
    return _finish(envelope, requirements, tasks, actions, outcomes)


def compile_policy_plan(question, goal_coverage, *, request_scope=None):
    """Adapt authorized policy coverage, preserving each goal's own blocker."""
    goals, requirements, tasks, actions, outcomes = [], [], [], [], []
    for item in goal_coverage:
        key = item["goal"]
        if key in {goal.id for goal in goals}:
            continue
        title = item.get("title_vi", key)
        goals.append(Goal(id=key, title_vi=title, quote=question, requirement_ids=[key]))
        source_status = "reference_available" if item.get("source_ids") and item.get("status") not in {"needs_source", "unsupported"} else "needs_source"
        refs = [{"kind": "policy_source", "source_id": source} for source in item.get("source_ids", [])]
        requirement = Requirement(id=key, goal_ids=[key], title_vi=title, origin="requested",
            why_vi="Mục tiêu trong câu hỏi được tra riêng; chính sách của mục tiêu khác không thay cho phần này.", source_status=source_status, source_refs=refs)
        requirements.append(requirement)
        task = Task(id="policy:" + key, requirement_id=key, goal_ids=[key], title_vi="Đối chiếu căn cứ cho " + title,
            capability_id="hanoi_policy." + key, status="needs_source" if source_status == "needs_source" else "ready_to_prepare",
            acceptance_vi="Có nguồn đọc đủ và quy tắc đã được người có quyền duyệt trước khi kết luận điều kiện; phần thiếu phải có lý do riêng.")
        tasks.append(task)
        actions.append(_action(requirement, task, len(actions) + 1, owner="DTT/chuyên gia đối chiếu căn cứ" if source_status == "needs_source" else "Chủ cơ sở và đầu mối chính sách"))
        outcomes.append({"goal_id": key, "requirement_ids": [key], "answer_status": item.get("status", "needs_source"),
                         "source_status": source_status, "complete": item.get("status") == "answered"})
    envelope = IntentEnvelope(question=question, domain="unsupported" if request_scope == "unsupported" else "policy", goals=goals,
        ambiguities=["Chưa có phạm vi chính sách đủ rõ."] if request_scope == "needs_clarification" else [])
    return _finish(envelope, requirements, tasks, actions, outcomes)


def assess_recorded_action_briefs(mission, actions):
    """Expose delivery gaps without repairing or rejecting a paid receipt.

    Legacy ResearchAction lacks acceptance/input/next-step fields. Never copy
    new server template text into it and claim that the model supplied them.
    Its older structural delivery status remains separately inspectable.
    """
    plan = compile_export_plan(mission)
    allowed_requirements = {item["id"] for item in plan["requirements"]}
    expected_refs = {ref["reference_id"] for item in plan["requirements"] for ref in item["source_refs"] if ref.get("reference_id")}
    results = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        requirement_ids = action.get("requirement_ids")
        if not isinstance(requirement_ids, list):
            outcome_ids = action.get("outcome_ids")
            requirement_ids = [_OUTCOME_REQUIREMENT[oid] for oid in outcome_ids if isinstance(oid, str) and oid in _OUTCOME_REQUIREMENT] if isinstance(outcome_ids, list) else []
        missing = [key for key in ("owner_vi", "deliverable_vi", "acceptance_vi", "next_step_vi")
                   if not isinstance(action.get(key), str) or not action[key].strip()]
        if not requirement_ids or any(not isinstance(key, str) or key not in allowed_requirements for key in requirement_ids):
            missing.append("requirement_ids")
        for key in ("input_keys", "reused_input_keys", "missing_input_keys"):
            if not isinstance(action.get(key), list) or any(not isinstance(field, str) for field in action[key]):
                missing.append(key)
        if isinstance(action.get("basis_source_ids"), list) and any(not isinstance(ref, str) or ref not in expected_refs for ref in action["basis_source_ids"]):
            missing.append("current_scoped_basis")
        results.append({"action_id": action.get("id"), "requirement_ids": requirement_ids,
                        "status": "needs_delivery_detail" if missing else "ready_to_prepare",
                        "missing_fields": missing, "does_not_mark_action_completed": True})
    return {"schema_version": "action-brief-acceptance/1", "plan_hash": plan["plan_hash"],
            "status": "not_recorded" if not results else "partial" if any(item["missing_fields"] for item in results) else "ready_to_prepare",
            "actions": results, "plan_completeness": plan["completeness"],
            "does_not_rewrite_saved_actions": True, "does_not_invalidate_answers": True}
