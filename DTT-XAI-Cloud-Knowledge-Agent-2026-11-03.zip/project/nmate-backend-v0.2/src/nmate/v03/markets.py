"""Bounded market registry. Unknown destinations never inherit the US pack."""
from copy import deepcopy
import re
import unicodedata

from .core import CoreError


MARKETS = {
    "US": {"id": "US", "code": "US", "name_vi": "Mỹ", "jurisdictions": ["US"],
           "label_language": "en", "pack_version": "us-food-2026-10-18"},
    "DE": {"id": "DE", "code": "DE", "name_vi": "Đức (EU)", "jurisdictions": ["EU", "DE"],
           "label_language": "de", "pack_version": "de-eu-food-2026-10-18"},
    "JP": {"id": "JP", "code": "JP", "name_vi": "Nhật Bản", "jurisdictions": ["JP"],
           "label_language": "ja", "pack_version": "jp-food-2026-10-18"},
}


def normalize_text(value):
    text = unicodedata.normalize("NFKD", str(value or "").casefold()).replace("đ", "d")
    return " ".join("".join(c for c in text if not unicodedata.combining(c)).split())


def get_market(code):
    aliases = {"us": "US", "usa": "US", "my": "US", "hoa ky": "US", "united states": "US",
               "de": "DE", "duc": "DE", "duc (eu)": "DE", "germany": "DE", "deutschland": "DE",
               "jp": "JP", "nhat": "JP", "nhat ban": "JP", "japan": "JP"}
    canonical = aliases.get(normalize_text(code))
    if canonical is None:
        raise CoreError("unsupported_market", "Hãy chọn Mỹ, Đức (EU) hoặc Nhật Bản; thị trường khác chưa có gói nguồn trong 0.3B.")
    return deepcopy(MARKETS[canonical])


def detect_markets(text):
    """Return explicit destinations; EU needs a member-country clarification."""
    value = normalize_text(text)
    patterns = {
        "US": r"\b(?:my|hoa ky|usa|united states|america|new york|los angeles|california|texas|boston|seattle|chicago|us)\b",
        "DE": r"\b(?:duc|germany|deutschland|berlin|hamburg|munich|frankfurt)\b",
        "JP": r"\b(?:nhat ban|nhat|japan|tokyo|osaka|yokohama|jp)\b",
        "EU": r"\b(?:eu|lien minh chau au|chau au|europe|european union)\b",
        "OTHER": r"\b(?:canada|uc|australia|phap|france|ha lan|netherlands|trung quoc|china|han quoc|korea|singapore|thai lan|thailand|dai loan|taiwan|hong kong|an do|india|new zealand|vuong quoc anh|nuoc anh|united kingdom|uk|london|italy|nuoc y|tay ban nha|spain|belgium|nuoc bi|thuy dien|sweden|ba lan|poland|brazil|braxin|bra xin)\b",
    }
    found = [(re.search(pattern, value).start(), code) for code, pattern in patterns.items()
             if re.search(pattern, value)]
    codes = [code for _, code in sorted(found)]
    if "DE" in codes:
        codes = [code for code in codes if code != "EU"]
    return codes


def market_title(outcome_id, code):
    market = get_market(code)
    if outcome_id == "label":
        language = {"en": "tiếng Anh", "de": "tiếng Đức", "ja": "tiếng Nhật"}[market["label_language"]]
        return f"Chuẩn bị nhãn {language} cho {market['name_vi']}"
    if outcome_id == "registration":
        return {"US": "Đối chiếu phạm vi đăng ký cơ sở FDA",
                "DE": "Đối chiếu điều kiện nhập khẩu và cơ sở cho Đức (EU)",
                "JP": "Đối chiếu thông báo nhập khẩu thực phẩm vào Nhật Bản"}[market["code"]]
    return {"prior_notice": "Làm rõ thông báo trước và thời điểm nộp",
            "certification": "Đối chiếu chứng nhận cần thiết",
            "certifications": "Đối chiếu chứng nhận cần thiết"}.get(outcome_id, str(outcome_id))
