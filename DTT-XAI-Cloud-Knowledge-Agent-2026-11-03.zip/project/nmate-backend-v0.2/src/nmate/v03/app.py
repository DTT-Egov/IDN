"""Isolated local 0.3B application. This module has no provider/config import."""
import asyncio
from contextlib import asynccontextmanager, suppress
from pathlib import Path
import secrets

import httpx2
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from mcp import Client
from mcp.client.streamable_http import streamable_http_client
from pydantic import BaseModel, ConfigDict, Field
from starlette.middleware.trustedhost import TrustedHostMiddleware

from nmate.models import AppError
from .core import CoreError, CoreRepository
from .identity import LocalAccounts
from .mcp import TOOL_NAMES, account_context, create_mcp
from .missions import MissionService

COOKIE = "nmate_v03_session"
PREAUTH = "nmate_v03_preauth"
CSRFCOOKIE = "nmate_v03_csrf"


class StrictInput(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)


class RegisterInput(StrictInput):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=10, max_length=200)
    enterprise_name: str = Field(min_length=2, max_length=160)


class LoginInput(StrictInput):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=1, max_length=200)


class ToolInput(StrictInput):
    name: str = Field(min_length=1, max_length=80)
    arguments: dict = Field(default_factory=dict)


class BodyLimit:
    def __init__(self, app, attachment_limit=65536):
        self.app = app
        self.attachment_limit = attachment_limit

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        limit = self.attachment_limit if scope.get("path") in {"/api/v03/mcp/call", "/mcp"} else 65536
        count = 0
        messages = []
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            count += len(message.get("body", b""))
            if count > limit:
                return await JSONResponse({"ok": False, "error": {"code": "BODY_LIMIT",
                    "message": "Nội dung quá dài. Vui lòng rút gọn."}}, 413)(scope, receive, send)
            messages.append(message)
            if not message.get("more_body"):
                break
        iterator = iter(messages)

        async def limited_receive():
            try:
                return next(iterator)
            except StopIteration:
                return await receive()

        await self.app(scope, limited_receive, send)


def create_app(db_path: Path, *, port: int = 8024, task_delay: float = 0.8,
               web_dir: Path | None = None, service_factory=None, mcp_factory=None,
               mode="bounded_templates_no_paid_calls", metadata_provider=None,
               cookie_namespace=None, mcp_timeout=30, enable_v04=False,
               intake_factory=None, tool_allowlist=None, main_document=None, extension_factory=None,
               defer_mcp_mount=False):
    repo = CoreRepository(db_path)
    accounts = LocalAccounts(repo)
    missions = (service_factory or MissionService)(repo, task_delay=task_delay)
    intake = None
    extension = None
    tool_names = TOOL_NAMES
    max_body = 65536
    if enable_v04:
        if mcp_factory is not None:
            raise ValueError("0.4A local intake cannot be combined with a live MCP factory")
        from nmate.v04.intake import IntakeService
        from nmate.v04.mcp import TOOL_NAMES as INTAKE_TOOLS
        intake = (intake_factory or IntakeService)(repo)
        tool_names = TOOL_NAMES | INTAKE_TOOLS
        extension = extension_factory(repo, missions, intake) if extension_factory else None
        if extension:
            tool_names = tool_names | set(extension.tool_names)
        max_body = 9 * 1024 * 1024
        mcp = create_mcp(repo, missions, intake=intake, live=getattr(intake, "paid_review", False), tool_allowlist=tool_allowlist,
                         extra_register=extension.register_tools if extension else None)
    else:
        mcp = (mcp_factory or create_mcp)(repo, missions)
    if tool_allowlist is not None:
        tool_names = tool_names & set(tool_allowlist)
    mcp_app = mcp.streamable_http_app(streamable_http_path="/mcp", stateless_http=True,
                                    json_response=True, max_request_body_size=max_body)
    server_tokens = {}
    anonymous = {}
    base_url = f"http://127.0.0.1:{port}"
    origins = {base_url, f"http://localhost:{port}"}
    web_dir = web_dir or Path(__file__).resolve().parents[4] / "nmate-mvp-v0.1"
    telemetry = {"mcp_calls": 0, "paid_calls": 0, "provider_attempts": 0, "worker_errors": 0}
    cookie_name = cookie_namespace + "_session" if cookie_namespace else COOKIE
    csrf_cookie = cookie_namespace + "_csrf" if cookie_namespace else CSRFCOOKIE
    preauth_cookie = cookie_namespace + "_preauth" if cookie_namespace else PREAUTH

    def metadata():
        return {**telemetry, **(metadata_provider() if metadata_provider else {})}

    async def worker():
        while True:
            try:
                worked = await missions.execute_next()
                if extension:
                    worked = await extension.execute_next() or worked
            except asyncio.CancelledError:
                raise
            except Exception:
                telemetry["worker_errors"] += 1
                worked = False
            if not worked:
                await asyncio.sleep(.15)

    @asynccontextmanager
    async def lifespan(app):
        if hasattr(missions, "recover_interrupted"):
            missions.recover_interrupted()
        if extension:
            extension.recover_interrupted()
        async with mcp_app.router.lifespan_context(mcp_app):
            task = asyncio.create_task(worker())
            try:
                yield
            finally:
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task

    app = FastAPI(title="nMate 0.4A · Hồ sơ doanh nghiệp · Kiểm thử giả lập" if enable_v04 else "nMate 0.3B · Đa thị trường · Kiểm thử giả lập",
                  version="0.4.0a" if enable_v04 else "0.3.0b", lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(BodyLimit, attachment_limit=max_body)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["127.0.0.1", "localhost", "testserver"])
    app.state.repo, app.state.accounts, app.state.missions = repo, accounts, missions
    app.state.intake = intake
    app.state.core_extension = extension
    app.state.telemetry = telemetry

    @app.middleware("http")
    async def security_headers(request, call_next):
        response = await call_next(request)
        response.headers.update({"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
            "Content-Security-Policy": "default-src 'self'; img-src 'self' data:" + (" blob:" if enable_v04 else "") + "; font-src 'self'; "
                "style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; "
                "frame-ancestors 'none'; base-uri 'self'; form-action 'self'"})
        return response

    @app.exception_handler(AppError)
    async def application_error(request, exc):
        return JSONResponse(exc.envelope(), status_code=exc.status)

    @app.exception_handler(CoreError)
    async def core_error(request, exc):
        return JSONResponse({"ok": False, "error": {"code": exc.code, "message": str(exc)}}, exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request, exc):
        return JSONResponse({"ok": False, "error": {"code": "INVALID_INPUT",
            "message": "Thông tin chưa đúng định dạng. Vui lòng kiểm tra lại."}}, 422)

    def origin_check(request):
        if request.headers.get("origin") not in origins:
            raise AppError("CSRF", "Trang gửi yêu cầu chưa được cho phép.", 403)

    def session(request, mutation=False):
        token = request.cookies.get(cookie_name, "")
        value = accounts.get_session(token)
        if not value:
            raise AppError("UNAUTHORIZED", "Vui lòng đăng nhập để mở hồ sơ doanh nghiệp.", 401)
        if mutation:
            origin_check(request)
            accounts.validate_csrf(token, request.headers.get("x-csrf-token", ""))
        return value

    def preauth(request):
        origin_check(request)
        token = request.cookies.get(preauth_cookie, "")
        csrf = anonymous.get(token)
        if not csrf or not secrets.compare_digest(csrf, request.headers.get("x-csrf-token", "")):
            raise AppError("CSRF", "Phiên đăng nhập đã đổi. Vui lòng tải lại trang.", 403)

    def public_session(value):
        # The adapter is deliberately explicit; opaque session/MCP tokens never enter JSON.
        return {"authenticated": True, "account": {"id": value["account_id"], "username": value["username"]},
                "enterprise": {"id": value["enterprise_id"], "name": value["enterprise_name"], "role": value.get("role", "owner")},
                "role": value.get("role", "owner"),
                "enterprises": [{"id": m["enterprise_id"], "name": m["enterprise_name"], "role": m["role"]}
                                for m in value.get("enterprises", [value])],
                "core_ready": bool(extension),
                "csrf_token": value["csrf_token"],
                "mode": mode, **metadata()}

    def logged_in(value, request):
        created = accounts.create_session(value["account_id"])
        response = JSONResponse(public_session({**value, **created}))
        response.set_cookie(cookie_name, created["token"], httponly=True, samesite="strict", max_age=86400)
        response.set_cookie(csrf_cookie, created["csrf_token"], httponly=True, samesite="strict", max_age=86400)
        previous = request.cookies.get(preauth_cookie, "")
        anonymous.pop(previous, None)
        response.delete_cookie(preauth_cookie)
        return response

    @app.get("/health")
    async def health():
        release = getattr(app.state, 'release_metadata', {"version": "0.4A" if enable_v04 else "0.3B"})
        return {"status": "ok", **release, "mode": mode,
                "network_policy": "loopback_only" if not metadata_provider else "review_provider_only", **metadata()}

    @app.get("/api/v03/session")
    async def read_session(request: Request):
        try:
            value = accounts.validate_csrf(request.cookies.get(cookie_name, ""), request.cookies.get(csrf_cookie, ""))
            return public_session({**value, "csrf_token": request.cookies.get(csrf_cookie)})
        except CoreError as exc:
            if exc.status_code not in (401, 403):
                raise
        token = request.cookies.get(preauth_cookie, "")
        if token not in anonymous:
            if len(anonymous) >= 1000:
                anonymous.clear()
            token = secrets.token_urlsafe(32)
            anonymous[token] = secrets.token_urlsafe(32)
        response = JSONResponse({"authenticated": False, "csrf_token": anonymous[token],
                                 "mode": mode, **metadata()})
        response.set_cookie(preauth_cookie, token, httponly=True, samesite="strict", max_age=3600)
        return response

    @app.post("/api/v03/register")
    async def register(request: Request, body: RegisterInput):
        preauth(request)
        value = await asyncio.to_thread(accounts.register, body.username, body.password, body.enterprise_name)
        return logged_in(value, request)

    @app.post("/api/v03/login")
    async def login(request: Request, body: LoginInput):
        preauth(request)
        value = await asyncio.to_thread(accounts.login, body.username, body.password)
        return logged_in(value, request)

    @app.post("/api/v03/logout")
    async def logout(request: Request):
        session(request, True)
        token = request.cookies.get(cookie_name, "")
        accounts.logout(token)
        server_tokens.clear()  # The next authenticated BFF call gets a new internal bearer.
        response = JSONResponse({"ok": True})
        response.delete_cookie(cookie_name)
        response.delete_cookie(csrf_cookie)
        return response

    @app.post("/api/v03/mcp/call")
    async def call_mcp(request: Request, body: ToolInput):
        session(request, True)
        if body.name not in tool_names:
            raise AppError("UNKNOWN_TOOL", "Chức năng này chưa có trong " + ("0.4A." if enable_v04 else "0.3B."), 400)
        cookie = request.cookies.get(cookie_name, "")
        token = secrets.token_urlsafe(32)
        server_tokens[token] = cookie
        try:
            async with httpx2.AsyncClient(headers={"Authorization": "Bearer " + token},
                    timeout=mcp_timeout, trust_env=False) as http:
                async with Client(streamable_http_client(base_url + "/mcp", http_client=http),
                                  mode="2026-07-28", cache=None) as client:
                    result = await client.call_tool(body.name, body.arguments)
                    payload = result.structured_content
            telemetry["mcp_calls"] += 1
            if not isinstance(payload, dict) or "ok" not in payload:
                raise AppError("MCP_INVALID", "Chưa nhận được kết quả hợp lệ. Mở lịch sử để kiểm tra; hệ thống không tự chạy lại.", 502)
            return payload
        finally:
            server_tokens.pop(token, None)

    @app.get("/")
    async def home():
        return RedirectResponse("/web/#assistant" if main_document else "/web/#assistant-v04a" if enable_v04 else "/web/#assistant-v03b")

    @app.get("/favicon.ico")
    async def favicon():
        return Response(status_code=204)

    @app.get("/favicon.svg")
    async def favicon_svg():
        return Response('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="9" fill="#087f6b"/><path d="M9 23V10h4v2c4-5 10-2 10 3v8h-4v-7c0-4-6-3-6 1v6z" fill="white"/></svg>', media_type="image/svg+xml")

    @app.get("/web/")
    async def web():
        return FileResponse(web_dir / (main_document or ("v04.html" if enable_v04 else "v03.html")))

    if (web_dir / "src").exists():
        app.mount("/web/src", StaticFiles(directory=web_dir / "src"), name="web-source")
    if enable_v04 and (web_dir / "demo-files").exists():
        app.mount("/web/demo-files", StaticFiles(directory=web_dir / "demo-files"), name="synthetic-demo-files")

    class McpAuthentication:
        def __init__(self, inner):
            self.inner = inner

        async def __call__(self, scope, receive, send):
            headers = dict(scope.get("headers", []))
            authorization = headers.get(b"authorization", b"").decode("latin1")
            token = authorization.removeprefix("Bearer ") if authorization.startswith("Bearer ") else ""
            cookie = server_tokens.get(token)
            try:
                value = accounts.get_session(cookie) if cookie else None
            except CoreError:
                value = None
            if not value:
                return await JSONResponse({"ok": False, "error": {"code": "UNAUTHORIZED",
                    "message": "Kênh MCP cần phiên đăng nhập hợp lệ."}}, 401)(scope, receive, send)
            context_token = account_context.set(value["account_id"])
            try:
                await self.inner(scope, receive, send)
            finally:
                account_context.reset(context_token)

    def finalize_mcp_mount():
        if getattr(app.state,'mcp_mount_finalized',False):
            raise RuntimeError('MCP transport has already been mounted.')
        app.mount("/", McpAuthentication(mcp_app))
        app.state.mcp_mount_finalized=True
    app.state.finalize_mcp_mount=finalize_mcp_mount
    if not defer_mcp_mount:finalize_mcp_mount()
    return app
