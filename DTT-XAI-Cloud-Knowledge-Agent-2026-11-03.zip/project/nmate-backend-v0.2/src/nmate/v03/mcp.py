"""The 0.3B facade: identity is supplied by the authenticated HTTP transport."""
from contextvars import ContextVar
import json
import inspect
from typing import Annotated, Any, Literal

from mcp.server import MCPServer
from mcp.types import CallToolResult, TextContent
from pydantic import BaseModel, ConfigDict, Field

from nmate.models import AppError
from .core import CoreError

account_context: ContextVar[str | None] = ContextVar("v03_account", default=None)
TOOL_NAMES = {"prepare_mission", "start_mission", "get_mission", "list_missions",
              "update_label", "update_label_progress", "get_enterprise_context", "update_enterprise_facts",
              "get_supported_markets"}
Identifier = Annotated[str, Field(min_length=1, max_length=128)]
Operation = Annotated[str, Field(min_length=8, max_length=128)]


class Envelope(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ok: bool
    data: dict[str, Any] | list | None = None
    error: dict[str, Any] | None = None


Result = Annotated[CallToolResult, Envelope]


def public_core_error(exc):
    """Only typed, bounded owner-authorized binding hints cross the MCP edge."""
    result={"code":exc.code,"message":str(exc)}
    if getattr(exc,"commit_state",None):
        result["commit_state"]=exc.commit_state
    detail=getattr(exc,"details",None)
    from nmate.v04.document_errors import public_document_rejection
    document_rejection = public_document_rejection(exc)
    if document_rejection is not None:
        result["details"] = document_rejection
    elif exc.code=="product_binding_required" and isinstance(detail,dict) and detail.get("kind")==exc.code:
        entities=detail.get("matched_entities")
        if (isinstance(detail.get("requested_name"),str) and 0<len(detail["requested_name"])<=250
                and isinstance(detail.get("intake_id"),str) and 0<len(detail["intake_id"])<=128
                and isinstance(entities,list) and 0<len(entities)<=5
                and all(isinstance(e,dict) and isinstance(e.get("id"),str) and 0<len(e["id"])<=128
                    and isinstance(e.get("name"),str) and 0<len(e["name"])<=250
                    and type(e.get("version")) is int and e["version"]>=0 for e in entities)):
            result["details"]={"kind":detail["kind"],"requested_name":detail["requested_name"],"intake_id":detail["intake_id"],
                "matched_entities":[{k:e[k] for k in ("id","name","version")} for e in entities]}
    elif (exc.code in {"product_selection_conflict", "ambiguous_product"}
          and isinstance(detail, dict) and detail.get("kind") == "product_selection_required"):
        entities = detail.get("matched_entities")
        if (detail.get("reason") in {"selection_conflict", "multiple_matches"}
                and isinstance(detail.get("requested_name"), str) and len(detail["requested_name"]) <= 250
                and isinstance(entities, list) and 0 < len(entities) <= 5
                and all(isinstance(e, dict) and isinstance(e.get("id"), str) and 0 < len(e["id"]) <= 128
                        and isinstance(e.get("name"), str) and 0 < len(e["name"]) <= 250
                        and type(e.get("version")) is int and e["version"] >= 0 for e in entities)):
            result["details"] = {
                "kind": detail["kind"], "reason": detail["reason"], "requested_name": detail["requested_name"],
                "matched_entities": [{k: e[k] for k in ("id", "name", "version")} for e in entities],
            }
    return result


def create_mcp(repo, missions, *, live=False, intake=None, tool_allowlist=None, extra_register=None):
    server = MCPServer("nMate Enterprise Missions", version="0.4.0a" if intake is not None else "0.3.0b",
        instructions=("Isolated 0.4A Claude review. Every explicitly consented send invokes at most one paid Claude call. Reads, drafts and SSOT confirmation are free. " if intake is not None and live else
        "Local 0.4A private image/Excel intake, bounded intent and confirmed SSOT. No paid calls. " if intake is not None else
        "Isolated Claude live review; explicit intake and research calls may incur charges. " if live else
        "Local 0.3B. Market-scoped templates, recorded public references and no paid calls. ") +
        "All private reads and writes require enterprise membership and resource access. "
        "A completed draft is not regulatory approval. Never submit externally.")

    async def call(operation):
        try:
            account = account_context.get()
            if not account:
                raise AppError("UNAUTHORIZED", "Vui lòng đăng nhập lại.", 401)
            value = operation(account)
            if inspect.isawaitable(value):
                value = await value
            payload = {"ok": True, "data": value}
        except AppError as exc:
            payload = exc.envelope()
        except CoreError as exc:
            payload = {"ok": False, "error": public_core_error(exc)}
        return CallToolResult(content=[TextContent(type="text", text=json.dumps(payload, ensure_ascii=False))],
                              structured_content=payload, is_error=not payload["ok"])

    @server.tool(structured_output=True, description="Plan supported outcomes from an explicit user question. "
                 "Creates an authorized SSOT snapshot and task DAG. " +
                 ("Explicitly invokes Claude intake once; may incur charges." if live else "Uses bounded templates only; no provider call."))
    async def prepare_mission(enterprise_id: Identifier, user_text: Annotated[str, Field(min_length=1, max_length=4000)],
                              operation_id: Operation, product_entity_id: Identifier | None = None,
                              continuation_mission_id: Identifier | None = None,
                              market_code: Annotated[str, Field(min_length=2, max_length=16)] | None = None) -> Result:
        prepare = getattr(missions, "prepare_async", missions.prepare)
        options = {"continuation_mission_id": continuation_mission_id}
        if market_code is not None:
            options["market_code"] = market_code
        return await call(lambda a: prepare(a, enterprise_id, user_text, operation_id, product_entity_id, **options))

    @server.tool(structured_output=True, description="Read the configured market capabilities and languages. "
                 "Recorded reference coverage does not certify complete compliance. No model call.")
    async def get_supported_markets(enterprise_id: Identifier) -> Result:
        def read(account):
            from .markets import MARKETS, get_market
            with repo.connection() as db:
                repo.get_membership(account, enterprise_id, db)
            return {"markets": [get_market(code) for code in MARKETS], "model_calls": 0}
        return await call(read)

    @server.tool(structured_output=True, description="Queue an explicitly accepted mission plan. Idempotent. " +
                 ("Claude research may incur charges; never automatically retries." if live else "No paid calls."))
    async def start_mission(enterprise_id: Identifier, mission_id: Identifier, operation_id: Operation,
                            paid_consent: bool = False) -> Result:
        def start(account):
            if getattr(missions, "requires_paid_consent", False) and paid_consent is not True:
                raise CoreError("PAID_CONSENT_REQUIRED", "Cần đồng ý rõ trước khi bắt đầu nghiên cứu có phí.", 409)
            return missions.start(account, enterprise_id, mission_id, operation_id)
        return await call(start)

    @server.tool(structured_output=True, description="Read the current authorized mission, answers, task state and saved drafts; never restarts it.")
    async def get_mission(enterprise_id: Identifier, mission_id: Identifier) -> Result:
        return await call(lambda a: missions.get(a, enterprise_id, mission_id))

    @server.tool(structured_output=True, description="List only missions accessible to the authenticated enterprise member.")
    async def list_missions(enterprise_id: Identifier) -> Result:
        return await call(lambda a: missions.list(a, enterprise_id))

    @server.tool(structured_output=True, description="Save a literal market-scoped label workbook edit with revision checks. Never files or approves a label.")
    async def update_label(enterprise_id: Identifier, mission_id: Identifier, artifact_id: Identifier,
                           fields: dict[str, str | None], expected_version: Annotated[int, Field(ge=1)],
                           operation_id: Operation) -> Result:
        return await call(lambda a: missions.update_label(a, enterprise_id, mission_id, artifact_id, fields,
                                                    expected_version, operation_id))

    @server.tool(structured_output=True, description="Atomically save a private label draft and only explicitly selected "
                 "fields as self-declared enterprise facts. CAS for artifact and entity; conflicts require an explicit choice. "
                 "Never verifies a fact, submits a label, calls a model or restarts research.")
    async def update_label_progress(enterprise_id: Identifier, mission_id: Identifier, artifact_id: Identifier,
                                   fields: dict[str, str | None], remember_fields: list[str],
                                   expected_artifact_version: Annotated[int, Field(ge=1)],
                                   expected_entity_version: Annotated[int, Field(ge=0)], operation_id: Operation,
                                   conflict_choices: dict[str, Literal["draft", "ssot", "edited"]] | None = None,
                                   expected_market_profile_version: Annotated[int, Field(ge=0)] | None = None) -> Result:
        options = {"conflict_choices": conflict_choices}
        if expected_market_profile_version is not None:
            options["expected_market_profile_version"] = expected_market_profile_version
        return await call(lambda a: missions.update_label_progress(a, enterprise_id, mission_id, artifact_id,
            fields, remember_fields, expected_artifact_version, expected_entity_version, operation_id,
            **options))

    @server.tool(structured_output=True, description="Read authorized enterprise entities and current facts with provenance and versions.")
    async def get_enterprise_context(enterprise_id: Identifier, entity_ids: list[str] | None = None) -> Result:
        return await call(lambda a: repo.get_context(a, enterprise_id, entity_ids=entity_ids))

    @server.tool(structured_output=True, description="Apply owner-confirmed product, facility or selected-market corrections through SSOT CAS. "
                 "Legacy label key allergens means market allergen_declaration; product allergen facts use the product SSOT proposal tool. "
                 "Null does not erase known facts; dependent old results become stale. No automatic rerun.")
    async def update_enterprise_facts(enterprise_id: Identifier, mission_id: Identifier,
                                      facts: list[dict[str, Any]], expected_version: Annotated[int, Field(ge=1)],
                                      operation_id: Operation,
                                      expected_market_profile_version: Annotated[int, Field(ge=0)] | None = None) -> Result:
        options = {}
        if expected_market_profile_version is not None:
            options["expected_market_profile_version"] = expected_market_profile_version
        return await call(lambda a: missions.update_facts(a, enterprise_id, mission_id, facts,
                                                    expected_version, operation_id, **options))

    if intake is not None:
        from nmate.v04.mcp import register_tools
        register_tools(server, intake, call)
    if extra_register:
        extra_register(server, call)
    if tool_allowlist is not None:
        # Filter the actual MCP registry too, not just the browser facade.
        for name in list(server._tool_manager._tools):
            if name not in tool_allowlist:
                server.remove_tool(name)
    return server
