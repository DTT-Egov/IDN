"""Shared typed public references and bounded export SQL read projection.

Export reference excerpts are not reviewed Hanoi eligibility claims. No raw
enterprise context, source observations, metrics, documents or actor IDs are
read into this reusable projection. It is not a legal currency certification.
"""
from __future__ import annotations

import hashlib
import json
import re

from .core import CoreError, json_text
from .evidence import evidence_date, record_applicability
from .markets import get_market
from .source_rights import public_source_permitted

GRAPH_VERSION = "public-domain-graph/1"


def digest(value):
    return hashlib.sha256(json_text(value).encode("utf-8")).hexdigest()


def ref(kind, identity, version):
    return {"kind": kind, "id": identity, "version": version}


def project_export_graph(db, *, market_code, as_of_date=None, reference_ids=None):
    market = get_market(market_code)
    as_of = evidence_date(as_of_date).isoformat()
    if reference_ids is not None and (not isinstance(reference_ids, list) or len(reference_ids) > 200
            or any(not isinstance(identity, str) or not identity for identity in reference_ids)):
        raise CoreError("invalid_reference_selection", "Danh sách trích đoạn cần định danh chính xác, tối đa 200 mục.")
    requested = set(reference_ids) if reference_ids is not None else None
    nodes, edges, dependencies, blocked, found = {}, [], [], [], set()

    def node(reference, **attributes):
        nodes[(reference["kind"], reference["id"], reference["version"])] = {"ref": reference, **attributes}

    def edge(left, relation, right, **attributes):
        edges.append({"from": left, "relation": relation, "to": right, **attributes})

    for row in db.execute("SELECT r.id reference_id,r.source_id reference_source_id,r.record_json,r.review_state,s.* "
                          "FROM v03_domain_references r JOIN v03_domain_sources s ON s.id=r.source_id ORDER BY r.id"):
        identity = row["reference_id"]
        if requested is not None and identity not in requested:
            continue
        if not public_source_permitted(row["rights"], row["url"]):
            if requested is not None:
                raise CoreError("domain_read_forbidden", "Quyền đọc nguồn công khai của kết quả đã bị thu hồi; chưa thể mở nội dung dẫn xuất.", 403)
            continue
        found.add(identity)
        try:
            record = json.loads(row["record_json"])
            if not isinstance(record, dict) or record.get("id") != identity or record.get("source_id") != row["reference_source_id"]:
                raise ValueError
            jurisdiction = record.get("scope", {}).get("jurisdiction")
            jurisdictions = [jurisdiction] if isinstance(jurisdiction, str) else jurisdiction
            if not isinstance(jurisdictions, list) or not jurisdictions or any(not isinstance(value, str) for value in jurisdictions):
                raise ValueError
            if not set(jurisdictions) <= set(market["jurisdictions"]):
                if requested is not None:
                    blocked.append({"reference_id": identity, "reason_code": "MARKET_SCOPE_MISMATCH"})
                continue
            if record.get("introduced_on", "0001-01-01") > as_of:
                if requested is not None:
                    blocked.append({"reference_id": identity, "reason_code": "NOT_YET_INTRODUCED"})
                continue
            excerpt = record["excerpt"]
            if not isinstance(excerpt, str) or hashlib.sha256(excerpt.encode()).hexdigest() != record["excerpt_sha256"]:
                raise ValueError
            if hashlib.sha256(row["text"].encode()).hexdigest() != row["content_sha256"]:
                raise ValueError
            def normalize(text):
                return re.sub(r"\s+", " ", text).strip()
            if normalize(excerpt) not in normalize(row["text"]):
                raise ValueError
            if not isinstance(record.get("topics"), list) or any(not isinstance(topic, str) for topic in record["topics"]):
                raise ValueError
            if record.get("excerpt_vi") is not None and not isinstance(record["excerpt_vi"], str):
                raise ValueError
        except (TypeError, ValueError, KeyError, AttributeError):
            blocked.append({"reference_id": identity, "reason_code": "REFERENCE_CONTRACT_INVALID"})
            continue
        record = {**record, "freshness_state": row["freshness_state"], "review_state": row["review_state"]}
        try:
            reason = record_applicability(record, market["code"], as_of)
        except CoreError:
            reason = "reference_contract_invalid"
        supersessions = [dict(item) for item in db.execute(
            "SELECT x.old_reference_id,x.new_reference_id,x.pack_id,x.effective_since,x.reason_vi,p.content_sha256 pack_hash "
            "FROM v03_domain_reference_supersessions x JOIN v03_domain_pack_installations p ON p.pack_id=x.pack_id "
            "WHERE x.old_reference_id=? AND x.effective_since<=? ORDER BY x.new_reference_id", (identity, as_of))]
        if supersessions:
            reason = reason or "reference_superseded"
        source_state = {key: row[key] for key in ("version", "content_sha256", "freshness_state", "rights", "observed_hash", "invalidated_at",
            "url", "title", "publisher", "accessed_at", "source_date")}
        source_ref = ref("export_public_source", row["reference_source_id"], digest(source_state))
        snapshot_ref = ref("export_source_snapshot", row["reference_source_id"] + ":" + row["content_sha256"], row["content_sha256"])
        excerpt_ref = ref("export_reference_excerpt", identity, record["excerpt_sha256"])
        status = "blocked" if reason else "bounded_reference"
        node(source_ref, rights=row["rights"], source_version=row["version"])
        node(snapshot_ref, authority_state="recorded_snapshot")
        node(excerpt_ref, scope={key: record["scope"][key] for key in ("jurisdiction", "product_family", "capabilities") if key in record["scope"]},
             market_code=market["code"], topics=record["topics"],
             status=status, reason_code=reason, review_state=row["review_state"], authority_state="reference_only",
             valid_from=record.get("valid_from"), valid_until=record.get("valid_until"), review_due_at=record.get("review_due_at"),
             original_language=record.get("original_language", record.get("language", "en")),
             translation_state=record.get("translation_state", "not_declared"),
             translated_excerpt_sha256=hashlib.sha256(record["excerpt_vi"].encode()).hexdigest() if record.get("excerpt_vi") else None)
        edge(excerpt_ref, "excerpt_of", snapshot_ref)
        edge(snapshot_ref, "snapshot_of", source_ref)
        refs = [source_ref, snapshot_ref, excerpt_ref]
        if record.get("excerpt_vi"):
            translation_ref = ref("export_reference_translation", identity + ":vi", hashlib.sha256(record["excerpt_vi"].encode()).hexdigest())
            node(translation_ref, language="vi", review_state=record.get("translation_state", "not_declared"),
                 authority_state="reference_translation_not_legal_approval")
            edge(excerpt_ref, "has_reference_translation", translation_ref, original_excerpt_hash=record["excerpt_sha256"])
            refs.append(translation_ref)
        declared_pack = record.get("pack_version")
        if isinstance(declared_pack, str) and declared_pack:
            installed = db.execute("SELECT content_sha256 FROM v03_domain_pack_installations WHERE pack_id=?", (declared_pack,)).fetchone()
            pack_ref = (ref("export_pack_version", declared_pack, installed[0]) if installed else
                        ref("export_pack_declaration", declared_pack, digest({"declared_pack_version": declared_pack})))
            node(pack_ref, authority_state="reference_pack_not_legal_approval" if installed else "declared_pack_without_sql_install_receipt")
            edge(excerpt_ref, "declares_reference_pack", pack_ref, basis="record.pack_version", installed=bool(installed))
            refs.append(pack_ref)
        for item in supersessions:
            pack_ref = ref("export_pack_version", item["pack_id"], item["pack_hash"])
            node(pack_ref, authority_state="reference_pack_not_legal_approval")
            successor = db.execute("SELECT r.record_json,r.source_id,s.rights,s.url FROM v03_domain_references r JOIN v03_domain_sources s "
                                   "ON s.id=r.source_id WHERE r.id=?", (item["new_reference_id"],)).fetchone()
            if successor and not public_source_permitted(successor["rights"], successor["url"]):
                successor = None
            if not successor:
                continue
            try:
                successor_record = json.loads(successor["record_json"])
                scope = successor_record.get("scope", {}).get("jurisdiction")
                scope = [scope] if isinstance(scope, str) else scope
                if not isinstance(scope, list) or not scope or not set(scope) <= set(market["jurisdictions"]):
                    continue
                successor_ref = ref("export_reference_excerpt", item["new_reference_id"], successor_record["excerpt_sha256"])
            except (ValueError, TypeError, KeyError):
                continue
            edge(successor_ref, "supersedes_export_excerpt", excerpt_ref, effective_since=item["effective_since"],
                 basis_pack=pack_ref, declared_only=True)
            refs.append(pack_ref)
        dependency = {"reference_id": identity, "refs": refs, "status": status, "reason_code": reason,
            "dependency_hash": digest({"version": GRAPH_VERSION, "market": market["code"], "as_of_date": as_of,
                "refs": refs, "record_hash": digest(record), "supersessions": supersessions, "reason": reason})}
        dependencies.append(dependency)
        if reason:
            blocked.append({"reference_id": identity, "reason_code": reason})
    if requested is not None:
        blocked.extend({"reference_id": identity, "reason_code": "REFERENCE_NOT_FOUND"} for identity in sorted(requested - found))
    nodes = sorted(nodes.values(), key=lambda item: json_text(item["ref"]))
    edges = sorted({json_text(value): value for value in edges}.values(), key=json_text)
    blocked = sorted(blocked, key=lambda item: (item["reference_id"], item["reason_code"]))
    return {"schema_version": GRAPH_VERSION, "domain": "export_reference", "market_code": market["code"], "as_of_date": as_of,
        "nodes": nodes, "edges": edges, "dependencies": dependencies, "blocked": blocked,
        "dependency_hash": digest({"version": GRAPH_VERSION, "market": market["code"], "as_of_date": as_of,
            "dependencies": dependencies, "blocked": blocked}), "writes": 0, "provider_calls": 0, "network_calls": 0,
        "authority": "existing_public_export_sql_records", "rebuildable": True, "legal_approval": False}
