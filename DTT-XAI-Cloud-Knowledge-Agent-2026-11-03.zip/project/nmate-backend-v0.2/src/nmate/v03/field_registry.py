"""P3 versioned business-field metadata; classification grants no authority.

Exact keys, values, entity IDs and historical assertions are never rewritten.
The registry describes observations; only existing owner/CAS/ACL commands can
promote them into SSOT. Financial observations are not sealed D05 metrics.
"""
from __future__ import annotations

from dataclasses import dataclass
import re
from types import MappingProxyType


REGISTRY_VERSION = "ssot-field-registry/1"
VALUE_CONTRACT_VERSION = "ssot-field-value/3"
SCOPE_COMPATIBILITY_VERSION = "ssot-field-scope/2"
MASS_UNITS = frozenset({"mg", "g", "kg", "µg", "μg", "ug", "mcg", "oz", "lb"})
QUANTITY_UNITS = MASS_UNITS | frozenset({"ml", "l", "fl oz"})
QUANTITY_NUMBER_PATTERN = r"\d{1,12}(?:[.,]\d{1,6})?"
FINANCIAL_FIELD_BASES = frozenset({
    "revenue", "annual_revenue", "turnover", "assets", "total_assets", "debt", "profit", "net_profit",
    "financial_period", "balance", "financial_metrics", "annual_sales", "annual_turnover", "liabilities",
    "total_liabilities", "employees", "employee_count", "annual_employee_count", "registered_capital",
    "owner_equity", "cost", "costs", "operating_cost", "cash_flow",
})
ENTITY_ALIASES = MappingProxyType({
    "company": "enterprise", "business": "enterprise", "organization": "enterprise",
    "production_facility": "facility", "market": "market_profile",
})
ENTITY_TYPES = frozenset({"enterprise", "product", "facility", "person", "document", "market_profile",
                          "shipment", "formula", "packaging", "financial_period", "enterprise_goal"})
LABEL_FACT_ALIASES = MappingProxyType({"allergens": "allergen_declaration"})


def base_field_key(field):
    """Classification only, never an exact permission lookup or storage key."""
    return field.split(".", 1)[0].casefold() if isinstance(field, str) else None


def field_is_financial(field):
    return isinstance(field, str) and (base_field_key(field) in FINANCIAL_FIELD_BASES
        or field.casefold().startswith(("finance.", "financial.", "revenue_", "assets_")))


_SCOPES = {
    "name": ENTITY_TYPES,
    **{field: frozenset({"enterprise"}) for field in (
        "legal_name", "trading_name", "legal_form", "enterprise_type", "business_type", "company_type", "tax_id",
        "registration_id", "registration_province", "registered_province", "province", "district",
        "headquarters_address", "industry", "business_sector", "business_activity", "sales_management", "inventory_management",
        "business_goal", "investment_goal")},
    **{field: frozenset({"product"}) for field in (
        "product_name", "product_code", "sku", "ingredients", "net_quantity", "net_weight", "origin",
        "origin_country", "allergens", "shelf_life", "storage", "storage_conditions", "manufacturer")},
    "packaging": frozenset({"product", "packaging"}),
    "packaging_material": frozenset({"product", "packaging"}),
    "certifications": frozenset({"enterprise", "facility", "product"}),
    "certificate": frozenset({"enterprise", "facility", "product"}),
    "address": frozenset({"enterprise", "facility", "person"}),
    **{field: frozenset({"facility"}) for field in (
        "facility_address", "facility_activity", "facility_name", "facility_type")},
    "market_code": frozenset({"market_profile", "shipment"}),
    **{field: frozenset({"market_profile"}) for field in (
        "allergen_declaration", "ingredients_declaration", "statement_of_identity", "responsible_business",
        "nutrition_information", "date_marking", "storage_instructions", "fda_registration_status")},
    "goal": frozenset({"enterprise", "enterprise_goal"}),
    **{field: frozenset({"enterprise", "financial_period"}) for field in FINANCIAL_FIELD_BASES},
}
_KINDS = {
    "name": "name", "product_name": "name", "trading_name": "name", "legal_name": "name", "facility_name": "name",
    "net_quantity": "quantity", "net_weight": "mass", "product_code": "product_code", "sku": "product_code",
    "employee_count": "count", "employees": "count", "annual_employee_count": "count",
    **{field: "text_or_list" for field in ("ingredients", "allergens", "certifications", "certificate")},
    **{field: "financial_observation" for field in FINANCIAL_FIELD_BASES
       - {"employees", "employee_count", "annual_employee_count"}},
}


@dataclass(frozen=True)
class FieldDefinition:
    base_field: str
    entity_types: frozenset[str]
    kind: str
    sensitivity: str
    confirmation_policy: str = "owner_required"
    qualifier_policy: str = "inherits_base_constraints_exact_acl"


FIELDS = MappingProxyType({field: FieldDefinition(field, scopes, _KINDS.get(field, "text"),
                          "finance" if field in FINANCIAL_FIELD_BASES else "business")
                          for field, scopes in _SCOPES.items()})
FIELD_ENTITY_TYPES = MappingProxyType({field: definition.entity_types for field, definition in FIELDS.items()})
FIELD_VALUE_KINDS = MappingProxyType({field: definition.kind for field, definition in FIELDS.items()})


def field_definition(field):
    """Opaque extensions retain exact grants; this function never registers one."""
    return FIELDS.get(base_field_key(field))


def value_schema(field):
    """Known-value schema. Null/no-op/clear are a separate command contract.

    Numeric quantities have a positive-decimal server check after JSON Schema;
    this schema does not promise unit conversion or make units interchangeable.
    """
    definition = field_definition(field)
    if definition is None:
        return None
    kind = definition.kind
    if kind in {"quantity", "mass"}:
        units = sorted(MASS_UNITS if kind == "mass" else QUANTITY_UNITS)
        # Exact spelling/case remains unchanged; the server classifier is case-insensitive.
        patterns = ["".join("[" + re.escape(char.lower() + char.upper()) + "]" if char.isascii() and char.isalpha()
                            else re.escape(char) for char in unit) for unit in units]
        # The final Decimal positivity guard remains server-owned, including
        # non-ASCII decimal glyphs; this pattern rejects the common zero form
        # without rejecting valid historical Unicode decimal observations.
        pattern = r"^\s*(?!0+(?:[.,]0+)?\s*[A-Za-zµμ])" + QUANTITY_NUMBER_PATTERN + r"\s*(?:" + "|".join(patterns) + r")\s*$"
        return {"type": "string", "minLength": 1, "pattern": pattern,
                "x-units": units, "x-server-validator": "positive_quantity_with_unit"}
    if kind == "count":
        return {"type": "integer", "minimum": 0}
    if kind == "product_code":
        return {"type": "string", "minLength": 1, "maxLength": 64,
                "x-server-validator": "unicode_product_code"}
    if kind == "financial_observation":
        # Historical observations have distinct scalar/object encodings. They
        # stay local; finance._metric and exact-value grants alone permit egress.
        return {"type": ["string", "integer", "number", "object", "array"],
                "x-egress": "not_authorized_by_field_contract"}
    text = {"type": "string", "minLength": 1, "maxLength": 250 if kind == "name" else 2000}
    if kind == "text_or_list":
        return {"anyOf": [text, {"type": "array", "maxItems": 30, "items": text}]}
    return text


def field_contract(field):
    definition = field_definition(field)
    if definition is None:
        return None
    return {"registry_version": REGISTRY_VERSION, "version": VALUE_CONTRACT_VERSION,
            "base_field": definition.base_field, "kind": definition.kind,
            "entity_types": sorted(definition.entity_types), "sensitivity": definition.sensitivity,
            "confirmation_policy": definition.confirmation_policy,
            "qualifier_policy": definition.qualifier_policy, "acl_policy": "exact_key_unchanged",
            "null_policy": "explicit_clear_separate", "value_schema": value_schema(field),
            "state_contract": fact_state_contract(), "advisories": ["ounce_mass", "ounce_volume"]
            if definition.kind in {"quantity", "mass"} else []}


def fact_state_contract():
    return {"version": "ssot-fact-action/1", "unknown_null": "no_op",
            "known_null": "no_op", "known_falsy": "set_preserve_exact_value",
            "explicit_clear": "requires_null_value_and_existing_write_authority",
            "known_absent": "explicit_state_distinct_from_unknown",
            "states": ["known", "unknown", "known_absent", "not_applicable", "withheld", "conflicted"]}


class FactActionError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code
        self.message_vi = message


@dataclass(frozen=True)
class FactAction:
    action: str
    value_state: str
    explicit_clear: bool


def classify_fact_action(item):
    """Interpret a command, without choosing a target, version, ACL or value."""
    value = item.get("value")
    state = item.get("value_state", "known" if value is not None else "unknown")
    if not isinstance(state, str) or state not in fact_state_contract()["states"]:
        raise FactActionError("invalid_state", "Trạng thái dữ kiện không hợp lệ.")
    if "explicit_clear" in item and not isinstance(item["explicit_clear"], bool):
        raise FactActionError("invalid_fact_action", "Lệnh xóa dữ kiện cần xác nhận đúng hoặc sai rõ ràng.")
    clear = item.get("explicit_clear") is True
    if clear and value is not None:
        raise FactActionError("conflicting_fact_action", "Không thể vừa đặt giá trị vừa xóa cùng một dữ kiện. Hãy chọn một thao tác.")
    if value is None and not clear and state in {"known", "unknown"}:
        return FactAction("noop", state, False)
    if clear:
        state = state if state in {"known_absent", "not_applicable", "withheld", "conflicted"} else "unknown"
    elif state != "known" and value is not None:
        raise FactActionError("invalid_fact", "Trạng thái chưa xác định không được có giá trị.")
    return FactAction("clear" if clear else "set" if state == "known" else "state", state, clear)


# Adapter declarations describe only the existing bounded ingestion vocabulary.
# Adding a field to the global registry does not silently enable it in imports.
_INGESTION = {
    "trading_name": ("Tên cơ sở (tên giao dịch)", "enterprise", "string"),
    "name": ("Tên sản phẩm", "product", "string"),
    "product_code": ("Mã sản phẩm", "product", "string"),
    "net_quantity": ("Lượng tịnh", "product", "string"),
    "packaging": ("Bao bì", "product", "string"),
    "ingredients": ("Thành phần đã khai", "product", "string"),
    "origin_country": ("Xuất xứ đã khai", "product", "string"),
    "sales_management": ("Quản lý bán hàng", "enterprise", "string"),
    "inventory_management": ("Quản lý tồn kho", "enterprise", "string"),
    "employee_count": ("Số lao động", "enterprise", "integer"),
    "revenue": ("Doanh thu theo kỳ", "enterprise", "object"),
    "business_goal": ("Mục tiêu doanh nghiệp", "enterprise", "string"),
}
INGESTION_FIELD_SPECS = MappingProxyType(_INGESTION)


def adapter_contract(adapter="bounded_local_ingestion"):
    if adapter != "bounded_local_ingestion":
        raise ValueError("Unknown field adapter")
    return {"registry_version": REGISTRY_VERSION, "adapter": adapter,
            "fields": {field: {"label_vi": spec[0], "entity_type": spec[1], "json_type": spec[2],
                                "field_contract": field_contract(field)}
                       for field, spec in INGESTION_FIELD_SPECS.items()},
            "unknown_fields": "not_enabled_by_registry"}


FINANCE_METRIC_LABELS = MappingProxyType({
    "revenue": "Doanh thu", "annual_revenue": "Doanh thu năm", "turnover": "Doanh thu",
    "cost": "Chi phí", "costs": "Chi phí", "operating_cost": "Chi phí hoạt động",
    "assets": "Tổng tài sản", "total_assets": "Tổng tài sản", "debt": "Nợ phải trả",
    "total_liabilities": "Nợ phải trả", "profit": "Lợi nhuận", "net_profit": "Lợi nhuận sau thuế",
    "cash_flow": "Dòng tiền", "employee_count": "Số lao động", "employees": "Số lao động",
})
FINANCE_COUNT_METRICS = frozenset({"employee_count", "employees"})
FINANCE_NEGATIVE_METRICS = frozenset({"profit", "net_profit", "cash_flow"})
FINANCE_CURRENCY_UNITS = frozenset({"VND", "USD", "EUR", "JPY"})
FINANCE_PERSON_UNITS = frozenset({"person", "persons", "người"})
FINANCE_DECIMAL_PATTERN = r"-?\d{1,24}(?:\.\d{1,8})?"
FINANCE_SCOPES = frozenset({"enterprise", "consolidated", "facility", "product"})


def finance_metric_contract(code):
    if code not in FINANCE_METRIC_LABELS:
        return None
    return {"registry_version": REGISTRY_VERSION, "adapter": "sealed_financial_metric/1", "metric_code": code,
            "json_type": "string", "decimal_pattern": FINANCE_DECIMAL_PATTERN,
            "units": sorted(FINANCE_PERSON_UNITS if code in FINANCE_COUNT_METRICS else FINANCE_CURRENCY_UNITS),
            "negative_allowed": code in FINANCE_NEGATIVE_METRICS,
            "whole_number_required": code in FINANCE_COUNT_METRICS,
            "maximum": 1_000_000 if code in FINANCE_COUNT_METRICS else None,
            "scope": sorted(FINANCE_SCOPES),
            "unknown": "local_only_not_egress", "egress": "exact_metric_grant_seal_required"}
