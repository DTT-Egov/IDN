"""Literal private drafts survive unrelated context changes without becoming facts."""
from copy import deepcopy

from .field_scope import LABEL_FACT_ALIASES


DEPENDENCIES = {
    "statement_of_identity": ("statement_of_identity",),
    "net_quantity": ("net_quantity",),
    "ingredients": ("ingredients",),
    "ingredients_declaration": ("ingredients_declaration", "ingredients", "processing_description"),
    "responsible_business": ("responsible_business",),
    "nutrition_information": ("nutrition_information", "ingredients", "net_quantity"),
    "allergens": ("allergen_declaration", "allergens", "ingredients", "processing_description"),
    "date_marking": ("date_marking",),
    "storage_instructions": ("storage_instructions",),
}


def literal(value):
    if value is None:
        return None
    return ", ".join(str(item) for item in value) if isinstance(value, list) else str(value)


def facts(context):
    return {f["field"]: f for entity in context.get("entities", []) for f in entity.get("facts", [])}


def values(context):
    """A display projection, never a destination for persisting mixed-scope facts."""
    return context.get("values", {key: value for entity in context.get("entities", [])
                                  for key, value in entity.get("values", {}).items()})


def basis(context, fields):
    current = facts(context)
    refs = {r["field"]: r for r in context.get("fact_refs", [])}
    return {key: {"version": refs.get(key, {}).get("version", 0),
                  "assertion_id": refs.get(key, {}).get("assertion_id"),
                  "freshness_state": current.get(key, {}).get("freshness_state", "unknown")}
            for key in fields}


def reconcile(data, original_context, current_context, *, fill_missing=False):
    """Expose conflicts rather than overwrite user work or bless changed facts."""
    value = deepcopy(data)
    current = facts(current_context)
    known = values(current_context)
    for field in value["fields"]:
        key = field["id"]
        storage_key = LABEL_FACT_ALIASES.get(key, key) if "label_fact_aliases" in current_context else key
        if value.get("market_code") in {"DE", "JP"} and key == "ingredients":
            # A readonly projection of the canonical recipe is not label prose.
            # Changing recipe facts never overwrites translated declarations.
            field.update(value=literal(known.get(key)), conflict=None, choice=None,
                         basis_refs=basis(current_context, DEPENDENCIES[key]),
                         label_en="Nguyên liệu gốc chưa dịch", label_vi="Thành phần sản phẩm đã khai · dùng chung",
                         state="needs_review" if known.get(key) is not None else "needs_input",
                         provenance={"kind": "enterprise_ssot", "scope": "shared_product", "verification_state": "self_declared", "translation_state": "original_user_value_untranslated"})
            continue
        old_basis = field.get("basis_refs") or basis(original_context, DEPENDENCIES[key])
        new_basis = basis(current_context, DEPENDENCIES[key])
        changed = [name for name in DEPENDENCIES[key] if old_basis.get(name) != new_basis[name]]
        ssot = literal(known.get(key))
        expired = any(current.get(name, {}).get("freshness_state") in {"expired", "not_yet_effective"} for name in DEPENDENCIES[key])
        mismatch = storage_key in current and field["value"] != ssot
        unresolved = field.get("conflict") is not None
        if field["value"] is not None and (unresolved or expired or (changed and (mismatch or any(name != storage_key for name in changed))) or (mismatch and not field.get("choice"))):
            field["conflict"] = {"reason": "ssot_changed" if changed else "ssot_mismatch",
                "draft_value": field["value"], "ssot_value": ssot,
                "ssot_fact_version": current.get(storage_key, {}).get("version", 0),
                "changed_fields": changed}
            field["state"] = "needs_review"
        else:
            field["conflict"] = None
            field["basis_refs"] = new_basis
            if fill_missing and field["value"] is None and ssot is not None:
                field["value"], field["state"] = ssot, "self_declared"
                field["provenance"] = {"kind": "enterprise_ssot", "assertion_id": current[storage_key]["assertion_id"], "verification_state": "self_declared"}
    return value
