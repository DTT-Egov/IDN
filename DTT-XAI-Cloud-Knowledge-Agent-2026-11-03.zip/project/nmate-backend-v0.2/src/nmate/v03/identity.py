"""Local credentials and opaque revocable sessions; no mail or identity provider."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import re
import secrets
import sqlite3

from .core import CoreError, new_id, now_iso


_ITERATIONS = 600_000
_DUMMY_SALT = bytes.fromhex("46f344b1ace4028bc7a9d54a33850aaa")


def _password_digest(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _ITERATIONS).hex()


def _hash_password(password):
    salt = secrets.token_bytes(24)
    return f"pbkdf2_sha256${_ITERATIONS}${salt.hex()}${_password_digest(password, salt)}"


def _verify_password(password, encoded):
    if not isinstance(password, str) or len(password) > 1024:
        return False
    try:
        scheme, iterations, salt, digest = encoded.split("$")
        if scheme != "pbkdf2_sha256" or int(iterations) != _ITERATIONS:
            return False
        actual = _password_digest(password, bytes.fromhex(salt))
        return hmac.compare_digest(actual, digest)
    except (ValueError, TypeError):
        return False


def _token_hash(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


class LocalAccounts:
    def __init__(self, repo, session_hours=24):
        self.repo = repo
        self.session_hours = min(max(session_hours, 1), 168)

    @staticmethod
    def _username(username):
        if not isinstance(username, str):
            raise CoreError("invalid_username", "Tên đăng nhập không hợp lệ.")
        username = username.strip().casefold()
        if not re.fullmatch(r"[a-z0-9][a-z0-9_.@+-]{2,99}", username):
            raise CoreError("invalid_username", "Tên đăng nhập cần 3–100 ký tự; có thể dùng địa chỉ email làm tên tài khoản local.")
        return username

    def register(self, username, password, enterprise_name, *, db=None):
        username = self._username(username)
        if not isinstance(password, str) or not 10 <= len(password) <= 1024:
            raise CoreError("weak_password", "Mật khẩu cần từ 10 đến 1024 ký tự.")
        if not isinstance(enterprise_name, str) or not enterprise_name.strip() or len(enterprise_name) > 250:
            raise CoreError("invalid_enterprise", "Cần tên doanh nghiệp từ 1 đến 250 ký tự.")
        password_hash = _hash_password(password)
        account_id, enterprise_id = new_id("account"), new_id("enterprise")
        try:
            with self.repo._fact_transaction(db) as db:
                db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES (?,?,?,?)",
                           (account_id, username, password_hash, now_iso()))
                db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES (?,?,?)",
                           (enterprise_id, enterprise_name, now_iso()))
                db.execute("INSERT INTO v03_memberships(account_id,enterprise_id,role) VALUES (?,?,'owner')",
                           (account_id, enterprise_id))
        except sqlite3.IntegrityError as exc:
            raise CoreError("username_taken", "Tên đăng nhập đã được sử dụng.", 409) from exc
        return {"account_id": account_id, "username": username, "enterprise_id": enterprise_id,
                "enterprise_name": enterprise_name, "role": "owner"}

    def login(self, username, password):
        try:
            username = self._username(username)
        except CoreError:
            username = ""
        with self.repo.connection() as db:
            row = db.execute("SELECT * FROM v03_accounts WHERE username=? AND active=1", (username,)).fetchone()
            if row is None:
                # Keep a missing account on the same expensive path as a bad password.
                _password_digest(password if isinstance(password, str) and len(password) <= 1024 else "", _DUMMY_SALT)
                raise CoreError("invalid_credentials", "Tên đăng nhập hoặc mật khẩu không đúng.", 401)
            if not _verify_password(password, row["password_hash"]):
                raise CoreError("invalid_credentials", "Tên đăng nhập hoặc mật khẩu không đúng.", 401)
            memberships = list(db.execute("SELECT m.enterprise_id,m.role,e.name enterprise_name FROM v03_memberships m "
                                         "JOIN v03_enterprises e ON e.id=m.enterprise_id WHERE account_id=? "
                                         "AND m.active=1 AND m.role IN ('owner','staff') ORDER BY e.created_at,e.id", (row["id"],)))
            if not memberships:
                raise CoreError("forbidden", "Tài khoản chưa có doanh nghiệp được phép truy cập.", 403)
            first = dict(memberships[0])
            return {"account_id": row["id"], "username": row["username"], **first,
                    "enterprises": [dict(m) for m in memberships]}

    def create_session(self, account_id):
        token, csrf = secrets.token_urlsafe(48), secrets.token_urlsafe(32)
        expires = (datetime.now(timezone.utc) + timedelta(hours=self.session_hours)).isoformat()
        with self.repo.connection(write=True) as db:
            row = db.execute("SELECT id FROM v03_accounts WHERE id=? AND active=1", (account_id,)).fetchone()
            if row is None:
                raise CoreError("unauthenticated", "Cần đăng nhập lại.", 401)
            db.execute("DELETE FROM v03_sessions WHERE expires_at<=?", (now_iso(),))
            db.execute("INSERT INTO v03_sessions VALUES (?,?,?,?,?)",
                       (_token_hash(token), account_id, _token_hash(csrf), now_iso(), expires))
        return {"token": token, "csrf_token": csrf, "expires_at": expires, "account_id": account_id}

    def get_session(self, token):
        if not isinstance(token, str) or not 30 <= len(token) <= 200:
            raise CoreError("unauthenticated", "Cần đăng nhập để tiếp tục.", 401)
        with self.repo.connection() as db:
            row = db.execute("SELECT s.account_id,s.expires_at,a.username FROM v03_sessions s JOIN v03_accounts a "
                             "ON a.id=s.account_id WHERE s.token_hash=? AND s.expires_at>? AND a.active=1",
                             (_token_hash(token), now_iso())).fetchone()
            if row is None:
                raise CoreError("unauthenticated", "Phiên đăng nhập đã hết hạn. Cần đăng nhập lại.", 401)
            memberships = list(db.execute("SELECT m.enterprise_id,m.role,e.name enterprise_name FROM v03_memberships m "
                                         "JOIN v03_enterprises e ON e.id=m.enterprise_id WHERE m.account_id=? "
                                         "AND m.active=1 AND m.role IN ('owner','staff') ORDER BY e.created_at,e.id", (row["account_id"],)))
            if not memberships:
                raise CoreError("forbidden", "Quyền truy cập đã được thu hồi.", 403)
            return {**dict(row), **dict(memberships[0]), "enterprises": [dict(m) for m in memberships]}

    def validate_csrf(self, token, csrf_token):
        session = self.get_session(token)
        if not isinstance(csrf_token, str) or len(csrf_token) > 200:
            raise CoreError("csrf_failed", "Không xác thực được thao tác. Hãy tải lại trang.", 403)
        with self.repo.connection() as db:
            row = db.execute("SELECT csrf_hash FROM v03_sessions WHERE token_hash=? AND expires_at>?",
                             (_token_hash(token), now_iso())).fetchone()
            if row is None or not hmac.compare_digest(row["csrf_hash"], _token_hash(csrf_token)):
                raise CoreError("csrf_failed", "Không xác thực được thao tác. Hãy tải lại trang.", 403)
        return session

    def logout(self, token):
        if isinstance(token, str) and len(token) <= 200:
            with self.repo.connection(write=True) as db:
                db.execute("DELETE FROM v03_sessions WHERE token_hash=?", (_token_hash(token),))
        return {"status": "logged_out"}

    def change_password(self, account_id, current_token, current_password, new_password):
        """Explicit user command; verifies current secret and revokes other sessions.

        No password, digest or token is returned, logged or put in an operation
        receipt. Existing memberships, approvals, SSOT and the current CSRF are
        preserved. The HTTP adapter performs origin+CSRF checks before this.
        """
        if not isinstance(new_password, str) or not 10 <= len(new_password) <= 1024:
            raise CoreError("weak_password", "Mật khẩu mới cần từ 10 đến 1024 ký tự.")
        token_hash = _token_hash(current_token)
        with self.repo.connection(write=True) as db:
            row = db.execute("SELECT a.password_hash FROM v03_accounts a JOIN v03_sessions s ON s.account_id=a.id WHERE a.id=? AND a.active=1 AND s.token_hash=? AND s.expires_at>?",
                             (account_id, token_hash, now_iso())).fetchone()
            if row is None:
                raise CoreError("unauthenticated", "Phiên đăng nhập đã hết hạn. Chị đăng nhập lại.", 401)
            if not _verify_password(current_password, row["password_hash"]):
                raise CoreError("invalid_current_password", "Mật khẩu hiện tại chưa đúng; chưa thay đổi mật khẩu.", 403)
            if _verify_password(new_password, row["password_hash"]):
                raise CoreError("password_unchanged", "Mật khẩu mới cần khác mật khẩu hiện tại.")
            db.execute("UPDATE v03_accounts SET password_hash=? WHERE id=?", (_hash_password(new_password), account_id))
            db.execute("DELETE FROM v03_sessions WHERE account_id=? AND token_hash!=?", (account_id, token_hash))
        return {"status": "password_changed", "other_sessions_revoked": True,
                "message_vi": "Đã đổi mật khẩu. Những phiên đăng nhập khác đã được đăng xuất."}
