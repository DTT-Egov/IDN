"""LangGraph DAG execution. Nodes have no provider or external-network capability."""
from __future__ import annotations

from typing import Annotated, TypedDict

from langgraph.graph import END, START, StateGraph


def merge_results(left, right):
    return {**left, **right}


class WorkflowState(TypedDict):
    mission_id: str
    task_results: Annotated[dict, merge_results]


def build_graph(service, mission):
    """Compile only registered tasks; the persisted ledger remains authoritative.

    Checkpoints are intentionally not represented as durable business state. A
    process interruption is exposed by recover_interrupted; it is never silently
    interpreted as permission to replay a model request.
    """
    graph = StateGraph(WorkflowState)
    tasks = mission["plan"]["tasks"]

    async def gate(state):
        service.execution_guard(state["mission_id"])
        return {}

    graph.add_node("context_gate", gate)
    graph.add_edge(START, "context_gate")
    for task in tasks:
        async def node(state, current_task=task):
            result = await service.execute_task(state["mission_id"], current_task, state["task_results"])
            return {"task_results": {current_task["id"]: result}}

        graph.add_node(task["id"], node)
        dependencies = task["depends_on"]
        graph.add_edge(dependencies if dependencies else "context_gate", task["id"])
    leaves = [task["id"] for task in tasks if not any(task["id"] in other["depends_on"] for other in tasks)]

    async def publish(state):
        service.publish(state["mission_id"], state["task_results"])
        return {}

    graph.add_node("publish", publish)
    graph.add_edge(leaves, "publish")
    graph.add_edge("publish", END)
    return graph.compile()
