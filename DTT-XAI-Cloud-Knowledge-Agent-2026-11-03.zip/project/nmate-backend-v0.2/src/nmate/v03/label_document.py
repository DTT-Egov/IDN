"""Vietnamese document rendering for newly created label revisions only."""
import hashlib


DOCUMENT_FORMAT_VERSION = "label-markdown-vi-v2"
UNKNOWN_VALUE_VI = "[Chưa cung cấp dữ kiện hoặc chưa xác định phạm vi áp dụng]"
LANGUAGES = {"en": "tiếng Anh", "de": "tiếng Đức", "ja": "tiếng Nhật"}


def render_label_document(data):
    language = LANGUAGES[data["label_language"]]
    lines = [f"# Khung nhãn {language} — {data['market_name_vi']} — bản nháp chưa duyệt", "",
             f"Sản phẩm do doanh nghiệp khai: {data['product_reference']}", "",
             "Hướng dẫn bằng tiếng Việt; giá trị do doanh nghiệp khai được giữ nguyên.", ""]
    originals = []
    for field in data["fields"]:
        if data["market_code"] != "US" and field["id"] == "ingredients":
            lines.extend(["## Dữ kiện tham chiếu — nguyên liệu gốc chưa dịch",
                          field["value"] if field["value"] is not None else "[Chưa khai công thức gốc]",
                          "Dữ kiện sản phẩm dùng chung; không phải dòng thành phần đã hoàn thiện để in nhãn.", ""])
            continue
        lines.extend([f"## {field['label_vi']}",
                      field["value"] if field["value"] is not None else UNKNOWN_VALUE_VI,
                      field["help_vi"], ""])
        if field["label_en"] != field["label_vi"]:
            originals.append((field["label_vi"], field["label_en"]))
    lines.extend([data["limitations_vi"], ""])
    if originals:
        lines.extend([f"## Đối chiếu tên mục nguyên bản ({language})", "",
                      "Tên mục nguyên bản dùng để đối chiếu khi chuẩn bị nhãn cho thị trường này.", "",
                      "| Hướng dẫn tiếng Việt | Tên mục nguyên bản |", "|---|---|"])
        for vietnamese, original in originals:
            # Both labels come from the bounded field registry, never the model.
            cells = [value.replace("|", r"\|") for value in (vietnamese, original)]
            lines.append("| " + " | ".join(cells) + " |")
    markdown = "\n".join(lines)
    return {"document_format_version": DOCUMENT_FORMAT_VERSION, "markdown": markdown,
            "markdown_sha256": hashlib.sha256(markdown.encode("utf-8")).hexdigest()}
