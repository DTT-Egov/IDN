"""Excerpt identities shared by deterministic and model-backed research.

Page IDs are never citeable excerpt IDs. No fuzzy lookup or output repair.
This validates provenance, not legal entailment of a generated statement.
"""
from copy import deepcopy
from datetime import date
import hashlib
import re

from .core import CoreError
from .markets import get_market, normalize_text

TOPICS = {"registration": "facility_registration", "label": "food_label", "prior_notice": "prior_notice"}
EU_OPERATOR_REFERENCE = "EU_LABEL_OPERATOR_VI_20261018_DRAFT"
EU_OPERATOR_EXCERPT_SHA256 = "89ebc58ef576ebb1a207d7a7e003c4e16892e1737f1d2fe89297b97796c84a04"
SUPPLEMENTARY_POLICY = "eu-food-information-operator-support-v1"


def _asks_operator_role(text):
    value = normalize_text(text)
    focused = re.split(r"\b(?:chi hoi|chi can|chi muon|only ask|only need)\b", value)
    value = focused[-1]
    value = re.sub(r"\b(?:khong hoi|khong can|khong muon)\b[^,;.?!]*", "", value)
    return bool(re.search(r"\b(?:vai tro (?:cua )?(?:don vi chiu trach nhiem|nha nhap khau)|"
                          r"(?:don vi|ben) chiu trach nhiem|trach nhiem thong tin thuc pham|"
                          r"responsible food business operator|importer role)\b", value))


def _eu_operator_supplement(record, quote, outcome_id, market_code, question_part, question):
    """One curated supporting clause, never a generic cross-topic exception."""
    return (market_code == "DE" and outcome_id == "registration"
            and record["id"] == EU_OPERATOR_REFERENCE
            and record.get("source_id") == "eu_1169_food_information"
            and record.get("source_version") == 1
            and "food_label" in record["topics"]
            and record.get("excerpt_sha256") == EU_OPERATOR_EXCERPT_SHA256
            and quote == record["excerpt"]
            and isinstance(question_part, str) and bool(question_part)
            and isinstance(question, str) and question_part in question
            and _asks_operator_role(question_part) and _asks_operator_role(question))


def outcome_topic(outcome_id, market_code=None):
    """A US prior notice source cannot establish an EU/Japan notification rule."""
    if market_code not in {"US", "DE", "JP"}:
        return None
    if outcome_id == "prior_notice" and market_code != "US":
        return None
    return TOPICS.get(outcome_id)


def citation_contract(schema, records):
    """One identity namespace in model input and a closed set in the schema."""
    result = deepcopy(schema)
    property_ = result["$defs"]["Citation"]["properties"]["source_id"]
    property_["enum"] = sorted({record["id"] for record in records})
    property_["description"] = "Mã trích đoạn: sao chép chính xác reference_records[].id; không dùng mã trang hay URL."
    projection = [{key: value for key, value in record.items() if key != "source_id"}
                  for record in records]
    return result, projection


def evidence_date(as_of_date=None):
    if as_of_date is None:
        return date.today()
    if isinstance(as_of_date, date):
        return as_of_date
    try:
        return date.fromisoformat(str(as_of_date))
    except (TypeError, ValueError):
        raise CoreError("invalid_as_of_date", "Ngày đối chiếu nguồn phải có dạng YYYY-MM-DD.") from None


def record_applicability(record, market_code=None, as_of_date=None):
    """Fail closed on explicit foreign scope, withdrawal and recorded validity."""
    if market_code is not None:
        allowed = set(get_market(market_code)["jurisdictions"])
        jurisdiction = record.get("scope", {}).get("jurisdiction")
        jurisdictions = [jurisdiction] if isinstance(jurisdiction, str) else jurisdiction
        if not isinstance(jurisdictions, list) or not jurisdictions or not set(jurisdictions).issubset(allowed):
            return "market_mismatch"
    if record.get("review_state") in {"revoked", "withdrawn", "rejected"} or record.get("revoked_at"):
        return "revoked"
    if record.get("freshness_state", "recorded_snapshot") not in {"recorded_snapshot", "reviewed_current"}:
        return "needs_revalidation"
    today = evidence_date(as_of_date)
    for field in ("valid_from", "valid_until", "review_due_at"):
        if not record.get(field):
            continue
        boundary = evidence_date(record[field])
        if field == "valid_from" and today < boundary:
            return "not_yet_effective"
        if field == "valid_until" and today > boundary:
            return "expired"
        if field == "review_due_at" and today > boundary:
            return "review_overdue"
    return None


def validate_citation(reference_id, quote_en=None, records=None, outcome_id=None, *,
                      expected_market_code=None, as_of_date=None, quote_original=None,
                      outcome_question_part=None, question=None):
    """Return canonical evidence metadata only after exact binding succeeds."""
    record = next((r for r in (records or []) if r["id"] == reference_id), None)
    if record is None:
        raise CoreError("live_output_invalid", "AI gắn nhầm nguồn trích dẫn; kết quả chưa được công bố. Không tự gửi lại.", 502)
    applicability = record_applicability(record, expected_market_code, as_of_date)
    if applicability == "market_mismatch":
        raise CoreError("evidence_market_mismatch", "Nguồn trích dẫn không thuộc phạm vi thị trường của hồ sơ; chưa công bố kết quả.", 409)
    if record.get("reusable") is not True or applicability:
        raise CoreError("evidence_stale", "Nguồn trích dẫn đã thay đổi; cần rà lại trước khi công bố.", 409)
    excerpt = record["excerpt"]
    if quote_original is not None and quote_en is not None and quote_original != quote_en:
        raise CoreError("live_output_invalid", "Hai trường nguyên văn trích dẫn không khớp nhau; chưa công bố kết quả.", 502)
    quote = quote_original if quote_original is not None else quote_en
    if not isinstance(quote, str) or not 20 <= len(quote) <= 1200 or quote not in excerpt:
        raise CoreError("live_output_invalid", "Trích dẫn AI không khớp nguyên văn nguồn được phép dùng.", 502)
    topic = outcome_topic(outcome_id, expected_market_code or record.get("market_code"))
    supplementary = _eu_operator_supplement(record, quote, outcome_id, expected_market_code,
                                            outcome_question_part, question)
    if topic is None or topic not in record["topics"] and not supplementary:
        raise CoreError("live_output_invalid", "Nguồn AI trích dẫn chưa phù hợp với ý đang trả lời; kết quả chưa được công bố. Không tự gửi lại.", 502)
    excerpt_hash = hashlib.sha256(excerpt.encode()).hexdigest()
    if record.get("excerpt_sha256") != excerpt_hash:
        raise CoreError("evidence_integrity", "Trích đoạn không khớp bản nguồn đã lưu; chưa công bố kết quả.", 409)
    language = record.get("original_language", record.get("language", "en"))
    result = {"reference_id": reference_id, "page_source_id": record["source_id"],
            "quote_original": quote, "original_language": language, "language": language,
            "excerpt_sha256": excerpt_hash,
            "source_version": record["source_version"],
            "review_state": record.get("review_state", "reference_unreviewed"),
            "jurisdiction": record.get("scope", {}).get("jurisdiction"),
            "market_code": get_market(expected_market_code)["code"] if expected_market_code is not None else record.get("market_code")}
    if language == "en":
        result["quote_en"] = quote
    if supplementary:
        result.update(evidence_role="supplementary", supplementary_scope="eu_food_information_responsible_operator",
                      citation_policy=SUPPLEMENTARY_POLICY)
    return result


def validate_answer_citations(citations, *, records, outcome_id, expected_market_code,
                              outcome_question_part=None, question=None):
    """Bind every citation, then require a separate primary for any supplement."""
    bound = [validate_citation(citation["source_id"], records=records, outcome_id=outcome_id,
             quote_original=citation["quote_original"], expected_market_code=expected_market_code,
             outcome_question_part=outcome_question_part, question=question) for citation in citations]
    if any(citation.get("evidence_role") == "supplementary" for citation in bound) and not any(
            citation.get("evidence_role", "primary") == "primary" for citation in bound):
        raise CoreError("evidence_primary_required", "Nguồn bổ trợ về trách nhiệm thông tin không thay căn cứ chính về điều kiện cơ sở và nhập khẩu.", 502)
    return bound


def bind_answer_citations(answers, records, *, expected_market_code=None, as_of_date=None):
    """Deterministic answers bind actual saved excerpts, never page aliases."""
    by_id = {record["id"]: record for record in records}
    bound = []
    for answer in answers:
        ids = answer.get("source_ids", [])
        if len(ids) != len(set(ids)):
            raise CoreError("evidence_duplicate", "Nguồn trích dẫn bị lặp; chưa công bố kết quả.", 502)
        citations = []
        for reference_id in ids:
            record = by_id.get(reference_id)
            quote = record["excerpt"] if record else ""
            citations.append(validate_citation(reference_id, records=records, outcome_id=answer["outcome_id"],
                                               quote_original=quote, expected_market_code=expected_market_code,
                                               as_of_date=as_of_date))
        if answer.get("status") != "blocked_source" and not citations:
            raise CoreError("evidence_missing", "Nhận định chưa có trích đoạn đối chiếu; chưa công bố kết quả.", 502)
        bound.append({**answer, "citations": citations})
    return bound
