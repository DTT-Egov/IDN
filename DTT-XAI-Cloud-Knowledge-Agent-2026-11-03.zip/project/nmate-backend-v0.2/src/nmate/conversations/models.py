"""Conversation transport and model output contracts; no arbitrary tools or patch paths."""
from typing import Literal
from math import isfinite

from pydantic import Field, StrictBool, StrictFloat, StrictInt, StrictStr, field_validator, model_validator

from ..models import CaseFactField, Shipment, StartInput, StrictModel


class DraftProduct(StrictModel):
    sku: str | None = Field(default=None, min_length=1, max_length=100)
    name: str | None = Field(default=None, min_length=1, max_length=200)
    family: Literal["dry_food"] = "dry_food"
    ingredients: list[str] | None = Field(default=None, max_length=30)
    processing_description: str | None = Field(default=None, max_length=1000)
    packaging: str | None = Field(default=None, max_length=300)
    shelf_life: str | None = Field(default=None, max_length=200)
    certifications: list[str] | None = Field(default=None, max_length=30)
    origin_country: Literal["VN"] = "VN"


class FieldSource(StrictModel):
    message_id: str
    source_quote: str
    certainty: Literal["provided", "estimate"]
    confirmed: bool = False


class ConversationDraft(StrictModel):
    product: DraftProduct = Field(default_factory=DraftProduct)
    shipment: Shipment = Field(default_factory=Shipment)
    question: str = Field(default="", max_length=2000)
    uncertain_fields: list[str] = Field(default_factory=list, max_length=30)
    field_sources: dict[str, FieldSource] = Field(default_factory=dict)


class ConversationCreate(StrictModel):
    consent_model: bool
    consent_storage: bool


class MessageInput(StrictModel):
    message: str = Field(min_length=1, max_length=2000)
    idempotency_key: str = Field(min_length=8, max_length=128)
    expected_version: int = Field(ge=1)
    artifact_id: str | None = Field(default=None, min_length=1, max_length=128)


class ConfirmInput(StrictModel):
    expected_version: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128)


class ResearchCaseInput(ConfirmInput):
    processing_level: Literal["auto", "standard", "complex"] = "auto"


class ManualFactChange(StrictModel):
    """An explicit field edit, not model extraction or an arbitrary JSON patch."""
    field: CaseFactField
    value: StrictStr | StrictInt | StrictFloat | list[StrictStr] | None
    certainty: Literal["provided", "estimate"] = "provided"

    @model_validator(mode="after")
    def valid_field_value(self):
        if self.field == "question":
            if not isinstance(self.value, str) or not self.value.strip() or len(self.value) > 2000:
                raise ValueError("Câu hỏi cần có nội dung, tối đa 2000 ký tự.")
            self.value = self.value.strip()
            return self
        section, key = self.field.split(".")
        model = DraftProduct if section == "product" else Shipment
        # Strict per-field types prevent numbers becoming text, fractional carton
        # counts, booleans or string numbers being silently accepted as user facts.
        validated = model.model_validate({key: self.value}, strict=True)
        self.value = getattr(validated, key)
        if isinstance(self.value, str) and not self.value:
            raise ValueError("Dùng null cho dữ kiện chưa biết, không dùng chuỗi rỗng.")
        if isinstance(self.value, list) and any(not item.strip() for item in self.value):
            raise ValueError("Mỗi mục dữ kiện cần có nội dung.")
        return self


class FactsInput(StrictModel):
    expected_version: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128)
    changes: list[ManualFactChange] = Field(min_length=1, max_length=20)
    same_product_correction: StrictBool = False

    @model_validator(mode="after")
    def distinct_fields(self):
        if len({change.field for change in self.changes}) != len(self.changes):
            raise ValueError("Mỗi dữ kiện chỉ được sửa một lần trong một yêu cầu.")
        return self


class LinkInput(StrictModel):
    expected_version: int = Field(ge=1)
    case_id: str = Field(min_length=1, max_length=128)
    case_version: int = Field(ge=1)
    run_id: str | None = Field(default=None, min_length=1, max_length=128)
    artifact_id: str | None = Field(default=None, min_length=1, max_length=128)


FactField = CaseFactField


class FactChange(StrictModel):
    field: FactField
    value: StrictStr | StrictInt | StrictFloat | list[StrictStr] | None
    source_quote: str = Field(min_length=1, max_length=1000)
    certainty: Literal["provided", "estimate"] = "provided"


class ExtractedFact(StrictModel):
    """Shared provenance; native branches bind field group to a value type.

    Keep a small plain anyOf union for Claude native JSON schema. Per-field
    length/range constraints are still checked locally because provider schema
    support does not enforce all numeric/string/array bounds.
    """
    source_quote: str = Field(min_length=1, max_length=1000)
    certainty: Literal["provided", "estimate"] = "provided"

    @model_validator(mode="after")
    def valid_domain_fact(self):
        edit = ManualFactChange(field=self.field, value=self.value, certainty=self.certainty)
        self.value = edit.value
        return self


class TextFactChange(ExtractedFact):
    field: Literal["product.sku", "product.name", "product.processing_description", "product.packaging",
                   "product.shelf_life", "shipment.carton_dimensions_cm", "shipment.pickup_location",
                   "shipment.destination", "shipment.incoterm", "shipment.importer_of_record", "shipment.fsvp_importer"]
    value: StrictStr | None


class CountFactChange(ExtractedFact):
    field: Literal["shipment.quantity_units", "shipment.carton_count"]
    value: StrictInt | None

    @field_validator("value", mode="before")
    @classmethod
    def json_integer_semantics(cls, value):
        # JSON Schema integer includes a numeric 500.0. Match that semantics
        # without rounding, accepting strings/booleans, or skipping field bounds.
        if isinstance(value, float) and isfinite(value) and value.is_integer():
            return int(value)
        return value


class MassFactChange(ExtractedFact):
    field: Literal["shipment.gross_weight_kg"]
    value: StrictFloat | None


class ListFactChange(ExtractedFact):
    field: Literal["product.ingredients", "product.certifications"]
    value: list[StrictStr] | None


class QuestionFactChange(ExtractedFact):
    field: Literal["question"]
    value: StrictStr


IntakeFactChange = TextFactChange | CountFactChange | MassFactChange | ListFactChange | QuestionFactChange


class IntakeSynthesis(StrictModel):
    """Intake has no artifact/citation fields; application mode is server authority."""
    reply: str = Field(min_length=1, max_length=1600)
    fact_patch: list[IntakeFactChange] = Field(default_factory=list, max_length=20)
    next_question: str | None = Field(default=None, min_length=1, max_length=300)
    ready_for_research: bool = False
    scope_status: Literal["supported", "needs_clarification", "unsupported"] = "supported"


class ConversationSynthesis(StrictModel):
    reply: str = Field(min_length=1, max_length=1600)
    fact_patch: list[FactChange] = Field(default_factory=list, max_length=20)
    next_question: str | None = Field(default=None, min_length=1, max_length=300)
    ready_for_research: bool = False  # Advisory only; server computes confirmed readiness.
    evidence_ids: list[str] = Field(default_factory=list, max_length=12)
    answer_basis: Literal["intake", "artifact", "recorded_context", "insufficient_evidence"] = "intake"
    fact_fields: list[CaseFactField] = Field(default_factory=list, max_length=20)
    canonical_step_ids: list[str] = Field(default_factory=list, max_length=3)
    scope_status: Literal["supported", "needs_clarification", "unsupported"] = "supported"


class ConversationMessage(StrictModel):
    id: str
    role: Literal["user", "assistant"]
    content: str
    kind: Literal["intake", "artifact_answer", "confirmation", "fact_edit"]
    created_at: str
    citations: list[str] = Field(default_factory=list)
    next_question: str | None = None
    model_provider: str | None = None
    model_name: str | None = None
    model_routing: dict | None = None
    artifact_id: str | None = None
    answer_basis: str | None = None
    model_calls: int | None = None
    fact_fields: list[CaseFactField] = Field(default_factory=list)
    canonical_step_ids: list[str] = Field(default_factory=list)


class ResearchLink(StrictModel):
    case_id: str
    case_version: int
    run_id: str | None = None
    artifact_id: str | None = None
    question: str
    created_at: str
    product_summary: dict[str, str]


class ActivityState(StrictModel):
    status: Literal["draft", "pending_confirmation", "sending", "research_queued", "researching", "ready",
                    "research_failed", "cancelled", "interrupted", "error"] = "draft"
    run_id: str | None = None
    run_status: str | None = None
    stage: str | None = None
    error_code: str | None = None
    artifact_id: str | None = None
    can_send: bool = True


class ConversationDTO(StrictModel):
    conversation_id: str
    version: int
    title: str
    messages: list[ConversationMessage]
    draft: ConversationDraft
    pending_proposal: ConversationDraft | None = None
    ready_for_research: bool = False
    clarification_count: int = Field(default=0, ge=0, le=2)
    scope_status: Literal["supported", "needs_clarification", "unsupported"] = "supported"
    case_id: str | None = None
    case_version: int | None = None
    run_id: str | None = None
    artifact_id: str | None = None
    research_links: list[ResearchLink] = Field(default_factory=list)
    # Durable launch intent, visible only to this conversation's owner. Reading
    # it never dispatches a model; only an explicit MCP start can consume it.
    pending_research_launch: StartInput | None = None
    consents: dict[str, bool]
    created_at: str
    updated_at: str
    activity_state: ActivityState = Field(default_factory=ActivityState)


class ConversationSummary(StrictModel):
    conversation_id: str
    version: int
    title: str
    updated_at: str
    case_id: str | None = None
    case_version: int | None = None
    artifact_id: str | None = None
    question: str = ""
    product_summary: dict[str, str] = Field(default_factory=dict)
    research_links: list[ResearchLink] = Field(default_factory=list)
    activity_state: ActivityState = Field(default_factory=ActivityState)


class ResearchCaseResponse(StrictModel):
    conversation: ConversationDTO
    case: dict
    start_arguments: StartInput
