"""Persistent, bounded conversation intake; research remains a separate MCP action."""
