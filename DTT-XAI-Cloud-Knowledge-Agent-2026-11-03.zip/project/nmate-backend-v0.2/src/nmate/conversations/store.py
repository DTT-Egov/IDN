"""Transactional conversation records in the existing local SQLite database.

No SQL transaction is held across a model request. A durable reservation makes
concurrent/duplicate sends fail safely rather than spending twice. Interrupted
reservations are never automatically replayed against a model.
"""
import copy
import json
import time
import uuid

from ..models import AppError, CaseCreate, StartInput
from ..store import canonical, digest, now
from .models import ConversationDTO, ConversationDraft, FactsInput, ResearchCaseInput


FACT_LABELS = {
    "product.sku": "Mã sản phẩm", "product.name": "Tên sản phẩm",
    "product.ingredients": "Thành phần", "product.processing_description": "Cách chế biến",
    "product.packaging": "Quy cách bao gói", "product.shelf_life": "Hạn dùng",
    "product.certifications": "Chứng nhận", "shipment.quantity_units": "Số đơn vị sản phẩm",
    "shipment.carton_count": "Số thùng", "shipment.gross_weight_kg": "Khối lượng cả bì (kg)",
    "shipment.carton_dimensions_cm": "Kích thước thùng (cm)", "shipment.pickup_location": "Điểm lấy hàng",
    "shipment.destination": "Điểm đến", "shipment.incoterm": "Điều kiện giao hàng",
    "shipment.importer_of_record": "Bên đứng tên nhập khẩu (IOR)",
    "shipment.fsvp_importer": "Bên phụ trách FSVP", "question": "Câu hỏi nghiên cứu",
}


def _edit_quote(change):
    value = change["value"]
    if value is None:
        return "chưa biết"
    if isinstance(value, list):
        return ", ".join(value) if value else "chưa có thông tin"
    text = str(value)
    return "khoảng " + text if change["certainty"] == "estimate" else text


def ready(body):
    return bool(body["draft"]["product"].get("name") and body["draft"].get("question")
                and body.get("pending_proposal") is None and body.get("scope_status") != "unsupported")


class ConversationStore:
    def __init__(self, business_store):
        self.business = business_store
        with business_store.connection(write=True) as db:
            db.executescript("""
              CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY, tenant TEXT NOT NULL, owner TEXT NOT NULL,
                version INTEGER NOT NULL, body TEXT NOT NULL, updated TEXT NOT NULL);
              CREATE INDEX IF NOT EXISTS conversation_owner ON conversations(tenant,owner,updated);
              CREATE TABLE IF NOT EXISTS conversation_requests (
                id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, tenant TEXT NOT NULL,
                idem TEXT NOT NULL, payload_hash TEXT NOT NULL, status TEXT NOT NULL,
                response TEXT, error TEXT, expires REAL NOT NULL, created TEXT NOT NULL,
                UNIQUE(tenant,conversation_id,idem));
              CREATE TABLE IF NOT EXISTS conversation_rejections (
                request_id TEXT PRIMARY KEY, tenant TEXT NOT NULL, diagnostic TEXT NOT NULL, created TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS conversation_research_requests (
                id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, tenant TEXT NOT NULL,
                idem TEXT NOT NULL, payload_hash TEXT NOT NULL, case_id TEXT NOT NULL,
                response TEXT NOT NULL, created TEXT NOT NULL,
                UNIQUE(tenant,conversation_id,idem));
              CREATE INDEX IF NOT EXISTS conversation_research_case ON conversation_research_requests(tenant,case_id);
            """)

    @staticmethod
    def _human(p):
        if p.role != "business":
            raise AppError("FORBIDDEN", "Chỉ người dùng doanh nghiệp được trao đổi và xác nhận hồ sơ.", 403)

    def _get(self, db, p, conversation_id):
        row = db.execute("SELECT body FROM conversations WHERE id=? AND tenant=? AND owner=?",
                         (conversation_id, p.tenant_id, p.subject)).fetchone()
        if not row:
            raise AppError("NOT_FOUND", "Không tìm thấy cuộc trao đổi được phép đọc.", 404)
        return json.loads(row["body"])

    @staticmethod
    def _version(body, expected):
        if body["version"] != expected:
            raise AppError("VERSION_CONFLICT", "Cuộc trao đổi đã thay đổi; hãy đọc lại trước khi gửi.", 409)

    @staticmethod
    def _consent(body):
        if not body["consents"].get("model") or not body["consents"].get("storage"):
            raise AppError("MODEL_CONSENT_REQUIRED", "Cần đồng ý lưu trao đổi và gửi dữ liệu cần thiết tới AI.", 403)

    def _save(self, db, p, body, action):
        if body.get("pending_proposal") is not None:
            body["pending_research_launch"] = None
        body["version"] += 1
        body["updated_at"] = now()
        body["ready_for_research"] = ready(body)
        ConversationDTO.model_validate(body)
        db.execute("UPDATE conversations SET version=?,body=?,updated=? WHERE id=?",
                   (body["version"], canonical(body), body["updated_at"], body["conversation_id"]))
        self.business._audit(db, p, action, body["conversation_id"])
        return body

    def create(self, p, args):
        self._human(p)
        if not args["consent_model"] or not args["consent_storage"]:
            raise AppError("MODEL_CONSENT_REQUIRED", "Cần đồng ý trước khi mở cuộc trao đổi có AI.", 403)
        timestamp = now()
        body = ConversationDTO(conversation_id=str(uuid.uuid4()), version=1, title="Trao đổi mới",
                               messages=[], draft=ConversationDraft(), consents={"model": True, "storage": True},
                               created_at=timestamp, updated_at=timestamp).model_dump(mode="json")
        with self.business.connection(write=True) as db:
            db.execute("INSERT INTO conversations VALUES(?,?,?,?,?,?)",
                       (body["conversation_id"], p.tenant_id, p.subject, 1, canonical(body), timestamp))
            self.business._audit(db, p, "conversation.create", body["conversation_id"])
        return body

    def get(self, p, conversation_id):
        self._human(p)
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            return {**body, "activity_state": self._activity(db, p, body)}

    def interrupt_processing(self):
        with self.business.connection(write=True) as db:
            db.execute("UPDATE conversation_requests SET status='failed',error=? WHERE status='processing'",
                       (canonical({"code": "TURN_INTERRUPTED", "message": "Lượt trao đổi bị gián đoạn; dữ kiện chưa được áp dụng, chưa tự gửi lại AI.", "status": 409}),))

    def _activity(self, db, p, body):
        self.business._expire_leases(db, p.tenant_id)
        db.execute("UPDATE conversation_requests SET status='failed',error=? WHERE tenant=? AND conversation_id=? AND status='processing' AND expires<=?",
                   (canonical({"code": "TURN_INTERRUPTED", "message": "Lượt trao đổi đã gián đoạn; chưa tự gửi lại AI.", "status": 409}), p.tenant_id, body["conversation_id"], time.time()))
        row = db.execute("SELECT status,error FROM conversation_requests WHERE tenant=? AND conversation_id=? ORDER BY created DESC,rowid DESC LIMIT 1",
                         (p.tenant_id, body["conversation_id"])).fetchone()
        state = {"status": "pending_confirmation" if body.get("pending_proposal") else "draft", "run_id": None,
                 "run_status": None, "stage": None, "error_code": None, "artifact_id": None, "can_send": True}
        if body.get("case_id"):
            run = db.execute("SELECT body FROM runs WHERE tenant=? AND case_id=? ORDER BY created DESC LIMIT 1",
                             (p.tenant_id, body["case_id"])).fetchone()
            if run:
                state = self.business.run_activity(json.loads(run[0]))
        if row and row["status"] == "processing":
            state.update(status="sending", can_send=False, stage="model_turn")
        elif row and row["status"] == "failed" and state["status"] not in ("research_queued", "researching"):
            error = json.loads(row["error"] or "{}")
            state.update(status="interrupted" if error.get("code") == "TURN_INTERRUPTED" else "error",
                         error_code=error.get("code"), can_send=True)
        elif body.get("pending_proposal") and state["can_send"]:
            state.update(status="pending_confirmation")
        return state

    def _research_guard(self, db, p, body):
        self.business._expire_leases(db, p.tenant_id)
        if body.get("case_id") and db.execute("SELECT 1 FROM runs WHERE tenant=? AND case_id=? AND status IN ('queued','running')",
            (p.tenant_id, body["case_id"])).fetchone():
            raise AppError("RESEARCH_IN_PROGRESS", "Đang nghiên cứu hồ sơ này; hãy chờ hoặc dừng trước khi sửa/gửi thêm.", 409)

    def list(self, p):
        self._human(p)
        with self.business.connection(write=True) as db:
            records = [dict(row) for row in db.execute(
                "SELECT id conversation_id,version,json_extract(body,'$.title') title,updated updated_at,"
                "json_extract(body,'$.case_id') case_id,json_extract(body,'$.case_version') case_version,"
                "json_extract(body,'$.artifact_id') artifact_id,"
                "coalesce(CASE WHEN json_type(body,'$.pending_proposal')='object' THEN "
                "json_extract(body,'$.pending_proposal.question') ELSE json_extract(body,'$.draft.question') END,'') question,"
                "CASE WHEN json_type(body,'$.pending_proposal')='object' THEN "
                "json_extract(body,'$.pending_proposal.product.name') ELSE json_extract(body,'$.draft.product.name') END product_name,"
                "CASE WHEN json_type(body,'$.pending_proposal')='object' THEN "
                "json_extract(body,'$.pending_proposal.product.sku') ELSE json_extract(body,'$.draft.product.sku') END product_sku,"
                "json_extract(body,'$.research_links') research_links_json,"
                "json_type(body,'$.pending_proposal') != 'null' pending_proposal "
                "FROM conversations WHERE tenant=? AND owner=? ORDER BY updated DESC LIMIT 50", (p.tenant_id, p.subject))]
            keys = ("conversation_id", "version", "title", "updated_at", "case_id", "case_version", "artifact_id")
            return [{**{key: record[key] for key in keys}, "question": record["question"],
                     "product_summary": {key: record[column] for key, column in
                                         (("name", "product_name"), ("sku", "product_sku"))
                                         if isinstance(record[column], str) and record[column]},
                     "research_links": json.loads(record["research_links_json"] or "[]"),
                     "activity_state": self._activity(db, p, record)} for record in records]

    @staticmethod
    def _replay(row, payload_hash):
        if row["payload_hash"] != payload_hash:
            raise AppError("IDEMPOTENCY_CONFLICT", "Khóa gửi đã dùng cho nội dung khác.", 409)
        if row["status"] == "completed":
            return json.loads(row["response"])
        if row["status"] == "failed":
            error = json.loads(row["error"])
            raise AppError(error["code"], error["message"], error["status"])
        raise AppError("TURN_IN_PROGRESS", "Lượt gửi đang xử lý hoặc chưa rõ kết quả; hãy đọc lại cuộc trao đổi.", 409)

    def reserve(self, p, conversation_id, args, *, max_daily=30):
        self._human(p)
        payload_hash = digest({"action": "message", **args})
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            self._consent(body)
            row = db.execute("SELECT * FROM conversation_requests WHERE tenant=? AND conversation_id=? AND idem=?",
                             (p.tenant_id, conversation_id, args["idempotency_key"])).fetchone()
            if row:
                return None, self._replay(row, payload_hash)
            self._version(body, args["expected_version"])
            self._research_guard(db, p, body)
            active = db.execute("SELECT id FROM conversation_requests WHERE conversation_id=? AND status='processing' "
                                "AND expires>?", (conversation_id, time.time())).fetchone()
            if active:
                raise AppError("TURN_IN_PROGRESS", "Một lượt trao đổi khác đang xử lý; chưa gửi thêm lượt mới.", 409)
            count = sum(message["role"] == "user" for message in body["messages"])
            daily = db.execute("SELECT COUNT(*) FROM audit WHERE action='conversation.turn_reserved' AND substr(at,1,10)=?",
                               (now()[:10],)).fetchone()[0]
            if count >= 20 or daily >= max_daily:
                raise AppError("CHAT_LIMIT", "Đã đạt giới hạn trao đổi của máy thử; không gọi thêm mô hình.", 429)
            token = str(uuid.uuid4())
            db.execute("INSERT INTO conversation_requests VALUES(?,?,?,?,?,'processing',NULL,NULL,?,?)",
                       (token, conversation_id, p.tenant_id, args["idempotency_key"], payload_hash,
                        time.time() + 90, now()))
            self.business._audit(db, p, "conversation.turn_reserved", conversation_id)
        return token, body

    def fail(self, p, token, error):
        safe = {"code": error.code, "message": error.message, "status": error.status}
        with self.business.connection(write=True) as db:
            db.execute("UPDATE conversation_requests SET status='failed',error=? WHERE id=? AND tenant=? "
                       "AND status='processing'", (canonical(safe), token, p.tenant_id))

    def record_rejection(self, p, token, diagnostic):
        """Private diagnostic: only application-selected enums, booleans, counts and hashes.

        Never exposed by the conversation DTO/list/error API. Never stores raw
        model content, matched text, user text, source quotes or exception bodies.
        """
        allowed = {"reason", "mode", "reply_sha256", "reply_chars", "reply_words", "basis",
                   "evidence_count", "fact_ref_count", "step_ref_count", "guard_unsafe",
                   "guard_rule", "guard_context", "guard_match_count", "schema_error_count", "invalid_field", "value_type",
                   "validation_fields", "validation_error_types", "validation_error_count"}
        safe = {key: value for key, value in diagnostic.items() if key in allowed}
        with self.business.connection(write=True) as db:
            if db.execute("SELECT id FROM conversation_requests WHERE id=? AND tenant=?",
                          (token, p.tenant_id)).fetchone():
                db.execute("INSERT OR IGNORE INTO conversation_rejections VALUES(?,?,?,?)",
                           (token, p.tenant_id, canonical(safe), now()))

    def commit(self, p, conversation_id, token, expected_version, updates):
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            self._consent(body)
            self._version(body, expected_version)
            row = db.execute("SELECT * FROM conversation_requests WHERE id=? AND tenant=? AND conversation_id=?",
                             (token, p.tenant_id, conversation_id)).fetchone()
            if not row or row["status"] != "processing" or row["expires"] < time.time():
                raise AppError("TURN_INTERRUPTED", "Lượt trao đổi đã hết thời gian; chưa áp dụng dữ kiện.", 409)
            body.update(updates)
            self._save(db, p, body, "conversation.turn_completed")
            db.execute("UPDATE conversation_requests SET status='completed',response=? WHERE id=?",
                       (canonical(body), token))
            body = {**body, "activity_state": self._activity(db, p, body)}
            db.execute("UPDATE conversation_requests SET response=? WHERE id=?", (canonical(body), token))
            return body

    def confirm(self, p, conversation_id, args):
        self._human(p)
        payload_hash = digest({"action": "confirm", **args})
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            row = db.execute("SELECT * FROM conversation_requests WHERE tenant=? AND conversation_id=? AND idem=?",
                             (p.tenant_id, conversation_id, args["idempotency_key"])).fetchone()
            if row:
                return self._replay(row, payload_hash)
            self._version(body, args["expected_version"])
            self._research_guard(db, p, body)
            if db.execute("SELECT id FROM conversation_requests WHERE conversation_id=? AND status='processing' "
                          "AND expires>?", (conversation_id, time.time())).fetchone():
                raise AppError("TURN_IN_PROGRESS", "Chờ lượt trao đổi hoàn tất trước khi xác nhận.", 409)
            if body["pending_proposal"] is None:
                raise AppError("NO_PENDING_PROPOSAL", "Không có đề xuất dữ kiện đang chờ xác nhận.", 409)
            body["draft"] = body["pending_proposal"]
            body["pending_proposal"] = None
            for source in body["draft"]["field_sources"].values():
                source["confirmed"] = True
            body["messages"].append({"id": str(uuid.uuid4()), "role": "assistant", "kind": "confirmation",
                "content": "Đã ghi nhận dữ kiện bạn xác nhận. Chưa bắt đầu nghiên cứu hoặc gửi yêu cầu cho bên ngoài.",
                "created_at": now()})
            self._save(db, p, body, "conversation.facts_confirmed")
            db.execute("INSERT INTO conversation_requests VALUES(?,?,?,?,?,'completed',?,NULL,?,?)",
                       (str(uuid.uuid4()), conversation_id, p.tenant_id, args["idempotency_key"],
                        payload_hash, canonical(body), time.time(), now()))
            body = {**body, "activity_state": self._activity(db, p, body)}
            db.execute("UPDATE conversation_requests SET response=? WHERE tenant=? AND conversation_id=? AND idem=?",
                       (canonical(body), p.tenant_id, conversation_id, args["idempotency_key"]))
            return body

    def edit_facts(self, p, conversation_id, args):
        """Save a human field edit as a pending proposal, without any model call.

        The server creates provenance from the exact submitted display value.
        Clients cannot supply a source quote, confirmation flag, scope change,
        owner or arbitrary patch path. The final explicit confirm remains separate.
        """
        self._human(p)
        args = FactsInput.model_validate(args).model_dump(mode="json")
        payload_hash = digest({"action": "edit_facts", **args})
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            self._consent(body)
            row = db.execute("SELECT * FROM conversation_requests WHERE tenant=? AND conversation_id=? AND idem=?",
                             (p.tenant_id, conversation_id, args["idempotency_key"])).fetchone()
            if row:
                return self._replay(row, payload_hash)
            self._version(body, args["expected_version"])
            self._research_guard(db, p, body)
            if db.execute("SELECT id FROM conversation_requests WHERE conversation_id=? AND status='processing' "
                          "AND expires>?", (conversation_id, time.time())).fetchone():
                raise AppError("TURN_IN_PROGRESS", "Chờ lượt trao đổi hoàn tất trước khi sửa dữ kiện.", 409)
            proposal = copy.deepcopy(body["pending_proposal"] or body["draft"])
            token = str(uuid.uuid4())
            identity_correction = args["same_product_correction"] and any(change["field"] in ("product.name", "product.sku") for change in args["changes"])
            # A generated edit log must not impersonate the user's self-address.
            lines = ["Cập nhật tên/mã của cùng sản phẩm, chờ kiểm trước khi nghiên cứu:" if identity_correction else "Cập nhật dữ kiện, chờ kiểm trước khi nghiên cứu:"]
            for change in args["changes"]:
                field, value = change["field"], change["value"]
                section, _, key = field.partition(".")
                if field in ("product.name", "product.sku"):
                    previous = proposal["product"][key]
                    if previous and str(previous).casefold() != str(value).casefold() and not args["same_product_correction"]:
                        raise AppError("PRODUCT_CONTEXT_CHANGE",
                            "Đây là hồ sơ một sản phẩm. Hãy mở cuộc trao đổi mới khi đổi sản phẩm hoặc SKU.", 409)
                if key:
                    proposal[section][key] = value
                else:
                    proposal[section] = value
                quote = _edit_quote(change)
                lines.append(FACT_LABELS[field] + ": " + quote)
                proposal["field_sources"][field] = {"message_id": token, "source_quote": quote,
                    "certainty": change["certainty"], "confirmed": False}
                if change["certainty"] == "estimate":
                    if field not in proposal["uncertain_fields"]:
                        proposal["uncertain_fields"].append(field)
                elif field in proposal["uncertain_fields"]:
                    proposal["uncertain_fields"].remove(field)
            proposal = ConversationDraft.model_validate(proposal).model_dump(mode="json")
            stamp = now()
            body["pending_proposal"] = proposal
            body["title"] = proposal["product"]["name"] or body["title"]
            body["messages"].append({"id": token, "role": "user", "kind": "fact_edit",
                "content": "\n".join(lines), "created_at": stamp, "model_calls": 0})
            self._save(db, p, body, "conversation.same_product_corrected" if identity_correction else "conversation.facts_edited")
            db.execute("INSERT INTO conversation_requests VALUES(?,?,?,?,?,'completed',?,NULL,?,?)",
                       (token, conversation_id, p.tenant_id, args["idempotency_key"],
                        payload_hash, canonical(body), time.time(), stamp))
            body = {**body, "activity_state": self._activity(db, p, body)}
            db.execute("UPDATE conversation_requests SET response=? WHERE id=?", (canonical(body), token))
            return body

    def research_case(self, p, conversation_id, args):
        """Create and attach a confirmed immutable snapshot in one DB commit.

        This records the user's explicit launch intent, but never invokes a
        provider. The frontend sends the returned StartInput through MCP once.
        Closing a tab at any point cannot leave an unattached case behind.
        """
        self._human(p)
        args = ResearchCaseInput.model_validate(args).model_dump(mode="json")
        payload_hash = digest({"action": "research_case", **args})
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            self._consent(body)
            previous = db.execute("SELECT payload_hash,response FROM conversation_research_requests "
                "WHERE tenant=? AND conversation_id=? AND idem=?",
                (p.tenant_id, conversation_id, args["idempotency_key"])).fetchone()
            if previous:
                if previous["payload_hash"] != payload_hash:
                    raise AppError("IDEMPOTENCY_CONFLICT", "Khóa nghiên cứu đã dùng cho nội dung khác.", 409)
                return json.loads(previous["response"])
            self._version(body, args["expected_version"])
            self._research_guard(db, p, body)
            if db.execute("SELECT id FROM conversation_requests WHERE conversation_id=? AND status='processing' AND expires>?",
                          (conversation_id, time.time())).fetchone():
                raise AppError("TURN_IN_PROGRESS", "Chờ lượt trao đổi hoàn tất trước khi nghiên cứu.", 409)
            if not ready(body):
                raise AppError("FACT_CONFIRMATION_REQUIRED", "Cần xác nhận dữ kiện và câu hỏi trước khi nghiên cứu.", 409)
            intent = body.get("pending_research_launch")
            if intent:
                # Lost endpoint response/reload: reuse an attached, unstarted
                # snapshot. No silent model dispatch and no second case.
                if intent["processing_level"] != args["processing_level"]:
                    raise AppError("RESEARCH_LAUNCH_MISMATCH", "Đã có lượt chưa gửi với mức xử lý khác; hãy đọc lại trước khi thay đổi.", 409)
                case = self.business._case(db, p, intent["case_id"])
            else:
                draft = body["draft"]
                product = {**draft["product"], "sku": draft["product"]["sku"] or "REF-" + conversation_id[:12].upper()}
                data = CaseCreate(product=product, shipment=draft["shipment"],
                    consent_research=True, consent_model=bool(body["consents"].get("model")),
                    research_context={"uncertain_fields": draft["uncertain_fields"],
                                      "field_sources": draft["field_sources"]}).model_dump(mode="json")
                self.business.check_scope(data)
                case = self.business._insert_case(db, p, data)
                intent = StartInput(case_id=case["case_id"], expected_case_version=case["version"],
                    idempotency_key="research-" + str(uuid.uuid4()), question=draft["question"],
                    processing_level=args["processing_level"]).model_dump(mode="json")
                body["research_links"].append({"case_id": case["case_id"], "case_version": case["version"],
                    "run_id": None, "artifact_id": None, "question": draft["question"], "created_at": now(),
                    "product_summary": {key: case["product"][key] for key in ("sku", "name")}})
                body.update(case_id=case["case_id"], case_version=case["version"], run_id=None,
                            artifact_id=None, pending_research_launch=intent)
                self._save(db, p, body, "conversation.research_case_created")
            response = {"conversation": {**body, "activity_state": self._activity(db, p, body)},
                        "case": case, "start_arguments": intent}
            db.execute("INSERT INTO conversation_research_requests VALUES(?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4()), conversation_id, p.tenant_id, args["idempotency_key"], payload_hash,
                 case["case_id"], canonical(response), now()))
            return response

    def link(self, p, conversation_id, args):
        self._human(p)
        with self.business.connection(write=True) as db:
            body = self._get(db, p, conversation_id)
            self._version(body, args["expected_version"])
            if db.execute("SELECT id FROM conversation_requests WHERE conversation_id=? AND status='processing' "
                          "AND expires>?", (conversation_id, time.time())).fetchone():
                raise AppError("TURN_IN_PROGRESS", "Chờ lượt trao đổi hoàn tất trước khi liên kết nghiên cứu.", 409)
            if body["pending_proposal"] is not None or not ready(body):
                raise AppError("FACT_CONFIRMATION_REQUIRED", "Cần xác nhận đề xuất hồ sơ trước khi liên kết nghiên cứu.", 409)
            case = self.business._case(db, p, args["case_id"])
            if case["version"] != args["case_version"]:
                raise AppError("VERSION_CONFLICT", "Phiên bản hồ sơ liên kết đã thay đổi.", 409)
            # A UUID alone must not attach an old or edited profile to this conversation.
            product = {**case["product"]}
            draft_product = {**body["draft"]["product"]}
            if draft_product["sku"] is None:
                product.pop("sku", None)
                draft_product.pop("sku", None)  # Caller may explicitly label a generated internal REF.
            if product != draft_product or case["shipment"] != body["draft"]["shipment"]:
                raise AppError("CASE_DRAFT_MISMATCH", "Hồ sơ không khớp dữ kiện đã xác nhận trong cuộc trao đổi.", 409)
            expected_context = {"uncertain_fields": body["draft"]["uncertain_fields"],
                                "field_sources": body["draft"]["field_sources"]}
            if case.get("research_context") != expected_context:
                raise AppError("CASE_DRAFT_MISMATCH", "Hồ sơ liên kết chưa giữ đúng nguồn dữ kiện và nhãn ước lượng đã xác nhận.", 409)
            run = None
            if args.get("run_id"):
                row = db.execute("SELECT body FROM runs WHERE id=? AND tenant=?",
                                 (args["run_id"], p.tenant_id)).fetchone()
                if not row:
                    raise AppError("NOT_FOUND", "Không tìm thấy lượt nghiên cứu được phép liên kết.", 404)
                run = json.loads(row["body"])
                if run["case_id"] != case["case_id"] or run["profile_version"] != case["version"]:
                    raise AppError("CONTEXT_MISMATCH", "Lượt nghiên cứu không thuộc đúng hồ sơ và phiên bản.", 409)
            if args.get("artifact_id"):
                row = db.execute("SELECT body FROM artifacts WHERE id=? AND tenant=?",
                                 (args["artifact_id"], p.tenant_id)).fetchone()
                if not row:
                    raise AppError("NOT_FOUND", "Không tìm thấy báo cáo được phép liên kết.", 404)
                artifact = json.loads(row["body"])
                if (artifact["case_id"] != case["case_id"] or artifact["profile_version"] != case["version"]
                        or run and artifact["run_id"] != run["run_id"]):
                    raise AppError("CONTEXT_MISMATCH", "Báo cáo không thuộc đúng lượt, hồ sơ và phiên bản.", 409)
                if not run:
                    run = json.loads(db.execute("SELECT body FROM runs WHERE id=? AND tenant=?",
                        (artifact["run_id"], p.tenant_id)).fetchone()["body"])
            entry = {"case_id": case["case_id"], "case_version": case["version"],
                     "run_id": run["run_id"] if run else None, "artifact_id": args.get("artifact_id"),
                     "question": run["question"] if run else body["draft"]["question"], "created_at": now(),
                     "product_summary": {"sku": case["product"]["sku"], "name": case["product"]["name"]}}
            links = body["research_links"]
            previous = next((item for item in links if entry["run_id"] and item["run_id"] == entry["run_id"]), None)
            if previous:
                entry["created_at"] = previous["created_at"]
                if entry["artifact_id"] is None:
                    entry["artifact_id"] = previous.get("artifact_id")
                links[links.index(previous)] = entry
            else:
                links.append(entry)
            for key in ("case_id", "case_version", "run_id", "artifact_id"):
                body[key] = entry[key]
            saved = self._save(db, p, body, "conversation.research_linked")
            return {**saved, "activity_state": self._activity(db, p, saved)}
