"""Unified, Claude-backed enterprise assistant."""
