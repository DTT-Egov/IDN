"""Read-only projection of independently valid parts of a failed Claude report.

Never repairs a model answer, persists anything, dispatches a provider, creates
an artifact or changes the mission's failed status. The caller must first check
resource ownership and the current fact/source snapshot against the repository.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import hashlib
import json

from nmate.v03.core import CoreError, json_text
from nmate.v03.evidence import validate_answer_citations
from nmate.v03.live_review import public_metadata, validate_research
from nmate.v03.markets import market_title
from nmate.v03.missions import market_of


STATUS = "partial_not_a_completed_report"


def _message(exc):
    text = str(exc)
    if "ngoài hợp đồng" in text:
        return "Phần này nêu các ô dữ kiện app chưa hỗ trợ cho thị trường đang chọn. Cần rà lại trước khi hiển thị."
    if "SSOT" in text:
        return "Phần này hỏi lại thông tin đã có trong hồ sơ. Mình giữ riêng để rà lại."
    if "khớp nguyên văn" in text:
        return "Trích dẫn trong phần này chưa khớp bản nguồn đã lưu. Mình chưa công bố phần này."
    if exc.code in {"evidence_market_mismatch", "evidence_stale", "evidence_integrity"}:
        return "Nguồn của phần này chưa khớp thị trường hoặc không còn đủ điều kiện dùng lại. Cần rà nguồn trước khi hiển thị."
    if "nguồn" in text.casefold() or "trích" in text.casefold():
        return "Phần này chưa có trích dẫn phù hợp với ý hỏi và bản nguồn đã lưu. Mình chưa công bố phần này."
    return "Phần này chưa đạt kiểm tra. Mình giữ lại bản gốc để rà và không tự gọi lại AI."


def project_partial_research(mission, provider_envelope):
    """Validate each requested answer intact; quarantine an invalid answer whole.

    ``validated_answers`` includes an honest, structurally valid blocked_source
    answer when Claude explicitly reports a coverage gap. ``blocked_outcomes``
    lists quarantined or absent answers, not silently edited substitutes.
    Audit data is intended for private evidence storage, outside the UI view.
    """
    if not isinstance(mission, dict) or mission.get("status") != "failed":
        raise CoreError("partial_failed_mission_required", "Chỉ xem phần đã kiểm của hồ sơ nghiên cứu đang báo lỗi.", 409)
    if not isinstance(provider_envelope, dict):
        provider_envelope = {}
    raw = deepcopy(provider_envelope.get("data"))
    try:
        parsed = json.loads(raw) if isinstance(raw, str) else deepcopy(raw)
    except (json.JSONDecodeError, TypeError, ValueError):
        parsed = None
    requested = mission["intent"]["outcomes"]
    result = {
        "status": STATUS, "complete_report": False, "mission_status": "failed",
        "validated_answers": [], "blocked_outcomes": [], "actions": [], "artifacts": [],
        "model_calls": 0, "provider_attempts": 0, "ssot_writes": 0, "research_replayed": False,
        "message": "Báo cáo đầy đủ đã dừng do chưa đạt kiểm tra. Chỉ các phần dưới đây vượt qua kiểm tra riêng; các phần còn lại được giữ riêng để rà. Không phát sinh lượt AI mới.",
        "audit": {
            "provider_metadata": deepcopy(public_metadata(provider_envelope)),
            "raw_output": raw,
            "raw_output_sha256": hashlib.sha256(json_text(raw).encode()).hexdigest(),
            "original_status": mission["status"],
            "original_error": {key: deepcopy(mission[key]) for key in ("stale_reason", "error", "operation_error") if key in mission},
            "original_cost": deepcopy(mission.get("cost", {})),
            "quarantined_answer_indexes": [],
        },
    }
    code = market_of(mission)

    def title(outcome):
        return market_title(outcome["id"], code) if code and outcome["id"] != "clarification" else outcome["title"]

    def block(outcome, message, *, error_code="partial_answer_invalid"):
        result["blocked_outcomes"].append({"outcome_id": outcome["id"], "title": title(outcome),
                                           "message": message, "error_code": error_code})

    context_market = mission.get("knowledge", {}).get("market_code")
    intent_market = mission.get("intent", {}).get("market_code")
    if not code or context_market and context_market != code or intent_market and intent_market != code:
        for outcome in requested:
            block(outcome, "Thị trường của hồ sơ và bản nguồn chưa khớp. Mình chưa công bố phần này.", error_code="partial_context_market_mismatch")
        return result
    if (not isinstance(parsed, dict) or set(parsed) - {"answers", "actions"}
            or not isinstance(parsed.get("answers"), list) or not 1 <= len(parsed["answers"]) <= 5):
        for outcome in requested:
            block(outcome, "Claude chưa trả phần này theo cấu trúc có thể kiểm tra. Mình giữ bản gốc để rà lại.")
        return result
    raw_answers = parsed["answers"]
    counts = Counter(answer.get("outcome_id") for answer in raw_answers if isinstance(answer, dict) and isinstance(answer.get("outcome_id"), str))
    requested_ids = {outcome["id"] for outcome in requested}
    quarantined = {index for index, answer in enumerate(raw_answers)
                   if not isinstance(answer, dict) or not isinstance(answer.get("outcome_id"), str)
                   or answer["outcome_id"] not in requested_ids}
    for outcome in requested:
        oid = outcome["id"]
        matches = [(index, answer) for index, answer in enumerate(raw_answers)
                   if isinstance(answer, dict) and answer.get("outcome_id") == oid]
        if counts[oid] != 1:
            quarantined.update(index for index, _ in matches)
            block(outcome, "Lượt này thiếu câu trả lời rõ ràng cho ý hỏi, hoặc có nhiều bản trùng nhau. Mình chưa công bố phần này.")
            continue
        index, answer = matches[0]
        one_mission = {**mission, "intent": {**mission["intent"], "outcomes": [outcome]}}
        try:
            # The complete original answer goes through the same strict schema,
            # field/SSOT checks and source binding. No field is dropped to pass.
            validated = validate_research({"data": {"answers": [deepcopy(answer)], "actions": []}}, one_mission)
            value = validated.answers[0]
            if value.status == "artifact_ready" and not any(
                    item.get("kind") == "food_label_workbook" and item.get("market_code") == code
                    for item in mission.get("artifacts", [])):
                raise CoreError("partial_artifact_missing", "Chưa có khung nhãn đã được máy chủ tạo và lưu để đối chiếu.", 409)
            citations = validate_answer_citations([citation.model_dump() for citation in value.citations],
                         records=mission["knowledge"]["records"], outcome_id=value.outcome_id,
                         expected_market_code=code, outcome_question_part=outcome.get("question_part"),
                         question=mission.get("question"))
            result["validated_answers"].append({**value.model_dump(exclude={"citations"}), "title": title(outcome),
                                                 "source_ids": list(dict.fromkeys(citation.source_id for citation in value.citations)),
                                                 "citations": citations, "review_state": "reference_unreviewed",
                                                 "projection": "independently_validated_part_of_failed_report"})
        except CoreError as exc:
            quarantined.add(index)
            block(outcome, _message(exc), error_code=exc.code)
    result["audit"]["quarantined_answer_indexes"] = sorted(quarantined)
    return result
