"""Pure query projections. Historical plans never become the live SSOT cache."""
from __future__ import annotations

import copy
import hashlib

from nmate.v03.core import json_text
from nmate.v04.product_binding import scoped_business_context
from nmate.core_v1.workspace_contract import workspace_interaction


def intake_workspace_view(repo, account, enterprise, intake, db, conversation=None):
    """All reads use the caller's SQL snapshot and active private-owner scope."""
    membership = repo.get_membership(account, enterprise, db)
    context = scoped_business_context(repo.get_context(account, enterprise, db=db), intake.get("product"))
    review = copy.deepcopy(intake.get("review") or {})
    conversation = conversation or {}
    interaction = workspace_interaction(intake, kind="intake", role=membership["role"], conversation=conversation)
    revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise,)).fetchone()[0]
    scope = {"account_id": account, "enterprise_id": enterprise,
             "conversation_id": conversation.get("id"), "workspace_id": intake["id"]}
    scope["authorization_fingerprint"] = hashlib.sha256(json_text(
        {**scope, "role": membership["role"], "active": membership["active"]}).encode()).hexdigest()
    receipt = copy.deepcopy(intake.get("latest_confirmation_receipt"))
    error = conversation.get("operation_error")
    operation_id = conversation.get("pending_operation_id")
    if error:
        operation = {"kind": "conversation", "state": "failed", "operation_id": error.get("operation_id"),
                     "message_vi": error.get("message"), "processing": False}
    elif operation_id:
        operation = {"kind": "conversation", "state": "pending", "operation_id": operation_id, "processing": True}
    elif receipt:
        operation = {"kind": "local_confirmation", "state": "succeeded", "processing": False,
                     "operation_id": receipt.get("operation_id"), "receipt_ref": receipt.get("receipt_id")}
    else:
        operation = {"kind": "idle", "state": "idle", "processing": False}
    return {"schema_version": "workspace-review/2", "scope": scope,
            "revisions": {"workspace": review.get("revision", 0), "context": revision,
                          "conversation": conversation.get("revision", 0)},
            "review": review, "current_context": {**context, "context_revision": revision},
            "historical_analysis": {"saved_context": copy.deepcopy(intake.get("saved_context")),
                                    "is_historical": True},
            "operation": operation,
            "billing": {"local_review_model_calls": 0,
                        "conversation_paid_calls": (conversation.get("cost") or {}).get("paid_calls", 0)},
            "latest_confirmation_receipt": receipt,
            "primary_action": interaction["primary_action"],
            "allowed_actions": interaction["allowed_actions"],
            "notices": [{"notice_id": "recovery:" + str(item.get("operation_id")),
                         "temporal_scope": "historical_event", "message_code": "RECORDED_RESULT_RECHECKED",
                         "message_vi": "Bước đọc lại này dùng kết quả đã lưu và không tự ghi hồ sơ."}
                        for item in conversation.get("application_recoveries", [])]}
