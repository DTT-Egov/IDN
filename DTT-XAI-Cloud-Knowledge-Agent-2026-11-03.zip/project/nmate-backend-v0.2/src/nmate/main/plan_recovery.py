"""Free correction of model observations incorrectly used as intent blockers.

Only an already validated, unstarted plan with an explicit product/market and
unchanged SSOT/source snapshot qualifies. Original model output is immutable.
"""
import copy
import json

from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.live_review import LiveIntent, validate_intake
from nmate.v03.missions import digest, make_plan, resolve_market


def recover_nonblocking_intake_gaps(repo):
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE IF NOT EXISTS main_plan_recoveries (mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id), previous_intent_json TEXT NOT NULL, previous_plan_hash TEXT, reason TEXT NOT NULL, recovered_at TEXT NOT NULL)")
    with repo.connection() as db:
        rows = list(db.execute("SELECT m.id,m.owner_id,m.enterprise_id,m.version,m.payload_json,o.output_json FROM v03_missions m JOIN v03_live_review_outputs o ON o.mission_id=m.id AND o.kind='intake' WHERE m.status='waiting_input'"))
    recovered = []
    for row in rows:
        try:
            mission = json.loads(row["payload_json"])
            market = (mission.get("market") or {}).get("code")
            product = (mission.get("product") or {}).get("entity_id")
            if market not in {"US", "DE", "JP"} or not product or mission.get("product_candidates"):
                continue
            intake = validate_intake({"data": json.loads(row["output_json"])}, mission["question"], market)
            if any(o.id == "clarification" for o in intake.outcomes) or not intake.ambiguities:
                continue
            # Product/market ambiguities added by deterministic guards must
            # survive. Only the exact original model observation list qualifies.
            if mission["intent"]["ambiguities"] != intake.ambiguities:
                continue
            code, _, issues = resolve_market(mission["question"], market)
            if code != market or issues:
                continue
            repo.get_entity(row["owner_id"], row["enterprise_id"], product)
            if intake.product_name and product not in {e["id"] for e in repo.find_entities_by_name(row["owner_id"], row["enterprise_id"], intake.product_name)}:
                continue
            checked = repo.validate_context(row["owner_id"], row["enterprise_id"], mission["context"]["fact_refs"], mission["knowledge"]["source_refs"])
            if not checked["valid"]:
                continue
            previous_intent = copy.deepcopy(mission["intent"])
            value = {**mission["intent"], "ambiguities": [], "preliminary_information_gaps": intake.ambiguities}
            intent = LiveIntent.model_validate(value)
            plan = make_plan(intent)
            plan.hash = digest({"plan": plan.model_dump(), "enterprise_id": row["enterprise_id"],
                                "fact_refs": mission["context"]["fact_refs"], "source_refs": mission["knowledge"]["source_refs"]})
            if [t.id for t in plan.tasks] != [t["id"] for t in mission["plan"]["tasks"]]:
                continue
            with repo.connection(write=True) as db:
                repo.get_membership(row["owner_id"], row["enterprise_id"], db)
                current = db.execute("SELECT status,version FROM v03_missions WHERE id=? AND owner_id=? AND enterprise_id=?", (row["id"], row["owner_id"], row["enterprise_id"])).fetchone()
                if not current or current["status"] != "waiting_input" or current["version"] != row["version"]:
                    continue
                if not repo.validate_context(row["owner_id"], row["enterprise_id"], mission["context"]["fact_refs"], mission["knowledge"]["source_refs"])["valid"]:
                    continue
                if db.execute("SELECT 1 FROM v03_task_attempts WHERE mission_id=? AND state!='planned'", (row["id"],)).fetchone():
                    continue
                if db.execute("SELECT 1 FROM v03_live_attempts WHERE mission_id=? AND kind='research'", (row["id"],)).fetchone():
                    continue
                if db.execute("SELECT 1 FROM v03_live_review_stages WHERE mission_id=? AND kind='research'", (row["id"],)).fetchone():
                    continue
                stamp = now_iso()
                db.execute("INSERT INTO main_plan_recoveries VALUES(?,?,?,?,?)", (row["id"], json_text(previous_intent), mission["plan"]["hash"], "nonblocking_model_observations_separated_from_validated_intent", stamp))
                mission.update(intent=intent.model_dump(), plan=plan.model_dump(), updated_at=stamp)
                mission["plan_recovery"] = {"model_calls": 0, "ssot_writes": 0,
                    "message": "Giữ yêu cầu và hồ sơ đã xác nhận; các quan sát sơ bộ được tách khỏi câu hỏi làm rõ. Chưa bắt đầu nghiên cứu và không gọi lại AI.",
                    "original_intake_preserved": True, "at": stamp}
                db.execute("UPDATE v03_missions SET status='planned',version=version+1,payload_json=?,updated_at=? WHERE id=?", (json_text(mission), stamp, row["id"]))
                recovered.append(row["id"])
        except (CoreError, ValueError, TypeError, KeyError):
            continue
    return recovered
