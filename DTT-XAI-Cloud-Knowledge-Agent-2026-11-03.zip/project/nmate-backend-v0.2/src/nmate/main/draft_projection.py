"""Read-only review of old text-parser observations in an authorized chat.

An owner-excluded parser mistake is kept as inspectable evidence, rather than
being offered again as a pending SSOT change. The persisted intake, choices,
provider receipt and SSOT are never rewritten by this projection.
"""
from __future__ import annotations

import copy
import hashlib
import re

from nmate.v04.extraction import (ALIASES, FIELD_SPECS, PRODUCT_OPERATION_END,
                                  extract_product_text, normalize, product_name_key)


def _proven_legacy_name_boundary_error(text, candidate, names):
    """Absence from today's proposals is unknown, not an invalid old decision.

    Only source-backed business/caption contamination or a sales-rate category
    is positive evidence of this old parser mistake. Literal historical names
    that today's grammar does not recognize remain available for owner review.
    """
    value, quote = candidate["value"], candidate["source"]["quote"]
    key = product_name_key(value)
    if not key or key not in product_name_key(quote) or key in names:
        return False
    normalized = normalize(value)
    raw = normalize(text)
    # An explicitly declared literal identity is not reinterpreted by a later
    # parser version. The old owner's unchecked choice is not invalidation.
    if re.search(r"\b(?:ten san pham\s*(?:la\s*|:\s*)|(?:toi|chi|anh|em|minh)\s+co\s+(?:san pham\s+)?)"
                 + re.escape(normalized) + r"(?!\w)", raw):
        return False
    captions = {alias for alias, field in ALIASES.items()
                if field != "name" and FIELD_SPECS[field][1] == "product"}
    for name in names:
        if not key.startswith(name):
            continue
        suffix = key[len(name):]
        if not suffix or not (suffix[0].isspace() or suffix[0] in ":：,;"):
            continue
        lexical_suffix = " " + suffix.lstrip(" :：,;")
        if re.match("(?:" + PRODUCT_OPERATION_END + ")", lexical_suffix, re.IGNORECASE):
            return True
        caption = normalize(lexical_suffix)
        if any(re.match(re.escape(label) + r"(?!\w)", caption) for label in captions):
            return True
    # "300 hộp trà mỗi tháng" denotes a sales rate, not a product named
    # "trà mỗi tháng". Missing/unsupported literal names alone never match.
    rate = r"(?:tra|mut|bot|banh|mien|chanh)\s+(?:moi|hang)\s+(?:ngay|tuan|thang|quy|nam)"
    return bool(re.fullmatch(rate, normalized) and re.search(
        r"\b(?:ban|tieu thu)\s+(?:(?:duoc|khoang|trung binh)\s+)?\d+(?:[.,]\d+)?\s*"
        r"(?:hop|tui|goi|chai|kg|g)?\s+" + re.escape(normalized) + r"(?!\w)", raw))


def stale_text_name_candidates(view, intake):
    """Find source-proven legacy boundary errors, not new proposal ineligibility.

    A clarification overwrites intake.text. Only earlier owner messages linked
    to this same intake can establish the old observation's source; assistant
    prose or text from another work item cannot do so.
    """
    if (intake.get("review") or {}).get("schema_version") == "workspace-review/2":
        return [candidate for candidate in intake.get("candidates", [])
                if candidate.get("decision_state") == "legacy_archived"
                and str(candidate.get("review_decision_reason", candidate.get("decision_reason", ""))).startswith("legacy_parser_invalid:")]
    if intake.get("status") == "confirmed" or view.get("status") == "confirmed":
        return []
    product = intake.get("product") or {}
    if product.get("entity_id") or product.get("id") not in {None, "new_product"}:
        return []
    texts = [intake.get("text") or ""]
    if intake.get("id"):
        texts.extend(message.get("text") or "" for message in view.get("messages", [])
                     if message.get("role") == "user" and message.get("intake_id") == intake["id"])
    stale = []
    for candidate in intake.get("candidates", []):
        source = candidate.get("source") or {}
        quote = source.get("quote")
        if (candidate.get("field") != "name" or candidate.get("status") != "candidate"
                or source.get("kind") != "server_text_extract" or not isinstance(quote, str) or not quote
                or not isinstance(candidate.get("value"), str)):
            continue
        digest = source.get("text_sha256")
        possible = {text for text in texts if isinstance(text, str) and quote in text
                    and (not digest or digest == hashlib.sha256(text.encode("utf-8")).hexdigest())}
        if len(possible) != 1:
            continue
        for text in possible:
            start, end = source.get("start_offset"), source.get("end_offset")
            if start is not None or end is not None:
                if not (type(start) is int and type(end) is int and 0 <= start < end <= len(text)
                        and text[start:end].strip() == quote):
                    continue
            elif text.count(quote) != 1:
                continue  # An unlocated repeated quote cannot prove its source span.
            names = {product_name_key(fact["value"]) for fact in extract_product_text(text, include_product_references=True)
                     if fact.get("field") == "name"}
            if _proven_legacy_name_boundary_error(text, candidate, names):
                stale.append(candidate)
            break
    return stale


def project_excluded_legacy_draft(view):
    """Compact only definitely stale observations explicitly excluded by owner.

    A valid unchecked fact, unreviewed old observation, owner edit, conflict,
    file/model observation or confirmed fact remains in the normal review.
    """
    intake = view.get("intake")
    if not intake:
        return view
    draft = (view.get("drafts") or {}).get(intake.get("id")) or {}
    selected, edits, choices = (draft.get(key) or {} for key in ("selected", "edits", "choices"))
    frozen = (intake.get("review") or {}).get("schema_version") == "workspace-review/2"
    excluded = [candidate for candidate in stale_text_name_candidates(view, intake)
                if isinstance(candidate.get("id"), str) and (frozen or selected.get(candidate.get("id")) is False
                and candidate.get("id") not in edits and not choices.get(candidate.get("id")))]
    if not excluded:
        return view
    result = copy.deepcopy(view)
    item = result["intake"]
    ids = {candidate["id"] for candidate in excluded}
    item["candidates"] = [candidate for candidate in item.get("candidates", []) if candidate.get("id") not in ids]
    active = sum(candidate.get("status") in {"candidate", "conflict"} for candidate in item["candidates"])
    item["draft_projection"] = {
        "state": "excluded_legacy_text_extraction", "source_status": intake.get("status"),
        "archived_count": len(excluded), "active_candidate_count": active,
        "archived_candidates": [{**copy.deepcopy(candidate),
            "reason_vi": "Đã bỏ chọn nháp trích tên sai từ câu chat. Giữ bản gốc để đối chiếu; không ghi vào hồ sơ."}
            for candidate in excluded],
        "ssot_changed": False, "model_called": False,
    }
    names = {product_name_key(candidate["value"]) for candidate in excluded}
    product = item.get("product") or {}
    if product_name_key(product.get("name")) in names:
        product.pop("name", None)
    binding = item.get("product_binding") or {}
    if product_name_key(binding.get("declared_name")) in names:
        binding.pop("declared_name", None)
    if not active and item.get("status") == "awaiting_confirmation":
        item["status"] = "needs_clarification" if item.get("questions") else "ready"
        item["plan"] = [task for task in item.get("plan", [])
                        if task.get("id") not in {"confirm_facts", "remember_facts"}]
        if result.get("status") == "awaiting_confirmation":
            result["status"] = item["status"]
    return result


def preserve_archived_exclusions(view, draft):
    """An older/compact client cannot erase an established exclusion by omission.

    Only the narrow projection above supplies these IDs. Other unchecked facts,
    explicit new selections or edits keep their normal draft semantics.
    """
    if not isinstance(draft, dict) or not isinstance(draft.get("selected", {}), dict):
        return draft
    projected = project_excluded_legacy_draft(view)
    archive = ((projected.get("intake") or {}).get("draft_projection") or {}).get("archived_candidates", [])
    omitted = {candidate["id"]: False for candidate in archive if candidate["id"] not in draft.get("selected", {})}
    return {**copy.deepcopy(draft), "selected": {**omitted, **draft.get("selected", {})}} if omitted else draft
