"""One public release identity for health, status and the running app."""
VERSION = '0.5'
APP_VERSION = '0.5.0'
BUILD_REVISION = 'cost-card-a11y-2026-10-28'


def metadata():
    return {'version': VERSION, 'build_revision': BUILD_REVISION}
