"""Loopback main app, explicit real Claude dispatch only; no simulated fallback."""
import argparse
import ipaddress
import os
from pathlib import Path
import socket


def network_guard():
    from nmate.v03.source_refresh import ALLOWED_HOSTS
    hosts = set(ALLOWED_HOSTS) | {"api.anthropic.com", "hotrodoanhnghiep.hanoi.gov.vn", "hanoi.gov.vn", "vanban.hanoi.gov.vn"}
    lookup, connect, connect_ex = socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex
    ips = set()
    counts = {"blocked_network_attempts": 0}

    def local(host):
        if host == "localhost":
            return True
        try:
            return ipaddress.ip_address(host).is_loopback
        except ValueError:
            return False

    def deny():
        counts["blocked_network_attempts"] += 1
        raise OSError("Main application blocked destination")

    def getaddrinfo(host, *args, **kwargs):
        if isinstance(host, bytes):
            host = host.decode("ascii", "strict")
        policy_host = isinstance(host, str) and (host in {"hanoi.gov.vn", "chinhphu.vn"} or
            host.endswith(".hanoi.gov.vn") or host.endswith(".chinhphu.vn"))
        if host not in hosts and not policy_host and host not in ips and not local(host):
            deny()
        values = lookup(host, *args, **kwargs)
        if host in hosts or policy_host:
            addresses = {value[4][0] for value in values}
            if not addresses or any(not ipaddress.ip_address(ip).is_global for ip in addresses):
                deny()
            ips.update(addresses)
        return values

    def check(address):
        if isinstance(address, tuple) and not local(address[0]) and (address[0] not in ips or address[1] != 443):
            deny()

    def guarded_connect(sock, address):
        check(address)
        return connect(sock, address)

    def guarded_connect_ex(sock, address):
        check(address)
        return connect_ex(sock, address)

    socket.getaddrinfo, socket.socket.connect, socket.socket.connect_ex = getaddrinfo, guarded_connect, guarded_connect_ex
    return counts


def main():
    parser = argparse.ArgumentParser(description="nMate main · Claude thật · không tự retry có phí")
    parser.add_argument("--port", type=int, default=8025)
    parser.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parents[3] / ".data-v03a-fake")
    parser.add_argument("--web-dir", type=Path, default=Path(__file__).resolve().parents[4] / "nmate-mvp-v0.1")
    parser.add_argument("--env-file", type=Path, default=Path(__file__).resolve().parents[3] / ".env")
    parser.add_argument("--schema-contract",type=Path,
                        help="Hợp đồng schema đã ghim trong bản phát hành; runtime chỉ kiểm, không migration.")
    parser.add_argument('--cost-approval-binding',type=Path)
    parser.add_argument('--cost-approval-sha256')
    parser.add_argument("--max-attempts", type=int, default=40)
    parser.add_argument("--audit-mode", action="store_true")
    parser.add_argument("--cookie-namespace", default="nmate_v04a")
    parser.add_argument("--enable-approved-gateway", action="store_true",
                        help="Chỉ bật sau khi D06 được duyệt; vẫn cần grant có phạm vi và hạn mức cụ thể trong server.")
    args = parser.parse_args()
    binding=None
    if args.cost_approval_binding is not None or args.cost_approval_sha256 is not None:
        if not args.cost_approval_binding or not args.cost_approval_sha256:raise RuntimeError('Cần assignment và pin đã được duyệt.')
        from nmate.knowledge_v1.cost_authority import ApproverAssignment
        binding=ApproverAssignment.load(args.cost_approval_binding,args.cost_approval_sha256)
    from nmate.config import Settings
    settings = Settings(_env_file=args.env_file)
    if settings.model_provider != "anthropic" or not settings.model_configured:
        raise RuntimeError("Claude chưa được cấu hình đúng. Chưa gửi yêu cầu nào.")
    if args.audit_mode and args.port == 8025:
        raise RuntimeError("Review dùng dữ liệu riêng và cổng riêng, không dùng cổng app chính.")
    if (settings.simple_model, settings.complex_model) != ("claude-sonnet-5-5", "claude-opus-5-5"):
        raise RuntimeError("Cấu hình model khác chính sách Sonnet 5.5 / Opus 5.5 đã chọn.")
    os.environ["LANGSMITH_TRACING"] = "false"
    os.environ["LANGCHAIN_TRACING_V2"] = "false"
    from .runtime_lock import EnterpriseRuntimeLock, RuntimeAlreadyRunning
    from nmate.core_v1.runtime_schema import RuntimeSchemaError
    try:
        # A duplicate process must not touch provider/recovery state before it
        # discovers that the app is already running with this same database.
        with EnterpriseRuntimeLock(args.data_dir / "enterprise.sqlite3"):
            from nmate.core_v1.runtime_schema import managed_runtime, verify_runtime_database
            readiness = verify_runtime_database(args.data_dir / "enterprise.sqlite3",contract_path=args.schema_contract)
            counts = network_guard()
            from .app import make_main_app
            with managed_runtime():
                app = make_main_app(args.data_dir / "enterprise.sqlite3", port=args.port, web_dir=args.web_dir,
                    api_key=settings.anthropic_api_key.get_secret_value(), simple_model=settings.simple_model,
                    complex_model=settings.complex_model, max_attempts=args.max_attempts,
                    budget_scope="global" if args.audit_mode else "owner_daily", audit_mode=args.audit_mode,
                    cookie_namespace=args.cookie_namespace, gateway_enabled=args.enable_approved_gateway,cost_approval_binding=binding)
            app.state.schema_readiness = readiness
            app.state.network_guard = counts
            import uvicorn
            uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning", access_log=False)
    except (RuntimeAlreadyRunning, RuntimeSchemaError) as exc:
        raise SystemExit(str(exc)) from None


if __name__ == "__main__":
    main()
