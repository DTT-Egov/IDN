"""Owner-private, read-only archive of a paid export intake rejected by the app.

This is an archive projection, not plan recovery or publication. A provider's
stored structured observation cannot substitute for the missing original user
question, current SSOT, or source-checked regulatory research. No model, worker,
SSOT mutation, schema migration, or cache replay is reachable from this module.
"""
from __future__ import annotations

import hashlib
import json

from pydantic import ValidationError

from nmate.v03.core import CoreError
from nmate.v03.live_review import IntakeOutput


_TITLES = {"registration": "Đăng ký hoặc điều kiện cơ sở", "label": "Nhãn thực phẩm",
           "prior_notice": "Thông báo trước lô hàng", "certification": "Yêu cầu chứng nhận"}


def project_recorded_export_intake(repo, account, enterprise, conversation_id, db=None, *, authorize_envelope=None):
    """Return the latest failed operation's saved intake, after ownership checks.

    Only an unlinked, successful provider intake is shown. Original text was not
    always durably retained by the old sender, so this function deliberately
    performs structural parsing only and cannot mark an outcome validated.
    An existing caller-owned read transaction can be passed in ``db``.
    """
    if db is None:
        with repo.connection() as conn:
            return project_recorded_export_intake(repo, account, enterprise, conversation_id, conn,
                                                  authorize_envelope=authorize_envelope)
    repo.get_membership(account, enterprise, db)
    owned = db.execute("SELECT id FROM v04_conversations WHERE id=? AND enterprise_id=? AND owner_id=?",
                       (conversation_id, enterprise, account)).fetchone()
    if not owned:
        raise CoreError("not_found", "Không tìm thấy cuộc trao đổi của tài khoản này.", 404)
    operation = db.execute("SELECT * FROM main_operations WHERE account_id=? AND enterprise_id=? AND conversation_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1",
                           (account, enterprise, conversation_id)).fetchone()
    if not operation or operation["state"] != "failed" or operation["task_hint"] != "export_research":
        return None
    if operation["error_code"] != "live_output_invalid":
        return None
    attempt = db.execute("SELECT * FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND operation_id=? AND kind='intake'",
                         (account, enterprise, operation["operation_id"])).fetchone()
    if not attempt or attempt["state"] != "succeeded" or attempt["mission_id"] is not None or not attempt["response_json"]:
        return None
    # A linked plan is displayed by the normal authorized mission projection.
    # This archive must not become a second source of truth for such a plan.
    if db.execute("SELECT 1 FROM v03_mission_operations WHERE account_id=? AND enterprise_id=? AND operation_id=? AND kind='prepare'",
                  (account, enterprise, operation["operation_id"])).fetchone():
        return None
    try:
        envelope = json.loads(attempt["response_json"])
    except (ValueError, TypeError):
        return None
    if not isinstance(envelope, dict) or envelope.get("attempt_id") != attempt["id"]:
        return None
    # DF-029/046: authorization is outside the parsing error boundary because
    # CoreError inherits ValueError. A denied READ must remain a typed denial.
    # Native pre-gateway archives keep their original limited contract;
    # never invent input dependencies from today's context for old rows.
    if "gateway_attempt_id" in envelope:
        gateway_id = envelope["gateway_attempt_id"]
        if not isinstance(gateway_id, str) or not gateway_id or not callable(authorize_envelope):
            raise CoreError("RECORDED_AUTHORITY_UNAVAILABLE",
                            "Chưa kiểm được quyền đọc kết quả đã lưu. Không gọi AI.", 409)
        authorize_envelope(account, enterprise, envelope, db=db, require_complete_lineage=True)
    try:
        raw = envelope.get("data")
        value = IntakeOutput.model_validate_json(raw) if isinstance(raw, str) else IntakeOutput.model_validate(raw)
    except (ValueError, TypeError, ValidationError):
        return None
    return {
        "status": "saved_intake_not_revalidated",
        "verification_state": "structure_only_original_question_not_revalidated",
        "title_vi": "Phân tích mục tiêu đã lưu · chưa có câu trả lời nghiên cứu",
        "message_vi": "Claude đã xử lý lượt có phí này. Dưới đây là phân tích mục tiêu đã lưu; app chưa đối chiếu lại đầy đủ với câu hỏi gốc và chưa nghiên cứu quy định. Đây chưa phải kế hoạch được xác nhận hay câu trả lời FDA/nhãn. Không gọi thêm AI.",
        "operation_id": operation["operation_id"],
        "reported_product_name": value.product_name,
        "reported_market_scope": value.scope,
        "outcomes": [{"id": outcome.id, "title": _TITLES[outcome.id],
                      "question_quote": outcome.question_quote, "verification_state": "archival_not_revalidated"}
                     for outcome in value.outcomes if outcome.id != "clarification"],
        "clarification_requests": [outcome.question_quote for outcome in value.outcomes if outcome.id == "clarification"],
        "preliminary_information_gaps": list(value.ambiguities),
        "receipt": {"attempt_id": attempt["id"], "model": attempt["model"],
                    "state": attempt["state"], "created_at": attempt["created_at"],
                    "paid_calls_already_recorded": 1,
                    "original_response_sha256": hashlib.sha256(attempt["response_json"].encode()).hexdigest()},
        "research_completed": False, "answers": [], "actions": [], "artifacts": [],
        "can_start_research": False, "new_model_calls": 0, "ssot_writes": 0,
        "original_result_preserved": True,
    }
