"""Free correction of unused source dependencies known invalid at plan creation.

Never removes a source that a plan was allowed to use. A source invalidated
after creation, any research/start receipt, changed facts or changed remaining
sources blocks this correction. Raw records, coverage and sources are immutable.
"""
from copy import deepcopy
from datetime import datetime, timezone
import json

from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.live_review import LiveIntent
from nmate.v03.missions import digest, make_plan


SCHEMA = """
CREATE TABLE IF NOT EXISTS main_source_binding_recoveries (
 mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id),
 original_source_refs_json TEXT NOT NULL, dropped_source_refs_json TEXT NOT NULL,
 previous_plan_hash TEXT NOT NULL, reason TEXT NOT NULL, recovered_at TEXT NOT NULL);
"""


def _stamp(value):
    try:
        stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return stamp.astimezone(timezone.utc) if stamp.tzinfo is not None else None
    except (TypeError, ValueError):
        return None


def _exists(db, table):
    return db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


def _unstarted(db, mission_id):
    if db.execute("SELECT 1 FROM v03_task_attempts WHERE mission_id=? AND state!='planned'", (mission_id,)).fetchone():
        return False
    if db.execute("SELECT 1 FROM v03_mission_operations WHERE mission_id=? AND kind='start'", (mission_id,)).fetchone():
        return False
    if _exists(db, "main_research_authorizations") and db.execute(
            "SELECT 1 FROM main_research_authorizations WHERE mission_id=?", (mission_id,)).fetchone():
        return False
    if _exists(db, "v03_live_attempts") and db.execute(
            "SELECT 1 FROM v03_live_attempts WHERE kind='research' AND (mission_id=? OR operation_id=?)",
            (mission_id, f"research:{mission_id}")).fetchone():
        return False
    if _exists(db, "v03_live_review_stages") and db.execute(
            "SELECT 1 FROM v03_live_review_stages WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone():
        return False
    if _exists(db, "v03_live_review_outputs") and db.execute(
            "SELECT 1 FROM v03_live_review_outputs WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone():
        return False
    return True


def _droppable_refs(db, mission):
    refs = mission["knowledge"]["source_refs"]
    created = _stamp(mission["created_at"])
    if created is None or len({ref["source_id"] for ref in refs}) != len(refs):
        return []
    dropped = []
    for ref in refs:
        records = [record for record in mission["knowledge"]["records"] if record.get("source_id") == ref["source_id"]]
        if not records or any(record.get("reusable") is not False for record in records):
            continue
        if any(record.get("source_version") != ref["version"] or record.get("content_sha256") != ref["content_sha256"] for record in records):
            continue
        source = db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (ref["source_id"],)).fetchone()
        if (not source or source["version"] != ref["version"] or source["content_sha256"] != ref["content_sha256"]
                or source["freshness_state"] in {"recorded_snapshot", "reviewed_current"}):
            continue
        invalidated = _stamp(source["invalidated_at"])
        if invalidated is None or invalidated > created:
            continue
        dependency = db.execute("SELECT dependency_version FROM v03_dependencies WHERE mission_id=? AND enterprise_id=? AND dependency_kind='source' AND dependency_key=?",
                                (mission["id"], mission["enterprise_id"], ref["source_id"])).fetchone()
        if not dependency or str(dependency[0]) != str(ref["version"]):
            continue
        dropped.append(ref)
    return dropped


def recover_unused_source_bindings(repo):
    """Return corrected mission IDs; no provider, network, SSOT or raw edits."""
    with repo.connection(write=True) as db:
        db.executescript(SCHEMA)
    with repo.connection() as db:
        if not _exists(db, "v03_live_review_outputs"):
            return []
        rows = list(db.execute(
            "SELECT m.id,m.owner_id,m.enterprise_id,m.version,m.status,m.payload_json FROM v03_missions m "
            "JOIN v03_live_review_outputs o ON o.mission_id=m.id AND o.kind='intake' "
            "WHERE m.status IN ('planned','waiting_input')"))
    recovered = []
    for row in rows:
        try:
            with repo.connection(write=True) as db:
                repo.get_membership(row["owner_id"], row["enterprise_id"], db)
                current = db.execute("SELECT status,version,payload_json FROM v03_missions WHERE id=? AND owner_id=? AND enterprise_id=?",
                                     (row["id"], row["owner_id"], row["enterprise_id"])).fetchone()
                if (not current or current["status"] != row["status"] or current["version"] != row["version"]
                        or current["payload_json"] != row["payload_json"] or not _unstarted(db, row["id"])):
                    continue
                if db.execute("SELECT 1 FROM main_source_binding_recoveries WHERE mission_id=?", (row["id"],)).fetchone():
                    continue
                mission = json.loads(current["payload_json"])
                if mission.get("mode") != "live_claude_review" or mission.get("answers") or mission.get("artifacts"):
                    continue
                if (mission.get("id") != row["id"] or mission.get("owner_id") != row["owner_id"]
                        or mission.get("enterprise_id") != row["enterprise_id"]):
                    continue
                market = (mission.get("market") or {}).get("code")
                if market not in {"US", "DE", "JP"} or mission["knowledge"].get("market_code") != market:
                    continue
                product = repo._entity(row["owner_id"], row["enterprise_id"], mission["product"]["entity_id"], db)
                if product["entity_type"] != "product":
                    continue
                task_rows = list(db.execute("SELECT task_id,attempt,state FROM v03_task_attempts WHERE mission_id=?", (row["id"],)))
                if (not task_rows or any(task["attempt"] != 1 or task["state"] != "planned" for task in task_rows)
                        or {task["task_id"] for task in task_rows} != {task["id"] for task in mission["plan"]["tasks"]}):
                    continue
                dropped = _droppable_refs(db, mission)
                if not dropped:
                    continue
                dropped_ids = {ref["source_id"] for ref in dropped}
                remaining = [ref for ref in mission["knowledge"]["source_refs"] if ref["source_id"] not in dropped_ids]
                if not repo.validate_context(row["owner_id"], row["enterprise_id"], mission["context"]["fact_refs"], remaining)["valid"]:
                    continue
                plan = make_plan(LiveIntent.model_validate(mission["intent"])).model_dump()
                if {key: value for key, value in plan.items() if key != "hash"} != {key: value for key, value in mission["plan"].items() if key != "hash"}:
                    continue
                plan_hash = digest({"plan": plan, "enterprise_id": row["enterprise_id"],
                                    "fact_refs": mission["context"]["fact_refs"], "source_refs": remaining})
                stamp = now_iso()
                db.execute("INSERT INTO main_source_binding_recoveries VALUES(?,?,?,?,?,?)",
                           (row["id"], json_text(mission["knowledge"]["source_refs"]), json_text(dropped),
                            mission["plan"]["hash"], "known_unusable_unused_source_at_creation", stamp))
                for ref in dropped:
                    db.execute("DELETE FROM v03_dependencies WHERE mission_id=? AND enterprise_id=? AND dependency_kind='source' AND dependency_key=? AND dependency_version=?",
                               (row["id"], row["enterprise_id"], ref["source_id"], str(ref["version"])))
                mission["knowledge"]["source_refs"] = deepcopy(remaining)
                mission["plan"]["hash"] = plan_hash
                mission["source_binding_recovery"] = {
                    "dropped_source_ids": sorted(dropped_ids), "known_unusable_at_creation": True,
                    "coverage_gap_preserved": True, "model_calls": 0, "ssot_writes": 0,
                    "message": "Nguồn đã không được phép dùng khi lập kế hoạch vẫn bị loại khỏi nghiên cứu. Chỉ bỏ liên kết chờ rà thừa; giữ nguyên phần thiếu nguồn và bản gốc, chưa chạy AI.",
                    "at": stamp,
                }
                mission["updated_at"] = stamp
                db.execute("UPDATE v03_missions SET payload_json=?,version=version+1,updated_at=? WHERE id=? AND status=? AND version=?",
                           (json_text(mission), stamp, row["id"], row["status"], row["version"]))
                recovered.append(row["id"])
        except (CoreError, ValueError, TypeError, KeyError):
            continue
    return recovered
