"""Read-only identity guard for export plans saved before explicit binding."""
from nmate.v04.extraction import product_name_key
from nmate.v04.product_binding import declared_product_name, owned_product_names


def mission_binding_warning(repo, account, enterprise, mission):
    product = mission.get("product") or {}
    product_id = product.get("entity_id") or product.get("id")
    declared = declared_product_name(mission.get("question", ""))
    if not product_id or not declared:
        return None
    with repo.connection() as db:
        entity, names = owned_product_names(repo, account, enterprise, product_id, db)
        if product_name_key(declared) in names:
            return None
        attempts = []
        if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='v03_live_attempts'").fetchone():
            attempts = list(db.execute(
                "SELECT a.id FROM v03_live_attempts a WHERE a.account_id=? AND a.enterprise_id=? AND a.state!='prepared' "
                "AND (a.mission_id=? OR a.operation_id IN (SELECT operation_id FROM v03_mission_operations "
                "WHERE account_id=? AND enterprise_id=? AND kind='prepare' AND mission_id=?))",
                (account, enterprise, mission["id"], account, enterprise, mission["id"])))
    dispatched = bool(attempts or (mission.get("cost") or {}).get("calls"))
    message = ("Tên sản phẩm trong câu hỏi khác hồ sơ của kế hoạch cũ. "
               "Cần chọn hoặc xác nhận đúng sản phẩm và lập kế hoạch mới. ")
    message += ("Lượt này đã gửi Claude; chi phí đã ghi nhận được giữ trong lịch sử, không tự gửi lại."
                if dispatched else "Chưa gửi Claude cho kế hoạch này.")
    return {"code": "product_identity_mismatch", "message_vi": message,
            "declared_name": declared, "selected_product_name": entity["name"],
            "selected_product_id": product_id, "requires_new_plan": True,
            "provider_dispatched": dispatched, "provider_attempt_count": len(attempts)}
