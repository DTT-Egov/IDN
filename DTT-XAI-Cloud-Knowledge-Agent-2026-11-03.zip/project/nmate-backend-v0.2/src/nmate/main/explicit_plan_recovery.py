"""Explicit free correction of a model-demoted, unstarted intake plan.

Never called at boot, by MCP, or by a worker. The original question, provider
receipt and intake output must still match; no provider transport is reachable.
Only mission/task/source bindings are revised, with the old rows audited.
"""
from __future__ import annotations

import asyncio
from copy import deepcopy
import hashlib
import json

from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.evidence import outcome_topic
from nmate.v03.live_review import interpret_validated_intake, validate_intake
from nmate.v03.missions import digest, make_plan, resolve_market


SCHEMA = """
CREATE TABLE IF NOT EXISTS main_explicit_intake_recoveries (
 mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id), account_id TEXT NOT NULL,
 enterprise_id TEXT NOT NULL, provider_attempt_id TEXT NOT NULL,
 original_response_sha256 TEXT NOT NULL, original_intake_sha256 TEXT NOT NULL,
 original_rows_json TEXT NOT NULL, source_refresh_json TEXT NOT NULL, recovered_at TEXT NOT NULL);
"""


def _refuse(message="Kế hoạch đã lưu không đủ điều kiện sửa mục tiêu miễn phí."):
    return CoreError("EXPLICIT_INTAKE_RECOVERY_REFUSED", message, 409)


def _read(service, db, account, enterprise, mission_id):
    row = dict(service._row(account, enterprise, mission_id, db))
    mission = json.loads(row["payload_json"])
    output = db.execute("SELECT * FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (mission_id,)).fetchone()
    if row["status"] != "waiting_input" or not output:
        raise _refuse()
    if ({outcome["id"] for outcome in mission["intent"]["outcomes"]} != {"clarification"}
            or mission.get("product_candidates") or not mission.get("product")
            or mission.get("answers") or mission.get("artifacts")):
        raise _refuse()
    market = (mission.get("market") or {}).get("code")
    code, _, issues = resolve_market(mission["question"], market)
    if code not in {"US", "DE", "JP"} or issues or code != market:
        raise _refuse()
    raw = json.loads(output["output_json"])
    validated = validate_intake({"data": raw}, mission["question"], code)
    if mission["intent"]["ambiguities"] != validated.ambiguities:
        raise _refuse("Kế hoạch có xung đột do máy chủ phát hiện; không bỏ qua để nghiên cứu.")
    intent, name = interpret_validated_intake(validated, mission["question"], code)
    if not intent.server_recovered_outcomes or intent.ambiguities:
        raise _refuse()
    product = mission["product"]["entity_id"]
    service.repo.get_entity(account, enterprise, product)
    if name and product not in {entity["id"] for entity in service.repo.find_entities_by_name(account, enterprise, name)}:
        raise _refuse("Tên sản phẩm không còn khớp hồ sơ được chọn.")
    checked = service.repo.validate_context(account, enterprise, mission["context"]["fact_refs"], mission["knowledge"]["source_refs"])
    if not checked["valid"] or not service._facility_binding_valid(account, enterprise, mission["context"]):
        raise _refuse("Hồ sơ hoặc nguồn đã đổi; không tự lấy dữ kiện mới thay kế hoạch cũ.")
    metadata = json.loads(output["metadata_json"])
    attempt = db.execute("SELECT * FROM v03_live_attempts WHERE id=? AND account_id=? AND enterprise_id=? AND kind='intake'",
                         (metadata.get("attempt_id"), account, enterprise)).fetchone()
    if not attempt or attempt["state"] != "succeeded" or not attempt["response_json"] or attempt["mission_id"] not in {None, mission_id}:
        raise _refuse("Lượt nhà cung cấp chưa rõ kết quả; không gửi lại.")
    prepared = db.execute("SELECT * FROM v03_mission_operations WHERE account_id=? AND enterprise_id=? AND mission_id=? AND operation_id=? AND kind='prepare'",
                          (account, enterprise, mission_id, attempt["operation_id"])).fetchone()
    original_request = {"text": mission["question"], "product_entity_id": product, "market_code": code}
    if mission.get("continuation_mission_id"):
        original_request["continuation_mission_id"] = mission["continuation_mission_id"]
    if not prepared or prepared["request_hash"] != digest(original_request):
        raise _refuse("Câu hỏi, sản phẩm hoặc thị trường không còn khớp yêu cầu gốc đã lưu.")
    envelope = json.loads(attempt["response_json"])
    if (not isinstance(envelope, dict) or envelope.get("attempt_id") != attempt["id"]
            or validate_intake(envelope, mission["question"], code).model_dump() != validated.model_dump()):
        raise _refuse()
    tasks = [dict(item) for item in db.execute("SELECT * FROM v03_task_attempts WHERE mission_id=? ORDER BY task_id,attempt", (mission_id,))]
    if (not tasks or any(item["state"] != "planned" or item["result_json"] is not None for item in tasks)
            or db.execute("SELECT 1 FROM v03_live_attempts WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone()
            or db.execute("SELECT 1 FROM v03_live_review_stages WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone()
            or db.execute("SELECT 1 FROM v03_artifact_revisions WHERE mission_id=?", (mission_id,)).fetchone()):
        raise _refuse("Nghiên cứu đã được yêu cầu hoặc chưa rõ trạng thái; không sửa và chạy lại.")
    intent.market_code, intent.market_candidates = code, [code]
    dependencies = [dict(item) for item in db.execute("SELECT * FROM v03_dependencies WHERE mission_id=? ORDER BY dependency_kind,dependency_key", (mission_id,))]
    return row, mission, dict(output), dict(attempt), intent, tasks, dependencies


async def recover_explicit_intake_plan(service, account, enterprise, mission_id):
    """Refresh authority URLs, then revise one exact unstarted recorded plan.

    The caller explicitly invokes this maintenance action while its worker is
    stopped. Research remains a separate consent/budget-controlled action.
    """
    lock = service._locks.setdefault(("explicit_intake_recovery", mission_id), asyncio.Lock())
    async with lock:
        with service.repo.connection() as db:
            # Authorization precedes even checking the audit table.
            current = service._row(account, enterprise, mission_id, db)
            if current["status"] == "planned":
                payload = json.loads(current["payload_json"])
                if payload.get("plan_recovery", {}).get("reason") == "explicit_user_outcomes_restored_from_recorded_intake":
                    return service.get(account, enterprise, mission_id)
            original = _read(service, db, account, enterprise, mission_id)
        row, mission, output, attempt, intent, _, _ = original
        if service.source_refresher is None:
            raise _refuse("Cần bật bước đọc nguồn chính thức miễn phí trước khi sửa kế hoạch.")
        code = intent.market_code
        topics = list(dict.fromkeys(topic for outcome in intent.outcomes if (topic := outcome_topic(outcome.id, code)) is not None))
        refresh = await service.refresh_sources_async(account, enterprise, code, topics)
        knowledge = service.catalog.lookup_domain(topics, market_code=code)
        plan = make_plan(intent)
        plan.hash = digest({"plan": plan.model_dump(), "enterprise_id": enterprise,
                            "fact_refs": mission["context"]["fact_refs"], "source_refs": knowledge["source_refs"]})
        with service.repo.connection(write=True) as db:
            latest = _read(service, db, account, enterprise, mission_id)
            if latest != original:
                raise _refuse("Kế hoạch đã đổi trong lúc đọc nguồn; không ghi đè.")
            if not service.repo.validate_context(account, enterprise, mission["context"]["fact_refs"], knowledge["source_refs"])["valid"]:
                raise _refuse("Nguồn hoặc hồ sơ vừa đổi; không tạo kế hoạch từ bản cũ.")
            db.execute(SCHEMA)
            if db.execute("SELECT 1 FROM main_explicit_intake_recoveries WHERE mission_id=?", (mission_id,)).fetchone():
                raise _refuse()
            stamp = now_iso()
            audited = {"mission": row, "tasks": original[5], "dependencies": original[6]}
            db.execute("INSERT INTO main_explicit_intake_recoveries VALUES(?,?,?,?,?,?,?,?,?)", (
                mission_id, account, enterprise, attempt["id"], hashlib.sha256(attempt["response_json"].encode()).hexdigest(),
                hashlib.sha256(output["output_json"].encode()).hexdigest(), json_text(audited), json_text(refresh), stamp))
            mission.update(intent=intent.model_dump(), plan=plan.model_dump(), knowledge=knowledge, updated_at=stamp)
            mission["plan_recovery"] = {"reason": "explicit_user_outcomes_restored_from_recorded_intake", "model_calls": 0,
                "ssot_writes": 0, "original_intake_preserved": True, "at": stamp,
                "message": "Đã sửa kế hoạch theo các ý hỏi rõ trong câu gốc; giữ nguyên phân tích Claude đã trả phí. Thông tin còn thiếu được giữ để nghiên cứu có điều kiện. Chưa gọi nghiên cứu và không gửi lại lượt intake."}
            mission["research_provenance"] = {**deepcopy(mission.get("research_provenance", {})),
                "synthesis_mode": "research_not_started", "network_refresh": True, "network_checks": refresh.get("sources", []),
                "note_vi": "Mới phân tích mục tiêu và thử đọc nguồn chính thức; chưa tổng hợp câu trả lời nghiên cứu, chưa được duyệt pháp lý."}
            db.execute("DELETE FROM v03_task_attempts WHERE mission_id=?", (mission_id,))
            for task in plan.tasks:
                db.execute("INSERT INTO v03_task_attempts(mission_id,task_id,state) VALUES(?,?,'planned')", (mission_id, task.id))
            db.execute("DELETE FROM v03_dependencies WHERE mission_id=? AND dependency_kind='source'", (mission_id,))
            for source in knowledge["source_refs"]:
                db.execute("INSERT INTO v03_dependencies VALUES(?,?,?,?,?)", (mission_id, enterprise, "source", source["source_id"], str(source["version"])))
            db.execute("UPDATE v03_missions SET status='planned',stale_reason=NULL,version=version+1,payload_json=?,updated_at=? WHERE id=? AND version=? AND status='waiting_input'",
                       (json_text(mission), stamp, mission_id, row["version"]))
        return service.get(account, enterprise, mission_id)
