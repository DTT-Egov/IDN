"""Main local app: one identity, SSOT, history, MCP and real provider."""
from pathlib import Path
from contextvars import ContextVar
import json

from fastapi import Request, Query
from fastapi.responses import Response, HTMLResponse
from pydantic import BaseModel, ConfigDict, Field, SecretStr

from nmate.v03.app import create_app
from nmate.v03.core import CoreError, now_iso
from nmate.v03.field_scope import field_is_in_scope
from nmate.v03.live_review import LiveReviewMissionService
from nmate.v03.mcp import TOOL_NAMES as MISSION_TOOLS
from nmate.v03.source_refresh import AuthoritySourceRefresher
from nmate.v03.goal_readiness import project_goal_readiness, read_authority_records, project_delivery_status
from nmate.v04.live_review import LIVE_TOOLS
from .conversations import MainIntakeService
from .provider import MainProvider
from .partial import project_partial_research
from .product_scope import mission_binding_warning
from nmate.v04.product_binding import declared_product_name, owned_product_names, resolve_declared_product
from nmate.v04.extraction import product_name_key
from nmate.core_v1.integration import CORE_TOOLS
from .workspace_management import WorkspaceIntegration, WORKSPACE_TOOLS
from .release import APP_VERSION, metadata as release_metadata

MODE = "live_claude_main"
TOOLS = ((MISSION_TOOLS - {"prepare_mission"}) | LIVE_TOOLS | CORE_TOOLS | WORKSPACE_TOOLS |
         {"get_review_workspace", "get_review_receipt", "dismiss_review_candidates"})


class MainMissions(LiveReviewMissionService):
    requires_paid_consent = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._selected_identity = ContextVar(f"main-selected-product-{id(self)}", default=None)
        with self.repo.connection(write=True) as db:
            db.execute("CREATE TABLE IF NOT EXISTS main_research_authorizations (mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id), account_id TEXT NOT NULL, enterprise_id TEXT NOT NULL, operation_id TEXT NOT NULL, consent_at TEXT NOT NULL)")
        # Legacy content repairs are explicit migrations. Startup only recovers
        # durable in-flight operations via their existing no-replay ledger.
        self.recovered_intent_plans = []
        self.recovered_source_bindings = []

    async def prepare_async(self, account_id, enterprise_id, user_text, operation_id, product_entity_id=None,
                            continuation_mission_id=None, market_code=None):
        # A direct MCP caller has the same identity gate as main chat. This runs
        # before the intake provider or any D06 reservation can be reached.
        declared = declared_product_name(user_text)
        if continuation_mission_id and not product_entity_id:
            previous = self.get(account_id, enterprise_id, continuation_mission_id)
            product_entity_id = (previous.get("product") or {}).get("entity_id")
        with self.repo.connection() as db:
            self.repo.get_membership(account_id, enterprise_id, db)
            if not product_entity_id and declared:
                product_entity_id = resolve_declared_product(self.repo, account_id, enterprise_id, declared, db)
            if not product_entity_id:
                raise CoreError("product_confirmation_required", "Chọn hoặc xác nhận hồ sơ sản phẩm trước khi gửi nghiên cứu có phí.", 409)
            entity, aliases = owned_product_names(self.repo, account_id, enterprise_id, product_entity_id, db)
            if declared and product_name_key(declared) not in aliases:
                raise CoreError("product_confirmation_required", "Tên sản phẩm vừa nêu khác hồ sơ đang chọn. Chưa gửi Claude; cần chọn hoặc xác nhận đúng sản phẩm trước.", 409)
        token = self._selected_identity.set((entity["name"], aliases))
        try:
            return await super().prepare_async(account_id, enterprise_id, user_text, operation_id, product_entity_id,
                continuation_mission_id=continuation_mission_id, market_code=market_code)
        finally:
            self._selected_identity.reset(token)

    def _interpret_request(self, user_text):
        intent, name = super()._interpret_request(user_text)
        selected = self._selected_identity.get()
        if name and selected and product_name_key(name) in selected[1]:
            # Only presentation-equivalent owned aliases may use the current
            # identity spelling for lookup. The raw model/user receipt remains.
            name = selected[0]
        return intent, name

    def start(self, account_id, enterprise_id, mission_id, operation_id):
        current = self.get(account_id, enterprise_id, mission_id)
        if current.get("binding_warning"):
            raise CoreError("product_confirmation_required", current["binding_warning"]["message_vi"], 409)
        if current["status"] == "needs_revalidation":
            raise CoreError("context_changed", "Dữ kiện hoặc nguồn đã đổi; cần kế hoạch mới, không tự chạy lại.", 409)
        if current["status"] == "planned" and not current["research_scope"]["can_start_research"]:
            raise CoreError("research_source_gap", "Chưa đủ nguồn cho các ý đã hỏi. Đã dừng trước lượt nghiên cứu có phí; cần bổ sung nguồn chính thức.", 409)
        with self.repo.connection(write=True) as db:
            row = self._row(account_id, enterprise_id, mission_id, db)
            if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='main_conversation_visibility'").fetchone():
                archived_chat = db.execute("SELECT 1 FROM main_conversation_visibility v JOIN v04_conversations c ON c.id=v.conversation_id AND c.enterprise_id=v.enterprise_id AND c.owner_id=v.account_id WHERE v.enterprise_id=? AND v.account_id=? AND v.archived_at IS NOT NULL AND EXISTS(SELECT 1 FROM json_each(c.payload_json,'$.mission_ids') WHERE value=?) LIMIT 1",
                                           (enterprise_id,account_id,mission_id)).fetchone()
                if archived_chat:
                    raise CoreError("CONVERSATION_ARCHIVED", "Cuộc trao đổi đang ở Thùng rác. Chị khôi phục trước khi bắt đầu nghiên cứu; chưa gửi Claude.", 409)
            request = {"mission_id": mission_id, "version": 1}
            old = self._operation(db, account_id, enterprise_id, "start", operation_id, request)
            if not old:
                if row["status"] == "planned":
                    db.execute("UPDATE v03_missions SET status='queued',updated_at=? WHERE id=? AND status='planned'", (now_iso(), mission_id))
                elif row["status"] not in {"queued", "running", "completed", "completed_partial"}:
                    raise CoreError("mission_not_ready", "Hồ sơ đã đổi hoặc còn thiếu mục tiêu; cần lập kế hoạch mới, không tự chạy lại.", 409)
                # MCP checks paid_consent before entering this service. Queue
                # and durable permission commit together; old mock queues do
                # not gain permission simply by upgrading the server.
                db.execute("INSERT OR IGNORE INTO main_research_authorizations VALUES(?,?,?,?,?)", (mission_id, account_id, enterprise_id, operation_id, now_iso()))
                self._remember(db, account_id, enterprise_id, "start", operation_id, request, mission_id)
        return self.get(account_id, enterprise_id, mission_id)

    async def _ensure_research(self, mission_id):
        current = self._internal(mission_id)
        warning = mission_binding_warning(self.repo, current["owner_id"], current["enterprise_id"], current)
        if warning:
            raise CoreError("product_confirmation_required", warning["message_vi"], 409)
        with self.repo.connection() as db:
            row = db.execute("SELECT 1 FROM main_research_authorizations WHERE mission_id=?", (mission_id,)).fetchone()
        if row is None:
            raise CoreError("PAID_CONSENT_REQUIRED", "Hồ sơ cũ chưa có đồng ý nghiên cứu Claude thật. Đã dừng; không tự tạo lượt có phí.", 409)
        return await super()._ensure_research(mission_id)

    def _context_usage(self, account, enterprise, mission, db):
        """Explain count scopes without expanding or rewriting research input.

        The plan's snapshot remains historical. Current counts use precisely
        its owned product, with the existing fact-scope/freshness rules, in one
        SQL read snapshot. Neither count implies independent verification.
        """
        product_id = (mission.get("product") or {}).get("entity_id")
        if not product_id:
            return None
        current_entity = self.repo._entity(account, enterprise, product_id, db)
        current_facts = self.repo._facts(db, enterprise, product_id)
        def known_fields(facts, entity_type):
            return {fact["field"] for fact in facts
                    if isinstance(fact, dict) and isinstance(fact.get("field"), str)
                    and fact.get("value_state") == "known" and fact.get("value") is not None
                    and fact.get("freshness_state", "self_declared") == "self_declared"
                    and field_is_in_scope(entity_type, fact["field"])}
        current_fields = known_fields(current_facts, current_entity["entity_type"])
        snapshot = mission.get("context") if isinstance(mission.get("context"), dict) else {}
        prior_entities = snapshot.get("entities") if isinstance(snapshot.get("entities"), list) else []
        prior_entity = next((entity for entity in prior_entities if isinstance(entity, dict)
                             and (entity.get("id") or entity.get("entity_id")) == product_id), {})
        prior_fields = None
        if isinstance(prior_entity.get("facts"), list):
            prior_fields = known_fields(prior_entity["facts"], current_entity["entity_type"])
        elif "facts" not in prior_entity and isinstance(prior_entity.get("values"), dict):
            prior_fields = {key for key, value in prior_entity.get("values", {}).items()
                            if value is not None and field_is_in_scope(current_entity["entity_type"], key)}
        plan_shared = snapshot.get("reused_shared_fact_count")
        if isinstance(plan_shared, bool) or not isinstance(plan_shared, int) or plan_shared < 0:
            shared_values = snapshot.get("shared_values", prior_entity.get("values"))
            plan_shared = len(shared_values) if isinstance(shared_values, dict) else len(prior_fields) if prior_fields is not None else None
        current_revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (enterprise,)).fetchone()[0]
        snapshot_revision = snapshot.get("context_revision")
        return {"schema_version": "mission-context-usage/1", "product_entity_id": product_id,
                "current_product_confirmed_fact_count": len(current_fields),
                "plan_product_fact_count": len(prior_fields) if prior_fields is not None else None, "plan_shared_fact_count": plan_shared,
                "snapshot_count_available": prior_fields is not None,
                "omitted_current_field_keys": sorted(current_fields - prior_fields) if prior_fields is not None else [],
                "snapshot_context_revision": snapshot_revision, "current_context_revision": current_revision,
                "snapshot_product_version": prior_entity.get("version", (mission.get("product") or {}).get("snapshot_version")),
                "current_product_version": current_entity["version"],
                "context_revision_changed": snapshot_revision != current_revision}

    def get(self, account_id, enterprise_id, mission_id):
        result = super().get(account_id, enterprise_id, mission_id)
        warning = mission_binding_warning(self.repo, account_id, enterprise_id, result)
        if warning:
            result["binding_warning"] = warning
            result["research_scope"] = {**result.get("research_scope", {}), "can_start_research": False}
            if result["status"] == "planned":
                result["status"] = "needs_product_confirmation"
        with self.repo.connection() as db:
            usage = self._context_usage(account_id, enterprise_id, result, db)
            if usage is not None:
                result["context_usage"] = usage
            readiness = project_goal_readiness(result, read_authority_records(db, (result.get("market") or {}).get("code")))
            if readiness is not None:
                result["goal_readiness"] = readiness
            result["delivery_status"] = project_delivery_status(result)
            row = db.execute("SELECT operation_id FROM v03_mission_operations WHERE account_id=? AND enterprise_id=? AND kind='start' AND mission_id=? ORDER BY rowid DESC LIMIT 1", (account_id, enterprise_id, mission_id)).fetchone()
            attempt_ids = {r[0] for r in db.execute(
                "SELECT id FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND (mission_id=? OR operation_id IN "
                "(SELECT operation_id FROM v03_mission_operations WHERE account_id=? AND enterprise_id=? AND kind='prepare' AND mission_id=?)) AND state!='prepared'",
                (account_id, enterprise_id, mission_id, account_id, enterprise_id, mission_id))}
            raw = db.execute("SELECT response_json FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND mission_id=? AND kind='research' AND state='succeeded' AND response_json IS NOT NULL ORDER BY created_at DESC,id DESC LIMIT 1",
                             (account_id, enterprise_id, mission_id)).fetchone() if result["status"] == "failed" else None
            cost_receipts = {}
            if attempt_ids:
                for native in db.execute("SELECT id,kind,operation_id,model,response_json FROM v03_live_attempts WHERE account_id=? AND enterprise_id=?",
                                         (account_id, enterprise_id)):
                    if native["id"] not in attempt_ids:
                        continue
                    try:
                        envelope = json.loads(native["response_json"] or "{}")
                    except (TypeError, ValueError):
                        envelope = {}
                    gateway_id = envelope.get("gateway_attempt_id") if isinstance(envelope, dict) else None
                    receipt = db.execute("SELECT id,actual_microusd,price_version,usage_json,created_at,dispatched_at,finished_at,state,validation_state "
                        "FROM core_model_attempts WHERE id=? AND enterprise_id=? AND actor_id=? AND operation_id=? AND task_id=? AND step_key='synthesis' AND model=?",
                        (gateway_id, enterprise_id, account_id, native["operation_id"], "legacy_" + native["kind"], native["model"])).fetchone() if gateway_id else None
                    # Only the durable native envelope's exact scoped ledger
                    # reference establishes actual cost. No usage estimate or
                    # nearest operation/date/model is treated as a receipt.
                    cost_receipts[native["id"]] = {"kind": native["kind"], "gateway_attempt_id": receipt["id"] if receipt else None,
                        "actual_microusd": receipt["actual_microusd"] if receipt else None,
                        "price_version": receipt["price_version"] if receipt else None,
                        "dispatched_at": receipt["dispatched_at"] if receipt else None,
                        "finished_at": receipt["finished_at"] if receipt else None,
                        "gateway_state": receipt["state"] if receipt else None,
                        "validation_state": receipt["validation_state"] if receipt else None,
                        "is_invoice": False}
                    if receipt:
                        try:
                            usage = json.loads(receipt["usage_json"] or "{}")
                        except (TypeError, ValueError):
                            usage = {}
                        cost_receipts[native["id"]]["usage"] = usage if isinstance(usage, dict) else {}
        result["latest_start_operation_id"] = row[0] if row else None
        router = getattr(self.model_call, "_model", None)
        if callable(router):
            # Reuse the authoritative dispatch router; a grant never selects a
            # model. Research's actual request uses these same outcomes.
            from nmate.core_v1.gateway import PROFILES
            try:
                model = router("research", {"input": {"outcomes": result.get("intent", {}).get("outcomes", [])}})
            except Exception:
                # Advisory metadata cannot prevent reading a stored result or
                # authorize a fallback when its configured router is unknown.
                model = None
            role = next((name for name, profile in PROFILES.items() if profile["model"] == model), None)
            if role is not None:
                result["research_model_requirement"] = {"purpose": "legacy_research", "role": role, "model": model}
        if attempt_ids and hasattr(self.model_call, "summary"):
            summary = self.model_call.summary(account_id=account_id, enterprise_id=enterprise_id)
            calls = [{**a, "attempt_id": a["id"], **cost_receipts.get(a["id"], {})} for a in summary["attempts"] if a["id"] in attempt_ids]
            result["cost"] = {**{k: v for k, v in summary.items() if k != "attempts"}, "calls": calls,
                              "paid_calls": len(calls), "provider_attempts": len(calls),
                              "cost_scope": "mission_prepare_and_research", "is_invoice": False,
                              "estimated_usd": round(sum(a["estimated_usd"] for a in calls), 6) if calls and all(isinstance(a.get("estimated_usd"), (int, float)) for a in calls) else None,
                              "completed_provider_calls": sum(c["state"] == "succeeded" for c in calls)}
        if raw and self.repo.validate_context(account_id, enterprise_id, result["context"]["fact_refs"], result["knowledge"]["source_refs"])["valid"]:
            try:
                partial = project_partial_research(result, json.loads(raw[0]))
                # Raw output and audit details stay in the durable provider
                # ledger; the UI only receives whole independently valid parts.
                partial.pop("audit", None)
                result["strict_partial"] = partial
            except (CoreError, ValueError, TypeError):
                pass  # A read may never turn malformed data into publication.
        from nmate.core_v1.workspace_contract import resource_workspace_contract
        with self.repo.connection() as db:
            market_code = (result.get("market") or {}).get("code")
            if market_code in {"US", "DE", "JP"}:
                reference_ids = [record["id"] for record in (result.get("knowledge") or {}).get("records", [])
                                 if isinstance(record, dict) and isinstance(record.get("id"), str)]
                result["domain_graph"] = self.catalog.domain_graph(market_code=market_code, reference_ids=reference_ids, db=db)
            result["workspace_contract"] = resource_workspace_contract(self.repo, account_id, enterprise_id, result, db, kind="research")
        return result


def make_main_app(db_path, *, api_key=None, simple_model="claude-sonnet-5-5", complex_model="claude-opus-5-5",
                  port=8025, web_dir=None, request_fn=None, max_attempts=40, budget_scope="owner_daily",
                  cookie_namespace="nmate_v04a", refresh_sources=True, audit_mode=False,
                  enforce_d06=True, gateway_enabled=False, gateway_request_fn=None,cost_approval_binding=None):
    holder = {}

    def missions_factory(repo, task_delay):
        provider = MainProvider(repo, api_key=api_key, simple_model=simple_model, complex_model=complex_model,
                                request_fn=request_fn, max_attempts=max_attempts, budget_scope=budget_scope)
        provider.recover()
        missions = MainMissions(repo, model_call=provider, task_delay=0)
        if refresh_sources:
            missions.source_refresher = AuthoritySourceRefresher(repo, missions.catalog)
        holder.update(provider=provider, missions=missions)
        return missions

    def intake_factory(repo):
        return MainIntakeService(repo, provider=holder["provider"], missions=holder["missions"])

    def extension_factory(repo, missions, intake):
        extension = WorkspaceIntegration(repo, missions, intake, api_key=api_key,
                                    request_fn=gateway_request_fn, gateway_enabled=gateway_enabled)
        if enforce_d06:
            from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
            adapter = GovernedLegacyAdapter(repo, extension.gateway, holder["provider"])
            holder["provider"].governed_adapter = extension.legacy_adapter = adapter
        holder["core"] = extension
        return extension

    app = create_app(Path(db_path), port=port, enable_v04=True, service_factory=missions_factory,
                     intake_factory=intake_factory, tool_allowlist=TOOLS, web_dir=web_dir,
                     main_document="main.html", cookie_namespace=cookie_namespace,
                     mode=MODE, mcp_timeout=115, extension_factory=extension_factory,defer_mcp_mount=True,
                     metadata_provider=lambda: ({k: v for k, v in holder["provider"].summary().items() if k != "attempts"}
                         if audit_mode else {"paid_calls": None, "provider_attempts": None, "usage_scope": "authenticated_owner_only"}))
    app.title, app.version = "nMate · Trợ lý doanh nghiệp Hà Nội", APP_VERSION
    app.state.release_metadata = release_metadata()
    app.state.main_provider = holder["provider"]
    app.state.policy = holder["core"].policy
    app.state.gateway = holder["core"].gateway
    app.state.policy_workbench = holder["core"].policy05.workbench
    if cost_approval_binding is not None:
        from nmate.knowledge_v1.cost_approval import CostApprovalService
        from nmate.knowledge_v1.cost_approval_http import router as cost_router
        app.state.cost_approval=CostApprovalService(holder['core'].repo,cost_approval_binding)
        app.include_router(cost_router(app.state.cost_approval,app.state.accounts,cookie_namespace=cookie_namespace))
    if holder['core'].policy.knowledge is not None:
        from nmate.knowledge_v1.host import attach_workbench
        attach_workbench(app,holder['core'].policy.knowledge,holder['core'].gateway,cookie_namespace=cookie_namespace)

    @app.get("/api/main/status")
    async def status(request: Request):
        value = None
        try:
            value = app.state.accounts.get_session(request.cookies.get(cookie_namespace + "_session", ""))
        except CoreError:
            pass
        paid_gate = (holder["core"].gateway_status(value["account_id"], value["enterprise_id"])
                     if value else holder["core"].gateway.status())
        summary = holder["provider"].summary(account_id=value["account_id"], enterprise_id=value["enterprise_id"]) if value and value.get("role") == "owner" else {}
        summary.pop("attempts", None)
        from nmate.policy_v05.integration import integration_status
        return {**release_metadata(),
                "mode": MODE, "configured": bool(api_key or request_fn),
                "tasks": ["profile_intake", "export_research", "sales_inventory", "hanoi_policy"],
                "core_ready": True,
                "schema_readiness": getattr(app.state, "schema_readiness", None),
                "paid_gate": paid_gate,
                "legacy_paid_gate": (holder["core"].legacy_adapter.status(value["account_id"], value["enterprise_id"])
                    if enforce_d06 and value and holder["core"].legacy_adapter else
                    {"approved": not enforce_d06, "reason_vi": "Cần đăng nhập và có hạn mức được duyệt cho tác vụ này."}),
                "model_policy": {"simple": simple_model, "complex": complex_model},
                "paid_calls": 0, "provider_attempts": 0, "remaining_attempts": None, **summary,
                "retry_policy": "no_sdk_retry_no_fallback_no_automatic_resend",
                "source_policy": "fixed_authority_urls_exact_excerpt_check_recorded_snapshot_when_unavailable",
                "shared": ["identity", "enterprise_ssot", "conversation_history", "domain_knowledge"],
                "features": {"pdf_text_intake": True, "label_pdf": True, "history_management": True,
                             "account_settings": True, "policy05_workbench": True,
                             "registered_enterprise_profile": True},
                "integrations": {"ihanoi": integration_status()},
                "contracts": {"workspace": "workspace-contract/1", "intent_plan": "intent-plan/1",
                              "domain_graph": "public-domain-graph/1", "field_registry": "ssot-field-registry/1"},
                "audit_isolation": "separate_database" if audit_mode else "main_enterprise_database"}


    @app.get("/api/main/policy05/drafts/{draft_id}/pdf")
    async def policy_draft_pdf(request: Request, draft_id: str, e: str, revision: int = Query(ge=1)):
        from nmate.policy_v05.pdf import render_policy_draft
        try:
            value = app.state.accounts.get_session(request.cookies.get(cookie_namespace + "_session", ""))
            draft = holder["core"].policy05.workbench.get_draft(value["account_id"], e, draft_id)
            if draft["version"] != revision:
                raise CoreError("DRAFT_VERSION_CONFLICT", "Bản nháp đã đổi. Chị mở lại bản hiện hành trước khi tải PDF.", 409)
        except CoreError as exc:
            if 'text/html' not in request.headers.get('accept', '').lower():
                raise
            # Do not echo IDs, source details or private content on a denied URL.
            message = ('Bản nháp đã thay đổi. Chị mở lại tài liệu từ cuộc trao đổi để xem đúng phiên bản.'
                       if exc.code == 'DRAFT_VERSION_CONFLICT' else
                       'Chị đăng nhập đúng tài khoản và mở lại tài liệu từ cuộc trao đổi được cấp quyền.')
            return HTMLResponse('<!doctype html><html lang="vi"><head><meta charset="utf-8">'
                '<meta name="viewport" content="width=device-width, initial-scale=1">'
                '<link rel="stylesheet" href="/web/src/main-app.css">'
                '<title>Chưa mở được bản nháp — nMate</title></head><body><div class="shell">'
                '<main class="main"><section class="card"><h1>Chưa mở được bản nháp</h1>'
                '<p>' + message + '</p><p><a class="button" href="/web/">Về trợ lý nMate</a></p>'
                '</section></main></div></body></html>',
                status_code=exc.status_code, headers={'Cache-Control': 'no-store'})
        return Response(render_policy_draft(draft), media_type="application/pdf", headers={
            "Content-Disposition": f'inline; filename="policy-{draft["id"]}-v{revision}.pdf"',
            "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


    class PasswordChange(BaseModel):
        model_config = ConfigDict(extra="forbid")
        current_password: SecretStr = Field(min_length=1, max_length=1024)
        new_password: SecretStr = Field(min_length=10, max_length=1024)

    @app.post("/api/main/account/password")
    async def change_password(request: Request, body: PasswordChange):
        # Credentials are submitted only by the user's settings form, not MCP,
        # an agent tool or the model gateway. Keep the current opaque session.
        if request.headers.get("origin") not in {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}:
            raise CoreError("csrf_failed", "Trang gửi yêu cầu chưa được cho phép.", 403)
        token = request.cookies.get(cookie_namespace + "_session", "")
        value = app.state.accounts.validate_csrf(token, request.headers.get("x-csrf-token", ""))
        return app.state.accounts.change_password(value["account_id"], token,
            body.current_password.get_secret_value(), body.new_password.get_secret_value())

    if audit_mode:
        @app.get("/api/main/qa-status")
        async def qa_status():
            return {"mode": MODE, **app.state.telemetry,
                    **{k: v for k, v in holder["provider"].summary().items() if k != "attempts"},
                    **getattr(app.state, "network_guard", {})}
    app.state.finalize_mcp_mount()
    return app
