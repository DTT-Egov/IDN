"""Nonblocking OS ownership lock for one canonical enterprise database.

Acquire before constructing any repository or running recovery. The operating
system releases the lock when the process exits, including abrupt termination.
The stable lock file is deliberately never removed (avoids inode replacement).
"""
from __future__ import annotations

import os
from pathlib import Path


class RuntimeAlreadyRunning(RuntimeError):
    """The database already belongs to another local runtime."""


class EnterpriseRuntimeLock:
    def __init__(self, database_path):
        self.database_path = Path(os.path.normcase(str(Path(database_path).expanduser().resolve())))
        self.lock_path = self.database_path.with_name(self.database_path.name + ".runtime.lock")
        self._handle = None

    def acquire(self):
        if self._handle is not None:
            raise RuntimeError("This runtime lock has already been acquired")
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.lock_path.open("a+b", buffering=0)
        try:
            # Windows byte-range locking needs one stable byte. Append mode
            # never truncates a lock owned by a running process.
            if handle.seek(0, os.SEEK_END) == 0:
                handle.write(b"\0")
            handle.seek(0)
            try:
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                raise RuntimeAlreadyRunning(
                    "Một phiên nMate đang dùng dữ liệu này hoặc chưa lấy được khóa dữ liệu. "
                    "Phiên mới đã dừng trước khi mở hồ sơ; hãy dùng app đang chạy."
                ) from None
            self._handle = handle
            return self
        except BaseException:
            handle.close()
            raise

    def release(self):
        handle, self._handle = self._handle, None
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        finally:
            handle.close()

    def __enter__(self):
        return self.acquire()

    def __exit__(self, exc_type, exc_value, traceback):
        self.release()
