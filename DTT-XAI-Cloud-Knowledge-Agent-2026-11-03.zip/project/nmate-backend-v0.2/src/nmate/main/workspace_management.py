"""Owner-private history, account preferences and free document utilities.

Soft deletion never deletes evidence, SSOT, model receipts or paid attempts.
All commands use the same authenticated MCP boundary and idempotent ledger.
"""
from __future__ import annotations

import asyncio
import base64
import json
import hashlib
from typing import Annotated, Literal

from pydantic import Field

from nmate.core_v1.integration import CoreIntegration
from nmate.v03.core import CoreError, now_iso
from nmate.v03.mcp import Identifier, Operation, Result
from nmate.v04.extraction import MAX_TOTAL, normalize, validate_attachment
from nmate.v04.document_errors import annotate_document_rejection


WORKSPACE_TOOLS = {'search_history', 'archive_conversation', 'restore_conversation',
                   'get_account_settings', 'update_account_settings', 'list_products',
                   'archive_product', 'restore_product', 'get_entity_versions',
                   'download_label_pdf', 'prepare_document_draft'}
SCHEMA = """
CREATE TABLE IF NOT EXISTS main_conversation_visibility (
 enterprise_id TEXT NOT NULL, account_id TEXT NOT NULL,
 conversation_id TEXT NOT NULL REFERENCES v04_conversations(id),
 archived_at TEXT, revision INTEGER NOT NULL, updated_at TEXT NOT NULL,
 PRIMARY KEY(enterprise_id,account_id,conversation_id));
CREATE TABLE IF NOT EXISTS main_account_preferences (
 account_id TEXT PRIMARY KEY REFERENCES v03_accounts(id), display_name TEXT NOT NULL,
 preferred_address TEXT NOT NULL, revision INTEGER NOT NULL, updated_at TEXT NOT NULL);
"""
ADDRESS_TERMS = {'chị', 'anh', 'cô', 'chú', 'bác'}


def preferred_address(repo, account):
    with repo.connection() as db:
        table = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='main_account_preferences'").fetchone()
        row = db.execute('SELECT preferred_address FROM main_account_preferences WHERE account_id=?', (account,)).fetchone() if table else None
    return row[0] if row and row[0] in ADDRESS_TERMS else 'chị'


def assert_chat_writable(db, account, enterprise, conversation_id):
    if not conversation_id or not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='main_conversation_visibility'").fetchone():
        return
    row = db.execute('SELECT archived_at FROM main_conversation_visibility WHERE enterprise_id=? AND account_id=? AND conversation_id=?',
                     (enterprise, account, conversation_id)).fetchone()
    if row and row[0]:
        raise CoreError('CONVERSATION_ARCHIVED', 'Cuộc trao đổi đang ở Thùng rác. Chị khôi phục trước khi gửi hoặc sửa; chưa gọi AI.', 409)


class WorkspaceIntegration(CoreIntegration):
    tool_names = CoreIntegration.tool_names | WORKSPACE_TOOLS

    def __init__(self, repo, missions, intake, **kwargs):
        super().__init__(repo, missions, intake, **kwargs)
        self.missions = missions
        with self.repo.connection(write=True) as db:
            db.executescript(SCHEMA)
        self.policy.before_start = lambda db, a, e, payload: assert_chat_writable(db, a, e, payload.get('conversation_id'))
        self.policy.before_prepare_commit = self.policy.before_start

    def _settings(self, account, enterprise, db):
        self.core.membership(account, enterprise, db)
        row = db.execute('SELECT * FROM main_account_preferences WHERE account_id=?', (account,)).fetchone()
        username = db.execute('SELECT username FROM v03_accounts WHERE id=?', (account,)).fetchone()[0]
        return {'display_name': row['display_name'] if row else username,
                'preferred_address': row['preferred_address'] if row else 'chị',
                'revision': row['revision'] if row else 0, 'has_preference': bool(row),
                'updated_at': row['updated_at'] if row else None, 'can_change_password': True}

    def settings(self, account, enterprise):
        with self.repo.connection() as db:
            return self._settings(account, enterprise, db)

    def update_settings(self, account, enterprise, display_name, preferred_address, expected_revision, operation_id):
        if not isinstance(display_name, str) or not 1 <= len(display_name.strip()) <= 100 or any(ord(c) < 32 for c in display_name):
            raise CoreError('INVALID_DISPLAY_NAME', 'Tên hiển thị cần từ 1 đến 100 ký tự, không chứa ký tự điều khiển.')
        if preferred_address not in ADDRESS_TERMS:
            raise CoreError('INVALID_ADDRESS_TERM', 'Chị chọn cách xưng hô trong danh sách.')
        if type(expected_revision) is not int or expected_revision < 0:
            raise CoreError('INVALID_REVISION', 'Phiên bản cài đặt chưa hợp lệ. Chị tải lại phần Cài đặt.')
        with self.repo.connection(write=True) as db:
            current = self._settings(account, enterprise, db)
            digest, prior = self.repo._operation(db, account, enterprise, 'update_account_settings', operation_id,
                                                 [display_name.strip(), preferred_address, expected_revision])
            if prior is not None:
                return {**current, 'receipt': {'operation_id': operation_id, 'committed_revision': prior['revision'], 'replayed': True}}
            if current['revision'] != expected_revision:
                raise CoreError('version_conflict', 'Cài đặt đã đổi ở phiên khác. Chị tải lại để đối chiếu; chưa lưu thay đổi.', 409)
            stamp, revision = now_iso(), expected_revision + 1
            db.execute('INSERT INTO main_account_preferences VALUES(?,?,?,?,?) ON CONFLICT(account_id) DO UPDATE SET display_name=excluded.display_name,preferred_address=excluded.preferred_address,revision=excluded.revision,updated_at=excluded.updated_at',
                       (account, display_name.strip(), preferred_address, revision, stamp))
            value = self._settings(account, enterprise, db)
            self.repo._save_operation(db, account, enterprise, 'update_account_settings', operation_id, digest, value)
            return value

    def get_chat(self, account, enterprise, conversation_id):
        value = super().get_chat(account, enterprise, conversation_id)
        with self.repo.connection() as db:
            row = db.execute('SELECT archived_at FROM main_conversation_visibility WHERE enterprise_id=? AND account_id=? AND conversation_id=?',
                             (enterprise, account, conversation_id)).fetchone()
            settings = self._settings(account, enterprise, db)
        value.update(archived=bool(row and row[0]), archived_at=row[0] if row else None,
                     account_preferences=settings)
        return value

    def prepare(self, account, enterprise, question, operation, conversation_id=None, product_entity_id=None, target_date=None):
        authorized = False
        try:
            with self.repo.connection() as db:
                self.core.membership(account, enterprise, db)
                recorded = db.execute("SELECT 1 FROM pol_operations WHERE enterprise_id=? AND account_id=? AND kind='prepare' AND operation_id=?",
                                      (enterprise, account, operation)).fetchone()
                if not recorded:
                    if conversation_id:
                        self._chat(db, account, enterprise, conversation_id)
                    if product_entity_id:
                        try:
                            self.core._require(db, account, enterprise, product_entity_id)
                        except CoreError:
                            # Preserve CoreIntegration's non-disclosing public
                            # contract for an unknown or unreadable target.
                            raise CoreError('not_found', 'Không tìm thấy hồ sơ sản phẩm được phép sử dụng.', 404) from None
                    authorized = True
                    assert_chat_writable(db, account, enterprise, conversation_id)
        except CoreError as exc:
            if authorized:
                context = {'entities': [{'id': product_entity_id}], 'fact_refs': []} if product_entity_id else None
                self.policy.annotate_prepare_failure(account, enterprise, operation, exc, 'not_started', context)
            raise
        # Exact request replay is a READ. PolicyService still verifies its full
        # hash/owner; new commits recheck trash under the same write lock.
        return super().prepare(account, enterprise, question, operation, conversation_id=conversation_id,
                               product_entity_id=product_entity_id, target_date=target_date)

    def _visibility(self, account, enterprise, conversation_id, operation_id, archived):
        view = self.get_chat(account, enterprise, conversation_id)
        kind = 'archive_conversation' if archived else 'restore_conversation'
        with self.repo.connection(write=True) as db:
            # Recheck the raw in-flight marker in this same write transaction.
            chat = self._chat(db, account, enterprise, conversation_id)
            digest, prior = self.repo._operation(db, account, enterprise, kind, operation_id, [conversation_id])
            if prior is not None:
                row = db.execute('SELECT archived_at FROM main_conversation_visibility WHERE enterprise_id=? AND account_id=? AND conversation_id=?',
                                 (enterprise, account, conversation_id)).fetchone()
                return {'conversation_id': conversation_id, 'archived': bool(row and row[0]), 'archived_at': row[0] if row else None,
                        'receipt': prior}
            if (view.get('pending_operation_id') or view.get('status') in {'processing', 'queued', 'running', 'preparing'}
                    or chat.get('pending_operation_id')):
                raise CoreError('CONVERSATION_BUSY', 'Lượt trước đang xử lý; chưa thay đổi lịch sử.', 409)
            for table, field, ids in (('v03_missions','owner_id',chat.get('mission_ids',[])),
                                       ('pol_missions','owner_id',chat.get('policy_case_ids',[]))):
                if ids and db.execute(f"SELECT 1 FROM {table} WHERE enterprise_id=? AND {field}=? AND id IN ({','.join('?' for _ in ids)}) AND status IN ('queued','running') LIMIT 1",
                                      (enterprise,account,*ids)).fetchone():
                    raise CoreError('CONVERSATION_BUSY', 'Nghiên cứu đã được đưa vào hàng đợi hoặc đang chạy; chưa chuyển cuộc trao đổi vào Thùng rác.', 409)
            old = db.execute('SELECT archived_at,revision FROM main_conversation_visibility WHERE enterprise_id=? AND account_id=? AND conversation_id=?',
                             (enterprise, account, conversation_id)).fetchone()
            stamp = now_iso()
            archived_at = (old['archived_at'] if old and old['archived_at'] else stamp) if archived else None
            revision = old['revision'] + 1 if old else 1
            db.execute('INSERT INTO main_conversation_visibility VALUES(?,?,?,?,?,?) ON CONFLICT(enterprise_id,account_id,conversation_id) DO UPDATE SET archived_at=excluded.archived_at,revision=excluded.revision,updated_at=excluded.updated_at',
                       (enterprise, account, conversation_id, archived_at, revision, stamp))
            result = {'conversation_id': conversation_id, 'archived': archived, 'archived_at': archived_at, 'revision': revision,
                      'message_vi': 'Đã chuyển vào Thùng rác. Có thể khôi phục; hồ sơ và kết quả đã lưu vẫn được giữ.' if archived else 'Đã khôi phục cuộc trao đổi.'}
            self.repo._save_operation(db, account, enterprise, kind, operation_id, digest, result)
            return result

    def list_chats(self, account, enterprise):
        return self.search_history(account, enterprise)['items']

    def search_history(self, account, enterprise, query='', task='all', status='all', visibility='active', offset=0, limit=50):
        if not isinstance(query, str) or len(query) > 200:
            raise CoreError('INVALID_SEARCH', 'Từ khóa tìm kiếm tối đa 200 ký tự.')
        if task not in {'all', 'profile_intake', 'export_research', 'sales_inventory', 'hanoi_policy'} or status not in {'all', 'needs_attention', 'completed'} or visibility not in {'active', 'trash'}:
            raise CoreError('INVALID_FILTER', 'Bộ lọc lịch sử chưa hợp lệ.')
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 100:
            raise CoreError('INVALID_FILTER', 'Số trang lịch sử chưa hợp lệ.')
        with self.repo.connection() as db:
            self.core.membership(account, enterprise, db)
            rows = list(db.execute('SELECT c.id,c.payload_json,v.archived_at FROM v04_conversations c LEFT JOIN main_conversation_visibility v ON v.conversation_id=c.id AND v.enterprise_id=c.enterprise_id AND v.account_id=c.owner_id WHERE c.enterprise_id=? AND c.owner_id=? AND ' +
                                   ('v.archived_at IS NOT NULL' if visibility == 'trash' else 'v.archived_at IS NULL') + ' ORDER BY c.updated_at DESC,c.id DESC', (enterprise, account)))
        needle, result = normalize(query), []
        for row in rows:
            raw = json.loads(row['payload_json'])
            if needle and needle not in normalize(' '.join([raw.get('title', ''), *[str(m.get('text', '')) for m in raw.get('messages', [])]])):
                continue
            try:
                view = self.get_chat(account, enterprise, row['id'])
            except CoreError as exc:
                if exc.status_code in {403, 404}:
                    continue
                raise
            from .history import history_metadata
            meta = history_metadata(view)
            if task != 'all' and task not in meta['history_task_kinds']:
                continue
            if (status == 'needs_attention' and meta['history_filter_state'] not in {'needs_attention', 'pending'}
                    or status == 'completed' and meta['history_filter_state'] != 'completed'):
                continue
            item = {k: view.get(k) for k in ('id','title','created_at','updated_at','status','task_hint',
                    'active_intake_id','intake_ids','mission_ids','active_mission_id','latest_operation_id','operation_ids',
                    'policy_case_ids','active_policy_case_id','pending_operation_id','operation_error','archived','archived_at')}
            first_question = next((m.get('text', '') for m in raw.get('messages', []) if m.get('role') == 'user' and m.get('text')), raw.get('title',''))
            item.update(meta, raw_question=first_question)
            result.append(item)
        return {'items': result[offset:offset+limit], 'total': len(result), 'offset': offset, 'limit': limit,
                'has_more': offset+limit < len(result), 'query': query, 'visibility': visibility}

    def products(self, account, enterprise, include_archived=True):
        entities = self.repo.list_entities(account, enterprise, include_archived=include_archived)
        products = [self.repo.get_entity(account, enterprise, item['id']) for item in entities if item['entity_type']=='product']
        for product in products:
            product['values'] = {fact['field']:fact['value'] for fact in product.get('facts',[]) if fact.get('value_state')=='known'}
        return {'items': products, 'model_calls': 0}

    def label_pdf(self, account, enterprise, mission_id, artifact_id):
        from nmate.v03.label_pdf import render_label_pdf
        mission = self.missions.get(account, enterprise, mission_id)
        artifact = next((item for item in mission.get('artifacts', []) if item['id']==artifact_id and item.get('kind')=='food_label_workbook'), None)
        if not artifact:
            raise CoreError('not_found', 'Không tìm thấy bản nhãn được phép đọc.', 404)
        data = render_label_pdf(artifact)
        return {'filename': f"khung-nhan-{mission.get('market',{}).get('code','')}-v{artifact['version']}.pdf",
                'media_type': 'application/pdf', 'content_base64': base64.b64encode(data).decode(),
                'version': artifact['version'], 'warning_vi': 'Bản nháp chưa duyệt, chưa dùng làm nhãn thương mại.', 'model_calls': 0}

    def prepare_document(self, account, enterprise, text, attachments, operation_id, conversation_id=None, product_entity_id=None, task_hint='profile_intake'):
        # Parse/validate before reserving any conversation operation. Failed PDF
        # preflight is provably not started, not an uncertain paid result.
        try:
            # Authorization precedes even local decoding/parsing. A valid file
            # must not buy CPU work or reveal detailed parser state in a scope
            # the caller cannot use.
            with self.repo.connection() as db:
                self.core.membership(account, enterprise, db)
                if product_entity_id:
                    self.repo.require_active_entity(account, enterprise, product_entity_id, db)
                if conversation_id:
                    self._chat(db, account, enterprise, conversation_id)
                assert_chat_writable(db, account, enterprise, conversation_id)
            files = []
            for index, item in enumerate(attachments):
                try:
                    files.append(validate_attachment(item))
                except CoreError as exc:
                    annotate_document_rejection(exc, item, operation_id, index, len(attachments))
                    raise
            if not files or any(item['kind']=='image' for item in files):
                raise CoreError('LOCAL_DOCUMENT_TYPES', 'Chị chọn PDF văn bản hoặc Excel cho bước đọc miễn phí; ảnh dùng luồng đọc ảnh riêng.')
            if sum(item['size'] for item in files) > MAX_TOTAL:
                raise CoreError('attachment_limit', 'Tổng tệp mỗi lượt tối đa 6 MB.')
            from nmate.v04.pdf_intake import parse_pdf, PDF_PREFLIGHT
            from nmate.v04.extraction import parse_workbook
            parsed_pdfs = {}
            for index, item in enumerate(files):
                try:
                    if item['kind']=='pdf':
                        parsed_pdfs[hashlib.sha256(item['raw']).hexdigest()] = parse_pdf(item['raw'])
                    else:
                        parse_workbook(item['raw'])
                except CoreError as exc:
                    annotate_document_rejection(exc, item, operation_id, index, len(files), item['raw'])
                    raise
            with self.repo.connection() as db:
                self.core.membership(account, enterprise, db)
                if product_entity_id:
                    self.repo.require_active_entity(account, enterprise, product_entity_id, db)
                assert_chat_writable(db, account, enterprise, conversation_id)
                if db.execute('SELECT 1 FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?', (account, enterprise, operation_id)).fetchone():
                    raise CoreError('idempotency_conflict', 'Mã lượt đã dùng cho Claude; chưa bắt đầu đọc tài liệu.', 409)
        except CoreError as exc:
            self.conversations.free_conversations.annotate_free_failure(account, enterprise, operation_id, exc, 'not_started')
            raise
        token = PDF_PREFLIGHT.set(parsed_pdfs)
        try:
            result = self.conversations.free_conversations.send(account, enterprise, text, attachments, operation_id,
                        conversation_id, product_entity_id, None, None, task_hint=task_hint)
        finally:
            PDF_PREFLIGHT.reset(token)
        return self.get_chat(account, enterprise, result['id'])

    def register_tools(self, server, call):
        super().register_tools(server, call)

        @server.tool(structured_output=True, description='Search only the authenticated user history. Filters and reads are free; excludes trash by default.')
        async def search_history(enterprise_id: Identifier, query: Annotated[str, Field(max_length=200)]='',
                task: Literal['all','profile_intake','export_research','sales_inventory','hanoi_policy']='all',
                status: Literal['all','needs_attention','completed']='all', visibility: Literal['active','trash']='active',
                offset: Annotated[int, Field(ge=0, strict=True)]=0, limit: Annotated[int, Field(ge=1,le=100,strict=True)]=50) -> Result:
            return await call(lambda a: self.search_history(a, enterprise_id, query, task, status, visibility, offset, limit))

        @server.tool(structured_output=True, description='Move an owned conversation to recoverable trash. Preserves SSOT, documents, receipts and paid results; no model call.')
        async def archive_conversation(enterprise_id: Identifier, conversation_id: Identifier, operation_id: Operation) -> Result:
            return await call(lambda a: self._visibility(a, enterprise_id, conversation_id, operation_id, True))

        @server.tool(structured_output=True, description='Restore an owned conversation from trash. No model call.')
        async def restore_conversation(enterprise_id: Identifier, conversation_id: Identifier, operation_id: Operation) -> Result:
            return await call(lambda a: self._visibility(a, enterprise_id, conversation_id, operation_id, False))

        @server.tool(structured_output=True, description='Read own account display preferences; never exposes credentials.')
        async def get_account_settings(enterprise_id: Identifier) -> Result:
            return await call(lambda a: self.settings(a, enterprise_id))

        @server.tool(structured_output=True, description='Save own display name and preferred form of address. Does not change enterprise SSOT or credentials.')
        async def update_account_settings(enterprise_id: Identifier, display_name: Annotated[str,Field(min_length=1,max_length=100)],
                preferred_address: Literal['chị','anh','cô','chú','bác'], expected_revision: Annotated[int,Field(ge=0,strict=True)], operation_id: Operation) -> Result:
            return await call(lambda a: self.update_settings(a, enterprise_id, display_name, preferred_address, expected_revision, operation_id))

        @server.tool(structured_output=True, description='List readable products, including empty and optionally archived profiles. No model call.')
        async def list_products(enterprise_id: Identifier, include_archived: bool=True) -> Result:
            return await call(lambda a: self.products(a, enterprise_id, include_archived))

        @server.tool(structured_output=True, description='Archive a product reversibly, preserving all SSOT and history. Archived products cannot be used for new AI work.')
        async def archive_product(enterprise_id: Identifier, entity_id: Identifier, expected_version: Annotated[int,Field(ge=0,strict=True)],
                operation_id: Operation, reason: Annotated[str,Field(max_length=500)]|None=None) -> Result:
            return await call(lambda a: self.repo.archive_entity(a, enterprise_id, entity_id, expected_version, operation_id, reason))

        @server.tool(structured_output=True, description='Restore a product if its normalized name does not collide with another active product.')
        async def restore_product(enterprise_id: Identifier, entity_id: Identifier, expected_version: Annotated[int,Field(ge=0,strict=True)],
                operation_id: Operation, reason: Annotated[str,Field(max_length=500)]|None=None) -> Result:
            return await call(lambda a: self.repo.restore_entity(a, enterprise_id, entity_id, expected_version, operation_id, reason))

        @server.tool(structured_output=True, description='Read authorized immutable fact and lifecycle history of one profile. Never replays an AI call.')
        async def get_entity_versions(enterprise_id: Identifier, entity_id: Identifier) -> Result:
            return await call(lambda a: self.repo.entity_versions(a, enterprise_id, entity_id))

        @server.tool(structured_output=True, description='Generate a printable PDF of an authorized saved label revision. Invalid quantities are blocked. Free; no model call.')
        async def download_label_pdf(enterprise_id: Identifier, mission_id: Identifier, artifact_id: Identifier) -> Result:
            return await call(lambda a: self.label_pdf(a, enterprise_id, mission_id, artifact_id))

        @server.tool(structured_output=True, description='Read PDF text or Excel locally into an owner-private draft. Never sends the original or PDF text to Claude. No OCR and no model call; owner confirms facts separately.')
        async def prepare_document_draft(enterprise_id: Identifier, text: Annotated[str,Field(max_length=4000)],
                attachments: Annotated[list[dict[str,str]],Field(min_length=1,max_length=3)], operation_id: Operation,
                conversation_id: Identifier|None=None, product_entity_id: Identifier|None=None,
                task_hint: Literal['profile_intake','export_research','sales_inventory']='profile_intake') -> Result:
            return await call(lambda a: asyncio.to_thread(self.prepare_document, a, enterprise_id, text, attachments, operation_id,
                                                          conversation_id, product_entity_id, task_hint))
