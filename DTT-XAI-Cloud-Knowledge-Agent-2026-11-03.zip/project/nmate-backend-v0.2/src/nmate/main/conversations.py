"""One owner-private conversation for document, operations and market research.

Reserve the conversation and operation before dispatch. Mission linkage can be
recovered from the durable prepare operation without replaying any model call.
"""
import asyncio
import hashlib
import json
from contextvars import ContextVar

from nmate.v03.core import CoreError, json_text, new_id, now_iso
from nmate.v03.missions import resolve_market
from nmate.v03.evidence import outcome_topic
from nmate.v03.research_scope import allowed_intake_outcomes
from nmate.v04.extraction import validate_attachment
from nmate.v04.live_review import LiveConversationService, LiveIntakeService
from nmate.v04.intake import IntakeService
from nmate.v04.conversations import ConversationService
from nmate.v04.product_binding import product_scope
from nmate.v04.dialogue import interpret, SELECTED_TASK_HINT, address_text
from .recorded_analysis import project_recorded_export_intake
from .draft_projection import project_excluded_legacy_draft, preserve_archived_exclusions

SCHEMA = """
CREATE TABLE IF NOT EXISTS main_operations (
 account_id TEXT NOT NULL, enterprise_id TEXT NOT NULL, operation_id TEXT NOT NULL,
 request_hash TEXT NOT NULL, conversation_id TEXT NOT NULL REFERENCES v04_conversations(id),
 task_hint TEXT NOT NULL, state TEXT NOT NULL, error_code TEXT, created_at TEXT NOT NULL,
 PRIMARY KEY(account_id,enterprise_id,operation_id));
CREATE TABLE IF NOT EXISTS main_application_recoveries (
 account_id TEXT NOT NULL, enterprise_id TEXT NOT NULL, operation_id TEXT NOT NULL,
 provider_attempt_id TEXT NOT NULL, original_error_code TEXT NOT NULL,
 original_request_hash TEXT NOT NULL, original_response_sha256 TEXT NOT NULL,
 recovered_at TEXT, PRIMARY KEY(account_id,enterprise_id,operation_id));
"""
TASKS = {"profile_intake", "export_research", "sales_inventory"}
FREE_OPERATION = ContextVar("main_free_preparation_operation", default=None)


class FreeDraftConversationService(ConversationService):
    def _draft(self, account, enterprise, payload, intake_id, draft, db):
        from .workspace_management import assert_chat_writable
        assert_chat_writable(db, account, enterprise, payload.get("id"))
        if intake_id not in payload.get("intake_ids", []):
            return super()._draft(account, enterprise, payload, intake_id, draft, db)
        item = self.intake._owned(account, enterprise, intake_id, db)
        draft = preserve_archived_exclusions({**payload, "intake": item}, draft)
        return super()._draft(account, enterprise, payload, intake_id, draft, db)

    def send(self, account, enterprise, text, attachments, operation_id, *args, task_hint=None):
        from .workspace_management import preferred_address
        from nmate.v04.dialogue import PREFERRED_ADDRESS
        token = FREE_OPERATION.set(operation_id)
        hint_token = SELECTED_TASK_HINT.set(task_hint)
        address_token = PREFERRED_ADDRESS.set(preferred_address(self.repo, account))
        try:
            return super().send(account, enterprise, text, attachments, operation_id, *args)
        except CoreError as exc:
            # ConversationService.send has left its SQL context by rollback.
            # Check exact persisted identity before claiming that this free
            # command did not commit: a replay read can fail after an older
            # successful receipt, and must retain its committed/unknown state.
            self.annotate_free_failure(account, enterprise, operation_id, exc, 'not_committed')
            raise
        finally:
            SELECTED_TASK_HINT.reset(hint_token)
            FREE_OPERATION.reset(token)
            PREFERRED_ADDRESS.reset(address_token)

    def annotate_free_failure(self, account, enterprise, operation_id, exc, state):
        """Attach only proven no-commit evidence; never classify paid/IO errors."""
        try:
            with self.repo.connection() as db:
                self.repo.get_membership(account, enterprise, db)
                saved = db.execute("SELECT 1 FROM v03_operations WHERE account_id=? AND enterprise_id=? "
                    "AND kind='v04_conversation_send' AND operation_id=?", (account, enterprise, operation_id)).fetchone()
                paid = db.execute("SELECT 1 FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                                  (account, enterprise, operation_id)).fetchone()
                if not saved and not paid:
                    exc.commit_state = state
        except Exception:
            # Failure of this read-only evidence check is uncertainty, not a
            # reason to mask the original error or unlock another operation.
            return

    def validate_dispatch_snapshot(self, account, enterprise, db):
        if db.execute("SELECT 1 FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                      (account, enterprise, FREE_OPERATION.get())).fetchone():
            raise CoreError("idempotency_conflict", "Mã lượt đã dùng cho tác vụ Claude; không dùng lại cho phần chuẩn bị miễn phí.", 409)

    def _owned(self, account, enterprise, conversation_id, db):
        payload = super()._owned(account, enterprise, conversation_id, db)
        from .workspace_management import assert_chat_writable
        assert_chat_writable(db, account, enterprise, conversation_id)
        if payload.get("pending_operation_id"):
            raise CoreError("CONVERSATION_BUSY", "Lượt trước đang xử lý. Hãy kiểm tra kết quả trước khi chuẩn bị nháp.", 409)
        return payload

    def decorate_conversation(self, payload):
        payload.update(task_hint=SELECTED_TASK_HINT.get() or "profile_intake", last_preparation={"origin": "bounded_local_parser",
                       "model_called": False, "operation_id": payload["latest_operation_id"]})
        payload.pop("operation_error", None)


class MainIntakeService(LiveIntakeService):
    unified_main = True

    def __init__(self, repo, *, provider, missions):
        super().__init__(repo, provider=provider)
        self.missions = missions
        self.conversations_factory = MainConversationService


class MainConversationService(LiveConversationService):
    def _draft(self, account, enterprise, payload, intake_id, draft, db):
        from .workspace_management import assert_chat_writable
        assert_chat_writable(db, account, enterprise, payload.get("id"))
        if intake_id not in payload.get("intake_ids", []):
            return super()._draft(account, enterprise, payload, intake_id, draft, db)
        item = self.intake._owned(account, enterprise, intake_id, db)
        draft = preserve_archived_exclusions({**payload, "intake": item}, draft)
        return super()._draft(account, enterprise, payload, intake_id, draft, db)

    def __init__(self, intake):
        super().__init__(intake)
        self.missions = intake.missions
        self._main_locks, self._active = {}, set()
        # Explicitly named free preparation uses the same owner-private stores,
        # but has no provider or gateway capability and cannot dispatch Claude.
        self.free_intake = IntakeService(self.repo)
        self.free_conversations = FreeDraftConversationService(self.free_intake)
        with self.repo.connection(write=True) as db:
            db.executescript(SCHEMA)
        self.recover()

    def _owned(self, account, enterprise, conversation_id, db):
        payload = super()._owned(account, enterprise, conversation_id, db)
        # Older payloads keep identity only in SQL columns. Authorization above
        # is authoritative; hydrate it before upgrading an existing chat.
        payload.update(owner_id=account, enterprise_id=enterprise)
        return payload

    def recover(self):
        with self.repo.connection() as db:
            owners = list(db.execute("SELECT DISTINCT account_id,enterprise_id FROM main_operations WHERE state IN ('preparing','failed')"))
        for row in owners:
            self._reconcile(*row, interrupted=True)

    def _link_mission(self, db, payload, op, mission):
        mission_id = mission["id"]
        if mission_id not in payload.setdefault("mission_ids", []):
            payload["mission_ids"].append(mission_id)
            stamp = now_iso()
            submitted = next((message for message in payload["messages"]
                              if message.get("role") == "user" and message.get("operation_id") == op), None)
            if submitted:
                submitted["mission_id"] = mission_id
            else:
                payload["messages"].append({"id": new_id("message"), "role": "user", "text": mission["question"],
                    "mission_id": mission_id, "operation_id": op, "created_at": stamp, "attachments": [], "kind": "message"})
            greeting = address_text("Mình đã lập kế hoạch theo câu hỏi và hồ sơ đang dùng. Bạn xem các ý bên dưới; bắt đầu nghiên cứu là một lượt AI mới có tính phí.", interpret(mission["question"]))
            payload["messages"].append(
                {"id": new_id("message"), "role": "assistant", "text": greeting,
                 "mission_id": mission_id, "created_at": now_iso(), "attachments": [], "kind": "mission_plan"})
        payload.update(active_mission_id=mission_id, task_hint="export_research")
        self._complete(db, payload, op)

    def decorate_conversation(self, payload):
        super().decorate_conversation(payload)
        # The user's submission was durably saved before dispatch. The shared
        # intake service appends its normal message after validation; merge its
        # attachment/intake linkage into the original bubble exactly once.
        op = payload.get("latest_operation_id")
        submitted = next((message for message in payload["messages"] if message.get("role") == "user"
                          and message.get("operation_id") == op), None)
        appended = payload["messages"][-2] if len(payload["messages"]) >= 2 else None
        if submitted and appended is not submitted and appended and appended.get("role") == "user":
            submitted.update({key: appended[key] for key in ("intake_id", "attachments") if key in appended})
            payload["messages"].remove(appended)

    def _complete(self, db, payload, op):
        payload["latest_operation_id"] = op
        if op not in payload["operation_ids"]:
            payload["operation_ids"].append(op)
        payload.pop("pending_operation_id", None)
        payload.pop("operation_error", None)
        db.execute("UPDATE main_operations SET state='completed',error_code=NULL WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                   (payload["owner_id"], payload["enterprise_id"], op))
        self._store(db, payload)

    def _reconcile(self, account, enterprise, *, interrupted=False):
        with self.repo.connection() as db:
            self.repo.get_membership(account, enterprise, db)
            rows = list(db.execute("SELECT * FROM main_operations WHERE account_id=? AND enterprise_id=? AND state IN ('preparing','failed')", (account, enterprise)))
        for row in rows:
            key = (account, enterprise, row["operation_id"])
            if key in self._active and not interrupted:
                continue
            with self.repo.connection() as db:
                prepared = db.execute("SELECT mission_id FROM v03_mission_operations WHERE account_id=? AND enterprise_id=? AND kind='prepare' AND operation_id=?",
                                      key).fetchone() if row["task_hint"] == "export_research" else None
                sent = db.execute("SELECT response_json FROM v03_operations WHERE account_id=? AND enterprise_id=? AND kind='v04_conversation_send' AND operation_id=?", key).fetchone()
            mission = self.missions.get(account, enterprise, prepared[0]) if prepared else None
            with self.repo.connection(write=True) as db:
                payload = self._owned(account, enterprise, row["conversation_id"], db)
                if mission:
                    self._link_mission(db, payload, row["operation_id"], mission)
                elif sent:
                    self._complete(db, payload, row["operation_id"])
                elif interrupted and row["state"] == "preparing":
                    db.execute("UPDATE main_operations SET state='failed',error_code='PROCESS_INTERRUPTED' WHERE account_id=? AND enterprise_id=? AND operation_id=?", key)
                    payload.pop("pending_operation_id", None)
                    payload["operation_error"] = {"operation_id": row["operation_id"], "code": "PROCESS_INTERRUPTED", "message": "Lượt trước bị gián đoạn, kết quả chưa xác định. Hệ thống không tự gửi lại lượt có phí."}
                    self._store(db, payload)

    def _view(self, account, enterprise, payload, db):
        result = super()._view(account, enterprise, payload, db)
        item = result.get("intake")
        if item and not item.get("product_binding") and item.get("product"):
            unresolved = False
            try:
                chosen, binding = product_scope(self.intake, account, enterprise, item.get("text", ""), db)
                old_product = item.get("product") or {}
                old_id = old_product.get("entity_id") or old_product.get("id")
                unresolved = (binding["state"] in {"new_product_draft", "unbound_reference"}
                              or bool(chosen and chosen != old_id))
            except CoreError as exc:
                # A historical read is not a new binding command. Semantic
                # ambiguity blocks reuse while retaining the original history;
                # current READ/ACL errors must still deny access normally.
                if exc.code not in {"ambiguous_product", "multiple_products_not_supported"}:
                    raise
                unresolved = True
            if unresolved:
                item["binding_warning"] = {"code": "PRODUCT_BINDING_UNCONFIRMED", "blocking": True,
                    "message_vi": "Hồ sơ gắn với kế hoạch cũ chưa đủ căn cứ cho câu hỏi này. Chỉ xem như lịch sử; cần trích và xác nhận đúng sản phẩm trước khi dùng tiếp."}
                item["status"] = result["status"] = "needs_product_confirmation"
        result["missions"] = [self.missions.get(account, enterprise, mid) for mid in payload.get("mission_ids", [])]
        result["mission_ids"] = payload.get("mission_ids", [])
        active = next((m for m in result["missions"] if m["id"] == payload.get("active_mission_id")), None)
        if payload.get("task_hint") == "export_research" and active:
            result["status"] = active["status"]
        if payload.get("pending_operation_id"):
            result["status"] = "preparing"
        if payload.get("operation_error"):
            result["status"] = "failed"
        ids = {m.get("provider_attempt_id") for m in result["messages"]}
        ids.update(c.get("attempt_id") for m in result["missions"] for c in m.get("cost", {}).get("calls", []))
        # Include failed/ambiguous sends and the crash boundary before mission
        # metadata linkage. Billing truth comes from the provider ledger.
        ids.update(row[0] for row in db.execute(
            "SELECT a.id FROM v03_live_attempts a JOIN main_operations o ON a.account_id=o.account_id AND a.enterprise_id=o.enterprise_id AND a.operation_id=o.operation_id "
            "WHERE o.account_id=? AND o.enterprise_id=? AND o.conversation_id=? AND a.state!='prepared'",
            (account, enterprise, payload["id"])))
        summary = self.provider.summary(account_id=account, enterprise_id=enterprise)
        attempts = [a for a in summary["attempts"] if a["id"] in ids]
        result.update(mode="live_claude_main", model_calls=len(attempts), cost={**summary, "attempts": attempts,
                      "paid_calls": len(attempts), "provider_attempts": len(attempts),
                      "completed_provider_calls": sum(a["state"] == "succeeded" for a in attempts),
                      "estimated_usd": round(sum(a.get("estimated_usd", 0) for a in attempts), 6)})
        if result.get("operation_error"):
            op = result["operation_error"]["operation_id"]
            operation_attempt_ids = {row[0] for row in db.execute(
                "SELECT id FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND operation_id=? AND state!='prepared'",
                (account, enterprise, op))}
            paid_attempts = [item for item in attempts if item["id"] in operation_attempt_ids]
            result["operation_error"] = {**result["operation_error"],
                "provider_dispatched": bool(paid_attempts), "provider_attempt_count": len(paid_attempts),
                "estimated_usd": round(sum(item.get("estimated_usd", 0) for item in paid_attempts), 6)}
            if paid_attempts and "chưa gửi claude" in result["operation_error"]["message"].casefold():
                result["operation_error"]["message"] = ("Lượt này đã gửi Claude và có thể đã tính phí. "
                    "Kết quả chưa gắn vào hồ sơ do kiểm tra sản phẩm; chi phí được giữ trong lịch sử. Không tự gửi lại.")
        adapter = getattr(self.provider, "governed_adapter", None)
        recorded = project_recorded_export_intake(self.repo, account, enterprise, payload["id"], db,
            authorize_envelope=getattr(adapter, "authorize_recorded_envelope", None))
        if recorded is not None:
            result["recorded_intake_analysis"] = recorded
        result = project_excluded_legacy_draft(result)
        if result.get("intake"):
            from .workspace_view import intake_workspace_view
            from nmate.core_v1.workspace_contract import project_intake_plan, resource_workspace_contract, current_product_reference
            result["workspace_view"] = intake_workspace_view(self.repo, account, enterprise, result["intake"], db, result)
            from nmate.v04.dialogue import business_values
            current = result["workspace_view"]["current_context"]
            result["intake"] = project_intake_plan(result["intake"], values=business_values(current, result["intake"].get("product")),
                                                   context_revision=current.get("context_revision"),
                                                   current_product=current_product_reference(current, result["intake"].get("product")))
            result["intake"]["workspace_contract"] = resource_workspace_contract(self.repo, account, enterprise, result["intake"], db, kind="intake", conversation=result)
            result["workspace_contract"] = result["intake"]["workspace_contract"]
        return result

    def get(self, account, enterprise, conversation_id):
        return super().get(account, enterprise, conversation_id)

    def list(self, account, enterprise):
        with self.repo.connection() as db:
            self.repo.get_membership(account, enterprise, db)
            rows = list(db.execute("SELECT payload_json FROM v04_conversations WHERE enterprise_id=? AND owner_id=? ORDER BY updated_at DESC,id DESC LIMIT 50", (enterprise, account)))
            result = []
            for row in rows:
                payload = json.loads(row[0])
                payload.update(owner_id=account, enterprise_id=enterprise)
                view = self._view(account, enterprise, payload, db)
                result.append({k: view.get(k) for k in ("id", "title", "created_at", "updated_at", "active_intake_id", "intake_ids", "latest_operation_id", "operation_ids", "status", "task_hint", "mission_ids", "active_mission_id", "pending_operation_id", "operation_error")})
            return result

    def prepare_chat_draft(self, account, enterprise, text, operation_id, conversation_id=None,
                           product_entity_id=None, draft=None, target_intake_id=None, *, task_hint=None):
        """Explicit free draft preparation; never a substitute for paid send."""
        try:
            if task_hint not in TASKS | {None}:
                raise CoreError("invalid_task", "Tác vụ chưa được hỗ trợ.")
            with self.repo.connection() as db:
                self.repo.get_membership(account, enterprise, db)
                from .workspace_management import assert_chat_writable
                assert_chat_writable(db, account, enterprise, conversation_id)
                if product_entity_id:
                    self.repo.require_active_entity(account, enterprise, product_entity_id, db)
                if db.execute("SELECT 1 FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                              (account, enterprise, operation_id)).fetchone():
                    raise CoreError("idempotency_conflict", "Mã lượt đã dùng cho tác vụ Claude; không dùng lại cho phần chuẩn bị miễn phí.", 409)
                if conversation_id:
                    payload = self._owned(account, enterprise, conversation_id, db)
                    if payload.get("pending_operation_id"):
                        raise CoreError("CONVERSATION_BUSY", "Lượt trước đang xử lý. Hãy kiểm tra kết quả trước khi chuẩn bị nháp.", 409)
        except CoreError as exc:
            self.free_conversations.annotate_free_failure(account, enterprise, operation_id, exc, 'not_started')
            raise
        result = self.free_conversations.send(account, enterprise, text, [], operation_id, conversation_id,
                                              product_entity_id, draft, target_intake_id, task_hint=task_hint)
        return self.get(account, enterprise, result["id"])

    async def recover_recorded_send_async(self, account, enterprise, operation_id, request):
        """Internal, explicit free recovery of a corrected application guard.

        Not an MCP retry tool. The provider is forced into exact-cache-only
        mode; request/context drift fails closed without any SDK capability.
        """
        digest = hashlib.sha256(json_text(request).encode()).hexdigest()
        with self.repo.connection() as db:
            self.repo.get_membership(account, enterprise, db)
            row = db.execute("SELECT * FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                             (account, enterprise, operation_id)).fetchone()
            attempt = db.execute("SELECT * FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND operation_id=? AND kind='intake'",
                                 (account, enterprise, operation_id)).fetchone()
        if (not row or row["task_hint"] == "export_research" or row["request_hash"] != digest
                or request.get("attachments") or request.get("conversation_id") not in {None, row["conversation_id"]}):
            raise CoreError("RECORDED_RECOVERY_REFUSED", "Lượt đã lưu không đủ điều kiện đọc lại miễn phí.", 409)
        lock = self._main_locks.setdefault((account, enterprise, row["conversation_id"]), asyncio.Lock())
        async with lock:
            with self.repo.connection() as db:
                latest = db.execute("SELECT operation_id FROM main_operations WHERE account_id=? AND enterprise_id=? AND conversation_id=? ORDER BY created_at DESC,rowid DESC LIMIT 1",
                                    (account, enterprise, row["conversation_id"])).fetchone()
                saved = self._owned(account, enterprise, row["conversation_id"], db)
            if not latest or latest["operation_id"] != operation_id:
                raise CoreError("RECORDED_RECOVERY_REFUSED", "Cuộc trao đổi đã có lượt mới hơn. Chưa đọc lại vào phần việc hiện tại.", 409)
            if row["state"] == "completed":
                return self.get(account, enterprise, row["conversation_id"])
            code_punctuation_guard = (row["error_code"] == "LIVE_ANSWER_UNGROUNDED"
                and saved.get("operation_error", {}).get("operation_id") == operation_id
                and saved.get("operation_error", {}).get("message") == "Mã sản phẩm phải khớp nguyên văn đầy đủ trong lời người dùng.")
            if (row["state"] != "failed" or not (row["error_code"] in {"LIVE_SAVE_CLAIM_INVALID", "LIVE_ANSWER_INVALID"} or code_punctuation_guard)
                    or not attempt or attempt["state"] != "succeeded" or not attempt["response_json"]):
                raise CoreError("RECORDED_RECOVERY_REFUSED", "Không đọc lại lượt chưa rõ kết quả hoặc đã lỗi kiểm chứng khác.", 409)
            with self.repo.connection(write=True) as db:
                db.execute("INSERT OR IGNORE INTO main_application_recoveries VALUES(?,?,?,?,?,?,?,NULL)",
                    (account, enterprise, operation_id, attempt["id"], row["error_code"], digest,
                     hashlib.sha256(attempt["response_json"].encode()).hexdigest()))
            cache_token = self.provider.recorded_only.set(True)
            hint_token = self.provider.task_hint.set(row["task_hint"])
            try:
                await super().send_async(account, enterprise, request["text"], [], operation_id,
                    row["conversation_id"], request.get("product_entity_id"), request.get("draft"),
                    request.get("target_intake_id"), paid_consent=True)
            finally:
                self.provider.task_hint.reset(hint_token)
                self.provider.recorded_only.reset(cache_token)
            with self.repo.connection(write=True) as db:
                current = self._owned(account, enterprise, row["conversation_id"], db)
                db.execute("UPDATE main_application_recoveries SET recovered_at=? WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                           (now_iso(), account, enterprise, operation_id))
                current.setdefault("application_recoveries", []).append({"operation_id": operation_id,
                    "provider_attempt_id": attempt["id"], "provider_calls": 0,
                    "note_vi": "Đã kiểm tra lại nguyên kết quả của lượt đã lưu; không gọi thêm Claude và không tự ghi SSOT.",
                    **({"capability_correction_vi": "Mã sản phẩm có thể được trích thành nháp để chủ doanh nghiệp xác nhận. Phần Claude cũ nói mã không thể lưu vào hồ sơ là hạn chế cũ; câu trả lời gốc được giữ nguyên."}
                       if row["error_code"] == "LIVE_ANSWER_INVALID" else {})})
                self._complete(db, current, operation_id)
            return self.get(account, enterprise, row["conversation_id"])

    async def send_async(self, account, enterprise, text, attachments, operation_id, conversation_id=None,
                         product_entity_id=None, draft=None, target_intake_id=None, *, paid_consent=False,
                         task_hint=None, market_code=None):
        from .workspace_management import preferred_address
        from nmate.v04.dialogue import PREFERRED_ADDRESS
        address_token = PREFERRED_ADDRESS.set(preferred_address(self.repo, account))
        try:
            return await self._send_async(account, enterprise, text, attachments, operation_id, conversation_id,
                product_entity_id, draft, target_intake_id, paid_consent=paid_consent, task_hint=task_hint, market_code=market_code)
        finally:
            PREFERRED_ADDRESS.reset(address_token)

    async def _send_async(self, account, enterprise, text, attachments, operation_id, conversation_id=None,
                         product_entity_id=None, draft=None, target_intake_id=None, *, paid_consent=False,
                         task_hint=None, market_code=None):
        if task_hint not in TASKS | {None}:
            raise CoreError("invalid_task", "Tác vụ chưa được hỗ trợ.")
        if not isinstance(text, str) or len(text) > 4000 or not isinstance(attachments, list) or len(attachments) > 3 or not text.strip() and not attachments:
            raise CoreError("invalid_message", "Gửi câu hỏi hoặc tối đa 3 tệp, câu hỏi tối đa 4.000 ký tự.")
        if any(validate_attachment(item)["kind"] == "pdf" for item in attachments):
            raise CoreError("PDF_LOCAL_ONLY", "PDF được đọc miễn phí tại máy chủ. Chị chọn Đọc tài liệu; chưa gửi Claude.", 409)
        task = task_hint or "profile_intake"
        if task == "export_research" and attachments:
            raise CoreError("confirm_documents_first", "Bạn chọn Đọc ảnh/Excel để đối chiếu tài liệu trước, rồi dùng hồ sơ đã xác nhận để nghiên cứu xuất khẩu.", 409)
        request = dict(text=text, attachments=attachments, conversation_id=conversation_id, product_entity_id=product_entity_id,
                       draft=draft, target_intake_id=target_intake_id, task_hint=task, market_code=market_code)
        digest = hashlib.sha256(json_text(request).encode()).hexdigest()
        key = (account, enterprise, operation_id)
        lock = self._main_locks.setdefault((account, enterprise, conversation_id or operation_id), asyncio.Lock())
        async with lock:
            self._reconcile(account, enterprise)
            with self.repo.connection(write=True) as db:
                self.repo.get_membership(account, enterprise, db)
                from .workspace_management import assert_chat_writable
                assert_chat_writable(db, account, enterprise, conversation_id)
                if product_entity_id:
                    self.repo.require_active_entity(account, enterprise, product_entity_id, db)
                old = db.execute("SELECT * FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?", key).fetchone()
                if old:
                    if old["request_hash"] != digest:
                        raise CoreError("idempotency_conflict", "Mã lượt gửi đã dùng cho nội dung khác.", 409)
                    if old["state"] == "completed":
                        return self._view(account, enterprise, self._owned(account, enterprise, old["conversation_id"], db), db)
                    raise CoreError("LIVE_ATTEMPT_NOT_REPLAYED", "Lượt này đang xử lý hoặc đã dừng. Mở lịch sử để kiểm tra; không tự gửi lại lượt có phí.", 409)
                if db.execute("SELECT 1 FROM v03_operations WHERE account_id=? AND enterprise_id=? AND kind='v04_conversation_send' AND operation_id=?", key).fetchone():
                    raise CoreError("idempotency_conflict", "Mã lượt đã dùng cho phần chuẩn bị miễn phí; không dùng lại để gửi Claude.", 409)
                payload = self._owned(account, enterprise, conversation_id, db) if conversation_id else None
                previous_intent = (self.intake._owned(account, enterprise, payload["active_intake_id"], db).get("intent")
                                   if payload and payload.get("active_intake_id") else None)
                unsupported = interpret(text, previous=previous_intent, task_hint=task)
                if unsupported.get("unsupported_request"):
                    raise CoreError("UNSUPPORTED_TASK", unsupported["unsupported_reason_vi"], 409)
                if payload and payload.get("pending_operation_id"):
                    raise CoreError("CONVERSATION_BUSY", address_text("Lượt trước đang xử lý. Bạn kiểm tra kết quả trước khi gửi một lượt AI mới có phí.", unsupported), 409)
                if payload and attachments and not text.strip():
                    known_hashes = {a.get("sha256") for m in payload["messages"] for a in m.get("attachments", [])}
                    supplied_hashes = {validate_attachment(a)["sha256"] for a in attachments}
                    if supplied_hashes and supplied_hashes <= known_hashes:
                        raise CoreError("FILES_ALREADY_SENT", "Những tệp này đã có trong cuộc chat. Bạn nêu câu hỏi tiếp; không cần gửi lại tệp và tạo thêm lượt đọc ảnh có phí.", 409)
                if paid_consent is not True:
                    raise CoreError("PAID_CONSENT_REQUIRED", "Cần đồng ý rõ trước khi gửi một lượt Claude có tính phí.", 409)
                if task == "export_research":
                    if market_code not in {"US", "DE", "JP"}:
                        raise CoreError("choose_market", address_text("Bạn chọn Mỹ, Đức hoặc Nhật trước khi gửi nghiên cứu.", unsupported), 409)
                    resolved, _, ambiguities = resolve_market(text, market_code, None)
                    if resolved != market_code or ambiguities:
                        raise CoreError("choose_market", address_text("Thị trường trong câu hỏi khác hoặc chưa khớp lựa chọn. Bạn xác nhận một thị trường trước khi gửi lượt AI có phí.", unsupported), 409)
                    product_entity_id, binding = product_scope(self.intake, account, enterprise, text, db, product_entity_id)
                    if binding["state"] == "new_product_draft":
                        raise CoreError("product_confirmation_required", "Sản phẩm vừa nêu chưa được xác nhận. Chọn Trích dữ kiện từ câu chat để chuẩn bị nháp miễn phí, rồi xác nhận trước khi nghiên cứu.", 409)
                    if not product_entity_id:
                        raise CoreError("choose_product", address_text("Bạn chọn hồ sơ sản phẩm đã xác nhận để nghiên cứu.", unsupported), 409)
                    product = self.repo._entity(account, enterprise, product_entity_id, db)
                    if product["entity_type"] != "product":
                        raise CoreError("invalid_product", "Thông tin được chọn chưa phải sản phẩm.")
                continuation = None
                if task == "export_research" and payload and payload.get("active_mission_id"):
                    previous = self.missions.get(account, enterprise, payload["active_mission_id"])
                    if (previous.get("product") or {}).get("entity_id") == product_entity_id and (previous.get("market") or {}).get("code") == market_code:
                        continuation = previous["id"]
                if payload is None:
                    stamp = now_iso()
                    payload = {"id": new_id("conversation"), "enterprise_id": enterprise, "owner_id": account,
                               "title": text[:140] or "Trao đổi từ tài liệu", "created_at": stamp, "updated_at": stamp,
                               "intake_ids": [], "active_intake_id": None, "messages": [], "drafts": {}, "operation_ids": [], "mission_ids": []}
                    db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (payload["id"], enterprise, account, json_text(payload), stamp, stamp))
                if draft:
                    self._draft(account, enterprise, payload, draft.get("intake_id"), {k: v for k, v in draft.items() if k != "intake_id"}, db)
                    self._persist_ui_draft(account, enterprise, payload, draft.get("intake_id"), db)
                # Store the exact owner question atomically with the pending
                # operation. A paid validation failure must not erase the only
                # full copy of what was sent, nor force a second paid submission.
                attachment_metadata = []
                for attachment in attachments:
                    checked = validate_attachment(attachment)
                    attachment_metadata.append({key: checked[key] for key in ("filename", "media_type", "size", "sha256", "kind")})
                payload["messages"].append({"id": new_id("message"), "role": "user", "text": text,
                    "operation_id": operation_id, "created_at": now_iso(), "attachments": attachment_metadata, "kind": "message"})
                payload.update(task_hint=task, pending_operation_id=operation_id)
                payload.pop("operation_error", None)
                self._store(db, payload)
                db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'preparing',NULL,?)", (*key, digest, payload["id"], task, now_iso()))
            self._active.add(key)
            hint_token = self.provider.task_hint.set(task)
            try:
                if task == "export_research":
                    if self.missions.source_refresher is not None:
                        previous_outcomes = [item["id"] for item in previous["intent"]["outcomes"]] if continuation else []
                        requested = allowed_intake_outcomes(text, market_code, previous_outcomes=previous_outcomes)
                        topics = list(dict.fromkeys(topic for oid in requested
                                                   if (topic := outcome_topic(oid, market_code)) is not None))
                        if topics:
                            await self.missions.refresh_sources_async(account, enterprise, market_code, topics)
                    mission = await self.missions.prepare_async(account, enterprise, text, operation_id, product_entity_id,
                                                                continuation_mission_id=continuation, market_code=market_code)
                    with self.repo.connection(write=True) as db:
                        current = self._owned(account, enterprise, payload["id"], db)
                        self._link_mission(db, current, operation_id, mission)
                else:
                    await super().send_async(account, enterprise, text, attachments, operation_id, payload["id"],
                                             product_entity_id, None, target_intake_id, paid_consent=True)
                    with self.repo.connection(write=True) as db:
                        current = self._owned(account, enterprise, payload["id"], db)
                        current["task_hint"] = task
                        self._complete(db, current, operation_id)
                return self.get(account, enterprise, payload["id"])
            except BaseException as exc:
                with self.repo.connection(write=True) as db:
                    db.execute("UPDATE main_operations SET state='failed',error_code=? WHERE account_id=? AND enterprise_id=? AND operation_id=? AND state='preparing'", (getattr(exc, "code", "OUTCOME_UNKNOWN"), *key))
                    current = self._owned(account, enterprise, payload["id"], db)
                    current.pop("pending_operation_id", None)
                    current["operation_error"] = {"operation_id": operation_id, "code": getattr(exc, "code", "OUTCOME_UNKNOWN"), "message": str(exc) if isinstance(exc, CoreError) else "Lượt xử lý chưa hoàn tất; không tự gửi lại lượt có phí."}
                    self._store(db, current)
                raise
            finally:
                self.provider.task_hint.reset(hint_token)
                self._active.discard(key)
