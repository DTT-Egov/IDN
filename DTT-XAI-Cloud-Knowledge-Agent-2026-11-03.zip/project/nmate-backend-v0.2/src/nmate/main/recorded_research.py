"""Explicit internal publication of an already paid, exact cached response.

This is intentionally absent from MCP, HTTP, boot and worker recovery. Callers
must stop the local worker and hold its enterprise runtime lock. The provider's
cache-only boundary remains active through validation and the ordinary graph;
there is no SDK retry or alternative model response in this module.
"""
from __future__ import annotations

import asyncio
import hashlib
import json

from langsmith import tracing_context

from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.workflow import build_graph
from .provider import MainProvider


TOPIC_FAILURE = "Nguồn AI trích dẫn chưa phù hợp với ý đang trả lời; kết quả chưa được công bố. Không tự gửi lại."
SCHEMA = """
CREATE TABLE IF NOT EXISTS main_recorded_research_recoveries (
 mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id),
 account_id TEXT NOT NULL, enterprise_id TEXT NOT NULL,
 provider_attempt_id TEXT NOT NULL, original_request_hash TEXT NOT NULL,
 original_response_sha256 TEXT NOT NULL, original_rows_json TEXT NOT NULL,
 state TEXT NOT NULL, error_code TEXT, started_at TEXT NOT NULL, finished_at TEXT);
"""


def _refuse(message="Lượt đã lưu không đủ điều kiện kiểm tra lại miễn phí."):
    return CoreError("RECORDED_RESEARCH_REFUSED", message, 409)


def _hash(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _read(service, db, account_id, enterprise_id, mission_id, attempt_id):
    """All authorization checks precede returning any private recovery state."""
    row = dict(service._row(account_id, enterprise_id, mission_id, db))
    attempts = [dict(item) for item in db.execute(
        "SELECT * FROM v03_live_attempts WHERE mission_id=? AND kind='research'",
        (mission_id,))]
    if len(attempts) != 1:
        raise _refuse()
    attempt = attempts[0]
    if (attempt["id"] != attempt_id or attempt["account_id"] != account_id
            or attempt["enterprise_id"] != enterprise_id
            or attempt["operation_id"] != f"research:{mission_id}"
            or attempt["state"] != "succeeded" or not attempt["response_json"]):
        raise _refuse("Kết quả nhà cung cấp chưa chắc chắn; không gửi lại hoặc suy ra kết quả.")
    try:
        envelope = json.loads(attempt["response_json"])
    except (ValueError, TypeError):
        raise _refuse() from None
    if not isinstance(envelope, dict) or envelope.get("attempt_id") != attempt_id:
        raise _refuse()
    return row, attempt


def _context(service, mission):
    checked = service.repo.validate_context(
        mission["owner_id"], mission["enterprise_id"],
        mission["context"]["fact_refs"], mission["knowledge"]["source_refs"])
    service.repo.get_entity(mission["owner_id"], mission["enterprise_id"], mission["product"]["entity_id"])
    if not checked["valid"]:
        raise CoreError("context_changed", "Dữ kiện hoặc nguồn đã đổi; không công bố kết quả đã lưu.", 409)


def _restore(service, mission_id, original, error):
    """Undo only this local publication; preserve a newly stale context status."""
    with service.repo.connection(write=True) as db:
        current = db.execute("SELECT status FROM v03_missions WHERE id=?", (mission_id,)).fetchone()
        db.execute("DELETE FROM v03_live_review_outputs WHERE mission_id=? AND kind='research'", (mission_id,))
        db.execute("DELETE FROM v03_artifact_revisions WHERE mission_id=?", (mission_id,))
        db.execute("DELETE FROM v03_task_attempts WHERE mission_id=?", (mission_id,))
        for task in original["tasks"]:
            db.execute("INSERT INTO v03_task_attempts(mission_id,task_id,attempt,state,result_json,started_at,ended_at) VALUES(?,?,?,?,?,?,?)",
                       tuple(task[key] for key in ("mission_id", "task_id", "attempt", "state", "result_json", "started_at", "ended_at")))
        db.execute("DELETE FROM v03_live_review_stages WHERE mission_id=?", (mission_id,))
        for stage in original["stages"]:
            db.execute("INSERT INTO v03_live_review_stages(mission_id,kind,state,error_message,updated_at) VALUES(?,?,?,?,?)",
                       tuple(stage[key] for key in ("mission_id", "kind", "state", "error_message", "updated_at")))
        row = original["mission"]
        if current and current["status"] == "needs_revalidation":
            db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (row["payload_json"], mission_id))
        else:
            db.execute("UPDATE v03_missions SET status=?,stale_reason=?,version=?,payload_json=?,updated_at=? WHERE id=?",
                (row["status"], row["stale_reason"], row["version"], row["payload_json"], row["updated_at"], mission_id))
        db.execute("UPDATE main_recorded_research_recoveries SET state='failed',error_code=?,finished_at=? WHERE mission_id=? AND state='recovering'",
                   (getattr(error, "code", type(error).__name__), now_iso(), mission_id))


async def recover_recorded_research(service, account_id, enterprise_id, mission_id, provider_attempt_id):
    """Strictly revalidate the original research and publish with zero dispatch.

    The exact provider request hash, current authorization, facts and sources are
    rechecked. An interrupted recovery stays visibly ambiguous and cannot be
    resumed by this function. Successful repeated calls return the existing
    publication without writing another artifact or audit entry.
    """
    if not isinstance(service.model_call, MainProvider):
        raise _refuse("Chỉ dùng được bộ cung cấp có ranh giới cache-only đã kiểm chứng.")
    provider = service.model_call
    lock = service._locks.setdefault(("recorded_research", mission_id), asyncio.Lock())
    async with lock:
        with service.repo.connection(write=True) as db:
            # Lazy schema creation is an explicit maintenance action, never boot.
            service.repo.get_membership(account_id, enterprise_id, db)
            db.executescript(SCHEMA)
        with service.repo.connection(write=True) as db:
            row, attempt = _read(service, db, account_id, enterprise_id, mission_id, provider_attempt_id)
            audit = db.execute("SELECT * FROM main_recorded_research_recoveries WHERE mission_id=?", (mission_id,)).fetchone()
            if audit:
                if (audit["state"] == "completed" and row["status"] in {"completed", "completed_partial"}
                        and audit["provider_attempt_id"] == provider_attempt_id
                        and audit["account_id"] == account_id and audit["enterprise_id"] == enterprise_id
                        and audit["original_request_hash"] == attempt["request_hash"]
                        and audit["original_response_sha256"] == _hash(attempt["response_json"])):
                    return service.get(account_id, enterprise_id, mission_id)
                raise _refuse("Lần kiểm tra lại đã dừng hoặc chưa rõ trạng thái; không tự công bố lần nữa.")
            mission = json.loads(row["payload_json"])
            stages = [dict(item) for item in db.execute("SELECT * FROM v03_live_review_stages WHERE mission_id=?", (mission_id,))]
            tasks = [dict(item) for item in db.execute("SELECT * FROM v03_task_attempts WHERE mission_id=? ORDER BY task_id,attempt", (mission_id,))]
            research_stage = next((item for item in stages if item["kind"] == "research"), None)
            if (row["status"] != "failed" or row["stale_reason"] != TOPIC_FAILURE
                    or not research_stage or research_stage["state"] != "stopped_no_replay"
                    or research_stage["error_message"] != TOPIC_FAILURE
                    or not tasks or any(item["state"] not in {"planned", "failed"} or item["result_json"] is not None for item in tasks)
                    or db.execute("SELECT 1 FROM v03_live_review_outputs WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone()
                    or db.execute("SELECT 1 FROM v03_artifact_revisions WHERE mission_id=?", (mission_id,)).fetchone()
                    or mission.get("answers") or mission.get("artifacts")
                    or not db.execute("SELECT 1 FROM main_research_authorizations WHERE mission_id=? AND account_id=? AND enterprise_id=?",
                                      (mission_id, account_id, enterprise_id)).fetchone()):
                raise _refuse()
            original = {"mission": row, "stages": stages, "tasks": tasks}
            db.execute("INSERT INTO main_recorded_research_recoveries VALUES(?,?,?,?,?,?,?,'recovering',NULL,?,NULL)",
                       (mission_id, account_id, enterprise_id, provider_attempt_id, attempt["request_hash"],
                        _hash(attempt["response_json"]), json_text(original), now_iso()))
            db.execute("UPDATE v03_missions SET status='running',updated_at=? WHERE id=? AND status='failed'", (now_iso(), mission_id))
        token = provider.recorded_only.set(True)
        try:
            _context(service, mission)
            current = service.execution_guard(mission_id)
            records = [record for record in current["knowledge"]["records"] if record.get("reusable") is True]
            # Original payload construction and ALL strict research validators.
            # MainProvider refuses any hash drift before it could dispatch.
            await service._request_research(current, records)
            service._stage(mission_id, "validated")
            with service.repo.connection(write=True) as db:
                db.execute("UPDATE v03_task_attempts SET state='planned',started_at=NULL,ended_at=NULL WHERE mission_id=?", (mission_id,))
            with tracing_context(enabled=False):
                await build_graph(service, service.execution_guard(mission_id)).ainvoke(
                    {"mission_id": mission_id, "task_results": {}}, {"recursion_limit": 24})
            with service.repo.connection(write=True) as db:
                latest, same_attempt = _read(service, db, account_id, enterprise_id, mission_id, provider_attempt_id)
                if (latest["status"] not in {"completed", "completed_partial"}
                        or dict(same_attempt) != attempt):
                    raise _refuse()
                db.execute("UPDATE main_recorded_research_recoveries SET state='completed',finished_at=? WHERE mission_id=? AND state='recovering'", (now_iso(), mission_id))
        except BaseException as exc:
            _restore(service, mission_id, original, exc)
            raise
        finally:
            provider.recorded_only.reset(token)
        return service.get(account_id, enterprise_id, mission_id)
