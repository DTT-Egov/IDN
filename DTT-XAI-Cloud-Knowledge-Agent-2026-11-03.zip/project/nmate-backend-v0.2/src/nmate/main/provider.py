"""Shared durable Claude ledger, model policy and per-owner daily reservations."""
import copy
import hashlib
import json
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from types import MappingProxyType

from nmate.v04.live_review import V04ReviewProvider
from nmate.v03.core import CoreError, json_text


_APP_INSTRUCTIONS_V1 = "\nĐây là app chính: selected_task_hint chỉ là gợi ý tác vụ do người dùng chọn, không ghi đè ý định thật. Chỉ hứa lưu các ssot_fields qua xác nhận. Số kiểm kê/ngày/mã sản phẩm hiện chỉ là dữ kiện làm việc trong chat, không hứa sẽ lưu chúng vào SSOT. Chuẩn bị xuất khẩu là tác vụ nghiên cứu riêng sau khi người dùng chọn thị trường; lượt hội thoại này không thực hiện nghiên cứu Internet."
_APP_INSTRUCTIONS_V2 = "\nĐây là app chính: selected_task_hint chỉ là gợi ý tác vụ do người dùng chọn, không ghi đè ý định thật. Chỉ hứa lưu các ssot_fields qua xác nhận. Mã sản phẩm product_code có thể được trích thành nháp và chủ doanh nghiệp xác nhận vào SSOT. Số kiểm kê và ngày kiểm kê chỉ là dữ kiện làm việc trong chat; không hứa lưu chúng như dữ kiện chuẩn. Chuẩn bị xuất khẩu là tác vụ nghiên cứu riêng sau khi người dùng chọn thị trường; lượt hội thoại này không thực hiện nghiên cứu Internet."
_APP_INSTRUCTIONS_V3 = _APP_INSTRUCTIONS_V2 + " Tên cơ sở/tên giao dịch trading_name là nháp doanh nghiệp riêng với tên sản phẩm name. Chỉ ghi trading_name khi chủ doanh nghiệp xác nhận; không suy diễn thành thay tên pháp lý legal_name, tên tài khoản hay tên doanh nghiệp hiển thị."
_ADDRESS_TERMS = ("chị", "anh", "cô", "chú", "bác", "em")
_MAIN_INTAKE_CONTRACTS = MappingProxyType({1: _APP_INSTRUCTIONS_V1, 2: _APP_INSTRUCTIONS_V2, 3: _APP_INSTRUCTIONS_V3})
CURRENT_INTAKE_CONTRACT = 3


def _decorate_address(payload, term):
    """One bounded static contract; no account data or mutable prompt prose."""
    value = copy.deepcopy(payload)
    if term in _ADDRESS_TERMS and isinstance(value.get("instructions_vi"), str):
        value["instructions_vi"] += f"\nCách xưng hô cho lượt này: gọi chủ cơ sở là {term}; trợ lý xưng mình. Đây là cài đặt giao tiếp, không phải dữ kiện doanh nghiệp."
    return value


def _decorate_main_intake(payload, task_hint, *, legacy=False, contract_version=CURRENT_INTAKE_CONTRACT):
    """Versioned server-owned model contract, including exact old cache shape."""
    version = 1 if legacy else contract_version
    if version not in _MAIN_INTAKE_CONTRACTS:
        raise ValueError("Unknown main intake contract version")
    fields = ["name", "net_quantity", "packaging", "ingredients", "origin_country",
              "sales_management", "inventory_management", "employee_count", "revenue", "business_goal"]
    if version >= 2:
        fields.insert(1, "product_code")
    if version >= 3:
        fields.insert(2, "trading_name")
    payload["input"]["selected_task_hint"] = task_hint
    payload["input"]["available_capabilities"] = {
        "owner_confirmation_required": True,
        "ssot_fields": fields,
        "inventory_answers_are_working_context_only": ["book_quantity", "physical_quantity", "count_date"] + (["product_code"] if version == 1 else []),
        "export_research_separate_explicit_paid_step": ["US", "DE", "JP"],
    }
    payload["instructions_vi"] += _MAIN_INTAKE_CONTRACTS[version]
    return payload


def canonical_main_request(kind, payload, task_hint, *, contract_version=CURRENT_INTAKE_CONTRACT, address=None):
    """DF-034: one builder shared by new dispatch and exact historic recovery."""
    value = copy.deepcopy(payload)
    if kind == "intake" and "current_question" in value.get("input", {}):
        value = _decorate_main_intake(value, task_hint, contract_version=contract_version)
    return _decorate_address(value, address)


def historic_main_request_hashes(kind, payload, task_hint):
    """Enumerate known full contracts, never partial/fuzzy context matching."""
    from nmate.v04.live_review import historic_dialogue_contract_payloads
    from nmate.v03.export_intake_contracts import historic_export_intake_payloads
    base_contracts = historic_dialogue_contract_payloads(payload) if kind == "intake" else [payload]
    if kind == "intake":
        base_contracts.extend(historic_export_intake_payloads(payload)[1:])
    return {hashlib.sha256(json_text(canonical_main_request(kind, base, task_hint,
                 contract_version=version, address=term)).encode()).hexdigest()
            for base in base_contracts for version in _MAIN_INTAKE_CONTRACTS for term in (None, *_ADDRESS_TERMS)}


class MainProvider(V04ReviewProvider):
    def __init__(self, repo, *, max_attempts=40, budget_scope="owner_daily", **kwargs):
        super().__init__(repo, max_attempts=max_attempts, **kwargs)
        self.max_attempts = max(1, min(int(max_attempts), 100))
        if budget_scope not in {"owner_daily", "global"}:
            raise ValueError("Unknown budget scope")
        self.budget_scope = budget_scope
        self.task_hint = ContextVar("main_task_hint", default=None)
        self.recorded_only = ContextVar("main_recorded_only", default=False)
        self.dispatch_guard = None
        self.governed_adapter = None

    @staticmethod
    def day_start():
        local = datetime.now(timezone(timedelta(hours=7)))
        return local.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(timezone.utc).isoformat()

    def _reservation_count(self, db, account_id, enterprise_id):
        if self.budget_scope == "global":
            return db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0]
        return db.execute("SELECT COUNT(*) FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND created_at>=?",
                          (account_id, enterprise_id, self.day_start())).fetchone()[0]

    def summary(self, *, account_id=None, enterprise_id=None, mission_id=None):
        result = super().summary(account_id=account_id, enterprise_id=enterprise_id, mission_id=mission_id)
        if self.governed_adapter is not None and account_id and enterprise_id:
            # Conversation projections can run inside a write transaction.
            # A read of the remaining quota must never provision child grants.
            gate = self.governed_adapter.gateway.status(account_id, enterprise_id, provision=False)
            legacy_grants = [g for g in gate["grants"] if set(g["purposes"]) & {"legacy_intake", "legacy_research"}]
            result["remaining_attempts"] = sum(g["remaining_calls"] for g in legacy_grants) if gate["approved"] else 0
            result["max_attempts"] = sum(g["max_calls"] for g in legacy_grants) if gate["approved"] else 0
            result["budget_scope"] = "D06_shared_local_app"
            result.update({key: gate[key] for key in (
                "known_spent_usd", "actual_spent_usd", "reserved_usd", "uncertain_usd", "uncertain_calls",
                "has_unknown_cost", "encumbered_usd", "cost_scope", "next_expiry_at", "reset_at", "reset_policy",
                "server_time", "expired_grants", "cost_basis", "billing_note_vi") if key in gate})
        elif self.budget_scope == "owner_daily" and not (account_id and enterprise_id):
            result["remaining_attempts"] = None
        else:
            with self.repo.connection() as db:
                count = self._reservation_count(db, account_id, enterprise_id)
            result["remaining_attempts"] = max(0, self.max_attempts - count)
        result.setdefault("budget_scope", self.budget_scope)
        result["budget_timezone"] = "Asia/Bangkok"
        result.setdefault("reset_policy", "local_counter_not_D06")
        result.setdefault("reset_at", None)
        return result

    def _model(self, kind, payload):
        outcomes = payload.get("input", {}).get("outcomes", [])
        complex_task = payload.get("complexity") == "complex" or kind == "research" and len(outcomes) > 1
        return self.complex_model if complex_task else self.simple_model

    async def __call__(self, kind, payload, **kwargs):
        if self.recorded_only.get():
            # A free application recovery can only read the exact original
            # successful SDK result. This branch has no dispatch path at all.
            # The native ledger stores the full canonical request hash, not raw
            # private requests. Only these exact static address decorations may
            # vary when reconstructing old requests. Current preferences must
            # not make an original successful response unrecoverable. Every
            # question, schema, SSOT value and context byte still participates
            # in the original full hash comparison; there is no partial match.
            digests = historic_main_request_hashes(kind, payload, self.task_hint.get())
            with self.repo.connection() as db:
                self.repo.get_membership(kwargs["account_id"], kwargs["enterprise_id"], db)
                row = db.execute("SELECT * FROM v03_live_attempts WHERE account_id=? AND enterprise_id=? AND kind=? AND operation_id=?",
                    (kwargs["account_id"], kwargs["enterprise_id"], kind, kwargs["operation_id"])).fetchone()
            if not row or row["state"] != "succeeded" or row["request_hash"] not in digests or not row["response_json"]:
                raise CoreError("RECORDED_CONTEXT_CHANGED", "Đầu vào không còn khớp lượt đã lưu. Không gọi AI hoặc tự gửi lại.", 409)
            envelope = json.loads(row["response_json"])
            if envelope.get("gateway_attempt_id"):
                if self.governed_adapter is None:
                    raise CoreError("RECORDED_AUTHORITY_UNAVAILABLE", "Chưa kiểm được quyền đọc kết quả đã lưu. Không gọi AI.", 409)
                self.governed_adapter.authorize_recorded_envelope(kwargs["account_id"], kwargs["enterprise_id"], envelope,
                                                                 declared_payload=payload)
            return envelope
        # Only new dispatches use the current bounded account preference. Old
        # paid receipts and exact-cache recovery retain their original contract.
        term = None
        if kwargs.get("account_id") and isinstance(payload.get("instructions_vi"), str):
            from .workspace_management import preferred_address
            from nmate.v04.dialogue import address_term, PREFERRED_ADDRESS
            preferred = preferred_address(self.repo, kwargs["account_id"])
            token = PREFERRED_ADDRESS.set(preferred)
            try:
                value = payload.get("input", {})
                term = address_term(value.get("current_question", value.get("question", "")), value.get("previous_intent"))
            finally:
                PREFERRED_ADDRESS.reset(token)
        payload = canonical_main_request(kind, payload, self.task_hint.get(), address=term)
        if self.governed_adapter is not None:
            return await self.governed_adapter(kind, payload, **kwargs)
        if self.dispatch_guard:
            self.dispatch_guard(kind, payload, kwargs)
        return await super().__call__(kind, payload, **kwargs)
