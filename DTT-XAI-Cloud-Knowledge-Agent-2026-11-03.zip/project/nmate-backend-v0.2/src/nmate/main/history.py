"""Small navigation summaries derived only from an already authorized chat view.

The original title and messages remain untouched. A policy source/rule gap is
never presented as a request for more enterprise facts.
"""
from __future__ import annotations

import re
from nmate.v04.extraction import product_name_key
from .draft_projection import stale_text_name_candidates


def _policy_goal_names():
    # Derive navigation from the same finite registry as coverage/prompt
    # compilation, so a newly supported goal cannot disappear in history.
    from nmate.policy_v1.service import GOAL_LABELS
    return {**{key: value for key, value in GOAL_LABELS.items() if key != "unspecified"},
            "market_development": "Xuất khẩu / thị trường"}


def _unconfirmed_text_name_needs_review(view, intake, name):
    return bool(name and any(product_name_key(fact.get("value")) == product_name_key(name)
                             for fact in stale_text_name_candidates(view, intake)))


def _active_mission(view):
    return next((mission for mission in view.get("missions", [])
                 if mission.get("id") == view.get("active_mission_id")), None)


def _recorded_plan_fact_count(view, intake):
    """Do not reinterpret an old plan using the enterprise's current profile."""
    mission = _active_mission(view)
    if mission and (view.get("task_hint") == "export_research" or view.get("status") == "planned"):
        refs = (mission.get("context") or {}).get("fact_refs")
        return len(refs) if isinstance(refs, list) else None
    recorded = (intake.get("origins") or {}).get("business_plan") == "claude_recorded_before_owner_confirmation"
    basis = intake.get("plan_reused_context") if "plan_reused_context" in intake else (
        None if recorded else intake.get("reused_context"))
    count = (basis or {}).get("fact_count")
    return count if isinstance(count, int) and not isinstance(count, bool) and count >= 0 else None


def _topic_title(view, intake, policy_intent, product_name):
    """A subject projection is distinct from an operation/confirmation state."""
    goal_names = _policy_goal_names()
    topics=[goal_names[g] for g in policy_intent.get("goals",[policy_intent.get("goal")]) if g in goal_names]
    intent=intake.get("intent") or {}
    if topics:
        subject=" + ".join(topics)
    elif intent.get("focus")=="restocking_planning":
        subject="Lập kế hoạch nhập hàng"
    elif intent.get("focus")=="inventory_accuracy":
        subject="Đối chiếu tồn kho"
    elif intent.get("focus")=="sales_reporting":
        subject="Báo cáo bán hàng"
    elif intent.get("focus")=="sales_inventory_overview":
        subject="Bán hàng và tồn kho"
    elif intent.get("primary")=="export_readiness" or view.get("mission_ids"):
        subject="Chuẩn bị xuất khẩu"
    elif intent.get("primary")=="improve_packaging":
        subject="Cải thiện bao bì"
    elif intent.get("primary")=="understand_business" and product_name:
        subject="Cập nhật hồ sơ"
    else:
        question=next((m.get("text","").strip() for m in view.get("messages",[]) if m.get("role")=="user" and m.get("text")),"")
        # A legacy row may lack its original user input. Never invent it from
        # a generic status or a model result; disclose the missing subject.
        if re.match(r"^(?:đã (?:lưu|xác nhận|trích|ghi)|đang (?:xử lý|đối chiếu)|chờ xác nhận)",question,re.I):
            question=""
        return question[:140] if question else "Trao đổi chưa có chủ đề gốc"
    return (str(product_name)[:60]+" · " if product_name else "")+subject


def history_metadata(view):
    intake = view.get("intake") or {}
    cases = view.get("policy_cases") or []
    active = next((case for case in cases if case.get("id") == view.get("active_policy_case_id")),
                  cases[-1] if cases else {})
    labels = []
    if view.get("intake_ids") or intake:
        labels.append("Hồ sơ")
    if view.get("mission_ids") or view.get("missions"):
        labels.append("Xuất khẩu")
    if cases:
        labels.append("Chính sách Hà Nội")
    if not labels:
        labels = [{"profile_intake": "Hồ sơ", "sales_inventory": "Bán hàng / tồn kho",
                   "export_research": "Xuất khẩu", "hanoi_policy": "Chính sách Hà Nội"}
                  .get(view.get("task_hint"), "Trao đổi")]

    # An entity name is accepted only from the scoped view, never from another
    # chat or an enterprise-wide product lookup that could pick the wrong item.
    product_name = (intake.get("product") or {}).get("name")
    stale_name = _unconfirmed_text_name_needs_review(view, intake, product_name)
    if stale_name:
        product_name = None
    if not product_name:
        products = [entity for entity in (active.get("context") or {}).get("entities", [])
                    if entity.get("entity_type") == "product" and entity.get("name")]
        if len(products) == 1:
            product_name = products[0]["name"]
    policy_intent = (active.get("scope_update") or {}).get("intent") or active.get("intent") or {}
    goal = policy_intent.get("goal")
    goals = policy_intent.get("goals") or [goal]
    intent = intake.get("intent") or {}
    task_kinds = set()
    if view.get("task_hint") in {"profile_intake", "export_research", "sales_inventory", "hanoi_policy"}:
        task_kinds.add(view["task_hint"])
    if intake or view.get("intake_ids"):
        task_kinds.add("profile_intake")
    if view.get("mission_ids") or view.get("missions") or "market_development" in goals:
        task_kinds.add("export_research")
    if cases:
        task_kinds.add("hanoi_policy")
    if intent.get("primary") == "digitize_operations" or intent.get("focus") == "inventory_accuracy":
        task_kinds.add("sales_inventory")
    task_names = {"profile_intake": "Hồ sơ", "export_research": "Xuất khẩu",
                  "sales_inventory": "Bán hàng / tồn kho", "hanoi_policy": "Chính sách Hà Nội"}
    labels = list(dict.fromkeys([*labels, *[name for kind, name in task_names.items() if kind in task_kinds]]))
    reused_count = _recorded_plan_fact_count(view, intake)
    if len(goals) > 1:
        names = {key: value if key == "ocop_program" else value[0].lower() + value[1:]
                 for key, value in _policy_goal_names().items()}
        topic = " + ".join(names[item] for item in goals if item in names) or "chính sách Hà Nội"
    elif policy_intent.get("request_scope") == "unsupported":
        topic = "câu hỏi ngoài phạm vi"
    elif intent.get("focus") == "restocking_planning":
        topic = "lập kế hoạch nhập hàng"
    elif goal == "digital_inventory" or intent.get("focus") == "inventory_accuracy":
        topic = "số hóa kho"
    elif goal == "digital_transformation" or intent.get("primary") == "digitize_operations":
        topic = "số hóa vận hành"
    elif active:
        topic = "chính sách Hà Nội"
    elif view.get("mission_ids"):
        topic = "chuẩn bị xuất khẩu"
    else:
        topic = "hồ sơ và công việc"
    title = f"{str(product_name)[:60]} · {topic}" if product_name else topic[0].upper() + topic[1:]

    status = view.get("status")
    details = []
    if stale_name:
        details.append("Tên sản phẩm trong nháp cũ cần được trích và đối chiếu lại từ câu hỏi; chưa thay đổi hồ sơ đã xác nhận.")
    if status in {"failed", "interrupted", "outcome_unknown"} or view.get("operation_error"):
        state = "Lượt trước chưa hoàn tất"
    elif status in {"processing", "preparing", "queued", "running"} or view.get("pending_operation_id"):
        state = "Đang xử lý lượt đã gửi"
    elif active:
        outcomes = active.get("outcomes") or []
        states = {item.get("status") for item in outcomes}
        effective = active.get("scope_update") or active
        if "awaiting_rule_review" in states:
            details.append("Quy tắc tư vấn chưa được duyệt")
        if states & {"needs_source", "source_currentness_unconfirmed"}:
            details.append("Còn phần thiếu căn cứ hiện hành")
        questions = active.get("ssot_questions") or (active.get("model_analysis") or {}).get("ssot_questions") or []
        if questions:
            details.append("Có câu hỏi bổ sung hồ sơ doanh nghiệp")
        if effective.get("result_status") == "unsupported" or policy_intent.get("request_scope") == "unsupported":
            state = "Nhu cầu ngoài phạm vi bản này"
        elif effective.get("result_status") == "needs_clarification" or policy_intent.get("request_scope") == "needs_clarification":
            state = "Cần làm rõ mục tiêu hỗ trợ"
        elif active.get("is_historical") or active.get("current_warning"):
            state = "Bản lưu · cần đối chiếu lại"
        elif effective.get("result_status") == "partially_answered":
            state = "Có kết quả chính sách một phần"
            if any(item.get("status") == "unsupported" for item in effective.get("goal_coverage", [])):
                details.append("Còn yêu cầu ngoài phạm vi hỗ trợ của bản này")
        elif details:
            state = "Chính sách · còn phần cần kiểm tra"
        else:
            state = "Đã có kết quả chính sách"
    elif intent.get("unsupported_request"):
        state = "Nhu cầu ngoài phạm vi bản này"
    elif stale_name:
        state = "Cần rà lại dữ kiện nháp"
    elif status == "ready":
        state = ("Trao đổi đã lưu" if (intake.get("draft_projection") or {}).get("state") == "excluded_legacy_text_extraction" else
                 "Đã dùng hồ sơ để lập kế hoạch" if reused_count else
                 "Đã lưu trao đổi · chưa dùng hồ sơ" if reused_count == 0 else "Trao đổi đã lưu")
    elif status == "planned":
        state = ("Có kế hoạch · dùng hồ sơ đã xác nhận" if reused_count else
                 "Có kế hoạch · chưa dùng hồ sơ" if reused_count == 0 else "Đã có kế hoạch")
    elif status in {"confirmed", "completed"}:
        state = "Đã lưu hồ sơ" if status == "confirmed" else "Đã có kết quả"
    elif status == "awaiting_confirmation":
        pending_count = len((intake.get("review") or {}).get("pending_candidate_ids") or [])
        state = (f"Đã lưu một phần · Còn {pending_count} dữ kiện ở nháp"
                 if (intake.get("review") or {}).get("lifecycle") == "partially_committed"
                 else "Chờ xác nhận dữ kiện")
    elif status == "completed_partial":
        state = "Có kết quả một phần"
    else:
        state = "Trao đổi đã lưu"
    # Filtering and prose share this projection. Absence of an error is not a
    # completion signal; a raw open/processing record must never match "done".
    effective = active.get("scope_update") or active
    if status in {"failed", "interrupted", "outcome_unknown"} or view.get("operation_error"):
        filter_state = "needs_attention"
    elif status in {"processing", "preparing", "queued", "running"} or view.get("pending_operation_id"):
        filter_state = "pending"
    elif active:
        filter_state = ("completed" if effective.get("result_status") == "answered"
                        and not details and not active.get("is_historical") and not active.get("current_warning")
                        else "needs_attention")
    elif (status in {"needs_clarification", "unsupported", "awaiting_confirmation", "planned", "needs_revalidation", "completed_partial"}
          or stale_name or intent.get("unsupported_request") or intent.get("primary") == "needs_clarification"):
        filter_state = "needs_attention"
    elif status in {"confirmed", "completed"}:
        filter_state = "completed"
    else:
        filter_state = "saved"
    return {"display_title": title, "topic_title": _topic_title(view,intake,policy_intent,product_name), "history_state_vi": state,
            "history_details_vi": details, "task_labels": labels,
            "history_task_kinds": sorted(task_kinds), "history_filter_state": filter_state,
            "history_reused_fact_count": reused_count,
            **({"history_extraction_review_needed": True} if stale_name else {})}
