"""Explicit local correction of one source-rights rejection before dispatch.

No paid retry exists here: any legacy/core research operation or attempt blocks
the correction, including prepared, failed and ambiguous attempts. The old
failed lifecycle and consent are audited. A new user consent is still required.
"""
from __future__ import annotations

import json

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.v03.core import CoreError, json_text, now_iso


RIGHTS_REJECTION = "Nguồn chưa được đăng ký là tài liệu công khai."
SCHEMA = """
CREATE TABLE IF NOT EXISTS main_pre_dispatch_recoveries (
 mission_id TEXT PRIMARY KEY REFERENCES v03_missions(id), account_id TEXT NOT NULL,
 enterprise_id TEXT NOT NULL, reason TEXT NOT NULL, original_rows_json TEXT NOT NULL,
 zero_dispatch_proof_json TEXT NOT NULL, recovered_at TEXT NOT NULL);
"""


def _refuse(message="Hồ sơ không đủ điều kiện sửa lỗi trước khi gửi Claude."):
    return CoreError("PRE_DISPATCH_RECOVERY_REFUSED", message, 409)


def recover_source_rights_pre_dispatch(service, account, enterprise, mission_id):
    """Re-enable an exact unstarted report; never authorize or call research.

    Invoke explicitly while the local worker is stopped. Source snapshots and
    the catalog rights remain unchanged; the fixed egress classifier is tested
    against the current registered excerpt before committing any correction.
    """
    repo = service.repo
    with repo.connection(write=True) as db:
        row = dict(service._row(account, enterprise, mission_id, db))
        mission = json.loads(row["payload_json"])
        if row["status"] == "planned" and mission.get("pre_dispatch_recovery", {}).get("reason") == "registered_public_quotation_rights_compatibility":
            return service.get(account, enterprise, mission_id)
        stages = [dict(item) for item in db.execute("SELECT * FROM v03_live_review_stages WHERE mission_id=?", (mission_id,))]
        tasks = [dict(item) for item in db.execute("SELECT * FROM v03_task_attempts WHERE mission_id=? ORDER BY task_id,attempt", (mission_id,))]
        stage = next((item for item in stages if item["kind"] == "research"), None)
        if (row["status"] != "failed" or row["stale_reason"] != RIGHTS_REJECTION
                or not stage or stage["state"] != "stopped_no_replay" or stage["error_message"] != RIGHTS_REJECTION
                or not tasks or any(item["state"] not in {"planned", "failed"} or item["result_json"] is not None for item in tasks)
                or mission.get("answers") or mission.get("artifacts")
                or db.execute("SELECT 1 FROM v03_live_review_outputs WHERE mission_id=? AND kind='research'", (mission_id,)).fetchone()
                or db.execute("SELECT 1 FROM v03_artifact_revisions WHERE mission_id=?", (mission_id,)).fetchone()):
            raise _refuse()
        operation = "research:" + mission_id
        # A reservation alone is enough to refuse. Never infer zero charge from
        # an error message, failed SDK state or an empty response body.
        legacy = db.execute("SELECT COUNT(*) FROM v03_live_attempts WHERE kind='research' AND (mission_id=? OR (account_id=? AND enterprise_id=? AND operation_id=?))",
                            (mission_id, account, enterprise, operation)).fetchone()[0]
        core = db.execute("SELECT COUNT(*) FROM core_model_attempts WHERE enterprise_id=? AND operation_id=?", (enterprise, operation)).fetchone()[0]
        core_operations = db.execute("SELECT COUNT(*) FROM core_model_operations WHERE enterprise_id=? AND operation_id=?", (enterprise, operation)).fetchone()[0]
        if legacy or core or core_operations:
            raise _refuse("Đã có dấu vết yêu cầu nhà cung cấp hoặc giữ chỗ phí; không sửa để gửi lại.")
        if not repo.validate_context(account, enterprise, mission["context"]["fact_refs"], mission["knowledge"]["source_refs"])["valid"]:
            raise _refuse("Nguồn hoặc hồ sơ đã đổi; không tự thay bản kế hoạch đang lỗi.")
        if not service._facility_binding_valid(account, enterprise, mission["context"]):
            raise _refuse("Liên kết cơ sở đã đổi; cần lập kế hoạch riêng.")
        records = [record for record in mission["knowledge"]["records"] if record.get("reusable") is True]
        if not records:
            raise _refuse("Chưa có trích đoạn nguồn đủ điều kiện dùng lại.")
        # Classification only: neither gateway nor provider is supplied, so
        # this check has no transport, reservation or budget capability.
        GovernedLegacyAdapter(repo, None, None)._public_records(records)
        authorizations = [dict(item) for item in db.execute("SELECT * FROM main_research_authorizations WHERE mission_id=?", (mission_id,))]
        if len(authorizations) != 1 or authorizations[0]["account_id"] != account or authorizations[0]["enterprise_id"] != enterprise:
            raise _refuse()
        db.execute(SCHEMA)
        if db.execute("SELECT 1 FROM main_pre_dispatch_recoveries WHERE mission_id=?", (mission_id,)).fetchone():
            raise _refuse()
        stamp = now_iso()
        proof = {"legacy_research_attempts": legacy, "core_research_attempts": core,
                 "core_research_operations": core_operations, "provider_calls": 0, "ssot_writes": 0}
        db.execute("INSERT INTO main_pre_dispatch_recoveries VALUES(?,?,?,?,?,?,?)", (
            mission_id, account, enterprise, "registered_public_quotation_rights_compatibility",
            json_text({"mission": row, "stages": stages, "tasks": tasks, "authorizations": authorizations}), json_text(proof), stamp))
        mission["pre_dispatch_recovery"] = {"reason": "registered_public_quotation_rights_compatibility", **proof,
            "requires_fresh_paid_consent": True, "original_failed_stage_preserved_in_audit": True,
            "at": stamp, "message_vi": "Lỗi phân loại nguồn xảy ra trước khi gửi Claude; lượt nghiên cứu chưa phát sinh. Đã giữ dấu vết lỗi và mở lại kế hoạch. Cần đồng ý mới trước lần gửi nghiên cứu đầu tiên."}
        db.execute("DELETE FROM v03_live_review_stages WHERE mission_id=? AND kind='research'", (mission_id,))
        db.execute("UPDATE v03_task_attempts SET state='planned',started_at=NULL,ended_at=NULL WHERE mission_id=?", (mission_id,))
        db.execute("DELETE FROM main_research_authorizations WHERE mission_id=?", (mission_id,))
        db.execute("UPDATE v03_missions SET status='planned',stale_reason=NULL,version=version+1,payload_json=?,updated_at=? WHERE id=? AND status='failed' AND version=?",
                   (json_text(mission), stamp, mission_id, row["version"]))
    return service.get(account, enterprise, mission_id)
