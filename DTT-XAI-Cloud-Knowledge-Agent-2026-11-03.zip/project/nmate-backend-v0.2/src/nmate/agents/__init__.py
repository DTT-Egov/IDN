"""Independent business workflows; common services do not contain their prompts or graphs."""
