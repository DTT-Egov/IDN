"""Derived Vietnamese display text, never a replacement for saved source evidence.

Catalog entries match the exact UTF-8 excerpt SHA-256, URL, title and publisher.
Changing even one original character makes the reference unavailable. Helpers
are pure: they never fetch sources, invoke a model, or write an artifact/database.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from types import MappingProxyType
from typing import Any, Literal

from .models import Evidence, EvidenceTranslationDraft, ShipmentWorkflowError, TranslationMetadata

REFERENCE_NOTE = "Bản dịch tham chiếu nháp, chưa được chuyên gia duyệt. Cần đối chiếu nguyên bản trước khi dùng cho thủ tục."
MODEL_NOTE = "Bản dịch nháp do cùng lượt mô hình tạo, chỉ để tham khảo; chưa được chuyên gia duyệt. Cần đối chiếu nguyên bản."
UNAVAILABLE_NOTE = "Chưa có bản dịch tiếng Việt cho đúng trích đoạn này. Có thể mở nguyên bản; không dùng nội dung tóm tắt chung thay cho bản dịch."


def excerpt_sha256(excerpt: str) -> str:
    return hashlib.sha256(excerpt.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class ReferenceTranslation:
    reference_id: str
    url: str
    title: str
    publisher: str
    excerpt: str
    title_vi: str
    excerpt_vi: str
    publisher_vi: str
    note: str = REFERENCE_NOTE


_FDA_PUBLISHER = "U.S. Food and Drug Administration"
_FDA_PUBLISHER_VI = "Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)"
_REFERENCES = (
    ReferenceTranslation(
        reference_id="FDA_IMPORT_VI_20261017_DRAFT",
        url="https://www.fda.gov/food/food-imports-exports/importing-food-products-united-states",
        title="Importing Food Products into the United States",
        publisher=_FDA_PUBLISHER,
        excerpt=(
            "Under provisions of the U.S. law contained in the U.S. Federal Food, Drug and Cosmetic Act, "
            "importers of food products intended for introduction into U.S. interstate commerce are responsible "
            "for ensuring that the products are safe, sanitary, and labeled according to U.S. requirements. "
            "(All imported food is considered to be interstate commerce.) FDA is not authorized under the law to "
            "approve, certify, license, or otherwise sanction individual food importers, products, labels, or "
            "shipments. Importers can import foods into the United States without prior sanction by FDA, as long "
            "as the facilities that produce, store, or otherwise handle the products are registered with FDA, "
            "and prior notice of incoming shipments is provided to FDA. Imported food products are subject to "
            "FDA inspection when offered for import at U.S. ports of entry. FDA may detain shipments of products "
            "offered for import if the shipments are found not to be in compliance with U.S. requirements. Both "
            "imported and domestically-produced foods must meet the same legal requirements in the United States."
        ),
        title_vi="Nhập khẩu sản phẩm thực phẩm vào Hoa Kỳ",
        excerpt_vi=(
            "Theo các quy định pháp luật Hoa Kỳ trong Đạo luật Liên bang về Thực phẩm, Dược phẩm và Mỹ phẩm, "
            "nhà nhập khẩu sản phẩm thực phẩm dự kiến đưa vào hoạt động thương mại giữa các tiểu bang Hoa Kỳ "
            "có trách nhiệm bảo đảm sản phẩm an toàn, bảo đảm vệ sinh và được ghi nhãn theo các yêu cầu của Hoa Kỳ. "
            "(Tất cả thực phẩm nhập khẩu đều được xem là thuộc hoạt động thương mại giữa các tiểu bang.) "
            "Pháp luật không trao cho FDA thẩm quyền phê duyệt, chứng nhận, cấp phép hoặc bằng hình thức khác "
            "chấp thuận từng nhà nhập khẩu thực phẩm, sản phẩm, nhãn hoặc lô hàng. Nhà nhập khẩu có thể nhập khẩu "
            "thực phẩm vào Hoa Kỳ mà không cần FDA chấp thuận trước, miễn là các cơ sở sản xuất, lưu trữ hoặc "
            "có hình thức khác xử lý sản phẩm đã đăng ký với FDA và FDA được thông báo trước về các lô hàng sắp đến. "
            "Sản phẩm thực phẩm nhập khẩu chịu sự kiểm tra của FDA khi được đưa đến các cửa khẩu Hoa Kỳ để nhập khẩu. "
            "FDA có thể tạm giữ các lô sản phẩm đưa ra để nhập khẩu nếu phát hiện các lô hàng này không đáp ứng "
            "các yêu cầu của Hoa Kỳ. Cả thực phẩm nhập khẩu và thực phẩm sản xuất trong nước đều phải đáp ứng "
            "cùng các yêu cầu pháp luật tại Hoa Kỳ."
        ),
        publisher_vi=_FDA_PUBLISHER_VI,
    ),
    ReferenceTranslation(
        reference_id="FDA_FSVP_VI_20261017_DRAFT",
        url="https://www.fda.gov/food/food-safety-modernization-act-fsma/"
        "fsma-final-rule-foreign-supplier-verification-programs-fsvp-importers-food-humans-and-animals",
        title="FSMA Final Rule on Foreign Supplier Verification Programs (FSVP) for Importers of Food for Humans and Animals",
        publisher=_FDA_PUBLISHER,
        excerpt=(
            "Who is covered by the rule? For the purposes of FSVP, an importer is the U.S. owner or consignee "
            "of a food offered for import into the United States. If there is no U.S. owner or consignee, the "
            "importer is the U.S. agency or representative of the foreign owner of consignee at the time of "
            "entry, as confirmed in a signed statement of consent. See Am I Subject to FSVP?"
        ),
        title_vi="Quy định chính thức của FSMA về các chương trình xác minh nhà cung cấp nước ngoài (FSVP) "
        "dành cho nhà nhập khẩu thực phẩm cho người và động vật",
        excerpt_vi=(
            "Ai thuộc phạm vi áp dụng của quy định này? Trong khuôn khổ FSVP, nhà nhập khẩu là chủ sở hữu "
            "hoặc bên nhận hàng tại Hoa Kỳ của thực phẩm được đưa vào Hoa Kỳ để nhập khẩu. Nếu không có chủ "
            "sở hữu hoặc bên nhận hàng tại Hoa Kỳ, nhà nhập khẩu là đại lý hoặc đại diện tại Hoa Kỳ của chủ sở "
            "hữu hoặc bên nhận hàng ở nước ngoài tại thời điểm nhập khẩu, theo xác nhận trong một văn bản đồng ý "
            "đã ký. Xem “Tôi có thuộc diện áp dụng FSVP không?”."
        ),
        publisher_vi=_FDA_PUBLISHER_VI,
        note="Bản nguồn ghi “foreign owner of consignee”; bản dịch đọc theo ngữ cảnh là “chủ sở hữu hoặc bên nhận hàng "
        "ở nước ngoài”. Đây là bản dịch tham chiếu nháp, cần người có chuyên môn đối chiếu nguyên bản trước khi dùng "
        "cho thủ tục. Không sửa chuỗi trích đoạn gốc.",
    ),
)
# Exact retrieved FDA clause renderings, manually drafted in Vietnamese; no expert approval.
_TOPIC_REFERENCES = (
    ReferenceTranslation(
        reference_id='FDA_REGISTRATION_RULES_VI_20261018_DRAFT',
        url='https://www.fda.gov/food/food-industry/how-start-food-business',
        title='How to Start a Food Business',
        publisher='U.S. Food and Drug Administration',
        excerpt='Facilities that manufacture, process, pack, or hold food that is intended for human or animal consumption in the United States must register with FDA before beginning these activities. The registration requirement applies to any facility that conducts these activities, unless a facility is specifically exempt under 21 CFR 1.226 . For example, farms, retail food establishments and restaurants are exempt from food facility registration requirements, as are private residences where FDA-regulated food is made.',
        title_vi='Hướng dẫn bắt đầu kinh doanh thực phẩm',
        excerpt_vi='Các cơ sở sản xuất, chế biến, đóng gói hoặc lưu giữ thực phẩm dành cho người hoặc động vật tiêu thụ tại Hoa Kỳ phải đăng ký với FDA trước khi bắt đầu các hoạt động này. Yêu cầu đăng ký áp dụng cho mọi cơ sở thực hiện các hoạt động đó, trừ cơ sở thuộc diện được miễn cụ thể theo 21 CFR 1.226. Ví dụ, trang trại, cơ sở bán lẻ thực phẩm và nhà hàng được miễn đăng ký cơ sở thực phẩm; nhà ở tư nhân nơi làm thực phẩm thuộc phạm vi FDA quản lý cũng được miễn.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_LABEL_ENGLISH_VI_20261018_DRAFT',
        url='https://www.fda.gov/food/food-industry/how-start-food-business',
        title='How to Start a Food Business',
        publisher='U.S. Food and Drug Administration',
        excerpt='Food manufacturers are responsible for developing labels (including nutrition information) that meet legal food labeling requirements . All labeling of FDA-regulated food products must be truthful and not misleading. Proper labeling, including nutrition labeling and labeling for the major food allergens, is required for most prepared foods. Note: The labels of food products sold in U.S. interstate commerce must be in English. If another language is used, an English translation must appear. However, foods distributed solely in Puerto Rico may bear labels in Spanish instead of English.',
        title_vi='Hướng dẫn bắt đầu kinh doanh thực phẩm',
        excerpt_vi='Nhà sản xuất thực phẩm chịu trách nhiệm xây dựng nhãn (bao gồm thông tin dinh dưỡng) đáp ứng yêu cầu pháp luật về ghi nhãn thực phẩm. Mọi nội dung ghi nhãn thực phẩm thuộc phạm vi FDA quản lý phải trung thực và không gây hiểu lầm. Phần lớn thực phẩm đã chế biến phải có nhãn đúng quy định, bao gồm nhãn dinh dưỡng và nhãn các chất gây dị ứng thực phẩm chính. Lưu ý: nhãn thực phẩm bán trong thương mại giữa các tiểu bang Hoa Kỳ phải bằng tiếng Anh. Nếu dùng ngôn ngữ khác, phải có bản dịch tiếng Anh. Tuy nhiên, thực phẩm chỉ được phân phối tại Puerto Rico có thể dùng nhãn tiếng Tây Ban Nha thay cho tiếng Anh.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_US_AGENT_VI_20261018_DRAFT',
        url='https://www.fda.gov/food/inspections-protect-food-supply/foreign-food-facility-inspection-program-questions-answers',
        title='Foreign Food Facility Inspection Program Questions & Answers',
        publisher='U.S. Food and Drug Administration',
        excerpt='The Public Health Security and Bioterrorism Preparedness and Response Act of 2002 (the Bioterrorism Act) requires a foreign facility registration to include a U.S. agent. Foreign facilities must designate a U.S. agent who lives or maintains a place of business in the U.S. and is physically present in the U.S. for purposes of registration. The U.S. agent may be authorized to register the facility.',
        title_vi='Hỏi đáp về chương trình thanh tra cơ sở thực phẩm ở nước ngoài',
        excerpt_vi='Đạo luật Chuẩn bị và Ứng phó về An ninh Y tế Công cộng và Khủng bố Sinh học năm 2002 (Đạo luật Chống khủng bố sinh học) yêu cầu hồ sơ đăng ký cơ sở ở nước ngoài phải có một đại diện tại Hoa Kỳ (U.S. agent). Cơ sở ở nước ngoài phải chỉ định một đại diện sống hoặc có địa điểm kinh doanh tại Hoa Kỳ và hiện diện thực tế tại Hoa Kỳ cho mục đích đăng ký. Đại diện tại Hoa Kỳ có thể được ủy quyền đăng ký cơ sở.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_PRIOR_NOTICE_WHO_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-industry-what-you-need-know-about-prior-notice-imported-food-shipments',
        title='Guidance for Industry: What You Need to Know About Prior Notice of Imported Food Shipments August 2011',
        publisher='U.S. Food and Drug Administration',
        excerpt='Any individual with knowledge of the required information can submit Prior Notice. This includes individuals, manufacturers, exporters, brokers, importers, and U.S. agents.',
        title_vi='Hướng dẫn: những điều cần biết về Thông báo trước lô thực phẩm nhập khẩu — tháng 8/2011',
        excerpt_vi='Bất kỳ cá nhân nào biết các thông tin bắt buộc đều có thể nộp Thông báo trước (Prior Notice). Những người này gồm cá nhân, nhà sản xuất, nhà xuất khẩu, người môi giới, nhà nhập khẩu và đại diện tại Hoa Kỳ.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_PRIOR_NOTICE_WHEN_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-industry-what-you-need-know-about-prior-notice-imported-food-shipments',
        title='Guidance for Industry: What You Need to Know About Prior Notice of Imported Food Shipments August 2011',
        publisher='U.S. Food and Drug Administration',
        excerpt='FDA must electronically receive and confirm Prior Notice before a food shipment arrives at the first port in the United States (port of arrival). The deadline for submitting Prior Notice depends on the mode of transportation used for shipment. Except in the case of food arriving by international mail, FDA must receive and confirm a Prior Notice: 1) no more than 30 days before a shipment arrives, if Prior Notice is submitted via ABI/ACS; or 2) no more than 15 days before a shipment arrives, if Prior Notice is submitted via FDA’s PNSI. In addition: For Shipments Arriving: Prior Notice Must Be Submitted: By land via road No less than 2 hours before arriving at the port of arrival By land via rail No less than 4 hours before arriving at the port of arrival By air No less than 4 hours before arriving at the port of arrival By water No less than 8 hours before arriving at the port of arrival By international mail Before the food is sent Carried by or otherwise accompanying an individual Within the timeframe for the applicable mode of transportation',
        title_vi='Hướng dẫn: những điều cần biết về Thông báo trước lô thực phẩm nhập khẩu — tháng 8/2011',
        excerpt_vi='FDA phải nhận và xác nhận Thông báo trước bằng phương thức điện tử trước khi lô thực phẩm đến cửa khẩu đầu tiên tại Hoa Kỳ (cửa khẩu đến). Hạn nộp phụ thuộc vào phương thức vận chuyển lô hàng. Trừ thực phẩm đến bằng bưu chính quốc tế, FDA phải nhận và xác nhận Thông báo trước: (1) không sớm hơn 30 ngày trước khi lô hàng đến nếu nộp qua ABI/ACS; hoặc (2) không sớm hơn 15 ngày trước khi lô hàng đến nếu nộp qua PNSI của FDA. Ngoài ra, theo phương thức đến: đường bộ bằng xe, ít nhất 2 giờ trước khi đến cửa khẩu; đường sắt, ít nhất 4 giờ; đường hàng không, ít nhất 4 giờ; đường thủy, ít nhất 8 giờ; bưu chính quốc tế, trước khi thực phẩm được gửi đi. Thực phẩm do một cá nhân mang theo hoặc đi cùng cá nhân đó phải tuân theo thời hạn tương ứng với phương thức vận chuyển.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_PRIOR_NOTICE_SCOPE_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-industry-what-you-need-know-about-prior-notice-imported-food-shipments',
        title='Guidance for Industry: What You Need to Know About Prior Notice of Imported Food Shipments August 2011',
        publisher='U.S. Food and Drug Administration',
        excerpt='Food Imports Requiring Prior Notice (Unless Exemptions Apply) Food imported for use, storage, or distribution in the U.S. (including gifts and trade and quality assurance/quality control and market research samples) Food transshipped through the U.S. to another country Food imported for future export, or food for use in a Foreign Trade Zone, unless it is on the list of exemptions on the following page',
        title_vi='Hướng dẫn: những điều cần biết về Thông báo trước lô thực phẩm nhập khẩu — tháng 8/2011',
        excerpt_vi='Các trường hợp nhập khẩu thực phẩm phải có Thông báo trước (trừ khi được miễn): thực phẩm nhập để sử dụng, lưu giữ hoặc phân phối tại Hoa Kỳ (gồm quà tặng và mẫu thương mại, mẫu bảo đảm/kiểm soát chất lượng và mẫu nghiên cứu thị trường); thực phẩm quá cảnh qua Hoa Kỳ tới quốc gia khác; thực phẩm nhập để xuất khẩu sau đó hoặc để sử dụng trong Khu Ngoại thương, trừ trường hợp nằm trong danh sách miễn ở trang tiếp theo.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_PRIOR_NOTICE_EXEMPTIONS_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-industry-what-you-need-know-about-prior-notice-imported-food-shipments',
        title='Guidance for Industry: What You Need to Know About Prior Notice of Imported Food Shipments August 2011',
        publisher='U.S. Food and Drug Administration',
        excerpt="Food carried by or otherwise accompanying (e.g., baggage) an individual arriving in the U.S. for that individual's personal use (i.e., for consumption by themselves, family, or friends, and not for sale or other distribution) Food made by an individual in his/her personal residence and sent by that individual as a personal gift (i.e., for non-business reasons) to an individual in the U.S. Food that is exported without leaving the port of arrival until export Meat food products, poultry products, and egg products that at the time of importation are subject to the exclusive jurisdiction of the U.S. Department of Agriculture (USDA) under the Federal Meat Inspection Act, the Poultry Products Inspection Act, or the Egg Products Inspection Act Food in diplomatic bags/pouches based on the authority in Art. 27(3) of The Vienna Convention on Diplomatic Relations (1961)",
        title_vi='Hướng dẫn: những điều cần biết về Thông báo trước lô thực phẩm nhập khẩu — tháng 8/2011',
        excerpt_vi='Các trường hợp được miễn: thực phẩm do cá nhân mang theo hoặc đi cùng (ví dụ trong hành lý) khi đến Hoa Kỳ, dành cho cá nhân đó sử dụng (bản thân, gia đình hoặc bạn bè tiêu thụ, không để bán hay phân phối theo cách khác); thực phẩm do cá nhân làm tại nhà riêng và chính cá nhân đó gửi làm quà tặng cá nhân, không vì mục đích kinh doanh, cho một cá nhân tại Hoa Kỳ; thực phẩm được xuất đi mà không rời cửa khẩu đến trước khi xuất; sản phẩm thịt, gia cầm và trứng tại thời điểm nhập thuộc thẩm quyền quản lý riêng của Bộ Nông nghiệp Hoa Kỳ (USDA) theo các đạo luật liên bang về kiểm tra thịt, gia cầm hoặc sản phẩm trứng; thực phẩm trong túi/túi thư ngoại giao theo Điều 27(3) Công ước Viên về Quan hệ Ngoại giao (1961).',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_LABEL_CORE_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/small-business-nutrition-labeling-exemption-guidance',
        title='Small Business Nutrition Labeling Exemption Guidance May 2007',
        publisher='U.S. Food and Drug Administration',
        excerpt='These exemptions pertain only to nutrition labeling information, and have no effect on all other mandatory information (i.e., statement of identity, net quantity of contents, ingredient statement, and name and address of manufacturer, packer or distributor).',
        title_vi='Hướng dẫn miễn ghi nhãn dinh dưỡng cho doanh nghiệp nhỏ — tháng 5/2007',
        excerpt_vi='Các miễn trừ này chỉ liên quan đến thông tin ghi nhãn dinh dưỡng và không ảnh hưởng tới mọi thông tin bắt buộc khác, gồm tên nhận diện thực phẩm, lượng tịnh, nội dung khai báo thành phần, cùng tên và địa chỉ của nhà sản xuất, bên đóng gói hoặc nhà phân phối.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_LABEL_NUTRITION_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/small-business-nutrition-labeling-exemption-guidance',
        title='Small Business Nutrition Labeling Exemption Guidance May 2007',
        publisher='U.S. Food and Drug Administration',
        excerpt='Section 403(q) of the Federal Food, Drug, and Cosmetic Act requires that packaged foods and dietary supplements bear nutrition labeling unless they qualify for an exemption.',
        title_vi='Hướng dẫn miễn ghi nhãn dinh dưỡng cho doanh nghiệp nhỏ — tháng 5/2007',
        excerpt_vi='Điều 403(q) của Đạo luật Liên bang về Thực phẩm, Dược phẩm và Mỹ phẩm yêu cầu thực phẩm đóng gói và thực phẩm bổ sung phải có nhãn dinh dưỡng, trừ khi đủ điều kiện được miễn.',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_INGREDIENTS_VI_20261018_DRAFT',
        url='https://www.fda.gov/regulatory-information/search-fda-guidance-documents/guidance-industry-questions-and-answers-regarding-food-allergen-labeling-edition-5',
        title='Guidance for Industry: Questions and Answers Regarding Food Allergen Labeling (Edition 5) January 2025',
        publisher='U.S. Food and Drug Administration',
        excerpt='As originally enacted in 1938, section 403(i) of the Federal Food, Drug, and Cosmetic Act (FD&C Act) requires that the label of a food that is fabricated from two or more ingredients declare each ingredient by its common or usual name (except that spices, flavorings, and certain colors can be declared as such) (21 U.S.C. 343(i)).',
        title_vi='Hỏi đáp về ghi nhãn chất gây dị ứng thực phẩm, phiên bản 5 — tháng 1/2025',
        excerpt_vi='Theo nội dung được ban hành ban đầu năm 1938, Điều 403(i) của Đạo luật Liên bang về Thực phẩm, Dược phẩm và Mỹ phẩm (FD&C Act) yêu cầu nhãn thực phẩm được làm từ hai thành phần trở lên phải khai báo từng thành phần bằng tên thông thường hoặc tên thường dùng (riêng gia vị, chất tạo hương và một số chất màu có thể được khai báo theo các nhóm đó) (21 U.S.C. 343(i)).',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_ALLERGENS_VI_20261018_DRAFT',
        url='https://www.fda.gov/food/nutrition-food-labeling-and-critical-foods/food-allergies',
        title='Food Allergies',
        publisher='U.S. Food and Drug Administration',
        excerpt='The major food allergens are milk, eggs, fish, Crustacean shellfish, tree nuts, peanuts, wheat, soybeans, and sesame.',
        title_vi='Dị ứng thực phẩm',
        excerpt_vi='Các chất gây dị ứng thực phẩm chính gồm sữa, trứng, cá, giáp xác, các loại hạt cây, lạc (đậu phộng), lúa mì, đậu nành và vừng (mè).',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
    ReferenceTranslation(
        reference_id='FDA_ALLERGEN_DECLARATION_VI_20261018_DRAFT',
        url='https://www.fda.gov/food/nutrition-food-labeling-and-critical-foods/food-allergies',
        title='Food Allergies',
        publisher='U.S. Food and Drug Administration',
        excerpt="People with food allergies should read labels and avoid the foods they are allergic to. The law requires that food labels identify the food source of all major food allergens used to make the food. This requirement is met if the common or usual name of an ingredient already identifies that allergen's food source name (for example, buttermilk). The law also requires that the type of tree nut (for example, almonds, pecans, walnuts), and the species of fish (for example, bass, flounder, cod) and Crustacean shellfish (for example, crab, lobster, shrimp) to be declared. The allergen's food source must be declared at least once on the food label in one of two ways. The name of the food source of a major food allergen must appear: In parentheses following the name of the ingredient. Examples: “lecithin (soy),” “flour (wheat),” and “whey (milk)” — OR — Immediately after or next to the list of ingredients in a “contains” statement. Example: “Contains wheat, milk, and soy.”",
        title_vi='Dị ứng thực phẩm',
        excerpt_vi='Người bị dị ứng thực phẩm nên đọc nhãn và tránh thực phẩm gây dị ứng cho mình. Pháp luật yêu cầu nhãn thực phẩm xác định nguồn thực phẩm của tất cả chất gây dị ứng chính được dùng để làm thực phẩm. Yêu cầu được đáp ứng nếu tên thông thường hoặc tên thường dùng của thành phần đã xác định tên nguồn gây dị ứng đó (ví dụ buttermilk, một sản phẩm từ sữa). Pháp luật cũng yêu cầu khai báo loại hạt cây (ví dụ hạnh nhân, hồ đào, óc chó), loài cá (ví dụ cá vược, cá bơn, cá tuyết) và loài giáp xác (ví dụ cua, tôm hùm, tôm). Nguồn thực phẩm gây dị ứng phải được khai báo ít nhất một lần trên nhãn bằng một trong hai cách: tên nguồn gây dị ứng chính xuất hiện trong ngoặc sau tên thành phần, ví dụ “lecithin (soy)”, “flour (wheat)”, “whey (milk)” (lecithin từ đậu nành, bột lúa mì, whey từ sữa); HOẶC ngay sau hoặc cạnh danh sách thành phần trong một câu “contains” (có chứa), ví dụ “Contains wheat, milk, and soy.” (Có chứa lúa mì, sữa và đậu nành).',
        publisher_vi='Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)',
    ),
)
REFERENCE_CATALOG = MappingProxyType({excerpt_sha256(item.excerpt): item for item in (*_REFERENCES, *_TOPIC_REFERENCES)})


def _reference_fields(evidence: Evidence) -> dict[str, Any]:
    digest = excerpt_sha256(evidence.excerpt)
    reference = REFERENCE_CATALOG.get(digest)
    if reference and (reference.url, reference.title, reference.publisher) == (
        evidence.url, evidence.title, evidence.publisher
    ):
        return {
            "title_vi": reference.title_vi, "excerpt_vi": reference.excerpt_vi,
            "publisher_vi": reference.publisher_vi,
            "translation": TranslationMetadata(
                status="draft_reference", method="reference_catalog", original_excerpt_sha256=digest,
                reference_id=reference.reference_id, note=reference.note,
            ).model_dump(mode="json"),
        }
    return {
        "title_vi": None, "excerpt_vi": None, "publisher_vi": None,
        "translation": TranslationMetadata(
            status="unavailable", method="unavailable", original_excerpt_sha256=digest, note=UNAVAILABLE_NOTE,
        ).model_dump(mode="json"),
    }


def attach_reference_translation(evidence: Evidence) -> Evidence:
    """Return a copy; unknown or changed excerpts never receive a generic translation."""
    return Evidence.model_validate({**evidence.model_dump(mode="json"), **_reference_fields(evidence)})


def apply_model_translations(
    evidence: list[Evidence], drafts: list[EvidenceTranslationDraft], *,
    model_provider: Literal["openai", "anthropic"], model_name: str,
) -> list[Evidence]:
    """Require one exact ID/hash entry per source; models cannot write originals."""
    originals = {item.id: item for item in evidence}
    submitted = {item.evidence_id: item for item in drafts}
    if len(submitted) != len(drafts) or set(submitted) != set(originals):
        raise ShipmentWorkflowError("MODEL_OUTPUT_INVALID", "Bản dịch phải khớp đủ và chỉ đúng các mã bằng chứng đã cung cấp.")
    result = []
    for original in evidence:
        draft = submitted[original.id]
        if draft.original_excerpt_sha256 != excerpt_sha256(original.excerpt):
            raise ShipmentWorkflowError("MODEL_OUTPUT_INVALID", "Bản dịch không khớp mã băm của đúng trích đoạn gốc.")
        # Prefer the fixed, exact-match reference over another model rendering.
        reference = attach_reference_translation(original)
        if reference.translation.method == "reference_catalog" or draft.status == "unavailable":
            result.append(reference)
            continue
        if draft.excerpt_vi.strip() == original.excerpt.strip():
            raise ShipmentWorkflowError("MODEL_OUTPUT_INVALID", "Mô hình chép nguyên trích đoạn gốc, chưa tạo bản dịch tiếng Việt.")
        metadata = TranslationMetadata(
            status="draft_reference", method="model", original_excerpt_sha256=draft.original_excerpt_sha256,
            model_provider=model_provider, model_name=model_name, note=MODEL_NOTE,
        )
        result.append(Evidence.model_validate({
            **original.model_dump(mode="json"), "title_vi": draft.title_vi,
            "excerpt_vi": draft.excerpt_vi, "publisher_vi": draft.publisher_vi,
            "translation": metadata.model_dump(mode="json"),
        }))
    return result


def evidence_display_translations(report: dict) -> list[dict]:
    """API sidecar rows only; never mutate an immutable report or its content hash.

    Existing valid model translations are reused. Legacy entries use the exact
    reference catalog or an explicit unavailable marker; this helper has no LLM.
    """
    rows = []
    for raw in report.get("evidence", []) if isinstance(report.get("evidence"), list) else []:
        if not isinstance(raw, dict):
            continue
        try:
            item = Evidence.model_validate(raw)
        except ValueError:
            # Ignore malformed derived fields; never trust a mismatched hash.
            original = {key: value for key, value in raw.items()
                        if key in Evidence.model_fields and key not in ("title_vi", "excerpt_vi", "publisher_vi", "translation")}
            try:
                item = Evidence.model_validate(original)
            except ValueError:
                continue
        if not item.translation or item.translation.status != "draft_reference":
            item = attach_reference_translation(item)
        rows.append({
            "evidence_id": item.id, "title_vi": item.title_vi, "excerpt_vi": item.excerpt_vi,
            "publisher_vi": item.publisher_vi,
            "translation": item.translation.model_dump(mode="json"),
        })
    return rows
