"""Bounded retrieval from a fixed FDA/CBP catalog, without API keys.

HTTP 200 alone is insufficient: JS shells, empty bodies and missing content
markers are rejected. Retrieved documents are candidates, never auto-approved.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import ipaddress
import re
import socket
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from .models import SourceBatch, SourceDocument, SourceFailure

Guard = Callable[[], Awaitable[None]] | None
ALLOWED_HOSTS = frozenset(
    {"www.fda.gov", "fda.gov", "www.cbp.gov", "cbp.gov", "www.help.cbp.gov", "help.cbp.gov"}
)


@dataclass(frozen=True)
class SourceSpec:
    id: str
    url: str
    title: str
    publisher: str
    markers: tuple[str, ...]


SOURCE_CATALOG = (
    SourceSpec(
        "fda_import",
        "https://www.fda.gov/food/food-imports-exports/importing-food-products-united-states",
        "Importing Food Products into the United States",
        "U.S. Food and Drug Administration",
        ("import", "prior notice"),
    ),
    SourceSpec(
        "fda_fsvp",
        "https://www.fda.gov/food/food-safety-modernization-act-fsma/"
        "fsma-final-rule-foreign-supplier-verification-programs-fsvp-importers-food-humans-and-animals",
        "FSMA Final Rule on Foreign Supplier Verification Programs",
        "U.S. Food and Drug Administration",
        ("foreign supplier verification", "owner or consignee"),
    ),
    SourceSpec(
        "cbp_import",
        "https://www.cbp.gov/trade/basic-import-export/tips-new-importers-and-exporters",
        "Tips for New Importers and Exporters",
        "U.S. Customs and Border Protection",
        ("importer of record", "responsib"),
    ),
    SourceSpec(
        "fda_registration",
        "https://www.fda.gov/food/food-industry/how-start-food-business",
        "How to Start a Food Business",
        "U.S. Food and Drug Administration",
        ("facilities that manufacture, process, pack, or hold food", "21 cfr 1.226", "private residences"),
    ),
    SourceSpec(
        "fda_us_agent",
        "https://www.fda.gov/food/inspections-protect-food-supply/"
        "foreign-food-facility-inspection-program-questions-answers",
        "Foreign Food Facility Inspection Program Questions & Answers",
        "U.S. Food and Drug Administration",
        ("foreign facility registration", "physically present", "u.s. agent"),
    ),
    SourceSpec(
        "fda_prior_notice",
        "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/"
        "guidance-industry-what-you-need-know-about-prior-notice-imported-food-shipments",
        "Guidance for Industry: What You Need to Know About Prior Notice of Imported Food Shipments",
        "U.S. Food and Drug Administration",
        ("any individual with knowledge", "no less than 2 hours", "no less than 8 hours", "before the food is sent"),
    ),
    SourceSpec(
        "fda_labeling",
        "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/"
        "small-business-nutrition-labeling-exemption-guidance",
        "Small Business Nutrition Labeling Exemption Guidance",
        "U.S. Food and Drug Administration",
        ("bear nutrition labeling unless", "all other mandatory information", "net quantity of contents"),
    ),
    SourceSpec(
        "fda_ingredients",
        "https://www.fda.gov/regulatory-information/search-fda-guidance-documents/"
        "guidance-industry-questions-and-answers-regarding-food-allergen-labeling-edition-5",
        "Guidance for Industry: Questions and Answers Regarding Food Allergen Labeling (Edition 5)",
        "U.S. Food and Drug Administration",
        ("two or more ingredients", "common or usual name", "sesame"),
    ),
    SourceSpec(
        "fda_allergens",
        "https://www.fda.gov/food/nutrition-food-labeling-and-critical-foods/food-allergies",
        "Food Allergies",
        "U.S. Food and Drug Administration",
        ("major food allergens", "soybeans, and sesame", "contains"),
    ),
)

# Explicit clause boundaries, not the first occurrence of a topic in a menu or
# introduction. Every returned passage is one contiguous slice of the retrieved
# whitespace-normalized document. Missing/truncated clauses produce no evidence.
# These are retrieval selectors, not cached evidence or regulatory conclusions.
_PASSAGE_BOUNDARIES = {
    "fda_registration": (
        ("registration_rules", "Facilities that manufacture, process, pack, or hold food",
         "as are private residences where FDA-regulated food is made."),
        ("label_english", "Food manufacturers are responsible for developing labels",
         "may bear labels in Spanish instead of English."),
    ),
    "fda_us_agent": (
        ("us_agent", "The Public Health Security and Bioterrorism Preparedness and Response Act of 2002 (the Bioterrorism Act) requires a foreign facility registration",
         "The U.S. agent may be authorized to register the facility."),
    ),
    "fda_prior_notice": (
        ("prior_notice_who", "Any individual with knowledge of the required information can submit Prior Notice.",
         "manufacturers, exporters, brokers, importers, and U.S. agents."),
        ("prior_notice_when", "FDA must electronically receive and confirm Prior Notice before a food shipment",
         "Within the timeframe for the applicable mode of transportation"),
        ("prior_notice_scope", "Food Imports Requiring Prior Notice (Unless Exemptions Apply)",
         "unless it is on the list of exemptions on the following page"),
        ("prior_notice_exemptions", "Food carried by or otherwise accompanying (e.g., baggage)",
         "The Vienna Convention on Diplomatic Relations (1961)"),
    ),
    "fda_labeling": (
        ("label_core", "These exemptions pertain only to nutrition labeling information,",
         "name and address of manufacturer, packer or distributor)."),
        ("label_nutrition", "Section 403(q) of the Federal Food, Drug, and Cosmetic Act requires",
         "bear nutrition labeling unless they qualify for an exemption."),
    ),
    "fda_ingredients": (
        ("ingredients", "As originally enacted in 1938, section 403(i)",
         "(21 U.S.C. 343(i))."),
    ),
    "fda_allergens": (
        ("allergens", "The major food allergens are milk, eggs, fish, Crustacean shellfish,",
         "tree nuts, peanuts, wheat, soybeans, and sesame."),
        ("allergen_declaration", "People with food allergies should read labels and avoid",
         "Example: “Contains wheat, milk, and soy.”"),
    ),
}


def source_evidence_passages(document: SourceDocument) -> list[tuple[str, str, str]]:
    """Extract only complete configured clauses from a successful live document.

    No fuzzy match, clipping, cached-text fallback, claim invention or approval.
    The locator records exact offsets into the normalized saved document.
    """
    text = re.sub(r"\s+", " ", document.text).strip()
    passages = []
    for passage_id, start, end in _PASSAGE_BOUNDARIES.get(document.id, ()):
        first = text.find(start)
        if first < 0:
            continue
        last = text.find(end, first)
        if last < 0:
            continue
        stop = last + len(end)
        excerpt = text[first:stop]
        if len(excerpt) > 1400:
            continue
        passages.append((passage_id, excerpt, f"normalized-text-chars:{first}:{stop}"))
    return passages


class SourceProvider(Protocol):
    async def fetch_all(self) -> SourceBatch: ...


class SourceRetrievalError(ValueError):
    def __init__(self, code: str, detail: str):
        self.code = code
        super().__init__(detail)


async def invoke_guard(guard: Guard) -> None:
    if guard:
        result = guard()
        if inspect.isawaitable(result):
            await result


def validate_url(url: str) -> str:
    """Reject credential-bearing URLs, unexpected schemes/ports and other hosts."""
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower().rstrip(".")
    try:
        port = parsed.port
    except ValueError as exc:
        raise SourceRetrievalError("UNSAFE_URL", "Invalid source URL port") from exc
    if (
        parsed.scheme != "https"
        or host not in ALLOWED_HOSTS
        or parsed.username is not None
        or parsed.password is not None
        or port not in (None, 443)
        or parsed.fragment
    ):
        raise SourceRetrievalError("UNSAFE_URL", "Source URL is outside the fixed HTTPS host allowlist")
    return host


async def validate_public_dns(host: str) -> None:
    try:
        records = await asyncio.get_running_loop().getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise SourceRetrievalError("DNS_UNAVAILABLE", "Unable to resolve official source") from exc
    addresses = {record[4][0].split("%")[0] for record in records}
    if not addresses or any(not ipaddress.ip_address(address).is_global for address in addresses):
        raise SourceRetrievalError("UNSAFE_ADDRESS", "Official source resolved to a non-public address")


def parse_document(spec: SourceSpec, url: str, raw: bytes, accessed_at: str) -> SourceDocument:
    """Hash the exact extracted UTF-8 text persisted in graph state, not raw HTML."""
    soup = BeautifulSoup(raw, "html.parser")
    source_date = None
    for attrs in (
        {"name": "dcterms.modified"},
        {"property": "article:modified_time"},
        {"name": "dcterms.issued"},
    ):
        tag = soup.find("meta", attrs=attrs)
        if tag and tag.get("content"):
            source_date = str(tag["content"])[:100]
            break
    h1 = soup.find("h1")
    title = h1.get_text(" ", strip=True)[:500] if h1 else spec.title
    for tag in soup(["script", "style", "noscript", "nav", "header", "footer", "iframe", "form"]):
        tag.decompose()
    main = soup.find("main") or soup.find("article") or soup.find(attrs={"role": "main"}) or soup.body
    if main is None:
        raise SourceRetrievalError("EMPTY_CONTENT", "Official source did not contain readable main content")
    regions = [main]
    if spec.id == "fda_us_agent":
        # The FDA FAQ has malformed HTML: several official accordion panels are
        # siblings of <main>/<article>, not descendants. Read only its labelled
        # FDA panels, never the whole page chrome or an unbounded fallback body.
        regions.extend(panel for panel in soup.select(".fda-accordion-panel")
                       if main not in panel.parents)
    lines = [" ".join(line.split()) for region in regions
             for line in region.get_text("\n", strip=True).splitlines()]
    text = "\n".join(line for line in lines if line)[:100_000]
    normalized = " ".join(text.casefold().split())
    if len(text) < 300 or not all(marker in normalized for marker in spec.markers):
        raise SourceRetrievalError(
            "EMPTY_CONTENT", "Readable source text/required markers missing; possible JS shell or challenge"
        )
    return SourceDocument(
        id=spec.id,
        url=url,
        title=title,
        publisher=spec.publisher,
        accessed_at=accessed_at,
        source_date=source_date,
        content_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        text=text,
    )


class OfficialSourceProvider:
    """Nine fixed official URLs, bounded bytes/time/redirects, three connections."""

    def __init__(
        self,
        *,
        guard: Guard = None,
        timeout_seconds: float = 12.0,
        max_bytes: int = 1_000_000,
        max_redirects: int = 3,
    ):
        if not 0 < timeout_seconds <= 30 or not 1_000 <= max_bytes <= 2_000_000:
            raise ValueError("Source retrieval limits are outside the supported bounds")
        if not 0 <= max_redirects <= 3:
            raise ValueError("At most three redirects are permitted")
        self.guard = guard
        self.timeout_seconds = timeout_seconds
        self.max_bytes = max_bytes
        self.max_redirects = max_redirects

    async def _fetch_one(self, client: httpx.AsyncClient, spec: SourceSpec) -> SourceDocument | SourceFailure:
        url = spec.url
        try:
            # Deadline includes DNS, redirects and reading the body for this source.
            async with asyncio.timeout(self.timeout_seconds):
                for hop in range(self.max_redirects + 1):
                    await invoke_guard(self.guard)
                    host = validate_url(url)
                    await validate_public_dns(host)
                    await invoke_guard(self.guard)
                    async with client.stream("GET", url) as response:
                        if response.status_code in (301, 302, 303, 307, 308):
                            target = response.headers.get("location")
                            if not target or hop >= self.max_redirects:
                                raise SourceRetrievalError("REDIRECT_LIMIT", "Official source redirect limit reached")
                            url = urljoin(url, target)
                            validate_url(url)
                            continue
                        if response.status_code != 200:
                            raise SourceRetrievalError(
                                f"HTTP_{response.status_code}", "Official source returned a non-success HTTP status"
                            )
                        content_type = response.headers.get("content-type", "").lower()
                        if not any(t in content_type for t in ("text/html", "text/plain", "application/xhtml+xml")):
                            raise SourceRetrievalError("UNSUPPORTED_CONTENT", "Official source is not readable HTML/text")
                        size = response.headers.get("content-length")
                        if size and size.isdigit() and int(size) > self.max_bytes:
                            raise SourceRetrievalError("BODY_TOO_LARGE", "Official source exceeds the body limit")
                        body = bytearray()
                        async for chunk in response.aiter_bytes():
                            await invoke_guard(self.guard)
                            body.extend(chunk)
                            if len(body) > self.max_bytes:
                                raise SourceRetrievalError("BODY_TOO_LARGE", "Official source exceeds the body limit")
                        return parse_document(
                            spec, str(response.url), bytes(body), datetime.now(timezone.utc).isoformat()
                        )
                raise SourceRetrievalError("REDIRECT_LIMIT", "Official source redirect limit reached")
        except SourceRetrievalError as exc:
            return SourceFailure(source_id=spec.id, url=spec.url, code=exc.code, detail=str(exc))
        except (TimeoutError, httpx.TimeoutException):
            return SourceFailure(
                source_id=spec.id, url=spec.url, code="SOURCE_TIMEOUT", detail="Official source timed out"
            )
        except (httpx.HTTPError, OSError):
            return SourceFailure(
                source_id=spec.id, url=spec.url, code="SOURCE_UNAVAILABLE", detail="Official source is unavailable"
            )

    async def fetch_all(self) -> SourceBatch:
        await invoke_guard(self.guard)
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds,
            follow_redirects=False,
            trust_env=False,
            limits=httpx.Limits(max_connections=3, max_keepalive_connections=3),
            headers={
                "User-Agent": "NMate-Research/0.2 (official-source retrieval)",
                "Accept": "text/html,text/plain;q=0.9",
                "Accept-Encoding": "identity",
            },
        ) as client:
            results = await asyncio.gather(*(self._fetch_one(client, spec) for spec in SOURCE_CATALOG))
        return SourceBatch(
            sources=[item for item in results if isinstance(item, SourceDocument)],
            failures=[item for item in results if isinstance(item, SourceFailure)],
        )
