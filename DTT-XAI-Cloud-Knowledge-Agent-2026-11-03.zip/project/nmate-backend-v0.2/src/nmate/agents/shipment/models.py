"""Typed results for the bounded US dry-food preparation workflow."""
from __future__ import annotations

import hashlib
import re
import unicodedata
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

SHIPMENT_KIND = "shipment_readiness"
REPORT_SCHEMA_VERSION = "0.2.0"
NEXT_STEPS_POLICY_VERSION = "0.2.3"
ResearchTopic = Literal["fda_registration", "labeling", "prior_notice", "certifications", "quote"]
TOPIC_ACTION_IDS = {
    "fda_registration": "clarify_facility_registration",
    "labeling": "prepare_food_label",
    "prior_notice": "prepare_prior_notice",
    "certifications": "clarify_certification_requirements",
    "quote": "complete_quote_information",
}
TARGET_ASSESSMENT_WORDS = 80
MAX_ASSESSMENT_WORDS = 160
MAX_ASSESSMENT_CHARS = 2000
ExecutionMode = Literal["evidence_only", "llm"]


def assessment_summary_constraints_error(summary: str) -> str | None:
    """Hard bounds stay errors even when a presentation issue is repairable."""
    if not summary.strip():
        return "Nhận định không được để trống."
    word_count = len(summary.split())
    if word_count > MAX_ASSESSMENT_WORDS:
        return f"Nhận định có {word_count} từ, vượt giới hạn {MAX_ASSESSMENT_WORDS} từ."
    if len(summary) > MAX_ASSESSMENT_CHARS:
        return f"Nhận định có {len(summary)} ký tự, vượt giới hạn {MAX_ASSESSMENT_CHARS} ký tự."
    return None


def assessment_summary_error(summary: str) -> str | None:
    """Stored assessments cannot become a second numbered/prioritized plan."""
    constraint_error = assessment_summary_constraints_error(summary)
    if constraint_error:
        return constraint_error
    folded = unicodedata.normalize("NFKD", summary.casefold().replace("đ", "d"))
    folded = "".join(char for char in folded if not unicodedata.combining(char))
    if re.search(r"(?m)^\s*(?:[-*•]|\d{1,2}[.)]|\(\d{1,2}\)|[①②③])(?:\s+|$)", summary):
        return "Nhận định không được tạo danh sách hành động đánh số hoặc gạch đầu dòng."
    if re.search(r"(?:^|[\s:;])(?:[123][.)]|\([123]\)|[①②③])\s+", summary):
        return "Nhận định không được tạo danh sách hành động đánh số."
    if re.search(
        r"\b(?:uu tien|truoc het|dau tien|thu nhat|thu hai|thu ba|sau do|tiep theo|cuoi cung|"
        r"ba viec|3 viec|priority|prioriti[sz]e|firstly|secondly|thirdly|next steps?|action plan)\b|"
        r"\b(?:buoc|viec|step|action)\s+(?:thu\s+)?(?:\d+|mot|hai|ba|nhat|first|second|third)\b",
        folded,
    ):
        return "Nhận định không được tạo thứ tự ưu tiên cạnh tranh với các việc tiếp theo đã lưu."
    return None


class DomainModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Finding(DomainModel):
    id: str
    title: str
    explanation: str
    evidence_ids: list[str] = Field(default_factory=list)
    basis: Literal["case_fact_unverified", "official_source", "rule_based", "llm_synthesis"]
    applicability: Literal[
        "general_guidance", "potentially_applicable", "requires_expert_confirmation", "out_of_scope"
    ]


class Unknown(DomainModel):
    field: str
    question: str


class Responsibility(DomainModel):
    role: Literal["importer_of_record", "fsvp_importer", "supplier_exporter"]
    party: str | None
    status: Literal["unknown", "provided_unverified"]
    verification_needed: str
    evidence_ids: list[str] = Field(default_factory=list)


class QuoteInformation(DomainModel):
    field: str
    value: str | int | float | None


class NextStep(DomainModel):
    id: str
    title: str
    reason: str
    evidence_ids: list[str] = Field(default_factory=list)
    owner_role: str | None = Field(default=None, min_length=1, max_length=200)
    done_when: str | None = Field(default=None, min_length=1, max_length=700)


class TopicAnswer(DomainModel):
    """A bounded, source-gated answer; never a case-specific compliance decision."""

    topic: ResearchTopic
    title: str = Field(min_length=1, max_length=160)
    answer: str = Field(min_length=1, max_length=2200)
    coverage: Literal["available", "partial", "unavailable"]
    evidence_ids: list[str] = Field(default_factory=list, max_length=12)
    applicability: Literal["general_guidance", "requires_expert_confirmation"] = "requires_expert_confirmation"


class TranslationMetadata(DomainModel):
    language: Literal["vi"] = "vi"
    status: Literal["draft_reference", "unavailable"]
    method: Literal["reference_catalog", "model", "unavailable"]
    original_excerpt_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    reference_id: str | None = None
    model_provider: Literal["openai", "anthropic"] | None = None
    model_name: str | None = Field(default=None, max_length=200)
    note: str = Field(min_length=1, max_length=600)


class EvidenceTranslationDraft(DomainModel):
    """Only derived text can be returned by the model; originals are not writable."""

    evidence_id: str = Field(min_length=1, max_length=200)
    original_excerpt_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    status: Literal["translated", "unavailable"]
    title_vi: str | None = Field(default=None, min_length=1, max_length=600)
    excerpt_vi: str | None = Field(default=None, min_length=1, max_length=5000)
    publisher_vi: str | None = Field(default=None, min_length=1, max_length=300)

    @model_validator(mode="after")
    def validate_translation_fields(self) -> EvidenceTranslationDraft:
        values = (self.title_vi, self.excerpt_vi, self.publisher_vi)
        if self.status == "translated" and not all(value and value.strip() for value in values):
            raise ValueError("A translated draft requires complete Vietnamese text")
        if self.status == "unavailable" and any(value is not None for value in values):
            raise ValueError("An unavailable translation must not fabricate translated text")
        return self


class Evidence(DomainModel):
    id: str
    url: str
    title: str
    publisher: str
    accessed_at: str
    source_date: str | None = None
    content_sha256: str = Field(
        pattern=r"^[a-f0-9]{64}$",
        description="SHA-256 of the extracted UTF-8 source text persisted in graph state, not raw HTML.",
    )
    excerpt: str = Field(min_length=1, max_length=1400)
    locator: str
    review_status: Literal["candidate"] = "candidate"
    title_vi: str | None = Field(default=None, min_length=1, max_length=600)
    excerpt_vi: str | None = Field(default=None, min_length=1, max_length=5000)
    publisher_vi: str | None = Field(default=None, min_length=1, max_length=300)
    translation: TranslationMetadata | None = None

    @model_validator(mode="after")
    def validate_translation_binding(self) -> Evidence:
        values = (self.title_vi, self.excerpt_vi, self.publisher_vi)
        if self.translation is None:
            if any(value is not None for value in values):
                raise ValueError("Derived Vietnamese text requires translation provenance")
            return self  # Old artifacts without additive fields remain valid.
        if hashlib.sha256(self.excerpt.encode("utf-8")).hexdigest() != self.translation.original_excerpt_sha256:
            raise ValueError("Translation does not match the exact original excerpt")
        if self.translation.status == "unavailable":
            if (self.translation.method != "unavailable" or any(value is not None for value in values)
                    or self.translation.reference_id or self.translation.model_provider or self.translation.model_name):
                raise ValueError("Unavailable translation must remain explicitly unavailable")
        elif not all(value and value.strip() for value in values):
            raise ValueError("A translation requires complete Vietnamese text")
        elif self.translation.method == "reference_catalog":
            if not self.translation.reference_id or self.translation.model_provider or self.translation.model_name:
                raise ValueError("Reference catalog translation must identify its reference without claiming model use")
        elif self.translation.method == "model":
            if not self.translation.model_provider or not self.translation.model_name or self.translation.reference_id:
                raise ValueError("Model translation must identify the actual provider/model")
        else:
            raise ValueError("A translated draft requires a declared translation method")
        return self


class SourceFailure(DomainModel):
    source_id: str
    url: str
    code: str
    detail: str


class SourceDocument(DomainModel):
    id: str
    url: str
    title: str
    publisher: str
    accessed_at: str
    source_date: str | None = None
    content_sha256: str = Field(
        pattern=r"^[a-f0-9]{64}$",
        description="SHA-256 of this document.text encoded as UTF-8; text is the persisted source snapshot.",
    )
    text: str = Field(min_length=1, max_length=100_000)

    @model_validator(mode="after")
    def validate_snapshot_hash(self) -> SourceDocument:
        if hashlib.sha256(self.text.encode("utf-8")).hexdigest() != self.content_sha256:
            raise ValueError("Source snapshot hash does not match persisted extracted text")
        return self


class SourceBatch(DomainModel):
    sources: list[SourceDocument] = Field(default_factory=list)
    failures: list[SourceFailure] = Field(default_factory=list)


class ShipmentReport(DomainModel):
    schema_version: Literal["0.2.0"] = REPORT_SCHEMA_VERSION
    kind: Literal["shipment_readiness"] = SHIPMENT_KIND
    summary: str = Field(description="Nhận định thực tế; với chính sách 0.2.2, mục tiêu không quá 80 từ, "
                         "giới hạn cứng 160 từ và 2000 ký tự, không danh sách hành động hoặc ưu tiên thứ hai. "
                         "Báo cáo lịch sử thiếu markers giữ nguyên nội dung.")
    summary_kind: Literal["assessment"] | None = None
    summary_origin: Literal["rule_based", "model"] | None = Field(
        default=None,
        description="Nguồn của riêng phần nhận định; None cho báo cáo lịch sử. "
        "rule_based là đối chiếu theo quy tắc, không phải câu trả lời của mô hình.",
    )
    next_steps_policy_version: Literal["0.2.2", "0.2.3"] | None = None
    question_topics: list[ResearchTopic] = Field(default_factory=list, max_length=5)
    topic_answers: list[TopicAnswer] = Field(default_factory=list, max_length=5)
    mode: ExecutionMode
    llm_used: bool = False
    model_provider: Literal["openai", "anthropic"] | None = None
    model_name: str | None = Field(default=None, max_length=200)
    uncertain_fields: list[str] = Field(default_factory=list, max_length=30,
                                        description="Các dữ kiện DN cung cấp dưới dạng ước lượng; xác nhận lưu không phải xác minh.")
    readiness_status: Literal[
        "preparation_only", "needs_information", "needs_specialist", "evidence_incomplete", "unsupported_scope"
    ]
    findings: list[Finding]
    unknowns: list[Unknown]
    responsibilities: list[Responsibility]
    quote_information: list[QuoteInformation]
    next_steps: list[NextStep] = Field(max_length=3)
    evidence: list[Evidence]
    source_failures: list[SourceFailure]
    warnings: list[str]

    @model_validator(mode="after")
    def validate_references(self) -> ShipmentReport:
        ids = {e.id for e in self.evidence}
        if len(ids) != len(self.evidence):
            raise ValueError("Duplicate evidence identifiers")
        for item in [*self.findings, *self.responsibilities, *self.next_steps, *self.topic_answers]:
            if not set(item.evidence_ids).issubset(ids):
                raise ValueError("An evidence identifier is not present in this report")
        if self.mode == "evidence_only" and self.llm_used:
            raise ValueError("evidence_only must never claim an LLM was used")
        if self.mode == "evidence_only" and self.summary_origin == "model":
            raise ValueError("evidence_only must not claim a model assessment")
        if self.mode == "evidence_only" and (self.model_provider is not None or self.model_name is not None):
            raise ValueError("evidence_only must not claim provider/model execution metadata")
        if self.mode == "evidence_only" and any(
            item.translation and item.translation.method == "model" for item in self.evidence
        ):
            raise ValueError("evidence_only must not claim a model translation")
        if self.mode == "llm" and not self.llm_used:
            raise ValueError("llm mode must not silently fall back to evidence_only")
        for item in self.evidence:
            if item.translation and item.translation.method == "model" and (
                item.translation.model_provider != self.model_provider or item.translation.model_name != self.model_name
            ):
                raise ValueError("A model translation must match the report's actual provider/model")
        if (self.summary_kind is None) != (self.next_steps_policy_version is None):
            raise ValueError("Assessment and canonical action policy markers must be supplied together")
        if self.next_steps_policy_version in {"0.2.2", NEXT_STEPS_POLICY_VERSION}:
            error = assessment_summary_error(self.summary)
            if error:
                raise ValueError(error)
            step_ids = [step.id for step in self.next_steps]
            allowed = {"clarify_import_roles", "clarify_delivery_terms", "complete_product_dossier",
                       "complete_quote_information", "expert_preparation_review"}
            if self.next_steps_policy_version == "0.2.3":
                allowed |= set(TOPIC_ACTION_IDS.values())
            if len(set(step_ids)) != len(step_ids) or not set(step_ids).issubset(allowed):
                raise ValueError("Canonical next steps require unique known action IDs")
            if self.readiness_status == "unsupported_scope":
                if self.next_steps:
                    raise ValueError("An unsupported case must not receive preparation actions")
            else:
                if not step_ids:
                    raise ValueError("A supported case must have a canonical preparation action")
                if self.next_steps_policy_version == "0.2.2" and step_ids[-1] != "expert_preparation_review":
                    raise ValueError("Expert preparation review must be the final canonical action")
                missing = {item.field for item in self.unknowns}
                # The old policy remains unchanged for immutable historical
                # reports. New reports prioritize the actual question.
                if (self.next_steps_policy_version == "0.2.2"
                        and {"shipment.importer_of_record", "shipment.fsvp_importer"} & missing
                        and "clarify_import_roles" not in step_ids):
                    raise ValueError("Missing import roles must have their grouped canonical action")
                if (self.next_steps_policy_version == "0.2.2" and "shipment.incoterm" in missing
                        and "clarify_delivery_terms" not in step_ids):
                    raise ValueError("Missing delivery terms must have an explicit canonical action")
            if any(not step.owner_role or not step.done_when for step in self.next_steps):
                raise ValueError("Canonical actions must state the responsible role and completion evidence")
            if self.next_steps_policy_version == "0.2.3":
                if len(set(self.question_topics)) != len(self.question_topics):
                    raise ValueError("Question topics must be unique")
                topics = [answer.topic for answer in self.topic_answers]
                if topics != self.question_topics:
                    raise ValueError("Every question topic must have exactly one answer in the same order")
                if self.readiness_status != "unsupported_scope" and not {
                    TOPIC_ACTION_IDS[topic] for topic in self.question_topics[:3]
                }.issubset(step_ids):
                    raise ValueError("Canonical actions must address the requested topics")
                for answer in self.topic_answers:
                    if answer.coverage == "available" and answer.topic != "quote" and not answer.evidence_ids:
                        raise ValueError("An available regulatory answer needs source evidence")
                    if answer.coverage == "unavailable" and answer.evidence_ids:
                        raise ValueError("An unavailable answer cannot claim source coverage")
        return self


class ShipmentWorkflowError(ValueError):
    """Expected workflow error that the application can map to its error envelope."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)
