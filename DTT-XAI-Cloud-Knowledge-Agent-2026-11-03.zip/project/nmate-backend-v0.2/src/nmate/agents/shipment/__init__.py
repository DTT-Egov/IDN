"""Independent Shipment Readiness workflow; no MCP or application mutations here."""
from .models import REPORT_SCHEMA_VERSION, SHIPMENT_KIND, ShipmentReport, ShipmentWorkflowError

__all__ = ["REPORT_SCHEMA_VERSION", "SHIPMENT_KIND", "ShipmentReport", "ShipmentWorkflowError", "build_graph"]


def build_graph(*args, **kwargs):
    # Avoid importing LangGraph merely to inspect the report schema.
    from .graph import build_graph as factory

    return factory(*args, **kwargs)
