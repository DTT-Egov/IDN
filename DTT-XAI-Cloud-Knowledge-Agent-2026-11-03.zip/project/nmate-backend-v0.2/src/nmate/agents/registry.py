from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class AgentDefinition:
    kind: str
    title: str
    artifact_type: str
    status: Literal["available", "planned"]
    version: str = "0.2.0"


AGENTS = {
    "shipment_readiness": AgentDefinition("shipment_readiness", "Chuẩn bị lô hàng", "shipment_preparation_plan", "available"),
    "market_research": AgentDefinition("market_research", "Thị trường và kênh", "market_comparison", "planned"),
    "partner_discovery": AgentDefinition("partner_discovery", "Nghiên cứu đối tác", "partner_shortlist", "planned"),
}
