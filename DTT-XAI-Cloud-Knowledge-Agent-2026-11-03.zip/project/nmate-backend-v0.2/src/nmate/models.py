from dataclasses import dataclass
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True, allow_inf_nan=False)


class Product(StrictModel):
    sku: str = Field(min_length=1, max_length=100)
    name: str = Field(min_length=1, max_length=200)
    family: str = Field(default="dry_food", min_length=1, max_length=50)
    ingredients: list[str] | None = Field(default=None, max_length=30)
    processing_description: str | None = Field(default=None, max_length=1000)
    packaging: str | None = Field(default=None, max_length=300)
    shelf_life: str | None = Field(default=None, max_length=200)
    certifications: list[str] | None = Field(default=None, max_length=30)
    origin_country: str = Field(default="VN", min_length=2, max_length=2)


class Shipment(StrictModel):
    target_market: str = Field(default="US", min_length=2, max_length=2)
    route: str = Field(default="importer", max_length=50)
    quantity_units: int | None = Field(default=None, ge=1, le=1000000)
    carton_count: int | None = Field(default=None, ge=1, le=100000)
    gross_weight_kg: float | None = Field(default=None, gt=0, le=100000)
    carton_dimensions_cm: str | None = Field(default=None, max_length=200)
    pickup_location: str | None = Field(default=None, max_length=300)
    destination: str | None = Field(default=None, max_length=300)
    incoterm: str | None = Field(default=None, max_length=100)
    importer_of_record: str | None = Field(default=None, max_length=300)
    fsvp_importer: str | None = Field(default=None, max_length=300)


CaseFactField = Literal[
    "product.sku", "product.name", "product.ingredients", "product.processing_description",
    "product.packaging", "product.shelf_life", "product.certifications",
    "shipment.quantity_units", "shipment.carton_count", "shipment.gross_weight_kg",
    "shipment.carton_dimensions_cm", "shipment.pickup_location", "shipment.destination",
    "shipment.incoterm", "shipment.importer_of_record", "shipment.fsvp_importer", "question",
]


class FactProvenance(StrictModel):
    message_id: str = Field(min_length=1, max_length=128)
    source_quote: str = Field(min_length=1, max_length=2000)
    certainty: Literal["provided", "estimate"]
    confirmed: Literal[True]


class ResearchContext(StrictModel):
    uncertain_fields: list[CaseFactField] = Field(default_factory=list, max_length=30)
    field_sources: dict[CaseFactField, FactProvenance] = Field(default_factory=dict, max_length=30)


class CaseCreate(StrictModel):
    product: Product
    shipment: Shipment = Field(default_factory=Shipment)
    consent_research: bool = False
    consent_model: bool = False
    research_context: ResearchContext | None = None


class CaseReplace(CaseCreate):
    expected_case_version: int = Field(ge=1)


class StartInput(StrictModel):
    case_id: str = Field(min_length=1, max_length=128)
    expected_case_version: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128)
    question: str = Field(default="Cần chuẩn bị gì cho lô hàng thử nghiệm?", min_length=1, max_length=2000)
    processing_level: Literal["auto", "standard", "complex"] = "auto"


class RunInput(StrictModel):
    run_id: str = Field(min_length=1, max_length=128)


class ArtifactInput(StrictModel):
    artifact_id: str = Field(min_length=1, max_length=128)


class CaseInput(StrictModel):
    case_id: str = Field(min_length=1, max_length=128)


class ToolCall(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    arguments: dict = Field(default_factory=dict)


@dataclass(frozen=True)
class Principal:
    tenant_id: str
    subject: str
    role: Literal["business", "research"] = "business"


class AppError(Exception):
    def __init__(self, code: str, message: str, status: int = 400):
        self.code, self.message, self.status = code, message, status
        super().__init__(message)

    def envelope(self) -> dict:
        return {"ok": False, "error": {"code": self.code, "message": self.message}}


def success(data: dict | list) -> dict:
    return {"ok": True, "data": data}
