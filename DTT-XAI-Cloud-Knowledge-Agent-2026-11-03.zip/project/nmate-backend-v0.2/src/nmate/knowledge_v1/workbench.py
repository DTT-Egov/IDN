"""Opt-in HTTP adapter to the same authenticated MCP registry.

Host supplies its existing session/CSRF validator. Never mounted on MAIN by M3.
No login system, public-data identity shortcut, paid tool or budget authority.
"""
import inspect,json
from pathlib import Path
from fastapi import APIRouter,Request
from fastapi.responses import FileResponse,JSONResponse
from mcp import Client
from nmate.v03.mcp import create_mcp,account_context
from nmate.v03.core import CoreError
from .mcp_m3 import register_tools,NAMES
from .mcp import register_tools as register_pipeline

def router(service,gateway,resolve_account,*,simulation=None):
    result=APIRouter(prefix='/knowledge')
    names=NAMES|{'knowledge_candidate_edit','knowledge_candidate','knowledge_backlinks'}
    if hasattr(service,'bind_applicability'):
        from .mcp_m4 import NAMES as M4_NAMES
        names|=M4_NAMES
    if simulation is not None:
        from .mcp_simulation import NAMES as SIMULATION_NAMES
        names|=SIMULATION_NAMES
    def register(server,call):
        register_pipeline(server,service,call);register_tools(server,service,call,gateway)
        if hasattr(service,'bind_applicability'):
            from .mcp_m4 import register_tools as register_m4
            register_m4(server,service,call)
        if simulation is not None:
            from .mcp_simulation import register_tools as register_simulation
            register_simulation(server,simulation,call)
    server=create_mcp(service.repo,None,extra_register=register,tool_allowlist=names)
    assets=Path(__file__).parent/'workbench_web'

    async def context(request):
        value=resolve_account(request)
        if inspect.isawaitable(value):value=await value
        if not value:return None
        return value if isinstance(value,dict) else dict(account_id=value,csrf_token=None)

    @result.get('/session')
    async def session(request:Request):
        try:value=await context(request)
        except CoreError as exc:return JSONResponse({'ok':False,'error':{'code':exc.code,'message':str(exc)}},status_code=exc.status_code)
        if not value:return JSONResponse({'ok':False,'error':{'code':'UNAUTHORIZED','message':'Cần đăng nhập bằng phiên ứng dụng hiện có.'}},status_code=401)
        return JSONResponse({'ok':True,'account_id':value['account_id'],'csrf_token':value.get('csrf_token')},headers={'Cache-Control':'no-store'})

    @result.get('/')
    async def index(): return FileResponse(assets/'index.html')

    @result.get('/app.js')
    async def javascript(): return FileResponse(assets/'app.js',media_type='application/javascript')

    if simulation is not None:
        @result.get('/simulation')
        async def simulation_index():return FileResponse(assets/'simulation.html')

        @result.get('/simulation.js')
        async def simulation_javascript():return FileResponse(assets/'simulation.js',media_type='application/javascript')

    @result.post('/rpc')
    async def rpc(request:Request):
        try:identity=await context(request)
        except CoreError as exc:return JSONResponse({'ok':False,'error':{'code':exc.code,'message':str(exc)}},status_code=exc.status_code)
        if not identity:return JSONResponse({'ok':False,'error':{'code':'UNAUTHORIZED','message':'Cần đăng nhập bằng phiên ứng dụng hiện có.'}},status_code=401)
        actor=identity['account_id']
        origin=request.headers.get('origin')
        if origin and origin!=str(request.base_url).rstrip('/'):
            return JSONResponse({'ok':False,'error':{'code':'FORBIDDEN','message':'Nguồn yêu cầu chưa hợp lệ.'}},status_code=403)
        raw=await request.body()
        if len(raw)>200000: return JSONResponse({'ok':False,'error':{'code':'INPUT_LIMIT','message':'Nội dung quá dài.'}},status_code=413)
        try:
            data=json.loads(raw)
            if set(data)!={'tool','arguments'} or data['tool'] not in names or not isinstance(data['arguments'],dict): raise ValueError()
        except (ValueError,TypeError): return JSONResponse({'ok':False,'error':{'code':'INVALID_INPUT','message':'Yêu cầu chưa đúng định dạng.'}},status_code=400)
        token=account_context.set(actor)
        try:
            async with Client(server,mode='2026-07-28',cache=None) as client:
                definitions=await client.list_tools()
                schema=next(t.input_schema for t in definitions.tools if t.name==data['tool'])
                if set(data['arguments'])-set(schema.get('properties',{})):
                    return JSONResponse({'ok':False,'error':{'code':'INVALID_INPUT','message':'Có trường ngoài hợp đồng của tác vụ.'}},status_code=400)
                value=await client.call_tool(data['tool'],data['arguments'])
                body=dict(value.structured_content or {'ok':False,'error':{'code':'INVALID_INPUT','message':'Dữ liệu chưa đúng hợp đồng. Kiểm tra tên trường và phiên bản.'}})
                return JSONResponse(body|{'_scope_actor_id':actor},headers={'Cache-Control':'no-store'})
        finally: account_context.reset(token)
    return result
