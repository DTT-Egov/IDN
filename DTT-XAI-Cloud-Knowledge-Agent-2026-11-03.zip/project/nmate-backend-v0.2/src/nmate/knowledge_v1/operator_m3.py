"""Exact M2→M3 upgrade on an explicit offline target, no automatic grants."""
from contextlib import closing
from functools import lru_cache
from pathlib import Path
import json,sqlite3,tempfile
from .schema_m3 import M3_STATEMENTS
from .operator_m2 import expected_m2_objects,target_m2_contract
from .schema import M1_STATEMENTS
from .schema_m2 import M2_STATEMENTS
from nmate.core_v1.runtime_schema import schema_objects,open_readonly,verify_runtime_database,digest
from nmate.core_v1.schema_lifecycle import create_plan,apply_plan
from nmate.v03.core import CoreError


@lru_cache(maxsize=1)
def expected_m3_objects():
    with closing(sqlite3.connect(':memory:')) as db:
        for sql in M1_STATEMENTS+M2_STATEMENTS+M3_STATEMENTS: db.execute(sql)
        return schema_objects(db)


def require_m3(db):
    wanted={r['name']:r for r in expected_m3_objects()}
    actual={r['name']:r for r in schema_objects(db) if r['name'] in wanted or r['name'].startswith(('kp_','pol_wiki_','core_domain_'))}
    if actual!=wanted: raise CoreError('knowledge_schema_not_ready','Cần operator kiểm schema M3 trên bản sao.',409)


def target_m3_contract():
    from nmate.core_v1.runtime_schema import read_runtime_contract
    value=read_runtime_contract();value['version']='nmate-main-20261027-knowledge-m3'
    value['required_objects']=sorted(value['required_objects']+expected_m3_objects(),key=lambda r:(r['type'],r['name']))
    return value


def install_m3_on_clone(database,*,backup_path):
    source=Path(__file__).resolve().parents[2]
    with closing(open_readonly(database)) as db:
        actual={r['name']:r for r in schema_objects(db) if r['name'].startswith(('kp_','pol_wiki_','core_domain_'))}
        known_m2={r['name']:r for r in expected_m2_objects()}
        known_m3={r['name']:r for r in expected_m3_objects()}
        if actual not in (known_m2,known_m3):
            raise CoreError('knowledge_schema_not_ready','Schema M2/M3 đã lệch; cần đối soát trước dry-run, chưa ghi gì.',409)
        if actual=={r['name']:r for r in expected_m3_objects()}:
            # Reconcile the original identity before trying a new DDL rehearsal.
            # Same common plan checksum/source verifier and apply authority.
            receipt=db.execute("SELECT plan_sha256,receipt_json FROM core_schema_migration_receipts WHERE version='knowledge-m3-20261027'").fetchone()
            if receipt is None: raise CoreError('migration_receipt_required','Schema đã có nhưng thiếu biên nhận; cần đối soát, chưa nhận đã apply.',409)
            saved=json.loads(receipt[1])
            plan=dict(schema_version='schema-migration-plan/1',version='knowledge-m3-20261027',statements=M3_STATEMENTS,
                source=saved['source'],before_schema_sha256=saved['before_schema_sha256'],after_schema_sha256=saved['after_schema_sha256'],
                required_receipts=[],dry_run=dict(passed=True,original_writes=0,provider_calls=0))
            plan['plan_sha256']=digest(plan)
            if plan['plan_sha256']!=receipt[0] or saved['plan_sha256']!=receipt[0]:
                raise CoreError('migration_receipt_mismatch','Biên nhận migration không đúng kế hoạch gốc.',409)
            replay=apply_plan(database,plan,source_root=source,backup_path=backup_path)
            return {'plan':plan,'receipt':replay}
    plan=create_plan(database,version='knowledge-m3-20261027',statements=M3_STATEMENTS,source_root=source,
        dependency_files=['nmate/knowledge_v1/schema_m3.py','nmate/knowledge_v1/operator_m3.py','nmate/core_v1/domain_gateway.py','nmate/core_v1/gateway.py'])
    with closing(open_readonly(database)) as original,closing(sqlite3.connect(':memory:')) as prepared:
        actual={r['name']:r for r in schema_objects(original) if r['name'].startswith(('kp_','pol_wiki_','core_domain_'))}
        m2={r['name']:r for r in expected_m2_objects()};m3={r['name']:r for r in expected_m3_objects()}
        if actual not in (m2,m3): raise CoreError('knowledge_schema_not_ready','Baseline phải đúng M2/M3, chưa tự sửa.',409)
        if original.execute("SELECT 1 FROM sqlite_master WHERE name='v04_conversations'").fetchone():
            with tempfile.TemporaryDirectory(prefix='wiki-contract-') as folder:
                target=Path(folder)/'contract.json';target.write_text(json.dumps(target_m2_contract() if actual==m2 else target_m3_contract()),encoding='utf-8')
                verify_runtime_database(database,contract_path=target)
        original.backup(prepared)
        if actual==m2:
            for sql in M3_STATEMENTS: prepared.execute(sql)
        require_m3(prepared)
    receipt=apply_plan(database,plan,source_root=source,backup_path=backup_path)
    with closing(sqlite3.connect(database)) as db: require_m3(db)
    return {'plan':plan,'receipt':receipt}


def open_m3_runtime(database,*,contract_path):
    verify_runtime_database(database,contract_path=contract_path)
    from nmate.v03.core import CoreRepository
    from .governance import WikiGovernance
    class ExistingRepository(CoreRepository):
        def __init__(self,path):
            self.db_path=str(Path(path).resolve(strict=True));self.managed_runtime=True;self._memory_anchor=None;self._uri=False
    return WikiGovernance(ExistingRepository(database))
