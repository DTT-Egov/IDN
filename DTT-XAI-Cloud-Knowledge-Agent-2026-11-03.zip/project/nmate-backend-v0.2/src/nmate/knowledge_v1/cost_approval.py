"""Authenticated main-account facade over the existing independent command.

No provider, queue, budget issuance or separate decision store. Browser data is
never trusted as the actor/assignment; v1 operator decisions cannot be submitted.
"""

from pathlib import Path
from nmate.v03.core import CoreError, now_iso
from .cost_authority import deny
from . import worker_m6, independent_branch


class CostApprovalService:
    def __init__(self, main_repo, assignment):
        self.repo = main_repo
        self.assignment = assignment
        if Path(main_repo.db_path).resolve() != Path(assignment.record["main_database"]).resolve():
            deny()
        self.directory = Path(assignment.record["public_batch_directory"])

    def _actor(self, actor, *, write=False):
        if write:
            self.assignment.check_write(actor)
        else:
            self.assignment.check_identity(actor)
        prepared, _, _, _ = worker_m6._load(self.directory)
        self.assignment.check_target(prepared)

    def status(self, actor):
        # Non-approvers do not learn the account, batch, failures or budget.
        if actor != self.assignment.record["subject"]["account_id"]:
            return dict(enabled=False)
        self._actor(actor)
        status = worker_m6.snapshot(self.directory)
        writable = True
        try:
            self._actor(actor, write=True)
        except CoreError:
            writable = False
        grant = None
        _, receipt, repo, authority = worker_m6._load(self.directory)
        with repo.connection() as db:
            grant = db.execute(
                "SELECT * FROM core_domain_budget_grants WHERE id=?", (receipt["id"],)
            ).fetchone()
            spec = authority._scope_row(db, grant["id"])
        from nmate.core_v1.gateway import money_micro

        return dict(
            enabled=True,
            account_id=actor,
            username=self.assignment.record["subject"]["username"],
            can_approve=writable
            and status["expires_at"] > now_iso()
            and status["grant_state"] == "paused_admission_review"
            and status["blocked_slots"] == ["O1"]
            and status["remaining_slots"] == ["O2"],
            grant_id=status["grant_id"],
            batch_instance_id=status["batch_instance_id"],
            expires_at=status["expires_at"],
            grant_state=status["grant_state"],
            blocked_slots=status["blocked_slots"],
            completed_slots=status["completed_slots"],
            remaining_slots=status["remaining_slots"],
            provider_calls=status["provider_calls"],
            known_estimated_microusd=status["known_estimated_microusd"],
            target_slot="O2",
            model="claude-opus-5-5",
            cap_microusd=money_micro(spec["per_role"]["complex"]["max_cost_usd"]),
            continuation_recorded=status.get("independent_continuation") is not None,
            automatic_dispatch=False,
            automatic_retry=False,
        )

    def preview(self, actor, command_id):
        self._actor(actor, write=True)
        return independent_branch.preview(self.directory, command_id, approver=self.assignment.descriptor())

    def approve(self, actor, decision):
        self._actor(actor)
        if (
            not isinstance(decision, dict)
            or decision.get("schema_version") != "knowledge-independent-continuation/2"
            or decision.get("approver") != self.assignment.descriptor()
            or decision.get("approved_by") != actor
        ):
            deny()
        # Shared application command returns exact historical receipt before
        # checking WRITE. A revoke must not create a permit or block allowed READ.
        return independent_branch.continue_independent(
            self.directory, decision, approver=self.assignment.descriptor()
        )
