"""Current source identity for NEW reviews/continuations, never old replay."""

from .governance import WikiGovernance
from . import source_control


def source_versions(service, db, actor, refs):
    versions = []
    for sid in sorted({r["source_id"] for r in refs}):
        pipeline = WikiGovernance._source_fingerprint(service, db, actor, sid)
        upstream = source_control.fingerprint(db, sid)
        control = source_control.current(db, sid) if source_control.enabled(db) else None
        versions.append(dict(source_id=sid, pipeline=pipeline, upstream=upstream, control=control))
    return versions
