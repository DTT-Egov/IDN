"""Versioned goal contracts, separate from receipt success and legal release.

DF-025/026: a schema-valid generic paragraph is not five FAQs or a checklist.
Every visible assertion is either evidenced or explicitly a source gap.
"""

import copy
from jsonschema import Draft202012Validator, ValidationError
from nmate.v03.core import CoreError

EVIDENCE = {
    "type": "array",
    "maxItems": 4,
    "items": {
        "type": "object",
        "properties": {
            "evidence_id": {"type": "string", "minLength": 1, "maxLength": 20},
            "quote": {"type": "string", "minLength": 1, "maxLength": 300},
        },
        "required": ["evidence_id", "quote"],
        "additionalProperties": False,
    },
}
UNIT = {
    "id": {"type": "string", "pattern": "^[a-zA-Z0-9_.:-]{1,80}$"},
    "text": {"type": "string", "minLength": 1, "maxLength": 600},
    "status": {"enum": ["supported", "gap"]},
    "evidence": EVIDENCE,
    "gap": {"type": "string", "maxLength": 500},
}


def unit(extra=None):
    props = copy.deepcopy(UNIT) | (extra or {})
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def schema(kind):
    props = {
        "contract_version": {"const": "policy-demo/1"},
        "kind": {"const": kind},
        "title": {"type": "string", "minLength": 1, "maxLength": 200},
    }
    if kind in {"overview_faq", "demo_package"}:
        props |= {
            "overview": {"type": "array", "minItems": 1, "maxItems": 7, "items": unit()},
            "faq": {
                "type": "array",
                "minItems": 5,
                "maxItems": 5,
                "items": unit({"question": {"type": "string", "minLength": 1, "maxLength": 200}}),
            },
        }
    if kind in {"checklist", "demo_package"}:
        props["actions"] = {
            "type": "array",
            "minItems": 5,
            "maxItems": 7,
            "items": unit(
                {
                    "inputs": {
                        "type": "array",
                        "minItems": 1,
                        "maxItems": 5,
                        "items": {"type": "string", "minLength": 1, "maxLength": 200},
                    },
                    "output": {"type": "string", "minLength": 1, "maxLength": 200},
                }
            ),
        }
    elif kind == "critique":
        props |= {
            "findings": {
                "type": "array",
                "maxItems": 12,
                "items": unit(
                    {
                        "target_id": {"type": "string", "minLength": 1, "maxLength": 80},
                        "severity": {"enum": ["critical", "major", "minor"]},
                    }
                ),
            },
            "unassessed": {
                "type": "array",
                "maxItems": 30,
                "uniqueItems": True,
                "items": {"type": "string", "minLength": 1, "maxLength": 80},
            },
        }
        props["assessed_target_ids"] = {
            "type": "array",
            "maxItems": 30,
            "uniqueItems": True,
            "items": {"type": "string", "minLength": 1, "maxLength": 160},
        }
        props["unassessed"]["items"]["maxLength"] = 160
        props["findings"]["items"]["properties"]["target_id"]["maxLength"] = 160
    elif kind not in {"overview_faq", "demo_package"}:
        raise CoreError("INVALID_ARTIFACT_KIND", "Loại đầu ra chưa được hỗ trợ.", 409)
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def units(data):
    return [x for key in ("overview", "faq", "actions", "findings") for x in data.get(key, [])]


def target_ids(prior_proposals):
    result = []
    for p in prior_proposals:
        data = p["data"]
        ids = (
            [n["id"] for n in units(data)]
            if data.get("contract_version") == "policy-demo/1"
            else ["claim" + str(i) for i, _ in enumerate(data.get("claims", []))]
        )
        result += [p["attempt_id"] + ":" + i for i in ids]
    return result


def validate_artifact(data, *, expected_kind=None, prior_proposals=None):
    try:
        if not isinstance(data, dict):
            raise ValueError()
        kind = data.get("kind")
        if expected_kind is not None and kind != expected_kind:
            raise ValueError()
        Draft202012Validator(schema(kind)).validate(data)
        nodes = units(data)
        if len({n["id"] for n in nodes}) != len(nodes):
            raise ValueError()
        for n in nodes:
            if n["status"] == "supported" and (not n["evidence"] or n["gap"]):
                raise ValueError()
            if n["status"] == "gap" and (not n["gap"].strip() or n["evidence"]):
                raise ValueError()
        # Bound the overview independently of FAQ/checklist; render as one page.
        if sum(len(n["text"]) for n in data.get("overview", [])) > 2400:
            raise ValueError()
        if kind == "critique":
            assessed = data["assessed_target_ids"]
            unassessed = data["unassessed"]
            if not assessed and not unassessed:
                raise ValueError()
            if set(assessed) & set(unassessed):
                raise ValueError()
            if any(n["target_id"] not in assessed for n in data["findings"]):
                raise ValueError()
            if prior_proposals is not None and set(assessed + unassessed) != set(target_ids(prior_proposals)):
                raise ValueError()
    except (ValidationError, ValueError, TypeError, KeyError):
        raise CoreError(
            "ARTIFACT_GOAL_INCOMPLETE",
            "Đầu ra chưa đủ cấu trúc hoặc chưa phân biệt căn cứ và phần thiếu nguồn.",
            409,
        ) from None
    return data


SLOT_KINDS = {
    "S1": "overview_faq",
    "S2": "overview_faq",
    "S3": "overview_faq",
    "S4": "checklist",
    "O1": "critique",
    "O2": "critique",
}


def kind_for(slot, recipe):
    return "demo_package" if recipe == "policy-knowledge-package/1" and slot == "S3" else SLOT_KINDS[slot]


def candidate(service, actor, data, body):
    """Use the existing exact-span admission, never treat gap text as a claim."""
    validate_artifact(data, prior_proposals=body["input"].get("prior_proposals", []))
    from .ai_proposals import _candidate_payload

    supported = [
        dict(kind="interpretation", text=n["text"], evidence=n["evidence"])
        for n in units(data)
        if n["status"] == "supported"
    ]
    legacy = dict(
        title=data["title"],
        claims=supported,
        gaps=[n["gap"] for n in units(data) if n["status"] == "gap"],
        questions_for_expert=[],
    )
    # Existing narrow quote alignment and source ACLs remain authoritative.
    payload, admission = _candidate_payload(service, actor, legacy, body, aligned=True, artifact=True)
    admission |= dict(
        version="proposal-admission/4",
        artifact_contract="policy-demo/1",
        artifact_kind=data["kind"],
        goal_structure_complete=True,
        content_verified=False,
        requires_expert_review=True,
    )
    return payload, admission


def render_markdown(data):
    validate_artifact(data)
    lines = ["# " + data["title"], "", "> Bản nháp chưa duyệt — không phải tư vấn đã phát hành.", ""]
    for n in units(data):
        lines += ["## " + n.get("question", n["id"]), n["text"]]
        if "inputs" in n:
            lines += ["Đầu vào: " + "; ".join(n["inputs"]), "Kết quả cần có: " + n["output"]]
        if n["status"] == "gap":
            lines += ["**Chưa trả lời được:** " + n["gap"]]
        else:
            lines += ["Căn cứ: " + "; ".join(e["evidence_id"] for e in n["evidence"])]
        lines += [""]
    if data.get("unassessed"):
        lines += ["Chưa rà: " + ", ".join(data["unassessed"])]
    return "\n".join(lines)
