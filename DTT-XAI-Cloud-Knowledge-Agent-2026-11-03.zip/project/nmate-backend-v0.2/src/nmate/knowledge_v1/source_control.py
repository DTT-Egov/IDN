"""M4 causal bridge for existing catalog writers. No backfill or READ writes.

Operational decisions stay out of the semantic review hash. A post-migration
observation anchors legacy data explicitly; old receipts never acquire one.
"""
import json
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.v03.core import CoreError,new_id

def fail():
    raise CoreError('knowledge_integrity_error','Chuỗi kiểm nguồn không khớp dữ liệu hiện tại; cần đối soát, chưa dùng tư vấn mới.',409)

def enabled(db):
    return bool(db.execute("SELECT 1 FROM sqlite_master WHERE name='ks_source_controls'").fetchone())

def head(db,source_id):
    h=db.execute('SELECT * FROM ks_source_control_heads WHERE source_id=?',(source_id,)).fetchone()
    if not h:
        if db.execute('SELECT 1 FROM ks_source_controls WHERE source_id=?',(source_id,)).fetchone():fail()
        return None
    row=db.execute('SELECT * FROM ks_source_controls WHERE source_id=? AND id=?',(source_id,h['decision_id'])).fetchone()
    if not row or row['sequence']!=h['sequence']:fail()
    if db.execute('SELECT 1 FROM ks_source_controls WHERE source_id=? AND previous_id=?',(source_id,row['id'])).fetchone():fail()
    value=dict(row)
    try:payload=json.loads(value['payload_json'])
    except (TypeError,ValueError):fail()
    if digest({k:v for k,v in value.items() if k!='record_hash'})!=value['record_hash'] or digest(payload)!=value['content_hash']:fail()
    if row['previous_id']:
        previous=db.execute('SELECT sequence FROM ks_source_controls WHERE source_id=? AND id=?',(source_id,row['previous_id'])).fetchone()
        if not previous or previous['sequence']+1!=row['sequence']:fail()
    elif row['sequence']!=1:fail()
    return value|{'payload':payload}

def fingerprint(db,source_id):
    source=db.execute('SELECT id,current_snapshot_id,url,language,metadata_json FROM pol_sources WHERE id=?',(source_id,)).fetchone()
    if not source:fail()
    gate=db.execute('SELECT * FROM pol_source_gates WHERE source_id=?',(source_id,)).fetchone()
    if not gate:
        if db.execute('SELECT 1 FROM pol_source_observations WHERE source_id=?',(source_id,)).fetchone():fail()
        return dict(source=dict(source),snapshot=None,gate=None,observation=None)
    observation=db.execute('SELECT * FROM pol_source_observations WHERE id=?',(gate['observation_id'],)).fetchone()
    snapshot=db.execute('SELECT id,source_id,raw_sha256,text_sha256 FROM pol_source_snapshots WHERE id=?',(source['current_snapshot_id'],)).fetchone()
    count=db.execute('SELECT count(*) FROM pol_source_observations WHERE source_id=?',(source_id,)).fetchone()[0]
    if (not observation or observation['source_id']!=source_id or observation['snapshot_id']!=source['current_snapshot_id'] or
        observation['checked_at']!=gate['checked_at'] or type(gate['version']) is not int or gate['version']!=count or
        (source['current_snapshot_id'] and (not snapshot or snapshot['source_id']!=source_id))):fail()
    # Count is only a conservation check for the pre-existing writer, never
    # a way to select authority or order observations by time/UUID/rowid.
    return dict(source=dict(source),snapshot=dict(snapshot) if snapshot else None,gate=dict(gate),observation=dict(observation))

def current(db,source_id):
    proof=head(db,source_id)
    actual=fingerprint(db,source_id)
    if proof and (proof['payload']!=actual or proof['observation_id']!=(actual['gate'] or {}).get('observation_id')):fail()
    return dict(anchored=bool(proof),decision_id=proof['id'] if proof else None,sequence=proof['sequence'] if proof else None,
      content_hash=proof['content_hash'] if proof else None,record_hash=proof['record_hash'] if proof else None)

def before_write(db,source_id):
    if enabled(db):current(db,source_id)

def append_observation(db,source_id):
    if not enabled(db):return
    previous=head(db,source_id);payload=fingerprint(db,source_id)
    if not payload['gate']:fail()
    value=dict(id=new_id('source_control'),source_id=source_id,previous_id=previous['id'] if previous else None,
      sequence=previous['sequence']+1 if previous else 1,observation_id=payload['gate']['observation_id'],
      payload_json=canonical(payload),content_hash=digest(payload))
    db.execute('INSERT INTO ks_source_controls VALUES(?,?,?,?,?,?,?,?)',(*value.values(),digest(value)))
    if previous:
        changed=db.execute('UPDATE ks_source_control_heads SET decision_id=?,sequence=? WHERE source_id=? AND decision_id=?',
          (value['id'],value['sequence'],source_id,previous['id']))
        if changed.rowcount!=1:fail()
    else:db.execute('INSERT INTO ks_source_control_heads VALUES(?,?,?)',(source_id,value['id'],value['sequence']))
