"""Scoped wiki expert workflow over the existing catalog authority.

AI proposal, human authoring, review and publication are separate capabilities.
No model call is possible from this module or its read/recovery methods.
"""
from datetime import datetime,timedelta,timezone
import difflib,json
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError,new_id,now_iso
from .pipeline import PipelineService,rendition_read,extraction_read,integrity
from .service import identifier,text,version_precondition
from .operator_m3 import require_m3


def _capabilities_exist(db):
    return db.execute("SELECT 1 FROM sqlite_master WHERE name='pol_wiki_capabilities'").fetchone() is not None


def _sources(db,revision_id):
    return {row[0] for row in db.execute('SELECT DISTINCT source_id FROM kp_wiki_dependencies WHERE revision_id=?',(revision_id,))}


def _cap(db,actor,policy,source_ids,capability):
    if not _capabilities_exist(db) or not source_ids: return False
    given={r[0] for r in db.execute('SELECT c.source_id FROM pol_wiki_capabilities c JOIN v03_accounts a ON a.id=c.account_id WHERE c.account_id=? AND c.policy_id=? AND c.capability=? AND c.revoked_at IS NULL AND a.active=1',(actor,policy,capability))}
    return set(source_ids)<=given


def _authority(db,actor,policy,sources,capability):
    if not _cap(db,actor,policy,sources,capability): raise CoreError('wiki_scope_denied','Chưa có quyền tác vụ wiki trên đúng chương trình và toàn bộ nguồn.',403)
    role={'review':'reviewer','publish':'publisher','attest':'reviewer'}.get(capability)
    if role:
        # Same catalog role authority, plus explicit new artifact capability.
        KnowledgeCatalog._member_authority(db,actor,role,{'policy_id':policy,'evidence_json':canonical([{'source_id':s} for s in sorted(sources)])})


def scoped_wiki_read(db,actor,page,revision_id):
    sources=_sources(db,revision_id)
    for capability in ('read','author','review','publish','attest'):
        try: _authority(db,actor,page['policy_id'],sources,capability)
        except CoreError: continue
        return True
    return False


class WikiGovernance(PipelineService):
    def __init__(self,repo):
        super().__init__(repo)
        with repo.connection() as db: require_m3(db)

    def _candidate_authorize(self,db,actor,policy_id,evidence):
        if KnowledgeCatalog._has_global_authority(db,actor,'curator'): return
        sources=set().union(*(self._resolve(db,actor,ref) for ref in evidence))
        _authority(db,actor,policy_id,sources,'author')

    def _source_fingerprint(self,db,actor,source_id):
        state=self._state(db,actor,source_id)
        if state['observation_id'] is None: raise CoreError('source_incomplete','Nguồn chưa có bản tệp được nhận.',409)
        observation=db.execute('SELECT * FROM kp_acquisition_observations WHERE source_id=? AND id=?',(source_id,state['observation_id'])).fetchone()
        if observation is None: integrity()
        raw=rendition_read(self,db,actor,observation['rendition_id'])
        rights=self._source_read(db,actor,source_id)
        # Recipe identity is explicit; never pick processor truth by timestamp.
        from .local_parser import PARSER_VERSION
        active=db.execute('SELECT id FROM kp_extractions WHERE rendition_id=? AND parser_version=?',(raw['id'],PARSER_VERSION)).fetchone()
        extracted=extraction_read(self,db,actor,active[0]) if active else None
        return {'source_id':source_id,'state_version':state['version'],'manifest_id':state['manifest_id'],
            'observation_id':state['observation_id'],'rendition_id':raw['id'],'raw_hash':raw['raw_hash'],
            'rights_revision_id':rights['event_id'],'manifest':state['manifest'],
            'extraction_id':extracted['extraction_id'] if extracted else None,
            'extraction_quality':extracted['quality'] if extracted else 'pending'}

    @staticmethod
    def _append_decision(db,kind,values):
        table={'attestation':'pol_wiki_source_attestations','review':'pol_wiki_reviews','release':'pol_wiki_releases'}[kind]
        columns=[r[1] for r in db.execute(f'PRAGMA table_info({table})') if r[1]!='record_hash']
        record=dict(zip(columns,values,strict=True))
        db.execute(f'INSERT INTO {table} VALUES('+','.join('?' for _ in range(len(values)+1))+')',(*values,digest(record)))

    @staticmethod
    def _head(db,kind,keys):
        # Static table/column registry: no client-controlled SQL identifiers.
        config={'attestation':('pol_wiki_attestation_heads','pol_wiki_source_attestations',('policy_id','source_id'),'version'),
                'review':('pol_wiki_review_heads','pol_wiki_reviews',('page_id',),'sequence'),
                'release':('pol_wiki_release_heads','pol_wiki_releases',('page_id',),'sequence')}
        heads,events,columns,seq=config[kind];where=' AND '.join(c+'=?' for c in columns)
        row=db.execute(f'SELECT * FROM {heads} WHERE {where}',keys).fetchone()
        if row is None:
            if db.execute(f'SELECT 1 FROM {events} WHERE {where}',keys).fetchone(): integrity('Thiếu head của chuỗi quyết định; chưa tự dựng lại.')
            return None
        event=db.execute(f'SELECT * FROM {events} WHERE {where} AND id=?',(*keys,row['decision_id'])).fetchone()
        if (event is None or event[seq]!=row[seq] or db.execute(f'SELECT 1 FROM {events} WHERE {where} AND previous_id=?',(*keys,row['decision_id'])).fetchone()): integrity('Head không phải quyết định cuối chuỗi; cần đối soát.')
        if digest({k:event[k] for k in event.keys() if k!='record_hash'})!=event['record_hash']: integrity('Quyết định không khớp nội dung đã ghi.')
        if kind=='review' and digest(json.loads(event['manifest_json']))!=event['manifest_hash']: integrity()
        return dict(event)

    def attest_source(self,actor,policy_id,source_id,*,expected_source_version,complete,legal_currency_confirmed,current_until,rationale,operation_id):
        request=dict(policy_id=policy_id,source_id=source_id,expected_source_version=expected_source_version,complete=complete,
                     legal_currency_confirmed=legal_currency_confirmed,current_until=current_until,rationale=rationale)
        kind='knowledge.wiki.source_attest/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            identifier(policy_id);identifier(source_id);version_precondition(expected_source_version)
            _authority(db,actor,policy_id,{source_id},'attest');text(rationale,'Căn cứ xác minh',8000)
            if type(complete) is not bool or type(legal_currency_confirmed) is not bool: raise CoreError('invalid_attestation','Cần xác nhận rõ từng tiêu chí.')
            try:
                until=datetime.fromisoformat(current_until);now=datetime.now(timezone.utc)
                if until.tzinfo is None or not now<until<=now+timedelta(hours=24): raise ValueError()
            except (TypeError,ValueError): raise CoreError('invalid_attestation','Hạn kiểm cần múi giờ và tối đa24giờ.') from None
            source=self._source_fingerprint(db,actor,source_id)
            if source['state_version']!=expected_source_version: raise CoreError('revision_conflict','Nguồn đã đổi từ lúc xem.',409)
            if complete and (source['manifest']['gaps'] or source['extraction_quality']!='text_extracted'): raise CoreError('source_incomplete','Nguồn còn khoảng trống/chưa đọc đủ; không được xác nhận đủ.',409)
            old=self._head(db,'attestation',(policy_id,source_id));version=(old['version'] if old else 0)+1
            payload=dict(complete=complete,legal_currency_confirmed=legal_currency_confirmed,current_until=current_until,rationale=rationale,source=source)
            aid=new_id('wiki_attest')
            self._append_decision(db,'attestation',
                (aid,policy_id,source_id,old['id'] if old else None,version,digest(source),canonical(payload),digest(payload),actor,now_iso()))
            db.execute('INSERT INTO pol_wiki_attestation_heads VALUES(?,?,?,?) ON CONFLICT(policy_id,source_id) DO UPDATE SET decision_id=excluded.decision_id,version=excluded.version',(policy_id,source_id,aid,version))
            result={'attestation_id':aid,'source_id':source_id,'version':version,'source_manifest_hash':digest(source)}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_source','source_id':source_id}])
            return result

    def _review_manifest(self,db,actor,page):
        sources=[];blockers=[]
        if page['lifecycle']!='active': blockers.append('page_archived')
        for sid in sorted({r['source_id'] for r in page['evidence']}):
            source=self._source_fingerprint(db,actor,sid)
            attest=self._head(db,'attestation',(page['policy_id'],sid))
            if source['manifest']['gaps'] or source['extraction_quality']!='text_extracted': blockers.append('source_incomplete')
            if attest:
                payload=json.loads(attest['payload_json'])
                if digest(payload)!=attest['content_hash']: integrity()
                if attest['source_manifest_hash']!=digest(source): blockers.append('source_attestation_stale')
                if not payload['complete'] or not payload['legal_currency_confirmed']: blockers.append('source_not_verified')
                if datetime.fromisoformat(payload['current_until'])<=datetime.now(timezone.utc): blockers.append('currentness_unconfirmed')
                # A withdrawn reviewer cannot lend authority to a new release.
                try: _authority(db,attest['actor_id'],page['policy_id'],{sid},'attest')
                except CoreError: blockers.append('attestation_authority_revoked')
            else: blockers.append('source_attestation_required')
            source['attestation_id']=attest['id'] if attest else None
            sources.append(source)
        for ref in page['evidence']:
            match=next(s for s in sources if s['source_id']==ref['source_id'])
            if match['rendition_id']!=ref['rendition_id'] or match['extraction_id']!=ref['extraction_id']: blockers.append('evidence_version_changed')
        manifest={k:page[k] for k in ('page_id','revision_id','body_hash','content_hash','binding_hash','policy_id','version')}
        manifest.update(sources=sources,section_ids=page['section_ids'])
        from .serving import applicability_binding
        applicability=applicability_binding(db,page['revision_id'])
        # No null/default key is added to already committed M3 manifests.
        if applicability is not None:
            manifest['applicability']=applicability
            controls=[KnowledgeCatalog.source_control_ref(db,s['source_id']) for s in sources]
            manifest['upstream_source_refs']=[c['identity'] for c in controls]
            if any(not c['control_proof']['anchored'] for c in controls):
                blockers.append('upstream_source_control_unanchored')
            if any(c['gate'] and c['gate']['availability'] in {'unavailable','changed','superseded'} for c in controls):
                blockers.append('upstream_source_unavailable')
        return manifest,sorted(set(blockers))

    def _workbench(self,db,actor,page_id):
        page=self._candidate_read(db,actor,identifier(page_id))
        manifest,blockers=self._review_manifest(db,actor,page)
        review=self._head(db,'review',(page_id,));release=self._head(db,'release',(page_id,))
        mh=digest(manifest)
        current_review=bool(review and review['revision_id']==page['revision_id'] and review['manifest_hash']==mh)
        state=review['decision'] if current_review else 'awaiting_review'
        publication='not_published'
        if release:
            publication=release['decision']
            if publication=='published' and (not current_review or state!='approved' or blockers or release['review_id']!=review['id'] or release['manifest_hash']!=mh): publication='needs_review'
        sources={r['source_id'] for r in page['evidence']}
        permissions={}
        for cap in ('author','review','publish','attest'):
            try:
                if cap=='author': self._candidate_authorize(db,actor,page['policy_id'],page['evidence'])
                else: _authority(db,actor,page['policy_id'],sources,cap)
                permissions[cap]=True
            except CoreError: permissions[cap]=False
        buffer=db.execute('SELECT * FROM pol_wiki_editor_buffers WHERE account_id=? AND page_id=?',(actor,page_id)).fetchone()
        # M2's mechanical reader deliberately knows no release authority. Do
        # not expose its placeholder status beside the M3 governance decision.
        content={k:v for k,v in page.items() if k not in {'publication_state','freshness'}}
        result={'candidate':content,'review_manifest':manifest,'review_manifest_hash':mh,'blockers':blockers,
            'governance':{'review_state':state,'publication_state':publication,'review_event_id':review['id'] if review else None,
                          'release_event_id':release['id'] if release else None,'historical_release_state':release['decision'] if release else None},
            'permissions':permissions,'editor_buffer':dict(buffer) if buffer else None,
            'notice_vi':'AI chỉ soạn đề xuất. Chuyên gia rà nội dung và phát hành bằng hai quyết định riêng.'}
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='ks_wiki_applicability'").fetchone():
            from nmate.policy_v1.service import GOAL_LABELS
            from .serving import applicability_binding
            result['serving_scope']=dict(binding=applicability_binding(db,page['revision_id']),
                goal_options=[dict(id=k,label_vi=v) for k,v in GOAL_LABELS.items() if k!='unspecified'])
        return result

    def workbench(self,actor,page_id):
        with self.repo.connection() as db: return self._workbench(db,actor,page_id)

    def queue(self,actor):
        result=[]
        with self.repo.connection() as db:
            self._active(db,actor)
            for row in db.execute('SELECT page_id FROM kp_page_contracts'):
                try: view=self._workbench(db,actor,row[0])
                except CoreError as exc:
                    if exc.status_code in (403,404,409): continue
                    raise
                p=view['candidate']
                result.append({'page_id':p['page_id'],'title':p['title'],'policy_id':p['policy_id'],'revision_id':p['revision_id'],
                               'governance':view['governance'],'blockers':view['blockers'],'permissions':view['permissions']})
        return result

    def review_wiki(self,actor,page_id,*,expected_version,revision_id,expected_manifest_hash,approve,rationale,operation_id):
        request=dict(page_id=page_id,expected_version=expected_version,revision_id=revision_id,expected_manifest_hash=expected_manifest_hash,approve=approve,rationale=rationale)
        kind='knowledge.wiki.review/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            view=self._workbench(db,actor,identifier(page_id));p=view['candidate']
            _authority(db,actor,p['policy_id'],{r['source_id'] for r in p['evidence']},'review')
            version_precondition(expected_version);identifier(revision_id);text(rationale,'Căn cứ rà',8000)
            if type(approve) is not bool: raise CoreError('invalid_review','Cần chọn duyệt hoặc từ chối rõ ràng.')
            if expected_version!=p['version'] or revision_id!=p['revision_id'] or expected_manifest_hash!=view['review_manifest_hash']:
                raise CoreError('revision_conflict','Body/căn cứ đã đổi; giữ nháp để đối chiếu, chưa ghi quyết định.',409)
            if approve and view['blockers']: raise CoreError('source_not_reviewable','Còn thiếu căn cứ xác minh; chỉ có thể ghi từ chối và lý do.',409)
            old=self._head(db,'review',(page_id,));sequence=(old['sequence'] if old else 0)+1
            rid=new_id('wiki_review');decision='approved' if approve else 'rejected'
            self._append_decision(db,'review',
                (rid,page_id,revision_id,old['id'] if old else None,sequence,view['review_manifest_hash'],canonical(view['review_manifest']),decision,rationale,actor,now_iso()))
            db.execute('INSERT INTO pol_wiki_review_heads VALUES(?,?,?) ON CONFLICT(page_id) DO UPDATE SET decision_id=excluded.decision_id,sequence=excluded.sequence',(page_id,rid,sequence))
            self._fault('after_review_before_receipt')
            result={'review_event_id':rid,'revision_id':revision_id,'review_state':decision,'review_manifest_hash':view['review_manifest_hash']}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_candidate','page_id':page_id,'revision_id':revision_id}])
            return result

    def publish_wiki(self,actor,page_id,*,revision_id,review_event_id,expected_manifest_hash,rationale,operation_id):
        request=dict(page_id=page_id,revision_id=revision_id,review_event_id=review_event_id,expected_manifest_hash=expected_manifest_hash,rationale=rationale)
        kind='knowledge.wiki.publish/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            view=self._workbench(db,actor,identifier(page_id));p=view['candidate']
            sources={r['source_id'] for r in p['evidence']};_authority(db,actor,p['policy_id'],sources,'publish')
            identifier(revision_id);identifier(review_event_id);text(rationale,'Căn cứ phát hành',8000)
            review=self._head(db,'review',(page_id,))
            if (not review or review['id']!=review_event_id or review['decision']!='approved' or revision_id!=p['revision_id'] or
                review['revision_id']!=revision_id or expected_manifest_hash!=view['review_manifest_hash'] or review['manifest_hash']!=expected_manifest_hash or view['blockers']):
                raise CoreError('review_required','Cần đúng bản/căn cứ đã rà còn hiệu lực; chưa phát hành.',409)
            _authority(db,review['actor_id'],p['policy_id'],sources,'review')
            old=self._head(db,'release',(page_id,));sequence=(old['sequence'] if old else 0)+1
            release=new_id('wiki_release')
            self._append_decision(db,'release',
                (release,page_id,revision_id,old['id'] if old else None,sequence,review_event_id,expected_manifest_hash,'published',rationale,actor,now_iso()))
            db.execute('INSERT INTO pol_wiki_release_heads VALUES(?,?,?) ON CONFLICT(page_id) DO UPDATE SET decision_id=excluded.decision_id,sequence=excluded.sequence',(page_id,release,sequence))
            # Same durable outbox, no filesystem or model inside the command.
            self._event(db,actor,'wiki',page_id,revision_id,'wiki_published',{'release_event_id':release})
            self._fault('after_release_before_receipt')
            result={'release_event_id':release,'revision_id':revision_id,'review_event_id':review_event_id,'publication_state':'published','review_manifest_hash':expected_manifest_hash}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_candidate','page_id':page_id,'revision_id':revision_id}])
            return result

    def save_buffer(self,actor,page_id,*,base_revision_id,expected_ui_revision,payload,operation_id):
        request=dict(page_id=page_id,base_revision_id=base_revision_id,expected_ui_revision=expected_ui_revision,payload=payload)
        kind='knowledge.wiki.buffer/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            p=self._candidate_read(db,actor,identifier(page_id),identifier(base_revision_id))
            if type(expected_ui_revision) is not int or expected_ui_revision<0: raise CoreError('invalid_revision','Phiên bản nháp cần số nguyên không âm.')
            if not isinstance(payload,dict) or set(payload)!={'title','body','claims','aliases','links'}: raise CoreError('invalid_editor_buffer','Nháp khác hợp đồng editor.')
            text(payload['title'],'Tiêu đề',800);text(payload['body'],'Nội dung nháp',100000,empty=True)
            if len(canonical(payload).encode())>150000: raise CoreError('input_limit','Nháp quá dài.')
            current=db.execute('SELECT ui_revision FROM pol_wiki_editor_buffers WHERE account_id=? AND page_id=?',(actor,page_id)).fetchone()
            if expected_ui_revision!=(current[0] if current else 0): raise CoreError('editor_conflict','Nháp đã thay ở nơi khác; giữ bản đang gõ và mở đối chiếu.',409)
            new=expected_ui_revision+1
            db.execute('INSERT INTO pol_wiki_editor_buffers VALUES(?,?,?,?,?,?) ON CONFLICT(account_id,page_id) DO UPDATE SET base_revision_id=excluded.base_revision_id,ui_revision=excluded.ui_revision,payload_json=excluded.payload_json,updated_at=excluded.updated_at',
                (actor,page_id,base_revision_id,new,canonical(payload),now_iso()))
            result={'page_id':page_id,'base_revision_id':base_revision_id,'ui_revision':new,'saved':True}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_candidate','page_id':page_id,'revision_id':base_revision_id}])
            return result

    def revision_diff(self,actor,page_id,left_revision,right_revision):
        with self.repo.connection() as db:
            left=self._candidate_read(db,actor,identifier(page_id),identifier(left_revision));right=self._candidate_read(db,actor,page_id,identifier(right_revision))
            return {'left_revision':left_revision,'right_revision':right_revision,'diff':'\n'.join(difflib.unified_diff(left['body'].splitlines(),right['body'].splitlines(),lineterm=''))}

    def apply_proposal(self,gateway,actor,proposal_id,*,operation_id):
        from .ai_proposals import read_proposal
        proposal=read_proposal(self,gateway,actor,proposal_id)
        request={'proposal_id':proposal_id};kind='knowledge.wiki.proposal.apply/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            if db.execute('SELECT 1 FROM pol_wiki_proposal_applications WHERE proposal_id=?',(proposal_id,)).fetchone():
                raise CoreError('proposal_already_applied','Đề xuất đã chuyển thành nháp wiki; mở bản đó để tiếp tục.',409)
            payload=proposal['payload']['candidate']|{'policy_id':proposal['policy_id']}
            page=self._create_candidate_in(db,actor,payload,'apply-'+proposal_id)
            db.execute('INSERT INTO pol_wiki_proposal_applications VALUES(?,?,?,?,?)',(proposal_id,page['page_id'],page['revision_id'],actor,now_iso()))
            self._fault('after_proposal_apply_before_receipt')
            self._save(db,actor,kind,operation_id,request,hashed,page,[{'kind':'pipeline_candidate','page_id':page['page_id'],'revision_id':page['revision_id']}])
            return page

    def withdraw_wiki(self,actor,page_id,*,expected_release_id,rationale,operation_id):
        request=dict(page_id=page_id,expected_release_id=expected_release_id,rationale=rationale)
        kind='knowledge.wiki.withdraw/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            page=self._candidate_read(db,actor,identifier(page_id))
            _authority(db,actor,page['policy_id'],{r['source_id'] for r in page['evidence']},'publish')
            old=self._head(db,'release',(page_id,));text(rationale,'Lý do ngừng phát hành',8000)
            if not old or old['id']!=expected_release_id or old['decision']!='published':
                raise CoreError('revision_conflict','Quyết định phát hành đã đổi; chưa ngừng bản khác.',409)
            rid=new_id('wiki_release')
            self._append_decision(db,'release',
                (rid,page_id,old['revision_id'],old['id'],old['sequence']+1,old['review_id'],old['manifest_hash'],'withdrawn',rationale,actor,now_iso()))
            db.execute('UPDATE pol_wiki_release_heads SET decision_id=?,sequence=? WHERE page_id=?',(rid,old['sequence']+1,page_id))
            self._event(db,actor,'wiki',page_id,page['revision_id'],'wiki_withdrawn',{'release_event_id':rid})
            result={'release_event_id':rid,'publication_state':'withdrawn'}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_candidate','page_id':page_id,'revision_id':old['revision_id']}])
            return result
