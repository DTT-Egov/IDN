"""M3 tools reuse v03 authenticated call context; no paid job/budget tool."""
from pydantic import StrictInt,StrictBool
from typing import Any
from nmate.v03.mcp import Identifier,Operation,Result

NAMES={'knowledge_wiki_queue','knowledge_wiki_workbench','knowledge_wiki_review','knowledge_wiki_publish',
       'knowledge_wiki_withdraw','knowledge_wiki_buffer','knowledge_wiki_diff','knowledge_wiki_proposals',
       'knowledge_wiki_proposal','knowledge_wiki_apply_proposal','knowledge_wiki_attest'}

def register_tools(server,service,call,gateway):
    @server.tool(structured_output=True,description='Hàng đợi wiki được phép; không gọi AI.')
    async def knowledge_wiki_queue()->Result:
        return await call(lambda actor:service.queue(actor))

    @server.tool(structured_output=True,description='Bản wiki, căn cứ và trạng thái rà/phát hành hiện hành; không gọi AI.')
    async def knowledge_wiki_workbench(page_id:Identifier)->Result:
        return await call(lambda actor:service.workbench(actor,page_id))

    @server.tool(structured_output=True,description='Chuyên gia ghi quyết định rà đúng revision/manifest, chưa phát hành.')
    async def knowledge_wiki_review(page_id:Identifier,expected_version:StrictInt,revision_id:Identifier,expected_manifest_hash:str,approve:StrictBool,rationale:str,operation_id:Operation)->Result:
        return await call(lambda actor:service.review_wiki(actor,page_id,expected_version=expected_version,revision_id=revision_id,
            expected_manifest_hash=expected_manifest_hash,approve=approve,rationale=rationale,operation_id=operation_id))

    @server.tool(structured_output=True,description='Phát hành riêng bản đã rà đúng căn cứ/scope. Không mở assessment M4.')
    async def knowledge_wiki_publish(page_id:Identifier,revision_id:Identifier,review_event_id:Identifier,expected_manifest_hash:str,rationale:str,operation_id:Operation)->Result:
        return await call(lambda actor:service.publish_wiki(actor,page_id,revision_id=revision_id,review_event_id=review_event_id,
            expected_manifest_hash=expected_manifest_hash,rationale=rationale,operation_id=operation_id))

    @server.tool(structured_output=True,description='Ngừng phát hành đúng release hiện tại, giữ lịch sử.')
    async def knowledge_wiki_withdraw(page_id:Identifier,expected_release_id:Identifier,rationale:str,operation_id:Operation)->Result:
        return await call(lambda actor:service.withdraw_wiki(actor,page_id,expected_release_id=expected_release_id,rationale=rationale,operation_id=operation_id))

    @server.tool(structured_output=True,description='Giữ nháp cá nhân qua CAS; không sửa bản wiki chuẩn.')
    async def knowledge_wiki_buffer(page_id:Identifier,base_revision_id:Identifier,expected_ui_revision:StrictInt,payload:dict[str,Any],operation_id:Operation)->Result:
        return await call(lambda actor:service.save_buffer(actor,page_id,base_revision_id=base_revision_id,expected_ui_revision=expected_ui_revision,payload=payload,operation_id=operation_id))

    @server.tool(structured_output=True,description='Diff hai bản được phép; không gọi AI.')
    async def knowledge_wiki_diff(page_id:Identifier,left_revision:Identifier,right_revision:Identifier)->Result:
        return await call(lambda actor:service.revision_diff(actor,page_id,left_revision,right_revision))

    @server.tool(structured_output=True,description='Đọc các đề xuất AI đã lưu của chính người được giao; chưa phải quyết định chuyên gia.')
    async def knowledge_wiki_proposals()->Result:
        def read(actor):
            from .ai_proposals import read_proposal
            with service.repo.connection() as db: rows=db.execute('SELECT id FROM pol_wiki_ai_proposals WHERE assignee_id=?',(actor,)).fetchall()
            return [read_proposal(service,gateway,actor,r[0]) for r in rows]
        return await call(read)

    @server.tool(structured_output=True,description='Đọc đề xuất theo current READ; không chạy AI lại.')
    async def knowledge_wiki_proposal(proposal_id:Identifier)->Result:
        from .ai_proposals import read_proposal
        return await call(lambda actor:read_proposal(service,gateway,actor,proposal_id))

    @server.tool(structured_output=True,description='Người có quyền chuyển đề xuất thành wiki nháp, chưa rà/phát hành.')
    async def knowledge_wiki_apply_proposal(proposal_id:Identifier,operation_id:Operation)->Result:
        return await call(lambda actor:service.apply_proposal(gateway,actor,proposal_id,operation_id=operation_id))

    @server.tool(structured_output=True,description='Chuyên gia xác minh nguồn đúng snapshot/phiên bản và thời hạn; không tự coi PDF đủ là luật hiện hành.')
    async def knowledge_wiki_attest(policy_id:Identifier,source_id:Identifier,expected_source_version:StrictInt,complete:StrictBool,legal_currency_confirmed:StrictBool,current_until:str,rationale:str,operation_id:Operation)->Result:
        return await call(lambda actor:service.attest_source(actor,policy_id,source_id,expected_source_version=expected_source_version,
            complete=complete,legal_currency_confirmed=legal_currency_confirmed,current_until=current_until,rationale=rationale,operation_id=operation_id))
