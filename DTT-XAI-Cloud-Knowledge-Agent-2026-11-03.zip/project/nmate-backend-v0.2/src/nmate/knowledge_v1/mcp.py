"""Opt-in adapter to the existing authenticated MCP `call` port.

Never registered by the main app at M2. No caller actor, enterprise bypass,
arbitrary filesystem path, SQL, model transport, or new consent/budget logic.
"""
import asyncio
import base64
import binascii
from typing import Annotated,Any
from pydantic import Field,StrictInt
from nmate.v03.core import CoreError
from nmate.v03.mcp import Identifier,Operation,Result
from .local_parser import MAX_BYTES


def register_tools(server,service,call):
    @server.tool(structured_output=True,description='Đọc cấu hình nguồn công khai được phép; không tải lại hoặc gọi AI.')
    async def knowledge_source(source_id:Identifier)->Result:
        return await call(lambda actor:service.source_manifest(actor,source_id))

    @server.tool(structured_output=True,description='Curator cấu hình nguồn công khai đã có và quyền explicit. Chỉ nhập cục bộ; không bật mạng/lịch.')
    async def knowledge_configure(source_id:Identifier,expected_version:StrictInt,manifest:dict[str,Any],operation_id:Operation)->Result:
        return await call(lambda actor:service.configure_source(actor,source_id,expected_version=expected_version,manifest=manifest,operation_id=operation_id))

    @server.tool(structured_output=True,description='Nhập bản tệp công khai được phép; lưu nguyên bytes/observation/receipt trước trích chữ, không AI.')
    async def knowledge_acquire(source_id:Identifier,expected_version:StrictInt,filename:Annotated[str,Field(max_length=240)],
                                mime_type:str,data_base64:Annotated[str,Field(max_length=6990512)],operation_id:Operation)->Result:
        def run(actor):
            if len(data_base64)>((MAX_BYTES+2)//3)*4: raise CoreError('source_size_limit','Tệp nguồn quá lớn.')
            try: raw=base64.b64decode(data_base64,validate=True)
            except (ValueError,binascii.Error) as exc: raise CoreError('invalid_source_bytes','Dữ liệu tệp mã hóa chưa hợp lệ.') from exc
            return service.acquire_bytes(actor,source_id,expected_version=expected_version,filename=filename,mime_type=mime_type,raw=raw,operation_id=operation_id)
        return await call(run)

    @server.tool(structured_output=True,description='Trích chữ cục bộ từ bản tệp đã lưu. Không OCR/AI, không tự tải lại; phục hồi bằng operation gốc.')
    async def knowledge_extract(rendition_id:Identifier,operation_id:Operation)->Result:
        async def run(actor): return await asyncio.to_thread(service.extract_local,actor,rendition_id,operation_id=operation_id)
        return await call(run)

    @server.tool(structured_output=True,description='Đọc kết quả trích chữ đã lưu và tên tệp lỗi; không parse/model lại.')
    async def knowledge_extraction(extraction_id:Identifier)->Result:
        return await call(lambda actor:service.get_extraction(actor,extraction_id))

    @server.tool(structured_output=True,description='Tạo ref có kiểu tới đúng vị trí câu trích và phiên bản nguồn công khai.')
    async def knowledge_evidence(chunk_id:Identifier,quote:Annotated[str,Field(max_length=64000)],quote_start:StrictInt|None=None)->Result:
        return await call(lambda actor:service.pipeline_evidence(actor,chunk_id,quote,quote_start=quote_start))

    @server.tool(structured_output=True,description='Tạo wiki candidate với từng section/claim gắn nguồn. Không duyệt/phát hành/SSOT/AI.')
    async def knowledge_candidate_create(policy_id:Identifier,title:str,body:str,claims:list[dict[str,Any]],aliases:list[str],links:list[dict[str,str]],operation_id:Operation)->Result:
        return await call(lambda actor:service.create_candidate(actor,policy_id=policy_id,title=title,body=body,claims=claims,aliases=aliases,links=links,operation_id=operation_id))

    @server.tool(structured_output=True,description='Sửa candidate qua CAS, giữ bản cũ và nháp xung đột; không phát hành.')
    async def knowledge_candidate_edit(page_id:Identifier,expected_version:StrictInt,expected_revision_id:Identifier,title:str,body:str,
                                      claims:list[dict[str,Any]],aliases:list[str],links:list[dict[str,str]],operation_id:Operation)->Result:
        return await call(lambda actor:service.edit_candidate(actor,page_id,expected_version=expected_version,expected_revision_id=expected_revision_id,
            title=title,body=body,claims=claims,aliases=aliases,links=links,operation_id=operation_id))

    @server.tool(structured_output=True,description='Đọc candidate đúng revision, kiểm quyền nguồn hiện hành và độ mới; chưa dùng tư vấn điều kiện.')
    async def knowledge_candidate(page_id:Identifier,revision_id:Identifier|None=None)->Result:
        return await call(lambda actor:service.get_candidate(actor,page_id,revision_id=revision_id))

    @server.tool(structured_output=True,description='Tìm wiki công khai nháp được phép bằng FTS/alias; index không cấp quyền, không AI.')
    async def knowledge_search(query:Annotated[str,Field(max_length=500)],limit:StrictInt=10)->Result:
        return await call(lambda actor:{'items':service.search(actor,query,limit=limit)})

    @server.tool(structured_output=True,description='Đọc nguyên bản công khai theo quyền xuất hiện hành; không tự tải nguồn.')
    async def knowledge_original(rendition_id:Identifier)->Result:
        def run(actor):
            value=service.read_original(actor,rendition_id)
            raw=value.pop('raw_bytes'); value['data_base64']=base64.b64encode(raw).decode('ascii')
            return value
        return await call(run)

    @server.tool(structured_output=True,description='Xuất Markdown projection từ SQL; file không là authority hay approval. Kiểm READ/export hiện hành.')
    async def knowledge_export(page_id:Identifier)->Result:
        return await call(lambda actor:service.export_markdown(actor,page_id))

    @server.tool(structured_output=True,description='Đối chiếu hai phiên bản trích xuất cùng nguồn, không AI.')
    async def knowledge_diff(left_id:Identifier,right_id:Identifier)->Result:
        return await call(lambda actor:service.source_diff(actor,left_id,right_id))

    @server.tool(structured_output=True,description='Đọc backlink điều hướng qua quyền hai đầu; không diễn giải thành quan hệ pháp luật.')
    async def knowledge_backlinks(page_id:Identifier)->Result:
        return await call(lambda actor:{'items':service.backlinks(actor,page_id)})
