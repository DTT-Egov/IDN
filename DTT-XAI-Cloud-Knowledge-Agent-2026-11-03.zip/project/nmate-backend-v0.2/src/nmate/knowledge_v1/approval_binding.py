"""Exclusive local approval→DB delegation binding, never a spending ledger.

Money/counting/dispatch remain solely in ModelGateway SQL. This guard narrows a
single human approval to one database instance across operator restarts/copies.
"""
from pathlib import Path
import json,os,tempfile
from datetime import datetime,timedelta,timezone
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.v03.core import CoreError,now_iso

def _read(path):
    try:
        if Path(path).is_symlink(): raise ValueError()
        value=json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(value,dict) or value.get('record_hash')!=digest({k:v for k,v in value.items() if k!='record_hash'}): raise ValueError()
        return value
    except (OSError,ValueError,TypeError): raise CoreError('APPROVAL_BINDING_INTEGRITY','Biên nhận ràng buộc hạn mức bị thiếu/hỏng; cần đối soát, chưa cấp hoặc gửi AI.',409) from None

def _publish(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    if any(p.is_symlink() or getattr(p,'is_junction',lambda:False)() for p in (path.parent,*path.parent.parents)):
        raise CoreError('APPROVAL_BINDING_INTEGRITY','Thư mục ràng buộc không được là liên kết.',409)
    data=dict(value,record_hash=digest(value))
    fd,name=tempfile.mkstemp(prefix='.approval-pending-',dir=path.parent)
    temporary=Path(name)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(canonical(data).encode('utf-8'));f.flush();os.fsync(f.fileno())
        try: os.link(temporary,path)  # Atomic, exclusive; never overwrite.
        except FileExistsError: pass
    finally: temporary.unlink(missing_ok=True)
    return _read(path)

def identity(prepared):
    return dict(approval_id=prepared['approval_id'],database_path=os.path.normcase(str(Path(prepared['database']).resolve(strict=True))),
        batch_instance_id=prepared['batch_instance_id'],account_id=prepared['account_id'],
        scope_id='public_domain:hanoi_policy:HN-DIGITAL-CONSULTING-2026',corpus_hash=prepared['corpus_hash'])

def paths(root,approval):
    # Approval is server-owned and already validated; not a browser path.
    if not isinstance(approval,str) or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_' for c in approval):
        raise CoreError('APPROVAL_CONFLICT','Mã phê duyệt chưa hợp lệ.',409)
    return Path(root)/(approval+'-claim.json'),Path(root)/(approval+'-issued.json')

def claim(root,prepared,expires_at):
    expected=identity(prepared);path,_=paths(root,expected['approval_id'])
    if path.exists(): value=_read(path)
    else:
        now=datetime.now(timezone.utc);until=datetime.fromisoformat(expires_at)
        if until.tzinfo is None or not now<until<=now+timedelta(hours=48): raise CoreError('APPROVAL_CONFLICT','Thời hạn vượt cửa 48 giờ hoặc đã hết.',409)
        value=_publish(path,dict(schema_version='knowledge-batch-approval-binding/1',**expected,claimed_at=now.isoformat(),expires_at=expires_at))
    if any(value.get(k)!=v for k,v in expected.items()):
        raise CoreError('APPROVAL_ALREADY_BOUND','Phê duyệt này đã gắn với một kho khác; không cấp thêm hoặc chuyển hạn mức.',409)
    _validate_window(value)
    return value

def _validate_window(value):
    try:
        if value['schema_version']!='knowledge-batch-approval-binding/1': raise ValueError()
        start=datetime.fromisoformat(value['claimed_at']);end=datetime.fromisoformat(value['expires_at'])
        if start.tzinfo is None or end.tzinfo is None or not timedelta(0)<end-start<=timedelta(hours=48): raise ValueError()
    except (KeyError,TypeError,ValueError): raise CoreError('APPROVAL_BINDING_INTEGRITY','Cửa hiệu lực claim khác phê duyệt 48 giờ; cần đối soát.',409) from None

def verify_claim(root,prepared):
    expected=identity(prepared);path,_=paths(root,expected['approval_id']);value=_read(path)
    if value.get('schema_version')!='knowledge-batch-approval-binding/1' or any(value.get(k)!=v for k,v in expected.items()):
        raise CoreError('APPROVAL_ALREADY_BOUND','Kho/instance/phạm vi khác biên nhận cấp; chưa gửi AI.',409)
    _validate_window(value)
    return value

def finalized(root,prepared,claim_value):
    _,path=paths(root,prepared['approval_id'])
    if not path.exists(): return None
    value=_read(path)
    if value.get('schema_version')!='knowledge-batch-grant-binding/1' or value.get('claim_hash')!=claim_value['record_hash']:
        raise CoreError('APPROVAL_BINDING_INTEGRITY','Biên nhận hoàn tất khác claim gốc.',409)
    return value

def finalize(root,prepared,claim_value,grant_id,terms):
    _,path=paths(root,prepared['approval_id'])
    expected=dict(schema_version='knowledge-batch-grant-binding/1',claim_hash=claim_value['record_hash'],grant_id=grant_id,terms_hash=digest(terms))
    old=finalized(root,prepared,claim_value)
    if old is None: old=_publish(path,dict(**expected,recorded_at=now_iso()))
    if any(old.get(k)!=v for k,v in expected.items()): raise CoreError('APPROVAL_BINDING_INTEGRITY','Grant khác biên nhận hoàn tất; dừng đối soát.',409)
    return old

def verify_dispatch(db,repo,spec,grant):
    """Sealed delegation is checked by Gateway at reservation and fence too."""
    proof=spec['invocation'].get('issuance_binding')
    if proof is None: return  # Other explicitly authorized operator grant kinds.
    try:
        instance=db.execute('SELECT * FROM pol_wiki_batch_instances WHERE id=?',(proof['batch_instance_id'],)).fetchone()
        if (instance is None or instance['record_hash']!=digest({k:instance[k] for k in instance.keys() if k!='record_hash'}) or
            instance['approval_id']!=grant['approval_id'] or instance['scope_id']!=grant['scope_id'] or instance['account_id']!=grant['account_id'] or
            instance['corpus_hash']!=digest(spec['corpus_refs'])): raise ValueError()
        prepared=dict(approval_id=grant['approval_id'],database=repo.db_path,batch_instance_id=instance['id'],
                      account_id=grant['account_id'],corpus_hash=instance['corpus_hash'])
        claimed=verify_claim(proof['registry_dir'],prepared)
        complete=finalized(proof['registry_dir'],prepared,claimed)
        if (proof['claim_hash']!=claimed['record_hash'] or proof['database_path']!=claimed['database_path'] or
            datetime.fromisoformat(grant['expires_at'])!=datetime.fromisoformat(claimed['expires_at']) or not complete or complete['grant_id']!=grant['id']): raise ValueError()
    except (KeyError,TypeError,ValueError): raise CoreError('APPROVAL_BINDING_INTEGRITY','Grant không gắn đúng kho/claim đã hoàn tất; chưa gửi AI.',409) from None
