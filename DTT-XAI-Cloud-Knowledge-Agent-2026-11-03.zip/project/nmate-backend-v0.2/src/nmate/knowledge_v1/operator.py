"""Opt-in schema operator; never called by app construction or a READ tool."""
from contextlib import closing
from functools import lru_cache
import sqlite3

from nmate.core_v1.runtime_schema import schema_objects
from nmate.core_v1.schema_lifecycle import create_plan, apply_plan
from nmate.v03.core import CoreError
from .schema import M1_STATEMENTS


@lru_cache(maxsize=1)
def expected_objects():
    with closing(sqlite3.connect(':memory:')) as db:
        for sql in M1_STATEMENTS:
            db.execute(sql)
        return schema_objects(db)


def require_schema(db):
    required = {r['name']: r for r in expected_objects()}
    actual = {r['name']: r for r in schema_objects(db) if r['name'].startswith('kp_')}
    from .operator_m2 import expected_m2_objects
    m2_required = {r['name']: r for r in expected_m2_objects()}
    if actual not in (required, m2_required):
        raise CoreError('knowledge_schema_not_ready',
                        'Schema kho tri thức chưa khởi tạo hoặc khác hợp đồng; cần operator kiểm bản sao.', 409)


def install_on_clone(database, *, backup_path):
    """Explicit migration over a caller-chosen offline DB; not an HTTP capability.

    Reuses the existing operator receipt/lock/backup/DDL authority. Tests and
    rehearsal invoke this function; no automatic invocation in runtime.
    """
    from pathlib import Path
    source = Path(__file__).resolve().parents[2]
    files = ['nmate/knowledge_v1/schema.py', 'nmate/knowledge_v1/operator.py']
    plan = create_plan(database, version='knowledge-m1-20261026', statements=M1_STATEMENTS,
                       source_root=source, dependency_files=files)
    # Validate the target before mutation, not merely after a durable commit.
    # This prevents a successful operator receipt followed by an avoidable
    # runtime rejection (DF-049). Small synthetic catalog fixtures use only the
    # knowledge contract; a whole-main baseline must also satisfy V17 exactly.
    from nmate.core_v1.runtime_schema import open_readonly, verify_runtime_database
    with closing(open_readonly(database)) as original, closing(sqlite3.connect(':memory:')) as prepared:
        if original.execute("SELECT 1 FROM sqlite_master WHERE name='v04_conversations'").fetchone():
            verify_runtime_database(database)
        original.backup(prepared)
        for statement in M1_STATEMENTS:
            prepared.execute(statement)
        require_schema(prepared)
    receipt = apply_plan(database, plan, source_root=source, backup_path=backup_path)
    with closing(sqlite3.connect(database)) as db:
        require_schema(db)
    return {'plan': plan, 'receipt': receipt}


def target_runtime_contract():
    """Separate candidate contract; the app's active V17 default is untouched."""
    from nmate.core_v1.runtime_schema import read_runtime_contract
    contract = read_runtime_contract()
    contract['version'] = 'nmate-main-20261026-knowledge-m1'
    contract['required_objects'] = sorted(contract['required_objects'] + expected_objects(),
                                          key=lambda item: (item['type'], item['name']))
    return contract


def open_runtime(database, *, contract_path):
    """Verify whole target before opening a non-initializing repository adapter."""
    from pathlib import Path
    from nmate.core_v1.runtime_schema import verify_runtime_database
    from nmate.v03.core import CoreRepository
    from .service import KnowledgeService
    verify_runtime_database(database, contract_path=contract_path)

    class ExistingRepository(CoreRepository):
        # Reuse the common connection/UoW port, but deliberately do not call
        # the bootstrap constructor. This adapter never creates DDL or seeds.
        def __init__(self, path):
            self.db_path = str(Path(path).resolve(strict=True))
            self.managed_runtime = True
            self._memory_anchor = None
            self._uri = False

    return KnowledgeService(ExistingRepository(database))
