"""Additive M2 only. No startup DDL or modification of M1/legacy records."""
M2_TABLES = [
    """CREATE TABLE kp_page_contracts (
 page_id TEXT PRIMARY KEY REFERENCES kp_wiki_pages(id),
 contract_kind TEXT NOT NULL CHECK(contract_kind='knowledge-candidate/1'))""",
    """CREATE TABLE kp_source_manifests (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id), previous_id TEXT,
 payload_json TEXT NOT NULL, content_hash TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 created_at TEXT NOT NULL, UNIQUE(source_id,id), UNIQUE(source_id,previous_id),
 FOREIGN KEY(source_id,previous_id) REFERENCES kp_source_manifests(source_id,id))""",
    """CREATE TABLE kp_source_state (
 source_id TEXT PRIMARY KEY REFERENCES pol_sources(id), manifest_id TEXT NOT NULL,
 version INTEGER NOT NULL CHECK(version>0), observation_id TEXT, event_head_id TEXT,
 FOREIGN KEY(source_id,manifest_id) REFERENCES kp_source_manifests(source_id,id),
 FOREIGN KEY(source_id,observation_id) REFERENCES kp_acquisition_observations(source_id,id),
 FOREIGN KEY(source_id,event_head_id) REFERENCES kp_knowledge_events(target_id,id))""",
    """CREATE TABLE kp_renditions (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id), manifest_id TEXT NOT NULL,
 raw_bytes BLOB NOT NULL, raw_hash TEXT NOT NULL, mime_type TEXT NOT NULL, filename TEXT NOT NULL,
 created_at TEXT NOT NULL, UNIQUE(source_id,id),
 FOREIGN KEY(source_id,manifest_id) REFERENCES kp_source_manifests(source_id,id))""",
    """CREATE TABLE kp_acquisition_observations (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id), rendition_id TEXT NOT NULL,
 previous_id TEXT, manifest_id TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 observed_at TEXT NOT NULL, UNIQUE(source_id,id), UNIQUE(source_id,previous_id),
 FOREIGN KEY(source_id,rendition_id) REFERENCES kp_renditions(source_id,id),
 FOREIGN KEY(source_id,manifest_id) REFERENCES kp_source_manifests(source_id,id),
 FOREIGN KEY(source_id,previous_id) REFERENCES kp_acquisition_observations(source_id,id))""",
    """CREATE TABLE kp_extractions (
 id TEXT PRIMARY KEY, rendition_id TEXT NOT NULL REFERENCES kp_renditions(id), parser_version TEXT NOT NULL,
 quality TEXT NOT NULL CHECK(quality IN ('text_extracted','source_incomplete','failed')),
 payload_json TEXT NOT NULL, content_hash TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 created_at TEXT NOT NULL, UNIQUE(rendition_id,parser_version))""",
    """CREATE TABLE kp_extraction_chunks (
 id TEXT PRIMARY KEY, extraction_id TEXT NOT NULL REFERENCES kp_extractions(id),
 ordinal INTEGER NOT NULL CHECK(ordinal>=0), text TEXT NOT NULL, locator_json TEXT NOT NULL,
 content_hash TEXT NOT NULL, UNIQUE(extraction_id,ordinal))""",
    """CREATE TABLE kp_candidate_bindings (
 revision_id TEXT PRIMARY KEY REFERENCES kp_wiki_revisions(id), body_hash TEXT NOT NULL,
 payload_json TEXT NOT NULL, content_hash TEXT NOT NULL)""",
    """CREATE TABLE kp_navigation_links (
 revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id), relation TEXT NOT NULL CHECK(relation IN ('related_topic','see_also')),
 target_page_id TEXT NOT NULL, target_revision_id TEXT NOT NULL,
 PRIMARY KEY(revision_id,relation,target_page_id,target_revision_id),
 FOREIGN KEY(target_page_id,target_revision_id) REFERENCES kp_wiki_revisions(page_id,id))""",
    """CREATE TABLE kp_search_documents (
 page_id TEXT PRIMARY KEY REFERENCES kp_wiki_pages(id), revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),
 projection_hash TEXT NOT NULL)""",
    """CREATE TABLE kp_export_manifests (
 page_id TEXT PRIMARY KEY REFERENCES kp_wiki_pages(id), revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),
 export_hash TEXT NOT NULL, event_id TEXT NOT NULL REFERENCES kp_knowledge_events(id))""",
    'CREATE INDEX kp_extraction_by_rendition ON kp_extractions(rendition_id,parser_version)',
    'CREATE INDEX kp_rendition_by_source ON kp_renditions(source_id)',
]
TRIGGERS_M2 = {}
for table in ('kp_page_contracts','kp_source_manifests','kp_renditions','kp_acquisition_observations','kp_extractions',
              'kp_extraction_chunks','kp_candidate_bindings','kp_navigation_links'):
    for action in ('UPDATE','DELETE'):
        name = table + ('_immutable' if action == 'UPDATE' else '_no_delete')
        TRIGGERS_M2[name] = (table, f"CREATE TRIGGER {name} BEFORE {action} ON {table} "
                            "BEGIN SELECT RAISE(ABORT,'immutable knowledge pipeline record'); END;")
M2_STATEMENTS = M2_TABLES + [value[1] for value in TRIGGERS_M2.values()]
