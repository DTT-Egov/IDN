"""Opt-in authenticated testing tools, no paid calls or budget capabilities."""

from nmate.v03.mcp import Identifier, Operation, Result
from typing import Any

NAMES = {
    "knowledge_simulation_bundle",
    "knowledge_simulation_review",
    "knowledge_simulation_status",
    "knowledge_simulation_release",
}


def register_tools(server, service, call):
    @server.tool(
        structured_output=True,
        description="Đọc gói bàn giao review mô phỏng và các tệp hướng dẫn; không gọi AI.",
    )
    async def knowledge_simulation_bundle(proposal_ids: list[Identifier]) -> Result:
        return await call(
            lambda actor: dict(
                bundle=service.bundle(actor, proposal_ids), files=service.files(actor, proposal_ids)
            )
        )

    @server.tool(
        structured_output=True,
        description="Nộp review mô phỏng đúng hash; không phải duyệt chuyên gia hay phát hành thật.",
    )
    async def knowledge_simulation_review(
        proposal_ids: list[Identifier], result: dict[str, Any], operation_id: Operation
    ) -> Result:
        return await call(lambda actor: service.submit(actor, proposal_ids, result, operation_id))

    @server.tool(
        structured_output=True,
        description="Đọc biên nhận review mô phỏng theo quyền hiện hành; không gọi AI.",
    )
    async def knowledge_simulation_status(operation_id: Operation) -> Result:
        return await call(lambda actor: service.status(actor, operation_id))

    @server.tool(
        structured_output=True,
        description="Phát hành sandbox riêng sau review mô phỏng; không vào kho tư vấn thật.",
    )
    async def knowledge_simulation_release(review_operation_id: Operation, operation_id: Operation) -> Result:
        return await call(lambda actor: service.release(actor, review_operation_id, operation_id))
