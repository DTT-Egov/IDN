"""Finite public-corpus worker; SQL ledger is the only checkpoint authority.

No daemon, auto-resume, new transport, budget issuance, schema, expert decision
or publication. Human resume is a separate explicit local operator command.
"""
from datetime import datetime,timezone
from pathlib import Path
import argparse,asyncio,json
from nmate.v03.core import CoreError,new_id,now_iso
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.core_v1.domain_gateway import DomainAuthority,PublicDomainScope,SLOTS
from nmate.core_v1.gateway import ModelGateway
from nmate.main.runtime_lock import EnterpriseRuntimeLock
from . import public_batch as batch,approval_binding as binding
from .governance import WikiGovernance

def _load(directory):
    directory=Path(directory).resolve(strict=True)
    prepared=json.loads((directory/'prepared.json').read_text(encoding='utf8'))
    receipt=json.loads((directory/'grant-receipt.json').read_text(encoding='utf8'))
    repo=batch.existing_repository(prepared)
    claimed=binding.verify_claim(batch._APPROVAL_REGISTRY_DIR,prepared)
    complete=binding.finalized(batch._APPROVAL_REGISTRY_DIR,prepared,claimed)
    if not complete or complete['grant_id']!=receipt['id'] or complete['terms_hash']!=digest(batch.bound_terms(prepared,claimed)):
        raise CoreError('APPROVAL_BINDING_INTEGRITY','Worker không khớp kho/hạn mức gốc.',409)
    gateway=ModelGateway(repo,enabled=False)
    authority=DomainAuthority(gateway,WikiGovernance(repo),prepared['account_id'],PublicDomainScope('hanoi_policy',batch.POLICY),prepared['source_refs'],'policy-knowledge-draft/1','standard')
    return prepared,receipt,repo,authority

def _state(db,prepared,receipt,authority,*,export=False):
    authority._member(prepared['account_id'],authority.scope.key,db)
    authority._resolve(db,prepared['account_id'],prepared['source_refs'],export=export)
    spec=authority._scope_row(db,receipt['id'])
    grant=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=?',(receipt['id'],)).fetchone()
    binding.verify_dispatch(db,authority.repo,spec,grant)
    from .batch_lifecycle import read as read_lifecycle
    lifecycle=read_lifecycle(db,grant)
    attempts=[dict(r) for r in db.execute('SELECT id,task_id,state,validation_state,held_microusd,actual_microusd FROM core_domain_model_attempts WHERE grant_id=?',(grant['id'],))]
    proposals={r['attempt_id']:r['id'] for r in db.execute('SELECT attempt_id,id FROM pol_wiki_ai_proposals WHERE attempt_id IN (SELECT id FROM core_domain_model_attempts WHERE grant_id=?)',(grant['id'],))}
    pauses=[dict(r) for r in db.execute("SELECT id,attempt_id,detail_json FROM core_domain_model_events WHERE kind='batch_paused_admission' AND attempt_id IN (SELECT id FROM core_domain_model_attempts WHERE grant_id=?)",(grant['id'],))]
    pause_hash=lifecycle['pause_set_hash']
    by_slot={r['task_id']:r for r in attempts}
    if len(by_slot)!=len(attempts) or set(by_slot)-set(SLOTS):raise CoreError('WORKER_CHECKPOINT_INVALID','Checkpoint có slot không được duyệt.',409)
    complete=[s for s in SLOTS if s in by_slot and by_slot[s]['state']=='response_received' and by_slot[s]['validation_state']=='accepted' and by_slot[s]['id'] in proposals]
    from .ai_proposals import read_proposal
    for slot in complete:
        read_proposal(authority.source,authority.gateway,prepared['account_id'],proposals[by_slot[slot]['id']])
    blocked=[s for s in SLOTS if s in by_slot and s not in complete]
    remaining=[s for s in SLOTS if s not in by_slot]
    current=lifecycle['installed'] and grant['state']=='active' and grant['expires_at']>now_iso()
    from .independent_branch import current_permit
    permit=current_permit(lifecycle)
    permit_current=True
    next_slot=remaining[0] if current and not blocked and remaining else None
    if current and permit and remaining==['O2'] and blocked==['O1']:
        from .independent_branch import inputs,failure
        if digest(permit.get('inputs'))!=digest(inputs(db,authority,grant)) or permit.get('failed_result')!=failure(db,grant):
            raise CoreError('INDEPENDENT_CONTINUATION_NOT_ALLOWED','Đầu vào nhánh độc lập đã thay đổi.',409)
        from .review_binding import source_versions
        permit_current=digest(permit.get('source_versions'))==digest(source_versions(authority.source,db,authority.actor,authority.refs))
        next_slot='O2' if permit_current else None
    return dict(schema_version='knowledge-worker-checkpoint/1',grant_id=grant['id'],batch_instance_id=prepared['batch_instance_id'],
      corpus_hash=prepared['corpus_hash'],grant_state=grant['state'],expires_at=grant['expires_at'],pause_set_hash=pause_hash,
      completed_slots=complete,blocked_slots=blocked,remaining_slots=remaining,
      next_slot=next_slot,
      batch_completion='partially_complete' if not remaining and blocked else ('complete' if not remaining else 'incomplete'),
      independent_continuation=permit,
      independent_continuation_current=permit_current if permit else None,
      provider_calls=sum(r['state']!='cancelled_before_dispatch' for r in attempts),attempts=attempts,
      held_microusd=sum(r['held_microusd'] for r in attempts),known_estimated_microusd=sum(r['actual_microusd'] or 0 for r in attempts),
      cap_microusd=grant['cap_microusd'],max_calls=grant['max_calls'],proposal_count=len(proposals),
      operator_schema_ready=lifecycle['installed'],lifecycle_ref=lifecycle['ref'],
      automatic_resume=False,automatic_retry=False,publication_performed=False)

def snapshot(directory):
    prepared,receipt,repo,authority=_load(directory)
    with repo.connection() as db:
        return _state(db,prepared,receipt,authority)

async def run_once(directory,*,api_key='',request_fn=None,max_new_calls=1,env_file=None):
    if type(max_new_calls) is not int or not 1<=max_new_calls<=6:raise CoreError('INVALID_BATCH_LIMIT','Giới hạn worker phải từ1đến6lượt.')
    prepared,receipt,repo,authority=_load(directory)
    with EnterpriseRuntimeLock(repo.db_path):
        before=snapshot(directory)
        if before['blocked_slots'] and before['grant_state']=='active' and before['next_slot'] is None and before.get('remaining_slots'):
            for attempt in before['attempts']:
                if attempt['task_id'] in before['blocked_slots']:
                    batch.pause_after_failure(repo,receipt['id'],attempt['id'],operator=batch.OPERATOR,
                      reason='worker found incomplete checkpoint; no automatic recovery or dispatch')
            return dict(state='stopped_no_dispatch',before=before,after=snapshot(directory),results=[])
        if before['next_slot'] is None:
            return dict(state='stopped_no_dispatch',before=before,after=before,results=[])
        if env_file is not None and request_fn is None:
            from nmate.config import Settings
            settings=Settings(_env_file=env_file)
            if settings.model_provider!='anthropic' or not settings.model_configured:
                raise CoreError('MODEL_NOT_CONFIGURED','Claude chưa được cấu hình; chưa gửi lượt nào.',409)
            api_key=settings.anthropic_api_key.get_secret_value()
        try:
            results=await batch.execute(directory,api_key,max_new_calls=max_new_calls,request_fn=request_fn)
        except BaseException:
            # Persist an interruption even if the SDK/kernel already stored its
            # unknown result. Never infer a retry from a missing output file.
            with repo.connection() as db:
                new=[r['id'] for r in db.execute('SELECT id FROM core_domain_model_attempts WHERE grant_id=?',(receipt['id'],)) if r['id'] not in {a['id'] for a in before['attempts']}]
            for attempt in new:batch.pause_after_failure(repo,receipt['id'],attempt,operator=batch.OPERATOR,reason='worker interrupted; operator reconciliation required')
            raise
        return dict(state='bounded_run_finished',before=before,after=snapshot(directory),results=results)

def resume(directory,decision):
    """Explicit operator receipt, tested offline; never called by READ/run/UI.

    This function accepts the human decision already obtained by the operator.
    A generated/model-supplied file is not authorization to call this command.
    """
    required={'schema_version','decision_id','approved_by','grant_id','batch_instance_id','corpus_hash','pause_set_hash',
              'expires_at','remaining_slots','no_retry','no_new_sources','no_publication'}
    if not isinstance(decision,dict) or set(decision)!=required or decision['schema_version']!='knowledge-batch-resume/1':raise CoreError('INVALID_RESUME','Cần quyết định tiếp tục đúng hợp đồng.',409)
    if any(decision[k] is not True for k in ('no_retry','no_new_sources','no_publication')):raise CoreError('INVALID_RESUME','Các cam kết phải là giá trị đúng kiểu boolean true.',409)
    from .service import identifier
    identifier(decision['decision_id'])
    prepared,receipt,repo,authority=_load(directory)
    with EnterpriseRuntimeLock(repo.db_path),repo.connection(write=True) as db:
        status=_state(db,prepared,receipt,authority)
        from .operator_m6 import require_extension
        require_extension(db)
        old=db.execute("SELECT c.payload_json FROM kw_batch_controls c WHERE c.grant_id=? AND c.action='resume' AND c.command_id=?",(receipt['id'],decision['decision_id'])).fetchall()
        for row in old:
            saved=json.loads(row['payload_json'])['detail']
            if (not isinstance(saved,dict) or saved.get('schema_version')!='knowledge-worker-resume-receipt/1'
                or not isinstance(saved.get('decision'),dict) or saved.get('decision_hash')!=digest(saved['decision'])
                or saved.get('resulting_state')!='active'):
                raise CoreError('RESUME_RECEIPT_INVALID','Biên nhận tiếp tục cần đối soát; chưa ghi thay đổi.',409)
            if saved['decision']['decision_id']==decision['decision_id']:
                if saved['decision']!=decision:raise CoreError('IDEMPOTENCY_CONFLICT','Quyết định đã dùng với nội dung khác.',409)
                return saved
        expected=dict(schema_version='knowledge-batch-resume/1',decision_id=decision['decision_id'],approved_by='project_owner_operator',
            grant_id=status['grant_id'],batch_instance_id=status['batch_instance_id'],corpus_hash=status['corpus_hash'],
            pause_set_hash=status['pause_set_hash'],expires_at=status['expires_at'],remaining_slots=status['remaining_slots'],
            no_retry=True,no_new_sources=True,no_publication=True)
        if (decision!=expected or status['grant_state']!='paused_admission_review' or status['expires_at']<=now_iso()
            or status['blocked_slots'] or not status['completed_slots'] or not status['remaining_slots']):
            raise CoreError('RESUME_NOT_ALLOWED','Batch chưa đủ điều kiện tiếp tục; không đổi hạn mức hoặc gửi AI.',409)
        batch.validate_approved_inputs(prepared,repo)
        authority._resolve(db,prepared['account_id'],prepared['source_refs'],export=True)
        # CAS and receipt share the existing ledger transaction. No grant
        # issuance, term/expiry changes or proposal/expert trust elevation.
        saved=dict(schema_version='knowledge-worker-resume-receipt/1',decision=decision,decision_hash=digest(decision),resulting_state='active',recorded_at=now_iso())
        anchor=status['attempts'][0]['id']  # FK anchor only, never chooses the causal "latest" event.
        from .batch_lifecycle import append
        grant=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=?',(receipt['id'],)).fetchone()
        append(db,grant,action='resume',attempt_id=anchor,detail=saved,command_id=decision['decision_id'])
        return saved

def main():
    parser=argparse.ArgumentParser(description='Worker kho công khai; không tự tiếp tục hoặc thử lại có phí')
    parser.add_argument('command',choices=['status','run','resume','preview-independent','continue-independent']);parser.add_argument('--directory',required=True,type=Path)
    parser.add_argument('--decision-id')
    parser.add_argument('--max-new-calls',type=int,default=1);parser.add_argument('--env-file',type=Path);parser.add_argument('--human-decision',type=Path)
    args=parser.parse_args()
    if args.command=='status':result=snapshot(args.directory)
    elif args.command=='run':
        if args.env_file is None:raise SystemExit('Cần đường dẫn cấu hình riêng trên máy, không gửi khóa trong chat.')
        result=asyncio.run(run_once(args.directory,max_new_calls=args.max_new_calls,env_file=args.env_file))
    elif args.command=='preview-independent':
        from .independent_branch import preview
        result=preview(args.directory,args.decision_id)
    else:
        if args.human_decision is None:raise SystemExit('Chưa có quyết định tiếp tục của chủ dự án; batch giữ nguyên.')
        handler=resume
        if args.command=='continue-independent':
            from .independent_branch import continue_independent
            handler=continue_independent
        result=handler(args.directory,json.loads(args.human_decision.read_text(encoding='utf8')))
    # Do not print generated proposal bodies or source excerpts in an operator
    # status log. They are inspected through the existing proposal reader.
    if 'results' in result:result={k:v for k,v in result.items() if k!='results'}
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
