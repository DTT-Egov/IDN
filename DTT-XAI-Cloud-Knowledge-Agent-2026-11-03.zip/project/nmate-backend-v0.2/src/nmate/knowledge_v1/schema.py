"""Explicit additive schemas. SQL is authoritative; no model or filesystem truth.

DF-013/033/041/049. M1 does not change the live V17 runtime contract.
"""
M1_TABLES = [
    """CREATE TABLE kp_source_rights_events (
 id TEXT PRIMARY KEY, source_id TEXT NOT NULL REFERENCES pol_sources(id),
 version INTEGER NOT NULL CHECK(version>0), previous_id TEXT,
 allow_read INTEGER NOT NULL CHECK(allow_read IN (0,1)),
 allow_export INTEGER NOT NULL CHECK(allow_export IN (0,1) AND allow_export<=allow_read),
 reason TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES v03_accounts(id), created_at TEXT NOT NULL,
 UNIQUE(source_id,version), UNIQUE(source_id,id,version), UNIQUE(source_id,id), UNIQUE(source_id,previous_id),
 CHECK((version=1 AND previous_id IS NULL) OR (version>1 AND previous_id IS NOT NULL)),
 FOREIGN KEY(source_id,previous_id) REFERENCES kp_source_rights_events(source_id,id))""",
    """CREATE TABLE kp_source_rights_heads (
 source_id TEXT PRIMARY KEY REFERENCES pol_sources(id), event_id TEXT NOT NULL,
 version INTEGER NOT NULL CHECK(version>0),
 FOREIGN KEY(source_id,event_id,version) REFERENCES kp_source_rights_events(source_id,id,version))""",
    """CREATE TABLE kp_wiki_pages (
 id TEXT PRIMARY KEY, domain TEXT NOT NULL CHECK(domain='hanoi_policy'),
 jurisdiction TEXT NOT NULL CHECK(jurisdiction='VN-HN'), policy_id TEXT NOT NULL,
 created_by TEXT NOT NULL REFERENCES v03_accounts(id), created_at TEXT NOT NULL,
 head_revision_id TEXT, version INTEGER NOT NULL CHECK(version>0),
 lifecycle TEXT NOT NULL CHECK(lifecycle IN ('active','archived')),
 event_head_id TEXT,
 FOREIGN KEY(id,head_revision_id) REFERENCES kp_wiki_revisions(page_id,id),
 FOREIGN KEY(id,event_head_id) REFERENCES kp_knowledge_events(target_id,id))""",
    """CREATE TABLE kp_wiki_revisions (
 id TEXT PRIMARY KEY, page_id TEXT NOT NULL REFERENCES kp_wiki_pages(id), parent_revision_id TEXT,
 revision_no INTEGER NOT NULL CHECK(revision_no>0),
 page_kind TEXT NOT NULL CHECK(page_kind IN ('topic','program','procedure','synthesis','gap')),
 title TEXT NOT NULL, body TEXT NOT NULL, body_hash TEXT NOT NULL, content_hash TEXT NOT NULL,
 language TEXT NOT NULL CHECK(language='vi'), recipe_version TEXT NOT NULL,
 evidence_json TEXT NOT NULL, created_by TEXT NOT NULL REFERENCES v03_accounts(id), created_at TEXT NOT NULL,
 UNIQUE(page_id,id), UNIQUE(page_id,revision_no),
 CHECK((revision_no=1 AND parent_revision_id IS NULL) OR (revision_no>1 AND parent_revision_id IS NOT NULL)),
 FOREIGN KEY(page_id,parent_revision_id) REFERENCES kp_wiki_revisions(page_id,id))""",
    """CREATE TABLE kp_wiki_dependencies (
 revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id), ordinal INTEGER NOT NULL,
 source_id TEXT NOT NULL REFERENCES pol_sources(id), ref_json TEXT NOT NULL,
 PRIMARY KEY(revision_id,ordinal,source_id))""",
    """CREATE TABLE kp_knowledge_operations (
 actor_id TEXT NOT NULL REFERENCES v03_accounts(id), domain TEXT NOT NULL CHECK(domain='hanoi_policy'),
 kind TEXT NOT NULL, operation_id TEXT NOT NULL, request_hash TEXT NOT NULL, request_json TEXT NOT NULL,
 response_json TEXT NOT NULL, read_refs_json TEXT NOT NULL, created_at TEXT NOT NULL, receipt_hash TEXT NOT NULL,
 PRIMARY KEY(actor_id,domain,kind,operation_id))""",
    """CREATE TABLE kp_knowledge_events (
 id TEXT PRIMARY KEY, target_kind TEXT NOT NULL CHECK(target_kind IN ('rights','wiki','source','extraction')),
 target_id TEXT NOT NULL, revision_id TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES v03_accounts(id), event_type TEXT NOT NULL,
 payload_json TEXT NOT NULL, previous_id TEXT, created_at TEXT NOT NULL,
 UNIQUE(target_id,id), UNIQUE(target_kind,target_id,id), UNIQUE(target_kind,target_id,previous_id),
 FOREIGN KEY(target_kind,target_id,previous_id) REFERENCES kp_knowledge_events(target_kind,target_id,id))""",
    """CREATE TABLE kp_pipeline_outbox (
 event_id TEXT PRIMARY KEY REFERENCES kp_knowledge_events(id), target_kind TEXT NOT NULL,
 target_id TEXT NOT NULL, revision_id TEXT NOT NULL, payload_json TEXT NOT NULL,
 delivery_state TEXT NOT NULL DEFAULT 'pending' CHECK(delivery_state IN ('pending','done')),
 delivered_at TEXT)""",
    "CREATE INDEX kp_dependencies_source ON kp_wiki_dependencies(source_id,revision_id)",
]

IMMUTABLE_M1 = ('kp_source_rights_events', 'kp_wiki_revisions', 'kp_wiki_dependencies',
                'kp_knowledge_operations', 'kp_knowledge_events')
TRIGGERS_M1 = {}
for _table in IMMUTABLE_M1:
    for _action in ('UPDATE', 'DELETE'):
        _name = _table + ('_immutable' if _action == 'UPDATE' else '_no_delete')
        TRIGGERS_M1[_name] = (_table, f"CREATE TRIGGER {_name} BEFORE {_action} ON {_table} "
                             "BEGIN SELECT RAISE(ABORT,'immutable knowledge record'); END;")
TRIGGERS_M1['kp_wiki_page_identity_immutable'] = ('kp_wiki_pages',
    "CREATE TRIGGER kp_wiki_page_identity_immutable BEFORE UPDATE OF id,domain,jurisdiction,policy_id,created_by,created_at "
    "ON kp_wiki_pages BEGIN SELECT RAISE(ABORT,'immutable knowledge identity'); END;")
M1_STATEMENTS = M1_TABLES + [value[1] for value in TRIGGERS_M1.values()]
