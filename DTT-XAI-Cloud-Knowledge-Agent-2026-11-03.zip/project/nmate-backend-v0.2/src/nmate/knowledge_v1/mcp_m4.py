"""Serving and scope tools share authenticated MCP, never model dispatch."""
from nmate.v03.mcp import Identifier,Operation,Result
NAMES={'knowledge_wiki_bind_scope','knowledge_public_lookup'}

def register_tools(server,service,call):
    @server.tool(structured_output=True,description='Gắn phạm vi cho đúng revision wiki; chưa duyệt/phát hành, không gọi AI.')
    async def knowledge_wiki_bind_scope(page_id:Identifier,revision_id:Identifier,payload:dict,operation_id:Operation)->Result:
        return await call(lambda actor:service.bind_applicability(actor,page_id,revision_id=revision_id,payload=payload,operation_id=operation_id))

    @server.tool(structured_output=True,description='Đọc tri thức công khai đã phát hành theo từng nhu cầu; không đọc SSOT hoặc gọi AI.')
    async def knowledge_public_lookup(goals:list[str],target_date:str)->Result:
        return await call(lambda actor:service.lookup(actor,goals=goals,target_date=target_date))
