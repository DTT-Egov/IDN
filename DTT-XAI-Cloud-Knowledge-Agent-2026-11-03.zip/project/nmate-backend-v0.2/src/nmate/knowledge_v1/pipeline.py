"""M2 offline acquisition and retrieval. SQL authority, local parser, no AI.

Sources are explicitly configured public test/approved imports. There is no
network-enabled profile, scheduler, publication authority or private ingestion.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import tempfile

from nmate.core_v1.runtime_schema import canonical, digest
from nmate.policy_v1.catalog import normalize
from nmate.v03.core import CoreError,new_id,now_iso
from .service import KnowledgeService,identifier,text,version_precondition
from .operator_m2 import require_m2
from .local_parser import PARSER_VERSION,MAX_BYTES,MIMES,parse_local
from .freshness import decide


def integrity(message='Dữ liệu kho không khớp phiên bản đã ghi; cần đối soát.'):
    raise CoreError('knowledge_integrity_error',message,409)


def rendition_read(service,db,actor,rendition_id,*,export=False):
    row=db.execute('SELECT * FROM kp_renditions WHERE id=?',(identifier(rendition_id),)).fetchone()
    if row is None: raise CoreError('knowledge_not_found','Không tìm thấy bản tệp được phép.',404)
    service._source_read(db,actor,row['source_id'],export=export)
    if hashlib.sha256(row['raw_bytes']).hexdigest()!=row['raw_hash']: integrity()
    return dict(row)


def extraction_read(service,db,actor,extraction_id,*,export=False):
    row=db.execute('SELECT * FROM kp_extractions WHERE id=?',(identifier(extraction_id),)).fetchone()
    if row is None: raise CoreError('knowledge_not_found','Không tìm thấy bản trích xuất được phép.',404)
    rendition=rendition_read(service,db,actor,row['rendition_id'],export=export)
    payload=json.loads(row['payload_json'])
    if digest(payload)!=row['content_hash']: integrity()
    rows=db.execute('SELECT * FROM kp_extraction_chunks WHERE extraction_id=? ORDER BY ordinal',(row['id'],)).fetchall()
    actual=[]
    for c in rows:
        item={'id':c['id'],'text':c['text'],'locator':json.loads(c['locator_json'])}
        if digest([row['id'],c['ordinal'],item])!=c['content_hash']: integrity()
        actual.append(item)
    if (actual!=payload['chunks'] or payload['quality']!=row['quality'] or
        payload['parser_version']!=row['parser_version'] or payload['raw_hash']!=rendition['raw_hash'] or
        payload['rendition_id']!=rendition['id']): integrity()
    return {**payload,'extraction_id':row['id'],'filename':rendition['filename'],'source_id':rendition['source_id']}


def resolve_pipeline_reference(service,db,actor,ref,*,export=False):
    require_m2(db)
    kind=ref.get('kind')
    if kind=='pipeline_source' and set(ref)=={'kind','source_id'}:
        service._source_read(db,actor,identifier(ref['source_id']),export=export)
        return {ref['source_id']}
    if kind=='pipeline_rendition' and set(ref)=={'kind','rendition_id'}:
        return {rendition_read(service,db,actor,ref['rendition_id'],export=export)['source_id']}
    if kind=='pipeline_extraction' and set(ref)=={'kind','extraction_id'}:
        return {extraction_read(service,db,actor,ref['extraction_id'],export=export)['source_id']}
    if kind=='pipeline_candidate' and set(ref)=={'kind','page_id','revision_id'}:
        value=PipelineService._candidate_read(service,db,actor,identifier(ref['page_id']),identifier(ref['revision_id']),export=export)
        return set().union(*(service._resolve(db,actor,r,export=export) for r in value['evidence']))
    if kind!='pipeline_chunk' or set(ref)!={'kind','source_id','rendition_id','extraction_id','chunk_id','chunk_hash','quote','quote_hash','quote_start','quote_end'}:
        raise CoreError('invalid_evidence','Căn cứ pipeline cần đúng loại, ID, hash và trích dẫn.')
    for key in ('source_id','rendition_id','extraction_id','chunk_id'): identifier(ref[key])
    ex=extraction_read(service,db,actor,ref['extraction_id'],export=export)
    c=db.execute('SELECT * FROM kp_extraction_chunks WHERE id=? AND extraction_id=?',
                  (ref['chunk_id'],ref['extraction_id'])).fetchone()
    quote=text(ref['quote'],'Trích dẫn',64000)
    if (c is None or ex['source_id']!=ref['source_id'] or ex['rendition_id']!=ref['rendition_id'] or
        c['content_hash']!=ref['chunk_hash'] or type(ref['quote_start']) is not int or type(ref['quote_end']) is not int or
        not 0<=ref['quote_start']<ref['quote_end']<=len(c['text']) or
        c['text'][ref['quote_start']:ref['quote_end']]!=quote or hashlib.sha256(quote.encode()).hexdigest()!=ref['quote_hash']):
        raise CoreError('evidence_mismatch','Câu trích hoặc phiên bản pipeline không khớp nguồn gốc.')
    return {ref['source_id']}


class PipelineService(KnowledgeService):
    def __init__(self,repo):
        super().__init__(repo)
        with repo.connection() as db: require_m2(db)
        self.parser=parse_local

    def _candidate_authorize(self,db,actor,policy_id,evidence):
        self._writer(db,actor)

    def _state(self,db,actor,source_id):
        self._source_read(db,actor,identifier(source_id))
        state=db.execute('SELECT * FROM kp_source_state WHERE source_id=?',(source_id,)).fetchone()
        if state is None:
            if db.execute('SELECT 1 FROM kp_source_manifests WHERE source_id=?',(source_id,)).fetchone():
                integrity('Thiếu head của nguồn đã có lịch sử; cần đối soát.')
            raise CoreError('source_not_configured','Nguồn chưa có cấu hình nhập được duyệt.',409)
        event=db.execute("SELECT * FROM kp_knowledge_events WHERE id=? AND target_kind='source' AND target_id=?",
                         (state['event_head_id'],source_id)).fetchone()
        snapshot={k:state[k] for k in ('manifest_id','version','observation_id')}
        if (event is None or json.loads(event['payload_json'])!=snapshot or
            db.execute("SELECT 1 FROM kp_knowledge_events WHERE target_kind='source' AND target_id=? AND previous_id=?",
                       (source_id,event['id'])).fetchone()): integrity()
        manifest=db.execute('SELECT * FROM kp_source_manifests WHERE id=? AND source_id=?',(state['manifest_id'],source_id)).fetchone()
        if manifest is None or digest(json.loads(manifest['payload_json']))!=manifest['content_hash']: integrity()
        return {**dict(state),'manifest':json.loads(manifest['payload_json'])}

    def _source_event(self,db,actor,source_id,event_type):
        state=db.execute('SELECT * FROM kp_source_state WHERE source_id=?',(source_id,)).fetchone()
        event=new_id('kpe')
        payload={k:state[k] for k in ('manifest_id','version','observation_id')}
        db.execute('INSERT INTO kp_knowledge_events VALUES(?,?,?,?,?,?,?,?,?)',
            (event,'source',source_id,state['manifest_id'],actor,event_type,canonical(payload),state['event_head_id'],now_iso()))
        db.execute('UPDATE kp_source_state SET event_head_id=? WHERE source_id=? AND event_head_id IS ?',
                   (event,source_id,state['event_head_id']))
        db.execute('INSERT INTO kp_pipeline_outbox(event_id,target_kind,target_id,revision_id,payload_json) VALUES(?,?,?,?,?)',
                   (event,'source',source_id,state['manifest_id'],canonical(payload)))

    @staticmethod
    def _manifest(manifest):
        keys={'url','mime_type','language','operator','document_role','rights_basis','required_parts','gaps','network_enabled'}
        if not isinstance(manifest,dict) or set(manifest)!=keys: raise CoreError('invalid_source_manifest','Cần đủ danh mục nguồn, quyền và khoảng trống.')
        if (not isinstance(manifest['mime_type'],str) or manifest['mime_type'] not in MIMES or
            not isinstance(manifest['language'],str) or manifest['language'] not in {'vi','en'} or manifest['network_enabled'] is not False):
            raise CoreError('source_capability_disabled','M2 chỉ nhập cục bộ văn bản, HTML hoặc PDF; chưa bật Internet/lịch.')
        for k in ('url','operator','document_role','rights_basis'): text(manifest[k],k,2000)
        from nmate.policy_v1.catalog import KnowledgeCatalog
        KnowledgeCatalog._url(manifest['url'])
        for k in ('required_parts','gaps'):
            if not isinstance(manifest[k],list) or len(manifest[k])>50: raise CoreError('invalid_source_manifest','Danh sách căn cứ quá dài hoặc sai kiểu.')
            for item in manifest[k]: text(item,'Mục căn cứ',2000)
        if not manifest['required_parts']: raise CoreError('invalid_source_manifest','Cần nêu các phần của bộ căn cứ.')

    def configure_source(self,actor,source_id,*,expected_version,manifest,operation_id):
        request=dict(source_id=source_id,expected_version=expected_version,manifest=manifest)
        kind='knowledge.source.configure/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            self._writer(db,actor); self._source_read(db,actor,identifier(source_id)); self._manifest(manifest)
            if type(expected_version) is not int or expected_version<0: raise CoreError('invalid_revision','Phiên bản nguồn chưa hợp lệ.')
            existing=db.execute('SELECT * FROM kp_source_state WHERE source_id=?',(source_id,)).fetchone()
            if existing is None and (db.execute('SELECT 1 FROM kp_source_manifests WHERE source_id=?',(source_id,)).fetchone()
                                     or db.execute("SELECT 1 FROM kp_knowledge_events WHERE target_kind='source' AND target_id=?",(source_id,)).fetchone()):
                integrity('Thiếu head của nguồn đã có lịch sử; không khởi tạo đè lên chuỗi cũ.')
            state=self._state(db,actor,source_id) if existing else None
            if expected_version!=(state['version'] if state else 0): raise CoreError('revision_conflict','Nguồn đã đổi cấu hình; cần đọc lại.',409)
            source=db.execute('SELECT url FROM pol_sources WHERE id=?',(source_id,)).fetchone()
            if source[0]!=manifest['url']: raise CoreError('source_identity_conflict','URL khác identity nguồn; chưa đổi ngầm.',409)
            mid=new_id('kpm')
            db.execute('INSERT INTO kp_source_manifests VALUES(?,?,?,?,?,?,?)',
                (mid,source_id,state['manifest_id'] if state else None,canonical(manifest),digest(manifest),actor,now_iso()))
            if state:
                db.execute('UPDATE kp_source_state SET manifest_id=?,version=version+1 WHERE source_id=?',(mid,source_id))
            else: db.execute('INSERT INTO kp_source_state VALUES(?,?,1,NULL,NULL)',(source_id,mid))
            self._source_event(db,actor,source_id,'configured')
            result={'source_id':source_id,'manifest_id':mid,'version':expected_version+1,'manifest':manifest}
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_source','source_id':source_id}])
            return result

    def source_manifest(self,actor,source_id):
        with self.repo.connection() as db: return self._state(db,actor,source_id)

    def acquire_bytes(self,actor,source_id,*,expected_version,filename,mime_type,raw,operation_id):
        if not isinstance(raw,bytes) or not 0<len(raw)<=MAX_BYTES: raise CoreError('source_size_limit','Tệp cần từ1byte đến5MB.')
        request=dict(source_id=source_id,expected_version=expected_version,filename=filename,mime_type=mime_type,
                     raw_hash=hashlib.sha256(raw).hexdigest(),raw_size=len(raw))
        kind='knowledge.source.acquire/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            self._writer(db,actor); state=self._state(db,actor,source_id); version_precondition(expected_version)
            text(filename,'Tên tệp',240)
            if any(c in filename for c in '/\\\r\n') or filename in {'.','..'}: raise CoreError('invalid_filename','Tên tệp chưa hợp lệ.')
            if not isinstance(mime_type,str) or mime_type not in MIMES or mime_type!=state['manifest']['mime_type']: raise CoreError('source_mime_mismatch','Loại tệp khác manifest đã chốt.')
            if state['version']!=expected_version: raise CoreError('revision_conflict','Nguồn đã đổi; chưa ghi tệp này.',409)
            rid=new_id('kpb'); oid=new_id('kpo')
            db.execute('INSERT INTO kp_renditions VALUES(?,?,?,?,?,?,?,?)',
                (rid,source_id,state['manifest_id'],raw,request['raw_hash'],mime_type,filename,now_iso()))
            db.execute('INSERT INTO kp_acquisition_observations VALUES(?,?,?,?,?,?,?)',
                (oid,source_id,rid,state['observation_id'],state['manifest_id'],actor,now_iso()))
            db.execute('UPDATE kp_source_state SET observation_id=?,version=version+1 WHERE source_id=?',(oid,source_id))
            self._source_event(db,actor,source_id,'acquired')
            result={'source_id':source_id,'rendition_id':rid,'observation_id':oid,'version':expected_version+1,
                    'raw_hash':request['raw_hash'],'filename':filename,'extraction_state':'pending'}
            self._fault('before_acquire_receipt')
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_rendition','rendition_id':rid}])
        self._fault('after_acquire_commit')
        return result

    def extract_local(self,actor,rendition_id,*,operation_id):
        kind='knowledge.source.extract/1'; request=dict(rendition_id=rendition_id,parser_version=PARSER_VERSION)
        # READ transaction closes before parsing; no SQLite lock across parser.
        with self.repo.connection() as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            self._writer(db,actor); raw=rendition_read(self,db,actor,rendition_id)
            state=self._state(db,actor,raw['source_id'])
            rights=self._source_read(db,actor,raw['source_id'])['event_id']
            existing=db.execute('SELECT id FROM kp_extractions WHERE rendition_id=? AND parser_version=?',(rendition_id,PARSER_VERSION)).fetchone()
        parsed=None if existing else self.parser(raw['raw_bytes'],raw['mime_type'],raw['filename'])
        self._fault('after_parse')
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            self._writer(db,actor); current=rendition_read(self,db,actor,rendition_id)
            if (current!=raw or self._source_read(db,actor,raw['source_id'])['event_id']!=rights):
                raise CoreError('revision_conflict','Tệp hoặc quyền nguồn đổi trong khi đọc; chưa ghi trích xuất.',409)
            # Historical extraction is allowed, but never promoted over a newer
            # observation. Re-check the manifest so config changes cannot race.
            current_state=self._state(db,actor,raw['source_id'])
            if current_state['manifest_id']!=state['manifest_id']: raise CoreError('revision_conflict','Cấu hình nguồn đã đổi khi đọc tệp.',409)
            existing=db.execute('SELECT id FROM kp_extractions WHERE rendition_id=? AND parser_version=?',(rendition_id,PARSER_VERSION)).fetchone()
            if existing:
                result=extraction_read(self,db,actor,existing[0])
            else:
                self._validate_parsed(parsed,raw=raw['raw_bytes'],mime=raw['mime_type'])
                eid=new_id('kpx')
                chunks=[{'id':new_id('kpc'),**item} for item in parsed['chunks']]
                payload={**parsed,'chunks':chunks,'raw_hash':raw['raw_hash'],'rendition_id':rendition_id,'parser_version':PARSER_VERSION}
                db.execute('INSERT INTO kp_extractions VALUES(?,?,?,?,?,?,?,?)',
                    (eid,rendition_id,PARSER_VERSION,parsed['quality'],canonical(payload),digest(payload),actor,now_iso()))
                for i,c in enumerate(chunks):
                    db.execute('INSERT INTO kp_extraction_chunks VALUES(?,?,?,?,?,?)',
                        (c['id'],eid,i,c['text'],canonical(c['locator']),digest([eid,i,c])))
                event=new_id('kpe')
                db.execute('INSERT INTO kp_knowledge_events VALUES(?,?,?,?,?,?,?,?,?)',
                    (event,'extraction',eid,eid,actor,'extracted',canonical({'content_hash':digest(payload)}),None,now_iso()))
                db.execute('INSERT INTO kp_pipeline_outbox(event_id,target_kind,target_id,revision_id,payload_json) VALUES(?,?,?,?,?)',
                    (event,'extraction',eid,eid,canonical({'content_hash':digest(payload)})))
                result=extraction_read(self,db,actor,eid)
            observation=db.execute('SELECT rendition_id FROM kp_acquisition_observations WHERE id=?',(current_state['observation_id'],)).fetchone()
            result['is_current']=bool(observation and observation[0]==rendition_id and raw['manifest_id']==current_state['manifest_id'])
            self._fault('before_extract_commit')
            self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_extraction','extraction_id':result['extraction_id']}])
        self._fault('after_extract_commit')
        return result

    @staticmethod
    def _validate_parsed(parsed,*,raw=None,mime=None):
        if (not isinstance(parsed,dict) or set(parsed)!={'quality','error_code','chunks','gaps','admission'} or
            not isinstance(parsed['quality'],str) or parsed['quality'] not in {'text_extracted','source_incomplete','failed'} or
            not isinstance(parsed['chunks'],list) or len(parsed['chunks'])>32 or not isinstance(parsed['gaps'],list)):
            raise CoreError('invalid_extraction','Bộ đọc trả kết quả khác hợp đồng; chưa ghi.')
        if parsed['quality']=='failed' and parsed['chunks']: raise CoreError('invalid_extraction','Tệp lỗi không được tạo căn cứ.')
        if (parsed['quality']=='text_extracted' and (not parsed['chunks'] or parsed['gaps'] or parsed['error_code'] is not None) or
            parsed['quality']=='source_incomplete' and (not parsed['gaps'] or parsed['error_code'] is not None) or
            parsed['quality']=='failed' and not isinstance(parsed['error_code'],str)):
            raise CoreError('invalid_extraction','Trạng thái chất lượng mâu thuẫn nội dung/gap; chưa ghi kết quả.')
        if len(parsed['gaps'])>100: raise CoreError('invalid_extraction','Quá nhiều khoảng trống; cần tách tài liệu.')
        for gap in parsed['gaps']: text(gap,'Khoảng trống căn cứ',2000)
        admission=parsed['admission']
        if (not isinstance(admission,dict) or set(admission)!={'state','reason_codes'} or
            not isinstance(admission['state'],str) or admission['state'] not in {'candidate_unverified','rejected'} or not isinstance(admission['reason_codes'],list) or
            (admission['state']=='rejected' and (parsed['chunks'] or parsed['quality']!='failed'))):
            raise CoreError('invalid_extraction','Trạng thái tiếp nhận tài liệu khác hợp đồng; chưa tạo căn cứ.')
        if len(admission['reason_codes'])>32: raise CoreError('invalid_extraction','Lý do tiếp nhận quá dài.')
        for reason in admission['reason_codes']: text(reason,'Lý do tiếp nhận',200)
        if (parsed['quality']=='failed')!=(admission['state']=='rejected'):
            raise CoreError('invalid_extraction','Admission và quality mâu thuẫn; chưa ghi.')
        total=0; previous_end=0; previous_page=0
        try:
            original=raw.decode('utf-8-sig') if raw is not None and mime=='text/plain' and parsed['chunks'] else None
        except UnicodeError as exc:
            raise CoreError('invalid_extraction','Bộ đọc tạo chữ từ nguyên bản TXT không đúng UTF8; chưa ghi.') from exc
        for c in parsed['chunks']:
            if not isinstance(c,dict) or set(c)!={'text','locator'} or not isinstance(c['locator'],dict): raise CoreError('invalid_extraction','Locator chưa hợp lệ.')
            text(c['text'],'Chữ trích xuất',200000); total+=len(c['text'])
            locator=c['locator']
            if mime=='application/pdf':
                if (set(locator)!={'kind','page'} or locator['kind']!='pdf_page' or type(locator['page']) is not int or
                    not previous_page<locator['page']<=20):
                    raise CoreError('invalid_extraction','Vị trí trang PDF không hợp lệ hoặc trùng/đảo thứ tự.')
                previous_page=locator['page']
            else:
                if (set(locator)!={'kind','start','end'} or locator['kind']!='extracted_text_span' or
                    type(locator['start']) is not int or type(locator['end']) is not int or
                    not previous_end<=locator['start']<locator['end']<=64000 or locator['end']-locator['start']!=len(c['text'])):
                    raise CoreError('invalid_extraction','Vị trí đoạn chữ sai kiểu, chồng lấn hoặc vượt phạm vi.')
                if original is not None and original[locator['start']:locator['end']]!=c['text']:
                    raise CoreError('invalid_extraction','Đoạn trích không khớp vị trí trong nguyên bản TXT.')
                previous_end=locator['end']
        if total>64000: raise CoreError('source_text_limit','Tệp quá nhiều chữ để đọc cục bộ.')

    def get_extraction(self,actor,extraction_id):
        with self.repo.connection() as db: return extraction_read(self,db,actor,extraction_id)

    def read_original(self,actor,rendition_id):
        with self.repo.connection() as db: return rendition_read(self,db,actor,rendition_id,export=True)

    def pipeline_evidence(self,actor,chunk_id,quote,*,quote_start=None):
        with self.repo.connection() as db:
            c=db.execute('SELECT * FROM kp_extraction_chunks WHERE id=?',(identifier(chunk_id),)).fetchone()
            if not c: raise CoreError('evidence_not_found','Không tìm thấy đoạn gốc.',404)
            ex=extraction_read(self,db,actor,c['extraction_id'])
            quote=text(quote,'Trích dẫn',64000)
            if quote_start is None:
                positions=[m.start() for m in re.finditer('(?='+re.escape(quote)+')',c['text'])]
                if len(positions)!=1: raise CoreError('ambiguous_quote_span','Câu trích thiếu hoặc lặp nhiều vị trí; cần chỉ rõ vị trí ký tự.')
                quote_start=positions[0]
            if type(quote_start) is not int: raise CoreError('invalid_quote_span','Vị trí câu trích cần số nguyên.')
            ref=dict(kind='pipeline_chunk',source_id=ex['source_id'],rendition_id=ex['rendition_id'],
                     extraction_id=ex['extraction_id'],chunk_id=c['id'],chunk_hash=c['content_hash'],
                     quote=quote,quote_hash=hashlib.sha256(quote.encode()).hexdigest(),quote_start=quote_start,quote_end=quote_start+len(quote))
            self._resolve(db,actor,ref)
            return ref

    def _validate_bindings(self,db,actor,body,claims,aliases,links,*,export=False):
        if not isinstance(claims,list) or not 1<=len(claims)<=40: raise CoreError('invalid_coverage','Cần khai từng nhận định và căn cứ.')
        covered=set(); evidence=[]
        for claim in claims:
            if (not isinstance(claim,dict) or set(claim)!={'kind','start','end','text','evidence'} or
                not isinstance(claim['kind'],str) or claim['kind'] not in {'source_excerpt','interpretation'} or type(claim['start']) is not int or type(claim['end']) is not int or
                not 0<=claim['start']<claim['end']<=len(body) or body[claim['start']:claim['end']]!=claim['text'] or
                not isinstance(claim['evidence'],list) or not 1<=len(claim['evidence'])<=10):
                raise CoreError('invalid_coverage','Nhận định cần đúng phần chữ, vị trí và loại căn cứ; chưa coi là luật.')
            for ref in claim['evidence']:
                self._resolve(db,actor,ref,export=export)
                if ref.get('kind')!='pipeline_chunk': raise CoreError('invalid_coverage','Candidate M2 cần căn cứ từ tệp đã trích có locator.')
                if ref not in evidence: evidence.append(ref)
            if claim['kind']=='source_excerpt' and not any(claim['text'] in ref['quote'] for ref in claim['evidence']):
                raise CoreError('invalid_coverage','Trích nguyên văn chưa khớp câu gốc; diễn giải phải ghi rõ để chuyên gia rà.')
            covered.update(range(claim['start'],claim['end']))
        offset=0
        for line in body.splitlines(keepends=True):
            if not re.match(r'^#{1,6}\s',line):
                if any(not ch.isspace() and offset+i not in covered for i,ch in enumerate(line)):
                    raise CoreError('incomplete_claim_coverage','Còn phần nội dung chưa gắn nhận định/căn cứ; chưa lưu candidate.')
            offset+=len(line)
        if not isinstance(aliases,list) or len(aliases)>20: raise CoreError('invalid_alias','Alias cần danh sách ngắn.')
        for alias in aliases: text(alias,'Tên tìm kiếm',160)
        if not isinstance(links,list) or len(links)>20: raise CoreError('invalid_link','Liên kết cần danh sách ngắn.')
        for link in links:
            if not isinstance(link,dict) or set(link)!={'relation','page_id','revision_id'} or not isinstance(link['relation'],str) or link['relation'] not in {'related_topic','see_also'}:
                raise CoreError('invalid_link','Liên kết điều hướng không phải quan hệ pháp lý.')
            # Navigation does not recursively inherit other navigation as
            # evidence. Read exact target body/direct evidence and verify its
            # binding envelope, without returning/traversing target links.
            target=self._page_read_base(db,actor,identifier(link['page_id']),identifier(link['revision_id']),export=export)
            if self._page_contract(db,link['page_id'])=='knowledge-candidate/1':
                target_binding=db.execute('SELECT * FROM kp_candidate_bindings WHERE revision_id=?',(link['revision_id'],)).fetchone()
                if (target_binding is None or target_binding['body_hash']!=target['body_hash'] or
                    digest(json.loads(target_binding['payload_json']))!=target_binding['content_hash']): integrity()
        return evidence

    def create_candidate(self,actor,*,policy_id,title,body,claims,aliases,links,operation_id):
        request=dict(policy_id=policy_id,title=title,body=body,claims=claims,aliases=aliases,links=links)
        with self.repo.connection(write=True) as db:
            return self._create_candidate_in(db,actor,request,operation_id)

    def _create_candidate_in(self,db,actor,request,operation_id):
        policy_id,title,body,claims,aliases,links=(request[k] for k in ('policy_id','title','body','claims','aliases','links'))
        kind='knowledge.candidate.create/1'
        hashed,replayed=self._replay(db,actor,kind,operation_id,request)
        if replayed is not None: return replayed
        identifier(policy_id); text(body,'Nội dung wiki',100000)
        evidence=self._validate_bindings(db,actor,body,claims,aliases,links)
        self._candidate_authorize(db,actor,policy_id,evidence)
        page=new_id('kpp')
        db.execute("INSERT INTO kp_wiki_pages VALUES(?,'hanoi_policy','VN-HN',?,?,?,NULL,1,'active',NULL)",
                   (page,policy_id,actor,now_iso()))
        db.execute("INSERT INTO kp_page_contracts VALUES(?,'knowledge-candidate/1')",(page,))
        revision=self._revision(db,actor,page,title,body,evidence,'topic')
        db.execute('UPDATE kp_wiki_pages SET head_revision_id=? WHERE id=?',(revision,page))
        payload=dict(claims=claims,aliases=aliases,links=links)
        db.execute('INSERT INTO kp_candidate_bindings VALUES(?,?,?,?)',(revision,hashlib.sha256(body.encode()).hexdigest(),canonical(payload),digest(payload)))
        for link in links: db.execute('INSERT INTO kp_navigation_links VALUES(?,?,?,?)',
                                     (revision,link['relation'],link['page_id'],link['revision_id']))
        self._event(db,actor,'wiki',page,revision,'created',{'page_id':page,'revision_id':revision})
        result=self._candidate_read(db,actor,page)
        self._save(db,actor,kind,operation_id,request,hashed,result,[{'kind':'pipeline_candidate','page_id':page,'revision_id':revision}])
        return result

    def _candidate_read(self,db,actor,page_id,revision_id=None,*,export=False):
        page=self._page_read_base(db,actor,page_id,revision_id,export=export)
        if self._page_contract(db,page_id)!='knowledge-candidate/1':
            raise CoreError('candidate_binding_missing','Trang này chưa có hợp đồng candidate M2.',409)
        row=db.execute('SELECT * FROM kp_candidate_bindings WHERE revision_id=?',(page['revision_id'],)).fetchone()
        if row is None: raise CoreError('candidate_binding_missing','Trang chưa có binding nhận định M2.',409)
        binding=json.loads(row['payload_json'])
        if row['body_hash']!=page['body_hash'] or digest(binding)!=row['content_hash']: integrity()
        evidence=PipelineService._validate_bindings(self,db,actor,page['body'],binding['claims'],binding['aliases'],binding['links'],export=export)
        if evidence!=page['evidence']: integrity()
        reasons=[]
        for ref in evidence:
            state=PipelineService._state(self,db,actor,ref['source_id'])
            raw=rendition_read(self,db,actor,ref['rendition_id'])
            obs=db.execute('SELECT rendition_id FROM kp_acquisition_observations WHERE id=?',(state['observation_id'],)).fetchone()
            latest=rendition_read(self,db,actor,obs[0]) if obs else None
            if (not latest or latest['raw_hash']!=raw['raw_hash'] or state['manifest_id']!=raw['manifest_id']): reasons.append('changed_needs_review')
            ex=extraction_read(self,db,actor,ref['extraction_id'])
            if ex['parser_version']!=PARSER_VERSION: reasons.append('changed_needs_review')
            if ex['quality']!='text_extracted' or state['manifest']['gaps']: reasons.append('source_incomplete')
        # No approved live source-check policy or expert release in M2.
        reasons.extend(['currentness_unconfirmed','not_published'])
        state=next((s for s in ('changed_needs_review','source_incomplete','currentness_unconfirmed') if s in reasons))
        freshness=decide(mode='history' if revision_id else 'discovery',blockers=[r for r in reasons if r!='not_published'],
                         reason_codes=reasons,basis_refs=evidence)
        return {**page,**binding,'binding_hash':row['content_hash'],'assessment_eligible':False,
                'freshness':freshness,'coverage':'mechanical_binding_only_not_legal_entailment',
                'section_ids':['section:'+digest([page['body_hash'],c['start'],c['end'],c['kind']]) for c in binding['claims']]}

    def edit_candidate(self,actor,page_id,*,expected_version,expected_revision_id,title,body,claims,aliases,links,operation_id):
        request=dict(page_id=page_id,expected_version=expected_version,expected_revision_id=expected_revision_id,
                     title=title,body=body,claims=claims,aliases=aliases,links=links)
        kind='knowledge.candidate.edit/1'
        with self.repo.connection(write=True) as db:
            hashed,replayed=self._replay(db,actor,kind,operation_id,request)
            if replayed is not None: return replayed
            old=self._candidate_read(db,actor,identifier(page_id))
            version_precondition(expected_version); identifier(expected_revision_id); text(body,'Nội dung wiki',100000)
            if old['lifecycle']!='active' or old['version']!=expected_version or old['revision_id']!=expected_revision_id:
                raise CoreError('revision_conflict','Trang đã đổi; nháp chưa ghi, cần đối chiếu phiên bản.',409)
            evidence=self._validate_bindings(db,actor,body,claims,aliases,links)
            self._candidate_authorize(db,actor,old['policy_id'],old['evidence']+evidence)
            revision=self._revision(db,actor,page_id,title,body,evidence,'topic',expected_revision_id)
            payload=dict(claims=claims,aliases=aliases,links=links)
            db.execute('INSERT INTO kp_candidate_bindings VALUES(?,?,?,?)',
                       (revision,hashlib.sha256(body.encode()).hexdigest(),canonical(payload),digest(payload)))
            for link in links: db.execute('INSERT INTO kp_navigation_links VALUES(?,?,?,?)',
                                         (revision,link['relation'],link['page_id'],link['revision_id']))
            db.execute('UPDATE kp_wiki_pages SET head_revision_id=?,version=version+1 WHERE id=?',(revision,page_id))
            self._event(db,actor,'wiki',page_id,revision,'edited',{'page_id':page_id,'revision_id':revision})
            result=self._candidate_read(db,actor,page_id)
            self._save(db,actor,kind,operation_id,request,hashed,result,
                       [{'kind':'pipeline_candidate','page_id':page_id,'revision_id':revision},
                        {'kind':'pipeline_candidate','page_id':page_id,'revision_id':expected_revision_id}])
            return result

    def get_candidate(self,actor,page_id,*,revision_id=None):
        if revision_id is not None: identifier(revision_id)
        with self.repo.connection() as db: return self._candidate_read(db,actor,identifier(page_id),revision_id)

    def source_diff(self,actor,left_id,right_id):
        import difflib
        with self.repo.connection() as db:
            a=extraction_read(self,db,actor,left_id); b=extraction_read(self,db,actor,right_id)
            if a['source_id']!=b['source_id']: raise CoreError('source_identity_conflict','Không đối chiếu ngầm hai nguồn khác identity.')
            old='\n'.join(c['text'] for c in a['chunks']); new='\n'.join(c['text'] for c in b['chunks'])
            return {'left':left_id,'right':right_id,'raw_changed':a['raw_hash']!=b['raw_hash'],
                    'text_changed':old!=new,'quality_changed':a['quality']!=b['quality'],
                    'diff':'\n'.join(difflib.unified_diff(old.splitlines(),new.splitlines(),lineterm=''))}

    def export_markdown(self,actor,page_id):
        with self.repo.connection() as db:
            page=self._candidate_read(db,actor,identifier(page_id),export=True)
            manifest={k:page[k] for k in ('page_id','revision_id','body_hash','content_hash','binding_hash')}
            # Neutral marker is never accepted as a write/import authority.
            content='<!-- nMate projection '+canonical(manifest)+' -->\n\n> BẢN NHÁP — chưa phát hành; không dùng kết luận điều kiện chính sách.\n\n'+page['body']
            return {'manifest':manifest,'markdown':content,'export_hash':hashlib.sha256(content.encode()).hexdigest()}

    def materialize(self,actor,page_id,*,root):
        # Filesystem is a disposable projection. Serialize the final short
        # replace + metadata/ack under the same writer lock as rights revoke.
        # A crash after replace before commit leaves only a file to reconcile.
        with self.repo.connection(write=True) as db:
            self._writer(db,actor)
            page=self._candidate_read(db,actor,identifier(page_id),export=True)
            if page['lifecycle']!='active': raise CoreError('page_archived','Trang đã cất; không dựng bản hiện hành.',409)
            manifest={k:page[k] for k in ('page_id','revision_id','body_hash','content_hash','binding_hash')}
            content='<!-- nMate projection '+canonical(manifest)+' -->\n\n> BẢN NHÁP — chưa phát hành; không dùng kết luận điều kiện chính sách.\n\n'+page['body']
            export_hash=hashlib.sha256(content.encode()).hexdigest()
            folder=self._projection_root(root)
            path=folder/(page_id+'.md')
            if path.is_symlink(): raise CoreError('unsafe_projection_path','Không ghi qua liên kết tệp.')
            descriptor,tmp=tempfile.mkstemp(prefix='.pending-',dir=folder)
            try:
                with os.fdopen(descriptor,'w',encoding='utf-8',newline='') as f:
                    f.write(content); f.flush(); os.fsync(f.fileno())
                self._fault('before_projection_replace')
                os.replace(tmp,path)
                self._fault('after_projection_replace')
                head=db.execute('SELECT event_head_id FROM kp_wiki_pages WHERE id=?',(page_id,)).fetchone()[0]
                db.execute('INSERT INTO kp_search_documents VALUES(?,?,?) ON CONFLICT(page_id) DO UPDATE SET revision_id=excluded.revision_id,projection_hash=excluded.projection_hash',
                           (page_id,page['revision_id'],digest([page['revision_id'],page['content_hash'],page['binding_hash']])))
                db.execute('INSERT INTO kp_export_manifests VALUES(?,?,?,?) ON CONFLICT(page_id) DO UPDATE SET revision_id=excluded.revision_id,export_hash=excluded.export_hash,event_id=excluded.event_id',
                           (page_id,page['revision_id'],export_hash,head))
                db.execute("UPDATE kp_pipeline_outbox SET delivery_state='done',delivered_at=? WHERE target_kind='wiki' AND target_id=?",(now_iso(),page_id))
                return {'page_id':page_id,'revision_id':page['revision_id'],'export_hash':export_hash}
            finally:
                if os.path.exists(tmp): os.unlink(tmp)

    @staticmethod
    def _projection_root(root):
        path=Path(root).absolute()
        if any(p.is_symlink() or getattr(p,'is_junction',lambda:False)() for p in (path,*path.parents)):
            raise CoreError('unsafe_projection_path','Thư mục projection không được đi qua liên kết/junction.')
        path=path.resolve()
        path.mkdir(parents=True,exist_ok=True)
        marker=path/'.nmate-projection'
        if not marker.exists():
            if list(path.iterdir()): raise CoreError('unsafe_projection_path','Chỉ dùng thư mục projection riêng, rỗng khi khởi tạo.')
            marker.write_text('nmate-public-wiki-projection/1',encoding='utf-8')
        if marker.is_symlink() or marker.read_text('utf-8')!='nmate-public-wiki-projection/1': raise CoreError('unsafe_projection_path','Thư mục không phải projection đã nhận diện.')
        return path

    def reconcile_exports(self,actor,*,root):
        removed=[]
        with self.repo.connection(write=True) as db:
            self._writer(db,actor)
            folder=self._projection_root(root)
            for path in folder.glob('*.md'):
                page_id=path.stem
                # A hand-authored file in this directory is not a registered
                # derivative; cleanup must not become an arbitrary-file delete.
                if not db.execute('SELECT 1 FROM kp_wiki_pages WHERE id=?',(page_id,)).fetchone(): continue
                try:
                    identifier(page_id); p=self._candidate_read(db,actor,page_id,export=True)
                    if p['lifecycle']!='active': raise CoreError('page_archived','Trang đã cất.',409)
                except CoreError:
                    if path.is_symlink(): raise CoreError('unsafe_projection_path','Không xử lý liên kết tệp.')
                    path.unlink(); removed.append(page_id)
                    db.execute('DELETE FROM kp_export_manifests WHERE page_id=?',(page_id,))
                    db.execute('DELETE FROM kp_search_documents WHERE page_id=?',(page_id,))
            # Temp leftovers are not published files. Explicit cleanup only in
            # this dedicated managed directory; never recursive or shell delete.
            for path in folder.glob('.pending-*'):
                if path.is_file() and not path.is_symlink(): path.unlink()
        return {'removed':removed}

    def drain_outbox(self,actor,*,root,limit=50):
        """Explicit local materializer, not a new scheduler or external tool.

        Canonical source/rights gates are already effective even if delivery is
        delayed. Duplicate delivery always regenerates from current SQL head.
        """
        if type(limit) is not int or not 1<=limit<=100: raise CoreError('invalid_limit','Mỗi đợt tối đa100sự kiện.')
        with self.repo.connection() as db:
            self._writer(db,actor)
            rows=[dict(r) for r in db.execute("SELECT * FROM kp_pipeline_outbox WHERE delivery_state='pending' LIMIT ?",(limit,))]
        done=[]
        for event in rows:
            with self.repo.connection() as db:
                self._writer(db,actor)
                if event['target_kind']=='wiki': pages=[event['target_id']]
                elif event['target_kind'] in {'rights','source'}:
                    pages=[r[0] for r in db.execute('SELECT DISTINCT p.id FROM kp_wiki_dependencies d JOIN kp_wiki_pages p ON p.head_revision_id=d.revision_id WHERE d.source_id=?',(event['target_id'],))]
                else: pages=[]  # extraction is immutable; new evidence needs a new candidate revision
            self.reconcile_exports(actor,root=root)
            for page_id in pages:
                try: self.materialize(actor,page_id,root=root)
                except CoreError as exc:
                    if exc.code not in {'knowledge_read_denied','knowledge_not_found','page_archived'}: raise
            with self.repo.connection(write=True) as db:
                self._writer(db,actor)
                self._fault('before_outbox_ack')
                db.execute("UPDATE kp_pipeline_outbox SET delivery_state='done',delivered_at=? WHERE event_id=?",(now_iso(),event['event_id']))
            done.append(event['event_id'])
        return {'delivered_event_ids':done}

    def search(self,actor,query,*,limit=10):
        text(query,'Từ khóa',500)
        if type(limit) is not int or not 1<=limit<=30: raise CoreError('invalid_limit','Số kết quả cần từ1đến30.')
        terms=normalize(query).split()
        if not terms: return []
        with self.repo.connection() as db:
            self._active(db,actor)
            rows=db.execute('SELECT * FROM kp_search_documents').fetchall()
            if len(rows)>500: raise CoreError('search_capacity_limit','Kho thử vượt500trang; cần cấu hình index bền trước mở rộng.',409)
            allowed=[]
            for row in rows:
                try: page=self._candidate_read(db,actor,row['page_id'])
                except CoreError as exc:
                    if exc.status_code in (403,404,409): continue
                    raise
                if (page['lifecycle']!='active' or page['revision_id']!=row['revision_id'] or
                    digest([page['revision_id'],page['content_hash'],page['binding_hash']])!=row['projection_hash']): continue
                allowed.append(page)
            # Bounded in-memory FTS5 over authorized canonical documents. No
            # persistent virtual-table migration or use of legacy unguarded FTS.
            with sqlite3.connect(':memory:') as fts:
                fts.execute('CREATE VIRTUAL TABLE lookup USING fts5(id UNINDEXED,search_text)')
                for p in allowed: fts.execute('INSERT INTO lookup VALUES(?,?)',(p['page_id'],normalize(p['title']+' '+p['body']+' '+' '.join(p['aliases']))))
                match=' AND '.join('"'+term+'"' for term in terms)
                ids=[r[0] for r in fts.execute('SELECT id FROM lookup WHERE lookup MATCH ? ORDER BY rank LIMIT ?',(match,limit))]
            pages={p['page_id']:p for p in allowed}
            return [{'page_id':pid,'revision_id':pages[pid]['revision_id'],'title':pages[pid]['title'],
                     'snippet':pages[pid]['body'][:240],'assessment_eligible':False,'freshness':pages[pid]['freshness']} for pid in ids]

    def backlinks(self,actor,page_id):
        with self.repo.connection() as db:
            self._candidate_read(db,actor,identifier(page_id))
            rows=db.execute('SELECT DISTINCT r.page_id FROM kp_navigation_links l JOIN kp_wiki_revisions r ON r.id=l.revision_id WHERE l.target_page_id=?',(page_id,)).fetchall()
            result=[]
            for row in rows:
                try: page=self._candidate_read(db,actor,row[0])
                except CoreError: continue
                if page['lifecycle']=='active' and any(l['page_id']==page_id for l in page['links']):
                    result.append({'page_id':page['page_id'],'title':page['title'],'relation':'navigation_only'})
            return result
