"""Bounded, local-only extraction. No source fetch, model or document commands."""
from html.parser import HTMLParser
import re
from nmate.v03.core import CoreError
from .service import text

PARSER_VERSION='knowledge-local/2'
MAX_BYTES=5*1024*1024
MAX_TEXT=64000
MIMES={'text/plain','text/html','application/pdf'}


class VisibleHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.parts=[]; self.hidden=0; self.companions=[]
        self.in_title=False; self.title=[]; self.credential_form=False
    def handle_starttag(self,tag,attrs):
        attributes=dict(attrs)
        if tag=='title': self.in_title=True
        if (tag=='input' and (attributes.get('type') or '').casefold()=='password' or
            tag=='form' and re.search(r'(?:login|sign.?in|authenticate|oauth)',attributes.get('action') or '',re.I)):
            self.credential_form=True
        if tag in {'script','style','noscript'}: self.hidden+=1
        if not self.hidden and tag in {'p','div','br','li','h1','h2','h3','tr'}: self.parts.append('\n')
        if not self.hidden and tag=='a':
            href=dict(attrs).get('href') or ''
            if re.search(r'\.(pdf|docx?|xlsx?)(?:[?#]|$)',href,re.I): self.companions.append(href[:1000])
    def handle_endtag(self,tag):
        if tag=='title': self.in_title=False
        if tag in {'script','style','noscript'}: self.hidden=max(0,self.hidden-1)
    def handle_data(self,data):
        if self.in_title: self.title.append(data)
        if not self.hidden: self.parts.append(data)


def html_admission(parser,visible):
    """Document-role admission is separate from mechanical text extraction.

    Conservative guard for known access/error representations. Successful text
    extraction is only an unverified candidate, never legal completeness.
    """
    from nmate.policy_v1.catalog import normalize
    title=normalize(' '.join(parser.title)); body=normalize(visible)
    auth_titles={'sign in','signin','log in','login','dang nhap','authentication required'}
    error_titles={'error','access denied','forbidden','not found','bad gateway','service unavailable'}
    reasons=[]
    if parser.credential_form: reasons.append('credential_form')
    if title in auth_titles or any(title.startswith(t+' ') for t in auth_titles): reasons.append('authentication_title')
    if title in error_titles or re.match(r'^(?:error\s+)?(?:401|403|404|500|502|503)\b',title): reasons.append('error_title')
    if len(body)<600 and any(p in body for p in ('please sign in','please log in','access denied','403 forbidden','404 not found','502 bad gateway','vui long dang nhap')):
        reasons.append('access_wall_body')
    return {'state':'rejected' if reasons else 'candidate_unverified',
            'reason_codes':reasons or ['local_document_only_no_legal_verification']}


def parse_local(raw,mime,filename):
    payload=_parse_local(raw,mime,filename)
    payload.setdefault('admission',{'state':'rejected' if payload['quality']=='failed' else 'candidate_unverified',
        'reason_codes':[payload['error_code']] if payload['quality']=='failed' else ['local_document_only_no_legal_verification']})
    return payload


def _parse_local(raw,mime,filename):
    if mime not in MIMES or not isinstance(raw,bytes) or not 0<len(raw)<=MAX_BYTES:
        return {'quality':'failed','error_code':'source_size_or_type_limit','chunks':[],'gaps':[]}
    if mime=='application/pdf':
        from nmate.v04.pdf_intake import extract_pdf_pages
        try:
            if not raw.startswith(b'%PDF-'): raise CoreError('invalid_pdf','PDF không hợp lệ.')
            result=extract_pdf_pages(raw)
        except CoreError as exc:
            return {'quality':'failed','error_code':exc.code,'chunks':[],'gaps':[]}
        pages=result['pages']
        # Any blank page is a completeness gap: mixed text/scanned pages must
        # not be silently accepted as a wholly read source.
        gaps=[f'page:{p["page_number"]}:no_readable_text' for p in pages if not p['text'].strip()]
        chunks=[{'text':p['text'],'locator':{'kind':'pdf_page','page':p['page_number']}}
                for p in pages if p['text'].strip()]
        return {'quality':'source_incomplete' if gaps or not chunks else 'text_extracted',
                'error_code':None,'chunks':chunks,'gaps':gaps or ([] if chunks else ['no_readable_text'])}
    try:
        decoded=raw.decode('utf-8-sig')
        text(decoded,'Nội dung nguồn',MAX_BYTES)
    except (UnicodeError,CoreError):
        return {'quality':'failed','error_code':'source_encoding_invalid','chunks':[],'gaps':[]}
    companions=[]
    if mime=='text/html':
        if not re.search(r'<(?:!doctype|html|body|p|div|h[1-6])(?:\s|>)',decoded,re.I):
            return {'quality':'failed','error_code':'source_mime_mismatch','chunks':[],'gaps':[]}
        parser=VisibleHTML(); parser.feed(decoded); decoded=''.join(parser.parts).strip()
        admission=html_admission(parser,decoded)
        if admission['state']=='rejected':
            return {'quality':'failed','error_code':'source_error_or_login_page','chunks':[],'gaps':[], 'admission':admission}
        companions=sorted(set(parser.companions))
    elif raw.startswith((b'%PDF-',b'PK\x03\x04')) or re.search(r'<(?:!doctype|html|body)(?:\s|>)',decoded,re.I):
        return {'quality':'failed','error_code':'source_mime_mismatch','chunks':[],'gaps':[]}
    if len(decoded)>MAX_TEXT:
        return {'quality':'failed','error_code':'source_text_limit','chunks':[],'gaps':[]}
    # Exact Unicode character offsets in the extracted rendition, not raw HTML
    # byte offsets. Original raw bytes remain separately addressable.
    chunks=[]
    for start in range(0,len(decoded),4000):
        part=decoded[start:start+4000]
        if part.strip(): chunks.append({'text':part,'locator':{'kind':'extracted_text_span','start':start,'end':start+len(part)}})
    gaps=['linked_attachment_unread:'+href for href in companions]
    if not chunks: gaps.append('no_readable_text')
    return {'quality':'source_incomplete' if gaps else 'text_extracted','error_code':None,'chunks':chunks,'gaps':gaps}
