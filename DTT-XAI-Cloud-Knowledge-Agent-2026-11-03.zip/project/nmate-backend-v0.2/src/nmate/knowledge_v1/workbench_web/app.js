/* One canonical server view; personal buffers never imply a published revision. */
"use strict";
const $ = (id) => document.getElementById(id);
let view = null,
  sessionActor = null,
  scopeEpoch = 0,
  dirty = false,
  unsaved = false,
  scopeUnsaved = false,
  busy = false,
  bufferVersion = 0;
const stateNames = {
  awaiting_review: "Chờ chuyên gia rà",
  approved: "Đã duyệt đúng bản",
  rejected: "Cần sửa",
  not_published: "Chưa phát hành",
  published: "Đã phát hành",
  withdrawn: "Đã ngừng phát hành",
  needs_review: "Căn cứ đã đổi · cần rà lại",
};
const gapNames = {
  page_archived: "Trang đã cất",
  source_incomplete: "Nguồn chưa đủ bộ hoặc chưa đọc đủ",
  source_attestation_required: "Cần chuyên gia xác minh nguồn",
  source_attestation_stale: "Nguồn đổi sau xác minh",
  source_not_verified: "Chưa xác minh đầy đủ/hiệu lực",
  currentness_unconfirmed: "Đã đến hạn kiểm tra lại nguồn",
  evidence_version_changed: "Trang còn dẫn phiên bản nguồn cũ",
  attestation_authority_revoked: "Quyền người xác minh đã thay đổi",
  upstream_source_unavailable: "Nguồn gốc báo thay đổi hoặc không kiểm tra được; cần đối chiếu lại",
  upstream_source_control_unanchored: "Cần một lần kiểm nguồn mới để xác lập chuỗi kiểm sau nâng cấp; dữ liệu cũ vẫn giữ nguyên",
};
function notice(s, error = false) {
  $("notice").textContent = s;
  $("notice").classList.toggle("error", error);
  $("notice").setAttribute("role", error ? "alert" : "status");
}
function clearPrivateView(){
    scopeEpoch++;
    view=null;dirty=false;unsaved=false;scopeUnsaved=false;bufferVersion=0;
    for(const id of ['editor','proposalList']){$(id).hidden=true;}
    for(const id of ['claims','queue','proposalList','preview','evidence','backlinks','scopeGoals'])$(id).replaceChildren();
    for(const id of ['title','rationale','leftRevision','scopeFrom','scopeUntil'])$(id).value='';
    for(const id of ['pageTitle','state','dirty','blockers','diffText','scopeState'])$(id).textContent='';
    history.replaceState(null,'',location.pathname);
}
async function readSession(){
    const epoch=scopeEpoch;
    let value;
    try{const response=await fetch('session',{cache:'no-store'});value=await response.json();}
    catch(error){if(epoch===scopeEpoch){clearPrivateView();sessionActor=null;}throw Error('Chưa xác minh được phiên đăng nhập. Nội dung riêng đã ẩn; nháp trên máy chủ vẫn giữ nguyên.');}
    if(epoch!==scopeEpoch)throw Error('Đã bỏ kiểm tra phiên đến muộn. Hãy mở lại mục đang dùng.');
    if(!value.ok){clearPrivateView();sessionActor=null;throw Error(value.error?.message||'Cần đăng nhập ứng dụng chính bằng tài khoản được phân quyền.');}
    if(sessionActor&&sessionActor!==value.account_id){clearPrivateView();sessionActor=value.account_id;throw Error('Tài khoản đã đổi. Nháp trên máy chủ vẫn giữ theo người sở hữu; hãy mở lại trang được phân quyền.');}
    sessionActor=value.account_id;
    return value;
}
async function rpc(tool, args = {}) {
  const before=await readSession();
  const epoch=scopeEpoch;
  const r = await fetch("rpc", {
    method: "POST",
    headers: { "Content-Type": "application/json",...(before.csrf_token?{'X-CSRF-Token':before.csrf_token}:{}) },
    body: JSON.stringify({ tool, arguments: args }),
  });
  const x = await r.json();
  if(epoch!==scopeEpoch)throw Error('Đã bỏ kết quả đến muộn của phiên trước. Nháp trên máy chủ vẫn giữ nguyên.');
  const after=await readSession();
  if(epoch!==scopeEpoch)throw Error('Đã bỏ kết quả đến muộn của phiên trước.');
  if(before.account_id!==after.account_id||x._scope_actor_id&&x._scope_actor_id!==before.account_id){
    clearPrivateView();sessionActor=after.account_id;
    throw Error('Tài khoản đã đổi. Đã bỏ kết quả đến muộn; nháp trên máy chủ vẫn giữ theo người sở hữu.');
  }
  if (!x.ok) throw Error(x.error?.message || "Chưa thực hiện được.");
  return x.data;
}
let sessionRecheck=null;
function revalidatePresentation(){
  if(sessionRecheck)return sessionRecheck;
  const epoch=scopeEpoch,panels=['editor','queue','proposalList'],visible=panels.filter(id=>!$(id).hidden);
  panels.forEach(id=>$(id).hidden=true);
  sessionRecheck=readSession().then(()=>{
    if(epoch===scopeEpoch)visible.forEach(id=>$(id).hidden=false);
  }).catch(error=>{notice(error.message,true);}).finally(()=>{sessionRecheck=null;});
  return sessionRecheck;
}
window.addEventListener('focus',revalidatePresentation);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)void revalidatePresentation();});
const op = () => crypto.randomUUID();
async function act(fn) {
  if (busy) return;
  busy = true;
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  notice("Đang xử lý, không gọi AI…");
  try {
    await fn();
  } catch (e) {
    notice(e.message, true);
  } finally {
    busy = false;
    document.querySelectorAll("button").forEach((b) => (b.disabled = false));
    if (view) permissions();
  }
}
function mark() {
  dirty = true;
  unsaved = true;
  $("dirty").hidden = false;
  $("dirty").textContent="Đang sửa nháp, chưa giữ trên máy chủ và chưa ghi bản wiki.";
  preview();
}
function payload() {
  const claims = view.candidate.claims.map((c, i) => ({
    ...c,
    text: $("claim-" + i).value,
  }));
  let body = "",
    pos = 0;
  for (const c of claims) {
    if (body) body += "\n\n";
    c.start = pos;
    c.end = pos + c.text.length;
    body += c.text;
    pos = body.length + 2;
  }
  return {
    title: $("title").value,
    body,
    claims,
    aliases: view.candidate.aliases,
    links: view.candidate.links,
  };
}
function preview() {
  const box = $("preview");
  box.replaceChildren();
  for (const c of payload().claims) {
    for (const line of c.text.split("\n")) {
      const match = line.match(/^(#{1,3})\s+(.*)$/);
      const p = document.createElement(
        match ? "h" + Math.min(4, match[1].length + 1) : "p",
      );
      p.textContent = match ? match[2] : line;
      box.append(p);
    }
  }
}
function permissions() {
  const p = view.permissions,
    g = view.governance;
  $("commit").disabled = !p.author;
  $("buffer").disabled = !p.author;
  $("approve").disabled = !p.review || !!view.blockers.length || dirty;
  $("reject").disabled = !p.review || dirty;
  $("publish").disabled =
    !p.publish ||
    g.publication_state === "published" ||
    g.review_state !== "approved" ||
    !!view.blockers.length ||
    dirty;
  $("withdraw").disabled =
    !p.publish || g.historical_release_state !== "published";
  $("bindScope").disabled=!p.author||dirty||!!view.serving_scope?.binding;
}
async function load(page) {
  location.hash = encodeURIComponent(page);
  view = await rpc("knowledge_wiki_workbench", { page_id: page });
  bufferVersion = view.editor_buffer?.ui_revision || 0;
  const p = view.candidate;
  let local =
    view.editor_buffer?.base_revision_id === p.revision_id
      ? JSON.parse(view.editor_buffer.payload_json)
      : null;
  dirty = !!local;
  unsaved=false;scopeUnsaved=false;
  $("editor").hidden = false;
  $("queue").hidden = true;
  $("proposalList").hidden = true;
  $("pageTitle").textContent = p.title;
  $("title").value = local?.title || p.title;
  $("state").textContent =
    `${stateNames[view.governance.review_state]} · ${stateNames[view.governance.publication_state]} · Bản ${p.version}`;
  $("dirty").hidden = !dirty;
  $("dirty").textContent="Đã giữ nháp riêng trên máy chủ; chưa ghi thành bản wiki chuẩn.";
  renderServingScope();
  $("claims").replaceChildren();
  (local?.claims || p.claims).forEach((c, i) => {
    const label = document.createElement("label");
    label.textContent = `Nhận định ${i + 1} · ${c.kind === "source_excerpt" ? "Nguyên văn" : "Diễn giải cần rà"}`;
    const t = document.createElement("textarea");
    t.id = "claim-" + i;
    t.value = c.text;
    t.addEventListener("input", mark);
    label.append(t);
    $("claims").append(label);
  });
  $("blockers").hidden = !view.blockers.length;
  $("blockers").textContent = view.blockers
    .map((b) => gapNames[b] || b)
    .join(" · ");
  $("evidence").replaceChildren();
  p.claims.forEach((c, i) => {
    const h = document.createElement("h3");
    h.textContent = `Căn cứ nhận định ${i + 1}`;
    $("evidence").append(h);
    c.evidence.forEach((e) => {
      const b = document.createElement("blockquote");
      b.textContent = `${e.source_id}\n${e.quote}\nBản nguồn: ${e.rendition_id}`;
      $("evidence").append(b);
    });
  });
  if (view.editor_buffer && !local) {
    const h = document.createElement("h3");
    h.textContent = "Nháp riêng từ bản cũ được giữ để đối chiếu";
    const old = document.createElement("pre");
    old.textContent = JSON.parse(view.editor_buffer.payload_json).body;
    $("evidence").append(h, old);
  }
  sourceForms();
  $("rationale").value = "";
  $("diffText").textContent = "";
  $("title").oninput = mark;
  preview();
  permissions();
  const links = await rpc("knowledge_backlinks", { page_id: page });
  $("backlinks").textContent =
    `Liên kết tới trang này: ${links.items?.length || 0}`;
}
function renderServingScope(){
  const scope=view.serving_scope,box=$("servingScope");box.hidden=!scope;
  if(!scope)return;
  const binding=scope.binding?.payload;$("scopeGoals").replaceChildren();
  for(const goal of scope.goal_options){
    const label=document.createElement("label"),input=document.createElement("input");
    input.type="checkbox";input.name="serving-goal";input.value=goal.id;input.checked=!!binding?.goal_types.includes(goal.id);
    input.disabled=!!binding||!view.permissions.author;label.append(input,document.createTextNode(goal.label_vi));$("scopeGoals").append(label);
    input.onchange=()=>{scopeUnsaved=true;};
  }
  $("scopeFrom").value=binding?.valid_from||"";$("scopeUntil").value=binding?.valid_until||"";
  for(const id of ["scopeFrom","scopeUntil"])$(id).disabled=!!binding||!view.permissions.author;
  for(const id of ["scopeFrom","scopeUntil"])$(id).oninput=()=>{scopeUnsaved=true;};
  $("scopeState").textContent=binding?"Đã ghi phạm vi cho bản này. Sửa phạm vi cần revision wiki mới và rà/phát hành lại.":"Chưa gắn phạm vi; bản này chưa xuất hiện trong tra cứu của doanh nghiệp.";
}
$("bindScope").onclick=()=>act(async()=>{
  if(dirty)throw Error("Hãy ghi bản wiki trước khi gắn phạm vi.");
  const page=view.candidate;
  await rpc("knowledge_wiki_bind_scope",{page_id:page.page_id,revision_id:page.revision_id,
    payload:{goal_types:[...document.querySelectorAll('input[name="serving-goal"]:checked')].map(i=>i.value),
      jurisdiction:"VN-HN",usable_for:["explain_public_policy"],valid_from:$("scopeFrom").value,valid_until:$("scopeUntil").value||null},operation_id:op()});
  await load(page.page_id);notice("Đã ghi phạm vi. Cần rà và phát hành đúng bản trước khi doanh nghiệp dùng.");
});
function sourceForms() {
  if (!view.permissions.attest) return;
  for (const source of view.review_manifest.sources) {
    const detail = document.createElement("details"),
      summary = document.createElement("summary");
    summary.textContent = "Xác minh nguồn: " + source.source_id;
    detail.append(summary);
    const note = document.createElement("p");
    note.textContent =
      "Chỉ ghi xác nhận sau khi đã đối chiếu bản gốc, đủ phần cần thiết và hiệu lực. Phần mềm không thay việc thẩm định.";
    detail.append(note);
    const checks = [];
    for (const labelText of [
      "Đã kiểm đủ toàn bộ phần cần thiết",
      "Đã xác minh hiệu lực pháp lý hiện hành",
    ]) {
      const label = document.createElement("label"),
        input = document.createElement("input");
      input.type = "checkbox";
      input.style.width = "44px";
      input.style.height = "44px";
      label.append(input, document.createTextNode(labelText));
      detail.append(label);
      checks.push(input);
    }
    const untilLabel = document.createElement("label"),
      until = document.createElement("input");
    untilLabel.textContent = "Hạn phải kiểm lại (tối đa 24 giờ)";
    until.type = "datetime-local";
    untilLabel.append(until);
    detail.append(untilLabel);
    const reasonLabel = document.createElement("label"),
      reason = document.createElement("textarea");
    reasonLabel.textContent = "Căn cứ đã xác minh";
    reasonLabel.append(reason);
    detail.append(reasonLabel);
    const button = document.createElement("button");
    button.textContent = "Ghi xác minh nguồn này";
    button.onclick = () =>
      act(async () => {
        await rpc("knowledge_wiki_attest", {
          policy_id: view.candidate.policy_id,
          source_id: source.source_id,
          expected_source_version: source.state_version,
          complete: checks[0].checked,
          legal_currency_confirmed: checks[1].checked,
          current_until: new Date(until.value).toISOString(),
          rationale: reason.value,
          operation_id: op(),
        });
        await load(view.candidate.page_id);
        notice("Đã ghi xác minh nguồn; chưa duyệt hay phát hành trang.");
      });
    detail.append(button);
    $("evidence").append(detail);
  }
}
async function queue() {
  if(unsaved||scopeUnsaved)throw Error("Còn thay đổi chưa ghi. Hãy giữ nháp hoặc ghi phạm vi trước khi chuyển mục.");
  view = null;
  dirty = false;
  history.replaceState(null, "", location.pathname);
  $("editor").hidden = true;
  $("proposalList").hidden = true;
  $("queue").hidden = false;
  const rows = await rpc("knowledge_wiki_queue");
  $("queue").replaceChildren();
  if (!rows.length)
    $("queue").textContent = "Chưa có trang wiki được phép trong hàng đợi.";
  for (const row of rows) {
    const card = document.createElement("section");
    const h = document.createElement("h2");
    h.textContent = row.title;
    const p = document.createElement("p");
    p.textContent = stateNames[row.governance.publication_state];
    const b = document.createElement("button");
    b.textContent = "Mở để rà";
    b.setAttribute("aria-label", "Mở để rà: " + row.title);
    b.onclick = () =>
      act(async () => {
        await load(row.page_id);
        notice("Đã mở đúng phiên bản hiện tại.");
      });
    card.append(h, p, b);
    $("queue").append(card);
  }
  notice("Đã đọc hàng đợi. Không gọi AI.");
}
$("refresh").onclick = () => act(queue);
$("back").onclick = () => act(queue);
$("buffer").onclick = () =>
  act(async () => {
    const p = view.candidate;
    const r = await rpc("knowledge_wiki_buffer", {
      page_id: p.page_id,
      base_revision_id: p.revision_id,
      expected_ui_revision: bufferVersion,
      payload: payload(),
      operation_id: op(),
    });
    bufferVersion = r.ui_revision;
    unsaved=false;
    $("dirty").textContent="Đã giữ nháp riêng trên máy chủ; chưa ghi thành bản wiki chuẩn.";
    notice("Đã giữ nháp riêng. Chưa sửa bản wiki chuẩn.");
  });
$("commit").onclick = () =>
  act(async () => {
    const p = view.candidate;
    await rpc("knowledge_candidate_edit", {
      page_id: p.page_id,
      expected_version: p.version,
      expected_revision_id: p.revision_id,
      ...payload(),
      operation_id: op(),
    });
    await load(p.page_id);
    dirty = false;
    $("dirty").hidden = true;
    permissions();
    notice("Đã ghi bản wiki mới. Cần rà lại bản mới trước khi phát hành.");
  });
for (const [id, approve] of [
  ["approve", true],
  ["reject", false],
])
  $(id).onclick = () =>
    act(async () => {
      const p = view.candidate;
      await rpc("knowledge_wiki_review", {
        page_id: p.page_id,
        expected_version: p.version,
        revision_id: p.revision_id,
        expected_manifest_hash: view.review_manifest_hash,
        approve,
        rationale: $("rationale").value,
        operation_id: op(),
      });
      await load(p.page_id);
      notice(
        approve
          ? "Đã duyệt đúng bản, chưa phát hành."
          : "Đã ghi yêu cầu sửa và lý do.",
      );
    });
$("publish").onclick = () =>
  act(async () => {
    const p = view.candidate;
    await rpc("knowledge_wiki_publish", {
      page_id: p.page_id,
      revision_id: p.revision_id,
      review_event_id: view.governance.review_event_id,
      expected_manifest_hash: view.review_manifest_hash,
      rationale: $("rationale").value,
      operation_id: op(),
    });
    await load(p.page_id);
    notice("Đã phát hành đúng bản và căn cứ đã rà.");
  });
$("withdraw").onclick = () =>
  act(async () => {
    const p = view.candidate;
    await rpc("knowledge_wiki_withdraw", {
      page_id: p.page_id,
      expected_release_id: view.governance.release_event_id,
      rationale: $("rationale").value,
      operation_id: op(),
    });
    await load(p.page_id);
    notice("Đã ngừng phát hành. Lịch sử được giữ.");
  });
$("diff").onclick = () =>
  act(async () => {
    const p = view.candidate;
    const d = await rpc("knowledge_wiki_diff", {
      page_id: p.page_id,
      left_revision: $("leftRevision").value,
      right_revision: p.revision_id,
    });
    $("diffText").textContent = d.diff || "Nội dung hai bản giống nhau.";
    notice("Đã đối chiếu, không gọi AI.");
  });
$("proposals").onclick = () =>
  act(async () => {
    if (unsaved||scopeUnsaved) throw Error("Còn thay đổi chưa ghi; giữ nháp hoặc ghi phạm vi trước khi chuyển mục.");
    const rows = await rpc("knowledge_wiki_proposals");
    $("proposalList").hidden = false;
    $("queue").hidden = true;
    $("editor").hidden = true;
    $("proposalList").replaceChildren();
    for (const row of rows) {
      const box = document.createElement("section"),
        h = document.createElement("h2"),
        body = document.createElement("pre");
      h.textContent = row.payload.model_output.title;
      body.textContent =
        row.payload.candidate.body +
        "\n\nNháp chờ chuyên gia rà; dẫn nguồn khớp chữ chưa chứng minh diễn giải đúng hoặc chính sách còn hiệu lực." +
        (row.payload.admission
          ? "\n" + row.payload.admission.claims.map((c, i) =>
              "Nhận định " + (i + 1) + ": " +
              (c.effective_kind === "interpretation" ? "Diễn giải chưa kiểm chứng ngữ nghĩa" : "Trích đoạn khớp chữ; chưa thẩm định") +
              (c.model_kind !== c.effective_kind ? " (AI gắn nhầm nhãn trích nguyên văn)" : "")
            ).join("\n")
          : "") +
        "\n\nCòn thiếu:\n" +
        row.payload.model_output.gaps.join("\n");
      const b = document.createElement("button");
      b.textContent = "Chuyển thành wiki nháp";
      b.onclick = () =>
        act(async () => {
          const p = await rpc("knowledge_wiki_apply_proposal", {
            proposal_id: row.id,
            operation_id: op(),
          });
          await load(p.page_id);
          notice("Đã tạo wiki nháp. Chưa duyệt hay phát hành.");
        });
      box.append(h, body, b);
      $("proposalList").append(box);
    }
    notice(
      rows.length
        ? "Đã mở đề xuất AI đã lưu. Chưa phải kết luận chuyên gia."
        : "Chưa có đề xuất AI được giao.",
    );
  });
window.addEventListener("beforeunload", (e) => {
  if (unsaved||scopeUnsaved) {
    e.preventDefault();
    e.returnValue = "";
  }
});
act(async () => {
  if (location.hash) {
    await load(decodeURIComponent(location.hash.slice(1)));
    notice("Đã mở lại đúng bản và nháp cá nhân.");
  } else await queue();
});
