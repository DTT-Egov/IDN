"""Canonical public wiki and source-rights service (M1).

No model/provider/network/renderer or implicit initialization. Public receipts
have a typed namespace; existing catalog authority controls writes. Rights are
explicit and versioned, not inferred from a legacy source's classification.
"""
from __future__ import annotations

import hashlib
import json
import re

from nmate.core_v1.runtime_schema import canonical, digest
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError, new_id, now_iso
from .operator import require_schema


DOMAIN = 'hanoi_policy'


def text(value, label, maximum=200, *, empty=False):
    if not isinstance(value, str):
        raise CoreError('invalid_knowledge_input', f'{label} chưa hợp lệ hoặc quá dài.')
    try:
        encoded = value.encode('utf-8')
    except UnicodeError as exc:
        raise CoreError('invalid_knowledge_input', f'{label} chứa ký tự không hợp lệ; chưa dùng dữ liệu này.') from exc
    if len(encoded) > maximum or (not empty and not value.strip()) or '\x00' in value:
        raise CoreError('invalid_knowledge_input', f'{label} chưa hợp lệ hoặc quá dài.')
    return value


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}', value):
        raise CoreError('invalid_knowledge_identity', 'Mã định danh hoặc mã thao tác chưa hợp lệ.')
    return value


def version_precondition(value):
    if type(value) is not int or value < 1:
        raise CoreError('invalid_revision', 'Phiên bản cần là số nguyên dương, không phải giá trị đúng/sai hoặc số thập phân.')
    return value


class KnowledgeService:
    def __init__(self, repo):
        self.repo = repo
        self.fault_hook = None
        with repo.connection() as db:
            require_schema(db)

    @staticmethod
    def _active(db, actor):
        if not isinstance(actor, str) or not db.execute(
                'SELECT 1 FROM v03_accounts WHERE id=? AND active=1', (actor,)).fetchone():
            raise CoreError('knowledge_forbidden', 'Không có quyền đọc nội dung này.', 403)

    @staticmethod
    def _writer(db, actor):
        KnowledgeCatalog._authority(db, actor, 'curator')

    def _fault(self, point):
        if self.fault_hook:
            self.fault_hook(point)

    @staticmethod
    def _rights_head(db, source_id):
        head = db.execute('SELECT * FROM kp_source_rights_heads WHERE source_id=?', (source_id,)).fetchone()
        if head is None:
            if db.execute('SELECT 1 FROM kp_source_rights_events WHERE source_id=?', (source_id,)).fetchone():
                raise CoreError('knowledge_integrity_error', 'Thiếu head của chuỗi quyền đã ghi; cần đối soát.', 409)
            return None
        row = db.execute('SELECT * FROM kp_source_rights_events WHERE id=? AND source_id=? AND version=?',
                          (head['event_id'], source_id, head['version'])).fetchone()
        if row is None or db.execute('SELECT 1 FROM kp_source_rights_events WHERE source_id=? AND previous_id=?',
                                     (source_id, head['event_id'])).fetchone():
            raise CoreError('knowledge_integrity_error', 'Head quyền nguồn không còn là quyết định cuối chuỗi; cần đối soát.', 409)
        return {**dict(head), **dict(row)}

    def _source_read(self, db, actor, source_id, *, export=False):
        self._active(db, actor)
        source = db.execute('SELECT usage_scope,domain,jurisdiction FROM pol_sources WHERE id=?', (source_id,)).fetchone()
        row = self._rights_head(db, source_id)
        if (source is None or tuple(source) != ('public', DOMAIN, 'VN-HN') or row is None
                or not row['allow_read'] or export and not row['allow_export']):
            raise CoreError('knowledge_read_denied', 'Nguồn chưa có quyền sử dụng hoặc quyền đã bị thu hồi.', 403)
        return dict(row)

    def _resolve(self, db, actor, ref, *, export=False):
        if not isinstance(ref, dict):
            raise CoreError('invalid_evidence', 'Căn cứ cần đúng loại và phiên bản.')
        kind = ref.get('kind')
        if isinstance(kind, str) and kind.startswith('pipeline_'):
            from .pipeline import resolve_pipeline_reference
            return resolve_pipeline_reference(self, db, actor, ref, export=export)
        if kind == 'policy_source_chunk':
            if set(ref) != {'kind', 'chunk_id', 'snapshot_id', 'source_id', 'quote', 'quote_hash', 'span_hash'}:
                raise CoreError('invalid_evidence', 'Hợp đồng căn cứ chưa đủ hoặc có trường ngoài phạm vi.')
            for key in ('chunk_id', 'snapshot_id', 'source_id'):
                identifier(ref[key])
            row = db.execute('SELECT c.*,s.source_id FROM pol_chunks c JOIN pol_source_snapshots s '
                             'ON s.id=c.snapshot_id WHERE c.id=?', (ref['chunk_id'],)).fetchone()
            if row is None:
                raise CoreError('evidence_not_found', 'Không tìm thấy căn cứ được phép.', 404)
            self._source_read(db, actor, row['source_id'], export=export)
            quote = ref['quote']
            if (row['snapshot_id'] != ref['snapshot_id'] or row['source_id'] != ref['source_id']
                    or row['span_hash'] != ref['span_hash'] or not isinstance(quote, str) or not quote
                    or quote not in row['text_original']
                    or hashlib.sha256(quote.encode()).hexdigest() != ref['quote_hash']):
                raise CoreError('evidence_mismatch', 'Trích dẫn hoặc phiên bản không khớp nguồn gốc.')
            return {row['source_id']}
        if kind == 'policy_member':
            if set(ref) != {'kind', 'member_id', 'content_hash'}:
                raise CoreError('invalid_evidence', 'Hợp đồng khẳng định chưa hợp lệ.')
            identifier(ref['member_id'])
            member = KnowledgeCatalog._member(db, ref['member_id'], ref['content_hash'])
            sources = set()
            for binding in json.loads(member['evidence_json']):
                bound = {'kind': 'policy_source_chunk', 'chunk_id': binding['chunk_id'],
                         'snapshot_id': binding['source_snapshot_id'], 'source_id': binding['source_id'],
                         'quote': binding['quote_original'], 'quote_hash': binding['quote_original_hash'],
                         'span_hash': binding['span_hash']}
                sources.update(self._resolve(db, actor, bound, export=export))
            if not sources:
                raise CoreError('invalid_evidence', 'Khẳng định chưa có bằng chứng gốc.')
            return sources
        # No private SSOT/file refs and no wiki-as-source loop in the public writer.
        raise CoreError('unsupported_evidence_kind', 'Chỉ nhận căn cứ nguồn công khai có kiểu; không nhận hồ sơ riêng hoặc wiki làm luật gốc.')

    def evidence_ref(self, actor, chunk_id, quote):
        with self.repo.connection() as db:
            row = db.execute('SELECT c.*,s.source_id FROM pol_chunks c JOIN pol_source_snapshots s '
                             'ON s.id=c.snapshot_id WHERE c.id=?', (identifier(chunk_id),)).fetchone()
            if row is None:
                raise CoreError('evidence_not_found', 'Không tìm thấy căn cứ được phép.', 404)
            self._source_read(db, actor, row['source_id'])
            ref = {'kind': 'policy_source_chunk', 'chunk_id': row['id'], 'snapshot_id': row['snapshot_id'],
                   'source_id': row['source_id'], 'quote': text(quote, 'Trích dẫn', 40000),
                   'quote_hash': hashlib.sha256(quote.encode()).hexdigest(), 'span_hash': row['span_hash']}
            self._resolve(db, actor, ref)
            return ref

    @staticmethod
    def _page_contract(db, page_id):
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='kp_page_contracts'").fetchone():
            return 'knowledge-page/1'
        contract=db.execute('SELECT contract_kind FROM kp_page_contracts WHERE page_id=?',(page_id,)).fetchone()
        if contract is not None:
            if contract[0]!='knowledge-candidate/1':
                raise CoreError('knowledge_integrity_error','Loại hợp đồng trang chưa được hỗ trợ.',409)
            return contract[0]
        if db.execute('SELECT 1 FROM kp_candidate_bindings b JOIN kp_wiki_revisions r ON r.id=b.revision_id WHERE r.page_id=?',(page_id,)).fetchone():
            raise CoreError('knowledge_integrity_error','Trang có lịch sử candidate nhưng thiếu hợp đồng identity; cần đối soát.',409)
        return 'knowledge-page/1'

    def _page_read(self, db, actor, page_id, revision_id=None, *, export=False):
        # Every facade, including a bare M1 service on an M2 database, obeys the
        # immutable target contract. Never downgrade a typed candidate to M1.
        base=self._page_read_base(db,actor,page_id,revision_id,export=export)
        if self._page_contract(db,page_id)=='knowledge-candidate/1':
            from .pipeline import PipelineService
            return PipelineService._candidate_read(self,db,actor,page_id,revision_id,export=export)
        return base

    def _page_read_base(self, db, actor, page_id, revision_id=None, *, export=False):
        self._active(db, actor)
        page = db.execute('SELECT * FROM kp_wiki_pages WHERE id=?', (page_id,)).fetchone()
        allowed=bool(page and (page['created_by']==actor or KnowledgeCatalog._has_global_authority(db,actor,'curator')))
        if page and not allowed:
            from .governance import scoped_wiki_read
            allowed=scoped_wiki_read(db,actor,page,revision_id or page['head_revision_id'])
        if page and not allowed:
            from .serving import historical_public_revision
            allowed=historical_public_revision(db,page,revision_id or page['head_revision_id'])
        if not page or not allowed:
            raise CoreError('knowledge_not_found', 'Không tìm thấy trang tri thức được phép.', 404)
        head = db.execute("SELECT * FROM kp_knowledge_events WHERE id=? AND target_kind='wiki' AND target_id=?",
                           (page['event_head_id'], page_id)).fetchone()
        if head is None:
            raise CoreError('knowledge_integrity_error', 'Chuỗi quyết định của trang không khớp; cần đối soát.', 409)
        try:
            state = json.loads(head['payload_json'])
        except (TypeError, ValueError) as exc:
            raise CoreError('knowledge_integrity_error', 'Trạng thái sự kiện không đọc được; cần đối soát.', 409) from exc
        if (head['revision_id'] != page['head_revision_id'] or state.get('aggregate_version') != page['version']
                or state.get('lifecycle') != page['lifecycle'] or state.get('head_revision_id') != page['head_revision_id']
                or db.execute("SELECT 1 FROM kp_knowledge_events WHERE target_kind='wiki' AND target_id=? AND previous_id=?",
                              (page_id, head['id'])).fetchone()):
            raise CoreError('knowledge_integrity_error', 'Head không khớp trạng thái hoặc đã có quyết định tiếp theo; cần đối soát.', 409)
        revision = db.execute('SELECT * FROM kp_wiki_revisions WHERE page_id=? AND id=?',
                              (page_id, revision_id or page['head_revision_id'])).fetchone()
        if not revision:
            raise CoreError('knowledge_not_found', 'Không tìm thấy phiên bản được phép.', 404)
        evidence = json.loads(revision['evidence_json'])
        for ref in evidence:
            self._resolve(db, actor, ref, export=export)
        payload = {key: revision[key] for key in ('title', 'body', 'page_kind', 'language', 'recipe_version')}
        payload['evidence'] = evidence
        if (hashlib.sha256(revision['body'].encode()).hexdigest() != revision['body_hash']
                or digest(payload) != revision['content_hash']):
            raise CoreError('knowledge_integrity_error', 'Nội dung phiên bản không khớp hash đã lưu; cần đối soát, chưa dùng trang này.', 409)
        value = {**dict(revision), 'revision_id': revision['id'], 'page_id': page['id'],
                 'policy_id': page['policy_id'], 'domain': page['domain'], 'version': page['version'],
                 'lifecycle': page['lifecycle'], 'evidence': evidence, 'publication_state': 'not_published'}
        value.pop('evidence_json')
        return value

    def get_page(self, actor, page_id, *, revision_id=None):
        if revision_id is not None:
            identifier(revision_id)
        with self.repo.connection() as db:
            return self._page_read(db, actor, identifier(page_id), revision_id)

    def _replay(self, db, actor, kind, operation, request):
        self._active(db, actor)
        identifier(operation)
        try:
            hashed = digest(request)
        except (TypeError, ValueError) as exc:
            raise CoreError('invalid_knowledge_input', 'Dữ liệu lệnh chưa đúng định dạng.') from exc
        row = db.execute('SELECT * FROM kp_knowledge_operations WHERE actor_id=? AND domain=? AND kind=? AND operation_id=?',
                          (actor, DOMAIN, kind, operation)).fetchone()
        if row is None:
            return hashed, None
        if row['request_hash'] != hashed or row['request_json'] != canonical(request):
            raise CoreError('idempotency_conflict', 'Mã thao tác đã được dùng cho dữ liệu hoặc phạm vi khác.', 409)
        values = [row[key] for key in ('actor_id', 'domain', 'kind', 'operation_id', 'request_hash',
                                      'request_json', 'response_json', 'read_refs_json', 'created_at')]
        if digest(values) != row['receipt_hash']:
            raise CoreError('knowledge_integrity_error', 'Biên nhận không khớp hash đã ghi; cần đối soát, chưa trả nội dung.', 409)
        for ref in json.loads(row['read_refs_json']):
            if ref['kind'] == 'wiki_revision':
                self._page_read(db, actor, ref['page_id'], ref['revision_id'])
            elif ref['kind'] == 'rights_control':
                # Control-plane receipt contains no source title/content. It
                # still requires the original actor to remain active, checked above.
                pass
            else:
                self._resolve(db, actor, ref)
        return hashed, json.loads(row['response_json'])

    def _save(self, db, actor, kind, operation, request, hashed, response, refs):
        self._fault('before_receipt')
        values = [actor, DOMAIN, kind, operation, hashed, canonical(request), canonical(response), canonical(refs), now_iso()]
        db.execute('INSERT INTO kp_knowledge_operations VALUES(?,?,?,?,?,?,?,?,?,?)', (*values, digest(values)))

    def _event(self, db, actor, target_kind, target_id, revision_id, event_type, payload):
        # An aggregate event head is distinct from the content revision parent.
        # Lifecycle/review events cannot infer causality from a content tree.
        previous = None
        if target_kind == 'wiki':
            head = db.execute('SELECT * FROM kp_wiki_pages WHERE id=?', (target_id,)).fetchone()
            if head is None:
                raise CoreError('knowledge_integrity_error', 'Không tìm thấy aggregate của sự kiện.', 409)
            previous = head['event_head_id']
            payload = {**payload, 'aggregate_version': head['version'], 'lifecycle': head['lifecycle'],
                       'head_revision_id': head['head_revision_id']}
            if previous and not db.execute("SELECT 1 FROM kp_knowledge_events WHERE id=? AND target_kind='wiki' AND target_id=?",
                                            (previous, target_id)).fetchone():
                raise CoreError('knowledge_integrity_error', 'Sự kiện trước không thuộc trang này.', 409)
            if not previous and event_type != 'created':
                raise CoreError('knowledge_integrity_error', 'Thiếu sự kiện trước; không tạo lại lịch sử ngầm.', 409)
        elif target_kind == 'rights':
            parent = db.execute('SELECT previous_id FROM kp_source_rights_events WHERE id=?', (revision_id,)).fetchone()[0]
            if parent:
                prior = db.execute("SELECT id FROM kp_knowledge_events WHERE target_kind='rights' AND revision_id=?", (parent,)).fetchone()
                previous = prior[0] if prior else None
                if previous is None:
                    raise CoreError('knowledge_integrity_error', 'Thiếu sự kiện quyền nguồn trước đó.', 409)
        else:
            raise CoreError('unsupported_event_target', 'Chưa bật writer cho loại aggregate này.')
        event = new_id('kpe')
        db.execute('INSERT INTO kp_knowledge_events VALUES(?,?,?,?,?,?,?,?,?)',
                   (event, target_kind, target_id, revision_id, actor, event_type, canonical(payload), previous, now_iso()))
        if target_kind == 'wiki':
            changed = db.execute('UPDATE kp_wiki_pages SET event_head_id=? WHERE id=? AND event_head_id IS ?',
                                  (event, target_id, previous)).rowcount
            if changed != 1:
                raise CoreError('revision_conflict', 'Chuỗi quyết định đã đổi; chưa ghi lệnh này.', 409)
        db.execute('INSERT INTO kp_pipeline_outbox(event_id,target_kind,target_id,revision_id,payload_json) VALUES(?,?,?,?,?)',
                   (event, target_kind, target_id, revision_id, canonical(payload)))

    def set_source_rights(self, actor, source_id, *, expected_version, allow_read, allow_export, reason, operation_id):
        request = dict(source_id=source_id, expected_version=expected_version, allow_read=allow_read,
                       allow_export=allow_export, reason=reason)
        kind = 'knowledge.source.rights/1'
        with self.repo.connection(write=True) as db:
            hashed, previous = self._replay(db, actor, kind, operation_id, request)
            if previous is not None:
                return previous
            self._writer(db, actor)
            identifier(source_id)
            text(reason, 'Lý do', 2000)
            if (type(expected_version) is not int or expected_version < 0 or type(allow_read) is not bool
                    or type(allow_export) is not bool or allow_export and not allow_read):
                raise CoreError('invalid_rights', 'Phiên bản và quyền nguồn chưa hợp lệ.')
            source = db.execute('SELECT usage_scope,domain,jurisdiction FROM pol_sources WHERE id=?', (source_id,)).fetchone()
            if source is None or tuple(source) != ('public', DOMAIN, 'VN-HN'):
                raise CoreError('source_not_found', 'Chưa có nguồn công khai được phép quản lý.', 404)
            head = self._rights_head(db, source_id)
            if expected_version != (head['version'] if head else 0):
                raise CoreError('revision_conflict', 'Quyền nguồn đã thay đổi; cần đọc lại trước khi sửa.', 409)
            event = new_id('kpr')
            db.execute('INSERT INTO kp_source_rights_events VALUES(?,?,?,?,?,?,?,?,?)',
                       (event, source_id, expected_version + 1, head['event_id'] if head else None,
                        int(allow_read), int(allow_export), reason, actor, now_iso()))
            db.execute('INSERT INTO kp_source_rights_heads VALUES(?,?,?) ON CONFLICT(source_id) DO UPDATE SET '
                       'event_id=excluded.event_id,version=excluded.version', (source_id, event, expected_version + 1))
            result = {'source_id': source_id, 'rights_revision_id': event, 'version': expected_version + 1,
                      'allow_read': allow_read, 'allow_export': allow_export}
            self._event(db, actor, 'rights', source_id, event, 'rights_changed', result)
            self._save(db, actor, kind, operation_id, request, hashed, result, [{'kind': 'rights_control', 'source_id': source_id}])
            return result

    def _revision(self, db, actor, page_id, title, body, evidence, page_kind, parent=None):
        text(title, 'Tiêu đề', 800)
        text(body, 'Nội dung', 100000)
        if page_kind not in {'topic', 'program', 'procedure', 'synthesis', 'gap'}:
            raise CoreError('invalid_page_kind', 'Loại trang chưa được hỗ trợ.')
        if not isinstance(evidence, list) or not 1 <= len(evidence) <= 40:
            raise CoreError('invalid_evidence', 'Trang cần từ1 đến40 căn cứ có kiểu.')
        sources = []
        for ref in evidence:
            sources.append(self._resolve(db, actor, ref))
        parent_row = db.execute('SELECT revision_no FROM kp_wiki_revisions WHERE id=? AND page_id=?',
                                (parent, page_id)).fetchone() if parent else None
        if parent and parent_row is None:
            raise CoreError('revision_conflict', 'Phiên bản gốc không thuộc trang này.', 409)
        revision = new_id('kpv')
        body_hash = hashlib.sha256(body.encode()).hexdigest()
        payload = dict(title=title, body=body, evidence=evidence, page_kind=page_kind, language='vi', recipe_version='wiki-manual/1')
        db.execute('INSERT INTO kp_wiki_revisions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                   (revision, page_id, parent, parent_row[0] + 1 if parent_row else 1, page_kind, title, body,
                    body_hash, digest(payload), 'vi', 'wiki-manual/1', canonical(evidence), actor, now_iso()))
        for ordinal, (ref, source_ids) in enumerate(zip(evidence, sources)):
            for source_id in sorted(source_ids):
                db.execute('INSERT INTO kp_wiki_dependencies VALUES(?,?,?,?)', (revision, ordinal, source_id, canonical(ref)))
        self._fault('after_revision')
        return revision

    def create_page(self, actor, *, policy_id, title, body, evidence, operation_id, page_kind='topic'):
        request = dict(policy_id=policy_id, title=title, body=body, evidence=evidence, page_kind=page_kind)
        kind = 'knowledge.page.create/1'
        with self.repo.connection(write=True) as db:
            hashed, previous = self._replay(db, actor, kind, operation_id, request)
            if previous is not None:
                return previous
            self._writer(db, actor)
            if isinstance(evidence,list) and any(isinstance(r,dict) and str(r.get('kind','')).startswith('pipeline_') for r in evidence):
                raise CoreError('candidate_contract_required','Nguồn M2 cần tạo candidate có binding từng nhận định; chưa ghi trang M1.')
            identifier(policy_id)
            page = new_id('kpp')
            db.execute("INSERT INTO kp_wiki_pages VALUES(?,'hanoi_policy','VN-HN',?,?,?,NULL,1,'active',NULL)",
                       (page, policy_id, actor, now_iso()))
            revision = self._revision(db, actor, page, title, body, evidence, page_kind)
            db.execute('UPDATE kp_wiki_pages SET head_revision_id=? WHERE id=?', (revision, page))
            self._event(db, actor, 'wiki', page, revision, 'created', {'page_id': page, 'revision_id': revision})
            result = self._page_read(db, actor, page)
            self._save(db, actor, kind, operation_id, request, hashed, result,
                       [{'kind': 'wiki_revision', 'page_id': page, 'revision_id': revision}])
            return result

    def edit_page(self, actor, page_id, *, expected_revision_id, expected_version, title, body, evidence, operation_id,
                  page_kind='topic'):
        request = dict(page_id=page_id, expected_revision_id=expected_revision_id, expected_version=expected_version,
                       title=title, body=body, evidence=evidence, page_kind=page_kind)
        kind = 'knowledge.page.edit/1'
        with self.repo.connection(write=True) as db:
            hashed, previous = self._replay(db, actor, kind, operation_id, request)
            if previous is not None:
                return previous
            current = self._page_read(db, actor, identifier(page_id))
            self._writer(db, actor)
            if self._page_contract(db,page_id)!='knowledge-page/1' or (isinstance(evidence,list) and any(isinstance(r,dict) and str(r.get('kind','')).startswith('pipeline_') for r in evidence)):
                raise CoreError('candidate_contract_required','Trang candidate cần sửa qua hợp đồng binding M2; nháp chưa bị ghi đè.',409)
            version_precondition(expected_version)
            identifier(expected_revision_id)
            if current['lifecycle'] != 'active' or current['version'] != expected_version or current['revision_id'] != expected_revision_id:
                raise CoreError('revision_conflict', 'Trang hoặc phiên bản đã thay đổi; bản nháp chưa được ghi.', 409)
            revision = self._revision(db, actor, page_id, title, body, evidence, page_kind, expected_revision_id)
            db.execute('UPDATE kp_wiki_pages SET head_revision_id=?,version=version+1 WHERE id=?', (revision, page_id))
            self._event(db, actor, 'wiki', page_id, revision, 'edited', {'page_id': page_id, 'revision_id': revision})
            result = self._page_read(db, actor, page_id)
            self._save(db, actor, kind, operation_id, request, hashed, result,
                       [{'kind': 'wiki_revision', 'page_id': page_id, 'revision_id': revision},
                        {'kind': 'wiki_revision', 'page_id': page_id, 'revision_id': expected_revision_id}])
            return result

    def archive_page(self, actor, page_id, *, expected_version, operation_id):
        request = dict(page_id=page_id, expected_version=expected_version)
        kind = 'knowledge.page.archive/1'
        with self.repo.connection(write=True) as db:
            hashed, previous = self._replay(db, actor, kind, operation_id, request)
            if previous is not None:
                return previous
            current = self._page_read(db, actor, identifier(page_id))
            self._writer(db, actor)
            version_precondition(expected_version)
            if current['lifecycle'] != 'active' or current['version'] != expected_version:
                raise CoreError('revision_conflict', 'Trạng thái trang đã thay đổi.', 409)
            db.execute("UPDATE kp_wiki_pages SET lifecycle='archived',version=version+1 WHERE id=?", (page_id,))
            self._event(db, actor, 'wiki', page_id, current['revision_id'], 'archived', {'page_id': page_id})
            result = self._page_read(db, actor, page_id)
            self._save(db, actor, kind, operation_id, request, hashed, result,
                       [{'kind': 'wiki_revision', 'page_id': page_id, 'revision_id': current['revision_id']}])
            return result
