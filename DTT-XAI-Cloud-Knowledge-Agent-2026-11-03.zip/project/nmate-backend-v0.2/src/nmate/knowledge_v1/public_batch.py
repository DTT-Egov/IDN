"""Explicit M3 operator job. Prepare is offline; execute requires the sealed D06.

No background loop, retries, expert decisions, enterprise import or MAIN write.
"""
from contextlib import closing
from datetime import datetime,timedelta,timezone
from pathlib import Path
import hashlib,json,sqlite3
from nmate.v03.core import CoreRepository,CoreError,now_iso,new_id
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.core_v1.runtime_schema import open_readonly,canonical,digest,schema_objects
from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.domain_gateway import PublicDomainScope,SLOTS
from .operator import install_on_clone
from .operator_m2 import install_m2_on_clone
from .operator_m3 import install_m3_on_clone
from .governance import WikiGovernance
from .ai_proposals import PROPOSAL_SCHEMA,record_proposal

APPROVAL='D06-M3-public-knowledge-20261027-6calls-2usd'
POLICY='HN-DIGITAL-CONSULTING-2026'
OPERATOR='operator_m3_public_corpus'
# Operator-owned local-machine namespace, deliberately outside any caller-
# chosen staging directory or frozen bundle. Tests redirect only this private seam.
_APPROVAL_REGISTRY_DIR=Path(r'C:\Enterprise AI\app\output\policy-knowledge-M3-2026-10-27\approval-registry')
PAGES={'HN-NOTICE-2026-14-ATTACHMENT':{2,9,10,11},'VN-DECREE-80-2021-SCAN':{6,26,28},'VN-CIRCULAR-06-2022-GAZETTE':{6}}

def write_json(path,value):
    # Local operator evidence. Never overwrite a conflicting approval/grant.
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def prepare(main_database,directory):
    directory=Path(directory).resolve();directory.mkdir(parents=True,exist_ok=True)
    manifest=directory/'prepared.json'
    if manifest.exists():
        value=json.loads(manifest.read_text(encoding='utf-8'))
        if value['approval_id']!=APPROVAL: raise CoreError('APPROVAL_CONFLICT','Namespace đã thuộc batch khác.')
        return value
    database=directory/'public-only.sqlite'
    if database.exists(): raise CoreError('STAGING_INCOMPLETE','Kho đã có nhưng chưa có biên nhận chuẩn bị; cần đối soát, chưa tự tạo lại.',409)
    with closing(open_readonly(main_database)) as db:
        db.row_factory=sqlite3.Row
        expert=db.execute('SELECT id,username,active,created_at FROM v03_accounts WHERE username=?',('trung@dtt.vn',)).fetchone()
        if expert is None or not expert['active']: raise CoreError('ACCOUNT_NOT_READY','Không tìm thấy tài khoản chuyên gia đang hoạt động.',409)
        # Directory metadata only. Never copy a password, login token or SSOT.
        identity=dict(expert)
        scopes=[dict(r) for r in db.execute('SELECT role,domain,policy_id,source_id,revoked_at FROM pol_knowledge_role_scopes WHERE account_id=?',(expert['id'],))]
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='kp_source_rights_heads'").fetchone():
            from .service import KnowledgeService
            reader=object.__new__(KnowledgeService)
            for sid in PAGES:
                history=db.execute('SELECT 1 FROM kp_source_rights_events WHERE source_id=?',(sid,)).fetchone()
                head=db.execute('SELECT 1 FROM kp_source_rights_heads WHERE source_id=?',(sid,)).fetchone()
                if history or head:
                    # Same current READ/export + causal leaf verifier as every
                    # other consumer. Never reinterpret a rewound allow head.
                    reader._source_read(db,identity['id'],sid,export=True)
    repo=CoreRepository(database);catalog=KnowledgeCatalog(repo)
    with repo.connection(write=True) as db:
        db.execute('INSERT INTO v03_accounts VALUES(?,?,?,?,1)',(identity['id'],identity['username'],'!non-login-directory-shadow',identity['created_at']))
        db.execute('INSERT INTO v03_accounts VALUES(?,?,?,?,1)',(OPERATOR,OPERATOR,'!non-login-operator-principal',now_iso()))
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'curator','hanoi_policy',?,?,NULL)",(OPERATOR,APPROVAL,now_iso()))
    catalog.bootstrap_digital_source_pack()
    install_on_clone(database,backup_path=directory/'schema-before-m1.sqlite')
    install_m2_on_clone(database,backup_path=directory/'schema-before-m2.sqlite')
    install_m3_on_clone(database,backup_path=directory/'schema-before-m3.sqlite')
    service=WikiGovernance(repo)
    pack_path=Path(__file__).resolve().parents[1]/'policy_v1/data/hanoi_digital_source_pack.json'
    pack=json.loads(pack_path.read_text(encoding='utf-8'));refs=[];corpus=[]
    for document in pack['documents']:
        sid=document['source_id']
        if sid not in PAGES: continue
        service.set_source_rights(OPERATOR,sid,expected_version=0,allow_read=True,allow_export=True,
            reason=APPROVAL+'; operator import of public pack only; not legal review',operation_id='m3-rights-'+sid)
        service.configure_source(OPERATOR,sid,expected_version=0,operation_id='m3-config-'+sid,manifest={
            'url':document['url'],'mime_type':'text/plain','language':'vi','operator':OPERATOR,
            'document_role':'stored_public_transcript_excerpt',
            'rights_basis':APPROVAL+'; public source pack; original hash '+document['raw_sha256'],
            'required_parts':['signed_authoritative_text','amendments','application_window','full_legal_context'],
            'gaps':['legal_currency_unverified','signature_or_identity_unverified','partial_excerpts_not_complete_policy'],
            'network_enabled':False})
        pages=[p for p in document['pages'] if p['page'] in PAGES[sid]]
        transcript='\n\n'.join('[Trang '+str(p['page'])+']\n'+p['text'] for p in pages)
        raw=transcript.encode('utf-8')
        rendition=service.acquire_bytes(OPERATOR,sid,expected_version=1,filename=sid+'-transcript.txt',mime_type='text/plain',raw=raw,operation_id='m3-acquire-'+sid)
        ex=service.extract_local(OPERATOR,rendition['rendition_id'],operation_id='m3-extract-'+sid)
        if ex['quality']!='text_extracted': raise CoreError('SOURCE_NOT_READY','Trích đoạn chưa đọc được; chưa gọi AI.',409)
        for chunk in ex['chunks']:
            refs.append(service.pipeline_evidence(identity['id'],chunk['id'],chunk['text']))
        corpus.append(dict(source_id=sid,original_raw_sha256=document['raw_sha256'],original_text_sha256=document['canonical_text_sha256'],
            selected_pages=[p['page'] for p in pages],transcript_sha256=hashlib.sha256(raw).hexdigest(),rendition_id=rendition['rendition_id'],
            extraction_id=ex['extraction_id'],legal_currency='not_verified',complete_policy=False))
    value=dict(approval_id=APPROVAL,prepared_at=now_iso(),database=str(database),account_id=identity['id'],
        invocation=dict(mode='operator_approved_batch',initiated_by='project_owner_operator',on_behalf_of_account_id=identity['id'],approval_receipt_id=APPROVAL),
        directory_origin=dict(kind='read_only_account_metadata_export',realm='isolated_M3_public_operator_batch',identity=identity,recorded_scopes=scopes,live_rbac_sync=False,credentials_copied=False),
        corpus=corpus,source_refs=refs,corpus_hash=digest(refs),provider_calls=0,review_events=0,release_events=0)
    # Manifest/body upper bounds are preflighted without an SDK/key/reservation.
    from nmate.core_v1.domain_gateway import DomainAuthority
    gw=ModelGateway(repo,enabled=False)
    port=DomainAuthority(gw,service,identity['id'],PublicDomainScope('hanoi_policy',POLICY),refs,'policy-knowledge-draft/1','standard')
    port.bind_slot('S1','policy_knowledge_build','NOT_ISSUED')
    body=port.compile_public_input()
    if len(canonical(body).encode())>16000: raise CoreError('INPUT_LIMIT','Corpus quá dài để còn chỗ cho hai đề xuất; cần chia batch trước paid.',413)
    instance=dict(id=new_id('domain_batch'),approval_id=APPROVAL,scope_id=PublicDomainScope('hanoi_policy',POLICY).key,
                  account_id=identity['id'],corpus_hash=value['corpus_hash'],created_at=now_iso())
    with repo.connection(write=True) as db:
        db.execute('INSERT INTO pol_wiki_batch_instances VALUES(?,?,?,?,?,?,?)',(*instance.values(),digest(instance)))
    value['batch_instance_id']=instance['id']
    with repo.connection() as db: value['schema_sha256']=digest(schema_objects(db))
    write_json(manifest,value)
    return value


def existing_repository(prepared):
    database=Path(prepared['database']).resolve(strict=True)
    with closing(open_readonly(database)) as db:
        db.row_factory=sqlite3.Row
        if digest(schema_objects(db))!=prepared.get('schema_sha256'):
            from .operator_m6 import require_extension
            require_extension(db,original_schema_hash=prepared.get('schema_sha256'))
        from .operator_m3 import require_m3
        require_m3(db)
        instance=db.execute('SELECT * FROM pol_wiki_batch_instances WHERE id=?',(prepared.get('batch_instance_id'),)).fetchone()
        if (not instance or digest({k:instance[k] for k in instance.keys() if k!='record_hash'})!=instance['record_hash'] or
            instance['approval_id']!=APPROVAL or instance['account_id']!=prepared['account_id'] or
            instance['scope_id']!=PublicDomainScope('hanoi_policy',POLICY).key or instance['corpus_hash']!=prepared['corpus_hash']):
            raise CoreError('STAGING_INSTANCE_CHANGED','Instance kho không khớp chuẩn bị; cần đối soát, chưa gọi AI.',409)
    class ExistingRepository(CoreRepository):
        def __init__(self):
            self.db_path=str(database);self.managed_runtime=True;self._memory_anchor=None;self._uri=False
    return ExistingRepository()


def validate_approved_inputs(prepared,repo):
    """Prepared files are evidence, not authority to widen the user's approval."""
    if prepared.get('approval_id')!=APPROVAL: raise CoreError('APPROVAL_CONFLICT','Khác phê duyệt batch.',409)
    pack=json.loads((Path(__file__).resolve().parents[1]/'policy_v1/data/hanoi_digital_source_pack.json').read_text(encoding='utf-8'))
    documents={d['source_id']:d for d in pack['documents'] if d['source_id'] in PAGES}
    if {c['source_id'] for c in prepared['corpus']}!=set(PAGES): raise CoreError('APPROVAL_CONFLICT','Tập nguồn khác phạm vi đã duyệt.',409)
    service=WikiGovernance(repo);refs=[]
    from .pipeline import rendition_read,extraction_read
    with repo.connection() as db:
        account=db.execute('SELECT username FROM v03_accounts WHERE id=? AND active=1',(prepared['account_id'],)).fetchone()
        if not account or account[0]!='trung@dtt.vn': raise CoreError('APPROVAL_CONFLICT','Khác tài khoản được giao của batch.',409)
        for corpus in prepared['corpus']:
            d=documents[corpus['source_id']]
            transcript='\n\n'.join('[Trang '+str(p['page'])+']\n'+p['text'] for p in d['pages'] if p['page'] in PAGES[d['source_id']])
            raw=rendition_read(service,db,prepared['account_id'],corpus['rendition_id'],export=True)
            ex=extraction_read(service,db,prepared['account_id'],corpus['extraction_id'],export=True)
            if (raw['raw_bytes']!=transcript.encode('utf-8') or raw['source_id']!=d['source_id'] or ex['rendition_id']!=raw['id'] or
                corpus['original_raw_sha256']!=d['raw_sha256'] or corpus['original_text_sha256']!=d['canonical_text_sha256']):
                raise CoreError('APPROVAL_CONFLICT','Bản nguồn không khớp public pack đã duyệt; chưa gửi AI.',409)
            for chunk in ex['chunks']: refs.append(service.pipeline_evidence(prepared['account_id'],chunk['id'],chunk['text']))
    if refs!=prepared['source_refs'] or digest(refs)!=prepared['corpus_hash']:
        raise CoreError('APPROVAL_CONFLICT','Trích đoạn khác corpus chuẩn bị; chưa gửi AI.',409)


def fixed_terms(prepared,expires_at):
    return dict(approval_id=APPROVAL,max_calls=6,max_cost_usd='2',
        per_role={'standard':{'max_calls':4,'max_cost_usd':'0.25'},'complex':{'max_calls':2,'max_cost_usd':'0.50'}},
        source_ids=list(PAGES),source_refs=prepared['source_refs'],expires_at=expires_at,
        invocation=dict(mode='operator_approved_batch',initiated_by='project_owner_operator',on_behalf_of_account_id=prepared['account_id'],approval_receipt_id=APPROVAL))

def bound_terms(prepared,claimed):
    terms=fixed_terms(prepared,claimed['expires_at'])
    terms['invocation']['issuance_binding']=dict(registry_dir=str(_APPROVAL_REGISTRY_DIR.resolve()),claim_hash=claimed['record_hash'],
        database_path=claimed['database_path'],batch_instance_id=prepared['batch_instance_id'])
    return terms


def issue_grant(prepared,directory):
    directory=Path(directory);path=directory/'grant-receipt.json'
    repo=existing_repository(prepared);validate_approved_inputs(prepared,repo);gateway=ModelGateway(repo,enabled=True)
    # Expiry is chosen exactly once, persisted before granting; restart cannot
    # move the approval window or reconstruct it from "now" again.
    terms_path=directory/'grant-terms.json'
    terms=json.loads(terms_path.read_text(encoding='utf-8')) if terms_path.exists() else fixed_terms(prepared,(datetime.now(timezone.utc)+timedelta(hours=48)).isoformat())
    try:
        expiry=datetime.fromisoformat(terms['expires_at']);now=datetime.now(timezone.utc)
        if expiry.tzinfo is None or expiry>now+timedelta(hours=48) or terms!=fixed_terms(prepared,terms['expires_at']): raise ValueError()
    except (KeyError,TypeError,ValueError): raise CoreError('APPROVAL_CONFLICT','Điều kiện trong file vượt hoặc khác 6 lượt/2 USD/48 giờ đã duyệt.',409) from None
    from . import approval_binding as binding
    claimed=binding.claim(_APPROVAL_REGISTRY_DIR,prepared,terms['expires_at'])
    # The exclusive claim owns the original expiry, even if the local terms
    # file was lost after a crash. It cannot move to another database instance.
    approved=fixed_terms(prepared,claimed['expires_at'])
    if terms_path.exists() and terms!=approved: raise CoreError('APPROVAL_CONFLICT','File điều kiện khác cửa đã claim; chưa cấp thêm.',409)
    terms=approved
    if not terms_path.exists():
        with terms_path.open('x',encoding='utf-8') as f: json.dump(terms,f,ensure_ascii=False,indent=2)
    completed=binding.finalized(_APPROVAL_REGISTRY_DIR,prepared,claimed)
    if completed:
        with repo.connection() as db:
            old=db.execute('SELECT id FROM core_domain_budget_grants WHERE approval_id=? AND scope_id=? AND account_id=?',(APPROVAL,PublicDomainScope('hanoi_policy',POLICY).key,prepared['account_id'])).fetchone()
        if not old or old['id']!=completed['grant_id']: raise CoreError('APPROVAL_BINDING_INTEGRITY','Grant đã hoàn tất bị thiếu/khác; không cấp lại từ bản sao cũ.',409)
    dispatched_terms=bound_terms(prepared,claimed)
    receipt=gateway.authorize_domain_budget(prepared['account_id'],PublicDomainScope('hanoi_policy',POLICY),**dispatched_terms)
    binding.finalize(_APPROVAL_REGISTRY_DIR,prepared,claimed,receipt['id'],dispatched_terms)
    if path.exists():
        previous=json.loads(path.read_text(encoding='utf-8'))
        if previous['id']!=receipt['id']: raise CoreError('APPROVAL_CONFLICT','Biên nhận cấp khác runtime; dừng đối soát.',409)
    else: write_json(path,receipt)
    return receipt


def pause_after_failure(repo,grant_id,attempt_id,*,operator,reason):
    """Operator-only stop on the existing ledger; never a second quota authority.

    No source/body read is needed to stop egress. READ recovery remains possible,
    and recording a proposal can never reactivate this lifecycle state.
    """
    if not operator or not reason: raise CoreError('INVALID_STOP','Cần ghi người vận hành và lý do dừng.')
    from .operator_m6 import has_extension
    with repo.connection() as db:extended=has_extension(db)
    if extended:
        from .batch_lifecycle import ensure_paused
        return ensure_paused(repo,grant_id,attempt_id,operator=operator,reason=reason)
    with repo.connection(write=True) as db:
        grant=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=?',(grant_id,)).fetchone()
        attempt=db.execute('SELECT * FROM core_domain_model_attempts WHERE id=? AND grant_id=?',(attempt_id,grant_id)).fetchone()
        if not grant or not attempt: raise CoreError('INVALID_STOP','Lượt dừng không thuộc hạn mức.',409)
        old=db.execute("SELECT * FROM core_domain_model_events WHERE attempt_id=? AND kind='batch_paused_admission'",(attempt_id,)).fetchone()
        if old: return dict(old)
        previous=grant['state']
        if previous=='active':
            db.execute("UPDATE core_domain_budget_grants SET state='paused_admission_review' WHERE id=? AND state='active'",(grant_id,))
        event_id=new_id('domain_event')
        detail=dict(grant_id=grant_id,operator=operator,reason=reason,previous_state=previous,
                    resulting_state='paused_admission_review' if previous=='active' else previous,
                    free_recovery_does_not_resume=True)
        db.execute('INSERT INTO core_domain_model_events VALUES(?,?,?,?,?,?)',
            (event_id,grant['scope_id'],attempt_id,'batch_paused_admission',canonical(detail),now_iso()))
        return dict(db.execute('SELECT * FROM core_domain_model_events WHERE id=?',(event_id,)).fetchone())


async def execute(directory,api_key,*,max_new_calls=6,request_fn=None):
    if type(max_new_calls) is not int or not 1<=max_new_calls<=6:
        raise CoreError('INVALID_BATCH_LIMIT','Cần giới hạn1–6lượt mới; không tự tăng hoặc thử lại.')
    directory=Path(directory);prepared=json.loads((directory/'prepared.json').read_text(encoding='utf-8'))
    grant=json.loads((directory/'grant-receipt.json').read_text(encoding='utf-8'))
    if prepared['approval_id']!=APPROVAL or grant['approval_id']!=APPROVAL or digest(prepared['source_refs'])!=prepared['corpus_hash']:
        raise CoreError('APPROVAL_CONFLICT','Corpus/phê duyệt không khớp; chưa gửi AI.',409)
    repo=existing_repository(prepared);validate_approved_inputs(prepared,repo);service=WikiGovernance(repo)
    from . import approval_binding as binding
    claimed=binding.verify_claim(_APPROVAL_REGISTRY_DIR,prepared)
    complete=binding.finalized(_APPROVAL_REGISTRY_DIR,prepared,claimed)
    terms=bound_terms(prepared,claimed)
    if not complete or complete.get('grant_id')!=grant['id'] or complete.get('terms_hash')!=digest(terms):
        raise CoreError('APPROVAL_BINDING_INTEGRITY','Chưa có grant hoàn tất đúng kho; chưa gửi AI.',409)
    gateway=ModelGateway(repo,api_key=api_key,enabled=True,request_fn=request_fn)
    output=[]
    with repo.connection() as db:
        lifecycle=db.execute('SELECT state FROM core_domain_budget_grants WHERE id=?',(grant['id'],)).fetchone()
        if not lifecycle or lifecycle['state']!='active':
            return [dict(state='batch_stopped_no_retry',grant_state=lifecycle['state'] if lifecycle else 'missing')]
        prior=db.execute('SELECT a.id,a.task_id,a.state,a.validation_state,p.id AS proposal_id FROM core_domain_model_attempts a LEFT JOIN pol_wiki_ai_proposals p ON p.attempt_id=a.id WHERE a.grant_id=?',(grant['id'],)).fetchall()
        blocked=[r for r in prior if r['state']!='response_received' or r['validation_state']!='accepted' or not r['proposal_id']]
        from .batch_lifecycle import read as read_lifecycle
        from .independent_branch import current_permit
        grant_row=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=?',(grant['id'],)).fetchone()
        try:
            permit=current_permit(read_lifecycle(db,grant_row))
        except CoreError as exc:
            # Preserve the operator's finite stop-result contract. A broken
            # causal chain is never repaired or paused anew by this read.
            return [dict(state='batch_stopped_no_retry',code=exc.code)]
    if blocked and not (permit and [r['task_id'] for r in blocked]==['O1']):
        # An uncertain/invalid result is a durable batch stop, not a transient
        # loop break. Restart/status/recovery must never consume another slot.
        for r in blocked:
            pause_after_failure(repo,grant['id'],r['id'],operator=OPERATOR,reason='restart found incomplete/invalid handoff')
        return [dict(slot=r['task_id'],state='batch_stopped_no_retry',attempt_id=r['id']) for r in blocked]
    new_calls=0
    for slot,(role,recipe,_) in SLOTS.items():
        if permit and slot!=permit['target_slot']:continue
        # A rerun observes old attempts and never resubmits a slot, even failure.
        with repo.connection() as db:
            old=db.execute('SELECT id,state,validation_state FROM core_domain_model_attempts WHERE grant_id=? AND task_id=?',(grant['id'],slot)).fetchone()
        if old:
            output.append({'slot':slot,'state':'already_recorded_no_retry','attempt_id':old['id']});continue
        if new_calls>=max_new_calls:break
        try:
            r=await gateway.call_domain_once(source_reader=service,account_id=prepared['account_id'],scope=PublicDomainScope('hanoi_policy',POLICY),
                operation_id=APPROVAL+'-'+slot,task_id=slot,role=role,purpose='policy_knowledge_build',source_refs=prepared['source_refs'],
                output_schema=PROPOSAL_SCHEMA,budget_grant_id=grant['id'],max_output_tokens=2048 if role=='standard' else 3072,recipe=recipe)
            proposal=record_proposal(service,gateway,prepared['account_id'],r['attempt_id'])
            new_calls+=1
            output.append(dict(slot=slot,state='proposal_saved',attempt_id=r['attempt_id'],model=r['model'],usage=r['usage'],estimated_usd=r['estimated_usd'],proposal=proposal))
        except CoreError as exc:
            with repo.connection() as db:
                failed=db.execute('SELECT id FROM core_domain_model_attempts WHERE grant_id=? AND task_id=?',(grant['id'],slot)).fetchone()
            if failed:
                pause_after_failure(repo,grant['id'],failed['id'],operator=OPERATOR,reason='batch failure: '+exc.code)
            output.append(dict(slot=slot,state='stopped_no_retry',code=exc.code,message=str(exc)))
            # Stop batch on any uncertain/invalid result. Remaining slots are
            # not silently used as repairs, alternate models or extra attempts.
            write_json(directory/'batch-result.json',output)
            break
        write_json(directory/'batch-result.json',output)
    return output
