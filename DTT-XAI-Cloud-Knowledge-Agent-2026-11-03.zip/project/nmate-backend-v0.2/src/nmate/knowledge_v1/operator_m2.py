"""Explicit offline M1→M2 operator, same lock/backup/receipt authority."""
from contextlib import closing
from functools import lru_cache
from pathlib import Path
import sqlite3
from .schema_m2 import M2_STATEMENTS
from .operator import expected_objects
from nmate.core_v1.runtime_schema import schema_objects, open_readonly, verify_runtime_database
from nmate.core_v1.schema_lifecycle import create_plan, apply_plan
from nmate.v03.core import CoreError


@lru_cache(maxsize=1)
def expected_m2_objects():
    from .schema import M1_STATEMENTS
    with closing(sqlite3.connect(':memory:')) as db:
        for sql in M1_STATEMENTS + M2_STATEMENTS: db.execute(sql)
        return schema_objects(db)


def require_m2(db):
    actual = {r['name']:r for r in schema_objects(db) if r['name'].startswith('kp_')}
    if actual != {r['name']:r for r in expected_m2_objects()}:
        raise CoreError('knowledge_schema_not_ready','Cần operator kiểm schema M2 trên bản sao trước.',409)


def target_m2_contract():
    from nmate.core_v1.runtime_schema import read_runtime_contract
    c=read_runtime_contract()
    c['version']='nmate-main-20261026-knowledge-m2'
    c['required_objects']=sorted(c['required_objects']+expected_m2_objects(),key=lambda x:(x['type'],x['name']))
    return c


def install_m2_on_clone(database, *, backup_path):
    from .operator import target_runtime_contract
    source=Path(__file__).resolve().parents[2]
    plan=create_plan(database,version='knowledge-m2-20261026',statements=M2_STATEMENTS,
        source_root=source,dependency_files=['nmate/knowledge_v1/schema_m2.py','nmate/knowledge_v1/operator_m2.py'])
    with closing(open_readonly(database)) as original, closing(sqlite3.connect(':memory:')) as prepared:
        actual={r['name']:r for r in schema_objects(original) if r['name'].startswith('kp_')}
        m2={r['name']:r for r in expected_m2_objects()}
        m1={r['name']:r for r in expected_objects()}
        if actual not in (m1,m2): raise CoreError('knowledge_schema_not_ready','Baseline M1/M2 không khớp.',409)
        # Full-main target is verified against exact generated object/seed contract
        # without temporarily replacing the active app contract file.
        if original.execute("SELECT 1 FROM sqlite_master WHERE name='v04_conversations'").fetchone():
            import json
            import tempfile
            with tempfile.TemporaryDirectory(prefix='knowledge-contract-') as folder:
                contract=Path(folder)/'target.json'
                contract.write_text(json.dumps(target_runtime_contract() if actual==m1 else target_m2_contract()),encoding='utf-8')
                verify_runtime_database(database,contract_path=contract)
        original.backup(prepared)
        if actual==m1:
            for sql in M2_STATEMENTS: prepared.execute(sql)
        require_m2(prepared)
    receipt=apply_plan(database,plan,source_root=source,backup_path=backup_path)
    with closing(sqlite3.connect(database)) as db: require_m2(db)
    return {'plan':plan,'receipt':receipt}


def open_m2_runtime(database, *, contract_path):
    verify_runtime_database(database,contract_path=contract_path)
    from .pipeline import PipelineService
    from nmate.v03.core import CoreRepository
    class ExistingRepository(CoreRepository):
        def __init__(self,path):
            self.db_path=str(Path(path).resolve(strict=True)); self.managed_runtime=True
            self._memory_anchor=None; self._uri=False
    return PipelineService(ExistingRepository(database))
