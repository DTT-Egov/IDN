"""One grant's pause/resume decisions, with immutable SQL records and head.

Not a second budget: counters, money, expiry, SDK and grants remain in Gateway.
Legacy records remain raw. READ never creates an anchor or repairs a projection.
"""
import json
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.v03.core import CoreError,new_id,now_iso
from .operator_m6 import has_extension,require_extension
KINDS={'batch_paused_admission','batch_resumed_after_review'}
TERMINAL_KINDS={'estimate_overrun','batch_stop_terminal'}

def invalid():raise CoreError('BATCH_LIFECYCLE_INVALID','Chuỗi dừng/tiếp tục hoặc biên nhận đã lệch; cần đối soát, chưa gửi AI.',409)
def parsed(value):
    try:return json.loads(value)
    except (ValueError,TypeError):invalid()
def envelope(row):
    return dict(id=row['id'],scope_id=row['scope_id'],attempt_id=row['attempt_id'],kind=row['kind'],detail=parsed(row['detail_json']),recorded_at=row['recorded_at'])

def read(db,grant,*,required=False):
    installed=has_extension(db)
    if installed:require_extension(db)
    elif required:raise CoreError('WORKER_SCHEMA_REQUIRED','Cần operator nâng schema worker trước khi gọi hoặc tiếp tục AI.',409)
    events={r['id']:envelope(r) for r in db.execute("SELECT e.* FROM core_domain_model_events e JOIN core_domain_model_attempts a ON a.id=e.attempt_id WHERE a.grant_id=? AND e.kind IN ('batch_paused_admission','batch_resumed_after_review')",(grant['id'],))}
    if any(e['scope_id']!=grant['scope_id'] for e in events.values()):invalid()
    # Terminal kernel evidence is a permanent stop barrier for this issuance.
    # It is independent of the pause/resume chain: neither a mutable projection
    # rewind nor a resume command may reconcile spending or reactivate it.
    terminal=[]
    for row in db.execute("SELECT e.*,a.actual_microusd AS attempt_actual FROM core_domain_model_events e JOIN core_domain_model_attempts a ON a.id=e.attempt_id WHERE a.grant_id=? AND e.kind IN ('estimate_overrun','batch_stop_terminal')",(grant['id'],)):
        event=envelope(row);detail=event['detail']
        if event['scope_id']!=grant['scope_id'] or not isinstance(detail,dict):invalid()
        if event['kind']=='estimate_overrun':
            actual=detail.get('actual_microusd')
            if type(actual) is not int or actual<=0 or actual!=row['attempt_actual']:invalid()
        elif (detail.get('grant_id')!=grant['id'] or detail.get('terminal_not_reactivated') is not True
              or detail.get('previous_state')!=detail.get('resulting_state')
              or not isinstance(detail.get('resulting_state'),str)
              or not detail['resulting_state'] or detail['resulting_state'] in {'active','paused_admission_review'}):invalid()
        terminal.append(event)
    if terminal and grant['state'] in {'active','paused_admission_review'}:invalid()
    controls=[dict(r) for r in db.execute('SELECT * FROM kw_batch_controls WHERE grant_id=?',(grant['id'],))] if installed else []
    head=db.execute('SELECT * FROM kw_batch_control_heads WHERE grant_id=?',(grant['id'],)).fetchone() if installed else None
    referenced={c['model_event_id'] for c in controls}
    legacy=[e for key,e in events.items() if key not in referenced]
    for e in legacy:
        d=e['detail']
        if (e['kind']!='batch_paused_admission' or not isinstance(d,dict) or d.get('grant_id')!=grant['id']
            or d.get('resulting_state')!='paused_admission_review'):invalid()
    scope=db.execute('SELECT contract_hash FROM core_domain_grant_scopes WHERE grant_id=?',(grant['id'],)).fetchone()
    if scope is None:invalid()
    root=dict(kind='legacy_pause_set' if legacy else 'issued_grant',grant_id=grant['id'],scope_id=grant['scope_id'],
      account_id=grant['account_id'],contract_hash=scope['contract_hash'],
      legacy_hash=digest(sorted(legacy,key=lambda e:e['id'])),state='paused_admission_review' if legacy else 'active')
    state=root['state'];previous=None;previous_id=None;sequence=0;visited=set();last=None
    by_parent={}
    for c in controls:
        if c['previous_id'] in by_parent:invalid()
        by_parent[c['previous_id']]=c
    while previous_id in by_parent:
        c=by_parent[previous_id]
        if c['id'] in visited or c['sequence']!=sequence+1 or parsed(c['root_json'])!=root:invalid()
        payload=parsed(c['payload_json']);event=events.get(c['model_event_id'])
        if (event is None or payload!=event or digest(payload)!=c['payload_hash']
            or digest({k:v for k,v in c.items() if k!='record_hash'})!=c['record_hash']
            or event['attempt_id']!=c['attempt_id'] or c['from_state']!=state):invalid()
        expected_kind='batch_paused_admission' if c['action']=='pause' else 'batch_resumed_after_review'
        if event['kind']!=expected_kind:invalid()
        if c['action']=='pause':
            d=event['detail']
            if (c['to_state']!='paused_admission_review' or state not in {'active','paused_admission_review'}
                or not isinstance(d,dict) or d.get('grant_id')!=grant['id']
                or d.get('previous_state')!=c['from_state'] or d.get('resulting_state')!=c['to_state']):invalid()
        elif c['action']=='resume':
            d=event['detail']
            if (state!='paused_admission_review' or c['to_state']!='active' or not isinstance(d,dict)
                or not isinstance(d.get('decision'),dict) or d.get('decision_hash')!=digest(d['decision'])
                or d['decision'].get('grant_id')!=grant['id'] or d['decision'].get('decision_id')!=c['command_id']
                or any(d['decision'].get(k) is not True for k in ('no_retry','no_new_sources','no_publication'))
                or d.get('resulting_state')!='active'):invalid()
            if d.get('schema_version')=='knowledge-independent-receipt/1':
                from .independent_branch import verify_stored
                previous_ref=dict(schema_version='batch-lifecycle-ref/1',grant_id=grant['id'],root_hash=digest(root),
                    decision_id=previous_id,sequence=sequence,record_hash=last['record_hash'] if last else None,
                    terminal_events_hash=digest([]))
                verify_stored(db,grant,d,previous_ref)
        else:invalid()
        state=c['to_state'];sequence=c['sequence'];previous_id=c['id'];visited.add(c['id']);last=c
    if len(visited)!=len(controls) or bool(head)!=bool(controls):invalid()
    if head and (head['decision_id']!=previous_id or head['sequence']!=sequence):invalid()
    # Terminal projections may restrict further. Retained terminal evidence
    # above prevents changing them back to active even before a control exists.
    if grant['state'] in {'active','paused_admission_review'} and grant['state']!=state:invalid()
    return dict(installed=installed,state=grant['state'],effective_state=state,root=root,head=last,sequence=sequence,
      event=events.get(last['model_event_id']) if last else None,
      pause_set_hash=digest(sorted([e for e in events.values() if e['kind']=='batch_paused_admission'],key=lambda e:e['id'])),
      ref=dict(schema_version='batch-lifecycle-ref/1',grant_id=grant['id'],root_hash=digest(root),
        decision_id=previous_id,sequence=sequence,record_hash=last['record_hash'] if last else None,
        terminal_events_hash=digest(sorted(terminal,key=lambda e:e['id']))))

def append(db,grant,*,action,attempt_id,detail,command_id=None):
    current=read(db,grant,required=True)
    attempt=db.execute('SELECT scope_id FROM core_domain_model_attempts WHERE id=? AND grant_id=?',(attempt_id,grant['id'])).fetchone()
    if attempt is None or attempt['scope_id']!=grant['scope_id']:invalid()
    target='paused_admission_review' if action=='pause' else 'active'
    if grant['state'] not in {'active','paused_admission_review'}:raise CoreError('RESUME_NOT_ALLOWED','Hạn mức cần đối soát, không tự đổi trạng thái terminal.',409)
    event_id=new_id('domain_event');event=dict(id=event_id,scope_id=grant['scope_id'],attempt_id=attempt_id,
      kind='batch_paused_admission' if action=='pause' else 'batch_resumed_after_review',detail=detail,recorded_at=now_iso())
    record=dict(id=new_id('batch_control'),grant_id=grant['id'],sequence=current['sequence']+1,
      previous_id=current['head']['id'] if current['head'] else None,action=action,command_id=command_id,attempt_id=attempt_id,
      from_state=grant['state'],to_state=target,root_json=canonical(current['root']),payload_json=canonical(event),payload_hash=digest(event),model_event_id=event_id)
    record['record_hash']=digest(record)
    db.execute('INSERT INTO core_domain_model_events VALUES(?,?,?,?,?,?)',(event_id,grant['scope_id'],attempt_id,event['kind'],canonical(detail),event['recorded_at']))
    db.execute('INSERT INTO kw_batch_controls VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',tuple(record.values()))
    if current['head']:
        changed=db.execute('UPDATE kw_batch_control_heads SET decision_id=?,sequence=? WHERE grant_id=? AND decision_id=? AND sequence=?',
          (record['id'],record['sequence'],grant['id'],current['head']['id'],current['sequence'])).rowcount
    else:
        db.execute('INSERT INTO kw_batch_control_heads VALUES(?,?,?)',(grant['id'],record['id'],record['sequence']));changed=1
    if changed!=1:invalid()
    if db.execute('UPDATE core_domain_budget_grants SET state=? WHERE id=? AND state=?',(target,grant['id'],grant['state'])).rowcount!=1:invalid()
    return event

def ensure_paused(repo,grant_id,attempt_id,*,operator,reason):
    """Safety primitive: idempotent only at current matching paused head.

    A call after resume means ensure-paused again, not historical command replay.
    """
    with repo.connection(write=True) as db:
        grant=db.execute('SELECT * FROM core_domain_budget_grants WHERE id=?',(grant_id,)).fetchone()
        if grant is None:invalid()
        current=read(db,grant,required=True)
        if grant['state'] not in {'active','paused_admission_review'}:
            attempt=db.execute('SELECT scope_id FROM core_domain_model_attempts WHERE id=? AND grant_id=?',(attempt_id,grant_id)).fetchone()
            if attempt is None or attempt['scope_id']!=grant['scope_id']:invalid()
            event_id=new_id('domain_event')
            detail=dict(grant_id=grant_id,operator=operator,reason=reason,previous_state=grant['state'],resulting_state=grant['state'],terminal_not_reactivated=True)
            db.execute('INSERT INTO core_domain_model_events VALUES(?,?,?,?,?,?)',(event_id,grant['scope_id'],attempt_id,'batch_stop_terminal',canonical(detail),now_iso()))
            return dict(db.execute('SELECT * FROM core_domain_model_events WHERE id=?',(event_id,)).fetchone())
        old=current['event']
        if (grant['state']=='paused_admission_review' and old and old['kind']=='batch_paused_admission'
          and old['attempt_id']==attempt_id and old['detail'].get('operator')==operator and old['detail'].get('reason')==reason):
            return dict(db.execute('SELECT * FROM core_domain_model_events WHERE id=?',(old['id'],)).fetchone())
        detail=dict(grant_id=grant_id,operator=operator,reason=reason,previous_state=grant['state'],
          resulting_state='paused_admission_review',free_recovery_does_not_resume=True)
        event=append(db,grant,action='pause',attempt_id=attempt_id,detail=detail)
        return dict(db.execute('SELECT * FROM core_domain_model_events WHERE id=?',(event['id'],)).fetchone())
