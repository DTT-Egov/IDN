"""Canonical policy-freshness-decision/1, pure and model/network free.

M2 has no approved live-check profile or expert release. Extension points are
explicit reasons, not a second vocabulary in UI/index adapters.
"""
from nmate.core_v1.runtime_schema import digest
from nmate.v03.core import CoreError

PRECEDENCE=('forbidden','changed_needs_review','source_incomplete','currentness_unconfirmed','refresh_required','reusable')


def decide(*,mode,blockers,reason_codes,basis_refs,outcome_kind='policy_assessment'):
    if mode not in {'discovery','history','new_assessment'} or any(b not in PRECEDENCE for b in blockers):
        raise CoreError('invalid_freshness_input','Chế độ hoặc trạng thái độ mới chưa hợp lệ.')
    decision=next((d for d in PRECEDENCE if d in blockers),'reusable')
    value={'schema_version':'policy-freshness-decision/1','decision':decision,'mode':mode,
           'reason_codes':sorted(set(reason_codes)),
           'usable_for':[] if decision=='forbidden' else ['discovery','history'],
           'blocked_outcomes':[outcome_kind] if decision!='reusable' else [],
           'next_check_at':None,'basis_refs':basis_refs}
    value['decision_hash']=digest(value)
    return value
