"""Workbench authentication delegates to the main app's existing sessions/CSRF.

No login, password, token generation, expert grant or model capability here.
"""
from .workbench import router
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError

def expert_has_scope(repo,actor):
    with repo.connection() as db:
        if any(KnowledgeCatalog._has_global_authority(db,actor,role) for role in ('curator','reviewer','publisher')):return True
        return bool(db.execute("SELECT 1 FROM pol_knowledge_role_scopes WHERE account_id=? AND revoked_at IS NULL LIMIT 1",(actor,)).fetchone() or
                    db.execute("SELECT 1 FROM pol_wiki_capabilities WHERE account_id=? AND revoked_at IS NULL LIMIT 1",(actor,)).fetchone())

def attach_workbench(app,service,gateway,*,cookie_namespace):
    def existing_session(request):
        token=request.cookies.get(cookie_namespace+'_session','')
        value=(app.state.accounts.validate_csrf(token,request.headers.get('X-CSRF-Token')) if request.method=='POST' else app.state.accounts.get_session(token))
        actor=value['account_id']
        if not expert_has_scope(service.repo,actor):raise CoreError('wiki_scope_denied','Tài khoản chưa được phân quyền bàn chuyên gia chính sách.',403)
        return dict(account_id=actor,csrf_token=request.cookies.get(cookie_namespace+'_csrf'))
    app.include_router(router(service,gateway,existing_session))
