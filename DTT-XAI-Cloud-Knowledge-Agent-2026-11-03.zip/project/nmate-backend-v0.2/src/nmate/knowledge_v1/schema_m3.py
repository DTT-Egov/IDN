"""M3 governance + public-domain ledger DDL; no source/business backfill."""
import re
import sqlite3
from nmate.core_v1.domain_gateway import DOMAIN_SCHEMA


def split_ddl(script):
    statements=[];buffer=''
    for line in script.splitlines(keepends=True):
        buffer+=line
        if sqlite3.complete_statement(buffer): statements.append(buffer.strip());buffer=''
    if buffer.strip(): raise ValueError('Incomplete schema declaration')
    return statements


GOV_TABLES=[
    """CREATE TABLE pol_wiki_batch_instances (
 id TEXT PRIMARY KEY,approval_id TEXT NOT NULL UNIQUE,scope_id TEXT NOT NULL,
 account_id TEXT NOT NULL REFERENCES v03_accounts(id),corpus_hash TEXT NOT NULL,
 created_at TEXT NOT NULL,record_hash TEXT NOT NULL)""",
    """CREATE TABLE pol_wiki_capabilities (
 account_id TEXT NOT NULL REFERENCES v03_accounts(id), policy_id TEXT NOT NULL,
 source_id TEXT NOT NULL REFERENCES pol_sources(id), capability TEXT NOT NULL CHECK(capability IN ('read','author','review','publish','attest')),
 approval_id TEXT NOT NULL, revoked_at TEXT,
 PRIMARY KEY(account_id,policy_id,source_id,capability))""",
    """CREATE TABLE pol_wiki_source_attestations (
 id TEXT PRIMARY KEY, policy_id TEXT NOT NULL,source_id TEXT NOT NULL REFERENCES pol_sources(id),
 previous_id TEXT, version INTEGER NOT NULL CHECK(version>0), source_manifest_hash TEXT NOT NULL,
 payload_json TEXT NOT NULL, content_hash TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES v03_accounts(id),created_at TEXT NOT NULL,record_hash TEXT NOT NULL,
 UNIQUE(policy_id,source_id,id),UNIQUE(policy_id,source_id,version),UNIQUE(policy_id,source_id,previous_id),
 FOREIGN KEY(policy_id,source_id,previous_id) REFERENCES pol_wiki_source_attestations(policy_id,source_id,id))""",
    """CREATE TABLE pol_wiki_attestation_heads (
 policy_id TEXT NOT NULL,source_id TEXT NOT NULL,decision_id TEXT NOT NULL,version INTEGER NOT NULL CHECK(version>0),
 PRIMARY KEY(policy_id,source_id),
 FOREIGN KEY(policy_id,source_id,decision_id) REFERENCES pol_wiki_source_attestations(policy_id,source_id,id))""",
    """CREATE TABLE pol_wiki_reviews (
 id TEXT PRIMARY KEY,page_id TEXT NOT NULL REFERENCES kp_wiki_pages(id),revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),
 previous_id TEXT,sequence INTEGER NOT NULL CHECK(sequence>0),manifest_hash TEXT NOT NULL,manifest_json TEXT NOT NULL,
 decision TEXT NOT NULL CHECK(decision IN ('approved','rejected')),rationale TEXT NOT NULL,
 actor_id TEXT NOT NULL REFERENCES v03_accounts(id),created_at TEXT NOT NULL,record_hash TEXT NOT NULL,
 UNIQUE(page_id,id),UNIQUE(page_id,sequence),UNIQUE(page_id,previous_id),
 FOREIGN KEY(page_id,previous_id) REFERENCES pol_wiki_reviews(page_id,id))""",
    """CREATE TABLE pol_wiki_review_heads (
 page_id TEXT PRIMARY KEY REFERENCES kp_wiki_pages(id),decision_id TEXT NOT NULL,sequence INTEGER NOT NULL,
 FOREIGN KEY(page_id,decision_id) REFERENCES pol_wiki_reviews(page_id,id))""",
    """CREATE TABLE pol_wiki_releases (
 id TEXT PRIMARY KEY,page_id TEXT NOT NULL REFERENCES kp_wiki_pages(id),revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),
 previous_id TEXT,sequence INTEGER NOT NULL CHECK(sequence>0),review_id TEXT NOT NULL REFERENCES pol_wiki_reviews(id),
 manifest_hash TEXT NOT NULL,decision TEXT NOT NULL CHECK(decision IN ('published','withdrawn')),
 rationale TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES v03_accounts(id),created_at TEXT NOT NULL,record_hash TEXT NOT NULL,
 UNIQUE(page_id,id),UNIQUE(page_id,sequence),UNIQUE(page_id,previous_id),
 FOREIGN KEY(page_id,previous_id) REFERENCES pol_wiki_releases(page_id,id))""",
    """CREATE TABLE pol_wiki_release_heads (
 page_id TEXT PRIMARY KEY REFERENCES kp_wiki_pages(id),decision_id TEXT NOT NULL,sequence INTEGER NOT NULL,
 FOREIGN KEY(page_id,decision_id) REFERENCES pol_wiki_releases(page_id,id))""",
    """CREATE TABLE pol_wiki_editor_buffers (
 account_id TEXT NOT NULL REFERENCES v03_accounts(id),page_id TEXT NOT NULL REFERENCES kp_wiki_pages(id),
 base_revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),ui_revision INTEGER NOT NULL CHECK(ui_revision>0),
 payload_json TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(account_id,page_id))""",
    """CREATE TABLE pol_wiki_ai_proposals (
 id TEXT PRIMARY KEY,attempt_id TEXT NOT NULL UNIQUE REFERENCES core_domain_model_attempts(id),policy_id TEXT NOT NULL,
 assignee_id TEXT NOT NULL REFERENCES v03_accounts(id),invocation_json TEXT NOT NULL,
 payload_json TEXT NOT NULL,content_hash TEXT NOT NULL,created_at TEXT NOT NULL)""",
    """CREATE TABLE pol_wiki_proposal_applications (
 proposal_id TEXT PRIMARY KEY REFERENCES pol_wiki_ai_proposals(id),page_id TEXT NOT NULL REFERENCES kp_wiki_pages(id),
 revision_id TEXT NOT NULL REFERENCES kp_wiki_revisions(id),actor_id TEXT NOT NULL REFERENCES v03_accounts(id),created_at TEXT NOT NULL)""",
]
GOV_TRIGGERS={}
for table in ('pol_wiki_batch_instances','pol_wiki_source_attestations','pol_wiki_reviews','pol_wiki_releases','pol_wiki_ai_proposals','pol_wiki_proposal_applications'):
    for action in ('UPDATE','DELETE'):
        name=table+('_immutable' if action=='UPDATE' else '_no_delete')
        GOV_TRIGGERS[name]=(table,f"CREATE TRIGGER {name} BEFORE {action} ON {table} BEGIN SELECT RAISE(ABORT,'immutable wiki governance record'); END;")
M3_STATEMENTS=split_ddl(DOMAIN_SCHEMA)+GOV_TABLES+[x[1] for x in GOV_TRIGGERS.values()]
TRIGGERS_M3={}
for statement in M3_STATEMENTS:
    match=re.match(r'CREATE TRIGGER(?: IF NOT EXISTS)? (\w+) BEFORE (?:UPDATE|DELETE) ON (\w+)',' '.join(statement.split()))
    if match: TRIGGERS_M3[match[1]]=(match[2],' '.join(statement.split()))
