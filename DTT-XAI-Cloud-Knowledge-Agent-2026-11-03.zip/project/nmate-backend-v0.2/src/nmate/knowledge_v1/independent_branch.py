"""Narrow failure disposition + continuation on the existing causal ledger.

No schema, grants, refunds, publication, retries or model calls. The operator
must already have a separate human decision before invoking the mutation.
"""

import hashlib
import json
from pathlib import Path
from nmate.core_v1.runtime_schema import digest
from nmate.v03.core import CoreError, now_iso

GRAPH = {"version": "policy-review-graph/1", "O1": ["S1", "S2"], "O2": ["S3", "S4"]}
DECISION_KEYS = {
    "schema_version",
    "decision_id",
    "approved_by",
    "grant_id",
    "scope_id",
    "batch_instance_id",
    "corpus_hash",
    "graph_hash",
    "failed_result",
    "inputs",
    "target_slot",
    "source_versions",
    "expected_lifecycle_ref",
    "expires_at",
    "no_retry",
    "no_new_sources",
    "no_publication",
}


def verify_stored(db, grant, detail, previous_ref):
    """Fixed receipt semantics, including historical identity, not current defaults."""
    decision = detail.get("decision")
    browser = (
        isinstance(decision, dict)
        and decision.get("schema_version") == "knowledge-independent-continuation/2"
    )
    expected_keys = DECISION_KEYS | {"approver"} if browser else DECISION_KEYS
    if browser and not isinstance(decision.get("approver"), dict):
        denied()
    expected_by = decision.get("approver", {}).get("account_id") if browser else "project_owner_operator"
    if (
        not isinstance(decision, dict)
        or set(decision) != expected_keys
        or decision["schema_version"]
        not in {"knowledge-independent-continuation/1", "knowledge-independent-continuation/2"}
        or decision["approved_by"] != expected_by
        or decision["grant_id"] != grant["id"]
        or decision["scope_id"] != grant["scope_id"]
        or decision["expires_at"] != grant["expires_at"]
        or decision["graph_hash"] != digest(GRAPH)
        or decision["target_slot"] != "O2"
        or digest(decision["expected_lifecycle_ref"]) != digest(previous_ref)
        or digest(detail.get("disposition"))
        != digest(dict(slot="O1", outcome="rejected_retained", retry_allowed=False, refunded=False))
    ):
        denied("Biên nhận nhánh độc lập không khớp identity gốc.")
    spec = db.execute(
        "SELECT corpus_refs_json,invocation_json FROM core_domain_grant_scopes WHERE grant_id=?",
        (grant["id"],),
    ).fetchone()
    invocation = json.loads(spec["invocation_json"])
    if decision["corpus_hash"] != digest(json.loads(spec["corpus_refs_json"])) or decision[
        "batch_instance_id"
    ] != invocation.get("issuance_binding", {}).get("batch_instance_id"):
        denied()
    if not isinstance(decision["source_versions"], list) or not decision["source_versions"]:
        denied()
    if browser:
        approver = decision["approver"]
        if (
            not isinstance(approver, dict)
            or set(approver)
            != {"realm", "account_id", "username", "assignment_id", "assignment_path", "assignment_sha256"}
            or approver["realm"] != "main_account"
            or approver["account_id"] != grant["account_id"]
            or not isinstance(approver["username"], str)
            or not approver["username"]
        ):
            denied()


def denied(message="Chưa đủ điều kiện tiếp tục riêng nhánh O2; chưa gửi AI."):
    raise CoreError("INDEPENDENT_CONTINUATION_NOT_ALLOWED", message, 409)


def failure(db, grant):
    """Known rejected response only. Unknown usage anywhere is a stronger stop."""
    rows = [
        dict(r)
        for r in db.execute("SELECT * FROM core_domain_model_attempts WHERE grant_id=?", (grant["id"],))
    ]
    for r in rows:
        usage = json.loads(r["usage_json"] or "{}")
        if (
            r["state"] not in {"response_received", "cancelled_before_dispatch", "reserved"}
            or r["state"] == "response_received"
            and (
                r["actual_microusd"] is None
                or any(
                    type(usage.get(k)) is not int or usage[k] < 0 for k in ("input_tokens", "output_tokens")
                )
            )
        ):
            denied("Có lượt chưa rõ kết quả hoặc chi phí; cần đối soát trước.")
    failed = [r for r in rows if r["task_id"] == "O1"]
    if len(failed) != 1:
        denied()
    r = failed[0]
    if (
        r["state"] != "response_received"
        or r["validation_state"] != "rejected"
        or r["raw_text"] is None
        or hashlib.sha256(r["raw_text"].encode()).hexdigest() != r["raw_sha256"]
    ):
        denied()
    # The current two-branch protocol does not dismiss unrelated failures.
    for a in rows:
        if a["task_id"] in {"O1", "O2"}:
            continue
        proposal = db.execute("SELECT 1 FROM pol_wiki_ai_proposals WHERE attempt_id=?", (a["id"],)).fetchone()
        if a["state"] != "response_received" or a["validation_state"] != "accepted" or not proposal:
            denied()
    return dict(
        slot="O1",
        attempt_id=r["id"],
        raw_sha256=r["raw_sha256"],
        state=r["state"],
        validation_state=r["validation_state"],
        actual_microusd=r["actual_microusd"],
        usage_hash=digest(json.loads(r["usage_json"])),
    )


def inputs(db, authority, grant):
    from .ai_proposals import read_proposal

    refs = []
    for slot in GRAPH["O2"]:
        row = db.execute(
            "SELECT a.id AS attempt_id,p.id AS proposal_id,p.content_hash FROM core_domain_model_attempts a JOIN pol_wiki_ai_proposals p ON p.attempt_id=a.id WHERE a.grant_id=? AND a.task_id=?",
            (grant["id"], slot),
        ).fetchone()
        if row is None:
            denied("Chưa có bản nháp S3/S4 đủ điều kiện để rà.")
        read_proposal(authority.source, authority.gateway, authority.actor, row["proposal_id"])
        refs.append(
            dict(
                slot=slot,
                attempt_id=row["attempt_id"],
                proposal_id=row["proposal_id"],
                content_hash=row["content_hash"],
            )
        )
    return refs


def current_permit(lifecycle):
    event = lifecycle.get("event")
    detail = event["detail"] if event else {}
    if detail.get("schema_version") == "knowledge-independent-receipt/1":
        decision = detail.get("decision")
        if not isinstance(decision, dict) or detail.get("decision_hash") != digest(decision):
            denied()
        return decision
    return None


def enforce(db, authority, grant, lifecycle, dependencies):
    """Same guard at shared reservation and dispatch fence; no UI shortcut."""
    permit = current_permit(lifecycle)
    if permit is None:
        return
    if (
        authority.task_id != "O2"
        or permit.get("target_slot") != "O2"
        or permit.get("grant_id") != grant["id"]
        or permit.get("graph_hash") != digest(GRAPH)
        or permit.get("scope_id") != grant["scope_id"]
        or permit.get("failed_result") != failure(db, grant)
    ):
        denied()
    bound = inputs(db, authority, grant)
    if digest(permit.get("inputs")) != digest(bound) or dependencies.get("prior_attempt_ids") != [
        x["attempt_id"] for x in bound
    ]:
        denied()
    from .review_binding import source_versions

    if digest(permit.get("source_versions")) != digest(
        source_versions(authority.source, db, authority.actor, authority.refs)
    ):
        denied("Nguồn đã đổi sau quyết định; cần rà và quyết định lại, chưa gửi AI.")
    if permit.get("schema_version") == "knowledge-independent-continuation/2":
        from .cost_authority import verify_dispatch_authority

        spec = authority._scope_row(db, grant["id"])
        binding = spec["invocation"].get("issuance_binding", {})
        directory = str(Path(binding["database_path"]).parent)
        verify_dispatch_authority(permit["approver"], scope_id=grant["scope_id"], directory=directory)


def _decision(db, prepared, receipt, authority, status, command_id, approver=None):
    from .batch_lifecycle import read
    from .service import identifier

    identifier(command_id)
    grant = db.execute("SELECT * FROM core_domain_budget_grants WHERE id=?", (receipt["id"],)).fetchone()
    lifecycle = read(db, grant, required=True)
    if grant["state"] != "paused_admission_review" or grant["expires_at"] <= now_iso():
        denied()
    if status["blocked_slots"] != ["O1"] or status["remaining_slots"] != ["O2"]:
        denied()
    from .review_binding import source_versions

    result = dict(
        schema_version="knowledge-independent-continuation/1",
        decision_id=command_id,
        approved_by="project_owner_operator",
        grant_id=grant["id"],
        scope_id=grant["scope_id"],
        batch_instance_id=prepared["batch_instance_id"],
        corpus_hash=prepared["corpus_hash"],
        graph_hash=digest(GRAPH),
        failed_result=failure(db, grant),
        inputs=inputs(db, authority, grant),
        target_slot="O2",
        source_versions=source_versions(authority.source, db, authority.actor, authority.refs),
        expected_lifecycle_ref=lifecycle["ref"],
        expires_at=grant["expires_at"],
        no_retry=True,
        no_new_sources=True,
        no_publication=True,
    )
    if approver is not None:
        from .cost_authority import verify_dispatch_authority

        verify_dispatch_authority(
            approver, scope_id=grant["scope_id"], directory=str(Path(prepared["database"]).parent)
        )
        if approver["account_id"] != prepared["account_id"]:
            denied()
        result.update(
            schema_version="knowledge-independent-continuation/2",
            approved_by=approver["account_id"],
            approver=approver,
        )
    return result


def preview(directory, command_id, *, approver=None):
    """Template is read-only, not human approval or dispatch authorization."""
    from .worker_m6 import _load, _state

    prepared, receipt, repo, authority = _load(directory)
    with repo.connection() as db:
        return _decision(
            db, prepared, receipt, authority, _state(db, prepared, receipt, authority), command_id, approver
        )


def continue_independent(directory, decision, *, approver=None):
    from .worker_m6 import _load, _state
    from .batch_lifecycle import append
    from .service import identifier
    from nmate.main.runtime_lock import EnterpriseRuntimeLock

    if not isinstance(decision, dict):
        denied()
    identifier(decision.get("decision_id"))
    prepared, receipt, repo, authority = _load(directory)
    with EnterpriseRuntimeLock(repo.db_path), repo.connection(write=True) as db:
        status = _state(
            db, prepared, receipt, authority
        )  # original subject + current READ, not current WRITE
        old = db.execute(
            "SELECT payload_json FROM kw_batch_controls WHERE grant_id=? AND command_id=?",
            (receipt["id"], decision["decision_id"]),
        ).fetchone()
        if old:
            saved = json.loads(old[0])["detail"]
            if (
                saved.get("schema_version") != "knowledge-independent-receipt/1"
                or digest(saved.get("decision")) != digest(decision)
                or saved.get("decision_hash") != digest(decision)
            ):
                raise CoreError("IDEMPOTENCY_CONFLICT", "Quyết định đã dùng với nội dung khác.", 409)
            return saved
        expected = _decision(db, prepared, receipt, authority, status, decision["decision_id"], approver)
        if digest(decision) != digest(expected):
            denied("Quyết định hoặc phiên bản đầu vào đã khác; cần quyết định riêng mới.")
        from .public_batch import validate_approved_inputs

        validate_approved_inputs(prepared, repo)
        authority._resolve(db, prepared["account_id"], prepared["source_refs"], export=True)
        grant = db.execute("SELECT * FROM core_domain_budget_grants WHERE id=?", (receipt["id"],)).fetchone()
        # Same grant, per-role caps, counters, original expiry and source closure.
        spec = authority._scope_row(db, grant["id"])
        role = spec["per_role"].get("complex")
        used = db.execute(
            "SELECT count(*),COALESCE(sum(held_microusd),0) FROM core_domain_model_attempts WHERE grant_id=? AND state!='cancelled_before_dispatch'",
            (grant["id"],),
        ).fetchone()
        role_used = db.execute(
            "SELECT count(*) FROM core_domain_model_attempts WHERE grant_id=? AND profile_version='complex/1' AND state!='cancelled_before_dispatch'",
            (grant["id"],),
        ).fetchone()[0]
        if (
            not role
            or role_used >= role["max_calls"]
            or used[0] >= grant["max_calls"]
            or used[1] >= grant["cap_microusd"]
        ):
            denied()
        saved = dict(
            schema_version="knowledge-independent-receipt/1",
            decision=decision,
            decision_hash=digest(decision),
            disposition=dict(slot="O1", outcome="rejected_retained", retry_allowed=False, refunded=False),
            resulting_state="active",
            recorded_at=now_iso(),
        )
        append(
            db,
            grant,
            action="resume",
            attempt_id=decision["failed_result"]["attempt_id"],
            detail=saved,
            command_id=decision["decision_id"],
        )
        return saved
