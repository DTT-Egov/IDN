"""M4 reviewed applicability is immutable and part of the release manifest."""
M4_TABLE = """CREATE TABLE ks_wiki_applicability (
 revision_id TEXT PRIMARY KEY REFERENCES kp_wiki_revisions(id),page_id TEXT NOT NULL,
 payload_json TEXT NOT NULL,content_hash TEXT NOT NULL,actor_id TEXT NOT NULL REFERENCES v03_accounts(id),
 created_at TEXT NOT NULL,record_hash TEXT NOT NULL,
 FOREIGN KEY(page_id,revision_id) REFERENCES kp_wiki_revisions(page_id,id))"""
TRIGGERS_M4={}
for table in ('ks_wiki_applicability','ks_source_controls'):
    for action,suffix in (('UPDATE','immutable'),('DELETE','no_delete')):
        name=table+'_'+suffix
        TRIGGERS_M4[name]=(table,f"CREATE TRIGGER {name} BEFORE {action} ON {table} BEGIN SELECT RAISE(ABORT,'immutable knowledge decision'); END;")
M4_STATEMENTS=[M4_TABLE,"""CREATE TABLE ks_source_controls (
 id TEXT PRIMARY KEY,source_id TEXT NOT NULL REFERENCES pol_sources(id),previous_id TEXT,
 sequence INTEGER NOT NULL CHECK(sequence>0),observation_id TEXT NOT NULL UNIQUE REFERENCES pol_source_observations(id),
 payload_json TEXT NOT NULL,content_hash TEXT NOT NULL,record_hash TEXT NOT NULL,
 UNIQUE(source_id,id),UNIQUE(source_id,sequence),UNIQUE(source_id,previous_id),
 FOREIGN KEY(source_id,previous_id) REFERENCES ks_source_controls(source_id,id))""",
 "CREATE UNIQUE INDEX ks_source_controls_one_root ON ks_source_controls(source_id) WHERE previous_id IS NULL",
 """CREATE TABLE ks_source_control_heads (
 source_id TEXT PRIMARY KEY REFERENCES pol_sources(id),decision_id TEXT NOT NULL,sequence INTEGER NOT NULL,
 FOREIGN KEY(source_id,decision_id) REFERENCES ks_source_controls(source_id,id))"""]+[value[1] for value in TRIGGERS_M4.values()]
