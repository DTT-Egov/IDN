"""Governed public knowledge; opt-in service/operator, no startup side effects."""
