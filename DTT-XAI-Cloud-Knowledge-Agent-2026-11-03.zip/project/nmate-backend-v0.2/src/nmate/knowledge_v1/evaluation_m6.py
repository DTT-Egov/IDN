"""Retrieval-only A/B diagnostic on an explicit synthetic frozen question set.

No answer/model/semantic gold is manufactured here. A discovers authorized raw
snippets; B retains that path and adds the existing released-wiki reader. These
different stages are reported separately, never as a legal-quality win.
"""
from datetime import date
import hashlib,statistics,time
from nmate.core_v1.runtime_schema import digest
from nmate.v03.core import CoreError
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.policy_v1.service import resolve_intent,intent_goals
from nmate.main.runtime_lock import EnterpriseRuntimeLock
from .serving import PublishedKnowledge

def _database_hash(repo):
    with repo.connection() as db:
        return hashlib.sha256('\n'.join(db.iterdump()).encode()).hexdigest()

def evaluate(repo,actor,questions,*,source_ids,repeat_reads=100,target_date=None):
    if (not isinstance(questions,dict) or questions.get('schema_version')!='knowledge-evaluation-questions/1'
        or questions.get('fixture_only') is not True or questions.get('expert_legal_gold') is not False):
        raise CoreError('EVALUATION_SCOPE_INVALID','Harness này chỉ nhận corpus câu hỏi thử; chưa có gold pháp lý.',409)
    cases=questions.get('cases')
    if (not isinstance(cases,list) or not 1<=len(cases)<=100 or len({c.get('id') for c in cases})!=len(cases)
        or any(not isinstance(c.get('question'),str) or not 1<=len(c['question'])<=1000 or not isinstance(c.get('goals'),list) for c in cases)):
        raise CoreError('EVALUATION_INPUT_INVALID','Cần danh sách câu hỏi thử hữu hạn, định danh không trùng.')
    if not isinstance(source_ids,list) or not source_ids or len(set(source_ids))!=len(source_ids) or type(repeat_reads) is not int or not 1<=repeat_reads<=1000:
        raise CoreError('EVALUATION_INPUT_INVALID','Cần nguồn thử và giới hạn đọc lại rõ ràng.')
    target_date=target_date or date.today().isoformat()
    knowledge=PublishedKnowledge(repo)
    # Existing catalog retrieval only; bypass constructor bootstrap DDL, not
    # the canonical source ACL, which is explicitly checked below per result.
    catalog=object.__new__(KnowledgeCatalog);catalog.repo=repo
    def raw(question,goals):
        found=[]
        with repo.connection() as db:
            for goal in goals:
                for row in catalog.retrieve(question,target_date=target_date,goal=goal,db=db):
                    if row['source_id'] not in source_ids:continue
                    knowledge._source_read(db,actor,row['source_id'])
                    found.append(row)
        return dict(source_ids=sorted({r['source_id'] for r in found}),snippet_chars=sum(len(r['text_original']) for r in found))
    def with_wiki(question,goals):
        result=raw(question,goals)
        bundles=knowledge.lookup(actor,goals=goals,target_date=target_date)
        bounded=[]
        for bundle in bundles:
            pairs=[(ref,e) for ref,e in zip(bundle['wiki_revision_refs'],bundle['explanations'],strict=True)
              if {c['ref']['source_id'] for c in e['citations']}<=set(source_ids)]
            bounded.append(bundle|dict(wiki_revision_refs=[ref for ref,e in pairs],explanations=[e for ref,e in pairs],
              source_refs=[c['ref'] for ref,e in pairs for c in e['citations']]))
        bundles=bounded
        return result|dict(wiki_goals=[b['outcome_id'] for b in bundles if b['wiki_revision_refs']],
          wiki_reference_hashes=[digest(ref) for b in bundles for ref in b['wiki_revision_refs']],
          wiki_source_ids=sorted({ref['source_id'] for b in bundles for ref in b['source_refs']}),
          wiki_chars=sum(len(e['body']) for b in bundles for e in b['explanations']),
          gap_goals=[b['outcome_id'] for b in bundles if not b['wiki_revision_refs']])
    with EnterpriseRuntimeLock(repo.db_path):
        before=_database_hash(repo)
        with repo.connection() as db:
            source_proof=[]
            for sid in source_ids:
                knowledge._source_read(db,actor,sid)
                row=db.execute('SELECT id,current_snapshot_id FROM pol_sources WHERE id=?',(sid,)).fetchone()
                snapshot=db.execute('SELECT raw_sha256,text_sha256 FROM pol_source_snapshots WHERE id=?',(row['current_snapshot_id'],)).fetchone()
                source_proof.append(dict(source_id=sid,snapshot_id=row['current_snapshot_id'],raw_sha256=snapshot['raw_sha256'],text_sha256=snapshot['text_sha256']))
        rows=[];times={'A':[],'B':[]}
        for case in cases:
            goals=intent_goals(resolve_intent(case['question']))
            measures={}
            for label,operation in (('A',raw),('B',with_wiki)):
                start=time.perf_counter();value=operation(case['question'],goals)
                elapsed=(time.perf_counter()-start)*1000;times[label].append(elapsed)
                measures[label]=value|dict(elapsed_ms=elapsed)
            rows.append(dict(id=case['id'],goals=goals,expected_goals=case['goals'],intent_match=goals==case['goals'],**measures))
        reuse=[]
        for index in range(repeat_reads):
            case=cases[index%len(cases)];goals=intent_goals(resolve_intent(case['question']))
            start=time.perf_counter();with_wiki(case['question'],goals);reuse.append((time.perf_counter()-start)*1000)
        after=_database_hash(repo)
        if before!=after:raise CoreError('EVALUATION_WROTE_DATA','Đọc lại đã thay dữ liệu; chưa nhận kết quả benchmark.',409)
    def latency(values):
        ordered=sorted(values)
        return dict(p50_ms=statistics.median(ordered),p95_ms=ordered[min(len(ordered)-1,int(len(ordered)*.95))],samples=len(ordered))
    return dict(schema_version='knowledge-retrieval-diagnostic/1',fixture_only=True,question_set_hash=digest(questions),
      source_corpus_hash=digest(source_proof),wiki_corpus_hash=digest(sorted({h for r in rows for h in r['B']['wiki_reference_hashes']})),public_source_proofs=source_proof,target_date=target_date,
      question_count=len(cases),unique_question_count=len({c['question'] for c in cases}),intent_matches=sum(r['intent_match'] for r in rows),
      questions=rows,reuse_reads=repeat_reads,latency={k:latency(v) for k,v in times.items()}|{'reuse_B':latency(reuse)},
      db_writes=0,data_unchanged=True,model_calls=0,model_mode='none_retrieval_only',paid_cost_usd=0,
      legal_quality='not_evaluable',answer_quality_score=None,expert_review_minutes=None,maintenance_minutes=None,
      limits=['Synthetic technical corpus only; not real legal gold','A source discovery and B released explanation have different outputs',
        'No answer synthesis, precision/entailment score or model quality/cost comparison','Fixed A-then-B order; no latency superiority claim',
        'AI build cost, operator maintenance and expert labor must be measured separately before production conclusions'])
