"""Main session + CSRF; no expert role shortcut, model or automatic dispatch."""

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from nmate.v03.core import CoreError
import json


def router(service, accounts, *, cookie_namespace):
    routes = APIRouter(prefix="/api/main/policy-cost")

    def actor(request):
        token = request.cookies.get(cookie_namespace + "_session", "")
        value = (
            accounts.validate_csrf(token, request.headers.get("X-CSRF-Token"))
            if request.method == "POST"
            else accounts.get_session(token)
        )
        origin = request.headers.get("origin")
        if request.method == "POST" and origin and origin != str(request.base_url).rstrip("/"):
            raise CoreError("FORBIDDEN", "Nguồn yêu cầu chưa hợp lệ.", 403)
        return value["account_id"]

    async def respond(request, action, fields=None):
        try:
            identity = actor(request)
            data = {}
            if fields is not None:
                raw = await request.body()
                if len(raw) > 100000:
                    raise CoreError("INPUT_LIMIT", "Quyết định quá dài.", 413)
                try:
                    data = json.loads(raw)
                except (ValueError, UnicodeError):
                    raise CoreError("INVALID_INPUT", "Quyết định chưa đúng JSON.") from None
                if not isinstance(data, dict) or set(data) != set(fields):
                    raise CoreError("INVALID_INPUT", "Có trường ngoài hợp đồng quyết định.")
            result = action(identity, data)
            return JSONResponse(
                dict(ok=True, data=result, _scope_actor_id=identity), headers={"Cache-Control": "no-store"}
            )
        except CoreError as exc:
            return JSONResponse(
                dict(ok=False, error=dict(code=exc.code, message=str(exc))),
                status_code=exc.status_code,
                headers={"Cache-Control": "no-store"},
            )

    @routes.get("/status")
    async def status(request: Request):
        return await respond(request, lambda actor, _: service.status(actor))

    @routes.post("/preview")
    async def preview(request: Request):
        return await respond(
            request, lambda actor, data: service.preview(actor, data["command_id"]), {"command_id"}
        )

    @routes.post("/approve")
    async def approve(request: Request):
        return await respond(
            request, lambda actor, data: service.approve(actor, data["decision"]), {"decision"}
        )

    return routes
