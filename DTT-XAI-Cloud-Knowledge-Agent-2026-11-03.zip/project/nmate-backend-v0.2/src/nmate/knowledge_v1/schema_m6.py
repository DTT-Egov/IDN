"""Additive lifecycle decisions, not another spending ledger."""
M6_STATEMENTS=[
"""CREATE UNIQUE INDEX kw_batch_attempt_identity ON core_domain_model_attempts(grant_id,id)""",
"""CREATE TABLE kw_batch_controls (
 id TEXT PRIMARY KEY,grant_id TEXT NOT NULL REFERENCES core_domain_budget_grants(id),
 sequence INTEGER NOT NULL CHECK(sequence>0),previous_id TEXT,
 action TEXT NOT NULL CHECK(action IN ('pause','resume')),command_id TEXT,attempt_id TEXT NOT NULL,
 from_state TEXT NOT NULL,to_state TEXT NOT NULL,root_json TEXT NOT NULL,
 payload_json TEXT NOT NULL,payload_hash TEXT NOT NULL,
 model_event_id TEXT NOT NULL UNIQUE REFERENCES core_domain_model_events(id),record_hash TEXT NOT NULL,
 UNIQUE(grant_id,id),UNIQUE(grant_id,id,sequence),UNIQUE(grant_id,sequence),UNIQUE(grant_id,previous_id),UNIQUE(grant_id,command_id),
 CHECK((action='resume' AND command_id IS NOT NULL) OR (action='pause' AND command_id IS NULL)),
 CHECK((sequence=1 AND previous_id IS NULL) OR (sequence>1 AND previous_id IS NOT NULL)),
 FOREIGN KEY(grant_id,previous_id) REFERENCES kw_batch_controls(grant_id,id),
 FOREIGN KEY(grant_id,attempt_id) REFERENCES core_domain_model_attempts(grant_id,id))""",
"""CREATE UNIQUE INDEX kw_batch_one_root ON kw_batch_controls(grant_id) WHERE previous_id IS NULL""",
"""CREATE TABLE kw_batch_control_heads (
 grant_id TEXT PRIMARY KEY REFERENCES core_domain_budget_grants(id),decision_id TEXT NOT NULL,sequence INTEGER NOT NULL,
 FOREIGN KEY(grant_id,decision_id,sequence) REFERENCES kw_batch_controls(grant_id,id,sequence))""",
]
TRIGGERS_M6={}
for action in ('UPDATE','DELETE'):
    name='kw_batch_controls'+('_immutable' if action=='UPDATE' else '_no_delete')
    sql=f"CREATE TRIGGER {name} BEFORE {action} ON kw_batch_controls BEGIN SELECT RAISE(ABORT,'immutable batch lifecycle decision'); END;"
    M6_STATEMENTS.append(sql);TRIGGERS_M6[name]=('kw_batch_controls',' '.join(sql.split()))
    # Protect the pre-M6 pause root as well. Schema-only guards cover existing
    # rows without rewriting/anchoring any historical event or grant.
    name='kw_batch_legacy_events'+('_immutable' if action=='UPDATE' else '_no_delete')
    sql=f"CREATE TRIGGER {name} BEFORE {action} ON core_domain_model_events WHEN OLD.kind IN ('batch_paused_admission','batch_resumed_after_review','batch_stop_terminal','estimate_overrun') BEGIN SELECT RAISE(ABORT,'immutable batch lifecycle event'); END;"
    M6_STATEMENTS.append(sql);TRIGGERS_M6[name]=('core_domain_model_events',' '.join(sql.split()))
