"""DF-060: mechanical, unique span mapping in one already-pinned excerpt.

No trimming, Unicode normalization, punctuation repair or semantic matching.
The returned quote is always the untouched contiguous original source span.
"""
from nmate.v03.core import CoreError

ASCII_WHITESPACE=frozenset(' \t\r\n')

def mismatch():
    raise CoreError('proposal_evidence_mismatch','Câu trích AI chưa khớp đoạn được cấp; giữ đầu ra để rà, không gọi lại.',409)

def ambiguous():
    raise CoreError('proposal_evidence_ambiguous','Câu trích có nhiều vị trí trong đoạn được cấp; giữ đầu ra để chuyên gia xác định vị trí, không gọi lại.',409)

def normalized_with_spans(text):
    chars=[];spans=[];index=0
    while index<len(text):
        start=index
        if text[index] in ASCII_WHITESPACE:
            index+=1
            while index<len(text) and text[index] in ASCII_WHITESPACE:index+=1
            chars.append(' ')
        else:
            chars.append(text[index]);index+=1
        spans.append((start,index))
    return ''.join(chars),spans

def align_v1(source,model_quote):
    if not isinstance(source,str) or not isinstance(model_quote,str) or not model_quote or model_quote.isspace():mismatch()
    position=source.find(model_quote)
    if position>=0:
        if source.find(model_quote,position+1)>=0:ambiguous()
        return dict(mode='exact/1',relative_start=position,relative_end=position+len(model_quote),
                    model_quote=model_quote,canonical_quote=model_quote)
    normalized_source,spans=normalized_with_spans(source)
    normalized_quote,_=normalized_with_spans(model_quote)
    position=normalized_source.find(normalized_quote)
    if position<0:mismatch()
    if normalized_source.find(normalized_quote,position+1)>=0:ambiguous()
    start=spans[position][0];end=spans[position+len(normalized_quote)-1][1]
    original=source[start:end]
    if normalized_with_spans(original)[0]!=normalized_quote:mismatch()
    return dict(mode='ascii-whitespace-span/1',relative_start=start,relative_end=end,
                model_quote=model_quote,canonical_quote=original)
