"""Exact M3→M4 operator; runtime never migrates or issues permissions."""
from contextlib import closing
from functools import lru_cache
from pathlib import Path
import json,sqlite3,tempfile
from .schema_m4 import M4_STATEMENTS
from .operator_m3 import expected_m3_objects,target_m3_contract
from .schema import M1_STATEMENTS
from .schema_m2 import M2_STATEMENTS
from .schema_m3 import M3_STATEMENTS
from nmate.core_v1.runtime_schema import schema_objects,open_readonly,verify_runtime_database,digest
from nmate.core_v1.schema_lifecycle import create_plan,apply_plan
from nmate.v03.core import CoreError

@lru_cache(maxsize=1)
def expected_m4_objects():
    with closing(sqlite3.connect(':memory:')) as db:
        for sql in M1_STATEMENTS+M2_STATEMENTS+M3_STATEMENTS+M4_STATEMENTS:db.execute(sql)
        return schema_objects(db)

def require_m4(db):
    wanted={r['name']:r for r in expected_m4_objects()}
    actual={r['name']:r for r in schema_objects(db) if r['name'] in wanted or r['name'].startswith(('kp_','pol_wiki_','core_domain_','ks_'))}
    if actual!=wanted:raise CoreError('knowledge_schema_not_ready','Cần operator kiểm schema phục vụ tri thức trước.',409)

def target_m4_contract():
    c=target_m3_contract();c['version']='nmate-main-20261027-knowledge-m4'
    known={r['name'] for r in expected_m3_objects()}
    c['required_objects']=sorted(c['required_objects']+[r for r in expected_m4_objects() if r['name'] not in known],key=lambda r:(r['type'],r['name']))
    return c

def install_m4_on_clone(database,*,backup_path):
    source=Path(__file__).resolve().parents[2]
    wanted3={r['name']:r for r in expected_m3_objects()};wanted4={r['name']:r for r in expected_m4_objects()}
    with closing(open_readonly(database)) as db:
        actual={r['name']:r for r in schema_objects(db) if r['name'].startswith(('kp_','pol_wiki_','core_domain_','ks_'))}
        if actual not in (wanted3,wanted4):raise CoreError('knowledge_schema_not_ready','Baseline M3/M4 đã lệch; chưa dry-run hoặc ghi schema.',409)
        if actual==wanted4:
            row=db.execute("SELECT plan_sha256,receipt_json FROM core_schema_migration_receipts WHERE version='knowledge-m4-20261027'").fetchone()
            if not row:raise CoreError('migration_receipt_required','Thiếu biên nhận M4; cần đối soát.',409)
            saved=json.loads(row[1])
            plan=dict(schema_version='schema-migration-plan/1',version='knowledge-m4-20261027',statements=M4_STATEMENTS,
                source=saved['source'],before_schema_sha256=saved['before_schema_sha256'],after_schema_sha256=saved['after_schema_sha256'],
                required_receipts=[],dry_run=dict(passed=True,original_writes=0,provider_calls=0))
            plan['plan_sha256']=digest(plan)
            if plan['plan_sha256']!=row[0] or saved['plan_sha256']!=row[0]:raise CoreError('migration_receipt_mismatch','Biên nhận M4 không khớp.',409)
            return dict(plan=plan,receipt=apply_plan(database,plan,source_root=source,backup_path=backup_path))
        if db.execute("SELECT 1 FROM sqlite_master WHERE name='v04_conversations'").fetchone():
            with tempfile.TemporaryDirectory(prefix='wiki-m4-contract-') as folder:
                path=Path(folder)/'contract.json';path.write_text(json.dumps(target_m3_contract()),encoding='utf-8')
                verify_runtime_database(database,contract_path=path)
    plan=create_plan(database,version='knowledge-m4-20261027',statements=M4_STATEMENTS,source_root=source,
        dependency_files=['nmate/knowledge_v1/schema_m4.py','nmate/knowledge_v1/operator_m4.py'])
    receipt=apply_plan(database,plan,source_root=source,backup_path=backup_path)
    with closing(sqlite3.connect(database)) as db:require_m4(db)
    return dict(plan=plan,receipt=receipt)
