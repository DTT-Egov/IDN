"""Released public wiki navigation. Never a rule or private-answer authority.

All content still passes M1/M2 canonical readers and current source READ. A
historical release grants READ of exactly its revision, not WRITE/expert roles.
"""
from datetime import date
import json,re
from .governance import WikiGovernance,_authority
from .operator_m4 import require_m4
from .pipeline import integrity
from .service import identifier
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.v03.core import CoreError,now_iso

REF_KEYS={'schema_version','kind','page_id','revision_id','release_event_id','review_event_id','body_hash','content_hash',
          'binding_hash','applicability_hash','review_manifest_hash','goal','target_date','jurisdiction'}

def validate_reference_shape(ref):
    from nmate.policy_v1.service import GOAL_LABELS
    if (not isinstance(ref,dict) or set(ref)!=REF_KEYS or any(not isinstance(v,str) for v in ref.values()) or
        ref.get('schema_version')!='released-wiki-ref/1' or ref.get('kind')!='released_wiki' or ref.get('jurisdiction')!='VN-HN'):
        raise CoreError('invalid_wiki_reference','Căn cứ wiki không đúng hợp đồng đã ghi.',409)
    for key in ('page_id','revision_id','release_event_id','review_event_id'):identifier(ref[key])
    for key in ('body_hash','content_hash','binding_hash','applicability_hash','review_manifest_hash'):
        if not re.fullmatch('[0-9a-f]{64}',ref[key]):raise CoreError('invalid_wiki_reference','Hash căn cứ wiki không hợp lệ.',409)
    try:
        if date.fromisoformat(ref['target_date']).isoformat()!=ref['target_date']:raise ValueError()
    except (TypeError,ValueError):raise CoreError('invalid_target_date','Ngày cần đối chiếu không hợp lệ.') from None
    if ref['goal'] not in GOAL_LABELS:raise CoreError('invalid_policy_goals','Nhu cầu chưa thuộc hợp đồng phục vụ.')
    return ref

def _json(value):
    try:return json.loads(value)
    except (TypeError,ValueError):integrity()

def _validate_applicability(payload):
    from nmate.policy_v1.service import GOAL_LABELS
    if (not isinstance(payload,dict) or set(payload)!={'goal_types','jurisdiction','usable_for','valid_from','valid_until'} or
        payload['jurisdiction']!='VN-HN' or payload['usable_for']!=['explain_public_policy'] or
        not isinstance(payload['goal_types'],list) or not 1<=len(payload['goal_types'])<=8 or
        any(not isinstance(g,str) or g not in GOAL_LABELS or g=='unspecified' for g in payload['goal_types']) or
        len(payload['goal_types'])!=len(set(payload['goal_types']))):
        raise CoreError('invalid_wiki_applicability','Cần đúng nhu cầu, phạm vi Hà Nội và quyền giải thích; chưa mở kết luận điều kiện hưởng.')
    try:
        start=date.fromisoformat(payload['valid_from'])
        end=date.fromisoformat(payload['valid_until']) if payload['valid_until'] is not None else None
        if start.isoformat()!=payload['valid_from'] or end and end.isoformat()!=payload['valid_until']:raise ValueError()
        if end and end<start:raise ValueError()
    except (ValueError,TypeError):raise CoreError('invalid_wiki_applicability','Ngày áp dụng cần đúng định dạng và thứ tự.') from None
    return payload

def applicability_binding(db,revision_id):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ks_wiki_applicability'").fetchone():return None
    row=db.execute('SELECT * FROM ks_wiki_applicability WHERE revision_id=?',(revision_id,)).fetchone()
    if not row:return None
    value=dict(row);payload=_json(value['payload_json'])
    if digest(payload)!=value['content_hash'] or digest({k:v for k,v in value.items() if k!='record_hash'})!=value['record_hash']:integrity()
    try:_validate_applicability(payload)
    except CoreError:integrity()
    return dict(schema_version='wiki-applicability/1',revision_id=value['revision_id'],page_id=value['page_id'],content_hash=value['content_hash'],payload=payload)

def _record(row):
    if row is None:raise CoreError('released_knowledge_not_found','Không có bản tri thức được phép đọc.',404)
    value=dict(row)
    if digest({k:v for k,v in value.items() if k!='record_hash'})!=value['record_hash']:integrity()
    return value

def _release_chain(db,page_id):
    head=WikiGovernance._head(db,'release',(page_id,));result=[]
    while head:
        if len(result)>=1000 or any(r['id']==head['id'] for r in result):integrity()
        result.append(head)
        if not head['previous_id']:
            if head['sequence']!=1:integrity()
            break
        previous=_record(db.execute('SELECT * FROM pol_wiki_releases WHERE page_id=? AND id=?',(page_id,head['previous_id'])).fetchone())
        if previous['sequence']+1!=head['sequence']:integrity()
        head=previous
    return result

def _proof(db,page_id,revision_id,release_id=None):
    binding=applicability_binding(db,revision_id)
    if not binding or binding['page_id']!=page_id:raise CoreError('released_knowledge_not_found','Chưa có bản tri thức đúng phạm vi được phép đọc.',404)
    choices=[r for r in _release_chain(db,page_id) if r['decision']=='published' and r['revision_id']==revision_id and (release_id is None or r['id']==release_id)]
    for release in choices:
        reviewed=_record(db.execute('SELECT * FROM pol_wiki_reviews WHERE id=? AND page_id=? AND revision_id=?',
            (release['review_id'],page_id,revision_id)).fetchone())
        manifest=_json(reviewed['manifest_json'])
        if digest(manifest)!=reviewed['manifest_hash']:integrity()
        if (reviewed['decision']=='approved' and release['manifest_hash']==reviewed['manifest_hash'] and
            manifest.get('applicability')==binding and manifest.get('page_id')==page_id and manifest.get('revision_id')==revision_id):
            return release,reviewed,manifest,binding
    raise CoreError('released_knowledge_not_found','Chưa có quyết định phát hành đúng bản và phạm vi.',404)

def historical_public_revision(db,page,revision_id):
    if not db.execute("SELECT 1 FROM sqlite_master WHERE name='ks_wiki_applicability'").fetchone():return False
    require_m4(db)
    try:_proof(db,page['id'],revision_id)
    except CoreError as exc:
        if exc.code=='released_knowledge_not_found':return False
        raise
    return True

class PublishedKnowledge(WikiGovernance):
    def __init__(self,repo):
        super().__init__(repo)
        with repo.connection() as db:require_m4(db)

    def bind_applicability(self,actor,page_id,*,revision_id,payload,operation_id):
        request=dict(page_id=page_id,revision_id=revision_id,payload=payload);kind='knowledge.wiki.applicability/1'
        with self.repo.connection(write=True) as db:
            hashed,replay=self._replay(db,actor,kind,operation_id,request)
            if replay is not None:return replay
            page=self._candidate_read(db,actor,identifier(page_id));identifier(revision_id)
            self._candidate_authorize(db,actor,page['policy_id'],page['evidence'])
            if page['revision_id']!=revision_id or page['lifecycle']!='active':
                raise CoreError('revision_conflict','Bản wiki đã đổi hoặc đã cất; chưa gắn phạm vi.',409)
            _validate_applicability(payload)
            if db.execute('SELECT 1 FROM ks_wiki_applicability WHERE revision_id=?',(revision_id,)).fetchone():
                raise CoreError('applicability_already_bound','Bản này đã có phạm vi; cần tạo revision mới để sửa.',409)
            value=dict(revision_id=revision_id,page_id=page_id,payload_json=canonical(payload),content_hash=digest(payload),actor_id=actor,created_at=now_iso())
            db.execute('INSERT INTO ks_wiki_applicability VALUES(?,?,?,?,?,?,?)',(*value.values(),digest(value)))
            self._event(db,actor,'wiki',page_id,revision_id,'wiki_applicability_bound',{'applicability_hash':value['content_hash']})
            result=applicability_binding(db,revision_id)
            self._save(db,actor,kind,operation_id,request,hashed,result,[dict(kind='pipeline_candidate',page_id=page_id,revision_id=revision_id)])
            return result

    @staticmethod
    def _reference(page,release,review,binding,goal,target_date):
        return dict(schema_version='released-wiki-ref/1',kind='released_wiki',page_id=page['page_id'],revision_id=page['revision_id'],
            release_event_id=release['id'],review_event_id=review['id'],body_hash=page['body_hash'],content_hash=page['content_hash'],
            binding_hash=page['binding_hash'],applicability_hash=binding['content_hash'],review_manifest_hash=review['manifest_hash'],
            goal=goal,target_date=target_date,jurisdiction='VN-HN')

    def _read_reference(self,db,actor,ref,*,mode='history',export=False):
        self._active(db,actor)
        if mode not in {'history','current'} or type(export) is not bool:raise CoreError('invalid_knowledge_mode','Chế độ đọc chưa hợp lệ.')
        validate_reference_shape(ref)
        release,review,manifest,binding=_proof(db,ref['page_id'],ref['revision_id'],ref['release_event_id'])
        page=self._candidate_read(db,actor,ref['page_id'],ref['revision_id'],export=export)
        if (ref!=self._reference(page,release,review,binding,ref['goal'],ref['target_date']) or
            any(manifest.get(k)!=page[k] for k in ('body_hash','content_hash','binding_hash'))):integrity()
        try:target=date.fromisoformat(ref['target_date'])
        except (ValueError,TypeError):raise CoreError('invalid_target_date','Ngày cần đối chiếu không hợp lệ.') from None
        scope=binding['payload']
        if ref['goal'] not in scope['goal_types'] or target<date.fromisoformat(scope['valid_from']) or (scope['valid_until'] and target>date.fromisoformat(scope['valid_until'])):
            raise CoreError('wiki_scope_mismatch','Bản wiki không áp dụng cho nhu cầu hoặc ngày này.',409)
        if mode=='current':
            view=self._workbench(db,actor,page['page_id'])
            current=self._head(db,'release',(page['page_id'],))
            if (not current or current['id']!=release['id'] or view['candidate']['revision_id']!=page['revision_id'] or
                view['governance']['publication_state']!='published' or view['review_manifest_hash']!=ref['review_manifest_hash']):
                raise CoreError('released_wiki_stale','Tri thức đã thay đổi hoặc chưa đạt kiểm tra hiện hành; giữ lịch sử, chưa dùng tư vấn mới.',409)
            sources={r['source_id'] for r in page['evidence']}
            _authority(db,review['actor_id'],page['policy_id'],sources,'review')
            _authority(db,release['actor_id'],page['policy_id'],sources,'publish')
        # Expose content without editor buffers/roles/actor identity. Every raw
        # quotation has gone through the same original evidence resolver.
        citations=[]
        for evidence in page['evidence']:
            source=next((s for s in manifest['sources'] if s['source_id']==evidence['source_id']),None)
            if source is None:integrity()
            recorded=source['manifest']
            citations.append(dict(ref=evidence,url=recorded['url'],language=recorded['language'],
                quote_original=evidence['quote'],excerpt_vi=evidence['quote'] if recorded['language']=='vi' else None))
        return dict(page_id=page['page_id'],revision_id=page['revision_id'],title=page['title'],body=page['body'],
            claims=page['claims'],section_ids=page['section_ids'],citations=citations,assessment_eligible=False,
            usable_for=['explain_public_policy'],notice_vi='Giải thích từ bản đã phát hành; chưa phải kết luận doanh nghiệp được hưởng hỗ trợ.')

    def read_reference(self,actor,ref,*,mode='history',export=False):
        with self.repo.connection() as db:return self._read_reference(db,actor,ref,mode=mode,export=export)

    def _current_control_proofs(self,db,actor,ref,*,export=False):
        self._read_reference(db,actor,ref,mode='current',export=export)
        _,_,manifest,_=_proof(db,ref['page_id'],ref['revision_id'],ref['release_event_id'])
        from .source_control import current
        controls=[]
        for source in manifest['sources']:
            proof=current(db,source['source_id'])
            if not proof['anchored']:raise CoreError('released_wiki_stale','Cần kiểm nguồn mới trước khi dùng.',409)
            controls.append(dict(source_id=source['source_id'],**proof,attestation_id=source['attestation_id']))
        return dict(schema_version='wiki-current-authorization/1',reference_hash=digest(ref),
          review_manifest_hash=ref['review_manifest_hash'],source_control_refs=controls)

    def lookup(self,actor,*,goals,target_date):
        from nmate.policy_v1.service import GOAL_LABELS
        try:date.fromisoformat(target_date)
        except (TypeError,ValueError):raise CoreError('invalid_target_date','Ngày cần đối chiếu không hợp lệ.') from None
        if (not isinstance(goals,list) or not 1<=len(goals)<=9 or any(not isinstance(g,str) or g not in GOAL_LABELS for g in goals) or len(set(goals))!=len(goals)):
            raise CoreError('invalid_policy_goals','Cần danh sách nhu cầu hữu hạn, không trùng.')
        result=[]
        with self.repo.connection() as db:
            self._active(db,actor)
            rows=db.execute('SELECT page_id,revision_id FROM ks_wiki_applicability ORDER BY revision_id LIMIT 500').fetchall()
            for goal in goals:
                refs=[];explanations=[]
                for row in rows:
                    binding=applicability_binding(db,row['revision_id'])
                    if goal not in binding['payload']['goal_types']:continue
                    try:
                        release,review,_,binding=_proof(db,row['page_id'],row['revision_id'])
                        page=self._candidate_read(db,actor,row['page_id'],row['revision_id'])
                        ref=self._reference(page,release,review,binding,goal,target_date)
                        content=self._read_reference(db,actor,ref,mode='current')
                    except CoreError as exc:
                        if exc.status_code in (403,404) or exc.code in {'released_wiki_stale','wiki_scope_mismatch'}:continue
                        raise
                    refs.append(ref);explanations.append(content)
                    if len(refs)>=min(5,20//len(goals)):break
                result.append(dict(schema_version='policy-evidence-bundle/2',outcome_id=goal,domain='hanoi_policy',
                    scope=dict(jurisdiction='VN-HN',target_date=target_date),decision='public_explanation_available' if refs else 'source_incomplete',
                    source_refs=[e for c in explanations for e in (x['ref'] for x in c['citations'])],member_refs=[],pack_release_refs=[],
                    wiki_revision_refs=refs,explanations=explanations,retrieval_policy_revision='released-wiki/1',assessment_eligible=False,
                    usable_for=['explain_public_policy'] if refs else [],blocked_for=['eligibility_conclusion'],
                    missing_evidence=['reviewed_applicable_rule'] if refs else ['reviewed_released_policy_for_this_goal'],provider_call_required=False))
        return result
