"""Explicit M3-public-staging extension. No runtime DDL or business backfill."""
from contextlib import closing
from functools import lru_cache
from pathlib import Path
import json,sqlite3
from nmate.core_v1.runtime_schema import schema_objects,digest,open_readonly
from nmate.core_v1.schema_lifecycle import create_plan,apply_plan
from nmate.v03.core import CoreError
from .schema import M1_STATEMENTS
from .schema_m2 import M2_STATEMENTS
from .schema_m3 import M3_STATEMENTS
from .schema_m6 import M6_STATEMENTS
VERSION='knowledge-m6-20261027'

@lru_cache(maxsize=1)
def extension_objects():
    with closing(sqlite3.connect(':memory:')) as db:
        for sql in M1_STATEMENTS+M2_STATEMENTS+M3_STATEMENTS+M6_STATEMENTS:db.execute(sql)
        return [r for r in schema_objects(db) if r['name'].startswith('kw_')]

def has_extension(db):return bool(db.execute("SELECT 1 FROM sqlite_master WHERE substr(name,1,3)='kw_'").fetchone())

def require_extension(db,*,original_schema_hash=None):
    wanted={r['name']:r for r in extension_objects()}
    objects=schema_objects(db)
    actual={r['name']:r for r in objects if r['name'].startswith('kw_')}
    if actual!=wanted:raise CoreError('WORKER_SCHEMA_REQUIRED','Cần operator nâng schema worker đúng kế hoạch; không tự sửa khi đọc.',409)
    base=[r for r in objects if r['name'] not in wanted]
    if original_schema_hash is not None and digest(base)!=original_schema_hash:raise CoreError('STAGING_SCHEMA_CHANGED','Baseline ngoài extension M6 khác prepared gốc.',409)
    row=db.execute('SELECT plan_sha256,receipt_json FROM core_schema_migration_receipts WHERE version=?',(VERSION,)).fetchone()
    if row is None:raise CoreError('MIGRATION_RECEIPT_REQUIRED','Extension M6 thiếu biên nhận operator.',409)
    receipt=json.loads(row['receipt_json'])
    plan=dict(schema_version='schema-migration-plan/1',version=VERSION,statements=M6_STATEMENTS,source=receipt['source'],
      before_schema_sha256=receipt['before_schema_sha256'],after_schema_sha256=receipt['after_schema_sha256'],required_receipts=[],
      dry_run=dict(passed=True,original_writes=0,provider_calls=0))
    if (digest(plan)!=row['plan_sha256'] or receipt['plan_sha256']!=row['plan_sha256']
      or receipt.get('business_data_writes')!=0 or receipt.get('provider_calls')!=0
      or receipt['before_schema_sha256']!=digest([r for r in base if r['name']!='core_schema_migration_receipts'])
      or receipt['after_schema_sha256']!=digest([r for r in objects if r['name']!='core_schema_migration_receipts'])):
        raise CoreError('MIGRATION_RECEIPT_MISMATCH','Extension/receipt không khớp exact baseline và DDL M6.',409)
    plan['plan_sha256']=row['plan_sha256']
    return dict(plan=plan,receipt=receipt)

def install_m6(database,*,prepared,backup_path):
    if Path(database).resolve()!=Path(prepared['database']).resolve():raise CoreError('STAGING_INSTANCE_CHANGED','Target operator phải đúng prepared đã chỉ định.',409)
    from .public_batch import existing_repository
    existing_repository(prepared)  # Original/known-extension classification before dry-run.
    source=Path(__file__).resolve().parents[2]
    with closing(open_readonly(database)) as db:
        db.row_factory=sqlite3.Row
        if has_extension(db):
            existing=require_extension(db,original_schema_hash=prepared['schema_sha256'])
            return dict(plan=existing['plan'],receipt=apply_plan(database,existing['plan'],source_root=source,backup_path=backup_path))
    plan=create_plan(database,version=VERSION,statements=M6_STATEMENTS,source_root=source,
      dependency_files=['nmate/knowledge_v1/schema_m6.py','nmate/knowledge_v1/operator_m6.py'])
    receipt=apply_plan(database,plan,source_root=source,backup_path=backup_path)
    with closing(open_readonly(database)) as db:
        db.row_factory=sqlite3.Row;require_extension(db,original_schema_hash=prepared['schema_sha256'])
    return dict(plan=plan,receipt=receipt)
