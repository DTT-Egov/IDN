"""Typed public drafts. Recording is not human authoring, approval or release."""
import json
from jsonschema import Draft202012Validator
from nmate.core_v1.domain_gateway import PublicDomainScope
from nmate.core_v1.runtime_schema import canonical,digest
from nmate.v03.core import CoreError,new_id,now_iso
from .pipeline import integrity
from .service import identifier

PROPOSAL_SCHEMA={'type':'object','properties':{
    'title':{'type':'string','minLength':1,'maxLength':300},
    'claims':{'type':'array','maxItems':12,'items':{'type':'object','properties':{
        'kind':{'type':'string','enum':['source_excerpt','interpretation']},
        'text':{'type':'string','minLength':1,'maxLength':1400},
        'evidence':{'type':'array','minItems':1,'maxItems':4,'items':{'type':'object','properties':{
            'evidence_id':{'type':'string'},'quote':{'type':'string','minLength':1,'maxLength':1000}},
            'required':['evidence_id','quote'],'additionalProperties':False}}},
        'required':['kind','text','evidence'],'additionalProperties':False}},
    'gaps':{'type':'array','items':{'type':'string','maxLength':700},'maxItems':12},
    'questions_for_expert':{'type':'array','items':{'type':'string','maxLength':700},'maxItems':8}},
    'required':['title','claims','gaps','questions_for_expert'],'additionalProperties':False}


def receipt_data(service,gateway,actor,attempt_id):
    with service.repo.connection() as db:
        row=db.execute('SELECT * FROM core_domain_model_attempts WHERE id=?',(identifier(attempt_id),)).fetchone()
        if row is None or row['actor_id']!=actor: raise CoreError('knowledge_not_found','Không có đề xuất được phép.',404)
        dep=json.loads(row['dependencies_json']);scope=PublicDomainScope(dep['domain'],dep['policy_id'])
        result=gateway.read_domain_receipt(service,actor,scope,attempt_id)
        sealed=db.execute('SELECT body_json FROM core_domain_request_inputs WHERE attempt_id=?',(attempt_id,)).fetchone()
        body=json.loads(sealed[0]);inv=db.execute('SELECT invocation_json FROM core_domain_grant_scopes WHERE grant_id=?',(row['grant_id'],)).fetchone()
        return result,dep,body,json.loads(inv[0])


def candidate_payload(service,actor,data,body):
    """Frozen v2 semantics retained for historical qualification, not upgraded."""
    return _candidate_payload(service,actor,data,body,aligned=False)


def candidate_payload_v3(service,actor,data,body):
    """Versioned mechanical alignment, without semantic/currentness approval."""
    return _candidate_payload(service,actor,data,body,aligned=True)


def _candidate_payload(service,actor,data,body,*,aligned,artifact=False):
    contract=PROPOSAL_SCHEMA
    if artifact:
        import copy
        contract=copy.deepcopy(PROPOSAL_SCHEMA)
        contract['properties']['claims']['maxItems']=40
        contract['properties']['gaps']['maxItems']=40
    Draft202012Validator(contract).validate(data)
    supplied={x['evidence_id']:x['ref'] for x in body['input']['source_excerpts']}
    lines=[];claims=[];decisions=[];offset=0
    for claim in data['claims']:
        refs=[];alignments=[]
        for evidence in claim['evidence']:
            ref=supplied.get(evidence['evidence_id']);quote=evidence['quote']
            if not ref or ref['kind']!='pipeline_chunk':
                raise CoreError('proposal_evidence_mismatch','Câu trích AI chưa khớp đoạn được cấp; giữ đầu ra để rà, không gọi lại.',409)
            if aligned:
                from .quote_alignment import align_v1
                alignment=align_v1(ref['quote'],quote)
                quote=alignment['canonical_quote'];relative=alignment['relative_start']
                alignments.append(dict(evidence_id=evidence['evidence_id'],source_ref_hash=digest(ref),**alignment))
            else:
                if quote not in ref['quote']:
                    raise CoreError('proposal_evidence_mismatch','Câu trích AI chưa khớp đoạn được cấp; giữ đầu ra để rà, không gọi lại.',409)
                relative=ref['quote'].index(quote)
                if ref['quote'].find(quote,relative+1)!=-1:
                    raise CoreError('proposal_evidence_ambiguous','Câu trích có nhiều vị trí trong đoạn được cấp; giữ đầu ra để chuyên gia xác định vị trí, không gọi lại.',409)
            absolute=ref['quote_start']+relative
            refs.append(service.pipeline_evidence(actor,ref['chunk_id'],quote,quote_start=absolute))
        content=claim['text'];lines.append(content)
        # A model label is an assertion, not authority. Verified quotations
        # remain exact; a paraphrase can only lose trust, never gain it.
        effective=claim['kind'];warnings=[]
        if effective=='source_excerpt' and not any(content in ref['quote'] for ref in refs):
            effective='interpretation'
            warnings.append('model_excerpt_is_paraphrase')
        if effective=='interpretation': warnings.append('semantic_entailment_not_verified')
        decisions.append(dict(model_kind=claim['kind'],effective_kind=effective,semantic_verified=False,warnings=warnings))
        if aligned:decisions[-1]['evidence_alignment']=alignments
        claims.append(dict(kind=effective,start=offset,end=offset+len(content),text=content,evidence=refs))
        offset+=len(content)+2
    return dict(title=data['title'],body='\n\n'.join(lines),claims=claims,aliases=[],links=[]),dict(
        version='proposal-admission/3' if aligned else 'proposal-admission/2',requires_expert_review=True,claims=decisions)


def _verified_stored(service,row,actor,result,dep,body,invocation):
    from nmate.core_v1.domain_gateway import stored_json
    value=stored_json(row['payload_json'])
    if (digest(value)!=row['content_hash'] or not isinstance(value,dict) or
        value.get('model_output')!=result['data'] or value.get('generated_by')!=row['attempt_id'] or
        value.get('assignee_id')!=actor or row['assignee_id']!=actor or row['policy_id']!=dep['policy_id'] or
        value.get('invoked_by')!=invocation or stored_json(row['invocation_json'])!=invocation or
        value.get('reviewed_by') is not None or value.get('published_by') is not None): integrity()
    admission=value.get('admission')
    if admission is not None and (not isinstance(admission,dict) or admission.get('version') not in {'proposal-admission/2','proposal-admission/3','proposal-admission/4'}):integrity()
    # Verify each historical version against its fixed original semantics.
    # A mutable version label must not bypass evidence checks by pretending
    # an aligned v3 record was a legacy exact-only record. No stored row changes.
    typed=body.get('response_schema',{}).get('properties',{}).get('contract_version',{}).get('const')=='policy-demo/1'
    if typed:
        if not admission or admission.get('version')!='proposal-admission/4':integrity()
        from .demo_artifacts import candidate
        candidate,verified=candidate(service,actor,result['data'],body)
    elif admission is not None and admission['version']=='proposal-admission/3':
        candidate,verified=candidate_payload_v3(service,actor,result['data'],body)
    else:
        candidate,verified=_candidate_payload(service,actor,result['data'],body,aligned=False)
    if digest(value.get('candidate'))!=digest(candidate):integrity()
    if admission is not None and digest(admission)!=digest(verified):integrity()
    return value


def record_proposal(service,gateway,actor,attempt_id):
    result,dep,body,invocation=receipt_data(service,gateway,actor,attempt_id)
    # Return the committed projection before deriving today's recipe. Old v1
    # receipts are never rewritten/backfilled by a new admission adapter.
    with service.repo.connection() as db:
        old=db.execute('SELECT * FROM pol_wiki_ai_proposals WHERE attempt_id=?',(attempt_id,)).fetchone()
        if old:
            _verified_stored(service,old,actor,result,dep,body,invocation)
            return {'proposal_id':old['id'],'state':'awaiting_expert','cached':True}
    # Verification is mechanical only, not entailment or legal-currentness.
    if body.get('response_schema',{}).get('properties',{}).get('contract_version',{}).get('const')=='policy-demo/1':
        from .demo_artifacts import candidate
        payload,admission=candidate(service,actor,result['data'],body)
    else:
        payload,admission=candidate_payload_v3(service,actor,result['data'],body)
    value=dict(model_output=result['data'],candidate=payload,generated_by=attempt_id,
               invoked_by=invocation,assignee_id=actor,reviewed_by=None,published_by=None,admission=admission)
    with service.repo.connection(write=True) as db:
        service._active(db,actor)
        for ref in dep['source_refs']: service._resolve(db,actor,ref)
        old=db.execute('SELECT * FROM pol_wiki_ai_proposals WHERE attempt_id=?',(attempt_id,)).fetchone()
        if old:
            _verified_stored(service,old,actor,result,dep,body,invocation)
            return {'proposal_id':old['id'],'state':'awaiting_expert','cached':True}
        pid=new_id('wiki_proposal')
        # A typed all-gap artifact is a reviewable negative result, not a wiki
        # claim. Keep it only as a proposal; never manufacture evidence or relax
        # PipelineService's non-empty claim coverage for actual wiki writes.
        if payload['claims'] or admission.get('version')!='proposal-admission/4':
            service._validate_bindings(db,actor,payload['body'],payload['claims'],[],[])
        db.execute('INSERT INTO pol_wiki_ai_proposals VALUES(?,?,?,?,?,?,?,?)',
            (pid,attempt_id,dep['policy_id'],actor,canonical(invocation),canonical(value),digest(value),now_iso()))
        return {'proposal_id':pid,'state':'awaiting_expert','cached':False}


def read_proposal(service,gateway,actor,proposal_id):
    with service.repo.connection() as db:
        row=db.execute('SELECT * FROM pol_wiki_ai_proposals WHERE id=? AND assignee_id=?',(identifier(proposal_id),actor)).fetchone()
        if row is None: raise CoreError('knowledge_not_found','Không có đề xuất được phép.',404)
    result,dep,body,invocation=receipt_data(service,gateway,actor,row['attempt_id'])
    payload=_verified_stored(service,row,actor,result,dep,body,invocation)
    return dict(row)|{'payload':payload,'state':'awaiting_expert'}
