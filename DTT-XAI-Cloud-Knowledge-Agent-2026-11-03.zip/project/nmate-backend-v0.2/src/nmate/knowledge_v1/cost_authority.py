"""Operator-pinned account assignment, NOT a D06 budget or SDK authority.

The owner's account choice permits recording a scoped continuation only. All
money, calls, expiry, egress and dispatch still belong to the original Gateway.
No runtime SQL roles, source rights, grants, sessions or schemas are created.
"""

from dataclasses import dataclass
from contextlib import closing
from pathlib import Path
import copy
import hashlib
import json
import sqlite3
from nmate.v03.core import CoreError
from .service import identifier

KEYS = {
    "schema_version",
    "assignment_id",
    "main_database",
    "public_batch_directory",
    "subject",
    "scope_id",
    "capability",
    "active",
    "approved_by",
    "approval_reference",
}


def deny():
    raise CoreError(
        "COST_APPROVAL_DENIED",
        "Tài khoản chưa có quyền duyệt tiếp tục nhánh này, hoặc quyền đã bị thu hồi.",
        403,
    )


@dataclass(frozen=True)
class ApproverAssignment:
    path: Path
    sha256: str
    record: dict

    @classmethod
    def load(cls, path, expected_sha256):
        try:
            path = Path(path).resolve(strict=True)
            raw = path.read_bytes()
            if not isinstance(expected_sha256, str) or hashlib.sha256(raw).hexdigest() != expected_sha256:
                deny()
            record = json.loads(raw)
            if (
                not isinstance(record, dict)
                or set(record) != KEYS
                or record["schema_version"] != "cost-approver-assignment/1"
                or record["active"] is not True
                or record["capability"] != "continue_independent_O2"
                or record["approved_by"] != "project_owner"
                or not isinstance(record["subject"], dict)
                or set(record["subject"]) != {"account_id", "username"}
                or not isinstance(record["subject"]["username"], str)
                or not record["subject"]["username"]
                or not isinstance(record["approval_reference"], str)
                or not record["approval_reference"]
            ):
                deny()
            identifier(record["assignment_id"])
            identifier(record["subject"]["account_id"])
            if not isinstance(record["scope_id"], str) or not record["scope_id"].startswith(
                "public_domain:hanoi_policy:"
            ):
                deny()
            for key in ("main_database", "public_batch_directory"):
                candidate = Path(record[key])
                if not candidate.is_absolute() or str(candidate.resolve()) != str(candidate):
                    deny()
            return cls(path, expected_sha256, copy.deepcopy(record))
        except (OSError, ValueError, TypeError, KeyError):
            deny()

    def descriptor(self):
        return dict(
            realm="main_account",
            account_id=self.record["subject"]["account_id"],
            username=self.record["subject"]["username"],
            assignment_id=self.record["assignment_id"],
            assignment_path=str(self.path),
            assignment_sha256=self.sha256,
        )

    def check_identity(self, actor):
        if actor != self.record["subject"]["account_id"]:
            deny()
        # READ-only direct identity check avoids constructor/startup/backfill and
        # never touches password hashes, sessions or private enterprise facts.
        try:
            with closing(
                sqlite3.connect(Path(self.record["main_database"]).as_uri() + "?mode=ro", uri=True)
            ) as db:
                db.execute("PRAGMA query_only=ON")
                row = db.execute("SELECT username,active FROM v03_accounts WHERE id=?", (actor,)).fetchone()
            if row is None or row[0] != self.record["subject"]["username"] or row[1] != 1:
                deny()
        except (OSError, sqlite3.Error):
            deny()

    def check_write(self, actor):
        self.check_identity(actor)
        current = type(self).load(self.path, self.sha256)
        if current.record != self.record:
            deny()

    def check_target(self, prepared):
        from nmate.core_v1.domain_gateway import PublicDomainScope
        from .public_batch import POLICY

        if (
            prepared["account_id"] != self.record["subject"]["account_id"]
            or PublicDomainScope("hanoi_policy", POLICY).key != self.record["scope_id"]
        ):
            deny()


def verify_dispatch_authority(approver, *, scope_id, directory):
    if not isinstance(approver, dict) or set(approver) != {
        "realm",
        "account_id",
        "username",
        "assignment_id",
        "assignment_path",
        "assignment_sha256",
    }:
        deny()
    assignment = ApproverAssignment.load(approver["assignment_path"], approver["assignment_sha256"])
    if (
        assignment.descriptor() != approver
        or assignment.record["scope_id"] != scope_id
        or Path(directory).resolve() != Path(assignment.record["public_batch_directory"]).resolve()
    ):
        deny()
    assignment.check_write(approver["account_id"])
