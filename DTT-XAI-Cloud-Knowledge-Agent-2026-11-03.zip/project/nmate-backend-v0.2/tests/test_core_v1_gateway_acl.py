"""Real ACL + Gateway integration with a local deterministic transport only."""
import asyncio
from datetime import datetime, timedelta, timezone

import pytest

import nmate.core_v1.finance as finance_module
from nmate.core_v1.finance import FinanceService
from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository, now_iso


OUTPUT = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "gateway-acl.sqlite")
    with repo.connection(write=True) as db:
        for account in ("owner", "colleague", "outsider"):
            db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES(?,?,?,?)",
                       (account, account, "test-no-login", now_iso()))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('enterprise','Trà Sen',?)", (now_iso(),))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('other','Doanh nghiệp khác',?)", (now_iso(),))
        # Multiple existing owner memberships are deliberately supported legacy
        # data; one owner's private resource is not another owner's by default.
        db.executemany("INSERT INTO v03_memberships VALUES(?,'enterprise','owner',1)", [("owner",), ("colleague",)])
        db.execute("INSERT INTO v03_memberships VALUES('outsider','other','owner',1)")
    resource = repo.create_entity("colleague", "enterprise", "enterprise", "Hồ sơ hạn chế")
    other_resource = repo.create_entity("owner", "enterprise", "enterprise", "Hồ sơ riêng khác")
    core = CoreSSOTService(repo)
    finance = FinanceService(repo, core)
    core.grant_resource("colleague", "enterprise", resource["id"], "owner", ["read"], ["name"])
    calls = []

    async def transport(model, body, limit):
        calls.append({"model": model, "body": body, "limit": limit})
        return {"text": '{"answer":"Đã đối chiếu theo phần được phép."}', "model": model,
                "usage": {"input_tokens": 100, "output_tokens": 50}, "stop_reason": "end_turn"}

    gateway = ModelGateway(repo, core=core, finance=finance, request_fn=transport, enabled=True)
    budget = gateway.authorize_budget("owner", "enterprise", approval_id="DETERMINISTIC-TEST-NO-NETWORK",
               max_calls=3, max_cost_usd="2", purposes=["policy_synthesis"], roles=["standard"],
               expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())["id"]
    return repo, core, finance, gateway, budget, resource["id"], other_resource["id"], calls


async def invoke(setup, *, operation="model-op", resource=None, context=None, grant_ids=None):
    _, _, _, gateway, budget, _, _, _ = setup
    return await gateway.call_once(account_id="owner", enterprise_id="enterprise", operation_id=operation,
               task_id="summary", role="standard", purpose="policy_synthesis", context=context or {"question": "Tôi cần hỗ trợ số hóa kho"},
               output_schema=OUTPUT, budget_grant_id=budget, financial_egress_grant_ids=grant_ids,
               resource_id=resource)


def authorize_finance(setup):
    _, core, finance, _, _, resource, _, _ = setup
    core.grant_resource("colleague", "enterprise", resource, "owner", ["read", "read_finance", "send_financial_metrics"], ["revenue"])
    projection = finance.stage_metrics("owner", "enterprise", resource,
                 [{"metric_code": "revenue", "value": "1000000.25", "unit": "VND",
                   "period_start": "2025-01-01", "period_end": "2026-01-01", "scope": "enterprise"}], "stage")
    return finance.grant_egress("owner", "enterprise", projection["projection_id"], "egress", "summary", "policy_synthesis",
               "standard/1", (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())


def test_cache_cannot_omit_or_substitute_original_resource_after_revoke(setup):
    _, core, _, _, _, resource, other_resource, calls = setup
    first = asyncio.run(invoke(setup, resource=resource))
    core.revoke_resource("colleague", "enterprise", resource, "owner")
    for substituted in (resource, None, other_resource):
        with pytest.raises(CoreError):
            asyncio.run(invoke(setup, resource=substituted))
    assert len(calls) == 1 and first["cached"] is False


def test_cache_binds_original_egress_grants_even_when_payload_identical(setup):
    _, _, finance, _, _, resource, _, calls = setup
    authorized = authorize_finance(setup)
    original = [authorized["grant_id"]]
    asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=original))
    replacement = finance.grant_egress("owner", "enterprise", authorized["projection_id"], "replacement",
                  "summary", "policy_synthesis", "standard/1", authorized["expires_at"])
    for substituted in ([], [replacement["grant_id"]]):
        with pytest.raises(CoreError):
            asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=substituted))
    assert len(calls) == 1


def test_expired_egress_cache_read_is_free_but_new_operation_is_blocked(setup, monkeypatch):
    _, _, _, _, _, resource, _, calls = setup
    authorized = authorize_finance(setup)
    ids = [authorized["grant_id"]]
    first = asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))

    class AfterExpiry(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime.now(tz) + timedelta(hours=2)
    monkeypatch.setattr(finance_module, "datetime", AfterExpiry)
    cached = asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))
    assert cached["cached"] and cached["data"] == first["data"]
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, operation="new-paid-op", resource=resource, context=authorized["payload"], grant_ids=ids))
    assert len(calls) == 1


def test_revoked_financial_field_blocks_cached_read_with_resource_still_readable(setup):
    _, core, _, _, _, resource, _, calls = setup
    authorized = authorize_finance(setup)
    ids = [authorized["grant_id"]]
    asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read_finance"], ["revenue"])
    assert core.can_read("owner", "enterprise", resource)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))
    assert len(calls) == 1


def test_derivative_block_is_enforced_on_gateway_cached_reads(setup):
    _, _, finance, _, _, resource, _, calls = setup
    authorized = authorize_finance(setup)
    ids = [authorized["grant_id"]]
    asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))
    finance.revoke_egress("owner", "enterprise", authorized["grant_id"], block_derivatives=True)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=ids))
    assert len(calls) == 1


def test_acl_revoked_between_reservation_and_dispatch_never_reaches_transport(setup, monkeypatch):
    repo, core, finance, _, _, resource, _, calls = setup
    authorized = authorize_finance(setup)
    verify = finance.verify_dispatch
    checks = []

    def revoke_after_check(*args, **kwargs):
        result = verify(*args, **kwargs)
        checks.append(1)
        if len(checks) == 1:
            # Simulate a change observed by the second authoritative check in the
            # same controlled service boundary; no network/provider is invoked.
            db = kwargs["db"]
            db.execute("UPDATE core_v1_grants SET revoked_at=? WHERE enterprise_id='enterprise' AND resource_id=? "
                       "AND account_id='owner' AND capability='read_finance' AND field_key='revenue'", (now_iso(), resource))
        return result
    monkeypatch.setattr(finance, "verify_dispatch", revoke_after_check)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, resource=resource, context=authorized["payload"], grant_ids=[authorized["grant_id"]]))
    assert calls == [] and core.can_read("owner", "enterprise", resource)
    with repo.connection() as db:
        attempt = db.execute("SELECT * FROM core_model_attempts").fetchone()
        assert attempt["state"] == "cancelled_before_dispatch"
        assert attempt["dispatched_at"] is None and attempt["held_microusd"] == 0
