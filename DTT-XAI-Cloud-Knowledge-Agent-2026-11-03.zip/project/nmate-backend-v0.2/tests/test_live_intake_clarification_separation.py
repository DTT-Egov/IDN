"""Recorded failure shape, local provider only: no SDK or paid transport."""
import copy
import json

import pytest

from nmate.main.partial import project_partial_research
from nmate.v03.core import CoreError
from nmate.v03.live_review import interpret_validated_intake, requests_three_first_actions, validate_intake, validate_research
from test_v03_live_review import research, setup as shared_setup


# The exact outcome/ambiguity shape received in the failed FDA intake. The
# surrounding question is synthetic and contains each original quoted clause.
QUESTION = ("Chị có Trà Sen Tây Hồ, hộp 100 g, mã TS01; gửi 500 hộp sang New York thì có phải đăng ký cơ sở với FDA không, "
            "nhãn hộp cần ghi những gì và ba việc đầu tiên nên làm?")
RECORDED_INTAKE = {
    "scope": "us_food", "product_name": "Trà Sen Tây Hồ", "product_quote": "Trà Sen Tây Hồ",
    "outcomes": [
        {"id": "registration", "question_quote": "gửi 500 hộp sang New York thì có phải đăng ký cơ sở với FDA không"},
        {"id": "label", "question_quote": "nhãn hộp cần ghi những gì"},
        {"id": "clarification", "question_quote": "ba việc đầu tiên nên làm"},
    ],
    "ambiguities": ["Chưa rõ cơ sở sản xuất/đóng gói/lưu kho đã đăng ký FDA hay chưa và nằm ở đâu.",
                    "Chưa có thành phần, thông tin dinh dưỡng hay công bố trên nhãn để nghiên cứu yêu cầu nhãn chi tiết.",
                    "Chưa rõ 'ba việc đầu tiên' là các bước cho đăng ký cơ sở, nhãn hay toàn bộ quy trình xuất khẩu."],
}


@pytest.fixture(name="setup")
def setup_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


def test_saved_intake_can_be_projected_without_storage_or_rewriting_the_provider_result():
    original = copy.deepcopy(RECORDED_INTAKE)
    validated = validate_intake({"data": original}, QUESTION)
    projected, name = interpret_validated_intake(validated, QUESTION)
    assert [outcome.id for outcome in projected.outcomes] == ["registration", "label"]
    assert projected.requested_action_count == 3 and name == "Trà Sen Tây Hồ"
    assert validated.model_dump() == original == RECORDED_INTAKE
    assert projected.ambiguities == [] and projected.clarification_requests == []


def test_action_preference_does_not_erase_another_question_from_the_same_quote():
    quote = "ba việc đầu tiên nên làm và ai nộp hồ sơ thay chị?"
    data = copy.deepcopy(RECORDED_INTAKE)
    data["outcomes"][-1]["question_quote"] = quote
    validated = validate_intake({"data": data}, QUESTION + " " + quote)
    projected, _ = interpret_validated_intake(validated, QUESTION + " " + quote)
    assert projected.requested_action_count == 3
    assert projected.clarification_requests == [quote]
    assert [outcome.id for outcome in projected.outcomes] == ["registration", "label"]


@pytest.mark.asyncio
async def test_recorded_mixed_clarification_keeps_two_research_tasks_and_original_output(setup):
    repo, owner, _, model, service = setup
    model.intake_transform = lambda _: copy.deepcopy(RECORDED_INTAKE)
    plan = await service.prepare_async(*scope(owner), QUESTION, "mixed-intake")
    assert plan["status"] == "planned"
    assert [o["id"] for o in plan["intent"]["outcomes"]] == ["registration", "label"]
    assert plan["intent"]["ambiguities"] == []
    assert plan["intent"]["preliminary_information_gaps"] == RECORDED_INTAKE["ambiguities"]
    assert plan["intent"]["clarification_requests"] == []
    assert plan["intent"]["requested_action_count"] == 3
    assert not any(task["id"] == "clarification-gap" for task in plan["plan"]["tasks"])
    with repo.connection() as db:
        raw = db.execute("SELECT output_json FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (plan["id"],)).fetchone()[0]
    assert json.loads(raw) == RECORDED_INTAKE
    service.start(*scope(owner), plan["id"], "mixed-start")
    assert await service.execute_next()
    result = service.get(*scope(owner), plan["id"])
    assert result["status"] == "completed_partial"
    assert {answer["outcome_id"] for answer in result["answers"]} == {"registration", "label"}
    assert all(answer["citations"] for answer in result["answers"])
    assert [call[0] for call in model.calls] == ["intake", "research"]
    assert all("tiếp tục gọi đúng 'chị' hoặc 'anh'" in call[1]["instructions_vi"] for call in model.calls)
    assert (await service.prepare_async(*scope(owner), QUESTION, "mixed-intake"))["id"] == plan["id"]
    assert not await service.execute_next() and len(model.calls) == 2


@pytest.mark.asyncio
async def test_real_input_question_is_retained_separately_without_becoming_a_research_task(setup):
    _, owner, _, model, service = setup
    question = QUESTION + " Ai sẽ nộp hồ sơ thay chị?"
    data = copy.deepcopy(RECORDED_INTAKE)
    data["outcomes"][-1]["question_quote"] = "Ai sẽ nộp hồ sơ thay chị?"
    model.intake_transform = lambda _: data
    plan = await service.prepare_async(*scope(owner), question, "separate-question")
    assert plan["status"] == "planned"
    assert plan["intent"]["clarification_requests"] == ["Ai sẽ nộp hồ sơ thay chị?"]
    assert {o["id"] for o in plan["intent"]["outcomes"]} == {"registration", "label"}
    assert len(model.calls) == 1


@pytest.mark.parametrize("mutation", [
    lambda data: data["outcomes"][-1].update(question_quote="Câu hỏi không nằm trong tin nhắn"),
    lambda data: data["outcomes"][0].update(id="prior_notice"),
    lambda data: data["outcomes"].append(copy.deepcopy(data["outcomes"][-1])),
    lambda data: data.update(scope="export_food"),
])
def test_separation_does_not_bypass_quote_topic_duplicate_or_market_checks(mutation):
    data = copy.deepcopy(RECORDED_INTAKE)
    mutation(data)
    with pytest.raises(CoreError):
        validate_intake({"data": data}, QUESTION)


@pytest.mark.asyncio
async def test_separated_intent_still_quarantines_missing_evidence_and_preserves_supported_answer(setup):
    _, owner, _, model, service = setup
    model.intake_transform = lambda _: copy.deepcopy(RECORDED_INTAKE)
    planned = await service.prepare_async(*scope(owner), QUESTION, "source-boundary")
    mission = service._internal(planned["id"])
    output = research({"input": {"reference_records": mission["knowledge"]["records"], "outcomes": mission["intent"]["outcomes"]}})
    label = next(answer for answer in output["answers"] if answer["outcome_id"] == "label")
    label["citations"] = []
    with pytest.raises(CoreError, match="trích đoạn"):
        validate_research({"data": output}, mission)
    partial = project_partial_research({**mission, "status": "failed"}, {"data": output})
    assert [answer["outcome_id"] for answer in partial["validated_answers"]] == ["registration"]
    assert [answer["outcome_id"] for answer in partial["blocked_outcomes"]] == ["label"]
    assert partial["model_calls"] == partial["ssot_writes"] == 0
    assert partial["actions"] == partial["artifacts"] == []
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_research_extra_clarification_cannot_hide_valid_cited_parts_or_become_a_legal_answer(setup):
    _, owner, _, model, service = setup
    model.intake_transform = lambda _: copy.deepcopy(RECORDED_INTAKE)
    planned = await service.prepare_async(*scope(owner), QUESTION, "research-extra-question")
    mission = service._internal(planned["id"])
    output = research({"input": {"reference_records": mission["knowledge"]["records"], "outcomes": mission["intent"]["outcomes"]}})
    # No artifact exists in this failed original report, so this example only
    # presents cited general guidance, never invents a ready label artifact.
    next(answer for answer in output["answers"] if answer["outcome_id"] == "label")["status"] = "answered_general"
    output["answers"].append({"outcome_id": "clarification", "status": "needs_input",
        "text": "Chị muốn ba việc đầu tiên cho cơ sở hay toàn bộ lô hàng?",
        "details_vi": "Đây là câu hỏi bổ sung của mô hình, không phải kết luận pháp lý.",
        "citations": [], "missing_fields": []})
    with pytest.raises(CoreError, match="đúng từng ý"):
        validate_research({"data": output}, mission)
    partial = project_partial_research({**mission, "status": "failed"}, {"data": output})
    assert {answer["outcome_id"] for answer in partial["validated_answers"]} == {"registration", "label"}
    assert partial["audit"]["quarantined_answer_indexes"] == [2]
    assert not partial["blocked_outcomes"] and not partial["complete_report"]
    assert partial["mission_status"] == "failed"
    assert partial["actions"] == partial["artifacts"] == []
    assert len(model.calls) == 1


@pytest.mark.parametrize("text,expected", [
    ("ba việc đầu tiên nên làm", True), ("3 bước cần làm trước", True),
    ("ba việc ưu tiên", True), ("Ba công ty cần đăng ký", False),
    ("Ba loại chứng nhận này có bắt buộc không?", False),
])
def test_next_action_preference_is_not_an_invented_research_topic(text, expected):
    assert requests_three_first_actions(text) is expected
