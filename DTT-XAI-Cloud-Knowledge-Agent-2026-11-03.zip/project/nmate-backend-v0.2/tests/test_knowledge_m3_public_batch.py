"""Offline batch preparation/issuance retains attribution, not private data."""
import json
import pytest
from test_knowledge_m1 import kb
from nmate.knowledge_v1.public_batch import prepare,issue_grant
from nmate.v03.core import now_iso

@pytest.fixture(autouse=True)
def isolated_registry(monkeypatch,tmp_path):
    from nmate.knowledge_v1 import public_batch
    monkeypatch.setattr(public_batch,'_APPROVAL_REGISTRY_DIR',tmp_path/'approval-registry-test-only')

def test_public_staging_excludes_credentials_enterprises_and_does_not_replenish(kb,tmp_path):
    repo,_,actor,other,_=kb
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_accounts SET username='trung@dtt.vn' WHERE id=?",(other,))
    with repo.connection() as db: before=list(db.iterdump())
    folder=tmp_path/'public-build'
    prepared=prepare(repo.db_path,folder)
    assert prepared['provider_calls']==0 and prepared['account_id']==other
    grant=issue_grant(prepared,folder)
    assert issue_grant(prepared,folder)['id']==grant['id']
    assert prepare(repo.db_path,folder)==prepared
    import sqlite3
    with sqlite3.connect(prepared['database']) as db:
        assert db.execute('SELECT count(*) FROM v03_enterprises').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM v03_memberships').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM core_domain_budget_grants').fetchone()[0]==1
        assert db.execute('SELECT count(*) FROM core_model_attempts').fetchone()[0]==0
        assert all(r[0].startswith('!non-login-') for r in db.execute('SELECT password_hash FROM v03_accounts'))
        assert db.execute('SELECT count(*) FROM pol_wiki_reviews').fetchone()[0]==0
    with repo.connection() as db: assert list(db.iterdump())==before
    second=prepare(repo.db_path,tmp_path/'second-public-build')
    from nmate.v03.core import CoreError
    with pytest.raises(CoreError): issue_grant(second,tmp_path/'second-public-build')
    with sqlite3.connect(second['database']) as db:
        assert db.execute('SELECT count(*) FROM core_domain_budget_grants').fetchone()[0]==0
