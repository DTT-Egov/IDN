"""Current business facts and information gaps must not become old conflicts.

Injected outputs only: no provider SDK, network or paid inference.
"""
from copy import deepcopy
import json

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_review import LiveReviewMissionService, selected_product_projection, ssot_context_projection


GAPS = [
    "Hồ sơ ghi 100 g nhưng nguồn ảnh cũ ghi 120 g; cần xác nhận.",
    "Thành phần từ ảnh từng có trạng thái owner_confirmation_required.",
    "Bao bì Hộp giấy tái chế khác quan sát cũ Hộp giấy.",
]
QUESTION = "Tôi muốn chuẩn bị nhãn cho Đức."


class Model:
    def __init__(self):
        self.calls = []
        self.data = {"scope": "export_food", "outcomes": [{"id": "label", "question_quote": "nhãn"}],
                     "product_name": None, "product_quote": None, "ambiguities": deepcopy(GAPS)}

    async def __call__(self, kind, payload, **scope):
        self.calls.append((kind, deepcopy(payload), scope))
        if kind == "research":
            answers = []
            for outcome in payload["input"]["outcomes"]:
                topic = "food_label" if outcome["id"] == "label" else "facility_registration"
                record = next(record for record in payload["input"]["reference_records"] if topic in record["topics"])
                answers.append({"outcome_id": outcome["id"], "status": "needs_input",
                                "text": "Theo trích đoạn đã lưu, cần đối chiếu phạm vi trước khi kết luận riêng.",
                                "details_vi": "Nguồn này là tài liệu tham khảo chưa được chuyên gia rà đầy đủ.",
                                "citations": [{"source_id": record["id"], "quote_original": record["excerpt"]}], "missing_fields": []})
            data = {"answers": answers, "actions": []}
        else:
            data = deepcopy(self.data)
        return {"data": data, "attempt_id": f"projection-{len(self.calls)}", "model": "injected-unit-output"}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "current-ssot.sqlite3")
    owner = LocalAccounts(repo).register("owner", "TestPassword12345", "Doanh nghiệp Sen")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    product = repo.create_entity(account, enterprise, "product", "Trà Sen Tây Hồ 2026")
    declarations = [{"field": field, "value": value, "source": {
                        "kind": "owner_selected_candidate", "quote": "120 g from old observation",
                        "filename": "tra-sen-label-QA-120g.png", "review_state": "owner_confirmation_required"}}
                    for field, value in (("name", "Trà Sen Tây Hồ 2026"), ("net_quantity", "100 g"),
                                         ("packaging", "Hộp giấy tái chế"), ("ingredients", ["Trà xanh", "Hoa sen"]))]
    repo.propose_or_apply_facts(account, enterprise, product["id"], declarations, product["version"], "confirmed-current-facts")
    model = Model()
    return repo, account, enterprise, product["id"], model, LiveReviewMissionService(repo, model_call=model)


@pytest.mark.asyncio
async def test_intake_sees_current_known_values_without_old_observation_metadata_and_keeps_audit_unchanged(setup):
    repo, account, enterprise, product, model, service = setup
    original = repo.get_entity(account, enterprise, product)
    mission = await service.prepare_async(account, enterprise, QUESTION, "current-facts-input", product, market_code="DE")
    current = model.calls[0][1]["input"]["selected_product"]
    assert current["id"] == current["entity_id"] == product
    assert current["version"] == original["version"]
    assert current["name"] == "Trà Sen Tây Hồ 2026"
    assert current["values"]["net_quantity"] == "100 g"
    assert current["values"]["packaging"] == "Hộp giấy tái chế"
    assert current["values"]["ingredients"] == ["Trà xanh", "Hoa sen"]
    assert current["ssot_current"]["authoritative_for_business_context"] is True
    assert current["ssot_current"]["reconfirmation_required"] is False
    assert current["ssot_current"]["verification_state"] == "owner_self_declared_not_legal_verification"
    assert current["historical_observations_excluded"] is True
    encoded = json.dumps(current, ensure_ascii=False)
    assert "120g.png" not in encoded and "120 g" not in encoded
    assert "owner_confirmation_required" not in encoded
    assert "filename" not in encoded and "source" not in encoded and "review_state" not in encoded
    assert repo.get_entity(account, enterprise, product) == original
    assert mission["status"] == "planned" and mission["intent"]["ambiguities"] == []
    assert mission["intent"]["preliminary_information_gaps"] == GAPS
    with repo.connection() as db:
        intake = json.loads(db.execute("SELECT output_json FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (mission["id"],)).fetchone()[0])
    assert intake["ambiguities"] == GAPS


def test_projection_excludes_expired_unknown_or_withheld_facts_and_is_independently_mutable():
    original = {"id": "entity", "entity_type": "product", "name": "Trà Sen", "version": 2,
                "facts": [{"field": "ingredients", "value": ["Trà"], "value_type": "list", "value_state": "known", "freshness_state": "self_declared", "source": {"quote": "old"}},
                          {"field": "net_quantity", "value": "120 g", "value_state": "known", "freshness_state": "expired"},
                          {"field": "origin_country", "value": None, "value_state": "unknown", "freshness_state": "self_declared"},
                          {"field": "nutrition_information", "value": None, "value_state": "withheld", "freshness_state": "self_declared"}]}
    before = deepcopy(original)
    projected = selected_product_projection(original)
    assert projected["values"] == {"ingredients": ["Trà"]}
    projected["values"]["ingredients"].append("Sen")
    assert original == before


@pytest.mark.asyncio
async def test_true_clarification_still_blocks_research(setup):
    _, account, enterprise, product, model, service = setup
    question = "Tôi muốn tìm hiểu."
    model.data.update(outcomes=[{"id": "clarification", "question_quote": question}], ambiguities=["Bạn muốn nghiên cứu việc gì?"])
    mission = await service.prepare_async(account, enterprise, question, "true-clarification", product, market_code="DE")
    assert mission["status"] == "waiting_input"
    assert mission["intent"]["ambiguities"] == ["Bạn muốn nghiên cứu việc gì?"]
    assert mission["intent"]["preliminary_information_gaps"] == []
    with pytest.raises(CoreError):
        service.start(account, enterprise, mission["id"], "cannot-research-clarification")
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_server_market_ambiguity_remains_blocking_even_when_model_outcome_is_clear(setup):
    _, account, enterprise, product, model, service = setup
    model.data["scope"] = "unsupported"
    mission = await service.prepare_async(account, enterprise, QUESTION, "conflicting-market", product, market_code="US")
    assert mission["status"] == "waiting_input"
    assert mission["intent"]["ambiguities"]
    assert any("khác" in item for item in mission["intent"]["ambiguities"])
    assert mission["intent"]["preliminary_information_gaps"] == GAPS
    with pytest.raises(CoreError):
        service.start(account, enterprise, mission["id"], "cannot-research-market-conflict")


@pytest.mark.asyncio
async def test_server_product_mismatch_remains_blocking(setup):
    _, account, enterprise, product, model, service = setup
    question = "Tôi có Bột Sen gửi Đức, cần nhãn."
    model.data.update(product_name="Bột Sen", product_quote="Bột Sen")
    mission = await service.prepare_async(account, enterprise, question, "conflicting-product", product, market_code="DE")
    assert mission["status"] == "waiting_input"
    assert any("Tên sản phẩm" in item for item in mission["intent"]["ambiguities"])
    assert mission["intent"]["preliminary_information_gaps"] == GAPS
    with pytest.raises(CoreError):
        service.start(account, enterprise, mission["id"], "cannot-research-product-conflict")


@pytest.mark.asyncio
async def test_non_product_selection_is_rejected_before_any_model_call(setup):
    repo, account, enterprise, _, model, service = setup
    facility = repo.create_entity(account, enterprise, "facility", "Xưởng trà")
    with pytest.raises(CoreError, match="đúng sản phẩm"):
        await service.prepare_async(account, enterprise, QUESTION, "not-a-product", facility["id"], market_code="DE")
    assert model.calls == []


@pytest.mark.asyncio
async def test_synthesis_receives_same_current_ssot_boundary_without_reopening_old_observations(setup):
    _, account, enterprise, product, model, service = setup
    mission = await service.prepare_async(account, enterprise, QUESTION, "synthesis-current-facts", product, market_code="DE")
    full_context_before = deepcopy(mission["context"])
    assert "tra-sen-label-QA-120g.png" in json.dumps(full_context_before, ensure_ascii=False)
    service.start(account, enterprise, mission["id"], "synthesis-current-facts-start")
    assert await service.execute_next()
    payload = next(payload for kind, payload, _ in model.calls if kind == "research")
    current = payload["input"]["ssot_context"]
    assert current["values"]["name"] == "Trà Sen Tây Hồ 2026"
    assert current["values"]["net_quantity"] == "100 g"
    assert current["values"]["packaging"] == "Hộp giấy tái chế"
    assert current["values"]["ingredients"] == ["Trà xanh", "Hoa sen"]
    assert current["shared_values"]["net_quantity"] == "100 g"
    assert current["entities"][0]["version"] == full_context_before["entities"][0]["version"]
    assert current["fact_refs"] == full_context_before["fact_refs"]
    assert current["ssot_current"]["verification_state"] == "owner_self_declared_not_legal_verification"
    encoded = json.dumps(payload, ensure_ascii=False)
    assert "120g.png" not in encoded and "120 g from old observation" not in encoded
    assert "owner_confirmation_required" not in encoded and '"filename"' not in encoded
    assert service.get(account, enterprise, mission["id"])["context"] == full_context_before
    assert len(model.calls) == 2


def test_context_projection_retains_only_canonical_current_values_and_reference_ids():
    entity = {"id": "product", "entity_type": "product", "name": "Trà Sen", "version": 3,
              "facts": [{"field": "name", "value": "Trà Sen", "value_state": "known", "freshness_state": "self_declared"},
                        {"field": "net_quantity", "value": "100 g", "value_state": "known", "freshness_state": "self_declared", "source": {"quote": "old120g", "filename": "old120g.png"}},
                        {"field": "facility_type", "value": "Old factory", "value_state": "known", "freshness_state": "expired"}]}
    original = {"entities": [entity], "values": {"name": "Trà Sen", "net_quantity": "100 g", "facility_type": "Old factory"},
                "shared_values": {"name": "Trà Sen", "net_quantity": "100 g"}, "market_values": {},
                "fact_refs": [{"entity_id": "product", "field": "net_quantity", "version": 2, "assertion_id": "fact-2"}],
                "context_revision": 7}
    before = deepcopy(original)
    current = ssot_context_projection(original)
    assert current["values"] == {"name": "Trà Sen", "net_quantity": "100 g"}
    assert current["fact_refs"] == original["fact_refs"]
    assert current["context_revision"] == 7
    assert "old120g" not in json.dumps(current)
    assert original == before
