"""Exact authorized subject sets precede resolver selection; no model IO."""
import unicodedata
import json

import pytest

from nmate.v03.core import CoreError, json_text
from nmate.v04.conversations import ConversationService
from nmate.v04.product_binding import product_scope
from test_product_reference_binding_closure import local_workspace as reference_workspace
from test_review_commands_v2 import data_snapshot


@pytest.fixture
def local_workspace(tmp_path):
    return reference_workspace.__wrapped__(tmp_path)


def products(workspace, names):
    repo, _intake, account, enterprise = workspace
    return [repo.create_entity(account, enterprise, "product", name) for name in names]


def resolve(workspace, text, selected=None):
    repo, intake, account, enterprise = workspace
    with repo.connection() as db:
        return intake.resolve_product_reference(account, enterprise, text, db, selected=selected)


@pytest.mark.parametrize("text", [
    "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho.",
    "Chị xem hồ sơ Bắc Sơn và Hồng Hà để đối chiếu tồn kho.",
    "Chị xem hồ sơ HỒNG HÀ và BẮC SƠN để đối chiếu tồn kho.",
    unicodedata.normalize("NFD", "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho."),
])
def test_known_subject_enumeration_offers_every_authorized_identity_before_selection(local_workspace, text):
    left, right, unrelated = products(local_workspace, ["Hồng Hà", "Bắc Sơn", "An Nhiên"])
    repo, *_ = local_workspace
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        resolve(local_workspace, text)
    assert error.value.code == "ambiguous_product"
    assert {item["id"] for item in error.value.details["matched_entities"]} == {left["id"], right["id"]}
    assert resolve(local_workspace, text, left["id"]) == left["id"]
    assert resolve(local_workspace, text, right["id"]) == right["id"]
    with pytest.raises(CoreError) as blocked:
        resolve(local_workspace, text, unrelated["id"])
    assert blocked.value.code == "ambiguous_product"
    assert data_snapshot(repo) == before


def test_long_known_literal_containing_conjunction_is_one_identity_not_a_list(local_workspace):
    _left, _right, full = products(local_workspace, ["Hồng Hà", "Bắc Sơn", "Hồng Hà và Bắc Sơn"])
    repo, *_ = local_workspace
    before = data_snapshot(repo)
    assert resolve(local_workspace, "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho.") == full["id"]
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("subject", ["Hồng Hà và Gió Mới", "Gió Mới và Bắc Sơn", "Hồng Hà và Gió Mới và Bắc Sơn",
    "Hồng Hà và Bắc Sơn Cao Cấp",
    "Hồng Hà Mới", "Bắc Sơn Cao Cấp", "Hồng Hà và Bắc Sơn mở rộng"])
def test_unknown_full_name_or_right_suffix_never_resolves_to_a_saved_prefix(local_workspace, subject):
    products(local_workspace, ["Hồng Hà", "Bắc Sơn", "Hồng Hà và Bắc Sơn"])
    repo, *_ = local_workspace
    before = data_snapshot(repo)
    assert resolve(local_workspace, "Chị xem hồ sơ " + subject + " để đối chiếu tồn kho.") is None
    assert data_snapshot(repo) == before


def test_aliases_of_same_identity_are_deduplicated_but_other_subject_is_preserved(local_workspace):
    repo, _intake, account, enterprise = local_workspace
    left, right = products(local_workspace, ["Hồng Hà", "Bắc Sơn"])
    repo.propose_or_apply_facts(account, enterprise, left["id"], [{"field": "name", "value": "Hồng Hà 2026"}],
                               left["version"], "rename-authorized-product")
    before = data_snapshot(repo)
    text = "Chị xem hồ sơ Hồng Hà và Hồng Hà 2026 và Bắc Sơn để đối chiếu tồn kho."
    with pytest.raises(CoreError) as error:
        resolve(local_workspace, text)
    assert {item["id"] for item in error.value.details["matched_entities"]} == {left["id"], right["id"]}
    assert len(error.value.details["matched_entities"]) == 2
    assert resolve(local_workspace, text, left["id"]) == left["id"]
    assert data_snapshot(repo) == before


def test_accents_remain_identity_when_forming_an_authorized_subject_set(local_workspace):
    accented, plain, right = products(local_workspace, ["Hồng Hà", "Hong Ha", "Bắc Sơn"])
    with pytest.raises(CoreError) as error:
        resolve(local_workspace, "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho.")
    offered = {item["id"] for item in error.value.details["matched_entities"]}
    assert offered == {accented["id"], right["id"]} and plain["id"] not in offered


@pytest.mark.parametrize("excluded", ["archived", "revoked"])
def test_ineligible_subject_cannot_supply_a_connector_endpoint_or_leak_in_offers(local_workspace, excluded):
    repo, _intake, account, enterprise = local_workspace
    _left, right = products(local_workspace, ["Hồng Hà", "Bắc Sơn"])
    if excluded == "archived":
        repo.archive_entity(account, enterprise, right["id"], right["version"], "archive-enumeration-right")
    else:
        with repo.connection(write=True) as db:
            db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (right["id"],))
    before = data_snapshot(repo)
    assert resolve(local_workspace, "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho.") is None
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("subject", ["Hồng Hà và Gió Mới", "Gió Mới và Bắc Sơn", "Hồng Hà và Gió Mới và Bắc Sơn",
    "Hồng Hà và Bắc Sơn Cao Cấp", "Trà Sen Mới"])
@pytest.mark.parametrize("selected_index", [0, 1])
def test_unknown_named_profile_lookup_does_not_borrow_selected_or_previous_product(local_workspace, subject, selected_index):
    repo, intake, account, enterprise = local_workspace
    available = products(local_workspace, ["Hồng Hà", "Bắc Sơn"])
    chats = ConversationService(intake)
    first = chats.send(account, enterprise, "Chị xem hồ sơ Hồng Hà để đối chiếu tồn kho.", [], "first-lookup")
    before_old = intake.get(account, enterprise, first["intake"]["id"])
    before = data_snapshot(repo)
    text = "Chị xem hồ sơ " + subject + " để đối chiếu tồn kho."
    second = chats.send(account, enterprise, text, [], "unknown-profile-lookup", first["id"], product_entity_id=available[selected_index]["id"])
    item = second["intake"]
    assert item["product"] is None and item["product_binding"]["state"] == "unbound_reference"
    assert item["product_binding"]["referenced_name"] == subject
    assert item["candidates"] == [] and item["reused_context"]["entity_ids"] == []
    assert intake.get(account, enterprise, before_old["id"])["candidates"] == before_old["candidates"]
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == before[table]


@pytest.mark.parametrize("text", ["Chị xem hồ sơ này để đối chiếu tồn kho.",
    "Chị đọc hồ sơ đã chọn để đối chiếu tồn kho.", "Ngày 18/10/2026, mã TS01"])
def test_deictic_and_bare_followups_keep_intentional_selected_context(local_workspace, text):
    repo, intake, account, enterprise = local_workspace
    product = products(local_workspace, ["Hồng Hà"])[0]
    before = data_snapshot(repo)
    with repo.connection() as db:
        chosen, binding = product_scope(intake, account, enterprise, text, db, selected=product["id"])
    assert chosen == product["id"] and binding["confirmed"] is True
    assert data_snapshot(repo) == before


def test_named_lookup_of_food_conjunction_is_resolved_as_authorized_subjects_before_new_name_parser(local_workspace):
    tea, powder = products(local_workspace, ["Trà Sen", "Bột Sen"])
    with pytest.raises(CoreError) as error:
        resolve(local_workspace, "Chị xem hồ sơ Trà Sen và Bột Sen để đối chiếu tồn kho.")
    assert error.value.code == "ambiguous_product"
    assert {item["id"] for item in error.value.details["matched_entities"]} == {tea["id"], powder["id"]}


def test_bare_followup_after_intentional_selection_in_food_lookup_keeps_that_bound_profile(local_workspace):
    repo, intake, account, enterprise = local_workspace
    tea, _powder = products(local_workspace, ["Trà Sen", "Bột Sen"])
    chats = ConversationService(intake)
    first = chats.send(account, enterprise,
        "Chị xem hồ sơ Trà Sen và Bột Sen để đối chiếu tồn kho.", [], "selected-food-list", product_entity_id=tea["id"])
    followup = chats.send(account, enterprise, "Ngày 18/10/2026, mã TS01", [], "bare-date-after-selected-list", first["id"])
    assert followup["intake"]["product"]["id"] == tea["id"]
    assert not any(candidate["field"] == "name" for candidate in followup["intake"]["candidates"])


def test_decomposed_named_lookup_does_not_borrow_selection_and_keeps_original_spelling(local_workspace):
    repo, intake, account, enterprise = local_workspace
    product = products(local_workspace, ["Hồng Hà"])[0]
    subject = unicodedata.normalize("NFD", "Hồng Hà và Gió Mới")
    text = unicodedata.normalize("NFD", "Chị xem hồ sơ ") + subject + unicodedata.normalize("NFD", " để đối chiếu tồn kho.")
    item = intake.prepare(account, enterprise, text, [], "nfd-unknown-reference", product["id"])
    assert item["product"] is None and item["product_binding"]["referenced_name"] == subject
    assert item["text"] == text and item["candidates"] == []


@pytest.mark.parametrize("prior_subject,ambiguous", [("Bắc Sơn", False), ("Gió Mới", False),
    ("Hồng Hà và Bắc Sơn", True)])
def test_legacy_bare_followup_does_not_inherit_a_contradicted_untyped_product(local_workspace, prior_subject, ambiguous):
    repo, intake, account, enterprise = local_workspace
    tea, _left, _right = products(local_workspace, ["Trà Sen", "Hồng Hà", "Bắc Sơn"])
    chats = ConversationService(intake)
    first = chats.send(account, enterprise, "Tên sản phẩm: Trà Sen", [], "legacy-first-product", product_entity_id=tea["id"])
    with repo.connection(write=True) as db:
        raw = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (first["intake"]["id"],)).fetchone()[0])
        raw.pop("product_binding", None)
        raw["text"] = "Chị xem hồ sơ " + prior_subject + " để đối chiếu tồn kho."
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(raw), raw["id"]))
    before = data_snapshot(repo)
    if ambiguous:
        with pytest.raises(CoreError) as error:
            chats.send(account, enterprise, "Ngày 18/10/2026, mã TS01", [], "legacy-bare-followup", first["id"])
        assert error.value.code == "ambiguous_product"
        assert data_snapshot(repo) == before
    else:
        followup = chats.send(account, enterprise, "Ngày 18/10/2026, mã TS01", [], "legacy-bare-followup", first["id"])
        assert followup["intake"]["product"] is None
        assert followup["intake"]["reused_context"]["entity_ids"] == []
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == before[table]
