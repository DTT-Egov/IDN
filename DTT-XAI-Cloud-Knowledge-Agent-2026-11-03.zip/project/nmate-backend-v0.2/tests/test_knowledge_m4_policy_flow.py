"""Enterprise-private cases reuse public release, not another enterprise's facts."""
import json
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed
from test_knowledge_m4_serving import serving,release
from nmate.core_v1.ssot import CoreSSOTService
from nmate.policy_v1.service import PolicyService
from nmate.v03.core import CoreError
from nmate.v03.identity import LocalAccounts

QUESTION='Chị cần hỗ trợ xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách buổi tối. Có đủ điều kiện không?'

def company(repo,core,user,name):
    entity=repo.create_entity(user['account_id'],user['enterprise_id'],'enterprise',name)
    facts=[{'field':'legal_form','value':'Công ty trách nhiệm hữu hạn'}, {'field':'registration_province','value':'Hà Nội'}, {'field':'business_sector','value':name}]
    proposed=core.propose_facts(user['account_id'],user['enterprise_id'],entity['id'],facts,0,'propose-company-'+name)
    core.confirm_facts(user['account_id'],user['enterprise_id'],proposed['proposal_id'],0,'confirm-company-'+name,proposal_hash=proposed['proposal_hash'])
    return entity

def test_two_enterprises_reuse_same_public_release_but_cases_and_ssot_stay_private(serving):
    repo,_,s,_,_,_,a,_=serving;release(serving);core=CoreSSOTService(repo)
    b=LocalAccounts(repo).register('TEST-other-shop','Synthetic-password-abc','THỬ NGHIỆM Tiệm B')
    ca=company(repo,core,a,'THỬ NGHIỆM Trà Sen A');cb=company(repo,core,b,'THỬ NGHIỆM B riêng')
    policy=PolicyService(repo,core)
    qa=policy.prepare(a['account_id'],a['enterprise_id'],QUESTION,'prepare-wiki-A',entity_ids=[ca['id']])
    qb=policy.prepare(b['account_id'],b['enterprise_id'],QUESTION,'prepare-wiki-B',entity_ids=[cb['id']])
    assert [x['outcome_id'] for x in qa['knowledge_bundles']]==['market_development','workforce_training']
    assert [x['decision'] for x in qa['knowledge_bundles']]==['source_incomplete','public_explanation_available']
    assert qa['knowledge_bundles'][1]['wiki_revision_refs']==qb['knowledge_bundles'][1]['wiki_revision_refs']
    assert qa['knowledge_bundles'][1]['context_manifest_ref']!=qb['knowledge_bundles'][1]['context_manifest_ref']
    assert 'THỬ NGHIỆM B riêng' not in str(qa) and 'THỬ NGHIỆM Trà Sen A' not in str(qb)
    assert qa['question']==QUESTION and 'buổi tối' in qa['question']
    assert qa['intent']['request_constraints']=={'training_schedule':'evening'}
    assert qa['knowledge_bundles'][1]['unresolved_request_constraints']==['training_schedule:evening']
    assert qa['provider_calls']==0 and qa['knowledge_bundles'][1]['assessment_eligible'] is False
    with pytest.raises(CoreError):policy.get(b['account_id'],b['enterprise_id'],qa['id'])
    with repo.connection() as db:before=list(db.iterdump())
    assert policy.prepare(a['account_id'],a['enterprise_id'],QUESTION,'prepare-wiki-A',entity_ids=[ca['id']])['knowledge_bundles']==qa['knowledge_bundles']
    for _ in range(5):assert policy.get(a['account_id'],a['enterprise_id'],qa['id'])['knowledge_bundles']==qa['knowledge_bundles']
    with repo.connection() as db:assert list(db.iterdump())==before

def test_policy_history_labels_withdrawn_release_without_rewriting_saved_case(serving):
    repo,g,s,_,expert,page,user,_=serving;released=release(serving)
    policy=PolicyService(repo,CoreSSOTService(repo))
    case=policy.prepare(user['account_id'],user['enterprise_id'],QUESTION,'prepare-before-withdraw')
    with repo.connection() as db:saved=db.execute('SELECT payload_json FROM pol_missions WHERE id=?',(case['id'],)).fetchone()[0]
    g.withdraw_wiki(expert,page['page_id'],expected_release_id=released['release_event_id'],rationale='TEST withdraw',operation_id='withdraw-policy')
    read=policy.get(user['account_id'],user['enterprise_id'],case['id'])
    assert read['knowledge_bundles']==case['knowledge_bundles']
    assert read['knowledge_current_status'][1]['usable_now'] is False
    assert read['is_historical'] is True
    with repo.connection() as db:assert db.execute('SELECT payload_json FROM pol_missions WHERE id=?',(case['id'],)).fetchone()[0]==saved

@pytest.mark.parametrize('question,expected',[
  ('Chị cần đào tạo nhân viên buổi tối',{'training_schedule':'evening'}),
  ('Chị cần đào tạo nhân viên, không học buổi tối',{}),
  ('Chị cần hỗ trợ xuất khẩu, không cần đào tạo nhân viên buổi tối',{}),
  ('Chị hỏi thời tiết buổi tối',{})])
def test_request_schedule_is_finite_and_negation_scoped(question,expected):
    from nmate.policy_v1.service import resolve_intent
    assert resolve_intent(question).get('request_constraints',{})==expected

@pytest.mark.asyncio
@pytest.mark.parametrize('bad',['none','invented_section','withdraw_during_inference'])
async def test_langgraph_wiki_selection_is_bounded_and_rechecked_before_publication(serving,bad):
    from test_policy_v1 import analysis_response
    repo,g,_,_,expert,page,user,_=serving;released=release(serving)
    class Gateway:
        def __init__(self):self.calls=[]
        async def call_once(self,**kwargs):
            self.calls.append(kwargs)
            candidates=kwargs['context']['analysis_candidates'];sections=candidates['wiki_sections']
            output=analysis_response(kwargs['context']);output['schema_version']='policy-model-analysis/3'
            output['wiki_section_ids']=['invented'] if bad=='invented_section' else [sections[0]['id']]
            if bad=='withdraw_during_inference':
                g.withdraw_wiki(expert,page['page_id'],expected_release_id=released['release_event_id'],rationale='TEST changed during model',operation_id='withdraw-during-inference')
            return dict(data=output,attempt_id='TEST-NO-PAID-PROVIDER',model='TEST-ONLY',usage={})
    gateway=Gateway();service=PolicyService(repo,CoreSSOTService(repo),gateway)
    case=service.prepare(user['account_id'],user['enterprise_id'],QUESTION,'prepare-graph-wiki')
    assert case['startable'] is True
    service.start(user['account_id'],user['enterprise_id'],case['id'],'start-graph','TEST-ONLY-grant',model_role='simple')
    result=await service.execute_next()
    assert len(gateway.calls)==1
    assert gateway.calls[0]['public_wiki_refs']==case['knowledge_bundles'][1]['wiki_revision_refs']
    assert gateway.calls[0]['context']['intent']['request_constraints']=={'training_schedule':'evening'}
    assert any(t['id']=='verify_evening_training_schedule' for t in gateway.calls[0]['context']['analysis_candidates']['next_tasks'])
    if bad=='none':
        assert result['status']=='completed_partial' and result['model_analysis']['schema_version']=='policy-model-analysis/3'
        assert result['model_analysis']['changes_legal_verdict'] is False
        assert len(result['model_analysis']['wiki_explanations'])==1
    else:assert result['status']=='failed'
    assert await service.execute_next() is None and len(gateway.calls)==1
    assert service.get(user['account_id'],user['enterprise_id'],case['id'])['status']==result['status']
