"""0.4A contract regressions using isolated data and actual local file parsing."""
import base64
from io import BytesIO
from pathlib import Path
import socket
import threading
import time
from zipfile import ZIP_DEFLATED, ZipFile
from xml.sax.saxutils import escape

import httpx
from PIL import Image
import pytest
import uvicorn

from nmate.v03.app import create_app
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.extraction import XLSX, parse_workbook, validate_attachment
from nmate.v04.intake import IntakeService, interpret

ASSETS = Path(__file__).resolve().parents[2] / "nmate-mvp-v0.1" / "demo-files"
QA = Path(__file__).resolve().parents[2] / "MVP" / "v0.4A-intake-ssot" / "fixtures"


def upload(path, media_type=None):
    return {"filename": path.name, "media_type": media_type or (XLSX if path.suffix == ".xlsx" else "image/png"),
            "data_base64": base64.b64encode(path.read_bytes()).decode("ascii")}


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "isolated.db")
    accounts = LocalAccounts(repo)
    owner = accounts.register("owner-one", "Test-only-secret-v04A", "Trà Sen An Nhiên")
    other = accounts.register("owner-two", "Test-only-secret-v04A", "Doanh nghiệp khác")
    return repo, IntakeService(repo), owner, other


def prepare(service, owner, op="prepare-v04-test-0001", files=None, text="Tôi muốn số hóa bán hàng và quản lý tồn kho"):
    return service.prepare(owner["account_id"], owner["enterprise_id"], text,
        files if files is not None else [upload(ASSETS / "tra-sen-ho-so.xlsx"), upload(ASSETS / "tra-sen-bao-bi-mau.png")], op)


def confirm(service, owner, intake, op="confirm-v04-test-0001", selected=None, **kwargs):
    return service.confirm(owner["account_id"], owner["enterprise_id"], intake["id"],
        selected if selected is not None else [x["id"] for x in intake["candidates"]],
        intake["expected_entity_versions"], op, **kwargs)


def test_extract_confirm_reuse_and_periods_are_distinct(workspace):
    repo, service, owner, _ = workspace
    intake = prepare(service, owner)
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []
    assert intake["status"] == "awaiting_confirmation"
    assert intake["prepare_operation_id"] == intake["latest_intake_operation_id"] == "prepare-v04-test-0001"
    assert service.list(owner["account_id"], owner["enterprise_id"])[0]["prepare_operation_id"] == "prepare-v04-test-0001"
    assert intake["intent"]["primary"] == "digitize_operations"
    assert len(intake["candidates"]) == 9
    name = next(c for c in intake["candidates"] if c["field"] == "name")
    assert name["value"] == "Trà Sen Tây Hồ" and len(name["sources"]) == 2
    assert {s["kind"] for s in name["sources"]} == {"spreadsheet", "simulated_vision"}
    assert intake["attachments"][1]["extraction_status"] == "simulated_fixture"
    saved = confirm(service, owner, intake)
    assert saved["model_calls"] == saved["provider_attempts"] == 0
    facts = {f["field"]: f for e in saved["saved_context"]["entities"] for f in e["facts"]}
    assert facts["revenue.2025"]["value"] == {"amount": 1200000000, "currency": "VND", "period": "2025"}
    assert facts["revenue.2026-Q1"]["value"]["amount"] == 330000000
    assert facts["employee_count"]["source"]["period"] == "2026"
    assert facts["revenue.2025"]["source"]["unit_cell"] == "D9"
    assert facts["name"]["source"]["additional_locators"][0]["bbox"]
    assert all(f["verification_state"] == "self_declared" and f["source"]["owner_confirmed"] for f in facts.values())
    assert confirm(service, owner, intake)["saved_context"]["context_hash"] == saved["saved_context"]["context_hash"]
    same = prepare(service, owner)
    assert same["id"] == intake["id"] and same["status"] == "confirmed"
    text_only = prepare(service, owner, "prepare-followup-001", files=[], text="Tôi muốn giảm sai lệch tồn kho, đã có hồ sơ rồi")
    assert text_only["status"] == "ready" and text_only["candidates"] == []
    assert all(entity["entity_type"] == "enterprise" for entity in text_only["saved_context"]["entities"])
    assert text_only["product"] is None
    assert text_only["reused_context"]["fact_count"] < len(saved["saved_context"]["fact_refs"])
    assert all(t["id"] != "confirm_facts" for t in text_only["plan"])
    assert "Excel" in str(text_only["business_plan"])
    reused = prepare(service, owner, "prepare-reuse-0001")
    assert reused["status"] == "ready" and all(c["status"] == "already_known" for c in reused["candidates"])


def test_selected_only_and_atomic_cas(workspace):
    repo, service, owner, _ = workspace
    first = prepare(service, owner)
    chosen = [c["id"] for c in first["candidates"] if c["entity_type"] == "enterprise"]
    saved = confirm(service, owner, first, selected=chosen)
    assert all(e["entity_type"] == "enterprise" for e in saved["saved_context"]["entities"])
    second = prepare(service, owner, "prepare-cas-0001")
    enterprise = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "enterprise")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], enterprise["id"],
        [{"field": "sales_management", "value": "Phần mềm"}], enterprise["version"], "other-write-00001")
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    with pytest.raises(CoreError, match="Hồ sơ đã được cập nhật"):
        confirm(service, owner, second, op="confirm-cas-00001")
    after = repo.get_context(owner["account_id"], owner["enterprise_id"])
    assert after["context_hash"] == before["context_hash"]
    assert not any(e["entity_type"] == "product" for e in after["entities"])
    assert service.get(owner["account_id"], owner["enterprise_id"], second["id"])["status"] == "awaiting_confirmation"


def test_conflicts_require_explicit_choice_and_preserve_original(workspace):
    repo, service, owner, _ = workspace
    first = prepare(service, owner)
    saved = confirm(service, owner, first)
    enterprise = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "enterprise")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], enterprise["id"],
        [{"field": "inventory_management", "value": "Phần mềm quản lý"}], enterprise["version"], "other-inventory-001")
    second = prepare(service, owner, "prepare-conflict-001")
    conflict = next(c for c in second["candidates"] if c["field"] == "inventory_management")
    assert conflict["status"] == "conflict"
    with pytest.raises(CoreError) as error:
        confirm(service, owner, second, op="confirm-missingchoice", selected=[conflict["id"]])
    assert error.value.code == "conflict_choice_required"
    kept = confirm(service, owner, second, op="confirm-keep-current", selected=[conflict["id"]], conflict_choices={conflict["id"]: "current"})
    assert next(e for e in kept["saved_context"]["entities"] if e["entity_type"] == "enterprise")["values"]["inventory_management"] == "Phần mềm quản lý"
    assert next(c for c in kept["candidates"] if c["id"] == conflict["id"])["status"] == "kept_current"


def test_private_attachments_and_intakes_never_cross_owner(workspace):
    _repo, service, owner, other = workspace
    intake = prepare(service, owner)
    assert service.list(other["account_id"], other["enterprise_id"]) == []
    for enterprise_id in (owner["enterprise_id"], other["enterprise_id"]):
        with pytest.raises(CoreError):
            service.get(other["account_id"], enterprise_id, intake["id"])
        with pytest.raises(CoreError):
            service.attachment(other["account_id"], enterprise_id, intake["attachments"][0]["id"])
    blob = service.attachment(owner["account_id"], owner["enterprise_id"], intake["attachments"][0]["id"])
    assert base64.b64decode(blob["data_base64"]) == (ASSETS / "tra-sen-ho-so.xlsx").read_bytes()


def test_unknown_photo_is_stored_without_inventing_facts(workspace):
    _repo, service, owner, _ = workspace
    buffer = BytesIO()
    Image.new("RGB", (20, 20), "white").save(buffer, format="PNG")
    image = {"filename": "tra-sen-bao-bi-mau.png", "media_type": "image/png", "data_base64": base64.b64encode(buffer.getvalue()).decode()}
    result = prepare(service, owner, files=[image], text="Tôi muốn cập nhật hồ sơ từ ảnh này")
    assert result["candidates"] == []
    assert result["attachments"][0]["extraction_status"] == "stored_not_read"
    assert "chưa đọc" in result["attachments"][0]["warnings"][0]


@pytest.mark.parametrize("text,expected", [
    ("Tôi muốn xuất khẩu Trà Sen, xem file Excel", "export_readiness"),
    ("Cải thiện bao bì, đây là Excel doanh nghiệp", "improve_packaging"),
    ("Số hóa quản lý bán hàng và tồn kho", "digitize_operations"),
    ("Cập nhật hồ sơ doanh nghiệp", "understand_business"),
    ("Thời tiết hôm nay thế nào?", "needs_clarification"),
    ("Không cần xuất khẩu, chỉ số hóa tồn kho", "digitize_operations"),
])
def test_business_goal_outranks_incidental_excel(text, expected):
    assert interpret(text)["primary"] == expected


def test_attachment_only_asks_goal_and_does_not_invent_it(workspace):
    _repo, service, owner, _ = workspace
    result = prepare(service, owner, text="")
    assert result["intent"]["primary"] == "needs_clarification"
    assert result["questions"] and result["candidates"]
    with pytest.raises(CoreError, match="mục tiêu hoặc gửi"):
        prepare(service, owner, op="empty-intake-001", text="", files=[])


def test_clarifying_goal_retains_same_unconfirmed_files_and_candidates(workspace):
    repo, service, owner, other = workspace
    first = prepare(service, owner, text="")
    args = (owner["account_id"], owner["enterprise_id"], first["id"], "Tôi muốn giảm sai lệch tồn kho", "clarify-goal-00001")
    clarified = service.clarify(*args)
    assert clarified["id"] == first["id"]
    assert clarified["attachments"] == first["attachments"]
    assert clarified["candidates"] == first["candidates"]
    assert clarified["expected_entity_versions"] == first["expected_entity_versions"]
    assert clarified["intent"]["focus"] == "inventory_accuracy"
    assert clarified["prepare_operation_id"] == first["prepare_operation_id"]
    assert clarified["latest_intake_operation_id"] == "clarify-goal-00001"
    assert service.list(owner["account_id"], owner["enterprise_id"])[0]["latest_intake_operation_id"] == "clarify-goal-00001"
    assert service.clarify(*args) == clarified
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []
    with pytest.raises(CoreError):
        service.clarify(other["account_id"], owner["enterprise_id"], first["id"], "Bỏ qua bảo vệ", "clarify-not-owned")
    saved = confirm(service, owner, clarified)
    assert "kiểm kê" in str(saved["next_steps"])
    assert "hay tổng hợp bán hàng" not in str(saved["next_steps"])
    with pytest.raises(CoreError) as error:
        service.clarify(owner["account_id"], owner["enterprise_id"], first["id"], "Đổi mục tiêu", "clarify-after-saved")
    assert error.value.code == "already_confirmed"


def test_followup_uses_specific_focus_and_explicit_market(workspace):
    _repo, service, owner, _ = workspace
    saved = confirm(service, owner, prepare(service, owner))
    inventory = prepare(service, owner, op="followup-inventory", files=[], text="Tôi muốn giảm sai lệch tồn kho")
    sales = prepare(service, owner, op="followup-sales", files=[], text="Tôi muốn tổng hợp bán hàng nhanh hơn")
    assert inventory["business_plan"][0]["id"] != sales["business_plan"][0]["id"]
    assert "kiểm kê" in str(inventory["next_steps"])
    assert "ngày hay tháng" in str(sales["next_steps"])
    export = service.prepare(owner["account_id"], owner["enterprise_id"], "Chuẩn bị xuất khẩu Trà Sen Tây Hồ sang Nhật", [], "followup-japan", saved["product"]["id"])
    assert export["intent"]["market_codes"] == ["JP"]
    assert "Nhật Bản" in str(export["next_steps"])
    assert "cần chọn thị trường" not in str(export["next_steps"])


def test_missing_finance_dimensions_and_document_instructions_are_not_promoted(workspace):
    repo, service, owner, _ = workspace
    missing = prepare(service, owner, files=[upload(QA / "doanh-thu-thieu-ky-don-vi.xlsx")])
    assert not any(c["base_field"] == "revenue" for c in missing["candidates"])
    assert any("tiền tệ" in warning for a in missing["attachments"] for warning in a["warnings"])
    injected = prepare(service, owner, op="prepare-untrusted-doc-001", text="Tôi muốn số hóa quản lý tồn kho",
                       files=[upload(QA / "van-ban-khong-phai-lenh.xlsx")])
    assert injected["intent"]["primary"] == "digitize_operations"
    assert not any(c["field"] == "policy_entitlement" for c in injected["candidates"])
    assert injected["model_calls"] == 0
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []


def test_document_disagreement_does_not_silently_pick_a_source(workspace):
    _repo, service, owner, _ = workspace
    result = prepare(service, owner, files=[upload(ASSETS / "tra-sen-ho-so.xlsx"), upload(QA / "tra-sen-mau-thuan.xlsx")])
    conflicts = [c for c in result["candidates"] if c.get("conflict", {}).get("kind") == "document_disagreement"]
    assert conflicts
    with pytest.raises(CoreError) as error:
        confirm(service, owner, result, selected=[c["id"] for c in conflicts])
    assert error.value.code in {"conflict_choice_required", "unresolved_conflict"}


def rewrite_xlsx(raw, mutate):
    output = BytesIO()
    with ZipFile(BytesIO(raw)) as source, ZipFile(output, "w", ZIP_DEFLATED) as target:
        for name in source.namelist():
            target.writestr(name, mutate(name, source.read(name)))
    return output.getvalue()


def synthetic_workbook(rows):
    """Small real XLSX values for identity/dimension regression cases."""
    matrix = [["Đối tượng", "Trường", "Giá trị", "Đơn vị", "Kỳ"], *rows]
    body = "".join('<row r="%d">%s</row>' % (i, "".join(
        '<c r="%s%d" t="inlineStr"><is><t>%s</t></is></c>' % (chr(65 + j), i, escape(str(value)))
        for j, value in enumerate(row))) for i, row in enumerate(matrix, 1))
    output = BytesIO()
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        archive.writestr("xl/workbook.xml", '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Hồ sơ" sheetId="1" r:id="rId1"/></sheets></workbook>')
        archive.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>')
        archive.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + body + '</sheetData></worksheet>')
    return {"filename": "ho-so-kiem-thu.xlsx", "media_type": XLSX,
            "data_base64": base64.b64encode(output.getvalue()).decode("ascii")}


def test_initial_edited_identity_keeps_observation_without_promoting_original_alias(workspace):
    repo, service, owner, _ = workspace
    first = prepare(service, owner)
    name = next(c for c in first["candidates"] if c["field"] == "name")
    saved = confirm(service, owner, first, edits={name["id"]: "Trà Sen Tây Hồ 2026"})
    product_id = saved["product"]["id"]
    assert repo.find_entities_by_name(owner["account_id"], owner["enterprise_id"], "Trà Sen Tây Hồ") == []
    repeat = prepare(service, owner, op="reimport-initial-name")
    assert repeat["product"]["id"] == "new_product"
    assert service.get(owner["account_id"], owner["enterprise_id"], first["id"])["candidates"][0]["value"] == name["value"]
    assert len(repo.list_entities(owner["account_id"], owner["enterprise_id"], "product")) == 1
    assert repo.get_entity(owner["account_id"], owner["enterprise_id"], product_id)["name"] == "Trà Sen Tây Hồ 2026"
    text_only = prepare(service, owner, op="followup-original-name", files=[],
                        text="Tôi muốn cải thiện bao bì Trà Sen Tây Hồ")
    # DF-006/008: an unknown request-only reference cannot assert a new name or
    # become an alias for the name the owner actually confirmed above.
    assert text_only["product"] is None
    assert text_only["product_binding"]["state"] == "unbound_reference"
    assert text_only["product_binding"]["referenced_name"] == "Trà Sen Tây Hồ"
    assert not any(c["field"] == "name" for c in text_only["candidates"])
    assert repo.find_entities_by_name(owner["account_id"], owner["enterprise_id"], "Trà Sen Tây Hồ") == []
    assert len(repo.list_entities(owner["account_id"], owner["enterprise_id"], "product")) == 1
    assert repo.get_entity(owner["account_id"], owner["enterprise_id"], product_id)["name"] == "Trà Sen Tây Hồ 2026"
    explicit = prepare(service, owner, op="declare-original-name-explicitly", files=[], text="Tên sản phẩm: Trà Sen Tây Hồ")
    assert explicit["product"]["id"] == "new_product"
    assert explicit["product_binding"]["state"] == "new_product_draft"
    assert next(c["value"] for c in explicit["candidates"] if c["field"] == "name") == "Trà Sen Tây Hồ"


def test_existing_name_alias_is_resolved_without_false_concurrency(workspace):
    repo, service, owner, _ = workspace
    saved = confirm(service, owner, prepare(service, owner))
    product = saved["product"]
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"],
        [{"field": "name", "value": "Trà Sen Tây Hồ Phiên bản mới"}], product["version"], "rename-existing-product")
    repeat = prepare(service, owner, op="reimport-existing-name")
    assert repeat["product"]["id"] == product["id"]
    name = next(c for c in repeat["candidates"] if c["field"] == "name")
    saved_again = confirm(service, owner, repeat, op="keep-existing-name", selected=[name["id"]],
                          conflict_choices={name["id"]: "current"})
    assert saved_again["product"]["id"] == product["id"]
    assert len(repo.list_entities(owner["account_id"], owner["enterprise_id"], "product")) == 1


def test_separate_owner_confirmed_identities_do_not_inherit_unconfirmed_alias(workspace):
    repo, service, owner, _ = workspace
    first = prepare(service, owner)
    parallel = prepare(service, owner, op="prepare-parallel-new-product")
    name = next(c for c in first["candidates"] if c["field"] == "name")
    first_saved = confirm(service, owner, first, edits={name["id"]: "Trà Sen Tây Hồ 2026"})
    second_saved = confirm(service, owner, parallel, op="confirm-parallel-new-product",
        selected=[c["id"] for c in parallel["candidates"] if c["entity_type"] == "product"])
    assert first_saved["product"]["id"] != second_saved["product"]["id"]
    assert {item["name"] for item in repo.list_entities(owner["account_id"], owner["enterprise_id"], "product")} == {
        "Trà Sen Tây Hồ 2026", "Trà Sen Tây Hồ"}


def test_multiple_product_workbook_is_rejected_before_any_persistence(workspace):
    repo, service, owner, _ = workspace
    file = synthetic_workbook([
        ["product", "name", "Trà Sen", "", ""], ["product", "net_quantity", "100", "g", ""],
        ["product", "name", "Cà Phê", "", ""], ["product", "packaging", "Túi cà phê", "", ""],
        ["enterprise", "employee_count", "10", "người", "2026"]])
    with pytest.raises(CoreError) as error:
        prepare(service, owner, files=[file])
    assert error.value.code == "multiple_products_not_supported"
    assert "một sản phẩm" in str(error.value)
    assert service.list(owner["account_id"], owner["enterprise_id"]) == []
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []
    with repo.connection() as db:
        assert db.execute("SELECT count(*) FROM v04_attachments").fetchone()[0] == 0
        assert db.execute("SELECT count(*) FROM v03_operations").fetchone()[0] == 0


def test_multiple_product_batch_is_rejected_before_mixing_files(workspace):
    repo, service, owner, _ = workspace
    files = [synthetic_workbook([["product", "name", name, "", ""],
                                ["product", "packaging", packaging, "", ""]])
             for name, packaging in [("Trà Sen", "Hộp trà"), ("Cà Phê", "Túi cà phê")]]
    with pytest.raises(CoreError) as error:
        prepare(service, owner, files=files)
    assert error.value.code == "multiple_products_not_supported"
    assert service.list(owner["account_id"], owner["enterprise_id"]) == []
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []


def test_quantity_edit_retains_unit_and_distinguishes_original_value(workspace):
    _repo, service, owner, _ = workspace
    file = synthetic_workbook([["product", "name", "Trà Sen", "", ""],
                               ["product", "net_quantity", "100", "g", ""]])
    pending = prepare(service, owner, files=[file])
    quantity = next(c for c in pending["candidates"] if c["field"] == "net_quantity")
    saved = confirm(service, owner, pending, edits={quantity["id"]: "200"})
    fact = next(f for e in saved["saved_context"]["entities"] for f in e["facts"] if f["field"] == "net_quantity")
    assert fact["value"] == "200 g"
    assert fact["source"]["original_value"] == "100 g"
    assert fact["source"]["unit"] == fact["source"]["confirmed_unit"] == "g"
    assert fact["source"]["owner_edited"] is True


@pytest.mark.parametrize("edited,code", [("0", "invalid_quantity"), ("200 kg", "quantity_unit_conflict"),
                                          ("rất nhiều", "invalid_quantity")])
def test_invalid_quantity_edit_is_atomic(workspace, edited, code):
    repo, service, owner, _ = workspace
    file = synthetic_workbook([["product", "name", "Trà Sen", "", ""],
                               ["product", "net_quantity", "100", "g", ""]])
    pending = prepare(service, owner, files=[file])
    quantity = next(c for c in pending["candidates"] if c["field"] == "net_quantity")
    with pytest.raises(CoreError) as error:
        confirm(service, owner, pending, edits={quantity["id"]: edited})
    assert error.value.code == code
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []
    assert service.get(owner["account_id"], owner["enterprise_id"], pending["id"])["status"] == "awaiting_confirmation"


def test_currency_edit_preserves_source_dimensions_and_period_guard(workspace):
    repo, service, owner, _ = workspace
    file = synthetic_workbook([["enterprise", "revenue", "1000", "VND", "2025"]])
    pending = prepare(service, owner, files=[file])
    revenue = pending["candidates"][0]
    saved = confirm(service, owner, pending, edits={revenue["id"]: {"amount": 2000, "currency": "USD", "period": "2025"}})
    fact = saved["saved_context"]["entities"][0]["facts"][0]
    assert fact["value"] == {"amount": 2000, "currency": "USD", "period": "2025"}
    assert fact["source"]["unit"] == "VND" and fact["source"]["confirmed_unit"] == "USD"
    assert fact["source"]["original_value"] == {"amount": 1000, "currency": "VND", "period": "2025"}
    assert fact["source"]["period"] == fact["source"]["confirmed_period"] == "2025"
    assert fact["source"]["cell"] == "C2" and fact["source"]["unit_cell"] == "D2"
    repeat = prepare(service, owner, op="prepare-change-period", files=[file])
    revenue = repeat["candidates"][0]
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    with pytest.raises(CoreError) as error:
        confirm(service, owner, repeat, op="confirm-change-period", edits={revenue["id"]: {"amount": 2000, "currency": "USD", "period": "2026"}},
                conflict_choices={revenue["id"]: "incoming"})
    assert error.value.code == "period_change_requires_intake"
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["context_hash"] == before["context_hash"]


def test_keep_current_ignores_invalid_unused_edit(workspace):
    repo, service, owner, _ = workspace
    confirm(service, owner, prepare(service, owner))
    file = synthetic_workbook([["enterprise", "revenue", "999", "VND", "2025"]])
    repeat = prepare(service, owner, op="prepare-keep-current-revenue", files=[file])
    revenue = repeat["candidates"][0]
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    kept = confirm(service, owner, repeat, op="confirm-keep-current-revenue", selected=[revenue["id"]],
                   edits={revenue["id"]: {"amount": "", "currency": "BAD", "period": ""}},
                   conflict_choices={revenue["id"]: "current"})
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["context_hash"] == before["context_hash"]
    assert all(entity["entity_type"] == "enterprise" for entity in kept["saved_context"]["entities"])
    assert kept["candidates"][0]["status"] == "kept_current"


def test_confirm_enterprise_only_retains_unconfirmed_product_draft_without_materializing(workspace):
    _repo, service, owner, _ = workspace
    pending = prepare(service, owner)
    saved = confirm(service, owner, pending, selected=[c["id"] for c in pending["candidates"] if c["entity_type"] == "enterprise"])
    assert saved["product"] == pending["product"]
    assert saved["product"]["id"] == "new_product"
    assert saved["product_binding"]["state"] == "new_product_draft"
    assert saved["product_binding"]["confirmed"] is False
    assert saved["expected_entity_versions"]["new_product"] == 0
    assert set(saved["review"]["pending_candidate_ids"]) == {c["id"] for c in pending["candidates"] if c["entity_type"] == "product"}
    assert all(e["entity_type"] != "product" for e in saved["saved_context"]["entities"])


def test_prepare_can_join_outer_atomic_transaction(workspace):
    repo, service, owner, _ = workspace
    with pytest.raises(RuntimeError, match="rollback-parent"):
        with repo.connection(write=True) as db:
            pending = service.prepare(owner["account_id"], owner["enterprise_id"], "Cập nhật hồ sơ",
                [upload(ASSETS / "tra-sen-ho-so.xlsx")], "prepare-outer-atomic", db=db)
            assert pending["candidates"]
            raise RuntimeError("rollback-parent")
    assert service.list(owner["account_id"], owner["enterprise_id"]) == []
    with repo.connection() as db:
        assert db.execute("SELECT count(*) FROM v04_attachments").fetchone()[0] == 0
        assert db.execute("SELECT count(*) FROM v03_operations").fetchone()[0] == 0


def test_formula_external_link_macro_bomb_and_malformed_rejected():
    raw = (ASSETS / "tra-sen-ho-so.xlsx").read_bytes()
    formula = rewrite_xlsx(raw, lambda name, data: data.replace(b"</c>", b"<f>HYPERLINK(\"https://example.invalid\")</f></c>", 1) if name.endswith("sheet1.xml") else data)
    with pytest.raises(CoreError) as error:
        parse_workbook(formula)
    assert error.value.code == "formula_not_supported"
    external = rewrite_xlsx(raw, lambda name, data: data.replace(b"<Relationship ", b'<Relationship TargetMode="External" ', 1) if name.endswith("workbook.xml.rels") else data)
    with pytest.raises(CoreError, match="liên kết ngoài"):
        parse_workbook(external)
    for name, content in (("xl/vbaProject.bin", b"macro"), ("xl/oversized.xml", b"x" * (5 * 1024 * 1024))):
        buf = BytesIO(raw)
        with ZipFile(buf, "a", ZIP_DEFLATED) as archive:
            archive.writestr(name, content)
        with pytest.raises(CoreError):
            parse_workbook(buf.getvalue())
    with pytest.raises(CoreError):
        validate_attachment({"filename": "pretend.png", "media_type": "image/png", "data_base64": base64.b64encode(b"not image").decode()})
    with pytest.raises(CoreError):
        validate_attachment({"filename": "../secrets.xlsx", "media_type": XLSX, "data_base64": "YWJj"})


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    app = create_app(tmp_path_factory.mktemp("v04-http") / "test.db", port=port, enable_v04=True,
                     cookie_namespace="qa_v04", task_delay=.01)
    instance = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error", access_log=False))
    thread = threading.Thread(target=instance.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not instance.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    yield {"url": f"http://127.0.0.1:{port}", "app": app}
    instance.should_exit = True
    thread.join(10)
    assert not thread.is_alive()


def test_actual_http_mcp_attachment_roundtrip_reload_and_limits(server):
    with httpx.Client(base_url=server["url"], timeout=20) as web:
        pre = web.get("/api/v03/session").json()
        headers = {"Origin": server["url"], "X-CSRF-Token": pre["csrf_token"]}
        session = web.post("/api/v03/register", headers=headers, json={"username": "http-owner-v04", "password": "Test-only-secret-v04", "enterprise_name": "Trà Sen HTTP QA"}).json()
        headers["X-CSRF-Token"] = session["csrf_token"]
        def tool(name, **arguments):
            result = web.post("/api/v03/mcp/call", headers=headers, json={"name": name, "arguments": {"enterprise_id": session["enterprise"]["id"], **arguments}})
            assert result.status_code == 200, result.text
            envelope = result.json()
            assert envelope["ok"], envelope
            return envelope["data"]
        intake = tool("prepare_intake", text="", attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx"), upload(ASSETS / "tra-sen-bao-bi-mau.png")], operation_id="http-prepare-intake-001")
        assert len(intake["candidates"]) == 9
        clarified = tool("clarify_intake", intake_id=intake["id"], text="Tôi muốn giảm sai lệch tồn kho", operation_id="http-clarify-intake-001")
        assert clarified["id"] == intake["id"] and clarified["candidates"] == intake["candidates"]
        assert clarified["intent"]["focus"] == "inventory_accuracy"
        assert tool("get_intake", intake_id=intake["id"])["id"] == intake["id"]
        saved = tool("confirm_intake", intake_id=intake["id"], selected_fact_ids=[c["id"] for c in intake["candidates"]],
                     expected_entity_versions=intake["expected_entity_versions"], operation_id="http-confirm-intake-001",
                     expected_review_revision=clarified["review"]["revision"],
                     expected_proposal_hashes=clarified["review"]["proposal_hashes"])
        assert saved["status"] == "confirmed"
        assert web.get("/api/v03/session").json()["authenticated"]
        assert tool("list_intakes")[0]["status"] == "confirmed"
        assert tool("get_attachment", attachment_id=intake["attachments"][0]["id"])["data_base64"]
        assert web.get("/health").json()["paid_calls"] == 0
        assert web.get("/web/demo-files/tra-sen-ho-so.xlsx").status_code == 200
        assert web.get("/web/demo-files/../../.data-v03a-fake/enterprise.sqlite3").status_code in {401, 404}
        assert web.post("/api/v03/register", content=b"x" * 65537).status_code == 413
