"""Explicit user text becomes unconfirmed facts; recovery never calls AI."""
import copy
import hashlib
import json

import pytest

from nmate.v03.core import CoreError, json_text
from nmate.v04.extraction import extract_product_text
from test_v04_live_review import workspace as workspace
from test_v04_live_review import services, result, send
from test_v04_intake import confirm


TEXT = "Tôi có sản phẩm Trà Sen Tây Hồ, hộp 100 g, thành phần trà xanh và hoa sen. Tôi muốn số hóa quản lý tồn kho; hãy ghi nhận dữ kiện sản phẩm để tôi kiểm tra trước khi lưu."


def test_explicit_product_declarations_have_exact_case_and_private_text_provenance():
    facts = extract_product_text(TEXT)
    assert {fact["field"]: fact["value"] for fact in facts} == {
        "name": "Trà Sen Tây Hồ", "net_quantity": "100 g", "packaging": "hộp",
        "ingredients": "trà xanh và hoa sen"}
    for fact in facts:
        assert fact["source"]["kind"] == "server_text_extract"
        assert fact["source"]["quote"] in TEXT and fact["source"]["value_quote"] in fact["source"]["quote"]
        assert fact["source"]["review_state"] == "owner_confirmation_required"


@pytest.mark.parametrize("text", ["Tôi không có sản phẩm Trà Sen, hộp 100 g.",
    "Ví dụ tôi có sản phẩm Trà Sen, hộp 100 g.", "Tên sản phẩm: Trà Sen?",
    "Tôi chưa biết thành phần là gì.", "Hộp 100", "Lợi nhuận 1000000 VND",
    "Tên sản phẩm: Trà Sen; tên sản phẩm: Trà Khác."])
def test_negative_hypothetical_questions_finance_and_ambiguous_names_are_not_facts(text):
    assert extract_product_text(text) == []


@pytest.mark.asyncio
async def test_new_text_only_chat_exposes_pending_candidates_before_owner_confirmation(workspace):
    repo, owner, _ = workspace
    _, intake, chat, stub = services(workspace, [result(TEXT)])
    conversation = await send(chat, owner, TEXT)
    item = conversation["intake"]
    assert item["status"] == "awaiting_confirmation"
    assert len(item["candidates"]) == 4
    assert {c["source"]["kind"] for c in item["candidates"]} == {"server_text_extract"}
    assert not repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"]
    saved = confirm(intake, owner, item)
    assert saved["status"] == "confirmed" and len(stub.calls) == 1
    context = repo.get_context(owner["account_id"], owner["enterprise_id"])
    product = next(entity for entity in context["entities"] if entity["entity_type"] == "product")
    assert product["values"]["name"] == "Trà Sen Tây Hồ" and product["values"]["net_quantity"] == "100 g"


@pytest.mark.asyncio
async def test_free_recovery_uses_original_text_preserves_sdk_receipt_and_ssot(workspace):
    repo, owner, other = workspace
    _, intake, chat, stub = services(workspace, [result(TEXT)])
    conv = await send(chat, owner, TEXT)
    item = conv["intake"]
    with repo.connection(write=True) as db:
        legacy = copy.deepcopy(item)
        legacy["candidates"] = []
        legacy["status"] = "ready"
        legacy["product"] = None
        db.execute("UPDATE v04_intakes SET status='ready',payload_json=? WHERE id=?", (json_text(legacy), item["id"]))
        receipt = db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0]
        receipt_hash = hashlib.sha256(receipt.encode()).hexdigest()
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    recovered = intake.recover_text_observations(owner["account_id"], owner["enterprise_id"], item["id"], "free-text-recovery-1")
    repeated = intake.recover_text_observations(owner["account_id"], owner["enterprise_id"], item["id"], "free-text-recovery-1")
    assert repeated["candidates"] == recovered["candidates"] and len(recovered["candidates"]) == 4
    assert recovered["status"] == "awaiting_confirmation" and len(stub.calls) == 1
    assert recovered["text_observation_recoveries"][0]["model_called"] is False
    assert recovered["origins"]["text_values"] == "server_text_extract"
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == before["fact_refs"]
    with repo.connection() as db:
        after = db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0]
        assert hashlib.sha256(after.encode()).hexdigest() == receipt_hash
        chat_payload = json.loads(db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (conv["id"],)).fetchone()[0])
        assert chat_payload["messages"][-1]["text"] == conv["messages"][-1]["text"]
    with pytest.raises(CoreError):
        intake.recover_text_observations(other["account_id"], other["enterprise_id"], item["id"], "denied-recovery")


@pytest.mark.asyncio
async def test_current_confirmed_values_are_not_reset_or_reconfirmed_on_same_text(workspace):
    repo, owner, _ = workspace
    _, intake, chat, stub = services(workspace, [result(TEXT)])
    first = await send(chat, owner, TEXT)
    confirm(intake, owner, first["intake"])
    second = await send(chat, owner, TEXT, op="text-second-0001", conversation_id=first["id"])
    assert second["intake"]["status"] == "ready"
    assert all(candidate["status"] == "already_known" for candidate in second["intake"]["candidates"])
    assert len(stub.calls) == 2


@pytest.mark.asyncio
async def test_text_candidates_cannot_be_rebound_to_company_even_with_matching_version(workspace):
    repo, owner, _ = workspace
    _, intake, chat, stub = services(workspace, [result(TEXT)])
    conversation = await send(chat, owner, TEXT)
    item = conversation["intake"]
    company = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "Trà Sen Tây Hồ")
    with repo.connection(write=True) as db:
        corrupt = copy.deepcopy(item)
        corrupt["expected_entity_versions"][company["id"]] = 0
        for candidate in corrupt["candidates"]:
            candidate["entity_id"] = company["id"]
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(corrupt), item["id"]))
        receipt = db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0]
    with pytest.raises(CoreError) as error:
        confirm(intake, owner, corrupt)
    assert error.value.code == "invalid_field_scope"
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    assert len(stub.calls) == 1
    with repo.connection() as db:
        assert db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0] == receipt
        assert db.execute("SELECT COUNT(*) FROM v03_entities").fetchone()[0] == 1


@pytest.mark.asyncio
async def test_empty_candidate_recovery_refuses_nonproduct_target_and_keeps_original_receipt(workspace):
    repo, owner, _ = workspace
    _, intake, chat, stub = services(workspace, [result(TEXT)])
    conversation = await send(chat, owner, TEXT)
    item = conversation["intake"]
    company = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "Trà Sen Tây Hồ")
    with repo.connection(write=True) as db:
        corrupt = copy.deepcopy(item)
        corrupt["candidates"] = []
        corrupt["status"] = "ready"
        corrupt["product"] = {key: company[key] for key in ("id", "name", "version")}
        corrupt["expected_entity_versions"][company["id"]] = 0
        db.execute("UPDATE v04_intakes SET status='ready',payload_json=? WHERE id=?", (json_text(corrupt), item["id"]))
        receipt = db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0]
    with pytest.raises(CoreError) as error:
        intake.recover_text_observations(owner["account_id"], owner["enterprise_id"], item["id"], "bad-recovery")
    assert error.value.code == "invalid_field_scope"
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    assert len(stub.calls) == 1
    with repo.connection() as db:
        assert db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0] == receipt
        assert json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (item["id"],)).fetchone()[0])["candidates"] == []
