"""DF-013/019/023/024/030/038/046: private fixtures, zero paid transport."""
import sqlite3

import pytest

from nmate.main.app import make_main_app
from nmate.main.history import history_metadata
from nmate.policy_v1.service import PolicyService, resolve_intent
from nmate.v03.core import CoreError


@pytest.fixture
def app_scope(tmp_path):
    calls = []

    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        pytest.fail("Design utility/read must not dispatch a model")

    app = make_main_app(tmp_path / "design-policy-history.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("design-policy-owner", "Synthetic-password-123", "Cơ sở QA riêng")
    other = app.state.accounts.register("design-policy-other", "Synthetic-password-456", "Cơ sở khác")
    return app, app.state.core_extension, owner, other, calls


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


def make_policy(service, owner, operation="mixed-policy-001", **kwargs):
    return service.prepare(*scope(owner), "Chị cần hỗ trợ chuyển đổi số và xuất khẩu.", operation, **kwargs)


def test_mixed_policy_and_unsupported_request_keep_both_parts(app_scope):
    _, service, owner, _, calls = app_scope
    case = service.prepare(*scope(owner), "Chị cần chuyển đổi số và hỏi thời tiết Hà Nội hôm nay.", "mixed-weather-001")["policy_case"]
    assert case["intent"]["goals"] == ["digital_transformation"]
    assert case["intent"].get("unsupported_requests") == ["weather"]
    coverage = {item["goal"]: item for item in case["goal_coverage"]}
    assert coverage["digital_transformation"]["source_ids"]
    assert coverage["weather"]["status"] == "unsupported" and coverage["weather"]["source_ids"] == []
    assert "thời tiết" in case["lead_vi"].lower() and "chưa hỗ trợ" in case["lead_vi"].lower()
    assert case["result_status"] == "partially_answered"
    metadata = history_metadata(service.get_chat(*scope(owner), case["conversation_id"]))
    assert metadata["history_state_vi"] == "Có kết quả chính sách một phần"
    assert metadata["history_filter_state"] == "needs_attention"
    reloaded = service.get_case(*scope(owner), case["id"])
    assert reloaded["goal_coverage"] == case["goal_coverage"]
    assert calls == []


@pytest.mark.parametrize("question", [
    "Chị không cần thời tiết, chỉ muốn hỗ trợ chuyển đổi số.",
    "Chị muốn chuyển đổi số; không hỏi thời tiết hôm nay.",
])
def test_negated_unsupported_part_does_not_pollute_scope(question):
    intent = resolve_intent(question)
    assert intent.get("unsupported_requests", []) == []
    assert intent["request_scope"] == "in_scope"


@pytest.mark.parametrize("field", ["revenue.2026", "assets.2025", "employee_count.2026", "net_profit.2025", "financial_metrics.2026"])
def test_qualified_financial_dependency_cannot_be_treated_as_nonfinancial(field):
    with sqlite3.connect(":memory:") as db:
        with pytest.raises(CoreError) as blocked:
            PolicyService._check_nonfinancial_context(db, {"fact_refs": [{"field": field}], "entities": []})
    assert blocked.value.code == "finance_egress_required"


def test_history_filter_uses_all_goals_and_explicit_processing_state(app_scope, monkeypatch):
    _, service, owner, other, calls = app_scope
    prepared = make_policy(service, owner)
    cid = prepared["conversation_id"]
    assert cid in {item["id"] for item in service.search_history(*scope(owner), task="export_research")["items"]}
    assert service.search_history(*scope(other), task="export_research")["items"] == []

    original = service.get_chat

    def processing(*args, **kwargs):
        view = original(*args, **kwargs)
        return {**view, "status": "processing", "pending_operation_id": "synthetic-pending-001",
                "policy_cases": [], "active_policy_case_id": None}

    monkeypatch.setattr(service, "get_chat", processing)
    assert service.search_history(*scope(owner), status="completed")["items"] == []
    assert cid in {item["id"] for item in service.search_history(*scope(owner), status="needs_attention")["items"]}
    assert calls == []


@pytest.mark.parametrize("status", ["open", "processing", "preparing", "queued", "running", "failed", "outcome_unknown", "planned"])
def test_history_does_not_infer_completion_from_absence_of_an_error(status):
    meta = history_metadata({"status": status, "task_hint": "profile_intake"})
    assert meta.get("history_filter_state") != "completed"
    assert meta.get("history_filter_state") in {"pending", "needs_attention", "saved"}


def test_archive_receipt_replay_is_read_only_when_another_action_is_pending(app_scope, monkeypatch):
    app, service, owner, _, calls = app_scope
    cid = make_policy(service, owner)["conversation_id"]
    first = service._visibility(*scope(owner), cid, "archive-first-001", True)
    service._visibility(*scope(owner), cid, "restore-second-001", False)
    original = service.get_chat

    def pending(*args, **kwargs):
        return {**original(*args, **kwargs), "pending_operation_id": "another-action-001", "status": "processing"}

    monkeypatch.setattr(service, "get_chat", pending)
    replay = service._visibility(*scope(owner), cid, "archive-first-001", True)
    assert replay["receipt"]["archived"] == first["archived"] is True
    assert replay["archived"] is False
    with pytest.raises(CoreError) as blocked:
        service._visibility(*scope(owner), cid, "archive-new-003", True)
    assert blocked.value.code == "CONVERSATION_BUSY"
    with app.state.repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
    assert calls == []


def test_document_membership_is_checked_before_parsing(app_scope, monkeypatch):
    _, service, owner, other, calls = app_scope
    monkeypatch.setattr("nmate.main.workspace_management.validate_attachment",
                        lambda value: pytest.fail("Foreign scope reached file decode/parse"))
    with pytest.raises(CoreError) as denied:
        service.prepare_document(owner["account_id"], other["enterprise_id"], "Chị đọc tệp.",
                                 [{"filename": "test.pdf"}], "foreign-document-001")
    assert denied.value.status_code in {403, 404}
    # No membership means the receipt evidence is unreadable as well. A prior
    # command could have committed before access was revoked; never infer an
    # operation-wide no-commit state from this invocation's preflight denial.
    assert getattr(denied.value, "commit_state", None) is None
    assert calls == []


def test_revoked_document_replay_does_not_claim_the_old_command_never_started(app_scope, monkeypatch):
    from test_review_commands_v2 import data_snapshot
    from test_workspace_management import attachment, pdf_bytes
    app, service, owner, _, calls = app_scope
    operation = "revoked-document-replay-001"
    text = "Chị đọc tài liệu để lập nháp hồ sơ."
    files = [attachment(pdf_bytes(["Ten san pham: Tra Sen QA", "Khoi luong tinh: 100 g"]))]
    prepared = service.prepare_document(*scope(owner), text, files, operation)
    with app.state.repo.connection(write=True) as db:
        assert db.execute("SELECT COUNT(*) FROM v03_operations WHERE account_id=? AND enterprise_id=? "
                          "AND kind='v04_conversation_send' AND operation_id=?", (*scope(owner), operation)).fetchone()[0] == 1
        db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?", scope(owner))
    before = data_snapshot(app.state.repo)
    monkeypatch.setattr("nmate.main.workspace_management.validate_attachment",
                        lambda value: pytest.fail("Revoked scope reached file decode/parse"))
    with pytest.raises(CoreError) as denied:
        service.prepare_document(*scope(owner), text, files, operation)
    assert denied.value.status_code in {403, 404}
    assert getattr(denied.value, "commit_state", None) is None
    assert prepared["id"] and data_snapshot(app.state.repo) == before
    assert calls == []


def test_policy_prepare_replay_is_read_but_new_prepare_in_trash_is_blocked(app_scope):
    _, service, owner, _, calls = app_scope
    prepared = make_policy(service, owner, "policy-original-001")
    cid = prepared["conversation_id"]
    service._visibility(*scope(owner), cid, "policy-trash-001", True)
    replay = make_policy(service, owner, "policy-original-001")
    assert replay["conversation_id"] == cid and replay["policy_case"]["id"] == prepared["policy_case"]["id"]
    with pytest.raises(CoreError) as blocked:
        make_policy(service, owner, "policy-new-002", conversation_id=cid)
    assert blocked.value.code == "CONVERSATION_ARCHIVED"
    assert calls == []


def test_policy_reads_of_archived_input_keep_history_but_block_new_use(app_scope):
    app, service, owner, _, calls = app_scope
    product = service.repo.create_entity(*scope(owner), "product", "Trà Sen QA riêng", operation_id="create-history-product-001")
    result = service.prepare(*scope(owner), "Chị cần hồ sơ chuyển đổi số.", "history-with-product-001", product_entity_id=product["id"])
    mid = result["policy_case"]["id"]
    with app.state.repo.connection() as db:
        before = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mid,)).fetchone()[0]
    service.repo.archive_entity(*scope(owner), product["id"], product["version"], "archive-history-product-001")
    read = service.get_case(*scope(owner), mid)
    assert read["is_historical"] and not read["cost_gate"]["approved"]
    assert any("cất" in warning or "lưu trữ" in warning for warning in read["current_warnings_vi"])
    with app.state.repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mid,)).fetchone()[0] == before
    assert calls == []


def test_policy_prepare_replay_keeps_recorded_implicit_scope_after_profile_changes(app_scope):
    _, service, owner, _, calls = app_scope
    first = make_policy(service, owner, "implicit-replay-001")
    service.create_entity(*scope(owner), "enterprise", "Cơ sở mới sau lần chuẩn bị", "new-enterprise-scope-001")
    replay = make_policy(service, owner, "implicit-replay-001")
    assert replay["policy_case"]["id"] == first["policy_case"]["id"]
    with pytest.raises(CoreError) as conflict:
        service.prepare(*scope(owner), "Chị cần chuyển đổi số khác.", "implicit-replay-001")
    assert conflict.value.code == "idempotency_conflict"
    new = make_policy(service, owner, "implicit-replay-002")
    assert new["policy_case"]["id"] != first["policy_case"]["id"]
    assert calls == []
