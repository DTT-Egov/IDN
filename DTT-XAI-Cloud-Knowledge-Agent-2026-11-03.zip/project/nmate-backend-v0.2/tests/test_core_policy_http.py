"""Actual browser BFF → HTTP MCP → SQL/graph, with paid transport replaced in tests only."""
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import json
import socket
import threading
import time

import httpx
import uvicorn

from nmate.main.app import make_main_app


@contextmanager
def running(tmp_path, **options):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    app = make_main_app(tmp_path / "integration.sqlite", port=port, refresh_sources=False, **options)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error", access_log=False))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not server.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    try:
        yield app, f"http://127.0.0.1:{port}"
    finally:
        server.should_exit = True
        thread.join(timeout=15)
        assert not thread.is_alive()


def register(web, url, username):
    pre = web.get("/api/v03/session").json()
    response = web.post("/api/v03/register", headers={"Origin": url, "X-CSRF-Token": pre["csrf_token"]},
                        json={"username": username, "password": "TestPassword12345", "enterprise_name": "Trà Sen " + username})
    assert response.status_code == 200, response.text
    return response.json()


def call(web, url, session, tool_name, **args):
    response = web.post("/api/v03/mcp/call", headers={"Origin": url, "X-CSRF-Token": session["csrf_token"]},
                        json={"name": tool_name, "arguments": {"enterprise_id": session["enterprise"]["id"], **args}})
    assert response.status_code == 200, response.text
    return response.json()


def good(web, url, session, tool_name, **args):
    value = call(web, url, session, tool_name, **args)
    assert value["ok"], value
    return value["data"]


def test_free_mobile_contract_ssot_private_history_reload_and_d06(tmp_path):
    transport_calls = []

    async def forbidden(*args):
        transport_calls.append(args)
        raise AssertionError("Not approved")

    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as owner, \
             httpx.Client(base_url=url, trust_env=False, timeout=20) as staff, \
             httpx.Client(base_url=url, trust_env=False, timeout=20) as outsider:
            os = register(owner, url, "core-owner")
            ss = register(staff, url, "core-staff")
            xs = register(outsider, url, "core-other")
            product = good(owner, url, os, "core_create_entity", entity_type="product", name="Trà Sen HỒ TÂY", operation_id="create-product")
            repeated = good(owner, url, os, "core_create_entity", entity_type="product", name="Trà Sen HỒ TÂY", operation_id="create-product")
            assert product["id"] == repeated["id"]
            added = good(owner, url, os, "core_add_member", username="core-staff", operation_id="add-staff")
            staff_id = added["account_id"]
            assert any(e["role"] == "staff" and e["id"] == os["enterprise"]["id"] for e in staff.get("/api/v03/session").json()["enterprises"])
            assert good(staff, url, ss, "core_list_entities", enterprise_id=os["enterprise"]["id"])["entities"] == []
            good(owner, url, os, "core_grant_resource", resource_id=product["id"], member_account_id=staff_id,
                 capabilities=["read", "propose_fact"], field_keys=["name", "net_quantity"])
            proposal = good(staff, url, ss, "core_propose_facts", enterprise_id=os["enterprise"]["id"], entity_id=product["id"],
                            facts=[{"field": "name", "value": "Trà Sen HỒ TÂY"}, {"field": "net_quantity", "value": "100 g"}],
                            expected_version=0, operation_id="staff-proposal")
            assert proposal["status"] == "awaiting_owner"
            assert not call(staff, url, ss, "core_confirm_facts", enterprise_id=os["enterprise"]["id"], proposal_id=proposal["proposal_id"],
                            expected_version=0, operation_id="staff-not-owner")["ok"]
            good(owner, url, os, "core_confirm_facts", proposal_id=proposal["proposal_id"], expected_version=0,
                 operation_id="owner-confirm", proposal_hash=proposal["proposal_hash"], expected_field_versions=proposal["expected_field_versions"])
            ctx = good(staff, url, ss, "core_get_context", enterprise_id=os["enterprise"]["id"], entity_ids=[product["id"]])
            assert ctx["entities"][0]["values"]["name"] == "Trà Sen HỒ TÂY"
            case = good(owner, url, os, "policy_prepare", question="Trà Sen cần hỗ trợ số hóa kho, điều kiện và cần chuẩn bị gì?",
                        product_entity_id=product["id"], operation_id="policy-prepare-1")["policy_case"]
            assert case["conversation_id"] and not case["provider_used"] and not case["cost_gate"]["approved"]
            same = good(owner, url, os, "policy_prepare", question=case["question"], product_entity_id=product["id"],
                        operation_id="policy-prepare-1")["policy_case"]
            assert same["id"] == case["id"] and same["conversation_id"] == case["conversation_id"]
            chat = good(owner, url, os, "get_conversation", conversation_id=case["conversation_id"])
            assert chat["policy_cases"][0]["id"] == case["id"] and len(chat["messages"]) == 2
            assert not call(staff, url, ss, "get_conversation", enterprise_id=os["enterprise"]["id"], conversation_id=case["conversation_id"])["ok"]
            assert not call(outsider, url, xs, "policy_get", enterprise_id=os["enterprise"]["id"], case_id=case["id"])["ok"]
            blocked = call(owner, url, os, "policy_start", case_id=case["id"], operation_id="no-budget-start", budget_grant_id="client-invented", paid_consent=True)
            assert not blocked["ok"] and blocked["error"]["code"] == "BUDGET_NOT_GRANTED"
            legacy = call(owner, url, os, "send_message", text="Trà Sen hỗ trợ xuất khẩu", attachments=[],
                          operation_id="old-task-no-approval", task_hint="export_research", paid_consent=True)
            assert not legacy["ok"]
            assert app.state.gateway.status(os["account"]["id"], os["enterprise"]["id"])["paid_calls"] == 0
            assert not transport_calls


def test_policy_graph_one_approved_stub_call_durable_read_and_no_retry(tmp_path):
    calls = []

    async def stub(model, body, limit):
        calls.append((model, body, limit))
        context = body["input"]
        candidates = context["analysis_candidates"]
        return {"text": json.dumps({"schema_version": "policy-model-analysis/2",
                    "evidence_choices": candidates["evidence"][:1],
                    "next_task_ids": [item["id"] for item in candidates["next_tasks"][:3]],
                    "ssot_question_ids": [item["id"] for item in candidates["ssot_questions"]]}, ensure_ascii=False),
                "model": model, "usage": {"input_tokens": 1000, "output_tokens": 500}, "stop_reason": "end_turn"}

    with running(tmp_path, gateway_request_fn=stub, gateway_enabled=True) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web:
            session = register(web, url, "policy-owner")
            actor, enterprise = session["account"]["id"], session["enterprise"]["id"]
            budget = app.state.gateway.authorize_budget(actor, enterprise, approval_id="TEST-TRANSPORT-ONLY",
                max_calls=1, max_cost_usd=2, purposes=["hanoi_policy_synthesis"], roles=["standard"],
                expires_at=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())["id"]
            case = good(web, url, session, "policy_prepare", question="Có chương trình nào hỗ trợ số hóa kho Trà Sen không?",
                        operation_id="prepare-approved-stub")["policy_case"]
            assert case["cost_gate"]["approved"] and case["cost_gate"]["model_id"] == "claude-sonnet-5-5"
            good(web, url, session, "policy_start", case_id=case["id"], operation_id="start-approved-stub", budget_grant_id=budget,
                 paid_consent=True, model_role="simple")
            deadline = time.monotonic()+15
            while True:
                current = good(web, url, session, "policy_get", case_id=case["id"])["policy_case"]
                if current["status"] not in {"queued", "running"}:
                    break
                assert time.monotonic() < deadline
                time.sleep(.05)
            assert current["status"] in {"completed", "completed_partial"}, current
            assert len(calls) == 1
            good(web, url, session, "get_conversation", conversation_id=case["conversation_id"])
            assert len(calls) == 1
            blocked = call(web, url, session, "policy_start", case_id=case["id"], operation_id="start-second-forbidden",
                           budget_grant_id=budget, paid_consent=True)
            assert not blocked["ok"] and len(calls) == 1
