"""Full paid-free browser contract through real BFF and MCP HTTP transports."""
import httpx

from test_v03_http import call, data, finish, register, server  # noqa: F401


def values(label):
    return {field["id"]: field["value"] for field in label["fields"]}


def entity(web, session, entity_id):
    return next(e for e in data(web, session, "get_enterprise_context")["entities"]
                if e["id"] == entity_id)


def test_atomic_memory_continue_after_facility_change_rename_and_isolation(server):  # noqa: F811
    with httpx.Client(base_url=server["url"]) as web, httpx.Client(base_url=server["url"]) as other:
        owner = register(web, "three-priorities-owner", "Trà Sen QA — ba ưu tiên")
        outsider = register(other, "three-priorities-other", "Doanh nghiệp B QA")
        first = data(web, owner, "prepare_mission", operation_id="priorities-prepare-01",
            user_text="Tôi có Trà Sen Tây Hồ gửi New York, cần đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.")
        data(web, owner, "start_mission", mission_id=first["id"], operation_id="priorities-start-01")
        first = finish(web, owner, first["id"])
        assert first["status"] == "completed_partial", first
        product_id = first["product"]["entity_id"]
        original_label = first["label"]
        declared = {"statement_of_identity": "Lotus-scented Green Tea", "net_quantity": "100 g",
                    "ingredients": "Green tea, Lotus flowers"}
        arguments = dict(mission_id=first["id"], artifact_id=original_label["id"], fields=declared,
            remember_fields=list(declared), expected_artifact_version=original_label["version"],
            expected_entity_version=entity(web, owner, product_id)["version"],
            expected_market_profile_version=first["market_profile"]["version"],
            operation_id="priorities-atomic-save-01")
        saved = data(web, owner, "update_label_progress", **arguments)
        version = saved["label"]["version"]
        assert version == original_label["version"] + 1
        assert values(saved["label"]) | declared == values(saved["label"])
        repeat = data(web, owner, "update_label_progress", **arguments)
        assert repeat["label"]["version"] == version
        product = entity(web, owner, product_id)
        assert product["values"]["ingredients"] == declared["ingredients"]
        assert product["values"]["net_quantity"] == declared["net_quantity"]
        assert "statement_of_identity" not in product["values"]
        assert saved["market_profile"]["values"]["statement_of_identity"] == declared["statement_of_identity"]
        data(web, owner, "update_enterprise_facts", mission_id=first["id"],
            expected_version=product["version"], operation_id="priorities-facility-01",
            facts=[{"field": "facility_activity", "value": "Chế biến và đóng gói"},
                   {"field": "facility_type", "value": "Cơ sở sản xuất thực phẩm"}])
        assert values(data(web, owner, "get_mission", mission_id=first["id"])["label"]) == values(saved["label"])
        second = data(web, owner, "prepare_mission", product_entity_id=product_id,
            continuation_mission_id=first["id"], operation_id="priorities-continue-01",
            user_text="Với hồ sơ này ở New York, chỉ tiếp tục nhãn tiếng Anh; không nghiên cứu lại đăng ký cơ sở.")
        assert {o["id"] for o in second["intent"]["outcomes"]} == {"label"}
        data(web, owner, "start_mission", mission_id=second["id"], operation_id="priorities-start-02")
        second = finish(web, owner, second["id"])
        assert second["status"] == "completed_partial", second
        assert all(values(second["label"])[key] == value for key, value in declared.items())
        assert second["label"]["parent_artifact_ref"]["artifact_id"] == original_label["id"]
        answer = next(a for a in second["answers"] if a["outcome_id"] == "label")
        assert not set(declared).intersection(answer["missing_fields"])
        assert answer["citations"]
        source_ids = {record["id"] for record in second["knowledge"]["records"]}
        assert all(c["reference_id"] in source_ids and c["reference_id"] != c["page_source_id"]
                   for c in answer["citations"])
        current = entity(web, owner, product_id)
        data(web, owner, "update_enterprise_facts", mission_id=second["id"], expected_version=current["version"],
             operation_id="priorities-rename-01", facts=[{"field": "product_name", "value": "Trà Sen Hồ Tây"}])
        renamed = data(web, owner, "prepare_mission", operation_id="priorities-rename-query-01",
            user_text="Tôi có Trà Sen Hồ Tây gửi New York, cần chuẩn bị nhãn tiếng Anh.")
        assert renamed["product"]["entity_id"] == product_id
        assert renamed["product"]["name"] == "Trà Sen Hồ Tây"
        forbidden = call(other, outsider, "prepare_mission", operation_id="priorities-cross-01",
            continuation_mission_id=first["id"], user_text="Tiếp tục nhãn ở New York.")
        assert not forbidden["ok"]
        assert data(other, outsider, "list_missions") == []
        health = web.get("/health").json()
        assert health["paid_calls"] == health["provider_attempts"] == health["worker_errors"] == 0
