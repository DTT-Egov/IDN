"""Field provenance survives bounded follow-ups and does not relabel model work.

Providers below are injected local test callbacks. No key or paid IO is used.
"""
import copy
import json

import pytest

from nmate.main.conversations import MainConversationService
from test_unified_main import setup as setup, scope


def recorded_rows(repo):
    with repo.connection() as db:
        return [dict(row) for row in db.execute("SELECT * FROM v03_live_attempts ORDER BY id")]


def test_free_inventory_plan_origin_survives_reload_and_clarify(setup):
    repo, owner, _other, model, provider, _missions, intake, chats = setup
    model.fail = True  # Any accidental dispatch would fail this bounded action.
    first = chats.prepare_chat_draft(*scope(owner),
        "Chị báo tồn trên sổ 120, đếm thực tế 110", "origin-free-counts")
    item = first["intake"]
    assert item["origins"]["business_plan"] == "bounded_local_parser"
    assert item["origins"]["assistant_text"] == "bounded_local_parser"
    first_operation = item["prepare_operation_id"]
    # Reconstruct services to prove the contract is durable, not browser memory.
    chats = MainConversationService(intake)
    restored = chats.get(*scope(owner), first["id"])
    result = chats.prepare_chat_draft(*scope(owner), "Ngày 18/10/2026, mã TS01",
        "origin-free-date-code", restored["id"])
    item = MainConversationService(intake).get(*scope(owner), result["id"])["intake"]
    assert item["prepare_operation_id"] == first_operation
    assert item["latest_intake_operation_id"] == "origin-free-date-code"
    assert item["origins"]["business_plan"] == "bounded_local_parser"
    assert item["origins"]["intent"] == item["origins"]["working_answers"] == "bounded_local_parser"
    assert item["origins"]["next_steps"] == "bounded_local_parser"
    assert item["intent"]["working_answers"] == {
        "book_quantity": 120.0, "physical_quantity": 110.0,
        "count_date": "2026-10-18", "product_code": "TS01"}
    assert "đối chiếu phiếu nhập/xuất" in item["pending_question"]
    assert item["candidates"] == []
    assert repo.get_context(*scope(owner))["fact_refs"] == []
    assert model.calls == [] and provider.summary()["paid_calls"] == 0


@pytest.mark.asyncio
async def test_model_followup_overwrites_bounded_origin_with_actual_model_origin(setup):
    _repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    first = chats.prepare_chat_draft(*scope(owner),
        "Chị muốn giảm sai lệch tồn kho", "origin-free-before-model")
    response = await chats.send_async(*scope(owner),
        "Chị muốn ưu tiên đối chiếu tồn kho", [], "origin-injected-model",
        first["id"], paid_consent=True, task_hint="sales_inventory")
    assert response["intake"]["id"] == first["intake"]["id"]
    assert response["intake"]["origins"]["business_plan"] == "claude"
    assert response["intake"]["origins"]["assistant_text"] == "claude"
    assert response["latest_operation_id"] == "origin-injected-model"
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_reading_recorded_claude_plan_preserves_provenance_and_receipt(setup):
    repo, owner, _other, model, _provider, _missions, intake, chats = setup
    first = await chats.send_async(*scope(owner),
        "Chị muốn ưu tiên đối chiếu tồn kho", [], "origin-recorded-model",
        paid_consent=True, task_hint="sales_inventory")
    original = copy.deepcopy(first["intake"])
    rows = recorded_rows(repo)
    with repo.connection() as db:
        stored_before_read = db.execute("SELECT payload_json FROM v04_intakes WHERE id=?",
            (original["id"],)).fetchone()[0]
    chats = MainConversationService(intake)
    for _ in range(2):
        restored = chats.get(*scope(owner), first["id"])
        assert restored["intake"]["origins"]["business_plan"] == "claude"
        assert restored["intake"] == original
    with repo.connection() as db:
        stored_after_read = db.execute("SELECT payload_json FROM v04_intakes WHERE id=?",
            (original["id"],)).fetchone()[0]
    assert stored_after_read == stored_before_read
    persisted = json.loads(stored_after_read)
    added_read_fields = {"intent_plan", "intent_plan_basis", "workspace_contract"}
    assert set(original) - set(persisted) == added_read_fields
    assert {key: value for key, value in original.items() if key not in added_read_fields} == persisted
    assert original["intent_plan"]["schema_version"] == "intent-plan/1"
    assert original["intent_plan_basis"]["does_not_rewrite_saved_analysis"] is True
    assert original["workspace_contract"]["schema_version"] == "workspace-contract/1"
    assert original["workspace_contract"]["projection_only"] is True
    assert recorded_rows(repo) == rows and len(model.calls) == 1
