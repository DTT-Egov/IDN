from nmate.policy_v1.service import resolve_intent, PolicyService
from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts


def test_negated_request_is_not_a_positive_equipment_goal():
    value = resolve_intent('Chị không đề nghị mua thiết bị; chị chỉ đề nghị mở lớp sổ sách buổi tối.')
    assert value['goals'] == ['workforce_training']


def test_affirmative_request_after_negative_clause_keeps_both_real_goals():
    value = resolve_intent('Chị không chỉ đề nghị mua thiết bị mà còn muốn đào tạo nhân viên sổ sách.')
    assert set(value['goals']) == {'equipment_purchase', 'workforce_training'}


def test_one_policy_topic_is_named_in_the_main_answer(tmp_path):
    repo = CoreRepository(tmp_path / 'intent.sqlite')
    owner = LocalAccounts(repo).register('v17-intent-owner', 'Synthetic-local-12345', 'Cơ sở thử')
    core = CoreSSOTService(repo)
    case = PolicyService(repo, core).prepare(owner['account_id'], owner['enterprise_id'],
        'Không xin mua thiết bị. Chị chỉ muốn kiến nghị đào tạo nhân viên sổ sách.', 'single-intent-once')
    assert 'Đào tạo nhân viên' in case['lead_vi']
    assert 'Mua thiết bị' not in case['lead_vi']


def test_multiple_policy_topics_are_each_named_once_not_nested_twice(tmp_path):
    repo = CoreRepository(tmp_path / 'multi.sqlite')
    owner = LocalAccounts(repo).register('v17-multi-owner', 'Synthetic-local-12345', 'Cơ sở thử')
    case = PolicyService(repo, CoreSSOTService(repo)).prepare(owner['account_id'], owner['enterprise_id'],
        'Chị muốn hỗ trợ xuất khẩu trà sen và đào tạo nhân viên sổ sách.', 'multi-intent-once')
    assert case['lead_vi'].count('Phát triển thị trường / xuất khẩu:') == 1
    assert case['lead_vi'].count('Đào tạo nhân viên:') == 1
