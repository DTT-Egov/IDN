"""Explicit public-source installation cannot alter enterprise or paid history."""
from datetime import date

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.install_readiness import install_readiness_pack, PACK_PATH
from nmate.v03.source_refresh import authority_host


def rows(db):
    return {row[0]: {tuple(value) for value in db.execute('SELECT * FROM "' + row[0] + '"')}
            for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}


def test_source_expansion_is_explicit_additive_and_idempotent(tmp_path):
    repo = CoreRepository(tmp_path / "install.sqlite3")
    catalog = DomainCatalog(repo)
    with repo.connection() as db:
        assert not db.execute("SELECT 1 FROM v03_domain_pack_installations WHERE pack_id LIKE '%readiness%'").fetchone()
        before = rows(db)
    result = install_readiness_pack(repo)
    assert result["paid_calls"] == 0 and result["enterprise_ssot_unchanged"]
    allowed = {"v03_domain_sources", "v03_domain_references", "v03_domain_pack_installations", "v03_domain_reference_supersessions"}
    with repo.connection() as db:
        after = rows(db)
    for table in before:
        if table in allowed:
            assert before[table] <= after[table]
        else:
            assert before[table] == after[table]
    repeat = install_readiness_pack(repo)
    assert all(value == 0 for value in repeat["inserted_rows"].values())
    with repo.connection() as db:
        assert rows(db) == after
    assert PACK_PATH.is_file()
    assert catalog.lookup_domain(["fsvp_importer", "origin_marking"], market_code="US", as_of_date=date(2026, 10, 22))["coverage"]["missing"] == []
    for market in ("DE", "JP"):
        found = catalog.lookup_domain(["fsvp_importer", "origin_marking"], market_code=market, as_of_date=date(2026, 10, 22))
        assert found["records"] == [] and found["coverage"]["supported"] == []


@pytest.mark.parametrize("host", ["www.ecfr.gov", "www.govinfo.gov"])
def test_curated_regulations_use_exact_official_hosts(host):
    assert authority_host("https://" + host + "/current/example") == host
    for suffix in (".example.com", "@evil.example"):
        with pytest.raises(CoreError):
            authority_host("https://" + host + suffix + "/current/example")
