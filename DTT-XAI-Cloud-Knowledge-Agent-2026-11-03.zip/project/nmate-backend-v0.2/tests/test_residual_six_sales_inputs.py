"""DF-006/015/024: a quoted sales count keeps its own calendar period.

These tests use local parsing/private SQLite only; counts never become SSOT.
"""
import copy

import pytest

from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.conversations import ConversationService
from nmate.v04.dialogue import business_plan, interpret, next_steps, working_answers
from nmate.v04.intake import IntakeService


def response(text, previous=None):
    intent = interpret(text, previous=previous, task_hint="sales_inventory")
    intent["working_answers"] = working_answers(text, intent, (previous or {}).get("working_answers"))
    return intent, next_steps({"intent": intent, "saved_context": {"entities": []}, "product": None})


@pytest.mark.parametrize("text,period", [
    ("Chị tháng 9 bán 120 hộp.", "tháng 9"),
    ("Tháng 09, bán được 120 hộp.", "tháng 9"),
    ("Chị bán 120 hộp trong tháng 9.", "tháng 9"),
    ("Tháng 9 năm 2026 chị bán 120 hộp.", "tháng 9/2026"),
    ("Bán được 120 hộp tháng 9/2026.", "tháng 9/2026"),
    ("Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp.", "tháng 9"),
])
def test_calendar_sales_count_is_retained_and_not_requested_again(text, period):
    intent, steps = response(text)
    assert intent["primary"] == "digitize_operations"
    assert intent["focus"] == "sales_reporting"
    assert intent["operation_topics"] == ["sales_reporting"]
    slots = intent["working_answers"]
    assert slots["recent_sales_quantity"] == 120
    assert slots["sales_period"] == slots["report_period"] == period
    assert slots["sales_period_kind"] == "calendar_month"
    assert slots["quantity_unit"] == "hộp"
    assert "120 hộp" in steps[0] and period in steps[0]
    assert "theo ngày hay tháng" not in " ".join(steps)
    assert "chưa ghi" in steps[0] and "chưa" in " ".join(steps)
    assert "120" in str(business_plan(intent, {}))


def test_quantity_without_period_asks_only_for_missing_period():
    intent, steps = response("Chị bán được 120 hộp.")
    assert intent["focus"] == "sales_reporting"
    assert intent["working_answers"]["recent_sales_quantity"] == 120
    assert "120 hộp" in steps[0]
    assert "kỳ bán" in steps[-1]
    assert "cho biết số bán" not in " ".join(steps)


@pytest.mark.parametrize("text", ["Tháng 9", "Trong tháng 09", "Tháng 9 năm 2026"])
def test_reporting_accepts_requested_calendar_period_after_quantity(text):
    first, _ = response("Chị bán được 120 hộp.")
    after, steps = response(text, first)
    assert after["focus"] == "sales_reporting"
    assert after["working_answers"]["recent_sales_quantity"] == 120
    assert after["working_answers"]["sales_period"].startswith("tháng 9")
    assert "120 hộp" in steps[0] and "Bạn" not in " ".join(steps)


def test_restocking_accepts_requested_calendar_period_without_losing_quantity():
    first, _ = response("Chị có nên nhập thêm hàng? Bán được 120 hộp.")
    after, _ = response("Tháng 9", first)
    assert after["focus"] == "restocking_planning"
    assert after["working_answers"]["recent_sales_quantity"] == 120
    assert after["working_answers"]["sales_period"] == "tháng 9"


def test_sales_answer_continues_reporting_after_reload_without_ssot(tmp_path):
    repo = CoreRepository(tmp_path / "private-sales.sqlite3")
    owner = LocalAccounts(repo).register("residual-sales", "Only-local-test-password", "Cơ sở thử")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    before = repo.get_context(account, enterprise)
    service = ConversationService(IntakeService(repo))
    first = service.send(account, enterprise, "Chị cần tổng hợp bán hàng theo tháng.", [], "sales-start")
    reopened = ConversationService(IntakeService(repo))
    assert reopened.get(account, enterprise, first["id"])["intake"]["intent"]["focus"] == "sales_reporting"
    result = reopened.send(account, enterprise, "Tháng 9 bán 120 hộp.", [], "sales-count", first["id"])
    item = result["intake"]
    assert item["intent"]["focus"] == "sales_reporting"
    assert item["intent"]["working_answers"]["recent_sales_quantity"] == 120
    assert item["intent"]["working_answers"]["sales_period"] == "tháng 9"
    assert "120 hộp" in item["assistant_text"] and "tháng 9" in item["assistant_text"]
    assert "bạn" not in (item["assistant_text"] + " " + item["pending_question"]).casefold()
    again = ConversationService(IntakeService(repo)).get(account, enterprise, first["id"])
    assert again["intake"]["intent"] == item["intent"]
    after = repo.get_context(account, enterprise)
    assert {key: value for key, value in after.items() if key != "as_of"} == {
        key: value for key, value in before.items() if key != "as_of"}
    assert item["candidates"] == []


def test_calendar_sales_followup_keeps_restocking_focus_and_supplier_days():
    first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 70 hộp.")
    prior = copy.deepcopy(first)
    after, steps = response("Tháng 9 bán 120 hộp; nhà cung cấp giao trong 5 ngày.", first)
    assert first == prior
    assert after["focus"] == "restocking_planning"
    assert after["working_answers"] == {"available_quantity": 70, "quantity_unit": "hộp", "available_quantity_unit": "hộp",
        "recent_sales_quantity": 120, "sales_period": "tháng 9", "sales_period_kind": "calendar_month",
        "recent_sales_quantity_unit": "hộp", "supplier_lead_days": 5}
    assert "số bán trong kỳ cụ thể" not in " ".join(steps)
    later, _ = response("Nhà cung cấp giao trong 7 ngày.", after)
    assert later["working_answers"]["sales_period"] == "tháng 9"
    assert later["working_answers"]["supplier_lead_days"] == 7


@pytest.mark.parametrize("text", [
    "Chị chưa bán được 120 hộp trong tháng 9.",
    "Chị muốn bán 120 hộp mỗi tháng.",
    "Dự kiến bán 120 hộp tháng 9.",
    "Mục tiêu là bán 120 hộp trong tháng 9.",
    "Hộp 120 g, tháng 9 nhập 30 hộp.",
    "Chị bán trà sen, hộp 120 g.",
])
def test_target_negation_and_net_weight_are_not_actual_sales_counts(text):
    intent, _ = response(text)
    assert "recent_sales_quantity" not in intent["working_answers"]


def test_calendar_month_is_not_a_recurring_month_or_supplier_period():
    first, _ = response("Chị có nên nhập thêm hàng? Bán 30 hộp mỗi tuần.")
    after, _ = response("Tháng 9 bán 120 hộp; nhà cung cấp giao trong 5 ngày.", first)
    assert after["working_answers"]["sales_period"] == "tháng 9"
    assert after["working_answers"]["sales_period_kind"] == "calendar_month"
    recurring, _ = response("Bán 40 hộp mỗi tháng.", after)
    assert recurring["working_answers"]["sales_period"] == "tháng"
    assert recurring["working_answers"]["sales_period_kind"] == "recurring"


def test_two_sales_statements_do_not_silently_collapse_into_one_total():
    intent, _ = response("Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp; tháng 10 bán 80 hộp.")
    assert "recent_sales_quantity" not in intent["working_answers"]


def test_invalid_calendar_month_does_not_become_month_one():
    intent, _ = response("Chị bán 120 hộp tháng 13.")
    assert intent["working_answers"]["recent_sales_quantity"] == 120
    assert not intent["working_answers"].get("sales_period")


@pytest.mark.parametrize("text", ["Tháng 9 dự kiến bán 120 hộp.", "Tháng 9 chưa bán 120 hộp."])
def test_target_or_negation_does_not_relabel_previous_observation(text):
    first, _ = response("Tháng 8 bán 90 hộp.")
    after, _ = response(text, first)
    assert after["working_answers"].get("recent_sales_quantity") != 120
    assert not (after["working_answers"].get("recent_sales_quantity") == 90
                and after["working_answers"].get("sales_period") == "tháng 9")


def test_new_count_without_period_cannot_borrow_previous_calendar_month():
    first, _ = response("Tháng 8 bán 90 hộp.")
    after, _ = response("Bán được 120 hộp.", first)
    assert after["working_answers"]["recent_sales_quantity"] == 120
    assert not after["working_answers"].get("sales_period")
    assert not after["working_answers"].get("report_period")


def test_zero_sales_is_an_observed_quantity():
    intent, steps = response("Tháng 9 bán 0 hộp.")
    assert intent["working_answers"]["recent_sales_quantity"] == 0
    assert "0 hộp" in steps[0]


def test_supplier_duration_before_sale_is_not_a_sales_period():
    intent, _ = response("Nhà cung cấp giao trong 5 ngày, bán 120 hộp.")
    assert intent["working_answers"]["recent_sales_quantity"] == 120
    assert not intent["working_answers"].get("sales_period")


@pytest.mark.parametrize("text", [
    "Tháng 9 bán 120 nghìn đồng.", "Tháng 9 bán 120000 đồng.",
    "Nếu tháng 9 bán 120 hộp thì nhập bao nhiêu?",
    "Chị có thể bán 120 hộp tháng 9 không?",
])
def test_money_and_hypothetical_statements_are_not_actual_unit_sales(text):
    intent, _ = response(text)
    assert "recent_sales_quantity" not in intent["working_answers"]


def test_count_uses_nearest_calendar_qualifier_not_report_heading():
    intent, _ = response("Báo cáo tháng 8, tháng 9 bán 120 hộp.")
    assert intent["working_answers"]["recent_sales_quantity"] == 120
    assert intent["working_answers"]["sales_period"] == "tháng 9"


@pytest.mark.parametrize("same_turn", [False, True])
def test_restocking_stock_and_sales_units_cannot_overwrite_each_other(same_turn):
    if same_turn:
        intent, steps = response("Chị có nên nhập thêm hàng? Tồn kho còn 70 hộp; tháng 9 bán 120 kg.")
    else:
        first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 70 hộp.")
        intent, steps = response("Tháng 9 bán 120 kg.", first)
    slots = intent["working_answers"]
    assert slots["available_quantity"] == 70 and slots["recent_sales_quantity"] == 120
    assert slots["available_quantity_unit"] == "hộp"
    assert slots["recent_sales_quantity_unit"] == "kg"
    assert "70 hộp" in " ".join(steps) and "70 kg" not in " ".join(steps)
    assert "đơn vị" in " ".join(steps) and "quy đổi" in " ".join(steps)


def test_restocking_mixed_units_survive_reload_without_ssot(tmp_path):
    repo = CoreRepository(tmp_path / "private-mixed-unit.sqlite3")
    owner = LocalAccounts(repo).register("residual-sales-units", "Only-local-test-password", "Cơ sở thử")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    service = ConversationService(IntakeService(repo))
    first = service.send(account, enterprise, "Chị có nên nhập thêm hàng? Tồn kho còn 70 hộp.", [], "units-stock")
    service = ConversationService(IntakeService(repo))
    value = service.send(account, enterprise, "Tháng 9 bán 120 kg.", [], "units-sales", first["id"])
    reopened = ConversationService(IntakeService(repo)).get(account, enterprise, value["id"])
    slots = reopened["intake"]["intent"]["working_answers"]
    assert slots["available_quantity_unit"] == "hộp" and slots["recent_sales_quantity_unit"] == "kg"
    assert "70 hộp" in str(reopened["intake"]["next_steps"])
    assert "70 kg" not in str(reopened["intake"]["next_steps"])
    assert repo.get_context(account, enterprise)["fact_refs"] == []


def test_missing_stock_unit_is_not_inferred_from_sales_unit():
    first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 70.")
    after, steps = response("Tháng 9 bán 120 kg.", first)
    assert after["working_answers"]["recent_sales_quantity_unit"] == "kg"
    assert not after["working_answers"].get("available_quantity_unit")
    assert "70 kg" not in " ".join(steps)
    assert "đơn vị của lượng tồn" in " ".join(steps)


@pytest.mark.parametrize("unit", ["", " hộp"])
def test_switch_to_inventory_keeps_closed_inventory_slots_not_sales_units(unit):
    from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
    first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 70 hộp.")
    sales, _ = response("Tháng 9 bán 120 kg.", first)
    after, _ = response("Tồn sổ 120" + unit + ", đếm thực tế 110" + unit + ".", sales)
    slots = after["working_answers"]
    assert after["focus"] == "inventory_accuracy"
    assert slots["book_quantity"] == 120 and slots["physical_quantity"] == 110
    assert not set(slots) & {"available_quantity", "available_quantity_unit", "recent_sales_quantity",
        "recent_sales_quantity_unit", "sales_period", "sales_period_kind"}
    assert slots.get("quantity_unit") == ("hộp" if unit else None)
    assert GovernedLegacyAdapter._inventory_context(after)["working_answers"] == slots


def test_inventory_count_followup_stays_separate_from_sales_context():
    first, _ = response("Chị đối chiếu tồn sổ 120 hộp, thực tế 110 hộp.")
    after, steps = response("Ngày 18/10/2026, mã TS01", first)
    assert after["focus"] == "inventory_accuracy"
    assert after["working_answers"]["book_quantity"] == 120
    assert after["working_answers"]["physical_quantity"] == 110
    assert "recent_sales_quantity" not in after["working_answers"]
    assert "phiếu nhập/xuất" in steps[-1]
