"""Public-source update and saved-Claude invariants; entirely offline/free."""
import copy
import hashlib
import json
from pathlib import Path

import pytest

from nmate.policy_v1 import KnowledgeCatalog, PolicyService
from nmate.policy_v1.source_update import ATTACHMENT_ID, PACK_PATH, POLICY_ID, PROGRAM_SOURCE_IDS, build_source_update
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "offline-source-update.sqlite")
    account = LocalAccounts(repo).register("source_update_owner", "only-local-test-password", "Trà Sen thử nghiệm")
    catalog = KnowledgeCatalog(repo)
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    # Save the original case before the appendix pack was available, matching
    # the actual user journey. Never call a model in this fixture.
    saved = service.prepare(account["account_id"], account["enterprise_id"],
        "Số hóa kho có chương trình nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?", "prepare-old")
    return repo, account, catalog, service, saved


def test_public_pack_has_original_bytes_exact_page_locators_and_no_legal_approval(setup):
    repo, _, catalog, _, _ = setup
    first = catalog.bootstrap_digital_source_pack()
    assert all(not entry["unchanged"] for entry in first["snapshots"])
    assert all(entry["unchanged"] for entry in catalog.bootstrap_digital_source_pack()["snapshots"])
    assert first["provider_calls"] == first["review_events_created"] == first["publication_events_created"] == 0
    pack = json.loads(PACK_PATH.read_text(encoding="utf8"))
    with repo.connection() as db:
        for document in pack["documents"]:
            row = db.execute("SELECT * FROM pol_source_snapshots WHERE source_id=?", (document["source_id"],)).fetchone()
            assert hashlib.sha256(row["raw_bytes"]).hexdigest() == document["raw_sha256"]
            assert hashlib.sha256(row["canonical_text"].encode()).hexdigest() == document["canonical_text_sha256"]
            assert row["complete_policy"] == 0
            assert row["extraction_version"] == document["extraction_version"]
            chunks = db.execute("SELECT * FROM pol_chunks WHERE snapshot_id=? ORDER BY ordinal", (row["id"],)).fetchall()
            assert len(chunks) == len(document["pages"])
            for chunk, page in zip(chunks, document["pages"]):
                locator = json.loads(chunk["locator_json"])
                assert locator["type"] == "pdf_page" and locator["page"] == page["page"]
                assert row["canonical_text"][chunk["start_offset"]:chunk["end_offset"]] == chunk["text_original"]
            gate = db.execute("SELECT * FROM pol_source_gates WHERE source_id=?", (document["source_id"],)).fetchone()
            assert gate["availability"] == "snapshot_only" and gate["current_until"] is None
        for table in ("pol_members", "pol_review_events", "pol_publication_events", "pol_release_events"):
            assert db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0
    assert not catalog.retrieve("số hóa kho", purpose="reviewed_policy_assessment")


def test_saved_result_addendum_is_useful_separate_and_read_only(setup):
    repo, account, catalog, service, saved = setup
    catalog.bootstrap_digital_source_pack()
    with repo.connection() as db:
        original = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (saved["id"],)).fetchone()[0]
        operations = db.execute("SELECT COUNT(*) FROM pol_operations").fetchone()[0]
    result = service.get(account["account_id"], account["enterprise_id"], saved["id"])
    update = result["source_update"]
    assert update["provider_calls"] == 0 and update["provider_used"] is False
    assert update["does_not_replace_saved_claude"] and not update["changes_legal_verdict"]
    assert update["eligibility_state"] == "awaiting_rule_review" and update["application_status"] == "unknown"
    assert result["outcomes"] == saved["outcomes"] and result["sources"] == saved["sources"]
    action = result["business_next_action"]
    assert action["kind"] == "prepare_program_enquiry"
    assert len(action["questions_vi"]) == 3 and "kho" in action["draft_message_vi"]
    assert action["automatic_contact"] is action["automatic_submission"] is False
    assert "url" not in action  # An inline guide does not launch a call/email.
    assert action["contact"]["phone"] == "0919140820"
    assert action["citations"][0]["locator"]["page"] == 9
    assert "Bà Lương Mỹ Hạnh" in action["citations"][0]["quote_original"]
    assert any("chữ ký" in s["identity_note_vi"] for s in update["sources"])
    for source in update["sources"]:
        assert source["legal_currency"] == "not_verified"
        for citation in source["chunks"]:
            bound = catalog.bind_evidence(citation["chunk_id"], citation["quote_original"])
            assert bound["span_hash"] == citation["span_hash"]
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (saved["id"],)).fetchone()[0] == original
        assert db.execute("SELECT COUNT(*) FROM pol_operations").fetchone()[0] == operations


def test_no_new_paid_receipt_or_rewrite_of_saved_analysis(setup):
    _, _, catalog, _, saved = setup
    catalog.bootstrap_digital_source_pack()
    stored = {**saved, "provider_used": True, "provider_calls": 1,
        "model_analysis": {"schema_version": "policy-model-analysis/2", "ordered_next_tasks": [{"id": "old_task"}]},
        "provider_receipt": {"attempt_id": "SAVED-NO-NEW-MODEL", "cost_usd": "0.054312"}}
    original = copy.deepcopy(stored)
    update = build_source_update(catalog, stored)
    assert update and update["provider_calls"] == 0
    assert stored == original


@pytest.mark.parametrize("change", ["other_goal", "other_notice", "unavailable", "changed", "superseded", "different_bytes"])
def test_contact_guide_fails_closed_for_unrelated_or_changed_sources(setup, change):
    repo, _, catalog, _, saved = setup
    catalog.bootstrap_digital_source_pack()
    payload = copy.deepcopy(saved)
    if change == "other_goal":
        payload["intent"]["goal"] = "equipment_purchase"
    elif change == "other_notice":
        payload["sources"] = []
    elif change == "different_bytes":
        # Use the public ingestion API to change the current source version;
        # no snapshot/hash mutation is needed to exercise the stale-guide guard.
        with repo.connection(write=True) as db:
            catalog._snapshot(db, "test-only", ATTACHMENT_ID, b"different-public-source", "Nguồn mới cần rà.",
                "2026-10-20T00:00:00+00:00", None, False, None, None, "text/plain")
    else:
        with repo.connection(write=True) as db:
            db.execute("UPDATE pol_source_gates SET availability=? WHERE source_id=?", (change, ATTACHMENT_ID))
    assert build_source_update(catalog, payload) is None


def test_pdf_named_attachment_does_not_misrepresent_unsigned_file_as_signed():
    pack = json.loads(PACK_PATH.read_text(encoding="utf8"))
    attachment = next(d for d in pack["documents"] if d["source_id"] == ATTACHMENT_ID)
    assert "signed" not in attachment["filename"]
    assert attachment["effective_from"] is None
    assert "trống" in attachment["identity_note_vi"]
    assert all(d["review_state"] == "not_reviewed" and d["publication_state"] == "not_published" for d in pack["documents"])
    assert Path(PACK_PATH.parent / attachment["filename"]).exists()


def test_new_case_uses_appendix_three_collection_not_other_programs(setup):
    _, _, catalog, _, saved = setup
    catalog.bootstrap_digital_source_pack()
    sources = catalog.retrieve("Số hóa quản lý kho cần giấy tờ gì và còn nhận hồ sơ không?", goal="digital_inventory", limit=30)
    appendix = [s for s in sources if s["source_id"] == ATTACHMENT_ID]
    assert appendix
    assert {s["locator"]["page"] for s in appendix} <= {2, 9, 10, 11}
    assert all("PHỤ LỤC 4" not in s["quote_original"] and "PHỤ LỤC 2" not in s["quote_original"] for s in appendix)
    source_ids = {s["source_id"] for s in sources}
    assert not source_ids.intersection({s["source_id"] for s in catalog.retrieve("Có hỗ trợ mua máy đóng gói không?", goal="equipment_purchase")}) - {"HN-NOTICE-2026-14"}
    # Fresh missions can cite the attachment without the original notice being
    # among the bounded retrieval results. The same guide must survive reload.
    payload = copy.deepcopy(saved)
    payload["sources"] = [{"source_id": ATTACHMENT_ID}]
    assert build_source_update(catalog, payload)["business_next_action"]["kind"] == "prepare_program_enquiry"


def test_scoped_assignment_does_not_approve_rules_or_say_no_reviewer(setup):
    repo, account, catalog, _, saved = setup
    catalog.bootstrap_digital_source_pack()
    with repo.connection(write=True) as db:
        for role in ("reviewer", "publisher"):
            for source_id in PROGRAM_SOURCE_IDS:
                db.execute("INSERT INTO pol_knowledge_role_scopes VALUES(?,?,'hanoi_policy',?,?,?,?,NULL)",
                           (account["account_id"], role, POLICY_ID, source_id, "test-assignment", "2026-10-20T00:00:00+00:00"))
    update = build_source_update(catalog, saved)
    assert update["authority_state"] == {"reviewer_assigned": True, "publisher_assigned": True, "rule_approval_inferred": False}
    assert "Chưa có người" not in update["pending_system_work"][0]["status_vi"]
    assert update["eligibility_state"] == "awaiting_rule_review"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_review_events").fetchone()[0] == 0


def test_unrelated_scope_or_revoked_scope_is_not_program_assignment(setup):
    repo, account, catalog, _, saved = setup
    catalog.bootstrap_digital_source_pack()
    with repo.connection(write=True) as db:
        for role in ("reviewer", "publisher"):
            for source_id in PROGRAM_SOURCE_IDS:
                db.execute("INSERT INTO pol_knowledge_role_scopes VALUES(?,?,'hanoi_policy',?,?,?,?,NULL)",
                           (account["account_id"], role, "OTHER-POLICY", source_id, "test-assignment", "2026-10-20T00:00:00+00:00"))
    assert not build_source_update(catalog, saved)["authority_state"]["reviewer_assigned"]
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_knowledge_role_scopes SET policy_id=?,revoked_at='2026-10-20T00:01:00+00:00'", (POLICY_ID,))
    assert not build_source_update(catalog, saved)["authority_state"]["publisher_assigned"]
