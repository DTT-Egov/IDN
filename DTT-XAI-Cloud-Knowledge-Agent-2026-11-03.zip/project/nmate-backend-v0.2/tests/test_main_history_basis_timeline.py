"""A later profile must not retroactively ground an older saved conversation."""
from nmate.main.history import history_metadata
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.conversations import ConversationService
from nmate.v04.intake import IntakeService


def test_old_empty_chat_retains_empty_basis_after_profile_creation_and_reload(tmp_path):
    repo = CoreRepository(tmp_path / "history-timeline.sqlite3")
    owner = LocalAccounts(repo).register("history-owner", "Only-for-history-test-20", "Cơ sở Trà Sen")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    service = ConversationService(IntakeService(repo))
    old = service.send(account, enterprise, "Tôi muốn số hóa quản lý tồn kho", [], "history-empty-chat-0001")
    assert old["intake"]["reused_context"]["fact_count"] == 0
    original_metadata = history_metadata(old)
    company = repo.create_entity(account, enterprise, "enterprise", "Cơ sở Trà Sen", operation_id="history-company-0001")
    repo.propose_or_apply_facts(account, enterprise, company["id"],
                               [{"field": "inventory_management", "value": "Excel"}],
                               company["version"], "history-company-facts-001")
    assert repo.get_context(account, enterprise)["fact_refs"]
    restored = ConversationService(IntakeService(CoreRepository(tmp_path / "history-timeline.sqlite3")))
    view = restored.get(account, enterprise, old["id"])
    assert history_metadata(view) == original_metadata
    assert history_metadata(view)["history_state_vi"] == "Đã lưu trao đổi · chưa dùng hồ sơ"
