"""DF-029/044/046: actual archive must not outlive a missing field READ.

Produce a genuine prior-style immutable manifest with fields=[], then retain
resource/net_quantity READ while revoking only name. No provider or MAIN use.
"""
import asyncio
from datetime import datetime, timedelta, timezone
import socket

import pytest

from nmate.main.app import make_main_app
from nmate.main.recorded_analysis import project_recorded_export_intake
from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.export_intake_contracts import build_export_intake_payload
from nmate.v03.markets import get_market
from test_review_commands_v2 import data_snapshot


def test_archive_rechecks_field_read_when_old_gateway_manifest_omitted_fields(tmp_path, monkeypatch):
    original_connect = socket.socket.connect

    def local_only(sock, address):
        if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
            return original_connect(sock, address)
        raise AssertionError("Legacy archive fixture cannot call any external provider")

    monkeypatch.setattr(socket.socket, "connect", local_only)
    calls = []
    name = "TÊN RIÊNG KIỂM THỬ"
    question = f"Chị muốn kiểm tra đăng ký FDA cho {name} sang Mỹ."
    output = {"scope": "us_food", "outcomes": [{"id": "registration", "question_quote": "đăng ký FDA"}],
              "product_name": name, "product_quote": name, "ambiguities": []}

    async def synthetic(model, _body, _limit):
        calls.append(model)
        return {"text": json_text(output), "model": model, "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    async def forbidden(*_args):
        raise AssertionError("Native provider cannot run in this fixture")

    app = make_main_app(tmp_path / "legacy-archive-fields.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=synthetic, gateway_enabled=True)
    repo, core, gateway, provider = app.state.repo, app.state.core_extension.core, app.state.gateway, app.state.main_provider
    owner = app.state.accounts.register("legacy-archive-reader", "Only-fixture-password", "Fixture A")
    colleague = app.state.accounts.register("legacy-archive-source-owner", "Only-fixture-password", "Fixture B")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_memberships VALUES(?,?,'owner',1)", (colleague["account_id"], enterprise))
    resource = repo.create_entity(colleague["account_id"], enterprise, "product", name)
    core.grant_resource(colleague["account_id"], enterprise, resource["id"], account,
                        ["read"], ["name", "net_quantity"])
    gateway.authorize_budget(account, enterprise, approval_id="SYNTHETIC-ARCHIVE-NO-PROVIDER",
        max_calls=1, max_cost_usd=1, purposes=["legacy_intake"], roles=["standard"],
        expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    payload = build_export_intake_payload(question, {"entity_id": resource["id"], "values": {"name": name}},
                                          None, get_market("US"))
    operation, conversation = "old-empty-fields-archive", "old-empty-fields-conversation"
    with monkeypatch.context() as previous_projector:
        previous_projector.setattr(provider.governed_adapter, "_resource_dependencies",
                                  lambda _context: [{"resource_id": resource["id"], "fields": []}])
        envelope = asyncio.run(provider("intake", payload, operation_id=operation, account_id=account,
                                        enterprise_id=enterprise))
    stamp = now_iso()
    chat = {"id": conversation, "enterprise_id": enterprise, "owner_id": account, "title": question,
            "messages": [], "drafts": {}, "intake_ids": [], "mission_ids": [], "active_intake_id": None,
            "operation_ids": [operation], "latest_operation_id": operation, "task_hint": "export_research",
            "created_at": stamp, "updated_at": stamp}
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)",
                   (conversation, enterprise, account, json_text(chat), stamp, stamp))
        db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'failed','live_output_invalid',?)",
                   (account, enterprise, operation, "synthetic-main-hash", conversation, "export_research", stamp))
    authorize = provider.governed_adapter.authorize_recorded_envelope
    # The red run also proved this opaque shared archive readable before the
    # revoke. The conservative fix may already deny it because the full old
    # field set was never retained; this independent invariant concerns the
    # later revoke and must not require opening the earlier incomplete scope.
    assert envelope["data"]["product_name"] == name
    core.revoke_resource(colleague["account_id"], enterprise, resource["id"], account, ["read"], ["name"])
    assert not core.can_read(account, enterprise, resource["id"], "name")
    assert core.can_read(account, enterprise, resource["id"], "net_quantity")
    assert core.can_read(account, enterprise, resource["id"])
    before = data_snapshot(repo)
    with pytest.raises(CoreError):
        project_recorded_export_intake(repo, account, enterprise, conversation, authorize_envelope=authorize)
    assert data_snapshot(repo) == before and len(calls) == 1
    assert envelope["data"] == output
