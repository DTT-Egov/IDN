"""DF-034: frozen old full requests remain exact cache reads, with current READ.

The fixture contains public static instructions/schema, copied from the build
before sales slots. No secrets, production data, real model or new budget.
"""
import asyncio
import copy
import hashlib
import json
from pathlib import Path

import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.main.provider import MainProvider, canonical_main_request, historic_main_request_hashes
from nmate.v03.core import CoreError, json_text
from nmate.v04.live_review import DialogueOutput, INSTRUCTIONS, INSTRUCTIONS_V1, historic_dialogue_contract_payloads
from test_design_gateway_invariants import workspace as shared_gateway_workspace
from test_v04_live_review import result


FROZEN = json.loads((Path(__file__).parent / "fixtures/dialogue_contract_before_sales_20261022.json").read_text(encoding="utf-8"))


def request(*, old=False, resource=None):
    payload = {"instructions_vi": FROZEN["instructions_vi"] if old else INSTRUCTIONS,
        "response_schema": copy.deepcopy(FROZEN["response_schema"]) if old else DialogueOutput.model_json_schema(),
        "input": {"current_question": "Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp.", "ssot": {"values": {"net_quantity": "100 g"}}}}
    if resource:
        payload["input"]["ssot"] = {"entities": [{"id": resource, "values": {"name": "Hồ sơ riêng"}}]}
    return payload


def digest(payload):
    return hashlib.sha256(json_text(payload).encode()).hexdigest()


def test_frozen_old_base_contract_is_exact_not_recreated_from_a_loose_hash():
    assert FROZEN["instructions_vi"] == INSTRUCTIONS_V1
    before = request()
    variants = historic_dialogue_contract_payloads(before)
    assert variants == [request(), request(old=True)]
    assert before == request()


@pytest.mark.parametrize("version", [1, 2, 3])
@pytest.mark.parametrize("address", [None, "chị", "bác"])
def test_new_registry_contains_old_exact_full_manifest_and_current_variant(version, address):
    old = digest(canonical_main_request("intake", request(old=True), "sales_inventory", contract_version=version, address=address))
    current = digest(canonical_main_request("intake", request(), "sales_inventory", contract_version=version, address=address))
    allowed = historic_main_request_hashes("intake", request(), "sales_inventory")
    assert old in allowed and current in allowed and old != current
    for mutation in ("question", "context", "prompt", "schema", "task"):
        changed = request()
        task = "sales_inventory"
        if mutation == "question":
            changed["input"]["current_question"] += " thay đổi"
        elif mutation == "context":
            changed["input"]["ssot"]["values"]["net_quantity"] = "200 g"
        elif mutation == "prompt":
            changed["instructions_vi"] += " bỏ kiểm chứng"
        elif mutation == "schema":
            changed["response_schema"]["$defs"]["Answer"]["properties"]["value"]["maxLength"] = 999
        else:
            task = "profile_intake"
        assert old not in historic_main_request_hashes("intake", changed, task)


@pytest.fixture
def gateway_workspace(tmp_path):
    return shared_gateway_workspace.__wrapped__(tmp_path)


def test_cross_version_recorded_read_keeps_source_acl_and_receipt_immutable(gateway_workspace):
    repo, core, _, gateway, _, resource, calls, _ = gateway_workspace
    async def injected(model, body, limit):
        calls.append(copy.deepcopy((model, body, limit)))
        output = result("Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp.", focus="sales_reporting")
        return {"text": json_text(output), "model": model,
                "usage": {"input_tokens": 10, "output_tokens": 5}, "stop_reason": "end_turn"}
    gateway.request_fn = injected
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("Native transport forbidden"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    old = request(old=True, resource=resource)
    current = request(resource=resource)
    kwargs = {"operation_id": "old-sales-schema", "account_id": "owner", "enterprise_id": "enterprise"}
    expected = asyncio.run(provider("intake", old, **kwargs))  # Injected gateway fixture only.
    with repo.connection() as db:
        native_before = [tuple(row) for row in db.execute("SELECT * FROM v03_live_attempts ORDER BY id")]
        model_before = [tuple(row) for row in db.execute("SELECT * FROM core_model_attempts ORDER BY id")]
    token = provider.recorded_only.set(True)
    try:
        assert asyncio.run(provider("intake", current, **kwargs)) == expected
        core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
        with pytest.raises(CoreError):
            asyncio.run(provider("intake", current, **kwargs))
    finally:
        provider.recorded_only.reset(token)
    assert len(calls) == 1
    with repo.connection() as db:
        assert [tuple(row) for row in db.execute("SELECT * FROM v03_live_attempts ORDER BY id")] == native_before
        assert [tuple(row) for row in db.execute("SELECT * FROM core_model_attempts ORDER BY id")] == model_before
