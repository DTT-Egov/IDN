"""DF-002/012/047: names in metadata obey current-value and READ authority."""
from __future__ import annotations

import asyncio

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository, json_text, new_id, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_review import LiveReviewMissionService
from nmate.v04.live_review import LiveConversationService, LiveIntakeService, V04ReviewProvider
from nmate.v04.product_binding import matching_owned_products
from test_review_commands_v2 import data_snapshot
from test_ssot_field_scope import legacy_fact


@pytest.fixture
def case(tmp_path):
    repo = CoreRepository(tmp_path / "legacy-name.sqlite3")
    owner = LocalAccounts(repo).register("r2-name-owner", "Local-only-name-password", "Trà Sen QA")
    core = CoreSSOTService(repo)
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    return repo, core, owner, entity


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


def append_legacy_name(repo, owner, entity_id, value):
    """Append an invalid historic value with a real causal predecessor."""
    with repo.connection(write=True) as db:
        old = db.execute("SELECT assertion_id,version FROM v03_current_facts WHERE entity_id=? AND field='name'", (entity_id,)).fetchone()
        assertion, resolution, stamp = new_id("assertion"), new_id("resolution"), now_iso()
        db.execute("INSERT INTO v03_fact_assertions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
            assertion, owner["enterprise_id"], entity_id, "name", json_text(value), "string", "known",
            owner["account_id"], json_text({"kind": "synthetic_legacy"}), "self_declared", None, None, stamp, 0))
        db.execute("INSERT INTO v03_fact_resolutions VALUES(?,?,?,?,?,?,?,?,?,?,?)", (
            resolution, owner["enterprise_id"], entity_id, "name", assertion, old["assertion_id"],
            owner["account_id"], "supersede", "synthetic_legacy", "Synthetic pre-validation value", stamp))
        db.execute("UPDATE v03_current_facts SET assertion_id=?,resolution_id=?,version=? WHERE entity_id=? AND field='name'",
                   (assertion, resolution, old["version"] + 1, entity_id))
    return assertion


def test_invalid_current_name_is_display_only_and_not_an_ai_identity(case):
    repo, core, owner, entity = case
    bad = "x" * 251
    legacy_fact(repo, owner, entity["id"], "name", bad)
    before = data_snapshot(repo)
    view = repo.get_entity(*args(owner), entity["id"])
    assert view["name"] == "Trà Sen Tây Hồ"
    assert view["name_validation"]["code"] == "invalid_name"
    assert view["name_validation"]["display_only"] and not view["can_select_for_ai"]
    assert repo.get_context(*args(owner))["entities"] == []
    for read in (lambda: repo.get_context(*args(owner), [entity["id"]]),
                 lambda: core.get_context(*args(owner), [entity["id"]], save_snapshot=False)):
        with pytest.raises(CoreError) as error:
            read()
        assert error.value.code == "invalid_name"
    assert repo.get_fact_history(*args(owner), entity["id"])[0]["value"] == bad
    assert data_snapshot(repo) == before


def test_invalid_raw_row_has_generic_display_without_invented_known_name(case):
    repo, core, owner, entity = case
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET name=? WHERE id=?", ("y" * 251, entity["id"]))
    before = data_snapshot(repo)
    view = repo.get_entity(*args(owner), entity["id"])
    assert view["name"] == "Hồ sơ cần sửa tên" and not view["can_select_for_ai"]
    assert view["facts"] == [] and view["name_validation"]["display_only"]
    shared = core.list_entities(*args(owner))[0]
    assert shared["name"] == "Hồ sơ cần sửa tên" and not shared["can_select_for_ai"]
    assert data_snapshot(repo) == before


def test_paid_intake_and_research_stop_before_any_provider_for_invalid_selected_identity(case):
    repo, _core, owner, entity = case
    legacy_fact(repo, owner, entity["id"], "name", "z" * 251)
    calls = []

    async def forbidden(*values, **options):
        calls.append((values, options))
        pytest.fail("Invalid name must stop before provider or budget reservation")

    provider = V04ReviewProvider(repo, request_fn=forbidden)
    intake = LiveIntakeService(repo, provider=provider)
    chat = LiveConversationService(intake)
    research = LiveReviewMissionService(repo, model_call=forbidden)
    before = data_snapshot(repo)
    for command in (
        lambda: chat.send_async(*args(owner), "Chị cần đọc hồ sơ này", [], "invalid-name-paid-chat",
                                product_entity_id=entity["id"], paid_consent=True),
        lambda: research.prepare_async(*args(owner), "Chị cần nghiên cứu nhãn trà sen gửi Mỹ", "invalid-name-research",
                                        product_entity_id=entity["id"]),
    ):
        with pytest.raises(CoreError) as error:
            asyncio.run(command())
        assert error.value.code == "invalid_name"
    assert calls == [] and data_snapshot(repo) == before


@pytest.mark.parametrize("value", [False, ["Trà Sen"], {"name": "Trà Sen"}, "   "])
def test_invalid_name_types_do_not_leak_via_metadata_or_revive_a_prior_fact(case, value):
    repo, core, owner, entity = case
    previous = repo.propose_or_apply_facts(*args(owner), entity["id"], [{"field": "name", "value": "Trà Sen cũ"}], 0, "old-name")
    append_legacy_name(repo, owner, entity["id"], value)
    before = data_snapshot(repo)
    for view in (repo.get_entity(*args(owner), entity["id"]), core.list_entities(*args(owner))[0]):
        assert view["name"] == "Trà Sen cũ"
        assert view["name_validation"]["display_only"] and not view["can_select_for_ai"]
        assert all(fact["field"] != "name" for fact in view["facts"])
    # Lawful receipt READ remains possible, but it does not become current.
    assert repo.propose_or_apply_facts(*args(owner), entity["id"], [{"field": "name", "value": "Trà Sen cũ"}], 0, "old-name") == previous
    assert repo.get_context(*args(owner))["entities"] == []
    assert data_snapshot(repo) == before


def test_valid_current_assertion_can_ground_identity_with_invalid_legacy_row_without_repairing_sql(case):
    repo, core, owner, entity = case
    repo.propose_or_apply_facts(*args(owner), entity["id"], [{"field": "name", "value": "Trà Sen hiện hành"}], 0, "valid-name")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET name=? WHERE id=?", ("x" * 251, entity["id"]))
    before = data_snapshot(repo)
    for context in (repo.get_context(*args(owner), [entity["id"]]), core.get_context(*args(owner), [entity["id"]], save_snapshot=False)):
        item = context["entities"][0]
        assert item["name"] == item["values"]["name"] == "Trà Sen hiện hành"
        assert item["can_select_for_ai"] and not item["name_validation"]["display_only"]
    assert data_snapshot(repo) == before


def test_future_valid_name_is_not_current_and_does_not_fix_an_invalid_row(case):
    repo, core, owner, entity = case
    repo.propose_or_apply_facts(*args(owner), entity["id"],
        [{"field": "name", "value": "Tên tương lai", "valid_from": "2099-01-01"}], 0, "future-name")
    before = data_snapshot(repo)
    for context in (repo.get_context(*args(owner), [entity["id"]]), core.get_context(*args(owner), [entity["id"]], save_snapshot=False)):
        item = context["entities"][0]
        assert item["name"] == "Trà Sen Tây Hồ" and "name" not in item["values"] and item["can_select_for_ai"]
    assert data_snapshot(repo) == before
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET name='' WHERE id=?", (entity["id"],))
    bad = data_snapshot(repo)
    assert repo.get_entity(*args(owner), entity["id"])["name"] == "Hồ sơ cần sửa tên"
    assert repo.get_context(*args(owner))["entities"] == []
    assert data_snapshot(repo) == bad


def test_empty_new_profile_identity_and_explicit_owner_repair_remain_available(case):
    repo, core, owner, entity = case
    assert repo.get_context(*args(owner), [entity["id"]])["entities"][0]["can_select_for_ai"]
    bad_assertion = legacy_fact(repo, owner, entity["id"], "name", "x" * 251)
    proposal = core.propose_facts(*args(owner), entity["id"], [{"field": "name", "value": "Trà Sen đã sửa"}], 0, "repair-proposal")
    result = core.confirm_facts(*args(owner), proposal["proposal_id"], 0, "repair-confirm", proposal_hash=proposal["proposal_hash"])
    assert result["status"] == "confirmed"
    assert repo.get_entity(*args(owner), entity["id"])["can_select_for_ai"]
    assert repo.get_context(*args(owner), [entity["id"]])["entities"][0]["values"]["name"] == "Trà Sen đã sửa"
    assert any(item["id"] == bad_assertion and item["value"] == "x" * 251 for item in repo.get_fact_history(*args(owner), entity["id"]))


def test_aliases_and_read_grants_do_not_turn_invalid_name_into_ai_identity_or_leak_name_state(case):
    repo, core, owner, entity = case
    repo.propose_or_apply_facts(*args(owner), entity["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "quantity")
    staff = LocalAccounts(repo).register("r2-name-staff", "Local-only-name-password", "Riêng")
    core.add_member(*args(owner), staff["username"])
    core.grant_resource(*args(owner), entity["id"], staff["account_id"], ["read"], ["net_quantity"])
    legacy_fact(repo, owner, entity["id"], "name", "x" * 251)
    before = data_snapshot(repo)
    shared = core.list_entities(staff["account_id"], owner["enterprise_id"])[0]
    assert shared["name"] == "Hồ sơ được chia sẻ" and "name_validation" not in shared
    assert shared["values"] == {"net_quantity": "100 g"} and shared["validation_issues"] == []
    with repo.connection() as db:
        assert matching_owned_products(repo, *args(owner), "Trà Sen Tây Hồ", db) == []
    assert data_snapshot(repo) == before
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (entity["id"],))
    revoked = data_snapshot(repo)
    for command in (lambda: repo.get_entity(*args(owner), entity["id"]),
                    lambda: core.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]], save_snapshot=False)):
        with pytest.raises(CoreError) as error:
            command()
        assert error.value.code == "forbidden"
    assert data_snapshot(repo) == revoked


def test_unselected_invalid_product_does_not_remove_valid_other_context(case):
    repo, core, owner, entity = case
    legacy_fact(repo, owner, entity["id"], "name", "x" * 251)
    good = repo.create_entity(*args(owner), "product", "Mứt Sen sấy")
    before = data_snapshot(repo)
    broad = repo.get_context(*args(owner))
    assert [item["id"] for item in broad["entities"]] == [good["id"]]
    scoped = core.get_context(*args(owner), [good["id"]], save_snapshot=False)
    assert scoped["entities"][0]["name"] == "Mứt Sen sấy"
    assert data_snapshot(repo) == before
