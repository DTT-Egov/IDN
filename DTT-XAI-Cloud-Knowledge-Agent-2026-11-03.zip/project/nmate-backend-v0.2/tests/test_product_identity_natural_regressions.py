"""Natural owner declarations and paid identity guards, with injected transport only."""
import copy
import json
import unicodedata

import pytest

from nmate.v03.core import CoreError
from nmate.v04.dialogue import interpret
from nmate.v04.extraction import extract_product_text, product_name_key
from nmate.v04.product_binding import product_scope, declared_product_name
from test_unified_main import setup as setup, scope
from test_v04_intake import confirm
from test_v03_live_review import intake as export_intake
from test_v04_live_review import result


NATURAL = "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSW01. Chị muốn đi Mỹ, cần FDA, nhãn và ba việc đầu tiên?"


def test_natural_declaration_keeps_owner_case_and_distinct_packaging_weight():
    facts = extract_product_text(NATURAL)
    values = {fact["field"]: fact["value"] for fact in facts}
    assert values == {"name": "Trà sen Tây Hồ ướp bông", "product_code": "TSW01", "packaging": "hộp", "net_quantity": "100 g"}
    for fact in facts:
        source = fact["source"]
        assert source["quote"] in NATURAL and source["value_quote"] in source["quote"]
        assert NATURAL[source["start_offset"]:source["end_offset"]].strip() == source["quote"]
        assert source["review_state"] == "owner_confirmation_required"


@pytest.mark.parametrize("text", ["Cơ sở chị bán khoảng 300 hộp trà mỗi tháng", "Chị bán 300 hộp trà mỗi tháng.",
    "Mỗi tháng chị bán khoảng 300 hộp trà", "Bán khoảng 300 hộp trà mỗi tuần", "Bán 50 túi bột mỗi ngày"])
def test_sales_rates_are_not_product_identity(text):
    assert not any(fact["field"] == "name" for fact in extract_product_text(text))


def test_explicit_packaging_with_weight_is_split_without_inventing_material():
    facts = extract_product_text("Tên sản phẩm: Mứt Sen Sấy; bao bì: hộp 200 g; mã MS01")
    assert {fact["field"]: fact["value"] for fact in facts} == {
        "name": "Mứt Sen Sấy", "packaging": "hộp", "product_code": "MS01", "net_quantity": "200 g"}


@pytest.mark.parametrize("text", ["muốn đi Mỹ", "Chị muốn đi Mỹ", "muốn sang Nhật", "Mỹ"])
def test_selected_export_task_retains_destination_intent(text):
    intent = interpret(text, task_hint="export_research")
    assert intent["primary"] == "export_readiness"
    assert intent["market_codes"] == (["JP"] if "Nhật" in text else ["US"])


@pytest.mark.parametrize("name", ["mứt sen sấy", " MỨT  SEN  SẤY ", unicodedata.normalize("NFD", "Mứt Sen Sấy")])
def test_presentation_equivalent_names_resolve_exactly_without_ssot_mutation(setup, name):
    repo, owner, _, model, _, _, intake, chats = setup
    pending = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Mứt Sen Sấy", "create-jam")
    saved = confirm(intake, owner, pending["intake"])
    pid = saved["product"]["id"]
    before = copy.deepcopy(repo.get_context(*scope(owner)))
    with repo.connection() as db:
        chosen, binding = product_scope(intake, *scope(owner), "Tên sản phẩm: " + name + "; muốn đi Mỹ", db, pid)
    assert chosen == pid and binding["confirmed"] is True
    assert product_name_key(name) == product_name_key("Mứt Sen Sấy")
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    assert model.calls == []


@pytest.mark.asyncio
async def test_longer_name_cannot_bind_saved_prefix_on_paid_or_direct_mcp_path(setup):
    repo, owner, _, model, provider, missions, intake, chats = setup
    pending = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Trà Sen Tây Hồ", "create-tea")
    saved = confirm(intake, owner, pending["intake"])
    pid = saved["product"]["id"]
    question = "Chị muốn xuất khẩu Trà Sen Tây Hồ Cao Cấp đi Mỹ cần nhãn thế nào?"
    with pytest.raises(CoreError) as error:
        await chats.send_async(*scope(owner), question, [], "wrong-paid-identity", product_entity_id=pid,
            paid_consent=True, task_hint="export_research", market_code="US")
    assert error.value.code == "product_confirmation_required"
    with pytest.raises(CoreError) as direct:
        await missions.prepare_async(*scope(owner), question, "wrong-direct-identity", pid, market_code="US")
    assert direct.value.code == "product_confirmation_required"
    assert model.calls == [] and provider.summary()["paid_calls"] == 0
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM main_operations").fetchone()[0] == 0


@pytest.mark.asyncio
async def test_paid_case_variant_jam_uses_exact_dossier_and_original_receipt(setup):
    repo, owner, _, model, provider, _, intake, chats = setup
    pending = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Mứt Sen Sấy; hộp 200 g", "create-jam-paid")
    saved = confirm(intake, owner, pending["intake"])
    pid = saved["product"]["id"]
    question = "Mứt sen sấy 200 g, 300 hộp đi Los Angeles: thông báo trước (prior notice) với FDA thì ai nộp, nộp khi nào và cần những thông tin gì? (THỬ NGHIỆM)"
    calls = []

    async def local_transport(model_name, payload, limit):
        calls.append(payload)
        value = export_intake()
        value.update(product_name="mứt sen sấy", product_quote="Mứt sen sấy", outcomes=[{"id": "prior_notice", "question_quote": "prior notice"}])
        return {"text": json.dumps(value, ensure_ascii=False), "model": model_name, "request_id": "local-jam-case",
                "stop_reason": "end_turn", "usage": {"input_tokens": 5, "output_tokens": 5}}

    provider._request_override = local_transport
    sent = await chats.send_async(*scope(owner), question, [], "jam-case-paid", product_entity_id=pid,
        paid_consent=True, task_hint="export_research", market_code="US")
    mission = sent["missions"][0]
    assert mission["product"]["entity_id"] == pid and not mission.get("binding_warning")
    assert mission["status"] == "planned"
    assert len(calls) == sent["cost"]["paid_calls"] == 1
    assert repo.get_entity(*scope(owner), pid)["name"] == "Mứt Sen Sấy"
    user = [message for message in sent["messages"] if message["role"] == "user"]
    assert len(user) == 1 and user[0]["text"] == question
    with repo.connection() as db:
        receipt = json.loads(db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0])
        assert receipt["data"]["product_name"] == "mứt sen sấy"


def test_natural_main_draft_round_trip_has_real_candidates_and_no_provider(setup):
    repo, owner, _, model, _, _, _, chats = setup
    model.fail = True
    initial = chats.prepare_chat_draft(*scope(owner), NATURAL, "natural-free", task_hint="export_research")
    item = initial["intake"]
    assert {fact["field"]: fact["value"] for fact in item["candidates"]} == {
        "name": "Trà sen Tây Hồ ướp bông", "product_code": "TSW01", "packaging": "hộp", "net_quantity": "100 g"}
    restored = chats.get(*scope(owner), initial["id"])
    assert restored["intake"]["candidates"] == item["candidates"]
    assert restored["task_hint"] == "export_research" and model.calls == []
    assert repo.get_context(*scope(owner))["fact_refs"] == []


def test_free_short_export_message_uses_selected_task_and_does_not_ask_four_goals(setup):
    _, owner, _, model, _, _, _, chats = setup
    sent = chats.prepare_chat_draft(*scope(owner), "Mỹ", "short-task-market", task_hint="export_research")
    assert sent["intake"]["intent"]["primary"] == "export_readiness"
    assert sent["intake"]["intent"]["market_codes"] == ["US"]
    assert not any("số hóa vận hành" in question for question in sent["intake"]["questions"])
    assert model.calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("task", ["profile_intake", "export_research"])
async def test_failed_paid_submission_survives_reload_and_operation_replay_once(setup, task):
    repo, owner, _, model, _, _, intake, chats = setup
    pending = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Trà Sen Tây Hồ", "failure-tea")
    pid = confirm(intake, owner, pending["intake"])["product"]["id"]
    question = "Chị muốn xuất khẩu Trà Sen Tây Hồ đi Mỹ cần nhãn thế nào?" if task == "export_research" else "Chị cần kiểm kê tồn kho Trà Sen Tây Hồ hôm nay."
    model.fail = True
    options = {"task_hint": task, "paid_consent": True, "product_entity_id": pid}
    if task == "export_research":
        options["market_code"] = "US"
    with pytest.raises(CoreError):
        await chats.send_async(*scope(owner), question, [], "durable-failed-question", **options)
    row = next(row for row in chats.list(*scope(owner))
               if (row.get("operation_error") or {}).get("operation_id") == "durable-failed-question")
    loaded = chats.get(*scope(owner), row["id"])
    users = [message for message in loaded["messages"] if message["role"] == "user"]
    assert len(users) == 1 and users[0]["text"] == question and users[0]["operation_id"] == "durable-failed-question"
    before = len(model.calls)
    with pytest.raises(CoreError):
        await chats.send_async(*scope(owner), question, [], "durable-failed-question", **options)
    assert len(model.calls) == before == 1
    assert [message for message in chats.get(*scope(owner), row["id"])["messages"] if message["role"] == "user"] == users


@pytest.mark.asyncio
async def test_successful_profile_submission_appears_once_after_model_validation(setup):
    _, owner, _, model, _, _, _, chats = setup
    question = "Chị muốn giảm sai lệch tồn kho."
    sent = await chats.send_async(*scope(owner), question, [], "durable-success-question", task_hint="sales_inventory", paid_consent=True)
    assert len(model.calls) == 1
    users = [message for message in sent["messages"] if message["role"] == "user"]
    assert len(users) == 1 and users[0]["text"] == question and users[0].get("intake_id")


@pytest.mark.asyncio
async def test_paid_natural_declaration_generates_owner_candidates_not_a_dead_end(setup):
    repo, owner, _, _, provider, _, _, chats = setup
    calls = []

    async def local_transport(model_name, payload, limit):
        calls.append(payload)
        value = result(NATURAL, primary="export_readiness", market_codes=["US"],
            assistant_text="Mình giữ dữ kiện sản phẩm của chị để xác nhận; lượt này chưa nghiên cứu FDA hay nhãn.",
            pending_question=None, next_steps=["Chị xác nhận dữ kiện muốn ghi nhớ trước khi lập kế hoạch nghiên cứu."], actions=[])
        return {"text": json.dumps(value, ensure_ascii=False), "model": model_name, "request_id": "local-natural-text",
                "stop_reason": "end_turn", "usage": {"input_tokens": 5, "output_tokens": 5}}

    provider._request_override = local_transport
    sent = await chats.send_async(*scope(owner), NATURAL, [], "natural-paid-route", paid_consent=True, task_hint="profile_intake")
    assert {fact["field"]: fact["value"] for fact in sent["intake"]["candidates"]} == {
        "name": "Trà sen Tây Hồ ướp bông", "product_code": "TSW01", "packaging": "hộp", "net_quantity": "100 g"}
    assert sent["intake"]["status"] == "awaiting_confirmation"
    assert len(calls) == 1 and not repo.get_context(*scope(owner))["fact_refs"]
    assert "chị" in sent["intake"]["summary"] and "bạn" not in sent["intake"]["summary"]


def test_equivalent_name_observation_does_not_ask_owner_to_rename_product(setup):
    repo, owner, _, model, _, _, intake, chats = setup
    pending = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Mứt Sen Sấy", "preserve-canonical-name")
    pid = confirm(intake, owner, pending["intake"])["product"]["id"]
    next_chat = chats.prepare_chat_draft(*scope(owner), "Chị muốn xuất khẩu mứt sen sấy đi Mỹ", "same-name-case", product_entity_id=pid)
    candidate = next(fact for fact in next_chat["intake"]["candidates"] if fact["field"] == "name")
    assert candidate["status"] == "already_known" and candidate.get("conflict") is None
    assert candidate["value"] == "mứt sen sấy" and candidate["current_value"] == "Mứt Sen Sấy"
    assert repo.get_entity(*scope(owner), pid)["name"] == "Mứt Sen Sấy" and model.calls == []


@pytest.mark.parametrize("quantity", ["200 g", "100g", "1 kg", "25,5 g", "300 hộp"])
def test_multi_digit_quantity_is_not_part_of_declared_product_name(quantity):
    question = "Mứt sen sấy " + quantity + ", 300 hộp đi Los Angeles: thông báo trước (prior notice) với FDA thì ai nộp, nộp khi nào và cần những thông tin gì? (THỬ NGHIỆM)"
    assert declared_product_name(question) == "Mứt sen sấy"


def test_product_year_is_not_misread_as_quantity():
    assert declared_product_name("Tên sản phẩm: Trà Sen 2026; mã TS26") == "Trà Sen 2026"


REALISTIC_OWNER_INTRO = "Chào em, chị là chủ Cơ sở Trà sen Quảng An ở Tây Hồ, Hà Nội (THỬ NGHIỆM). Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TEST-TRASEN-100-001, muốn gửi thử 500 hộp sang New York qua một nhà nhập khẩu. Chị cần biết có phải đăng ký cơ sở với FDA không, nhãn hộp cần ghi những gì, và ba việc đầu tiên nên làm."


def test_business_intro_is_not_a_second_food_product_in_full_natural_question():
    facts = extract_product_text(REALISTIC_OWNER_INTRO)
    assert {fact["field"]: fact["value"] for fact in facts} == {
        "name": "Trà sen Tây Hồ ướp bông", "product_code": "TEST-TRASEN-100-001", "packaging": "hộp", "net_quantity": "100 g"}
    assert all(fact["source"]["quote"] in REALISTIC_OWNER_INTRO for fact in facts)


def test_business_intro_natural_question_on_main_draft_has_confirmation_path(setup):
    _, owner, _, model, _, _, _, chats = setup
    model.fail = True
    sent = chats.prepare_chat_draft(*scope(owner), REALISTIC_OWNER_INTRO, "full-natural-intro", task_hint="export_research")
    assert sent["intake"]["status"] == "awaiting_confirmation"
    assert len(sent["intake"]["candidates"]) == 5 and sent["intake"]["product"]["name"] == "Trà sen Tây Hồ ướp bông"
    company = next(c for c in sent["intake"]["candidates"] if c["entity_type"] == "enterprise")
    assert company["field"] == "trading_name" and company["value"] == "Trà sen Quảng An"
    assert model.calls == []
