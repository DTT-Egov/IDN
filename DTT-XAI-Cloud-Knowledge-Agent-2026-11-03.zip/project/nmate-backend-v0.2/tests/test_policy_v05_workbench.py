"""TDD contracts for policy drafts: private, durable and never legal approval."""
from concurrent.futures import ThreadPoolExecutor
import json

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.policy_v05.workbench import PolicyWorkbench
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def scope(tmp_path):
    path = tmp_path / "policy05.sqlite"
    repo = CoreRepository(path)
    accounts = LocalAccounts(repo)
    owner = accounts.register("policy05-owner", "Private-test-12345", "Cơ sở Trà Sen")
    stranger = accounts.register("policy05-other", "Private-test-12345", "Cơ sở khác")
    core = CoreSSOTService(repo)
    company = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Hộ Trà Sen Hà Nội')
    product = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'product', 'Trà Sen Tây Hồ')
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'], [
        {'field': 'name', 'value': 'Hộ Trà Sen Hà Nội'},
        {'field': 'legal_form', 'value': 'Hộ kinh doanh'},
        {'field': 'province', 'value': 'Hà Nội'},
    ], 0, 'seed-company')
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], product['id'], [
        {'field': 'name', 'value': 'Trà Sen Tây Hồ'}, {'field': 'net_quantity', 'value': '100 g'},
    ], 0, 'seed-product')
    service = PolicyWorkbench(repo, core=core)
    return path, repo, core, service, owner, stranger, company, product


def create(scope, **kwargs):
    _, _, _, service, owner, _, _, product = scope
    return service.create_draft(owner['account_id'], owner['enterprise_id'],
        'Chị muốn hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách.',
        'participation_request', kwargs.pop('operation_id', 'create-draft'), product_entity_id=kwargs.pop('product_entity_id', product['id']), **kwargs)


def approve(scope, draft, **kwargs):
    _, _, _, service, owner, *_ = scope
    return service.approve_draft(owner['account_id'], owner['enterprise_id'], draft['id'],
        draft['version'], draft['content_hash'], True, kwargs.pop('operation_id', 'approve-draft'), **kwargs)


def test_guidance_retains_both_needs_and_never_claims_programme_open(scope):
    draft = create(scope)
    assert draft['requested_kind'] == 'participation_request'
    assert draft['kind'] == 'request_guidance'
    assert {need['need_id'] for need in draft['needs']} == {'market_development', 'workforce_training'}
    assert all(need['status'] == 'needs_verification' for need in draft['needs'])
    assert draft['program_readiness']['application_open'] is None
    assert draft['program_readiness']['eligibility'] == 'not_assessed'
    assert draft['provider_calls'] == 0
    assert draft['sharing']['publication'] == 'unknown'


def test_enterprise_summary_uses_enterprise_not_product_legal_identity(scope):
    draft = create(scope)
    assert 'Hộ Trà Sen Hà Nội' in draft['body']['enterprise_summary']
    assert 'Hộ kinh doanh' in draft['body']['enterprise_summary']
    assert '100 g' not in draft['body']['enterprise_summary']
    assert draft['context_manifest']['enterprise_entity_id'] == scope[6]['id']
    assert draft['context_manifest']['product_entity_id'] == scope[7]['id']
    assert scope[7]['id'] != scope[6]['id']


def test_product_cannot_be_passed_as_enterprise_identity(scope):
    with pytest.raises(CoreError) as exc:
        create(scope, enterprise_entity_id=scope[7]['id'])
    assert exc.value.code == 'invalid_enterprise_entity'


def test_multiple_company_profiles_need_explicit_choice(scope):
    _, repo, _, _, owner, *_ = scope
    repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở phụ')
    with pytest.raises(CoreError) as exc:
        create(scope)
    assert exc.value.code == 'enterprise_entity_required'
    assert create(scope, enterprise_entity_id=scope[6]['id'])['version'] == 1


def test_create_replay_freezes_implicit_binding_and_is_read_only(scope):
    draft = create(scope)
    _, repo, core, service, owner, *_ = scope
    repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở mới sau nháp')
    # Implicit defaults are not rebuilt on exact receipt replay (DF-046).
    before = table_counts(repo)
    assert create(scope) == draft
    assert table_counts(repo) == before
    assert service.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])['content_hash'] == draft['content_hash']


def table_counts(repo):
    with repo.connection() as db:
        return {name: db.execute('SELECT COUNT(*) FROM ' + name).fetchone()[0]
                for name in ['pol05_drafts', 'pol05_revisions', 'pol05_approvals', 'v03_operations', 'v03_fact_assertions']}


def test_idempotency_conflict_does_not_create_second_draft(scope):
    draft = create(scope)
    _, _, _, service, owner, *_ = scope
    with pytest.raises(CoreError) as exc:
        service.create_draft(owner['account_id'], owner['enterprise_id'], 'Khác câu hỏi', 'business_petition', 'create-draft')
    assert exc.value.code == 'idempotency_conflict'
    assert len(service.list_drafts(owner['account_id'], owner['enterprise_id'])) == 1
    assert draft['id']


def test_persistence_and_tenant_separation(scope):
    draft = create(scope)
    path, _, _, _, owner, stranger, *_ = scope
    reloaded = PolicyWorkbench(CoreRepository(path))
    assert reloaded.get_draft(owner['account_id'], owner['enterprise_id'], draft['id']) == draft
    assert reloaded.list_drafts(stranger['account_id'], stranger['enterprise_id']) == []
    with pytest.raises(CoreError):
        reloaded.get_draft(stranger['account_id'], stranger['enterprise_id'], draft['id'])
    with pytest.raises(CoreError):
        reloaded.get_draft(stranger['account_id'], owner['enterprise_id'], draft['id'])


def test_cas_and_exact_content_owner_approval_are_separate_from_ssot(scope):
    draft = create(scope)
    _, repo, _, service, owner, *_ = scope
    before = table_counts(repo)['v03_fact_assertions']
    with pytest.raises(CoreError) as exc:
        service.approve_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, 'wrong-hash', True, 'wrong-approval')
    assert exc.value.code == 'content_conflict'
    approved = approve(scope, draft)
    assert approved['approval']['approved_version'] == 1
    assert approved['approval']['authorizes_external_send'] is False
    assert approved['approval']['type'] == 'draft_content_only'
    assert approved['status'] == 'approved'
    assert table_counts(repo)['v03_fact_assertions'] == before
    edited = service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1,
                                 {'request': 'Đề nghị có lớp buổi tối.'}, 'edit-request')
    assert edited['version'] == 2 and edited['status'] == 'draft' and edited['approval'] is None
    assert edited['previous_approval_id'] == approved['approval']['approval_id']
    with pytest.raises(CoreError) as exc:
        service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, {'request': 'Khác'}, 'stale-edit')
    assert exc.value.code == 'version_conflict'


def test_edit_replay_returns_exact_receipt_after_later_edit(scope):
    draft = create(scope)
    _, _, _, service, owner, *_ = scope
    first = service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, {'impact': 'Hai nhân viên cần học.'}, 'edit1')
    service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 2, {'request': 'Lớp buổi tối'}, 'edit2')
    replay = service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, {'impact': 'Hai nhân viên cần học.'}, 'edit1')
    assert replay == first and replay['version'] == 2


def test_approval_replay_requires_read_but_not_current_owner_write(scope):
    draft = create(scope)
    approved = approve(scope, draft)
    _, repo, core, _, owner, *_ = scope
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?", (owner['account_id'], owner['enterprise_id']))
    for entity in [scope[6], scope[7]]:
        # Explicit READ survives role change, but no WRITE authority is invented.
        with repo.connection(write=True) as db:
            db.execute("INSERT INTO core_v1_resources VALUES(?,?, 'ssot_entity',?,1,datetime('now'))", (owner['enterprise_id'], entity['id'], owner['account_id']))
            db.execute("INSERT INTO core_v1_grants VALUES(?,?,?,'read','*',?,datetime('now'),NULL)", (owner['enterprise_id'], entity['id'], owner['account_id'], owner['account_id']))
    assert approve(scope, draft) == approved
    with pytest.raises(CoreError) as exc:
        approve(scope, draft, operation_id='new-approval')
    assert exc.value.status_code == 403


def test_revoked_original_input_blocks_get_list_export_and_replay(scope):
    draft = create(scope)
    _, repo, _, service, owner, _, company, _ = scope
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (company['id'],))
    for read in [lambda: service.get_draft(owner['account_id'], owner['enterprise_id'], draft['id']),
                 lambda: create(scope), lambda: service.export_payload(owner['account_id'], owner['enterprise_id'], draft['id'])]:
        with pytest.raises(CoreError) as exc:
            read()
        assert exc.value.status_code == 403
    assert service.list_drafts(owner['account_id'], owner['enterprise_id']) == []


def test_archive_does_not_revoke_history_but_blocks_new_approval(scope):
    draft = create(scope)
    _, repo, _, service, owner, _, _, product = scope
    # Existing repository lifecycle command is product-only, not a company API.
    current = repo.get_entity(owner['account_id'], owner['enterprise_id'], product['id'])
    repo.archive_entity(owner['account_id'], owner['enterprise_id'], product['id'], current['version'], 'archive-product')
    saved = service.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])
    assert saved['id'] == draft['id'] and saved['is_historical']
    assert saved['current_warnings_vi']
    assert create(scope) == draft
    with pytest.raises(CoreError) as exc:
        approve(scope, draft)
    assert exc.value.code == 'entity_archived'


def test_concurrent_same_create_has_one_durable_receipt(scope):
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: create(scope), range(2)))
    assert results[0] == results[1]
    assert table_counts(scope[1])['pol05_drafts'] == 1


def test_conversation_must_belong_to_actor_and_atomic_callback_rolls_back(scope):
    _, repo, _, service, owner, *_ = scope
    def fail(db, payload):
        db.execute('CREATE TABLE callback_side_effect(id TEXT)')
        db.execute('INSERT INTO callback_side_effect VALUES(?)', ('rolled-back',))
        raise CoreError('callback_failure', 'Tình huống kiểm thử')
    with pytest.raises(CoreError):
        create(scope, on_commit=fail)
    assert table_counts(repo)['pol05_drafts'] == 0
    with repo.connection() as db:
        assert db.execute("SELECT 1 FROM sqlite_master WHERE name='callback_side_effect'").fetchone() is None
    with pytest.raises(CoreError):
        create(scope, conversation_id='foreign-conversation')


def test_unsupported_question_and_complaint_are_not_silently_petitions(scope):
    service, owner = scope[3], scope[4]
    for question in ['Ngày mai thời tiết thế nào?', 'Chị muốn tố cáo một cán bộ']:
        with pytest.raises(CoreError) as exc:
            service.create_draft(owner['account_id'], owner['enterprise_id'], question, 'business_petition', 'unsupported-' + question)
        assert exc.value.code == 'unsupported_policy_request'


def test_body_schema_rejects_eligibility_status_and_unknown_fields(scope):
    draft = create(scope)
    service, owner = scope[3], scope[4]
    for patch in [{'eligibility': 'approved'}, {'request': 42}, {'request': ''}, {'situation': 'x' * 6001}]:
        with pytest.raises(CoreError):
            service.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, patch, 'bad-' + str(len(json.dumps(patch))))
    assert service.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])['version'] == 1


def test_context_changes_block_new_approval_without_rewriting_draft(scope):
    draft = create(scope)
    _, repo, _, service, owner, _, company, _ = scope
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'], [{'field': 'province', 'value': 'Hải Phòng'}], 1, 'company-changed')
    with pytest.raises(CoreError) as exc:
        approve(scope, draft)
    assert exc.value.code == 'context_changed'
    saved = service.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])
    assert saved['content_hash'] == draft['content_hash']
    assert saved['body'] == draft['body']
    assert saved['is_historical'] and saved['current_warnings_vi']
    assert service.export_payload(owner['account_id'], owner['enterprise_id'], draft['id'])['is_historical']
    # Exact command receipt keeps original bytes; current view is separate.
    assert create(scope) == draft
    with repo.connection() as db:
        assert 'is_historical' not in json.loads(db.execute('SELECT payload_json FROM pol05_drafts WHERE id=?', (draft['id'],)).fetchone()[0])


def test_approval_requires_explicit_consent_and_pdf_remains_free(scope):
    draft = create(scope)
    service, owner = scope[3], scope[4]
    with pytest.raises(CoreError) as exc:
        service.approve_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1, draft['content_hash'], False, 'no-consent')
    assert exc.value.code == 'sharing_consent_required'
    payload = service.export_payload(owner['account_id'], owner['enterprise_id'], draft['id'])
    assert payload['draft_id'] == draft['id']
    assert payload['watermark_vi'] == 'BẢN NHÁP — CHƯA GỬI'
    assert payload['provider_calls'] == 0


def test_revision_and_approval_rows_are_immutable(scope):
    import sqlite3
    draft = create(scope)
    approve(scope, draft)
    for table in ['pol05_revisions', 'pol05_approvals']:
        with pytest.raises(sqlite3.IntegrityError):
            with scope[1].connection(write=True) as db:
                db.execute('DELETE FROM ' + table)


def test_policy_case_product_binding_cannot_be_overridden_by_current_picker(scope):
    _, repo, _, service, owner, _, company, product = scope
    other_product = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'product', 'Mứt sen sấy')
    class CaseService:
        def get(self, account, enterprise, identity):
            return {'id': identity, 'conversation_id': None, 'context': {'entities': [company, product]}}
    service.policy = CaseService()
    with pytest.raises(CoreError) as exc:
        create(scope, policy_case_id='same-account-case', product_entity_id=other_product['id'])
    assert exc.value.code == 'context_scope_conflict'
    derived = service.create_draft(owner['account_id'], owner['enterprise_id'], 'Đào tạo nhân viên',
        'participation_request', 'derive-product', policy_case_id='same-account-case')
    assert derived['context_manifest']['product_entity_id'] == product['id']


def test_same_owner_policy_case_and_conversation_are_not_interchangeable(scope):
    _, repo, _, service, owner, _, company, product = scope
    with repo.connection(write=True) as db:
        db.execute('CREATE TABLE v04_conversations(id TEXT PRIMARY KEY,enterprise_id TEXT,owner_id TEXT)')
        db.executemany('INSERT INTO v04_conversations VALUES(?,?,?)', [
            ('conversation-a', owner['enterprise_id'], owner['account_id']),
            ('conversation-b', owner['enterprise_id'], owner['account_id'])])
    class CaseService:
        def get(self, account, enterprise, identity):
            return {'id': identity, 'conversation_id': 'conversation-a', 'context': {'entities': [company, product]}}
    service.policy = CaseService()
    with pytest.raises(CoreError) as exc:
        create(scope, policy_case_id='case-a', conversation_id='conversation-b')
    assert exc.value.code == 'context_scope_conflict'
    derived = create(scope, operation_id='derive-conversation', policy_case_id='case-a')
    assert derived['conversation_id'] == 'conversation-a'


@pytest.mark.parametrize('kind', ['participation_request', 'business_petition'])
def test_document_has_raw_statement_once_and_never_invents_event_or_impact(scope, kind):
    service, owner = scope[3], scope[4]
    question = 'Chị muốn đào tạo nhân viên sổ sách, có lớp buổi tối thì tốt.'
    draft = service.create_draft(owner['account_id'], owner['enterprise_id'], question, kind, 'structured-document')
    body = draft['body']
    assert sum(value.count(question) for value in body.values()) == 1
    assert body['situation'] == question
    assert body['requested_support'] == 'Đào tạo nhân viên'
    assert body['impact'] == ''
    assert 'Đề nghị' in body['request']
    assert 'thiệt hại' not in body['request']
    assert 'được hỗ trợ' not in body['request']


def test_write_guard_never_runs_for_exact_receipt_replay(scope):
    draft = create(scope)
    service = scope[3]
    calls = []
    def archive_guard(db, account, enterprise, payload):
        calls.append(payload['id'])
        raise CoreError('conversation_archived', 'Cuộc trao đổi đã cất.', 409)
    service.before_write = archive_guard
    assert create(scope) == draft
    assert calls == []
    with pytest.raises(CoreError) as exc:
        service.update_draft(scope[4]['account_id'], scope[4]['enterprise_id'], draft['id'], 1, {'request': 'Nội dung mới'}, 'new-edit')
    assert exc.value.code == 'conversation_archived'
    assert calls == [draft['id']]


def test_empty_profile_display_name_does_not_become_confirmed_legal_identity(scope):
    _, repo, _, service, owner, *_ = scope
    empty = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở mới tự đặt tên')
    draft = create(scope, enterprise_entity_id=empty['id'])
    summary = draft['body']['enterprise_summary']
    assert 'Hồ sơ cơ sở: Cơ sở mới tự đặt tên' in summary
    assert 'Tên cơ sở/pháp lý chưa có dữ kiện xác nhận' in summary
    assert 'Loại hình pháp lý chưa có dữ kiện xác nhận' in summary
    assert 'doanh nghiệp nhỏ' not in summary.lower()
    refs = [ref for ref in draft['context_manifest']['fact_refs'] if ref['entity_id'] == empty['id']]
    assert all(ref['assertion_id'] is None for ref in refs)
