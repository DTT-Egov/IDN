from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import socket
from unittest.mock import AsyncMock

import httpx
import pytest
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver

from nmate.agents.shipment import ShipmentReport, ShipmentWorkflowError, build_graph
from nmate.agents.shipment.models import SourceBatch, SourceDocument, SourceFailure
from nmate.agents.shipment.sources import (
    SOURCE_CATALOG,
    OfficialSourceProvider,
    SourceRetrievalError,
    parse_document,
    validate_public_dns,
    validate_url,
)
from nmate.model_provider import (
    ANTHROPIC_API_BASE,
    OPENAI_API_BASE,
    ModelProviderError,
    create_chat_model,
)


def sample_case():
    return {
        "case_id": "MOCK-CASE-01", "version": 1,
        "product": {
            "sku": "MOCK-SKU-01", "name": "MOCK miến dong khô", "family": "dry_food",
            "ingredients": None, "processing_description": None, "packaging": None,
            "shelf_life": None, "certifications": None, "origin_country": "VN",
        },
        "shipment": {
            "target_market": "US", "route": "importer", "quantity_units": None,
            "carton_count": None, "gross_weight_kg": None, "carton_dimensions_cm": None,
            "pickup_location": None, "destination": None, "incoterm": None,
            "importer_of_record": None, "fsvp_importer": None,
        },
        "consent_research": True, "consent_model": False,
    }


def batch_without_cbp():
    texts = {
        "fda_import": "MOCK official-source fixture.\nImport procedures include prior notice for review.\n"
        + "MOCK source content used only to exercise the retrieval contract. " * 8,
        "fda_fsvp": "MOCK official-source fixture.\nThe U.S. owner or consignee is described for FSVP purposes.\n"
        + "MOCK foreign supplier verification context, not a legal opinion. " * 8,
    }
    return SourceBatch(
        sources=[
            SourceDocument(
                id=spec.id, url=spec.url, title="MOCK " + spec.title, publisher="MOCK " + spec.publisher,
                accessed_at="2026-10-17T09:00:00+00:00", source_date=None,
                content_sha256=hashlib.sha256(texts[spec.id].encode()).hexdigest(), text=texts[spec.id],
            )
            for spec in SOURCE_CATALOG if spec.id in texts
        ],
        failures=[SourceFailure(
            source_id="cbp_import", url=SOURCE_CATALOG[2].url,
            code="HTTP_403", detail="MOCK source blocked",
        )],
    )


class MockProvider:
    def __init__(self, batch=None):
        self.calls = 0
        self.batch = batch if batch is not None else batch_without_cbp()

    async def fetch_all(self):
        self.calls += 1
        return self.batch


def mock_unavailable_translations(messages):
    """Old summary-only collaborators explicitly decline translation, never fake it."""
    payload = json.loads(messages[1][1])
    return [{"evidence_id": row["id"], "original_excerpt_sha256": row["original_excerpt_sha256"],
             "status": "unavailable", "title_vi": None, "excerpt_vi": None, "publisher_vi": None}
            for row in payload["evidence_candidates"]]


async def run_graph(case=None, provider=None, **kwargs):
    provider = provider or MockProvider()
    graph = build_graph(InMemorySaver(), source_provider=provider, **kwargs)
    config = {"configurable": {"thread_id": "MOCK-RUN-01"}}
    nodes = []
    async for update in graph.astream({"case": case or sample_case(), "question": "MOCK cần làm rõ gì?"},
                                     config=config, stream_mode="updates"):
        nodes.extend(update)
    state = await graph.aget_state(config)
    return ShipmentReport.model_validate(state.values["report"]), nodes, provider


async def test_evidence_only_is_real_graph_and_never_claims_llm_or_shipping_approval():
    report, nodes, provider = await run_graph()
    assert nodes == ["validate_scope", "fetch_sources", "assess_preparation", "validate_report"]
    assert provider.calls == 1
    assert report.kind == "shipment_readiness" and report.mode == "evidence_only" and not report.llm_used
    assert report.readiness_status == "evidence_incomplete"
    assert 1 <= len(report.next_steps) <= 3
    assert all(e.review_status == "candidate" for e in report.evidence)
    assert report.unknowns and report.source_failures[0].code == "HTTP_403"
    assert any("không sử dụng LLM" in warning for warning in report.warnings)
    assert all(r.status == "unknown" for r in report.responsibilities)


async def test_fsvp_never_inherited_from_ior_and_supplied_facts_stay_unverified():
    case = sample_case()
    case["shipment"]["importer_of_record"] = "MOCK importer"
    report, _, _ = await run_graph(case)
    roles = {item.role: item for item in report.responsibilities}
    assert roles["importer_of_record"].party == "MOCK importer"
    assert roles["importer_of_record"].status == "provided_unverified"
    assert roles["fsvp_importer"].party is None and roles["fsvp_importer"].status == "unknown"
    case["shipment"]["fsvp_importer"] = "MOCK importer"
    report, _, _ = await run_graph(case)
    assert all(r.status != "verified" for r in report.responsibilities)
    assert {r.role for r in report.responsibilities} == {"importer_of_record", "fsvp_importer", "supplier_exporter"}


async def test_blocked_cbp_has_no_fabricated_citation_or_ior_official_finding():
    report, _, _ = await run_graph()
    blocked = report.source_failures[0]
    assert blocked.source_id == "cbp_import" and blocked.code == "HTTP_403"
    assert blocked.detail.startswith("CBP — Cơ quan Hải quan và Bảo vệ Biên giới Hoa Kỳ:")
    assert "MOCK source blocked" not in blocked.detail
    assert all("cbp.gov" not in e.url for e in report.evidence)
    assert "ior_responsibility" not in {f.id for f in report.findings}
    ior = next(r for r in report.responsibilities if r.role == "importer_of_record")
    assert ior.evidence_ids == []
    known = {item.id for item in report.evidence}
    assert all(set(item.evidence_ids) <= known for item in [*report.findings, *report.next_steps, *report.responsibilities])
    assert all(item.value is None for item in report.quote_information)


async def test_out_of_scope_never_fetches_or_relabels_us_evidence():
    case, provider = sample_case(), MockProvider()
    case["shipment"]["target_market"] = "EU"
    report, nodes, _ = await run_graph(case, provider)
    assert report.readiness_status == "unsupported_scope"
    assert provider.calls == 0 and report.evidence == [] and report.next_steps == []
    assert "fetch_sources" not in nodes


async def test_research_consent_blocks_before_source_access():
    case, provider = sample_case(), MockProvider()
    case["consent_research"] = False
    with pytest.raises(ShipmentWorkflowError) as error:
        await run_graph(case, provider)
    assert error.value.code == "CONSENT_REQUIRED" and provider.calls == 0


async def test_guard_can_block_revoked_consent_before_next_node():
    count, provider = 0, MockProvider()

    async def guard():
        nonlocal count
        count += 1
        if count >= 2:
            raise ShipmentWorkflowError("CONSENT_REQUIRED", "MOCK consent revoked")

    with pytest.raises(ShipmentWorkflowError) as error:
        await run_graph(provider=provider, guard=guard)
    assert provider.calls == 0 and error.value.code == "CONSENT_REQUIRED"


async def test_outer_task_cancellation_stops_inflight_workflow():
    started = asyncio.Event()

    class SlowProvider:
        async def fetch_all(self):
            started.set()
            await asyncio.Event().wait()

    task = asyncio.create_task(run_graph(provider=SlowProvider()))
    await asyncio.wait_for(started.wait(), timeout=2)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task


def test_llm_mode_missing_configuration_fails_explicitly():
    with pytest.raises(ShipmentWorkflowError) as error:
        build_graph(InMemorySaver(), mode="llm")
    assert error.value.code == "MODEL_UNAVAILABLE"


@pytest.mark.parametrize("model_provider", ["openai", "anthropic"])
async def test_llm_consent_required_even_when_key_exists(model_provider):
    provider = MockProvider()
    with pytest.raises(ShipmentWorkflowError) as error:
        await run_graph(provider=provider, mode="llm", model_provider=model_provider,
                        model_name="MOCK-MODEL", api_key="MOCK-NOT-A-KEY")
    assert error.value.code == "CONSENT_REQUIRED" and provider.calls == 0


async def test_llm_is_one_bounded_call_and_not_an_evidence_only_fallback(monkeypatch):
    import langchain_openai

    calls, parameters = [], {}

    class FakeModel:
        def __init__(self, **kwargs):
            parameters.update(kwargs)

        def with_structured_output(self, schema):
            self.schema = schema
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            return self.schema(
                summary="MOCK vai trò IOR và FSVP còn cần xác minh riêng; dữ kiện thiếu vẫn được giữ là chưa biết.",
                ordered_finding_ids=["fsvp_role_separate", "facts_unverified"], evidence_ids=[],
                evidence_translations=mock_unavailable_translations(messages),
            )

    monkeypatch.setattr(langchain_openai, "ChatOpenAI", FakeModel)
    case = sample_case()
    case["consent_model"] = True
    case["shipment"].update(
        importer_of_record="MOCK-PRIVATE-IOR", fsvp_importer="MOCK-PRIVATE-FSVP",
        pickup_location="MOCK-PRIVATE-ADDRESS",
    )
    report, nodes, _ = await run_graph(
        case, mode="llm", model_name="MOCK-MODEL", api_key="MOCK-NOT-A-KEY"
    )
    assert "summarize_with_model" in nodes and report.mode == "llm" and report.llm_used
    assert len(calls) == 1 and parameters["max_tokens"] == 4000 and parameters["max_retries"] == 0
    assert parameters["base_url"] == OPENAI_API_BASE and parameters["timeout"] == 45
    assert len(calls[0][1][1].encode("utf-8")) <= 30_000
    assert "MOCK-NOT-A-KEY" not in report.model_dump_json()
    assert report.findings[0].id == "fsvp_role_separate"
    assert report.model_provider == "openai" and report.model_name == "MOCK-MODEL"
    assert all(marker not in str(calls) for marker in (
        "MOCK-PRIVATE-IOR", "MOCK-PRIVATE-FSVP", "MOCK-PRIVATE-ADDRESS"
    ))


async def test_bad_model_citation_fails_without_fallback_or_retry(monkeypatch):
    import langchain_openai

    calls = 0

    class BadModel:
        def __init__(self, **kwargs): pass
        def with_structured_output(self, schema): return self
        async def ainvoke(self, messages):
            nonlocal calls
            calls += 1
            return {"summary": "MOCK summary long enough for structured output.", "ordered_finding_ids": [],
                    "evidence_ids": ["MOCK-FABRICATED-EVIDENCE"]}

    monkeypatch.setattr(langchain_openai, "ChatOpenAI", BadModel)
    case = sample_case()
    case["consent_model"] = True
    with pytest.raises(ShipmentWorkflowError) as error:
        await run_graph(case, mode="llm", model_name="MOCK-MODEL", api_key="MOCK-NOT-A-KEY")
    assert calls == 1 and error.value.code == "MODEL_OUTPUT_INVALID"


async def test_graph_checkpoint_is_persisted_in_real_async_sqlite(tmp_path):
    db = str(tmp_path / "shipment.sqlite")
    config = {"configurable": {"thread_id": "MOCK-PERSISTED-RUN"}}
    async with AsyncSqliteSaver.from_conn_string(db) as saver:
        graph = build_graph(saver, source_provider=MockProvider())
        await graph.ainvoke({"case": sample_case(), "question": "MOCK checkpoint"}, config=config)
    async with AsyncSqliteSaver.from_conn_string(db) as saver:
        graph = build_graph(saver, source_provider=MockProvider())
        state = await graph.aget_state(config)
        assert state.values["report"]["mode"] == "evidence_only"
        assert state.values["case"]["case_id"] == "MOCK-CASE-01"


def test_source_parser_rejects_successful_js_shell():
    shell = b"<html><head><title>Salesforce</title></head><body><div>Loading</div>" + b" " * 500 + b"</body></html>"
    with pytest.raises(SourceRetrievalError) as error:
        parse_document(SOURCE_CATALOG[2], SOURCE_CATALOG[2].url, shell, "2026-10-17T00:00:00+00:00")
    assert error.value.code == "EMPTY_CONTENT"


def test_source_parser_keeps_hash_locator_material_without_executing_html():
    raw = ("<html><head><meta name='dcterms.modified' content='2026-10-16'/></head><body>"
           "<nav>MOCK navigation</nav><main><h1>MOCK FDA imports</h1><p>Import procedures and prior notice.</p>"
           "<p>" + "MOCK readable official-source fixture. " * 15 +
           "</p><script>MOCK_UNTRUSTED_SCRIPT</script></main></body></html>").encode()
    doc = parse_document(SOURCE_CATALOG[0], SOURCE_CATALOG[0].url, raw, "2026-10-17T00:00:00+00:00")
    assert doc.content_sha256 == hashlib.sha256(doc.text.encode("utf-8")).hexdigest()
    assert doc.source_date == "2026-10-16"
    assert "MOCK_UNTRUSTED_SCRIPT" not in doc.text and "MOCK navigation" not in doc.text


def test_source_document_refuses_hash_from_a_different_snapshot():
    data = batch_without_cbp().sources[0].model_dump()
    data["text"] += "\nMOCK tampered content"
    with pytest.raises(ValueError):
        SourceDocument.model_validate(data)


@pytest.mark.parametrize("url", [
    "http://www.fda.gov/food", "https://127.0.0.1/source", "https://www.fda.gov.evil.invalid/",
    "https://user:pass@www.fda.gov/food", "https://www.fda.gov:8443/food",
])
def test_static_source_host_policy_rejects_unexpected_urls(url):
    with pytest.raises(SourceRetrievalError):
        validate_url(url)


async def test_dns_private_address_is_rejected(monkeypatch):
    loop = asyncio.get_running_loop()
    monkeypatch.setattr(loop, "getaddrinfo", AsyncMock(return_value=[
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))
    ]))
    with pytest.raises(SourceRetrievalError) as error:
        await validate_public_dns("www.fda.gov")
    assert error.value.code == "UNSAFE_ADDRESS"


async def test_redirect_to_private_url_is_rejected_without_second_request(monkeypatch):
    from nmate.agents.shipment import sources
    monkeypatch.setattr(sources, "validate_public_dns", AsyncMock())
    requests = []

    async def handler(request):
        requests.append(str(request.url))
        return httpx.Response(302, headers={"Location": "https://127.0.0.1/private"})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler), follow_redirects=False) as client:
        result = await OfficialSourceProvider()._fetch_one(client, SOURCE_CATALOG[0])
    assert isinstance(result, SourceFailure) and result.code == "UNSAFE_URL"
    assert len(requests) == 1


async def test_provider_keeps_403_as_failure_and_enforces_body_limit(monkeypatch):
    from nmate.agents.shipment import sources
    monkeypatch.setattr(sources, "validate_public_dns", AsyncMock())
    for response, expected in [
        (httpx.Response(403), "HTTP_403"),
        (httpx.Response(200, headers={"Content-Type": "text/html", "Content-Length": "2000000"},
                        content=b"MOCK"), "BODY_TOO_LARGE"),
    ]:
        async with httpx.AsyncClient(transport=httpx.MockTransport(lambda request: response)) as client:
            result = await OfficialSourceProvider()._fetch_one(client, SOURCE_CATALOG[0])
        assert isinstance(result, SourceFailure) and result.code == expected


async def test_candidate_report_rejects_fabricated_evidence_references():
    report, _, _ = await run_graph()
    changed = copy.deepcopy(report.model_dump())
    changed["findings"][0]["evidence_ids"] = ["MOCK-NOT-PRESENT"]
    with pytest.raises(ValueError):
        ShipmentReport.model_validate(changed)
    assert "verified" not in json.dumps([r.status for r in report.responsibilities])


@pytest.mark.parametrize("provider", ["openai", "anthropic"])
def test_explicit_api_key_required_without_ambient_credential_lookup(monkeypatch, provider):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "MOCK-AMBIENT-NOT-A-KEY")
    monkeypatch.setenv("OPENAI_API_KEY", "MOCK-AMBIENT-NOT-A-KEY")
    with pytest.raises(ModelProviderError) as error:
        create_chat_model(provider, "MOCK-MODEL", None)
    assert error.value.code == "MODEL_CREDENTIALS_MISSING"
    assert "MOCK-AMBIENT" not in str(error.value)


def test_claude_subscription_token_is_not_used_as_api_credential():
    with pytest.raises(ModelProviderError) as error:
        create_chat_model("anthropic", "MOCK-MODEL", "sk-ant-oat01-MOCK-NOT-A-TOKEN")
    assert error.value.code == "MODEL_CREDENTIALS_INVALID"
    assert "MOCK-NOT-A-TOKEN" not in str(error.value)


def test_model_provider_and_name_are_validated_separately():
    with pytest.raises(ModelProviderError) as error:
        create_chat_model("claude-code", "MOCK-MODEL", "MOCK-NOT-A-KEY")
    assert error.value.code == "MODEL_PROVIDER_UNSUPPORTED"
    with pytest.raises(ModelProviderError) as error:
        create_chat_model("anthropic", "https://example.invalid/model?token=MOCK", "MOCK-NOT-A-KEY")
    assert error.value.code == "MODEL_NAME_INVALID" and "token=MOCK" not in str(error.value)


def test_official_api_endpoints_override_ambient_base_url(monkeypatch):
    for variable in ("ANTHROPIC_BASE_URL", "ANTHROPIC_API_URL", "OPENAI_BASE_URL", "OPENAI_API_BASE"):
        monkeypatch.setenv(variable, "https://mock-untrusted.example.invalid")
    claude = create_chat_model("anthropic", "claude-sonnet-5-5", "MOCK-NOT-A-KEY")
    openai = create_chat_model("openai", "MOCK-MODEL", "MOCK-NOT-A-KEY")
    assert claude.anthropic_api_url == ANTHROPIC_API_BASE
    assert str(openai.openai_api_base).rstrip("/") == OPENAI_API_BASE
    assert claude.max_tokens == 4000 and claude.max_retries == 0 and claude.default_request_timeout == 45
    assert claude.temperature is None


async def test_claude_graph_uses_native_json_one_call_and_records_actual_provider(monkeypatch):
    import langchain_anthropic
    import langchain_openai

    calls, settings, methods = [], {}, []

    class FakeClaude:
        def __init__(self, **kwargs):
            settings.update(kwargs)

        def with_structured_output(self, schema, **kwargs):
            methods.append(kwargs)
            self.schema = schema
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            return self.schema(
                summary="MOCK xác minh riêng các vai trò IOR và FSVP, giữ nguyên thông tin thiếu trong phương án chuẩn bị.",
                ordered_finding_ids=["fsvp_role_separate"], evidence_ids=[],
                evidence_translations=mock_unavailable_translations(messages),
            )

    def no_other_provider(**kwargs):
        raise AssertionError("OpenAI fallback must never be constructed")

    monkeypatch.setattr(langchain_anthropic, "ChatAnthropic", FakeClaude)
    monkeypatch.setattr(langchain_openai, "ChatOpenAI", no_other_provider)
    case = sample_case()
    case["consent_model"] = True
    case["shipment"].update(importer_of_record="MOCK-PRIVATE-IOR", fsvp_importer="MOCK-PRIVATE-FSVP")
    report, _, _ = await run_graph(
        case, mode="llm", model_provider="anthropic", model_name="claude-sonnet-5-5",
        api_key="MOCK-CLAUDE-NOT-A-KEY",
    )
    assert methods == [{"method": "json_schema"}]
    assert len(calls) == 1 and settings["max_tokens"] == 4000 and settings["max_retries"] == 0
    assert settings["timeout"] == 45 and settings["base_url"] == ANTHROPIC_API_BASE
    assert "temperature" not in settings and "tool_choice" not in settings
    assert report.llm_used and report.model_provider == "anthropic" and report.model_name == "claude-sonnet-5-5"
    assert "MOCK-CLAUDE-NOT-A-KEY" not in report.model_dump_json()
    assert all(marker not in str(calls) for marker in ("MOCK-PRIVATE-IOR", "MOCK-PRIVATE-FSVP"))


@pytest.mark.parametrize("status,code", [
    (401, "MODEL_AUTHENTICATION_FAILED"), (404, "MODEL_NOT_FOUND"),
    (429, "MODEL_RATE_LIMITED"), (500, "MODEL_UNAVAILABLE"),
])
async def test_claude_api_errors_are_typed_sanitized_and_never_fall_back(monkeypatch, status, code):
    import langchain_anthropic
    import langchain_openai

    calls = 0

    class MockApiError(Exception):
        status_code = status

    class RejectingClaude:
        def __init__(self, **kwargs): pass
        def with_structured_output(self, schema, **kwargs): return self
        async def ainvoke(self, messages):
            nonlocal calls
            calls += 1
            raise MockApiError("MOCK-CREDENTIAL-PROMPT-AND-ENDPOINT-MUST-NOT-LEAK")

    def forbidden_openai(**kwargs):
        raise AssertionError("Provider fallback attempted")

    monkeypatch.setattr(langchain_anthropic, "ChatAnthropic", RejectingClaude)
    monkeypatch.setattr(langchain_openai, "ChatOpenAI", forbidden_openai)
    case = sample_case()
    case["consent_model"] = True
    with pytest.raises(ShipmentWorkflowError) as error:
        await run_graph(case, mode="llm", model_provider="anthropic",
                        model_name="claude-sonnet-5-5", api_key="MOCK-NOT-A-KEY")
    assert error.value.code == code and calls == 1
    assert "MOCK-CREDENTIAL" not in str(error.value)


async def test_actual_claude_sdk_serializes_native_json_without_forced_tools():
    """Real installed LangChain/Anthropic code, with HTTP intercepted before network."""
    import anthropic
    import httpx2

    from nmate.agents.shipment.graph import ModelSynthesis

    requests = []
    synthesis = {
        "summary": "MOCK tóm tắt phương án chuẩn bị và các dữ kiện còn thiếu, cần chuyên gia xác minh.",
        "ordered_finding_ids": ["facts_unverified"], "evidence_ids": [],
        "evidence_translations": [{
            "evidence_id": "MOCK-EVIDENCE", "original_excerpt_sha256": "a" * 64,
            "status": "translated", "title_vi": "Tiêu đề nguồn mô phỏng",
            "excerpt_vi": "Bản dịch nguồn mô phỏng; chưa có xác nhận nghiệp vụ.", "publisher_vi": "Cơ quan mô phỏng",
        }],
    }

    async def handler(request):
        requests.append({"url": str(request.url), "body": json.loads(request.content)})
        return httpx2.Response(200, json={
            "id": "msg_MOCK", "type": "message", "role": "assistant", "model": "claude-sonnet-5-5",
            "content": [{"type": "text", "text": json.dumps(synthesis, ensure_ascii=False)}],
            "stop_reason": "end_turn", "stop_sequence": None,
            "usage": {"input_tokens": 100, "output_tokens": 50},
        })

    async with httpx2.AsyncClient(transport=httpx2.MockTransport(handler)) as http:
        client = create_chat_model("anthropic", "claude-sonnet-5-5", "MOCK-NOT-A-KEY")
        api = anthropic.AsyncClient(
            api_key="MOCK-NOT-A-KEY", base_url=ANTHROPIC_API_BASE,
            max_retries=0, timeout=45, http_client=http,
        )
        # Override the cached transport only in this test; production factory is unchanged.
        client.__dict__["_async_client"] = api
        result = await client.with_structured_output(ModelSynthesis, method="json_schema").ainvoke(
            [("human", "MOCK structured output serialization smoke")]
        )
        await api.close()
    assert isinstance(result, ModelSynthesis) and result.summary == synthesis["summary"]
    assert result.evidence_translations[0].excerpt_vi == synthesis["evidence_translations"][0]["excerpt_vi"]
    assert len(requests) == 1
    request = requests[0]
    assert request["url"] == "https://api.anthropic.com/v1/messages"
    assert request["body"]["max_tokens"] == 4000
    assert request["body"]["output_config"]["format"]["type"] == "json_schema"
    native_schema = request["body"]["output_config"]["format"]["schema"]
    assert native_schema["additionalProperties"] is False
    assert "minLength" not in native_schema["properties"]["summary"]
    assert "maxLength" not in native_schema["properties"]["summary"]
    assert "maxItems" not in native_schema["properties"]["evidence_ids"]
    # SDK removes unsupported native constraints; the client still enforces bounds.
    with pytest.raises(ValueError):
        ModelSynthesis(summary="short", ordered_finding_ids=[], evidence_ids=[])
    assert "tools" not in request["body"] and "tool_choice" not in request["body"]
    assert "temperature" not in request["body"]


async def test_evidence_only_records_no_model_execution_metadata():
    report, _, _ = await run_graph(model_provider="anthropic")
    assert report.model_provider is None and report.model_name is None and not report.llm_used


async def test_actual_claude_sdk_explicit_key_avoids_ambient_token_or_disk_profile(monkeypatch):
    import anthropic._client

    monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "MOCK-AMBIENT-SUBSCRIPTION-TOKEN")
    monkeypatch.setenv("ANTHROPIC_PROFILE", "MOCK-NONEXISTENT-PROFILE")

    def forbid_discovery(*args, **kwargs):
        raise AssertionError("Credential/profile discovery must not be invoked")

    monkeypatch.setattr(anthropic._client, "default_credentials", forbid_discovery)
    model = create_chat_model("anthropic", "claude-sonnet-5-5", "MOCK-EXPLICIT-API-KEY")
    api = model._async_client
    assert api.auth_token is None and api.credentials is None
    assert api.api_key == "MOCK-EXPLICIT-API-KEY"
    assert str(api.base_url).rstrip("/") == ANTHROPIC_API_BASE
    await api.close()
