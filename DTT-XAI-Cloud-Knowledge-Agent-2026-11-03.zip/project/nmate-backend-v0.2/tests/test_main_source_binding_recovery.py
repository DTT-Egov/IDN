"""Recover only never-usable dependencies, with no provider or network replay."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.main.source_binding_recovery import recover_unused_source_bindings
from nmate.v03.core import CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_provider import ReviewProvider
from nmate.v03.live_review import LiveIntent, LiveReviewMissionService
from nmate.v03.missions import digest, make_plan
from test_v03_live_multimarket import GroundedModel


BAD_SOURCE = "jp_mhlw_notification_20261019_v1"


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "bindings.sqlite3")
    owner = LocalAccounts(repo).register("owner", "TestPassword12345", "Doanh nghiệp Sen")
    model = GroundedModel()
    service = LiveReviewMissionService(repo, model_call=model)
    # Install the durable ledger schema; its request function is never invoked.
    ReviewProvider(repo, request_fn=None)
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE main_research_authorizations (mission_id TEXT PRIMARY KEY, account_id TEXT, enterprise_id TEXT, operation_id TEXT, consent_at TEXT)")
    return repo, owner, model, service


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


async def legacy_plan(workspace):
    repo, owner, _, service = workspace
    with repo.connection(write=True) as db:
        before = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation',version=2,invalidated_at=? WHERE id=?", (before, BAD_SOURCE))
    mission = await service.prepare_async(*scope(owner), "Tôi có Trà Sen Tây Hồ gửi Nhật Bản, cần điều kiện nhập khẩu và nhãn.", "legacy-jp-prepare", market_code="JP")
    # Reproduce the old catalog bug: binding a source whose snapshot records
    # already explicitly said it could not be used when this plan was created.
    with repo.connection(write=True) as db:
        source = db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (BAD_SOURCE,)).fetchone()
        payload = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mission["id"],)).fetchone()[0])
        payload["knowledge"]["source_refs"].append({"source_id": BAD_SOURCE, "version": source["version"], "content_sha256": source["content_sha256"]})
        plan = make_plan(LiveIntent.model_validate(payload["intent"]))
        plan.hash = digest({"plan": plan.model_dump(), "enterprise_id": owner["enterprise_id"],
                            "fact_refs": payload["context"]["fact_refs"], "source_refs": payload["knowledge"]["source_refs"]})
        payload["plan"] = plan.model_dump()
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(payload), mission["id"]))
        db.execute("INSERT INTO v03_dependencies VALUES(?,?,?,?,?)", (mission["id"], owner["enterprise_id"], "source", BAD_SOURCE, str(source["version"])))
    assert service.get(*scope(owner), mission["id"])["status"] == "needs_revalidation"
    return mission["id"]


def payload(repo, mission_id):
    with repo.connection() as db:
        return json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mission_id,)).fetchone()[0])


def force_planned(repo, mission_id):
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_missions SET status='planned' WHERE id=?", (mission_id,))


@pytest.mark.asyncio
async def test_repairs_only_unused_at_creation_ref_and_preserves_gap_sources_raw_context_and_status(workspace):
    repo, owner, model, service = workspace
    mid = await legacy_plan(workspace)
    before = payload(repo, mid)
    with repo.connection() as db:
        raw_before = db.execute("SELECT output_json,metadata_json FROM v03_live_review_outputs WHERE mission_id=?", (mid,)).fetchone()
        source_before = dict(db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (BAD_SOURCE,)).fetchone())
        dependencies_before = [tuple(row) for row in db.execute("SELECT * FROM v03_dependencies WHERE mission_id=? ORDER BY dependency_kind,dependency_key", (mid,))]
        fact_count = db.execute("SELECT COUNT(*) FROM v03_fact_assertions").fetchone()[0]
    assert recover_unused_source_bindings(repo) == [mid]
    view = service.get(*scope(owner), mid)
    after = payload(repo, mid)
    assert view["status"] == "planned"
    assert after["context"] == before["context"] and after["intent"] == before["intent"]
    assert after["knowledge"]["records"] == before["knowledge"]["records"]
    assert after["knowledge"]["coverage"] == before["knowledge"]["coverage"]
    assert "facility_registration" in after["knowledge"]["coverage"]["missing"]
    assert all(not record["reusable"] for record in after["knowledge"]["records"] if record["source_id"] == BAD_SOURCE)
    assert after["knowledge"]["source_refs"] == [ref for ref in before["knowledge"]["source_refs"] if ref["source_id"] != BAD_SOURCE]
    assert after["plan"]["hash"] != before["plan"]["hash"]
    assert {key: value for key, value in after["plan"].items() if key != "hash"} == {key: value for key, value in before["plan"].items() if key != "hash"}
    assert after["source_binding_recovery"]["model_calls"] == after["source_binding_recovery"]["ssot_writes"] == 0
    assert len(model.calls) == 1
    with repo.connection() as db:
        assert tuple(db.execute("SELECT output_json,metadata_json FROM v03_live_review_outputs WHERE mission_id=?", (mid,)).fetchone()) == tuple(raw_before)
        assert dict(db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (BAD_SOURCE,)).fetchone()) == source_before
        assert db.execute("SELECT COUNT(*) FROM v03_fact_assertions").fetchone()[0] == fact_count
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0
        audit = db.execute("SELECT * FROM main_source_binding_recoveries WHERE mission_id=?", (mid,)).fetchone()
        assert json.loads(audit["original_source_refs_json"]) == before["knowledge"]["source_refs"]
        assert audit["previous_plan_hash"] == before["plan"]["hash"]
        dependencies = [tuple(row) for row in db.execute("SELECT * FROM v03_dependencies WHERE mission_id=? ORDER BY dependency_kind,dependency_key", (mid,))]
        assert dependencies == [row for row in dependencies_before if not (row[2] == "source" and row[3] == BAD_SOURCE)]
    assert recover_unused_source_bindings(repo) == []


@pytest.mark.asyncio
@pytest.mark.parametrize("mutation", ["after_creation", "new_version", "new_hash", "no_timestamp", "not_explicit_false", "another_usable_record"])
async def test_uncertain_or_later_source_change_is_never_detached(workspace, mutation):
    repo, _, model, _ = workspace
    mid = await legacy_plan(workspace)
    before = payload(repo, mid)
    with repo.connection(write=True) as db:
        if mutation == "after_creation":
            later = (datetime.fromisoformat(before["created_at"]) + timedelta(seconds=1)).isoformat()
            db.execute("UPDATE v03_domain_sources SET invalidated_at=? WHERE id=?", (later, BAD_SOURCE))
        elif mutation == "new_version":
            db.execute("UPDATE v03_domain_sources SET version=3 WHERE id=?", (BAD_SOURCE,))
        elif mutation == "new_hash":
            db.execute("UPDATE v03_domain_sources SET content_sha256=? WHERE id=?", ("0" * 64, BAD_SOURCE))
        elif mutation == "no_timestamp":
            db.execute("UPDATE v03_domain_sources SET invalidated_at=NULL WHERE id=?", (BAD_SOURCE,))
        else:
            modified = deepcopy(before)
            record = next(record for record in modified["knowledge"]["records"] if record["source_id"] == BAD_SOURCE)
            if mutation == "not_explicit_false":
                record.pop("reusable")
            else:
                extra = deepcopy(record)
                extra.update(id="another-snapshot-record", reusable=True)
                modified["knowledge"]["records"].append(extra)
            db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(modified), mid))
    assert recover_unused_source_bindings(repo) == []
    assert any(ref["source_id"] == BAD_SOURCE for ref in payload(repo, mid)["knowledge"]["source_refs"])
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_source_reusable_at_creation_and_invalidated_later_remains_blocked(workspace):
    repo, owner, model, service = workspace
    mission = await service.prepare_async(*scope(owner), "Tôi có Trà Sen Tây Hồ gửi Nhật Bản, cần điều kiện nhập khẩu và nhãn.", "usable-at-creation", market_code="JP")
    assert all(record["reusable"] for record in mission["knowledge"]["records"])
    service.catalog.observe_source(*scope(owner), BAD_SOURCE, "0" * 64, "changed-after-plan")
    assert recover_unused_source_bindings(repo) == []
    assert service.get(*scope(owner), mission["id"])["status"] == "needs_revalidation"
    # Even a caller accidentally restoring SQL status cannot erase the true
    # snapshot's reusable=True marker or the version mismatch.
    force_planned(repo, mission["id"])
    assert recover_unused_source_bindings(repo) == []
    assert len(model.calls) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("guard", ["authorization", "start_receipt", "research_stage", "research_attempt", "task_started", "fact_changed", "remaining_source_changed"])
async def test_any_started_paid_or_changed_context_guard_prevents_recovery(workspace, guard):
    repo, owner, _, service = workspace
    mid = await legacy_plan(workspace)
    mission = payload(repo, mid)
    if guard == "fact_changed":
        product = repo.get_entity(*scope(owner), mission["product"]["entity_id"])
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "200 g"}], product["version"], "changed-product")
        force_planned(repo, mid)
    elif guard == "remaining_source_changed":
        service.catalog.observe_source(*scope(owner), "jp_caa_label_language", "0" * 64, "another-source-changed")
        force_planned(repo, mid)
    else:
        with repo.connection(write=True) as db:
            if guard == "authorization":
                db.execute("INSERT INTO main_research_authorizations VALUES(?,?,?,?,?)", (mid, *scope(owner), "paid-start", now_iso()))
            elif guard == "start_receipt":
                db.execute("INSERT INTO v03_mission_operations VALUES(?,?,?,?,?,?)", (owner["enterprise_id"], owner["account_id"], "start", "start-receipt", "0" * 64, mid))
            elif guard == "research_stage":
                db.execute("INSERT INTO v03_live_review_stages VALUES(?,?,?,?,?)", (mid, "research", "synthesis_requested", None, now_iso()))
            elif guard == "research_attempt":
                db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,model,state,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                           ("prepared-research", *scope(owner), f"research:{mid}", "research", "0" * 64, "injected-model", "prepared", now_iso()))
            else:
                db.execute("UPDATE v03_task_attempts SET state='running' WHERE mission_id=?", (mid,))
    assert recover_unused_source_bindings(repo) == []
    assert any(ref["source_id"] == BAD_SOURCE for ref in payload(repo, mid)["knowledge"]["source_refs"])
