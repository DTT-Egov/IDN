"""Historical lexical evidence is independent of today's proposal eligibility."""
import copy
import hashlib

import pytest

from nmate.main.draft_projection import project_excluded_legacy_draft, stale_text_name_candidates
from nmate.main.history import history_metadata
from nmate.v04.extraction import extract_product_text
from test_main_excluded_legacy_draft import FIRST, WRONG_NAME, old_view


@pytest.mark.parametrize("text, name", [
    (FIRST, "Trà Sen Tây Hồ"),
    ("Chị có nên nhập thêm hàng Trà Sen khi tồn kho còn 120 hộp?", "Trà Sen"),
    ("Chị đọc tài liệu Trà Sen Tây Hồ để lập nháp hồ sơ.", "Trà Sen Tây Hồ"),
])
def test_valid_unchecked_historical_reference_survives_read_projection_and_history(text, name):
    view = old_view()
    intake = view["intake"]
    intake.update(text=text, product={"id": "new_product", "name": name, "version": 0})
    candidate = intake["candidates"][0]
    start = text.index(name)
    candidate.update(value=name, source={"kind": "server_text_extract", "quote": name,
        "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
        "start_offset": start, "end_offset": start + len(name)})
    view["messages"] = [{"role": "user", "text": text, "intake_id": intake["id"]}]
    before = copy.deepcopy(view)
    assert not any(fact["field"] == "name" for fact in extract_product_text(text))
    assert stale_text_name_candidates(view, intake) == []
    for _ in range(2):
        projected = project_excluded_legacy_draft(view)
        assert projected == before and projected["intake"]["candidates"] == [candidate]
        history = history_metadata(projected)
        assert not history.get("history_extraction_review_needed")
    assert view == before


@pytest.mark.parametrize("checked, expected_archive", [(False, True), (True, False)])
def test_malformed_historical_reference_only_compacts_when_owner_excluded(checked, expected_archive):
    view = old_view()
    view["drafts"]["old-intake"]["selected"]["old-name"] = checked
    before = copy.deepcopy(view)
    projected = project_excluded_legacy_draft(view)
    archive = ((projected["intake"].get("draft_projection") or {}).get("archived_candidates") or [])
    assert bool(archive) is expected_archive
    if expected_archive:
        assert archive[0]["value"] == WRONG_NAME
        assert archive[0]["source"] == before["intake"]["candidates"][0]["source"]
    else:
        assert projected["intake"]["candidates"] == before["intake"]["candidates"]
    assert view == before


@pytest.mark.parametrize("text, name", [
    ("Chị đọc tài liệu Lotus Tea để chuẩn bị hồ sơ.", "Lotus Tea"),
    ("Tên sản phẩm: Trà Mỗi Tháng. Chị bán 300 hộp Trà Mỗi Tháng.", "Trà Mỗi Tháng"),
    ("Chị kiểm kê Trà Sen và Bột Sen, tồn kho còn 120 hộp.", "Trà Sen"),
])
def test_unrecognized_or_ambiguous_legacy_literal_is_unknown_not_invalid(text, name):
    view = old_view()
    view["intake"].update(text=text, product={"id": "new_product", "name": name, "version": 0})
    view["intake"]["candidates"][0].update(value=name, source={"kind": "server_text_extract", "quote": name,
        "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest()})
    view["messages"] = [{"role": "user", "text": text, "intake_id": view["intake"]["id"]}]
    before = copy.deepcopy(view)
    assert stale_text_name_candidates(view, view["intake"]) == []
    assert project_excluded_legacy_draft(view) == before


@pytest.mark.parametrize("change", ["empty_parse", "longer_reference", "value_differs_from_quote",
    "wrong_offset", "source_ambiguity"])
def test_missing_current_reference_or_unproven_source_cannot_invalidate_legacy_name(monkeypatch, change):
    import nmate.main.draft_projection as projection
    view = old_view()
    candidate = view["intake"]["candidates"][0]
    if change == "empty_parse":
        monkeypatch.setattr(projection, "extract_product_text", lambda *_args, **_kwargs: [])
    elif change == "longer_reference":
        monkeypatch.setattr(projection, "extract_product_text", lambda *_args, **_kwargs: [
            {"field": "name", "value": WRONG_NAME + " 120 hộp"}])
    elif change == "value_differs_from_quote":
        candidate["source"]["quote"] = "Trà Sen Tây Hồ"
    elif change == "wrong_offset":
        candidate["source"].update(start_offset=0, end_offset=len(WRONG_NAME))
    elif change == "source_ambiguity":
        candidate["source"].pop("text_sha256")
        view["messages"].append({"role": "user", "intake_id": view["intake"]["id"],
                                 "text": "Chị hỏi lại " + FIRST})
    before = copy.deepcopy(view)
    assert stale_text_name_candidates(view, view["intake"]) == []
    assert project_excluded_legacy_draft(view) == before


def test_frozen_legacy_decision_never_reparses_or_changes_historical_choice(monkeypatch):
    import nmate.main.draft_projection as projection
    view = old_view()
    view["intake"]["review"] = {"schema_version": "workspace-review/2"}
    candidate = view["intake"]["candidates"][0]
    candidate.update(decision_state="pending")
    def forbidden(*_args, **_kwargs):
        raise AssertionError("Frozen legacy decisions must not re-run the parser")
    monkeypatch.setattr(projection, "extract_product_text", forbidden)
    assert project_excluded_legacy_draft(view) == view
    candidate.update(decision_state="legacy_archived", review_decision_reason="legacy_parser_invalid:20261021")
    before = copy.deepcopy(view)
    result = project_excluded_legacy_draft(view)
    assert result["intake"]["draft_projection"]["archived_count"] == 1
    assert view == before
