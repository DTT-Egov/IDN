"""Natural business needs have separate bounded coverage; no external calls."""
import copy

import pytest

from nmate.main.app import make_main_app
from nmate.policy_v1 import service as policy_service
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.conversations import ConversationService
from nmate.v04.dialogue import business_plan, interpret, next_steps, working_answers
from nmate.v04.intake import IntakeService


POLICY_CASES = [
    ("THỬ NGHIỆM: Cơ sở muốn hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách.", ["market_development", "workforce_training"]),
    ("Chị cần chính sách số hóa sổ sách và đưa hàng ra nước ngoài.", ["digital_transformation", "market_development"]),
    ("Chị cần hỗ trợ chuyển đổi số và xúc tiến thương mại.", ["digital_transformation", "market_development"]),
    ("Hà Nội hỗ trợ gì để chị tham gia hội chợ và đăng ký nhãn hiệu?", ["market_development", "trademark_protection"]),
    ("Chị muốn hỗ trợ ứng dụng phần mềm và OCOP.", ["digital_transformation", "ocop_program"]),
    ("Có hỗ trợ bồi dưỡng nhân sự và phát triển thị trường không?", ["workforce_training", "market_development"]),
    ("Chị muốn tập huấn nhân viên làm sổ sách.", ["workforce_training"]),
    ("Có chương trình nâng cao tay nghề cho người lao động và bảo hộ thương hiệu không?", ["workforce_training", "trademark_protection"]),
    ("Chị không cần xuất khẩu, chỉ đào tạo nhân viên làm sổ sách.", ["workforce_training"]),
    ("Không hỏi đào tạo nhân viên, chị muốn xúc tiến thương mại.", ["market_development"]),
    ("Không chỉ đào tạo nhân viên mà còn xúc tiến thương mại và OCOP.", ["workforce_training", "market_development", "ocop_program"]),
    ("Chị không cần xúc tiến thương mại và đào tạo nhân viên; chỉ OCOP.", ["ocop_program"]),
    ("THỬ NGHIỆM: không đào tạo nhân viên; cần đưa hàng ra nước ngoài.", ["market_development"]),
    ("Chị cần đào tạo nhân viên nhưng chưa cần OCOP hay nhãn hiệu.", ["workforce_training"]),
    ("Không cần đưa hàng ra nước ngoài nhưng cần ứng dụng phần mềm và tập huấn nhân viên.", ["digital_transformation", "workforce_training"]),
    ("Có hỗ trợ đào tạo kế toán và tham gia hội chợ không?", ["workforce_training", "market_development"]),
    ("Chị cần bồi dưỡng nghiệp vụ sổ sách và OCOP.", ["workforce_training", "ocop_program"]),
]


@pytest.mark.parametrize("text,expected", POLICY_CASES)
def test_natural_policy_needs_are_ordered_complete_and_respect_negation(text, expected):
    result = policy_service.resolve_intent(text)
    assert result["goals"] == expected
    assert result["provider_used"] is False and result["request_scope"] == "in_scope"


def test_every_registered_goal_has_a_minimized_safe_prompt():
    for goal in policy_service.GOAL_LABELS:
        text = policy_service.safe_policy_question({"goals": [goal], "outcome_types": ["policy_discovery"]})
        assert isinstance(text, str) and text
        assert policy_service.OUTCOMES["policy_discovery"] in text
        assert policy_service.POLICY_GOAL_DEFINITIONS[goal]["citation_terms"]


def test_training_and_export_do_not_borrow_digital_sources_or_claim_eligibility(tmp_path):
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append(True)
        raise AssertionError("Policy discovery must not call a provider")
    app = make_main_app(tmp_path / "private-policy.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("natural-policy-needs", "Only-local-test-password", "Cơ sở QA")
    a, e = owner["account_id"], owner["enterprise_id"]
    text = POLICY_CASES[0][0]
    result = app.state.core_extension.prepare(a, e, text, "natural-policy-mixed")["policy_case"]
    coverage = {item["goal"]: item for item in result["goal_coverage"]}
    assert list(coverage) == ["market_development", "workforce_training"]
    assert all(item["status"] == "needs_source" and not item["source_ids"] for item in coverage.values())
    assert result["provider_calls"] == 0 and not calls
    assert app.state.core_extension.get_case(a, e, result["id"])["goal_coverage"] == result["goal_coverage"]


def test_training_requires_explicit_matching_source_and_rule_scope(tmp_path, monkeypatch):
    service = policy_service.PolicyService(CoreRepository(tmp_path / "scope.sqlite3"))
    intent = policy_service.resolve_intent("Chị cần đào tạo nhân viên làm sổ sách.")
    monkeypatch.setattr(service.catalog, "retrieve", lambda *args, **kwargs: [{
        "chunk_id": "TEST-DIGITAL-CHUNK", "metadata": {"goal_types": ["digital_inventory"],
        "scope": "consulting_digital_transformation"}}])
    monkeypatch.setattr(service, "_assess", lambda *args, **kwargs: [{
        "member_id": "TEST-DIGITAL-RULE", "pack_version_id": "TEST-PACK", "payload": {
            "scope": {"goal_types": ["general", "digital_inventory"]}}}])
    assert service._retrieve_for_intent("đào tạo nhân viên", intent, "2026-10-22") == []
    assert service._assess_for_intent({}, intent, "2026-10-22") == []


def response(text, previous=None):
    intent = interpret(text, previous=previous, task_hint="sales_inventory")
    intent["working_answers"] = working_answers(text, intent, (previous or {}).get("working_answers"))
    payload = {"intent": intent, "saved_context": {"entities": []}, "product": None, "attachments": []}
    return intent, next_steps(payload)


@pytest.mark.parametrize("text", [
    "Chị có nên nhập thêm hàng khi tồn kho còn 120 hộp?",
    "Có nên nhập thêm hàng?",
    "Chị muốn tính lượng đặt hàng bổ sung, tồn kho còn 120 hộp.",
    "Chị cần lên kế hoạch bổ sung hàng cho tuần tới.",
    "Khi nào chị nên đặt thêm hàng?",
    "Chị có nên lấy thêm trà về bán không?",
])
def test_restocking_is_a_decision_need_not_a_count_discrepancy(text):
    intent, steps = response(text)
    assert intent["primary"] == "digitize_operations" and intent["focus"] == "restocking_planning"
    assert intent["operation_topics"] == ["restocking_planning"]
    combined = " ".join(steps)
    assert "chưa" in combined and "nhập" in combined
    assert "bán" in combined and "giao" in combined
    assert "kiểm kê thực tế cùng thời điểm" not in combined
    assert "Bạn" not in combined if text.startswith("Chị") else True
    assert "book_quantity" not in intent["working_answers"]
    plan = business_plan(intent, {})
    assert {task["id"] for task in plan} == {"restocking_stock", "restocking_sales", "restocking_lead_time"}


def test_restocking_followup_keeps_context_without_repeating_already_known_stock():
    first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 120 hộp.")
    saved = copy.deepcopy(first)
    next_intent, steps = response("Bán 30 hộp mỗi tuần; nhà cung cấp giao sau 5 ngày.", saved)
    assert first == saved
    assert next_intent["focus"] == "restocking_planning"
    answers = next_intent["working_answers"]
    assert answers["available_quantity"] == 120 and answers["recent_sales_quantity"] == 30
    assert answers["sales_period"] == "tuần" and answers["supplier_lead_days"] == 5
    assert "120" in " ".join(steps)
    assert not any("cho biết lượng tồn" in item for item in steps)


def test_supplier_days_do_not_replace_sales_period_in_restocking_followup():
    first, _ = response("Chị có nên nhập thêm hàng? Tồn kho còn 120 hộp; bán 30 hộp mỗi tuần.")
    before = copy.deepcopy(first)
    after, _ = response("Nhà cung cấp giao trong 5 ngày.", first)
    assert first == before
    assert after["focus"] == "restocking_planning"
    assert after["working_answers"]["supplier_lead_days"] == 5
    assert after["working_answers"]["recent_sales_quantity"] == 30
    assert after["working_answers"]["sales_period"] == "tuần"


@pytest.mark.parametrize("text,expected", [
    ("Bán 45 hộp trong 7 ngày.", "7 ngày"),
    ("Bán 45 hộp mỗi tháng.", "tháng"),
    ("Nhà cung cấp giao trong 5 ngày, bán 45 hộp trong 7 ngày.", "7 ngày"),
    ("Bán 45 hộp trong 7 ngày; nhà cung cấp giao trong 5 ngày.", "7 ngày"),
    ("Bán 45 hộp, nhà cung cấp giao trong 5 ngày.", "tuần"),
])
def test_restocking_sales_period_updates_only_from_the_sales_clause(text, expected):
    first, _ = response("Chị có nên nhập thêm hàng? Bán 30 hộp mỗi tuần.")
    after, _ = response(text, first)
    assert after["working_answers"]["recent_sales_quantity"] == 45
    assert after["working_answers"]["sales_period"] == expected


def test_restocking_reload_and_followup_do_not_write_ssot_or_inherit_count_discrepancy(tmp_path):
    repo = CoreRepository(tmp_path / "restocking.sqlite3")
    owner = LocalAccounts(repo).register("restocking-owner", "Only-local-test-password", "Cơ sở QA")
    a, e = owner["account_id"], owner["enterprise_id"]
    conversation = ConversationService(IntakeService(repo))
    first = conversation.send(a, e, "Chị có nên nhập thêm hàng? Tồn kho còn 120 hộp.", [], "restocking-first")
    reopened_service = ConversationService(IntakeService(repo))
    reopened = reopened_service.get(a, e, first["id"])
    assert reopened["intake"]["intent"]["focus"] == "restocking_planning"
    followup = "Bán 30 hộp mỗi tuần; nhà cung cấp giao sau 5 ngày."
    after = reopened_service.send(a, e, followup, [], "restocking-followup", first["id"])
    intent = after["intake"]["intent"]
    assert intent["focus"] == "restocking_planning"
    assert intent["working_answers"]["available_quantity"] == 120
    assert intent["working_answers"]["recent_sales_quantity"] == 30
    assert intent["working_answers"]["supplier_lead_days"] == 5
    assert any(item["role"] == "user" and item["text"] == followup for item in after["messages"])
    assert repo.get_context(a, e)["fact_refs"] == []
    wrong_context = working_answers("Có nên nhập thêm hàng?", intent, {"book_quantity": 900, "physical_quantity": 700})
    assert "available_quantity" not in wrong_context and "book_quantity" not in wrong_context


@pytest.mark.parametrize("text", [
    "Chị không cần nhập thêm hàng; cần đối chiếu tồn sổ 120 hộp và thực tế 110 hộp.",
    "Chị chưa muốn đặt thêm hàng, chỉ muốn kiểm kê tồn kho.",
])
def test_rejected_restocking_does_not_replace_inventory_reconciliation(text):
    intent, steps = response(text)
    assert intent["focus"] == "inventory_accuracy"
    assert "restocking_planning" not in intent["operation_topics"]
    assert any("đối chiếu" in item or "kiểm đếm" in item for item in steps)


@pytest.mark.parametrize("text", [
    "Chị muốn nhập thêm dữ liệu vào Excel.",
    "Chị cần nhập thêm hàng vào Excel để ghi sổ.",
    "Chị đã nhập thêm hàng, muốn đối chiếu tồn kho.",
])
def test_recording_data_or_received_goods_is_not_restocking_advice(text):
    assert interpret(text, task_hint="sales_inventory")["focus"] != "restocking_planning"


def test_financing_request_still_stops_before_any_operating_plan():
    intent, steps = response("Chị muốn vay vốn để nhập thêm hàng.")
    assert intent["unsupported_request"] == "financing"
    assert business_plan(intent, {}) == []
    assert "chưa hỗ trợ tư vấn vay vốn" in " ".join(steps)
