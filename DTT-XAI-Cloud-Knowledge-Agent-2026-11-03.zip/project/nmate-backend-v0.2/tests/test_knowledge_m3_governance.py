"""Exact wiki governance, scoped rights, no model or fake human decisions."""
import json
from datetime import datetime,timedelta,timezone
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe,candidate,acquire
from nmate.v03.core import CoreError,now_iso
from nmate.knowledge_v1.governance import WikiGovernance
from nmate.knowledge_v1.operator_m3 import install_m3_on_clone


@pytest.fixture
def governed(pipe,tmp_path):
    repo,source,author,reviewer=pipe
    install_m3_on_clone(repo.db_path,backup_path=tmp_path/'before-m3.sqlite')
    g=WikiGovernance(repo)
    # Human permissions here are explicit synthetic test setup, never MAIN.
    with repo.connection(write=True) as db:
        for role in ('reviewer','publisher'):
            db.execute("INSERT INTO pol_knowledge_role_scopes VALUES(?,?,'hanoi_policy','TEST-POLICY','KB-TEST-A',?,?,NULL)",(reviewer,role,'TEST-ONLY',now_iso()))
        for cap in ('read','review','publish','attest'):
            db.execute('INSERT INTO pol_wiki_capabilities VALUES(?,?,?,?,?,NULL)',(reviewer,'TEST-POLICY','KB-TEST-A',cap,'TEST-ONLY'))
    # Clear the synthetic fixture gap through the ordinary curator config command.
    m=g.source_manifest(author,'KB-TEST-A')['manifest'];m['gaps']=[]
    g.configure_source(author,'KB-TEST-A',expected_version=1,manifest=m,operation_id='config-complete-test')
    a=acquire((repo,g,author,reviewer),version=2)
    ex=g.extract_local(author,a['rendition_id'],operation_id='extract-test')
    ref=g.pipeline_evidence(author,ex['chunks'][0]['id'],'Training for enterprises.')
    body='Training for enterprises.'
    page=g.create_candidate(author,policy_id='TEST-POLICY',title='TEST ONLY',body=body,
        claims=[{'kind':'source_excerpt','start':0,'end':len(body),'text':body,'evidence':[ref]}],aliases=[],links=[],operation_id='create-governed')
    return repo,g,author,reviewer,page


def attest(env):
    _,g,_,reviewer,p=env
    return g.attest_source(reviewer,p['policy_id'],'KB-TEST-A',expected_source_version=3,
        complete=True,legal_currency_confirmed=True,current_until=(datetime.now(timezone.utc)+timedelta(hours=12)).isoformat(),
        rationale='SYNTHETIC verification only, no real policy',operation_id='attest-source-test')


def review(env,op='review-test'):
    _,g,_,reviewer,p=env
    value=g.workbench(reviewer,p['page_id'])
    return g.review_wiki(reviewer,p['page_id'],expected_version=p['version'],revision_id=p['revision_id'],
        expected_manifest_hash=value['review_manifest_hash'],approve=True,
        rationale='SYNTHETIC expert test, not an actual policy review',operation_id=op)


def test_scoped_reviewer_can_read_without_becoming_global_curator(governed):
    repo,g,_,reviewer,p=governed
    assert g.workbench(reviewer,p['page_id'])['candidate']['body']==p['body']
    with repo.connection() as db:
        assert not db.execute("SELECT 1 FROM pol_knowledge_roles WHERE account_id=? AND role IN ('curator','admin')",(reviewer,)).fetchone()
    with pytest.raises(CoreError):
        g.configure_source(reviewer,'KB-TEST-A',expected_version=3,manifest={},operation_id='forbidden-curation')


def test_two_steps_bind_exact_revision_and_source_manifest(governed):
    _,g,_,reviewer,p=governed
    with pytest.raises(CoreError): review(governed)
    attest(governed);r=review(governed)
    released=g.publish_wiki(reviewer,p['page_id'],revision_id=p['revision_id'],review_event_id=r['review_event_id'],
        expected_manifest_hash=r['review_manifest_hash'],rationale='SYNTHETIC release only',operation_id='publish-test')
    assert released['publication_state']=='published'
    w=g.workbench(reviewer,p['page_id'])
    assert w['governance']['review_state']=='approved' and w['governance']['publication_state']=='published'
    assert w['candidate']['assessment_eligible'] is False


def test_edit_after_review_never_publishes_under_old_approval(governed):
    _,g,author,reviewer,p=governed
    attest(governed);r=review(governed)
    g.edit_candidate(author,p['page_id'],expected_version=1,expected_revision_id=p['revision_id'],
        title='Changed',body=p['body'],claims=p['claims'],aliases=[],links=[],operation_id='edit-after-review')
    with pytest.raises(CoreError):
        g.publish_wiki(reviewer,p['page_id'],revision_id=p['revision_id'],review_event_id=r['review_event_id'],
            expected_manifest_hash=r['review_manifest_hash'],rationale='Wrong old hash',operation_id='wrong-publish')


def test_source_change_and_revoke_recheck_before_publish(governed):
    _,g,author,reviewer,p=governed
    attest(governed);r=review(governed)
    acquire((g.repo,g,author,reviewer),raw=b'Changed source with exception.',version=3,operation='changed-source')
    with pytest.raises(CoreError):
        g.publish_wiki(reviewer,p['page_id'],revision_id=p['revision_id'],review_event_id=r['review_event_id'],
            expected_manifest_hash=r['review_manifest_hash'],rationale='Old source',operation_id='source-publish')


def test_review_receipt_replay_after_role_revoke_but_new_write_denied(governed):
    repo,g,_,reviewer,p=governed
    attest(governed);result=review(governed)
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_wiki_capabilities SET revoked_at=? WHERE account_id=? AND capability='review'",(now_iso(),reviewer))
    assert review(governed)==result
    with pytest.raises(CoreError): review(governed,'new-review')


def test_review_and_outbox_receipt_are_atomic(governed):
    repo,g,_,_,p=governed
    attest(governed)
    with repo.connection() as db: before=list(db.iterdump())
    def crash(point):
        if point=='after_review_before_receipt': raise RuntimeError('TEST crash')
    g.fault_hook=crash
    with pytest.raises(RuntimeError): review(governed)
    with repo.connection() as db: assert list(db.iterdump())==before
    g.fault_hook=None
    assert review(governed)['review_state']=='approved'


def test_buffer_survives_reload_conflict_and_is_actor_scoped(governed):
    repo,g,author,reviewer,p=governed
    payload={k:p[k] for k in ('title','body','claims','aliases','links')};payload['body']='Unfinished personal draft'
    g.save_buffer(author,p['page_id'],base_revision_id=p['revision_id'],expected_ui_revision=0,payload=payload,operation_id='save-buffer')
    reread=WikiGovernance(repo).workbench(author,p['page_id'])
    assert json.loads(reread['editor_buffer']['payload_json'])['body']==payload['body']
    assert g.workbench(reviewer,p['page_id'])['editor_buffer'] is None
    with pytest.raises(CoreError): g.save_buffer(author,p['page_id'],base_revision_id=p['revision_id'],expected_ui_revision=0,payload=payload,operation_id='stale-buffer')
    assert g.get_candidate(author,p['page_id'])['body']==p['body']


def test_withdraw_is_causal_and_preserves_readable_history(governed):
    _,g,_,reviewer,p=governed
    attest(governed);r=review(governed)
    released=g.publish_wiki(reviewer,p['page_id'],revision_id=p['revision_id'],review_event_id=r['review_event_id'],expected_manifest_hash=r['review_manifest_hash'],rationale='TEST',operation_id='pub-withdraw')
    result=g.withdraw_wiki(reviewer,p['page_id'],expected_release_id=released['release_event_id'],rationale='TEST withdrawn',operation_id='withdraw-test')
    assert g.workbench(reviewer,p['page_id'])['governance']['publication_state']=='withdrawn'
    assert g.withdraw_wiki(reviewer,p['page_id'],expected_release_id=released['release_event_id'],rationale='TEST withdrawn',operation_id='withdraw-test')==result
    assert g.get_candidate(reviewer,p['page_id'])['body']==p['body']


def test_publisher_revocation_blocks_release_and_source_revocation_blocks_read(governed):
    repo,g,author,reviewer,p=governed
    attest(governed);r=review(governed)
    with repo.connection(write=True) as db: db.execute("UPDATE pol_knowledge_role_scopes SET revoked_at=? WHERE account_id=? AND role='publisher'",(now_iso(),reviewer))
    with pytest.raises(CoreError):
        g.publish_wiki(reviewer,p['page_id'],revision_id=p['revision_id'],review_event_id=r['review_event_id'],expected_manifest_hash=r['review_manifest_hash'],rationale='TEST',operation_id='revoked-pub')
    g.set_source_rights(author,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,reason='TEST revoke',operation_id='revoke-gov')
    with pytest.raises(CoreError): g.workbench(reviewer,p['page_id'])
    assert g.queue(reviewer)==[]


def test_corrupt_review_envelope_is_not_trusted(governed):
    repo,g,_,reviewer,p=governed
    attest(governed);r=review(governed)
    # Synthetic corruption injection; no raw SQL capability is exposed by app.
    with repo.connection(write=True) as db:
        db.execute('DROP TRIGGER pol_wiki_reviews_immutable')
        db.execute("UPDATE pol_wiki_reviews SET rationale='corrupted' WHERE id=?",(r['review_event_id'],))
        from nmate.knowledge_v1.schema_m3 import GOV_TRIGGERS
        db.execute(GOV_TRIGGERS['pol_wiki_reviews_immutable'][1])
    with pytest.raises(CoreError): g.workbench(reviewer,p['page_id'])
