"""Natural declarations keep enterprise, product identity and ingredients separate."""
import copy

import pytest

from nmate.v04.extraction import extract_product_text
from nmate.v04.product_binding import declared_product_name
from test_unified_main import setup as setup, scope
from test_v04_intake import confirm


TEXT = "Cơ sở Trà sen Quảng An của chị đang bán khoảng 300 hộp trà mỗi tháng. Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSB01, thành phần trà xanh và hoa sen. Hãy bóc tách đúng tên cơ sở và tên sản phẩm thành nháp riêng; chị chưa đồng ý sửa hồ sơ đã có."
EXPECTED = {"name": "Trà sen Tây Hồ ướp bông", "packaging": "hộp", "net_quantity": "100 g", "product_code": "TSB01", "ingredients": "trà xanh và hoa sen"}


def test_real_natural_question_does_not_treat_ingredients_as_another_product():
    facts = extract_product_text(TEXT)
    assert {fact["field"]: fact["value"] for fact in facts} == EXPECTED
    assert declared_product_name(TEXT) == "Trà sen Tây Hồ ướp bông"
    for fact in facts:
        source = fact["source"]
        assert source["quote"] in TEXT and source["value_quote"] in source["quote"]
        assert TEXT[source["start_offset"]:source["end_offset"]].strip() == source["quote"]
        assert source["review_state"] == "owner_confirmation_required"


@pytest.mark.parametrize("text", [
    "Sản phẩm Trà Sen Tây Hồ, thành phần trà xanh và hoa sen.",
    "Hỏi FDA cho Trà Sen Tây Hồ, thành phần trà xanh và hoa sen.",
])
def test_food_words_inside_explicit_ingredients_span_cannot_be_product_names(text):
    facts = extract_product_text(text)
    assert {fact["field"]: fact["value"] for fact in facts} == {"name": "Trà Sen Tây Hồ", "ingredients": "trà xanh và hoa sen"}


@pytest.mark.parametrize("text", ["Chị không có Trà sen Tây Hồ, hộp 100 g.",
    "Ví dụ chị có Trà sen Tây Hồ, hộp 100 g.", "Nếu chị có Trà sen Tây Hồ, hộp 100 g."])
def test_natural_declaration_still_rejects_negation_and_hypothetical_scope(text):
    assert extract_product_text(text) == []


def test_main_natural_free_draft_is_new_product_not_shorter_saved_tea(setup):
    repo, owner, _, model, provider, _, intake, chats = setup
    initial = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Trà Sen Tây Hồ; khối lượng tịnh: 200 g", "original-tea-for-natural")
    old_tea = confirm(intake, owner, initial["intake"])["product"]["id"]
    before = copy.deepcopy(repo.get_context(*scope(owner)))
    drafted = chats.prepare_chat_draft(*scope(owner), TEXT, "natural-ingredients-draft", product_entity_id=old_tea)
    item = drafted["intake"]
    assert item["status"] == "awaiting_confirmation" and item["product"]["id"] == "new_product"
    assert item["product"]["name"] == EXPECTED["name"]
    product_facts = [fact for fact in item["candidates"] if fact["entity_type"] == "product"]
    company_facts = [fact for fact in item["candidates"] if fact["entity_type"] == "enterprise"]
    assert {fact["field"]: fact["value"] for fact in product_facts} == EXPECTED
    assert all(fact["entity_id"] == "new_product" for fact in product_facts)
    assert len(company_facts) == 1
    assert company_facts[0]["field"] == "trading_name" and company_facts[0]["value"] == "Trà sen Quảng An"
    assert company_facts[0]["entity_id"] == "new_enterprise"
    assert company_facts[0]["source"]["quote"] == "Cơ sở Trà sen Quảng An"
    assert item["product_binding"]["state"] == "new_product_draft"
    assert old_tea not in item["reused_context"]["entity_ids"]
    assert old_tea not in {entity["id"] for entity in item["saved_context"]["entities"]}
    loaded = chats.get(*scope(owner), drafted["id"])
    assert loaded["intake"]["candidates"] == item["candidates"]
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    assert model.calls == [] and provider.summary()["paid_calls"] == 0
