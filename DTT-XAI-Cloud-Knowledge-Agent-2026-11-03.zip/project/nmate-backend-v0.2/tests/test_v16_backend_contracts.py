"""V16: typed unsupported answers and distinct stock observations, no paid IO."""
import copy

import pytest

from nmate.v03.core import CoreError
from nmate.v04.dialogue import interpret, next_steps, working_answers
from nmate.v03.intent_plan import compile_dialogue_plan
from nmate.v04.extraction import validate_attachment
from test_residual_six_pdf_rejection import local_document_workspace, expected_rejection  # noqa: F401 - registers pytest fixture
from test_workspace_management import attachment, pdf_bytes, scope
from test_policy_intent_scope_regressions import policy, prepare  # noqa: F401 - registers pytest fixture


def local_reply(text, previous=None):
    intent = interpret(text, previous=previous, task_hint='sales_inventory')
    intent['working_answers'] = working_answers(text, intent, (previous or {}).get('working_answers'))
    return intent, next_steps({'intent': intent, 'saved_context': {'entities': []}, 'product': None})


@pytest.mark.parametrize('text', [
    'Chị tháng 9 bán 120 hộp, tồn 30 hộp.',
    'Tháng 9 bán được 120 hộp; tồn kho còn 30 hộp.',
    'Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp và tồn 30 hộp.',
])
def test_sales_preserves_distinct_unconfirmed_stock_and_never_assumes_period(text):
    intent, steps = local_reply(text)
    slots = intent['working_answers']
    assert intent['focus'] == 'sales_reporting'
    assert slots['recent_sales_quantity'] == 120 and slots['sales_period'] == 'tháng 9'
    assert slots['reported_stock_quantity'] == 30 and slots['reported_stock_unit'] == 'hộp'
    assert slots['reported_stock_quote'] in text
    assert '30 hộp' in steps[0] and '120 hộp' in steps[0]
    assert 'tồn cuối tháng 9' not in ' '.join(steps).lower()
    plan = compile_dialogue_plan(intent, text)
    assert plan['intent']['known_inputs']['reported_stock_quantity'] == 30


def test_sales_stock_units_and_zero_do_not_overwrite_sales_quantity_or_unit():
    intent, steps = local_reply('Chị tháng 9 bán 120 hộp, tồn 0 kg.')
    assert intent['working_answers']['reported_stock_quantity'] == 0
    assert intent['working_answers']['reported_stock_unit'] == 'kg'
    assert intent['working_answers']['quantity_unit'] == 'hộp'
    assert 'số tồn 0 kg' in steps[0] and 'số tồn 0 hộp' not in steps[0]


def test_sales_stock_followup_and_reopened_context_remain_working_only():
    first, _ = local_reply('Chị tháng 9 bán 120 hộp, tồn 30 hộp.')
    before = copy.deepcopy(first)
    again, steps = local_reply('Tồn kho còn 25 hộp.', copy.deepcopy(first))
    assert first == before
    assert again['focus'] == 'sales_reporting'
    assert again['working_answers']['recent_sales_quantity'] == 120
    assert again['working_answers']['reported_stock_quantity'] == 25
    assert '25 hộp' in steps[0]
    changed, _ = local_reply('Chị muốn cập nhật hồ sơ doanh nghiệp.', again)
    assert 'reported_stock_quantity' not in changed['working_answers']


def test_sales_and_stock_reopen_from_private_sql_without_changing_ssot(tmp_path):
    from nmate.v03.core import CoreRepository
    from nmate.v03.identity import LocalAccounts
    from nmate.v04.conversations import ConversationService
    from nmate.v04.intake import IntakeService
    repo = CoreRepository(tmp_path / 'v16-sales-reload.sqlite3')
    owner = LocalAccounts(repo).register('v16-sales-stock', 'fixture-only-password', 'Cơ sở QA')
    account, enterprise = owner['account_id'], owner['enterprise_id']
    before = repo.get_context(account, enterprise)
    chat = ConversationService(IntakeService(repo))
    value = chat.send(account, enterprise, 'Chị tháng 9 bán 120 hộp, tồn 30 hộp.', [], 'v16-sales-stock-001')
    reopened = ConversationService(IntakeService(repo)).get(account, enterprise, value['id'])
    assert reopened['intake']['intent']['working_answers']['reported_stock_quantity'] == 30
    assert 'số tồn 30 hộp' in reopened['intake']['assistant_text']
    assert not reopened['intake']['candidates']
    after = repo.get_context(account, enterprise)
    assert {key: item for key, item in before.items() if key != 'as_of'} == {key: item for key, item in after.items() if key != 'as_of'}


def test_existing_live_envelope_can_retain_locally_grounded_stock_without_schema_change():
    from test_residual_six_live_sales_contract import envelope, request
    from nmate.v04.live_review import validate_output
    text = 'Chị tháng 9 bán 120 hộp, tồn 30 hộp.'
    _output, slots = validate_output(envelope(text), request(text))
    assert slots['recent_sales_quantity'] == 120 and slots['reported_stock_quantity'] == 30


@pytest.mark.parametrize('stock', [
    'dự kiến tồn 30 hộp', 'chưa tồn 30 hộp', 'mục tiêu tồn 30 hộp',
    'nếu tồn 30 hộp thì sao', 'tồn trên sổ 30 hộp',
    'tồn đầu kỳ 30 hộp', 'tồn kho 30 hộp; tồn kho 40 hộp',
])
def test_other_stock_roles_forecasts_and_ambiguous_counts_are_not_current_stock(stock):
    intent, _ = local_reply('Chị tháng 9 bán 120 hộp; ' + stock)
    assert 'reported_stock_quantity' not in intent['working_answers']


@pytest.mark.parametrize(('question', 'kind'), [
    ('Ngày mai thời tiết Hà Nội thế nào?', 'weather'),
    ('Chị muốn hỏi cá độ bóng đá.', 'gambling'),
    ('Có nên đánh bạc không?', 'gambling'),
])
def test_unsupported_policy_has_typed_reason_no_generic_digital_question(policy, question, kind):  # noqa: F811 - pytest injects the imported fixture
    result = prepare(policy, question)
    assert result['intent']['request_scope'] == result['result_status'] == 'unsupported'
    assert result['intent']['unsupported_request'] == kind
    assert result['intent']['unsupported_reason_vi']
    assert result['intent']['clarification_vi'] is None
    assert result['lead_vi'].startswith(result['intent']['unsupported_reason_vi'])
    assert result['sources'] == result['outcomes'] == [] and not result['startable']
    assert result['provider_calls'] == 0


def test_supported_policy_goal_is_not_erased_by_unrelated_unsupported_part(policy):  # noqa: F811 - pytest injects the imported fixture
    result = prepare(policy, 'Chị cần hỗ trợ đào tạo nhân viên; ngày mai thời tiết thế nào?')
    assert result['intent']['request_scope'] == 'in_scope'
    coverage = {item['goal']: item for item in result['goal_coverage']}
    assert coverage['workforce_training']['status'] == 'needs_source'
    assert coverage['weather']['status'] == 'unsupported'


@pytest.mark.parametrize('raw', [b'PK\x03\x04Excel renamed PDF', b'%PDF-1.7\nnot PDF structure'])
def test_invalid_pdf_message_names_exact_failed_attachment(workspace, raw):
    _app, service, owner, _ = workspace
    with pytest.raises(CoreError) as rejected:
        service.prepare_document(*scope(owner), 'Chị đọc tệp.',
            [attachment(pdf_bytes(['Tên sản phẩm: Bột sen']), 'good.pdf'), attachment(raw, 'bad-v16.pdf')],
            'v16-pdf-rejection-001')
    assert 'bad-v16.pdf' in str(rejected.value)
    assert 'good.pdf' not in str(rejected.value)
    assert rejected.value.details == expected_rejection(raw, 'v16-pdf-rejection-001', 1, 2)


def test_direct_signature_rejection_names_file_without_leaking_contents():
    with pytest.raises(CoreError) as rejected:
        validate_attachment(attachment(b'PK\x03\x04private-content', 'wrong-kind.pdf'))
    assert 'wrong-kind.pdf' in str(rejected.value)
    assert 'private-content' not in str(rejected.value)


@pytest.mark.asyncio
@pytest.mark.parametrize('paid', [False, True])
async def test_csv_has_specific_named_error_before_any_operation_or_model(workspace, paid):
    import base64
    from test_review_commands_v2 import data_snapshot
    app, service, owner, _ = workspace
    csv = {'filename': 'so-ban-v16.csv', 'media_type': 'text/csv',
           'data_base64': base64.b64encode(b'product,quantity\nTS,120\n').decode()}
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as rejected:
        if paid:
            await service.conversations.send_async(*scope(owner), 'Chị đọc số bán.', [csv],
                'v16-csv-paid-0001', paid_consent=True, task_hint='sales_inventory')
        else:
            service.prepare_document(*scope(owner), 'Chị đọc số bán.', [csv], 'v16-csv-free-0001')
    assert rejected.value.code == 'unsupported_attachment'
    assert 'so-ban-v16.csv' in str(rejected.value) and 'CSV' in str(rejected.value)
    assert '.xlsx' in str(rejected.value)
    assert 'PNG/JPEG' not in str(rejected.value)
    assert data_snapshot(app.state.repo) == before
