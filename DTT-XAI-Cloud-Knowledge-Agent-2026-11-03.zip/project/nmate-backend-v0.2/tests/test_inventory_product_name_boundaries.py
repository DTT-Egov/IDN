"""Operational text following a product reference cannot rename its SSOT dossier."""
import copy

import pytest

from nmate.v04.extraction import extract_product_text
from nmate.v04.product_binding import declared_product_name
from test_unified_main import setup as setup, scope
from test_v04_intake import confirm


INVENTORY = "Chị kiểm kê Trà Sen Tây Hồ: tồn trên sổ 120 hộp, đếm thực tế 110 hộp. Chị nên đối chiếu gì trước, chưa rõ nguyên nhân lệch?"


@pytest.mark.parametrize("text", [INVENTORY, INVENTORY.replace(":", "："), INVENTORY.replace(": ", " "),
    "Chị kiểm kê Trà Sen Tây Hồ thực tế 110 hộp, tồn trên sổ 120 hộp.",
    "Tên sản phẩm: Trà Sen Tây Hồ: tồn trên sổ 120 hộp, đếm thực tế 110 hộp."])
def test_inventory_reference_stops_before_count_clause(text):
    facts = extract_product_text(text)
    assert declared_product_name(text) == "Trà Sen Tây Hồ"
    # DF-006/008: an operational reference resolves existing context; it is not
    # an owner assertion of a new name. The explicit caption remains a proposal.
    assert {fact["field"]: fact["value"] for fact in facts} == (
        {"name": "Trà Sen Tây Hồ"} if text.startswith("Tên sản phẩm:") else {})
    reference = extract_product_text(text, include_product_references=True)
    source = next(fact["source"] for fact in reference if fact["field"] == "name")
    assert source["quote"] in text and source["value_quote"] == "Trà Sen Tây Hồ"
    assert text[source["start_offset"]:source["end_offset"]].strip() == source["quote"]
    assert source["review_state"] == "owner_confirmation_required"


def test_free_inventory_reuses_exact_confirmed_identity_without_rename_candidate(setup):
    repo, owner, _, model, provider, _, intake, chats = setup
    initial = chats.prepare_chat_draft(*scope(owner), "Tên sản phẩm: Trà Sen Tây Hồ", "known-tea-for-inventory")
    pid = confirm(intake, owner, initial["intake"])["product"]["id"]
    before = copy.deepcopy(repo.get_context(*scope(owner)))
    sent = chats.prepare_chat_draft(*scope(owner), INVENTORY, "inventory-colon-boundary", product_entity_id=pid,
                                    task_hint="sales_inventory")
    item = sent["intake"]
    assert item["product"]["id"] == pid and item["product"]["name"] == "Trà Sen Tây Hồ"
    names = [candidate for candidate in item["candidates"] if candidate["field"] == "name"]
    assert names == []  # referencing a confirmed product cannot propose a name
    assert not any(candidate["status"] in {"candidate", "conflict"} for candidate in item["candidates"])
    assert item["intent"]["working_answers"]["book_quantity"] == 120
    assert item["intent"]["working_answers"]["physical_quantity"] == 110
    restored = chats.get(*scope(owner), sent["id"])
    assert restored["intake"]["candidates"] == item["candidates"]
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    assert model.calls == [] and provider.summary()["paid_calls"] == 0


def test_natural_tea_declaration_still_preserves_case_and_separate_package_weight():
    text = "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TS-UPB-100. Chị muốn đi Mỹ."
    facts = extract_product_text(text)
    assert {fact["field"]: fact["value"] for fact in facts} == {
        "name": "Trà sen Tây Hồ ướp bông", "packaging": "hộp", "net_quantity": "100 g", "product_code": "TS-UPB-100"}
    assert all(fact["source"]["quote"] in text for fact in facts)
