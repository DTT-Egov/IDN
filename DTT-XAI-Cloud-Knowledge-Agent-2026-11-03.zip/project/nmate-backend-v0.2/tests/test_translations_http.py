"""Translation display is a local, authorized read of an immutable artifact.

Reference/model translation fidelity is tested in the shipment translation suite.
These tests deliberately inject a TEST translation and never use a model or web.
"""
import json

import pytest
from fastapi.testclient import TestClient

from nmate.app import create_app
from nmate.auth import LOCAL_PRINCIPAL
from nmate.config import Settings
from nmate.models import Principal


@pytest.fixture
def translation_api(tmp_path, monkeypatch):
    from nmate.agents.shipment import translations

    calls = []

    def display(report):
        calls.append(report)
        return [{"evidence_id": "TEST-EVIDENCE", "title_vi": "Nguồn THỬ",
                 "excerpt_vi": "Bản dịch THỬ, không phải nguồn nghiệp vụ.", "publisher_vi": "THỬ",
                 "translation": {"language": "vi", "status": "draft_reference", "method": "reference_catalog"}}]

    monkeypatch.setattr(translations, "evidence_display_translations", display)
    app = create_app(Settings(_env_file=None, data_dir=tmp_path, mode="evidence_only",
                              OPENAI_API_KEY=None, ANTHROPIC_API_KEY=None))
    # No lifespan/worker is started. Test data is inserted through real Store transactions.
    client = TestClient(app, base_url="http://127.0.0.1:8022")
    yield app, client, calls
    client.close()


def saved_artifact(store, principal):
    case = store.create_case(principal, {"product": {"sku": "TEST-TRANSLATION", "name": "Miến THỬ",
                                       "family": "dry_food", "origin_country": "VN"},
                                       "shipment": {"target_market": "US", "route": "importer"},
                                       "consent_research": True, "consent_model": False})
    run = store.start(principal, {"case_id": case["case_id"], "expected_case_version": 1,
                                 "idempotency_key": "TEST-TRANSLATION-REQUEST", "question": "THỬ"},
                      mode="evidence_only", max_active=5, max_daily=30)
    assert store.claim("TEST-OWNER")["run_id"] == run["run_id"]
    store.finish(run["run_id"], "TEST-OWNER", report={"evidence": [{"id": "TEST-EVIDENCE",
                 "url": "https://www.fda.gov/TEST", "excerpt": "TEST original English, not an actual source."}]})
    return store.get_artifact(principal, store.get_run(principal, run["run_id"])["artifact_id"])


def test_translation_endpoint_requires_session_before_reading(translation_api):
    app, client, calls = translation_api
    artifact = saved_artifact(app.state.store, LOCAL_PRINCIPAL)
    assert client.get(f"/api/artifacts/{artifact['artifact_id']}/translations").status_code == 401
    assert not calls


def test_translation_endpoint_preserves_original_hash_and_data(translation_api):
    app, client, calls = translation_api
    client.get("/api/session")
    owner = app.state.auth.device_principal(client.cookies.get("nmate_device"))
    artifact = saved_artifact(app.state.store, owner)
    before = json.dumps(artifact, sort_keys=True)
    client.get("/api/session")
    response = client.get(f"/api/artifacts/{artifact['artifact_id']}/translations")
    assert response.status_code == 200
    body = response.json()
    assert body["artifact_id"] == artifact["artifact_id"]
    assert body["content_sha256"] == artifact["content_sha256"]
    assert body["evidence_translations"][0]["evidence_id"] == "TEST-EVIDENCE"
    assert "report" not in body and "snapshot" not in body and "tenant_id" not in body
    assert response.headers["cache-control"] == "no-store"
    assert len(calls) == 1
    after = app.state.store.get_artifact(owner, artifact["artifact_id"])
    assert json.dumps(after, sort_keys=True) == before


def test_translation_endpoint_rechecks_tenant_and_does_not_disclose(translation_api):
    app, client, calls = translation_api
    foreign = Principal("TEST-FOREIGN-TENANT", "TEST-FOREIGN-SUBJECT", "business")
    artifact = saved_artifact(app.state.store, foreign)
    client.get("/api/session")
    response = client.get(f"/api/artifacts/{artifact['artifact_id']}/translations")
    assert response.status_code == 404
    assert "TEST original" not in response.text and "Nguồn THỬ" not in response.text
    assert not calls


def test_translation_endpoint_missing_result_does_not_translate(translation_api):
    _, client, calls = translation_api
    client.get("/api/session")
    assert client.get("/api/artifacts/TEST-MISSING/translations").status_code == 404
    assert not calls
