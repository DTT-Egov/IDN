"""M1 contracts: synthetic public corpus only, no provider/network/live DB.

DF-013/014/027/029/033/043/044/046/048/049.
"""
import hashlib
import sqlite3

import pytest

from nmate.v03.core import CoreError, CoreRepository, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.policy_v1 import KnowledgeCatalog
from nmate.knowledge_v1.service import KnowledgeService
from nmate.knowledge_v1.operator import install_on_clone


@pytest.fixture
def kb(tmp_path):
    repo = CoreRepository(tmp_path / 'knowledge-test.sqlite')
    accounts = LocalAccounts(repo)
    owner = accounts.register('kb_author', 'synthetic-password-123', 'TEST ONLY')
    other = accounts.register('kb_other', 'synthetic-password-456', 'TEST ONLY B')
    catalog = KnowledgeCatalog(repo)
    actor = owner['account_id']
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)",
                   (actor, 'synthetic-fixture', now_iso()))
    catalog.register_source(actor, 'KB-TEST-A', 'TEST ONLY source', 'TEST ONLY',
                            'https://hanoi.gov.vn/test-only/kb-a')
    raw = 'TEST ONLY — public source. Training is a separate topic. No actual policy.'
    snapshot = catalog.add_snapshot(actor, 'KB-TEST-A', raw.encode(), raw)
    with repo.connection() as db:
        chunk = dict(db.execute('SELECT * FROM pol_chunks WHERE snapshot_id=?',
                                (snapshot['snapshot_id'],)).fetchone())
    install_on_clone(repo.db_path, backup_path=tmp_path / 'before-kb.sqlite')
    service = KnowledgeService(repo)
    service.set_source_rights(actor, 'KB-TEST-A', expected_version=0, allow_read=True,
                              allow_export=True, reason='Synthetic public source', operation_id='rights-1')
    ref = service.evidence_ref(actor, chunk['id'], raw)
    return repo, service, actor, other['account_id'], ref


def create(kb, op='create-1', **extra):
    _, service, actor, _, ref = kb
    return service.create_page(actor, policy_id='TEST-POLICY', title='TEST ONLY topic',
                               body='# TEST ONLY\n\nTraining topic.', evidence=[ref], operation_id=op, **extra)


def test_create_edit_history_preserves_raw_markdown_and_causal_parent(kb):
    repo, service, actor, _, ref = kb
    first = create(kb)
    second = service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'],
        expected_version=1, title='TEST ONLY renamed', body='## New\n\nCase Preserved.\n',
        evidence=[ref], operation_id='edit-1')
    assert second['version'] == 2
    assert second['parent_revision_id'] == first['revision_id']
    assert service.get_page(actor, first['page_id'], revision_id=first['revision_id'])['body'] == first['body']
    assert service.get_page(actor, first['page_id'])['body'] == '## New\n\nCase Preserved.\n'
    assert second['body_hash'] == hashlib.sha256(second['body'].encode()).hexdigest()
    with repo.connection() as db:
        assert db.execute('SELECT count(*) FROM kp_wiki_revisions').fetchone()[0] == 2
        assert db.execute('SELECT count(*) FROM kp_pipeline_outbox').fetchone()[0] >= 2


def test_constructor_read_does_not_initialize_or_mutate(kb):
    repo, _, _, _, _ = kb
    with repo.connection() as db:
        before = list(db.iterdump())
    KnowledgeService(repo)
    with repo.connection() as db:
        assert list(db.iterdump()) == before


def test_constructor_missing_schema_refuses_without_creating_tables(tmp_path):
    repo = CoreRepository(tmp_path / 'missing.sqlite')
    KnowledgeCatalog(repo)
    with pytest.raises(CoreError, match='schema|Schema|khởi tạo'):
        KnowledgeService(repo)
    with repo.connection() as db:
        assert not db.execute("SELECT name FROM sqlite_master WHERE name LIKE 'kp_%'").fetchall()


def test_exact_replay_before_write_cas_and_lifecycle(kb):
    repo, service, actor, _, ref = kb
    first = create(kb)
    archived = service.archive_page(actor, first['page_id'], expected_version=1, operation_id='archive-1')
    assert archived['lifecycle'] == 'archived'
    with repo.connection(write=True) as db:
        db.execute('UPDATE pol_knowledge_roles SET revoked_at=? WHERE account_id=?', (now_iso(), actor))
    assert create(kb) == first
    assert service.get_page(actor, first['page_id'])['body'] == first['body']
    with pytest.raises(CoreError) as exc:
        service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'],
            expected_version=1, title='Changed', body='Changed', evidence=[ref], operation_id='new-edit')
    assert exc.value.status_code in (403, 409)


def test_replay_identity_conflict_does_not_reconstruct_current_defaults(kb):
    _, service, actor, _, ref = kb
    first = create(kb)
    service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'], expected_version=1,
                      title='Different current title', body='Different body', evidence=[ref], operation_id='e1')
    assert create(kb) == first
    with pytest.raises(CoreError) as exc:
        service.create_page(actor, policy_id='OTHER-POLICY', title='TEST ONLY topic',
                            body='# TEST ONLY\n\nTraining topic.', evidence=[ref], operation_id='create-1')
    assert exc.value.code == 'idempotency_conflict'


def test_source_rights_revoke_wins_creator_and_receipt(kb):
    _, service, actor, _, ref = kb
    first = create(kb)
    service.set_source_rights(actor, 'KB-TEST-A', expected_version=1, allow_read=False,
                              allow_export=False, reason='Revoked', operation_id='rights-2')
    for read in [lambda: service.get_page(actor, first['page_id']), lambda: create(kb),
                 lambda: service.evidence_ref(actor, ref['chunk_id'], ref['quote'])]:
        with pytest.raises(CoreError) as exc:
            read()
        assert exc.value.status_code == 403


def test_unavailable_source_is_not_read_revoke(kb):
    repo, service, actor, _, _ = kb
    first = create(kb)
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_source_gates SET availability='unavailable' WHERE source_id='KB-TEST-A'")
    assert service.get_page(actor, first['page_id'])['body'] == first['body']


def test_other_account_cannot_read_draft_or_guess_revision(kb):
    _, service, _, other, _ = kb
    first = create(kb)
    with pytest.raises(CoreError) as exc:
        service.get_page(other, first['page_id'], revision_id=first['revision_id'])
    assert exc.value.status_code in (403, 404)


def test_cas_conflict_preserves_both_original_and_committed_revision(kb):
    repo, service, actor, _, ref = kb
    first = create(kb)
    service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'], expected_version=1,
                      title='First editor', body='Committed', evidence=[ref], operation_id='edit-a')
    with pytest.raises(CoreError) as exc:
        service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'], expected_version=1,
                          title='Second editor', body='Not committed', evidence=[ref], operation_id='edit-b')
    assert exc.value.status_code == 409
    with repo.connection() as db:
        assert db.execute('SELECT count(*) FROM kp_wiki_revisions').fetchone()[0] == 2


@pytest.mark.parametrize('kind', ['enterprise_fact', 'private_file', 'wiki_revision', 'unknown'])
def test_public_writer_rejects_private_or_self_referential_evidence(kb, kind):
    _, service, actor, _, _ = kb
    with pytest.raises(CoreError):
        service.create_page(actor, policy_id='TEST-POLICY', title='TEST', body='TEST',
                            evidence=[{'kind': kind, 'id': 'secret'}], operation_id='bad-ref')


def test_corrupt_quote_hash_and_parent_page_are_rejected(kb):
    _, service, actor, _, ref = kb
    with pytest.raises(CoreError):
        service.create_page(actor, policy_id='TEST-POLICY', title='TEST', body='TEST',
                            evidence=[{**ref, 'quote_hash': '0' * 64}], operation_id='bad-quote')


def test_immutable_sql_rows_cannot_be_changed_or_deleted(kb):
    repo, _, _, _, _ = kb
    create(kb)
    for table in ['kp_wiki_revisions', 'kp_knowledge_operations', 'kp_knowledge_events', 'kp_source_rights_events']:
        with pytest.raises(sqlite3.DatabaseError), repo.connection(write=True) as db:
            db.execute('DELETE FROM '+table)
    with pytest.raises(sqlite3.DatabaseError), repo.connection(write=True) as db:
        db.execute("UPDATE kp_wiki_revisions SET body='changed'")


def test_transaction_fault_rolls_back_page_revision_event_outbox_receipt(kb):
    repo, service, actor, _, ref = kb
    with repo.connection() as db:
        before = list(db.iterdump())
    def fault(point):
        if point == 'before_receipt':
            raise RuntimeError('synthetic crash')
    service.fault_hook = fault
    with pytest.raises(RuntimeError):
        service.create_page(actor, policy_id='TEST-POLICY', title='TEST', body='TEST',
                            evidence=[ref], operation_id='crash-1')
    service.fault_hook = None
    with repo.connection() as db:
        assert list(db.iterdump()) == before


def test_source_without_rights_decision_is_not_implicitly_public(kb):
    repo, service, actor, _, _ = kb
    catalog = KnowledgeCatalog(repo)
    catalog.register_source(actor, 'KB-NO-RIGHTS', 'TEST', 'TEST', 'https://hanoi.gov.vn/test-only/no-rights')
    catalog.add_snapshot(actor, 'KB-NO-RIGHTS', b'TEST', 'TEST')
    with repo.connection() as db:
        chunk = db.execute("SELECT c.id FROM pol_chunks c JOIN pol_source_snapshots s ON s.id=c.snapshot_id WHERE s.source_id='KB-NO-RIGHTS'").fetchone()[0]
    with pytest.raises(CoreError) as exc:
        service.evidence_ref(actor, chunk, 'TEST')
    assert exc.value.status_code == 403


@pytest.mark.parametrize(('field', 'value'), [('domain', 'different_domain'), ('jurisdiction', 'US')])
def test_exact_source_domain_and_jurisdiction_are_required(kb, field, value):
    repo, service, actor, _, _ = kb
    page = create(kb)
    with repo.connection(write=True) as db:
        db.execute('UPDATE pol_sources SET '+field+'=? WHERE id=?', (value, 'KB-TEST-A'))
    with pytest.raises(CoreError) as exc:
        service.get_page(actor, page['page_id'])
    assert exc.value.status_code == 403


@pytest.mark.parametrize('version', [True, 1.0, '1', None, -1])
@pytest.mark.parametrize('action', ['edit', 'archive'])
def test_expected_version_is_strict_integer(kb, version, action):
    _, service, actor, _, ref = kb
    page = create(kb)
    with pytest.raises(CoreError):
        if action == 'edit':
            service.edit_page(actor, page['page_id'], expected_revision_id=page['revision_id'],
                expected_version=version, title='Changed', body='Changed', evidence=[ref], operation_id='strict')
        else:
            service.archive_page(actor, page['page_id'], expected_version=version, operation_id='strict')
    assert service.get_page(actor, page['page_id'])['version'] == 1


def test_archive_event_follows_current_content_event_not_grandparent(kb):
    repo, service, actor, _, ref = kb
    first = create(kb)
    current = service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'],
        expected_version=1, title='New', body='New', evidence=[ref], operation_id='edit')
    service.archive_page(actor, first['page_id'], expected_version=2, operation_id='archive')
    with repo.connection() as db:
        edited = db.execute("SELECT id FROM kp_knowledge_events WHERE event_type='edited' AND revision_id=?",
                            (current['revision_id'],)).fetchone()[0]
        archived = db.execute("SELECT previous_id FROM kp_knowledge_events WHERE event_type='archived'").fetchone()[0]
    assert archived == edited


def test_corrupt_stored_markdown_is_detected_before_read(kb):
    repo, service, actor, _, _ = kb
    page = create(kb)
    # Simulate an out-of-band damaged DB, never a runtime mutation capability.
    with repo.connection(write=True) as db:
        trigger = db.execute("SELECT sql FROM sqlite_master WHERE name='kp_wiki_revisions_immutable'").fetchone()[0]
        db.execute('DROP TRIGGER kp_wiki_revisions_immutable')
        db.execute("UPDATE kp_wiki_revisions SET body='Damaged' WHERE id=?", (page['revision_id'],))
        db.execute(trigger)
    with pytest.raises(CoreError) as exc:
        service.get_page(actor, page['page_id'])
    assert exc.value.code == 'knowledge_integrity_error'


@pytest.mark.parametrize('revision', [{}, [], '', True, 1.0])
def test_read_revision_requires_scalar_explicit_identity(kb, revision):
    _, service, actor, _, _ = kb
    page = create(kb)
    with pytest.raises(CoreError):
        service.get_page(actor, page['page_id'], revision_id=revision)


def test_corrupt_receipt_response_does_not_bypass_canonical_verification(kb):
    import json
    repo, _, _, _, _ = kb
    create(kb)
    with repo.connection(write=True) as db:
        trigger = db.execute("SELECT sql FROM sqlite_master WHERE name='kp_knowledge_operations_immutable'").fetchone()[0]
        db.execute('DROP TRIGGER kp_knowledge_operations_immutable')
        row = db.execute("SELECT response_json FROM kp_knowledge_operations WHERE kind='knowledge.page.create/1'").fetchone()
        response = json.loads(row[0]); response['body'] = 'Damaged receipt'
        db.execute("UPDATE kp_knowledge_operations SET response_json=? WHERE kind='knowledge.page.create/1'", (json.dumps(response),))
        db.execute(trigger)
    with pytest.raises(CoreError) as exc:
        create(kb)
    assert exc.value.code == 'knowledge_integrity_error'


def test_page_has_explicit_aggregate_event_head_and_exact_predecessor_chain(kb):
    repo, service, actor, _, ref = kb
    first = create(kb)
    with repo.connection() as db:
        created_head = db.execute('SELECT event_head_id FROM kp_wiki_pages WHERE id=?', (first['page_id'],)).fetchone()[0]
    current = service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'], expected_version=1,
        title='Second', body='Second', evidence=[ref], operation_id='second')
    with repo.connection() as db:
        edited_head = db.execute('SELECT event_head_id FROM kp_wiki_pages WHERE id=?', (first['page_id'],)).fetchone()[0]
        assert db.execute('SELECT previous_id FROM kp_knowledge_events WHERE id=?', (edited_head,)).fetchone()[0] == created_head
    service.archive_page(actor, first['page_id'], expected_version=2, operation_id='archive')
    with repo.connection() as db:
        archived_head = db.execute('SELECT event_head_id FROM kp_wiki_pages WHERE id=?', (first['page_id'],)).fetchone()[0]
        assert db.execute('SELECT previous_id FROM kp_knowledge_events WHERE id=?', (archived_head,)).fetchone()[0] == edited_head
    assert current['parent_revision_id'] == first['revision_id']


def test_evidence_read_maps_invalid_utf8_to_domain_error_and_preserves_db(kb):
    repo, service, actor, _, ref = kb
    with repo.connection() as db:
        before = list(db.iterdump())
    with pytest.raises(CoreError) as exc:
        service.evidence_ref(actor, ref['chunk_id'], '\ud800')
    assert exc.value.code == 'invalid_knowledge_input'
    with repo.connection() as db:
        assert list(db.iterdump()) == before


@pytest.mark.parametrize('mode', ['head_only', 'consistent_rewind'])
def test_stale_same_page_event_head_is_not_a_valid_current_state(kb, mode):
    repo, service, actor, _, ref = kb
    first = create(kb)
    with repo.connection() as db:
        old_head = db.execute('SELECT event_head_id FROM kp_wiki_pages WHERE id=?', (first['page_id'],)).fetchone()[0]
    service.edit_page(actor, first['page_id'], expected_revision_id=first['revision_id'], expected_version=1,
        title='New', body='New', evidence=[ref], operation_id='new-state')
    with repo.connection(write=True) as db:
        db.execute('UPDATE kp_wiki_pages SET event_head_id=? WHERE id=?', (old_head, first['page_id']))
        if mode == 'consistent_rewind':
            db.execute('UPDATE kp_wiki_pages SET head_revision_id=?,version=1 WHERE id=?', (first['revision_id'], first['page_id']))
    with pytest.raises(CoreError) as exc:
        service.get_page(actor, first['page_id'])
    assert exc.value.code == 'knowledge_integrity_error'


def test_rights_head_rewind_does_not_revive_revoked_read(kb):
    repo, service, actor, _, _ = kb
    page = create(kb)
    with repo.connection() as db:
        old = dict(db.execute("SELECT * FROM kp_source_rights_heads WHERE source_id='KB-TEST-A'").fetchone())
    service.set_source_rights(actor, 'KB-TEST-A', expected_version=1, allow_read=False, allow_export=False,
                              reason='Revoked', operation_id='revoke')
    with repo.connection(write=True) as db:
        db.execute('UPDATE kp_source_rights_heads SET event_id=?,version=1 WHERE source_id=?', (old['event_id'], 'KB-TEST-A'))
    with pytest.raises(CoreError) as exc:
        service.get_page(actor, page['page_id'])
    assert exc.value.code == 'knowledge_integrity_error'
