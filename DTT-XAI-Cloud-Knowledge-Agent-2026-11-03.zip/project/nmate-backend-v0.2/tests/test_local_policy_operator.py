"""Local credentials and program-scoped roles, never MAIN data or model IO."""
import json
import os

import pytest

from nmate.core_v1.operator import administer, main
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError, CoreRepository, now_iso
from nmate.v03.identity import LocalAccounts


def windows_sddl(path):
    import ctypes
    from ctypes import wintypes
    advapi = ctypes.WinDLL("advapi32", use_last_error=True)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    advapi.GetFileSecurityW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, ctypes.c_void_p,
                                      wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    advapi.GetFileSecurityW.restype = wintypes.BOOL
    advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes = [
        ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(wintypes.LPWSTR), ctypes.c_void_p]
    advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW.restype = wintypes.BOOL
    kernel.LocalFree.argtypes = [ctypes.c_void_p]
    needed = wintypes.DWORD()
    advapi.GetFileSecurityW(str(path), 5, None, 0, ctypes.byref(needed))
    buffer = ctypes.create_string_buffer(needed.value)
    assert advapi.GetFileSecurityW(str(path), 5, buffer, needed.value, ctypes.byref(needed))
    sddl = wintypes.LPWSTR()
    assert advapi.ConvertSecurityDescriptorToStringSecurityDescriptorW(buffer, 1, 5, ctypes.byref(sddl), None)
    try:
        return sddl.value
    finally:
        kernel.LocalFree(ctypes.cast(sddl, ctypes.c_void_p))


@pytest.fixture
def operators(tmp_path):
    repo = CoreRepository(tmp_path / "operator-local.sqlite")
    accounts = LocalAccounts(repo)
    admin = accounts.register("policy-admin", "test-only-password", "DTT test")
    operator = accounts.register("trung@dtt.vn", "test-only-password", "DTT vận hành")
    catalog = KnowledgeCatalog(repo)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy','TEST',?,NULL)", (admin["account_id"], now_iso()))
    for source_id in ("NOTICE-A", "ATTACHMENT-A", "SHARED-BASIS", "OTHER-SOURCE"):
        catalog.register_source(admin["account_id"], source_id, "Nguồn kiểm thử " + source_id, "Hà Nội",
                                "https://hanoi.gov.vn/test/" + source_id)
        snap = catalog.add_snapshot(admin["account_id"], source_id, b"test", "Chỉ dữ liệu kiểm thử điều kiện.",
                                    complete_policy=True, effective_from="2020-01-01", effective_until="2099-01-01")
        catalog.record_source_check(admin["account_id"], source_id, result="verified_current", current_until="2099-01-01T00:00:00+00:00", rationale="TEST ONLY")
        assert snap["snapshot_id"]
    return repo, catalog, admin, operator


def member(operators, policy_id="PROGRAM-A", source_ids=("NOTICE-A",), kind="rule"):
    repo, catalog, admin, _ = operators
    with repo.connection() as db:
        chunks = [dict(db.execute("SELECT c.* FROM pol_chunks c JOIN pol_source_snapshots p ON p.id=c.snapshot_id "
                  "WHERE p.source_id=?", (source,)).fetchone()) for source in source_ids]
    payload = {"scope": {"jurisdiction": "VN-HN", "goal_types": ["general"]},
               "conditions": [{"id": "c1", "expression": {"field": "province", "op": "eq", "value": "Hà Nội"}}]}
    return catalog.propose_member(admin["account_id"], kind=kind, policy_id=policy_id, title_vi="Dữ liệu kiểm thử",
        payload=payload, evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": "c1"} for chunk in chunks],
        effective_from="2020-01-01", effective_until="2099-01-01")


def grant(operators, role, sources=("NOTICE-A", "ATTACHMENT-A", "SHARED-BASIS"), approval=None):
    repo, _, _, operator = operators
    return administer(repo, "knowledge-grant", approval_id=approval or "TEST-SCOPED-" + role,
                      username=operator["username"], role=role, policy_id="PROGRAM-A", source_ids=list(sources))


def test_local_account_create_writes_private_file_safe_ledger_and_never_resets(tmp_path, capsys):
    repo = CoreRepository(tmp_path / "account.sqlite")
    target = tmp_path / "credentials" / "login.txt"
    arguments = ["--db", repo.db_path, "account-create", "--approval-id", "TEST-LOCAL-ACCOUNT",
                 "--username", "trung@dtt.vn", "--enterprise-name", "DTT vận hành chính sách", "--credential-file", str(target)]
    assert main(arguments) == 0
    output = capsys.readouterr().out
    metadata = json.loads(output)["result"]
    assert metadata["status"] == "created" and metadata["session_created"] is False
    text = target.read_text(encoding="utf-8")
    credential = next(line.split(": ", 1)[1] for line in text.splitlines() if line.startswith("Mật khẩu: "))
    assert len(credential) >= 24 and credential not in output
    assert LocalAccounts(repo).login("TRUNG@DTT.VN", credential)["account_id"] == metadata["account_id"]
    with repo.connection() as db:
        ledger = db.execute("SELECT result_json FROM core_operator_approvals").fetchone()[0]
        original_hash = db.execute("SELECT password_hash FROM v03_accounts").fetchone()[0]
        assert credential not in ledger
        assert db.execute("SELECT COUNT(*) FROM v03_sessions").fetchone()[0] == 0
    assert main(arguments) == 0
    assert json.loads(capsys.readouterr().out)["result"] == metadata
    second = administer(repo, "account-create", approval_id="TEST-LOCAL-EXISTING", username="trung@dtt.vn",
                        enterprise_name="Other", credential_file=tmp_path / "must-not-exist.txt")
    assert second["status"] == "already_exists" and second["password_created"] is False
    assert not (tmp_path / "must-not-exist.txt").exists()
    with repo.connection() as db:
        assert db.execute("SELECT password_hash FROM v03_accounts").fetchone()[0] == original_hash
        assert db.execute("SELECT COUNT(*) FROM v03_accounts").fetchone()[0] == 1
    if os.name == "nt":
        acl = windows_sddl(target)
        assert "D:P" in acl and acl.count("(A;") == 1
    else:
        assert target.stat().st_mode & 0o777 == 0o600


def test_credential_collision_rolls_back_new_account_without_overwriting(tmp_path):
    repo = CoreRepository(tmp_path / "collision.sqlite")
    target = tmp_path / "existing.txt"
    target.write_text("KEEP", encoding="utf-8")
    with pytest.raises(CoreError) as error:
        administer(repo, "account-create", approval_id="TEST-COLLISION", username="trung@dtt.vn",
                   enterprise_name="DTT", credential_file=target)
    assert error.value.code == "credential_file_exists"
    assert target.read_text(encoding="utf-8") == "KEEP"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_accounts").fetchone()[0] == 0


def test_program_grants_are_scoped_idempotent_and_not_rule_approval(operators):
    repo, catalog, _, operator = operators
    draft = member(operators)
    result = grant(operators, "reviewer")
    assert grant(operators, "reviewer") == result and result["rules_approved"] is False
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_knowledge_roles WHERE account_id=?", (operator["account_id"],)).fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM pol_knowledge_role_scopes WHERE account_id=?", (operator["account_id"],)).fetchone()[0] == 3
        assert db.execute("SELECT review_state FROM pol_members WHERE id=?", (draft["member_id"],)).fetchone()[0] == "draft"
        with pytest.raises(CoreError):
            catalog._authority(db, operator["account_id"], "reviewer")  # no global source authority
    assert [row["id"] for row in catalog.list_review_queue(operator["account_id"])] == [draft["member_id"]]


def test_reviewer_and_publisher_cannot_escape_program_or_any_evidence_source(operators):
    _, catalog, _, operator = operators
    grant(operators, "reviewer")
    grant(operators, "publisher")
    allowed = member(operators, source_ids=("NOTICE-A", "SHARED-BASIS"))
    other_program = member(operators, policy_id="PROGRAM-B")
    mixed_sources = member(operators, source_ids=("NOTICE-A", "OTHER-SOURCE"))
    assert {row["id"] for row in catalog.list_review_queue(operator["account_id"])} == {allowed["member_id"]}
    for draft in (other_program, mixed_sources):
        with pytest.raises(CoreError) as error:
            catalog.review_member(operator["account_id"], draft["member_id"], draft["content_hash"], approve=True, rationale="TEST")
        assert error.value.code == "knowledge_forbidden"
        with pytest.raises(CoreError) as error:
            catalog.publish_member(operator["account_id"], draft["member_id"], draft["content_hash"], "fake-review")
        assert error.value.code == "knowledge_forbidden"
    approved = catalog.review_member(operator["account_id"], allowed["member_id"], allowed["content_hash"], approve=True, rationale="TEST ONLY")
    publication = catalog.publish_member(operator["account_id"], allowed["member_id"], allowed["content_hash"], approved["review_event_id"])
    assert publication["publication_event_id"]
    released = catalog.release_pack(operator["account_id"], "TEST ONLY", [allowed["member_id"]])
    assert released["pack_version_id"]
    with pytest.raises(CoreError) as blocked:
        catalog.record_source_check(operator["account_id"], "SHARED-BASIS", result="verified_current",
                                    current_until="2099-01-01T00:00:00+00:00", rationale="TEST")
    assert blocked.value.code == "knowledge_forbidden"


def test_role_revocation_blocks_publication_and_release_even_after_review(operators):
    repo, catalog, _, operator = operators
    grant(operators, "reviewer")
    grant(operators, "publisher")
    draft = member(operators)
    reviewed = catalog.review_member(operator["account_id"], draft["member_id"], draft["content_hash"], approve=True, rationale="TEST ONLY")
    administer(repo, "knowledge-revoke", approval_id="TEST-REVOKE-SCOPED", username=operator["username"], role="reviewer",
               policy_id="PROGRAM-A", source_ids=["NOTICE-A"])
    with pytest.raises(CoreError) as error:
        catalog.publish_member(operator["account_id"], draft["member_id"], draft["content_hash"], reviewed["review_event_id"])
    assert error.value.code == "knowledge_forbidden"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_publication_events").fetchone()[0] == 0


def test_pack_release_requires_publisher_scope_for_every_member(operators):
    repo, catalog, admin, operator = operators
    grant(operators, "reviewer")
    grant(operators, "publisher")
    allowed = member(operators)
    other = member(operators, policy_id="PROGRAM-B")
    for draft in (allowed, other):
        review = catalog.review_member(admin["account_id"], draft["member_id"], draft["content_hash"], approve=True, rationale="TEST ONLY")
        catalog.publish_member(admin["account_id"], draft["member_id"], draft["content_hash"], review["review_event_id"])
    with pytest.raises(CoreError) as blocked:
        catalog.release_pack(operator["account_id"], "MIXED TEST", [allowed["member_id"], other["member_id"]])
    assert blocked.value.code == "knowledge_forbidden"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_packs").fetchone()[0] == 0
