import hashlib
import json

import pytest

from nmate.v03 import CoreError, CoreRepository, DomainCatalog, LocalAccounts


def test_public_reference_reuse_never_contains_other_enterprise_facts(tmp_path):
    repo = CoreRepository(tmp_path / "catalog.sqlite")
    accounts = LocalAccounts(repo)
    a = accounts.register("alice", "alice-password", "PRIVATE_COMPANY_A")
    b = accounts.register("bravo", "bravo-password", "Company B")
    entity = repo.create_entity(a["account_id"], a["enterprise_id"], "product", "PRIVATE_PRODUCT_A")
    repo.propose_or_apply_facts(a["account_id"], a["enterprise_id"], entity["id"],
                               [{"field": "secret_formula", "value": "PRIVATE_FORMULA_A"}], 0, "a")
    catalog = DomainCatalog(repo)
    lookup = catalog.lookup_domain(["facility_registration", "food_label"], b["account_id"], b["enterprise_id"])
    assert len(lookup["records"]) == 8
    assert lookup["coverage"]["missing"] == []
    serialized = json.dumps(lookup)
    assert all(secret not in serialized for secret in ["PRIVATE_COMPANY_A", "PRIVATE_PRODUCT_A", "PRIVATE_FORMULA_A", a["enterprise_id"]])
    for record in lookup["records"]:
        source = catalog.get_source(record["source_id"])
        assert hashlib.sha256(source["text"].encode()).hexdigest() == record["content_sha256"]
        assert hashlib.sha256(record["excerpt"].encode()).hexdigest() == record["excerpt_sha256"]
        assert record["excerpt_vi"] and record["review_state"] == "reference_unreviewed"
        assert record["freshness_state"] == "recorded_snapshot"
    assert lookup["network_calls"] == lookup["model_calls"] == 0
    assert catalog.lookup_domain(["prior_notice"])["coverage"]["state"] == "supported_reference"
    assert catalog.lookup_domain(["certification"])["coverage"]["state"] == "no_support_found"
    with pytest.raises(CoreError):
        catalog.lookup_domain(["food_label"], b["account_id"], a["enterprise_id"])


def test_source_change_invalidates_gate_immediately_and_cannot_auto_bless(tmp_path):
    repo = CoreRepository(tmp_path / "catalog.sqlite")
    owner = LocalAccounts(repo).register("owner", "correct-password", "Sen")
    catalog = DomainCatalog(repo)
    lookup = catalog.lookup_domain(["food_label"])
    ref = next(r for r in lookup["source_refs"] if r["source_id"] == "fda_registration")
    assert repo.validate_context(owner["account_id"], owner["enterprise_id"], source_refs=[ref])["valid"]
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE v03_missions(id TEXT,enterprise_id TEXT,status TEXT,stale_reason TEXT)")
        db.execute("CREATE TABLE v03_dependencies(mission_id TEXT,enterprise_id TEXT,dependency_kind TEXT,dependency_key TEXT,dependency_version INTEGER)")
        db.execute("INSERT INTO v03_missions VALUES ('m',?,'ready',NULL)", (owner["enterprise_id"],))
        db.execute("INSERT INTO v03_dependencies VALUES ('m',?,'source','fda_registration',1)", (owner["enterprise_id"],))
    observed = catalog.observe_source(owner["account_id"], owner["enterprise_id"], "fda_registration", "0" * 64, "change")
    assert observed["changed"] and observed["freshness_state"] == "needs_revalidation"
    assert not repo.validate_context(owner["account_id"], owner["enterprise_id"], source_refs=[ref])["valid"]
    with repo.connection() as db:
        assert db.execute("SELECT status FROM v03_missions WHERE id='m'").fetchone()[0] == "needs_revalidation"
    catalog = DomainCatalog(repo)  # Reopening does not overwrite an invalidation.
    changed = catalog.lookup_domain(["facility_registration"])
    assert "facility_registration" in changed["coverage"]["missing"]
    catalog.observe_source(owner["account_id"], owner["enterprise_id"], "fda_registration", ref["content_sha256"], "old-hash")
    assert catalog.get_source("fda_registration")["freshness_state"] == "needs_revalidation"
    assert catalog.observe_source(owner["account_id"], owner["enterprise_id"], "fda_registration", "0" * 64, "change") == observed
