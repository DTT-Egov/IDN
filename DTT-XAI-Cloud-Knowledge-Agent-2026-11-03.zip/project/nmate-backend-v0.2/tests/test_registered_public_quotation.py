"""Bounded installed official quotations are public; arbitrary prose is not."""
import asyncio
import hashlib
import json

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, json_text
from test_legacy_model_gateway import setup as shared_setup, grant, invoke, payload


@pytest.fixture(name="workspace")
def workspace_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


def records(workspace):
    return DomainCatalog(workspace[0]).lookup_domain(["prior_notice"], market_code="US")["records"]


def test_all_three_canonical_fda_prior_notice_quotes_use_gateway_and_keep_registered_rights(workspace):
    repo, _, _, _, _, adapter, calls = workspace
    references = records(workspace)
    assert len(references) == 3
    with repo.connection() as db:
        before = [tuple(row) for row in db.execute("SELECT id,rights,text,content_sha256 FROM v03_domain_sources ORDER BY id")]
    grant(workspace)
    asyncio.run(invoke(workspace, payload(reference_records=references), kind="research"))
    outbound = calls[0][1]["input"]["input"]["reference_records"]
    assert {item["id"] for item in outbound} == {item["id"] for item in references}
    assert all(item["rights"] == "official_reference_quotation_not_full_republication" for item in outbound)
    assert sum(len(item["excerpt"]) for item in outbound) < 2000
    assert all("text" not in item and "content_sha256" not in item for item in outbound)
    with repo.connection() as db:
        after = [tuple(row) for row in db.execute("SELECT id,rights,text,content_sha256 FROM v03_domain_sources ORDER BY id")]
    assert before == after
    assert adapter._public_records(references) == outbound


@pytest.mark.parametrize("drift", ["private", "unknown_rights", "nonofficial", "forged_excerpt", "bad_excerpt_hash", "bad_source_hash", "not_in_source", "full_source"])
def test_new_rights_label_cannot_smuggle_private_unknown_unregistered_or_full_source_content(workspace, drift):
    repo, _, _, _, _, adapter, calls = workspace
    reference = records(workspace)[0]
    with repo.connection(write=True) as db:
        source = db.execute("SELECT * FROM v03_domain_sources WHERE id=?", (reference["source_id"],)).fetchone()
        canonical = json.loads(db.execute("SELECT record_json FROM v03_domain_references WHERE id=?", (reference["id"],)).fetchone()[0])
        if drift in {"private", "unknown_rights"}:
            db.execute("UPDATE v03_domain_sources SET rights=? WHERE id=?", ("private_owner" if drift == "private" else "unreviewed_external", source["id"]))
        elif drift == "nonofficial":
            db.execute("UPDATE v03_domain_sources SET url='https://example.com/private' WHERE id=?", (source["id"],))
        elif drift == "forged_excerpt":
            reference["excerpt"] = "Private enterprise finance report revenue 999999999."
        elif drift == "bad_source_hash":
            db.execute("UPDATE v03_domain_sources SET content_sha256=? WHERE id=?", ("0" * 64, source["id"]))
        else:
            if drift == "bad_excerpt_hash":
                canonical["excerpt_sha256"] = "0" * 64
            else:
                canonical["excerpt"] = source["text"] if drift == "full_source" else "A completely unregistered private claim with a valid local hash."
                canonical["excerpt_sha256"] = hashlib.sha256(canonical["excerpt"].encode()).hexdigest()
                reference["excerpt"] = canonical["excerpt"]
            db.execute("UPDATE v03_domain_references SET record_json=? WHERE id=?", (json_text(canonical), reference["id"]))
    with pytest.raises(CoreError):
        adapter._public_records([reference])
    assert calls == []
