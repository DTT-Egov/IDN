"""The profile binding is an explicit additive upgrade, not startup backfill."""
from contextlib import closing
import json
from pathlib import Path
import sqlite3

from nmate.main.app import make_main_app
from nmate.core_v1.enterprise_profile import SCHEMA
from nmate.core_v1.runtime_schema import verify_runtime_database, read_runtime_contract, managed_runtime
from nmate.core_v1.schema_lifecycle import create_plan, apply_plan


SOURCE = Path(__file__).resolve().parents[1] / 'src'
OLD = SOURCE / 'nmate/core_v1/data/runtime_schema_20261024_v05_1.json'


def test_new_database_and_target_contract_include_profile_binding(tmp_path):
    db = tmp_path / 'new.sqlite'
    make_main_app(db, refresh_sources=True, gateway_enabled=False)
    ready = verify_runtime_database(db)
    assert ready['contract_version'] == 'nmate-main-20261026-v17'
    assert ready['required_table_count'] == 95


def test_old_schema_upgrade_then_managed_startup_and_exact_receipt_replay(tmp_path):
    db = tmp_path / 'upgrade.sqlite'
    make_main_app(db, refresh_sources=True, gateway_enabled=False)
    # Build an exact empty old baseline from the same public seeds. No business
    # assertion or historical draft is interpreted or repaired by this fixture.
    with closing(sqlite3.connect(db)) as conn:
        conn.execute('DROP TABLE core_v1_enterprise_profiles')
        conn.commit()
    verify_runtime_database(db, contract_path=OLD)
    statement = SCHEMA.strip()
    plan = create_plan(db, version='v17-enterprise-link-1', statements=[statement], source_root=SOURCE,
                       dependency_files=['nmate/core_v1/enterprise_profile.py'])
    receipt = apply_plan(db, plan, source_root=SOURCE, backup_path=tmp_path / 'backup.sqlite')
    ready = verify_runtime_database(db)
    assert ready['contract_version'] == 'nmate-main-20261026-v17'
    with closing(sqlite3.connect(db)) as conn:
        before = '\n'.join(conn.iterdump())
    with managed_runtime():
        make_main_app(db, refresh_sources=True, gateway_enabled=False)
    with closing(sqlite3.connect(db)) as conn:
        assert '\n'.join(conn.iterdump()) == before
        assert conn.execute('SELECT count(*) FROM core_v1_enterprise_profiles').fetchone()[0] == 0
    assert apply_plan(db, plan, source_root=SOURCE, backup_path=tmp_path / 'not-used.sqlite') == receipt
    assert not (tmp_path / 'not-used.sqlite').exists()


def test_new_contract_only_adds_exact_binding_table_and_preserves_seeds():
    before = json.loads(OLD.read_text(encoding='utf8'))
    after = read_runtime_contract()
    assert after['version'] == 'nmate-main-20261026-v17'
    assert after['required_seeds'] == before['required_seeds']
    assert after['optional_objects'] == before['optional_objects']
    prior = {item['name']: item for item in before['required_objects']}
    current = {item['name']: item for item in after['required_objects']}
    assert current.keys() - prior.keys() == {'core_v1_enterprise_profiles'}
    assert all(current[name] == value for name, value in prior.items())
