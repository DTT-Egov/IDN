"""Actual MCP SDK in-memory transport + M1→M2 whole synthetic runtime."""
from contextlib import closing
import json
from pathlib import Path
import sqlite3
import pytest
from mcp import Client
from nmate.v03.mcp import create_mcp,account_context
from nmate.knowledge_v1.mcp import register_tools
from nmate.knowledge_v1.operator_m2 import install_m2_on_clone,target_m2_contract,open_m2_runtime
from nmate.knowledge_v1.operator import install_on_clone
from nmate.core_v1.runtime_schema import verify_runtime_database
from nmate.main.app import make_main_app
from test_knowledge_m2 import pipe,candidate
from test_knowledge_m1 import kb


@pytest.mark.asyncio
async def test_actual_mcp_sdk_reads_cannot_impersonate_or_dispatch_model(pipe):
    repo,s,actor,other=pipe
    p=candidate(pipe)
    names={'knowledge_source','knowledge_candidate','knowledge_export','knowledge_search','knowledge_extract','knowledge_extraction','knowledge_evidence','knowledge_candidate_edit'}
    server=create_mcp(repo,None,extra_register=lambda server,call:register_tools(server,s,call),tool_allowlist=names)
    def no_parse(*args): pytest.fail('Read cannot parse')
    s.parser=no_parse
    token=account_context.set(actor)
    try:
        async with Client(server,mode='2026-07-28',cache=None) as client:
            tools=await client.list_tools()
            assert {t.name for t in tools.tools}==names
            for t in tools.tools:
                props=t.input_schema.get('properties',{})
                assert not {'actor','account_id','root','path','api_key','paid_consent'} & set(props)
            result=await client.call_tool('knowledge_candidate',{'page_id':p['page_id']})
            assert result.structured_content['ok'] and result.structured_content['data']['body']==p['body']
            result=await client.call_tool('knowledge_export',{'page_id':p['page_id']})
            assert result.structured_content['ok']
    finally: account_context.reset(token)
    token=account_context.set(other)
    try:
        async with Client(server,mode='2026-07-28',cache=None) as client:
            result=await client.call_tool('knowledge_candidate',{'page_id':p['page_id']})
            assert result.is_error and not result.structured_content['ok']
    finally: account_context.reset(token)
    async with Client(server,mode='2026-07-28',cache=None) as client:
        result=await client.call_tool('knowledge_source',{'source_id':'KB-TEST-A'})
        assert result.is_error and result.structured_content['error']['code']=='UNAUTHORIZED'


def test_full_synthetic_v17_m1_m2_operator_readonly_target(tmp_path):
    database=tmp_path/'whole-main.sqlite'
    def denied(*args,**kwargs): pytest.fail('No paid AI permitted')
    make_main_app(database,request_fn=denied,gateway_request_fn=denied,refresh_sources=True,gateway_enabled=False)
    install_on_clone(database,backup_path=tmp_path/'before-m1.sqlite')
    with closing(sqlite3.connect(database)) as db:
        tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        before={t:db.execute('SELECT * FROM "'+t+'"').fetchall() for t in tables if t!='core_schema_migration_receipts'}
    result=install_m2_on_clone(database,backup_path=tmp_path/'before-m2.sqlite')
    target=tmp_path/'target-m2.json'; target.write_text(json.dumps(target_m2_contract()),encoding='utf-8')
    assert verify_runtime_database(database,contract_path=target)['ready']
    with closing(sqlite3.connect(database)) as db: prior=list(db.iterdump())
    service=open_m2_runtime(database,contract_path=target)
    assert service.repo.managed_runtime
    with closing(sqlite3.connect(database)) as db:
        assert list(db.iterdump())==prior
        assert {t:db.execute('SELECT * FROM "'+t+'"').fetchall() for t in before}==before
    from nmate.core_v1.schema_lifecycle import apply_plan
    source=Path(__file__).resolve().parents[1]/'src'
    assert apply_plan(database,result['plan'],source_root=source,backup_path=tmp_path/'not-used.sqlite')==result['receipt']
    assert not (tmp_path/'not-used.sqlite').exists()
