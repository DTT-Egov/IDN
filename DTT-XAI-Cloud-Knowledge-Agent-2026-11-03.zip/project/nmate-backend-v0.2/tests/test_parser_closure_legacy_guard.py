"""New reference roles must not make old wrong-product bindings look valid."""
import json
import pytest

from nmate.main.app import make_main_app
from nmate.v03.core import CoreError, json_text
from test_review_commands_v2 import data_snapshot


@pytest.mark.parametrize("question,extra_names", [
    ("Chị có nên nhập thêm hàng Bột Sen khi tồn kho còn 120 hộp?", []),
    ("Chị xem hồ sơ Hồng Hà và Gió Mới để đối chiếu tồn kho.", ["Hồng Hà"]),
    ("Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho.", ["Hồng Hà", "Bắc Sơn"]),
    ("Chị xem hồ sơ Bắc Sơn để đối chiếu tồn kho.", ["Bắc Sơn"]),
])
def test_unbound_reference_in_legacy_chat_is_readable_with_blocking_binding_warning(tmp_path, question, extra_names):
    calls = []

    async def forbidden(*args, **kwargs):
        calls.append(1)
        raise AssertionError("Legacy projection must not call a model")

    app = make_main_app(tmp_path / "legacy-role.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("parser-legacy-owner", "Synthetic-password-123", "Cơ sở QA riêng")
    scope = owner["account_id"], owner["enterprise_id"]
    service = app.state.core_extension
    product = service.create_entity(*scope, "product", "Trà Sen Tây Hồ", "legacy-role-create-product")
    for index, name in enumerate(extra_names):
        service.create_entity(*scope, "product", name, f"legacy-extra-product-{index}")
    chat = service.conversations.prepare_chat_draft(*scope, "Tên sản phẩm: Trà Sen Tây Hồ, lượng tịnh 100 g.",
        "legacy-role-prepare-free", product_entity_id=product["id"], task_hint="profile_intake")
    # Explicit legacy fixture only: retain the old Tea product while replacing
    # the old owner's raw text with a different, pure operational reference.
    with app.state.repo.connection(write=True) as db:
        item = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?",
                                     (chat["active_intake_id"],)).fetchone()[0])
        item.pop("product_binding", None)
        item["text"] = question
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(item), item["id"]))
    before = data_snapshot(app.state.repo)
    view = service.get_chat(*scope, chat["id"])
    assert view["intake"]["binding_warning"]["blocking"] is True
    assert view["intake"]["binding_warning"]["code"] == "PRODUCT_BINDING_UNCONFIRMED"
    assert data_snapshot(app.state.repo) == before and calls == []


@pytest.mark.parametrize("code,status", [("forbidden", 403), ("READ_PROJECTION_FAILED", 500)])
def test_legacy_semantic_warning_never_masks_current_read_or_acl_failure(tmp_path, monkeypatch, code, status):
    calls = []
    async def forbidden(*_args, **_kwargs):
        calls.append(1)
        raise AssertionError("A legacy read must not call a provider")
    app = make_main_app(tmp_path / "legacy-read-errors.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("legacy-read-owner", "Synthetic-password-123", "Cơ sở QA")
    scope = owner["account_id"], owner["enterprise_id"]
    service = app.state.core_extension
    product = service.create_entity(*scope, "product", "Hồng Hà", "legacy-read-create")
    chat = service.conversations.prepare_chat_draft(*scope, "Tên sản phẩm: Hồng Hà", "legacy-read-prepare",
                                                  product_entity_id=product["id"])
    with app.state.repo.connection(write=True) as db:
        item = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (chat["active_intake_id"],)).fetchone()[0])
        item.pop("product_binding", None)
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(item), item["id"]))
    before = data_snapshot(app.state.repo)
    def failed_read(*_args, **_kwargs):
        raise CoreError(code, "Synthetic current read failure", status)
    monkeypatch.setattr("nmate.main.conversations.product_scope", failed_read)
    with pytest.raises(CoreError) as error:
        service.get_chat(*scope, chat["id"])
    assert error.value.code == code and error.value.status_code == status
    assert data_snapshot(app.state.repo) == before and calls == []


def test_legacy_same_known_lookup_keeps_existing_profile_without_false_warning(tmp_path):
    async def forbidden(*_args, **_kwargs):
        raise AssertionError("A legacy read must not call a provider")
    app = make_main_app(tmp_path / "legacy-same-reference.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("legacy-same-owner", "Synthetic-password-123", "Cơ sở QA")
    scope = owner["account_id"], owner["enterprise_id"]
    service = app.state.core_extension
    product = service.create_entity(*scope, "product", "Hồng Hà", "legacy-same-create")
    chat = service.conversations.prepare_chat_draft(*scope, "Tên sản phẩm: Hồng Hà", "legacy-same-prepare",
                                                  product_entity_id=product["id"])
    with app.state.repo.connection(write=True) as db:
        item = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (chat["active_intake_id"],)).fetchone()[0])
        item.pop("product_binding", None)
        item["text"] = "Chị xem hồ sơ Hồng Hà để đối chiếu tồn kho."
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(item), item["id"]))
    before = data_snapshot(app.state.repo)
    view = service.get_chat(*scope, chat["id"])
    assert not view["intake"].get("binding_warning")
    assert view["intake"]["product"]["id"] == product["id"] and data_snapshot(app.state.repo) == before
