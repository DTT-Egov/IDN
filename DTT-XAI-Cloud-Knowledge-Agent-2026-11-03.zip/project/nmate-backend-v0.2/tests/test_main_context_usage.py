"""Scope-aware mission counts and authoritative research model metadata.

Only isolated SQL and a transport that raises before dispatch are used.
"""
from __future__ import annotations

import copy
import json
import socket

import pytest

from nmate.main.app import MainMissions
from nmate.main.provider import MainProvider
from nmate.v03.core import CoreRepository, json_text
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from test_review_commands_v2 import data_snapshot
from test_ssot_field_scope import legacy_fact


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Context usage must not call any network or model")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "context-usage.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("usage-owner", "Only-local-usage-password", "Trà Sen QA")
    other = accounts.register("usage-other", "Only-local-usage-password", "Doanh nghiệp khác")
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"], [
        {"field": "name", "value": "Trà Sen Tây Hồ"}, {"field": "product_code", "value": "TS01"},
        {"field": "net_quantity", "value": "100 g"}, {"field": "packaging", "value": "hộp"}], 0, "usage-seed")
    async def denied(*_args, **_kwargs):
        raise AssertionError("No model dispatch allowed")
    provider = MainProvider(repo, api_key=None, request_fn=denied)
    missions = MainMissions(repo, model_call=provider)
    bounded = MissionService(repo)
    return repo, owner, other, product, provider, missions, bounded


def plan(setup, suffix="two", question="Đăng ký cơ sở FDA và chuẩn bị nhãn Trà Sen Tây Hồ gửi New York"):
    _repo, owner, _other, product, _provider, _missions, bounded = setup
    return bounded.prepare(owner["account_id"], owner["enterprise_id"], question, "usage-plan-" + suffix, product["id"])


def get(setup, mission):
    return setup[5].get(setup[1]["account_id"], setup[1]["enterprise_id"], mission["id"])


def test_four_confirmed_product_facts_and_three_plan_facts_have_different_scopes(setup):
    repo, owner, _other, product, _provider, _missions, _bounded = setup
    mission = plan(setup)
    original_context = copy.deepcopy(mission["context"])
    before = data_snapshot(repo)
    for _ in range(2):
        result = get(setup, mission)
        usage = result["context_usage"]
        assert usage["current_product_confirmed_fact_count"] == 4
        assert usage["plan_product_fact_count"] == usage["plan_shared_fact_count"] == 3
        assert usage["omitted_current_field_keys"] == ["product_code"]
        assert usage["product_entity_id"] == product["id"]
        assert usage["snapshot_context_revision"] == usage["current_context_revision"]
        assert usage["context_revision_changed"] is False
        assert result["status"] == "planned" and result["needs_revalidation"] is False
        assert result["context"] == original_context
        assert result["reused_fact_count"] == 3
    assert data_snapshot(repo) == before


def test_excluded_code_change_is_current_revision_change_without_forcing_replan(setup):
    repo, owner, _other, product, _provider, _missions, _bounded = setup
    mission = plan(setup)
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"],
        [{"field": "product_code", "value": "TS02"}], 1, "usage-code-change")
    before = data_snapshot(repo)
    result = get(setup, mission)
    assert result["context"] == mission["context"]
    assert result["context_usage"]["context_revision_changed"] is True
    assert result["context_usage"]["snapshot_product_version"] == 1
    assert result["context_usage"]["current_product_version"] == 2
    assert result["needs_revalidation"] is False and result["status"] == "planned"
    assert data_snapshot(repo) == before


def test_unknown_expired_and_wrong_scope_fields_are_not_confirmed_count(setup):
    repo, owner, _other, product, _provider, _missions, _bounded = setup
    mission = plan(setup)
    legacy_fact(repo, owner, product["id"], "legal_form", "TNHH")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"], [
        {"field": "origin_country", "value": None, "value_state": "unknown", "explicit_clear": True},
        {"field": "ingredients", "value": "Công thức cũ", "valid_from": "2020-01-01", "valid_to": "2020-02-01"}], 1, "usage-noncurrent")
    before = data_snapshot(repo)
    result = get(setup, mission)
    assert result["context_usage"]["current_product_confirmed_fact_count"] == 4
    assert result["context_usage"]["omitted_current_field_keys"] == ["product_code"]
    assert result["context"] == mission["context"]
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("question,expected_role,expected_model", [
    ("Đăng ký cơ sở FDA cho Trà Sen Tây Hồ gửi New York", "standard", "claude-sonnet-5-5"),
    ("Đăng ký cơ sở FDA và chuẩn bị nhãn Trà Sen Tây Hồ gửi New York", "complex", "claude-opus-5-5"),
])
def test_research_requirement_uses_same_router_as_actual_request(setup, question, expected_role, expected_model):
    repo, _owner, _other, _product, provider, missions, bounded = setup
    mission = plan(setup, expected_role, question)
    captured = []
    class StopBeforeDispatch(RuntimeError):
        pass
    class Recorder:
        _model = provider._model
        async def __call__(self, kind, payload, **kwargs):
            captured.append((kind, payload))
            raise StopBeforeDispatch()
    missions.model_call = Recorder()
    before = data_snapshot(repo)
    metadata = get(setup, mission)["research_model_requirement"]
    raw = bounded._internal(mission["id"])
    coroutine = missions._request_research(raw, raw["knowledge"]["records"])
    with pytest.raises(StopBeforeDispatch):
        coroutine.send(None)
    assert len(captured) == 1
    kind, request = captured[0]
    assert metadata == {"purpose": "legacy_research", "role": expected_role, "model": expected_model}
    assert provider._model(kind, request) == metadata["model"]
    assert data_snapshot(repo) == before


def test_malformed_legacy_count_shape_is_unknown_without_rewriting_history(setup):
    repo, _owner, _other, _product, _provider, _missions, _bounded = setup
    mission = plan(setup)
    with repo.connection(write=True) as db:
        raw = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mission["id"],)).fetchone()[0])
        old_product = raw["context"]["entities"][0]
        old_product.pop("facts")
        old_product["values"] = ["malformed old shape"]
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(raw), mission["id"]))
    before = data_snapshot(repo)
    result = get(setup, mission)
    assert result["context_usage"]["current_product_confirmed_fact_count"] == 4
    assert result["context_usage"]["plan_product_fact_count"] is None
    assert result["context_usage"]["snapshot_count_available"] is False
    assert result["context_usage"]["omitted_current_field_keys"] == []
    assert result["context"] == raw["context"]
    assert data_snapshot(repo) == before


def test_unknown_configured_router_does_not_guess_role_or_block_history(setup, monkeypatch):
    repo, _owner, _other, _product, provider, _missions, _bounded = setup
    mission = plan(setup)
    def unavailable(_kind, _payload):
        raise RuntimeError("Unknown configured routing policy")
    monkeypatch.setattr(provider, "_model", unavailable)
    before = data_snapshot(repo)
    result = get(setup, mission)
    assert "research_model_requirement" not in result
    assert result["context_usage"]["current_product_confirmed_fact_count"] == 4
    assert result["context"] == mission["context"]
    assert data_snapshot(repo) == before
