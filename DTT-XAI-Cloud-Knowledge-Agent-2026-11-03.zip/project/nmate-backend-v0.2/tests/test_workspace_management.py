"""Product-owner regressions at real service/HTTP/MCP boundaries; no provider."""
import base64
from io import BytesIO

import httpx
import pytest
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas

from nmate.main.app import make_main_app
from nmate.v03.core import CoreError
from nmate.v03.label_pdf import register_fonts, render_label_pdf
from nmate.v04.pdf_intake import parse_pdf


@pytest.fixture
def workspace(tmp_path):
    async def forbidden(*_args, **_kwargs):
        pytest.fail('A free workspace command must not call a model')
    app = make_main_app(tmp_path/'workspace.sqlite3', refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    accounts = app.state.accounts
    owner = accounts.register('owner-workspace', 'Workspace-TEST-only-123', 'Trà Sen QA')
    other = accounts.register('other-workspace', 'Workspace-TEST-only-456', 'Doanh nghiệp khác QA')
    return app, app.state.core_extension, owner, other


def scope(owner):
    return owner['account_id'], owner['enterprise_id']


def pdf_bytes(lines, pages=1):
    register_fonts()
    result = BytesIO()
    document = canvas.Canvas(result)
    for _ in range(pages):
        document.setFont('nMateText', 12)
        for index, line in enumerate(lines):
            document.drawString(40, 790-index*22, line)
        document.showPage()
    document.save()
    return result.getvalue()


def attachment(raw, filename='tra-sen.pdf'):
    return {'filename': filename, 'media_type':'application/pdf', 'data_base64':base64.b64encode(raw).decode()}


def test_account_settings_cas_idempotency_and_no_enterprise_fact_write(workspace):
    app, service, owner, other = workspace
    before = app.state.repo.get_context(*scope(owner))
    assert service.settings(*scope(owner))['preferred_address'] == 'chị'
    saved = service.update_settings(*scope(owner), 'Chị Sen', 'chị', 0, 'settings-save-0001')
    assert saved['display_name']=='Chị Sen' and saved['revision']==1
    assert service.update_settings(*scope(owner), 'Chị Sen', 'chị', 0, 'settings-save-0001')['receipt']['replayed']
    with pytest.raises(CoreError) as conflict:
        service.update_settings(*scope(owner), 'Tên khác', 'anh', 0, 'settings-save-0002')
    assert conflict.value.code=='version_conflict'
    assert service.settings(*scope(other))['display_name']=='other-workspace'
    with pytest.raises(CoreError):
        service.settings(owner['account_id'], other['enterprise_id'])
    after = app.state.repo.get_context(*scope(owner))
    assert {key:value for key,value in after.items() if key!='as_of'}=={key:value for key,value in before.items() if key!='as_of'}


def test_password_change_requires_current_secret_keeps_current_csrf_and_revokes_others(workspace):
    app, _service, owner, _other = workspace
    accounts = app.state.accounts
    first = accounts.create_session(owner['account_id'])
    second = accounts.create_session(owner['account_id'])
    with pytest.raises(CoreError) as invalid:
        accounts.change_password(owner['account_id'], first['token'], 'wrong', 'New-Workspace-TEST-123')
    assert invalid.value.code=='invalid_current_password'
    assert accounts.get_session(second['token'])['account_id']==owner['account_id']
    value = accounts.change_password(owner['account_id'], first['token'], 'Workspace-TEST-only-123', 'New-Workspace-TEST-123')
    assert value=={'status':'password_changed','other_sessions_revoked':True,
                   'message_vi':'Đã đổi mật khẩu. Những phiên đăng nhập khác đã được đăng xuất.'}
    accounts.validate_csrf(first['token'], first['csrf_token'])
    with pytest.raises(CoreError):
        accounts.get_session(second['token'])
    with pytest.raises(CoreError):
        accounts.login('owner-workspace','Workspace-TEST-only-123')
    assert accounts.login('owner-workspace','New-Workspace-TEST-123')['account_id']==owner['account_id']


def test_history_search_filters_trash_restore_and_owner_isolation(workspace):
    app, service, owner, other = workspace
    first = service.conversations.prepare_chat_draft(*scope(owner), 'Chị muốn rà số tồn kho trà sen.', 'history-free-0001', task_hint='sales_inventory')
    second = service.prepare(*scope(owner), 'Chị cần chính sách chuyển đổi số và xuất khẩu.', 'history-policy-0002')
    cid = second['conversation_id']
    matching = service.search_history(*scope(owner), query='chuyen doi so')
    assert [item['id'] for item in matching['items']]==[cid]
    assert 'xuất khẩu' in matching['items'][0]['raw_question']
    assert service.search_history(*scope(owner),task='sales_inventory')['items'][0]['id']==first['id']
    assert service.search_history(*scope(other))['items']==[]
    with pytest.raises(CoreError):
        service._visibility(*scope(other),cid,'foreign-trash-0001',True)
    archived = service._visibility(*scope(owner),cid,'history-trash-0001',True)
    assert archived['archived']
    assert cid not in {item['id'] for item in service.list_chats(*scope(owner))}
    assert service.search_history(*scope(owner),visibility='trash')['items'][0]['id']==cid
    assert service.get_chat(*scope(owner),cid)['archived']
    with pytest.raises(CoreError) as stopped:
        service.prepare(*scope(owner),'Chị cần chính sách khác.','archived-prepare-001',conversation_id=cid)
    assert stopped.value.code=='CONVERSATION_ARCHIVED'
    assert not service._visibility(*scope(owner),cid,'history-restore-001',False)['archived']
    assert service.search_history(*scope(owner),visibility='trash')['items']==[]
    with app.state.repo.connection() as db:
        assert db.execute('SELECT COUNT(*) FROM core_model_attempts').fetchone()[0]==0


def test_empty_and_archived_products_are_available_in_manager_not_ai_selector(workspace):
    app, service, owner, _other = workspace
    product = app.state.repo.create_entity(*scope(owner),'product','Sản phẩm chưa có dữ kiện',operation_id='empty-product-0001')
    shown = service.products(*scope(owner))['items']
    assert shown[0]['id']==product['id'] and shown[0]['values']=={}
    app.state.repo.archive_entity(*scope(owner),product['id'],product['version'],'archive-empty-0001')
    assert service.products(*scope(owner),False)['items']==[]
    assert service.products(*scope(owner),True)['items'][0]['archived']


def test_real_local_pdf_extracts_proposals_with_page_provenance_without_committing_ssot(workspace):
    app, service, owner, _other = workspace
    raw = pdf_bytes(['Tên sản phẩm: Trà Sen Tây Hồ','Mã sản phẩm: TS-PDF-01','Khối lượng tịnh: 100 g'])
    view = service.prepare_document(*scope(owner),'Chị đọc thông tin sản phẩm trong PDF này.',[attachment(raw)],'pdf-prepare-0001')
    intake = view['intake']
    assert intake['attachments'][0]['extraction_status']=='parsed_local_pdf'
    assert intake['attachments'][0]['egress_policy']=='server_only_no_llm'
    facts = {candidate['field']: candidate for candidate in intake['candidates']}
    assert facts['name']['value']=='Trà Sen Tây Hồ'
    assert facts['net_quantity']['value']=='100 g'
    assert facts['product_code']['value']=='TS-PDF-01'
    assert all(candidate['source']['page_number']==1 and candidate['source']['simulation'] is False for candidate in facts.values())
    assert app.state.repo.get_context(*scope(owner))['entities']==[]
    reopened = service.get_chat(*scope(owner),view['id'])
    assert reopened['intake']['id']==intake['id']
    assert reopened['model_calls']==0


def test_scanned_pdf_is_honestly_unread_and_has_no_facts():
    facts, warnings, metadata = parse_pdf(pdf_bytes([]))
    assert facts==[] and metadata['extraction_status']=='stored_not_read'
    assert any('chưa OCR' in warning for warning in warnings)


def test_pdf_limits_encryption_and_preflight_do_not_create_chat(workspace):
    app, service, owner, _other = workspace
    writer = PdfWriter()
    writer.add_blank_page(width=100,height=100)
    writer.encrypt('test-local-fixture-only')
    encrypted = BytesIO()
    writer.write(encrypted)
    with pytest.raises(CoreError) as locked:
        service.prepare_document(*scope(owner),'',[attachment(encrypted.getvalue())],'pdf-encrypted-0001')
    assert locked.value.code=='encrypted_pdf' and locked.value.commit_state=='not_started'
    with pytest.raises(CoreError) as oversized:
        service.prepare_document(*scope(owner),'',[attachment(pdf_bytes(['Tệp quá dài'],pages=21))],'pdf-overpage-00001')
    assert oversized.value.code=='pdf_page_limit' and oversized.value.commit_state=='not_started'
    with app.state.repo.connection() as db:
        assert db.execute('SELECT COUNT(*) FROM v04_conversations').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM main_operations').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM core_model_attempts').fetchone()[0]==0


@pytest.mark.asyncio
async def test_pdf_cannot_reach_paid_send_or_create_pending_operation(workspace):
    app, service, owner, _other = workspace
    with pytest.raises(CoreError) as stopped:
        await service.conversations.send_async(*scope(owner),'Chị đọc tệp.',[attachment(pdf_bytes(['Tài liệu']))],
                                                'pdf-paid-block-001',paid_consent=True,task_hint='profile_intake')
    assert stopped.value.code=='PDF_LOCAL_ONLY'
    with app.state.repo.connection() as db:
        assert db.execute('SELECT COUNT(*) FROM main_operations').fetchone()[0]==0
        assert db.execute('SELECT COUNT(*) FROM core_model_attempts').fetchone()[0]==0


def test_label_pdf_is_readable_vietnamese_preserves_draft_warning_and_rejects_invalid_mass():
    artifact = {'version':2,'market_code':'US','market_name_vi':'Mỹ','label_language':'en','product_reference':'Trà Sen Tây Hồ',
                'fields':[{'id':'net_quantity','label_vi':'Khối lượng tịnh','label_en':'Net quantity','value':'100 g','help_vi':'Đối chiếu trên bao bì.'},
                          {'id':'ingredients','label_vi':'Thành phần','label_en':'Ingredients','value':'Trà xanh, hương sen <không phải lệnh>','help_vi':'Cần bản tiếng Anh.'}]}
    pdf = render_label_pdf(artifact)
    text = '\n'.join(page.extract_text() for page in PdfReader(BytesIO(pdf)).pages)
    assert 'Trà Sen Tây Hồ' in text and '100 g' in text and 'BẢN NHÁP CHƯA DUYỆT' in text
    assert '<không phải lệnh>' in text
    for invalid_quantity in ('một trăm gam abc', '', ' '):
        artifact['fields'][0]['value']=invalid_quantity
        with pytest.raises(CoreError) as bad:
            render_label_pdf(artifact)
        assert bad.value.code=='INVALID_LABEL_VALUE'
    artifact['fields'][0]['value']='100 g'
    artifact['product_reference']='Trà Sen 🌸'
    with pytest.raises(CoreError) as missing_font:
        render_label_pdf(artifact)
    assert missing_font.value.code=='PDF_FONT_UNSUPPORTED'


@pytest.mark.asyncio
async def test_password_http_requires_csrf_and_does_not_return_secrets(workspace):
    app, _service, owner, _other = workspace
    created = app.state.accounts.create_session(owner['account_id'])
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app),base_url='http://127.0.0.1:8025',
                                 cookies={'nmate_v04a_session':created['token']}) as client:
        body = {'current_password':'Workspace-TEST-only-123','new_password':'New-HTTP-TEST-only-123'}
        denied = await client.post('/api/main/account/password',json=body)
        assert denied.status_code==403
        success = await client.post('/api/main/account/password',json=body,
                                    headers={'Origin':'http://127.0.0.1:8025','X-CSRF-Token':created['csrf_token']})
        assert success.status_code==200 and success.json()['status']=='password_changed'
        assert 'TEST' not in success.text and 'token' not in success.text and 'hash' not in success.text
