"""Registered immutable draft DDL migrates atomically; arbitrary triggers stay forbidden."""
from pathlib import Path
import sqlite3

import pytest

from nmate.core_v1.schema_lifecycle import create_plan, apply_plan, SchemaLifecycleError
from nmate.policy_v05.workbench import SCHEMA


def statements():
    result, pending = [], ""
    for line in SCHEMA.splitlines(keepends=True):
        pending += line
        if sqlite3.complete_statement(pending):
            result.append(pending.strip())
            pending = ""
    assert not pending.strip()
    return result


def base(path):
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE v03_enterprises(id TEXT PRIMARY KEY)")
        db.execute("CREATE TABLE v03_accounts(id TEXT PRIMARY KEY)")
        db.execute("INSERT INTO v03_enterprises VALUES('preserve-enterprise')")


def plan(path, sql=None):
    root = Path(__file__).resolve().parents[1] / "src"
    return create_plan(path, version="mvp05-policy-drafts-1", statements=sql or statements(), source_root=root,
                       dependency_files=["nmate/policy_v05/workbench.py"]), root


def test_registered_workbench_schema_migration_preserves_data_and_receipt_replays(tmp_path):
    path = tmp_path / "old.sqlite"
    base(path)
    value, root = plan(path)
    assert value["dry_run"]["original_writes"] == 0
    receipt = apply_plan(path, value, source_root=root)
    assert apply_plan(path, value, source_root=root) == receipt
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT id FROM v03_enterprises").fetchall() == [("preserve-enterprise",)]
        assert db.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'pol05_%'").fetchone()[0] == 4
        assert db.execute("SELECT count(*) FROM pol05_drafts").fetchone()[0] == 0


def test_partial_workbench_migration_rolls_back_all_registered_objects(tmp_path):
    path = tmp_path / "rollback.sqlite"
    base(path)
    value, root = plan(path)

    def interrupted(index):
        if index == 5:
            raise RuntimeError("simulated interruption")

    with pytest.raises(RuntimeError, match="interruption"):
        apply_plan(path, value, source_root=root, after_statement=interrupted)
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT count(*) FROM sqlite_master WHERE name LIKE 'pol05_%'").fetchone()[0] == 0
        assert db.execute("SELECT id FROM v03_enterprises").fetchall() == [("preserve-enterprise",)]


@pytest.mark.parametrize("sql", [
    "CREATE TRIGGER evil AFTER INSERT ON v03_enterprises BEGIN DELETE FROM v03_accounts; END;",
    "CREATE TRIGGER IF NOT EXISTS pol05_revisions_immutable BEFORE UPDATE ON v03_enterprises BEGIN SELECT RAISE(ABORT,'immutable policy draft revision'); END;",
    "CREATE TRIGGER IF NOT EXISTS pol05_revisions_immutable BEFORE UPDATE ON pol05_revisions BEGIN DELETE FROM v03_accounts; END;",
])
def test_unregistered_or_modified_trigger_is_rejected(tmp_path, sql):
    path = tmp_path / "unsafe.sqlite"
    base(path)
    with pytest.raises(SchemaLifecycleError):
        plan(path, [sql])
