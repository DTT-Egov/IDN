"""Snapshot-bound public context: no model, network, credentials or current-case reads."""
from copy import deepcopy
import json

import pytest

from nmate.config import Settings
from nmate.models import CaseCreate, Principal, StartInput
from nmate.service import ResearchService, public_run
from nmate.store import Store


def test_public_run_whitelists_snapshot_sku_and_name_without_mutating_snapshot():
    run = {
        "run_id": "MOCK-RUN", "case_id": "MOCK-CASE", "profile_version": 1,
        "tenant_id": "MOCK-PRIVATE-TENANT", "status": "succeeded",
        "case_summary": {"sku": "MOCK-WRONG", "name": "MOCK-WRONG", "secret": "MOCK-UNTRUSTED"},
        "snapshot": {
            "product": {"sku": "MOCK-ORIGINAL", "name": "MOCK Miến gốc", "ingredients": ["MOCK-PRIVATE-INGREDIENT"]},
            "owner": "MOCK-PRIVATE-OWNER", "email": "MOCK-PRIVATE-EMAIL",
            "shipment": {"importer_of_record": "MOCK-PRIVATE-IOR"},
            "consent_model": True,
        },
    }
    before = deepcopy(run)
    result = public_run(run)
    assert result["case_summary"] == {"sku": "MOCK-ORIGINAL", "name": "MOCK Miến gốc"}
    assert "snapshot" not in result and "tenant_id" not in result
    serialized = json.dumps(result, ensure_ascii=False)
    assert "MOCK-PRIVATE" not in serialized and "MOCK-UNTRUSTED" not in serialized
    assert run == before
    result["case_summary"]["sku"] = "MOCK-MUTATED-CLIENT"
    assert run == before


@pytest.mark.parametrize("snapshot", [None, [], "MOCK-bad-snapshot", {}, {"product": None}, {"product": []}])
def test_legacy_or_malformed_snapshot_does_not_guess_context(snapshot):
    result = public_run({"run_id": "MOCK-LEGACY", "snapshot": snapshot,
                         "case_summary": {"sku": "MOCK-UNTRUSTED"}})
    assert result == {"run_id": "MOCK-LEGACY"}


def test_legacy_run_without_snapshot_keeps_unknown_context():
    assert public_run({"run_id": "MOCK-LEGACY", "profile_version": 1}) == {
        "run_id": "MOCK-LEGACY", "profile_version": 1,
    }


def test_only_nonempty_string_summary_fields_can_be_exposed():
    result = public_run({"snapshot": {"product": {"sku": {"private": "MOCK-SECRET"}, "name": "MOCK hợp lệ"}}})
    assert result == {"case_summary": {"name": "MOCK hợp lệ"}}
    assert public_run({"snapshot": {"product": {"sku": " ", "name": None}}}) == {}


def test_service_context_remains_pinned_to_run_snapshot_after_current_case_changes(tmp_path):
    principal = Principal("MOCK-TENANT", "MOCK-USER", "business")
    store = Store(tmp_path / "run-context.sqlite3")
    initial = CaseCreate.model_validate({
        "product": {"sku": "MOCK-SKU-V1", "name": "MOCK Miến phiên bản đầu", "ingredients": ["MOCK tinh bột"]},
        "shipment": {"importer_of_record": "MOCK-PRIVATE-IOR"}, "consent_research": True,
    }).model_dump(mode="json")
    case = store.create_case(principal, initial)
    settings = Settings(_env_file=None, data_dir=tmp_path, mode="evidence_only")
    service = ResearchService(store, settings, None, graph_factory=lambda *_args, **_kwargs: None)
    started = service.start(principal, StartInput.model_validate({
        "case_id": case["case_id"], "expected_case_version": 1,
        "idempotency_key": "MOCK-run-context-key", "question": "MOCK chuẩn bị hồ sơ",
    }))
    expected = {"sku": "MOCK-SKU-V1", "name": "MOCK Miến phiên bản đầu"}
    assert started["case_summary"] == expected
    changed = deepcopy(initial)
    changed["product"].update(sku="MOCK-SKU-V2", name="MOCK sản phẩm mới")
    store.replace_case(principal, case["case_id"], 1, changed)
    settings.simple_model = "claude-MOCK-new-simple"
    settings.complex_model = "claude-MOCK-new-complex"

    # Public start/get/list/cancel all use the same immutable run snapshot,
    # including a process/store reopen; none consult current product values.
    reopened = Store(store.path)
    second = ResearchService(reopened, settings, None, graph_factory=lambda *_args, **_kwargs: None)
    outputs = [started, second.get_run(principal, started["run_id"]),
               public_run(reopened.list_runs(principal)[0]), second.cancel(principal, started["run_id"])]
    for output in outputs:
        assert output["profile_version"] == 1
        assert output["case_summary"] == expected
        assert "snapshot" not in output and "tenant_id" not in output
        assert "MOCK-PRIVATE-IOR" not in json.dumps(output)
    assert reopened.get_case(principal, case["case_id"])["product"]["sku"] == "MOCK-SKU-V2"
