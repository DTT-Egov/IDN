"""Owned list labels expose only decision metadata, never whole transcripts.

Isolated SQLite and deterministic local model fixtures; no credentials/network.
"""
import copy
import json

import pytest
from fastapi.testclient import TestClient

from nmate.app import create_app
from nmate.conversations.models import ConversationSummary
from nmate.models import Principal

from test_conversations import P, confirm, fact, output, send, settings, setup


@pytest.mark.asyncio
async def test_summary_uses_pending_goal_and_keeps_unknowns_and_body_private(tmp_path):
    question = "Mình có trà sen Tây Hồ, muốn gửi New York. Mình nên bắt đầu từ đâu?"
    service, fake, body = setup(tmp_path, output([
        fact("product.name", "trà sen Tây Hồ", "trà sen Tây Hồ"),
        fact("question", question, question),
    ]))
    pending = await send(service, body, question)
    assert pending["draft"]["product"]["name"] is None
    rows = service.store.list(P)
    assert len(rows) == 1
    summary = ConversationSummary.model_validate(rows[0]).model_dump()
    assert summary["question"] == question
    assert summary["product_summary"] == {"name": "trà sen Tây Hồ"}
    assert summary["research_links"] == []
    assert summary["activity_state"]["status"] == "pending_confirmation"
    assert set(summary).isdisjoint({"messages", "draft", "pending_proposal", "consents", "field_sources"})
    confirmed = confirm(service, pending)
    assert service.store.list(P)[0]["question"] == question
    assert confirmed["draft"]["product"]["certifications"] is None
    assert len(fake.calls) == 1


def test_list_keeps_saved_link_goal_and_product_separate_from_current_draft(tmp_path):
    service, fake, body = setup(tmp_path)
    stored = copy.deepcopy(body)
    stored["draft"]["product"]["name"] = "Trà Sen Tây Hồ mới"
    stored["draft"]["question"] = "Câu hỏi hiện tại"
    stored["research_links"] = [{
        "case_id": "TEST-CASE", "case_version": 1, "run_id": "TEST-RUN",
        "artifact_id": "TEST-ARTIFACT", "question": "Câu hỏi nhãn đã lưu",
        "created_at": body["created_at"],
        "product_summary": {"name": "Trà Sen Tây Hồ", "sku": "TEST-TEA"},
    }]
    with service.store.business.connection(write=True) as db:
        db.execute("UPDATE conversations SET body=? WHERE id=?", (json.dumps(stored), body["conversation_id"]))
    before = copy.deepcopy(service.store.get(P, body["conversation_id"]))
    summary = ConversationSummary.model_validate(service.store.list(P)[0]).model_dump()
    assert summary["question"] == "Câu hỏi hiện tại"
    assert summary["product_summary"]["name"] == "Trà Sen Tây Hồ mới"
    assert summary["research_links"][0]["question"] == "Câu hỏi nhãn đã lưu"
    assert summary["research_links"][0]["product_summary"]["name"] == "Trà Sen Tây Hồ"
    assert service.store.get(P, body["conversation_id"])["research_links"] == before["research_links"]
    assert not fake.calls


@pytest.mark.parametrize("foreign", [
    Principal(subject="OTHER-BUSINESS", tenant_id=P.tenant_id, role="business"),
    Principal(subject=P.subject, tenant_id="OTHER-TENANT", role="business"),
])
def test_goal_and_link_metadata_stays_owner_and_tenant_scoped(tmp_path, foreign):
    service, fake, body = setup(tmp_path)
    assert len(service.store.list(P)) == 1
    assert service.store.list(foreign) == []
    assert not fake.calls


def test_http_summary_schema_returns_minimal_metadata_and_other_profile_sees_nothing(tmp_path):
    app = create_app(settings(tmp_path))
    with TestClient(app, base_url="http://127.0.0.1:8022") as owner:
        csrf = owner.get("/api/session").json()["csrf_token"]
        created = owner.post("/api/conversations", headers={"X-CSRF-Token": csrf},
                             json={"consent_storage": True, "consent_model": True})
        assert created.status_code == 201
        body = created.json()
        edited = owner.post(f"/api/conversations/{body['conversation_id']}/facts", headers={"X-CSRF-Token": csrf},
                            json={"expected_version": body["version"], "idempotency_key": "SUMMARY-METADATA-TEST",
                                  "changes": [{"field": "product.name", "value": "Trà Sen Tây Hồ", "certainty": "provided"},
                                              {"field": "question", "value": "Mình cần làm rõ vai trò nhập khẩu?", "certainty": "provided"}]})
        assert edited.status_code == 200
        rows = owner.get("/api/conversations")
        assert rows.status_code == 200
        assert rows.headers["cache-control"] == "no-store"
        result = rows.json()[0]
        assert result["question"] == "Mình cần làm rõ vai trò nhập khẩu?"
        assert result["product_summary"] == {"name": "Trà Sen Tây Hồ"} and result["research_links"] == []
        assert "messages" not in result and "draft" not in result
        with TestClient(create_app(settings(tmp_path)), base_url="http://127.0.0.1:8022") as other:
            other.get("/api/session")
            assert other.get("/api/conversations").json() == []
