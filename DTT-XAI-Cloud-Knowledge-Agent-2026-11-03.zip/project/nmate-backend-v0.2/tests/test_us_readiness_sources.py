"""Independent integrity and deployment-boundary checks for public US sources.

This file reads the actual versioned pack and installs only into temporary DBs.
It does not fetch sources, simulate a model answer, or connect to MAIN.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import socket
from urllib.parse import urlsplit

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreRepository
from nmate.v03.install_readiness import install_readiness_pack


PACK_PATH = Path(__file__).parents[1] / "src/nmate/v03/data/us_readiness_20261022.json"
PACK_ID = "us-readiness-2026-10-22-v1"


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Public source pack tests must use no network/model transport")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


@pytest.fixture
def pack():
    return json.loads(PACK_PATH.read_text(encoding="utf-8"))


def by_id(pack, record_id):
    return next(record for record in pack["records"] if record["id"] == record_id)


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def test_pack_is_bounded_verbatim_versioned_and_unreviewed(pack):
    assert pack["pack_id"] == PACK_ID
    assert pack["install_policy"] == "explicit_operator_install_only"
    assert 6 <= len(pack["records"]) <= 12
    sources = {source["id"]: source for source in pack["sources"]}
    assert len(sources) == len(pack["sources"])
    assert len({record["id"] for record in pack["records"]}) == len(pack["records"])
    assert {topic for record in pack["records"] for topic in record["topics"]} == {
        "facility_registration", "prior_notice", "fsvp_importer", "origin_marking"}
    for source in sources.values():
        parsed = urlsplit(source["url"])
        assert parsed.scheme == "https" and parsed.hostname in {
            "www.fda.gov", "www.ecfr.gov", "www.govinfo.gov"}
        assert not parsed.username and not parsed.password and not parsed.fragment
        assert source["content_sha256"] == digest(source["text"])
        assert source["legal_review_state"] == "reference_unreviewed"
        assert source["no_complete_current_law_claim"] is True
    for record in pack["records"]:
        assert record["source_id"] in sources
        assert record["excerpt"] in sources[record["source_id"]]["text"]
        assert record["excerpt_original"] == record["excerpt"]
        assert record["excerpt_sha256"] == digest(record["excerpt"])
        assert record["locator"]["excerpt_sha256"] == record["excerpt_sha256"]
        assert record["excerpt_vi"] and record["readiness_summary_vi"]
        assert record["review_state"] == record["translation_state"] == "reference_unreviewed"
        assert record["no_complete_current_law_claim"] is True
        assert record["scope"]["jurisdiction"] == "US"


def test_cfr_tool_capture_does_not_invent_http_success_or_body_hash(pack):
    cfr = [source for source in pack["sources"] if urlsplit(source["url"]).hostname == "www.ecfr.gov"]
    assert cfr
    for source in cfr:
        assert source["retrieval_provider"] == "official_web_tool"
        assert source["body_sha256"] is None
        assert source["http_status"] is None
        assert source["raw_body_unavailable"] is True
        assert source["direct_network_check_at_capture"] == "unavailable_automated_access_challenge"
        assert source["runtime_check_required"] is True
    direct = [source for source in pack["sources"] if source["retrieval_provider"] == "direct_official_html"]
    assert {urlsplit(source["url"]).hostname for source in direct} == {"www.fda.gov", "www.govinfo.gov"}
    assert all(source["http_status"] == 200 and len(source["body_sha256"]) == 64 for source in direct)


def test_registration_conditions_survive_narrow_excerpts(pack):
    scope = by_id(pack, "US_REGISTRATION_SCOPE_20261022_V1")["excerpt"]
    assert "unless your facility qualifies for one of the exemptions" in scope
    foreign = by_id(pack, "US_REGISTRATION_EXEMPTIONS_20261022_V1")["excerpt"]
    assert "another facility outside the United States" in foreign
    assert "not exempt" in foreign and "adding labeling" in foreign and "de minimis" in foreign
    retail = by_id(pack, "US_REGISTRATION_RETAIL_20261022_V1")["excerpt"]
    assert "annual monetary value" in retail and "exceeds" in retail
    assert "does not include businesses" in retail
    manufacturing = by_id(pack, "US_REGISTRATION_DEFINITIONS_20261022_V1")["excerpt"]
    assert "Manufacturing/processing means" in manufacturing
    assert "does not include activities that are part of harvesting, packing, or holding" in manufacturing
    assert len(retail) <= 1200 and len(manufacturing) <= 1200
    assert "farm_definition" not in by_id(pack, "US_REGISTRATION_DEFINITIONS_20261022_V1")["readiness_facets"]


def test_prior_notice_has_scope_who_timing_exceptions_and_current_mail_distinction(pack):
    records = [record for record in pack["records"] if record["topics"] == ["prior_notice"]]
    assert {facet for record in records for facet in record["readiness_facets"]} >= {
        "scope", "submitter", "timing", "exceptions", "international_mail_update"}
    who = by_id(pack, "US_PN_SUBMITTER_20261022_V1")["excerpt"]
    assert "any person with knowledge of the required information" in who
    assert "submitter and transmitter may be the same person" in who
    timing = by_id(pack, "US_PN_TIMING_20261022_V1")["excerpt"]
    for fact in ("2 hours", "4 hours", "8 hours", "30-calendar days", "15-calendar days",
                 "before the article of food is sent", "confirmed your prior notice for review"):
        assert fact in timing
    exception = by_id(pack, "US_PN_SCOPE_EXCEPTIONS_20261022_V1")["excerpt"]
    assert "samples" in exception and "nonbusiness reasons" in exception
    mail = by_id(pack, "US_PN_MAIL_UPDATE_20261022_V1")["excerpt"]
    assert "September 25, 2025" in mail and "October 1, 2026" in mail
    assert "does not expect industry" in mail and "May 1, 2027" in mail


def test_fsvp_roles_and_tea_origin_exception_are_kept_separate(pack):
    importer = by_id(pack, "US_FSVP_IMPORTER_20261022_V1")["excerpt"]
    for phrase in ("U.S. owner or consignee", "at the time of U.S. entry", "signed statement of consent"):
        assert phrase in importer
    scope = by_id(pack, "US_FSVP_SCOPE_EXCEPTIONS_20261022_V1")["excerpt"]
    assert "not intended for retail sale" in scope and "electronic declaration" in scope
    general = by_id(pack, "US_ORIGIN_GENERAL_20261022_V1")["excerpt"]
    assert "Unless excepted by law" in general and "unless the container is also excepted" in general
    tea = by_id(pack, "US_ORIGIN_TEA_EXCEPTION_20261022_V1")
    assert "subsections (a) and (b) shall not apply" in tea["excerpt"]
    assert all(code in tea["excerpt"] for code in ("0902.10", "0902.20", "0902.30", "0902.40", "2101.20"))
    assert "January 1, 1995" in tea["excerpt"]
    assert "2024" in tea["conditions_vi"]
    assert {r["source_id"] for r in pack["records"] if "fsvp_importer" in r["topics"]}.isdisjoint(
        {r["source_id"] for r in pack["records"] if "origin_marking" in r["topics"]})


def rows(repo, table):
    with repo.connection() as db:
        return {row["id"]: dict(row) for row in db.execute(f"SELECT * FROM {table}")}


def test_explicit_install_is_additive_idempotent_and_not_a_constructor_effect(tmp_path, pack):
    repo = CoreRepository(tmp_path / "readiness-source-audit.sqlite3")
    catalog = DomainCatalog(repo)
    before_sources = rows(repo, "v03_domain_sources")
    before_records = rows(repo, "v03_domain_references")
    assert not ({record["id"] for record in pack["records"]} & before_records.keys())
    initial = install_readiness_pack(repo)
    assert initial["paid_calls"] == 0 and initial["legal_review"] == "reference_unreviewed"
    assert initial["inserted_rows"]["v03_domain_sources"] == len(pack["sources"])
    assert initial["inserted_rows"]["v03_domain_references"] == len(pack["records"])
    after_sources, after_records = rows(repo, "v03_domain_sources"), rows(repo, "v03_domain_references")
    assert {key: after_sources[key] for key in before_sources} == before_sources
    assert {key: after_records[key] for key in before_records} == before_records
    repeat = install_readiness_pack(repo)
    assert set(repeat["inserted_rows"].values()) == {0}
    assert rows(repo, "v03_domain_sources") == after_sources
    assert rows(repo, "v03_domain_references") == after_records
    DomainCatalog(repo)
    assert rows(repo, "v03_domain_sources") == after_sources
    assert rows(repo, "v03_domain_references") == after_records
    topics = ["prior_notice", "fsvp_importer", "origin_marking"]
    viewed = catalog.lookup_domain(topics, market_code="US", as_of_date="2026-10-22")
    assert set(viewed["coverage"]["supported"]) == set(topics)
    assert {record["id"] for record in viewed["records"] if record["reusable"]} >= {
        "US_PN_SUBMITTER_20261022_V1", "US_PN_TIMING_20261022_V1", "US_PN_MAIL_UPDATE_20261022_V1",
        "US_FSVP_IMPORTER_20261022_V1", "US_ORIGIN_TEA_EXCEPTION_20261022_V1"}
    assert rows(repo, "v03_domain_sources") == after_sources
    assert rows(repo, "v03_domain_references") == after_records


def test_supersession_is_date_bound_and_keeps_historical_references(tmp_path, pack):
    repo = CoreRepository(tmp_path / "readiness-history.sqlite3")
    catalog = DomainCatalog(repo)
    install_readiness_pack(repo)
    old_ids = {item["old_reference_id"] for item in pack["supersessions"]}
    assert old_ids == {"FDA_PRIOR_NOTICE_SCOPE_VI_20261019_V1",
        "FDA_PRIOR_NOTICE_SUBMITTER_VI_20261019_V1", "FDA_PRIOR_NOTICE_TIMING_VI_20261019_V1"}
    historic = catalog.lookup_domain(["prior_notice"], market_code="US", as_of_date="2026-10-21")
    current = catalog.lookup_domain(["prior_notice"], market_code="US", as_of_date="2026-10-22")
    assert old_ids <= {record["id"] for record in historic["records"]}
    assert old_ids.isdisjoint({record["id"] for record in current["records"]})
    assert all(record["introduced_on"] == "2026-10-22" for record in current["records"])
    assert old_ids <= rows(repo, "v03_domain_references").keys()
    assert "FDA_US_AGENT_VI_20261018_DRAFT" in rows(repo, "v03_domain_references")
