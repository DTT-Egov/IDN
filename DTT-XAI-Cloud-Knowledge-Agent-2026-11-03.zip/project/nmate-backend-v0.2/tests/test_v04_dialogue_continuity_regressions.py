"""Owner-reported conversational regressions, without any model dispatch."""
import httpx
import pytest

from nmate.v04.conversations import ConversationService
from nmate.v04.dialogue import interpret, next_steps, address_text
from nmate.v04.intake import IntakeService
from test_v04_intake import workspace as shared_workspace, synthetic_workbook, confirm
from test_v04_intake import server as shared_server


@pytest.fixture
def workspace(tmp_path):
    return shared_workspace.__wrapped__(tmp_path)


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    yield from shared_server.__wrapped__(tmp_path_factory)


def send(chat, owner, text, operation, conversation_id=None):
    return chat.send(owner["account_id"], owner["enterprise_id"], text, [], operation,
                     conversation_id=conversation_id)


@pytest.mark.parametrize("reload_before_reply", [False, True])
@pytest.mark.parametrize("reply", ["Ngày 18/10/2026, mã TS01",
                                  "Ngày 18/10/2026, mã sản phẩm TS01, chị nhé"])
def test_inventory_counts_then_date_code_continue_to_documents(workspace, reload_before_reply, reply):
    repo, intake, owner, _ = workspace
    chat = ConversationService(intake)
    start = send(chat, owner, "Chị muốn cập nhật hồ sơ", "continuity-profile-start")
    counts = send(chat, owner, "Tồn trên sổ 120, đếm thực tế 110", "continuity-counts", start["id"])
    assert counts["intake"]["intent"]["focus"] == "inventory_accuracy"
    assert "-10" in counts["messages"][-1]["text"]
    assert "ngày kiểm kê" in counts["intake"]["pending_question"]
    if reload_before_reply:
        # Recreate services from the database rather than reusing in-memory intent.
        chat = ConversationService(IntakeService(repo))
        counts = chat.get(owner["account_id"], owner["enterprise_id"], start["id"])
    result = send(chat, owner, reply, "continuity-date-code", counts["id"])
    item = result["intake"]
    assert item["id"] == counts["intake"]["id"]
    assert item["intent"]["primary"] == "digitize_operations"
    assert item["intent"]["focus"] == "inventory_accuracy"
    assert item["intent"]["working_answers"] == {
        "book_quantity": 120.0, "physical_quantity": 110.0,
        "count_date": "2026-10-18", "product_code": "TS01"}
    assert item["intent"]["address_term"] == "chị"
    assert "đối chiếu phiếu nhập/xuất" in item["pending_question"]
    assert "18/10/2026" in item["pending_question"] and "TS01" in item["pending_question"]
    assert not any("bạn" in text.casefold() for text in [item["assistant_text"], item["pending_question"]])
    reopened = ConversationService(IntakeService(repo)).get(owner["account_id"], owner["enterprise_id"], start["id"])
    assert reopened["intake"]["intent"] == item["intent"]
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


@pytest.mark.parametrize("text", ["Chị muốn vay vốn ngân hàng cho cơ sở", "Có gói tín dụng nào cho doanh nghiệp?",
                                 "Tư vấn huy động vốn cho chị", "Chị muốn vay vốn để xuất khẩu đi Mỹ"])
def test_financing_is_explicitly_unsupported_without_task_menu(workspace, text):
    repo, intake, owner, _ = workspace
    result = send(ConversationService(intake), owner, text, "unsupported-financing")
    item = result["intake"]
    assert item["intent"]["unsupported_request"] == "financing"
    assert item["intent"]["unsupported_reason_vi"] == item["assistant_text"]
    assert "chưa hỗ trợ" in item["assistant_text"]
    assert "vay vốn" in item["assistant_text"]
    assert item["pending_question"] is None
    assert item["business_plan"] == []
    assert "số hóa vận hành, cải thiện bao bì" not in " ".join(item["next_steps"])
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


def test_confirmation_uses_declared_address_without_rewriting_product_name(workspace):
    repo, intake, owner, _ = workspace
    chat = ConversationService(intake)
    result = chat.send(owner["account_id"], owner["enterprise_id"], "Chị muốn cập nhật hồ sơ",
                       [synthetic_workbook([["product", "name", "Trà Chị Sen", "", ""]])],
                       "address-confirmation-start")
    confirm(intake, owner, result["intake"])
    reopened = ConversationService(IntakeService(repo)).get(owner["account_id"], owner["enterprise_id"], result["id"])
    confirmation = next(message["text"] for message in reopened["messages"] if message["kind"] == "confirmation")
    assert confirmation == "Đã ghi nhớ 1 dữ kiện chị xác nhận."
    assert reopened["intake"]["product"]["name"] == "Trà Chị Sen"


@pytest.mark.parametrize("text,term", [
    ("Chị muốn đối chiếu tồn kho", "chị"),
    ("Chị có sản phẩm Trà Sen Tây Hồ", "chị"),
    ("Cơ sở của chị bán trà sen", "chị"),
    ("Gọi tôi là chị nhé", "chị"),
    ("Tôi có sản phẩm Trà Chị Sen", "bạn"),
    ("Bà Lan là chị của tôi", "bạn"),
    ("Chính sách hỗ trợ doanh nghiệp", "bạn"),
    ("Chỉ muốn cập nhật hồ sơ", "bạn"),
    ("Có cần đăng ký cơ sở không?", "bạn"),
    ("Chị có thể giúp tôi không?", "bạn"),
])
def test_address_uses_explicit_self_reference_only(text, term):
    assert interpret(text)["address_term"] == term


@pytest.mark.parametrize("text,followup", [
    ("Chị hỏi FDA cho Trà Sen Tây Hồ đi Mỹ.", "Mỹ"),
    ("Chị gửi tồn trên sổ 120, đếm thực tế 110.", "Ngày 18/10/2026, mã TS01"),
    ("Chị báo tồn trên sổ 120, đếm thực tế 110.", "Ngày 18/10/2026, mã TS01"),
])
def test_address_in_report_or_question_survives_next_turn_and_reload(workspace, text, followup):
    repo, intake, owner, _ = workspace
    first = send(ConversationService(intake), owner, text, "address-report-start")
    assert first["intake"]["intent"]["address_term"] == "chị"
    chat = ConversationService(IntakeService(repo))
    reopened = chat.get(owner["account_id"], owner["enterprise_id"], first["id"])
    result = send(chat, owner, followup, "address-report-followup", reopened["id"])
    assert result["intake"]["intent"]["address_term"] == "chị"
    generated_text = result["intake"]["assistant_text"] + " " + (result["intake"]["pending_question"] or "")
    assert "bạn" not in generated_text.casefold()
    assert address_text("Bạn kiểm tra phần vừa gửi.", result["intake"]["intent"]) == "Chị kiểm tra phần vừa gửi."


@pytest.mark.parametrize("question,topic", [
    ("Trà Sen đi Mỹ có cần đăng ký FDA không?", "facility_registration"),
    ("Nhãn Trà Sen đi Mỹ cần ghi gì?", "food_label"),
    ("Ai nộp prior notice và nộp lúc nào cho lô sang Mỹ?", "prior_notice"),
])
def test_free_export_response_names_unanswered_regulatory_question(question, topic):
    intent = interpret(question)
    steps = next_steps({"intent": intent, "text": question, "export_question_topics": [topic],
                        "saved_context": {"entities": []}, "product": None})
    assert "chưa" in steps[0].casefold()
    assert "nghiên cứu" in steps[0].casefold()
    assert "Đã ghi nhận thị trường" not in steps[0]
    assert "Nhật" not in " ".join(steps)


@pytest.mark.parametrize("reply", ["Ngày 18/10/2026, mã TS01", "Ngày 18/10/2026, mã sản phẩm TS01, chị nhé"])
def test_legacy_free_mcp_prepare_reload_clarify_keeps_inventory(server, reply):
    with httpx.Client(base_url=server["url"], timeout=20) as web:
        pre = web.get("/api/v03/session").json()
        headers = {"Origin": server["url"], "X-CSRF-Token": pre["csrf_token"]}
        session = web.post("/api/v03/register", headers=headers, json={
            "username": "http-inventory-" + ("natural" if "sản phẩm" in reply else "exact"),
            "password": "Test-only-secret-inventory", "enterprise_name": "Trà Sen kiểm thử"}).json()
        headers["X-CSRF-Token"] = session["csrf_token"]

        def tool(name, **arguments):
            response = web.post("/api/v03/mcp/call", headers=headers, json={
                "name": name, "arguments": {"enterprise_id": session["enterprise"]["id"], **arguments}})
            assert response.status_code == 200, response.text
            envelope = response.json()
            assert envelope["ok"], envelope
            return envelope["data"]

        item = tool("prepare_intake", text="Tồn trên sổ 120, đếm thực tế 110", attachments=[],
                    operation_id="legacy-inventory-counts")
        assert item["intent"]["focus"] == "inventory_accuracy"
        assert item["intent"]["working_answers"]["book_quantity"] == 120
        assert "-10" in str(item["next_steps"])
        reloaded = tool("get_intake", intake_id=item["id"])
        assert reloaded["intent"] == item["intent"]
        result = tool("clarify_intake", intake_id=reloaded["id"], text=reply,
                      operation_id="legacy-inventory-date-code")
        assert result["intent"]["primary"] == "digitize_operations"
        assert result["intent"]["working_answers"] == {
            "book_quantity": 120.0, "physical_quantity": 110.0,
            "count_date": "2026-10-18", "product_code": "TS01"}
        assert "đối chiếu phiếu nhập/xuất" in result["pending_question"]
        assert tool("get_intake", intake_id=item["id"])["intent"] == result["intent"]
        assert web.get("/health").json()["paid_calls"] == 0
