"""Exact local attachment rejection metadata, never a model dispatch contract."""
import copy
import hashlib
from types import SimpleNamespace

import httpx
import pytest

from nmate.v03.core import CoreError
from nmate.v03.mcp import public_core_error
from nmate.v04.pdf_intake import extract_pdf_pages
from test_core_policy_http import call, register, running
from test_review_commands_v2 import data_snapshot
from test_workspace_management import attachment, pdf_bytes, scope, workspace as workspace_fixture


@pytest.fixture(name='workspace')
def local_document_workspace(tmp_path):
    return workspace_fixture.__wrapped__(tmp_path)


def expected_rejection(raw, operation, index, count, code='invalid_pdf'):
    return {'kind': 'document_attachment_rejected', 'operation_id': operation,
            'attachment_index': index, 'attachment_count': count,
            'attachment_sha256': hashlib.sha256(raw).hexdigest(),
            'disposition': 'remove_from_pending', 'reason': code}


@pytest.mark.parametrize('raw', [b'PK\x03\x04Excel renamed PDF', b'%PDF-1.7\nnot PDF structure'])
def test_bad_pdf_identifies_only_the_rejected_file_without_writes(workspace, raw):
    app, service, owner, _ = workspace
    good = attachment(pdf_bytes(['Tên sản phẩm: Bột sen']), 'same-name.pdf')
    bad = attachment(raw, 'same-name.pdf')
    files = [good, bad, copy.deepcopy(bad)]
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as rejected:
        service.prepare_document(*scope(owner), 'Chị đọc các tệp.', files, 'pdf-reject-specific-001')
    error = public_core_error(rejected.value)
    assert error['code'] == 'invalid_pdf' and error['commit_state'] == 'not_started'
    assert error['details'] == expected_rejection(raw, 'pdf-reject-specific-001', 1, 3)
    assert data_snapshot(app.state.repo) == before


def test_bad_signature_metadata_survives_real_http_mcp(tmp_path, monkeypatch):
    from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
    async def no_source_refresh(_self):
        return False
    monkeypatch.setattr(SourceRefreshJobs, 'execute_next', no_source_refresh)
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        pytest.fail('Local PDF rejection reached a model')
    raw = b'PK\x03\x04Excel renamed PDF'
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, 'residual-pdf-owner')
            before = data_snapshot(app.state.repo)
            result = call(web, url, session, 'prepare_document_draft', text='Chị đọc tệp.',
                          attachments=[attachment(raw)], operation_id='pdf-http-reject-001')
            assert result['ok'] is False
            assert result['error']['details'] == expected_rejection(raw, 'pdf-http-reject-001', 0, 1)
            assert result['error']['commit_state'] == 'not_started'
            assert data_snapshot(app.state.repo) == before and calls == []


@pytest.mark.parametrize('code,state', [('pdf_resource_limit', 'not_started'), ('access_denied', 'not_started'),
    ('invalid_workbook', 'not_started'),
    ('invalid_pdf', None), ('invalid_pdf', 'not_committed'), ('invalid_pdf', 'committed')])
def test_uncertain_resource_or_non_preflight_errors_never_remove_file(code, state):
    error = CoreError(code, 'Chưa đủ căn cứ.')
    if state:
        error.commit_state = state
    error.details = expected_rejection(b'fake', 'pdf-negative-001', 0, 1, code)
    assert 'details' not in public_core_error(error)


@pytest.mark.parametrize('change', [
    {'attachment_index': True}, {'attachment_index': 1}, {'attachment_count': 4},
    {'attachment_sha256': 'x' * 64}, {'operation_id': ''}, {'reason': 'access_denied'},
    {'disposition': 'delete_saved_attachment'}, {'kind': 'generic_error'},
])
def test_rejection_serializer_rejects_unbounded_or_mismatched_metadata(change):
    error = CoreError('invalid_pdf', 'PDF không hợp lệ.')
    error.commit_state = 'not_started'
    error.details = {**expected_rejection(b'fake', 'pdf-negative-002', 0, 1), **change}
    assert 'details' not in public_core_error(error)


def test_rejection_metadata_is_stripped_to_the_safe_manifest_only():
    error = CoreError('invalid_pdf', 'PDF không hợp lệ.')
    error.commit_state = 'not_started'
    expected = expected_rejection(b'fake', 'pdf-sanitize-001', 0, 1)
    error.details = {**expected, 'filename': 'private-name.pdf', 'raw_document': 'not-public',
                     'content': 'private-content', 'path': 'private-path'}
    assert public_core_error(error)['details'] == expected


def test_failed_replay_does_not_remove_a_saved_receipts_attachment(workspace, monkeypatch):
    app, service, owner, _ = workspace
    files = [attachment(pdf_bytes(['Tên sản phẩm: Bột sen', 'Khối lượng tịnh: 200 g']))]
    operation = 'pdf-replay-reject-001'
    prepared = service.prepare_document(*scope(owner), 'Chị đọc tệp.', files, operation)
    before = data_snapshot(app.state.repo)
    def failure(_):
        raise CoreError('invalid_pdf', 'Không đọc được PDF trong lần kiểm này.')
    monkeypatch.setattr('nmate.v04.pdf_intake.parse_pdf', failure)
    with pytest.raises(CoreError) as rejected:
        service.prepare_document(*scope(owner), 'Chị đọc tệp.', files, operation)
    error = public_core_error(rejected.value)
    assert 'details' not in error and 'commit_state' not in error
    assert data_snapshot(app.state.repo) == before
    assert service.get_chat(*scope(owner), prepared['id'])['id'] == prepared['id']


def test_revoked_receipt_read_cannot_publish_attachment_disposition(workspace, monkeypatch):
    app, service, owner, _ = workspace
    files = [attachment(pdf_bytes(['Tên sản phẩm: Bột sen']))]
    operation = 'pdf-revoke-reject-001'
    service.prepare_document(*scope(owner), 'Chị đọc tệp.', files, operation)
    with app.state.repo.connection(write=True) as db:
        db.execute('UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?', scope(owner))
    before = data_snapshot(app.state.repo)
    monkeypatch.setattr('nmate.main.workspace_management.validate_attachment',
                        lambda _: pytest.fail('Revoked caller reached file parsing'))
    with pytest.raises(CoreError) as denied:
        service.prepare_document(*scope(owner), 'Chị đọc tệp.', files, operation)
    error = public_core_error(denied.value)
    assert 'details' not in error and 'commit_state' not in error
    assert data_snapshot(app.state.repo) == before


def test_unauthorized_document_scope_does_not_decode_or_publish_rejection(workspace, monkeypatch):
    app, service, owner, other = workspace
    monkeypatch.setattr('nmate.main.workspace_management.validate_attachment',
                        lambda _: pytest.fail('Unauthorized caller reached PDF decoding'))
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as denied:
        service.prepare_document(owner['account_id'], other['enterprise_id'], 'Chị đọc tệp.',
                                 [attachment(b'PK\x03\x04fake')], 'pdf-foreign-001')
    error = public_core_error(denied.value)
    assert error['code'] in {'forbidden', 'not_found', 'access_denied'}
    assert 'details' not in error and 'commit_state' not in error
    assert data_snapshot(app.state.repo) == before


def test_pdf_resource_failure_preserves_pending_attachment(workspace, monkeypatch):
    app, service, owner, _ = workspace
    def resource_failure(_):
        raise CoreError('pdf_resource_limit', 'PDF quá phức tạp để đọc an toàn.')
    monkeypatch.setattr('nmate.v04.pdf_intake.parse_pdf', resource_failure)
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as rejected:
        service.prepare_document(*scope(owner), 'Chị đọc tệp.',
            [attachment(b'%PDF-1.7\nresource-fixture')], 'pdf-resource-001')
    error = public_core_error(rejected.value)
    assert error['commit_state'] == 'not_started' and 'details' not in error
    assert data_snapshot(app.state.repo) == before


@pytest.mark.parametrize('failure', ['spawn', 'protocol', 'shape', 'unknown_code'])
def test_pdf_reader_infrastructure_failure_is_not_invalid_bytes(monkeypatch, failure):
    def run(*_args, **_kwargs):
        if failure == 'spawn':
            raise OSError('Worker unavailable')
        stdout = {'protocol': b'not JSON', 'shape': b'[]',
                  'unknown_code': b'{"ok":false,"code":"not_a_validated_worker_code"}'}[failure]
        return SimpleNamespace(returncode=0, stdout=stdout)
    monkeypatch.setattr('nmate.v04.pdf_intake.subprocess.run', run)
    with pytest.raises(CoreError) as rejected:
        extract_pdf_pages(b'%PDF-1.7\nvalid-input-infrastructure-fixture')
    assert rejected.value.code == 'pdf_reader_unavailable'


def test_valid_pdf_spawn_failure_never_authorizes_file_removal(workspace, monkeypatch):
    app, service, owner, _ = workspace
    files = [attachment(pdf_bytes(['Tên sản phẩm: Bột sen']))]
    before = data_snapshot(app.state.repo)
    def unavailable(*_args, **_kwargs):
        raise OSError('Reader worker unavailable')
    monkeypatch.setattr('nmate.v04.pdf_intake.subprocess.run', unavailable)
    with pytest.raises(CoreError) as rejected:
        service.prepare_document(*scope(owner), 'Chị đọc tệp.', files, 'pdf-worker-unavailable-001')
    error = public_core_error(rejected.value)
    assert error['code'] == 'pdf_reader_unavailable' and error['commit_state'] == 'not_started'
    assert 'details' not in error and data_snapshot(app.state.repo) == before


@pytest.mark.parametrize('failure', ['limits', 'reader_internal', 'memory'])
def test_pdf_worker_does_not_call_infrastructure_failure_invalid_pdf(monkeypatch, failure):
    import io
    from nmate.v04 import pdf_worker
    # main() owns a disposable child process in production. Give the in-process
    # unit a private socket namespace rather than poisoning later HTTP/async IO.
    monkeypatch.setattr(pdf_worker, 'socket', SimpleNamespace(socket=None, create_connection=None, getaddrinfo=None))
    result = SimpleNamespace(buffer=io.BytesIO())
    monkeypatch.setattr(pdf_worker.sys, 'stdin', SimpleNamespace(buffer=io.BytesIO(b'%PDF-1.7\nfixture')))
    monkeypatch.setattr(pdf_worker.sys, 'stdout', result)
    def fail():
        raise RuntimeError('Resource guard unavailable')
    monkeypatch.setattr(pdf_worker, 'limit_resources', fail if failure == 'limits' else lambda: None)
    def read(_):
        if failure == 'memory':
            raise MemoryError()
        raise RuntimeError('Reader internal error')
    monkeypatch.setattr(pdf_worker, 'read_pdf', read)
    pdf_worker.main()
    import json
    code = json.loads(result.buffer.getvalue())['code']
    assert code == ('pdf_resource_limit' if failure == 'memory' else 'pdf_reader_unavailable')
