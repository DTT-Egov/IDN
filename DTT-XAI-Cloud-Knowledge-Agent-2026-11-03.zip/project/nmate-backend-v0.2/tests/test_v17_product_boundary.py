"""V17 DF-006/008: operational quantities cannot become product identity.

Exercise the actual free main-app business service and its persisted history,
as well as the shared extraction/reference boundary. No provider is dispatched.
"""
import copy
import hashlib
import json
import unicodedata

import pytest

from nmate.main.history import history_metadata
from nmate.v03.core import CoreError, json_text
from nmate.v04.extraction import extract_product_text
from nmate.v04.product_binding import declared_product_name, exact_product_reference
from test_unified_main import setup as setup, scope


NAME = "Trà Sen KIỂM THỬ 26-10"
QUESTION = NAME + " tồn 30 hộp; tháng 9 bán 120 hộp."


def _context(repo, owner):
    value = copy.deepcopy(repo.get_context(*scope(owner)))
    value.pop("as_of", None)
    return value


@pytest.mark.parametrize("tail", [
    "tồn 30 hộp", "tồn 0 hộp", "tồn là 30 hộp", "tồn: 30 hộp",
    "tồn 30.5 kg", "tồn 30,5 kg", "bán 12.5 kg",
    "tồn hiện tại 30 hộp", "hiện tồn 30 hộp", "đang tồn 30 hộp",
    "bán 120 hộp", "đã bán được 120 hộp", "bán khoảng 120 hộp",
])
def test_observation_clause_ends_reference_before_predicate(tail):
    text = f"{NAME} {tail}."
    assert declared_product_name(text) == NAME
    assert exact_product_reference(text, NAME)
    # An operating observation is not a new proposed identity or package size.
    assert extract_product_text(text) == []
    reference, = extract_product_text(text, include_product_references=True)
    assert reference["value"] == NAME
    assert reference["source"]["assertion_role"] == "product_reference"
    assert reference["source"]["value_quote"] == NAME
    assert reference["source"]["quote"] == text[reference["source"]["start_offset"]:reference["source"]["end_offset"]]
    assert reference["source"]["text_sha256"] == hashlib.sha256(text.encode("utf-8")).hexdigest()


def test_reported_sales_stock_main_service_reloads_without_proposal_or_wrong_title(setup):
    repo, owner, _other, model, provider, _missions, _intake, chats = setup
    model.fail = True
    product = repo.create_entity(*scope(owner), "product", NAME)
    before = _context(repo, owner)
    sent = chats.prepare_chat_draft(*scope(owner), QUESTION, "v17-stock-boundary-001",
                                    product_entity_id=product["id"], task_hint="sales_inventory")
    item = sent["intake"]
    assert item["product"]["id"] == product["id"]
    assert item["product"]["name"] == NAME
    assert item["candidates"] == []
    assert item["intent"]["working_answers"]["reported_stock_quantity"] == 30
    assert item["intent"]["working_answers"]["recent_sales_quantity"] == 120
    reopened = chats.get(*scope(owner), sent["id"])
    assert reopened["intake"]["candidates"] == []
    metadata = history_metadata(reopened)
    assert metadata["topic_title"].startswith(NAME + " · ")
    assert NAME + " tồn" not in metadata["topic_title"]
    assert next(message["text"] for message in reopened["messages"] if message["role"] == "user") == QUESTION
    assert chats.prepare_chat_draft(*scope(owner), QUESTION, "v17-stock-boundary-001",
        product_entity_id=product["id"], task_hint="sales_inventory")["id"] == sent["id"]
    assert _context(repo, owner) == before
    assert model.calls == [] and provider.summary()["paid_calls"] == 0


@pytest.mark.parametrize("name", ["Trà Tồn Tâm", "Trà Sen Tồn", "Trà Bán Mai", "Trà Sen 2026", "Trà Tồn 2026"])
def test_legitimate_literal_words_and_year_remain_reviewable(name):
    text = f"Tên sản phẩm: {name}; khối lượng tịnh 100 g; mã TS01."
    values = {fact["field"]: fact["value"] for fact in extract_product_text(text)}
    assert values == {"name": name, "net_quantity": "100 g", "product_code": "TS01"}
    assert declared_product_name(text) == name


def test_fact_question_keeps_literal_attributes_and_exact_casing():
    text = f"Chị cần hỏi FDA cho {NAME}, khối lượng tịnh 100 g, mã TS01."
    facts = extract_product_text(text)
    assert {fact["field"]: fact["value"] for fact in facts} == {
        "name": NAME, "net_quantity": "100 g", "product_code": "TS01"}
    assert all(fact["source"]["quote"] in text and fact["source"]["value_quote"] in text for fact in facts)


def test_boundary_never_turns_longer_unknown_name_into_saved_prefix(setup):
    repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    product = repo.create_entity(*scope(owner), "product", "Trà Sen")
    before = _context(repo, owner)
    text = f"{NAME} tồn 30 hộp."
    value = chats.prepare_chat_draft(*scope(owner), text, "v17-not-prefix-boundary",
                                     product_entity_id=product["id"], task_hint="sales_inventory")
    assert value["intake"]["product"] is None
    assert value["intake"]["product_binding"] == {
        "state": "unbound_reference", "referenced_name": NAME, "confirmed": False}
    assert value["intake"]["candidates"] == []
    assert product["id"] not in value["intake"]["reused_context"]["entity_ids"]
    assert _context(repo, owner) == before and model.calls == []


def test_unicode_comparison_keeps_literal_provenance_without_casefolding_value():
    text = unicodedata.normalize("NFD", f"Tên sản phẩm: {NAME}; mã TS01.")
    # Existing composed-grammar policy is retained; its identity resolver may
    # normalize comparison without ever rewriting source text or a stored fact.
    assert declared_product_name(text) == NAME


@pytest.mark.parametrize("name", ["Trà Tồn Tâm", "Trà Sen Tồn", "Trà Tồn 2026", NAME])
def test_valid_literal_legacy_proposal_is_not_invalidated_by_new_operation_boundary(name):
    from nmate.main.draft_projection import stale_text_name_candidates
    text = f"Tên sản phẩm: {name}; lượng tịnh 100 g."
    old_name = copy.deepcopy(next(fact for fact in extract_product_text(text) if fact["field"] == "name"))
    old_name.update(id="legacy-name", status="candidate")
    intake = {"id": "legacy-intake", "status": "awaiting_confirmation", "text": text,
              "product": {"id": "new_product", "name": name}, "candidates": [old_name]}
    before = copy.deepcopy(intake)
    assert stale_text_name_candidates({"intake": intake, "messages": []}, intake) == []
    assert intake == before


def _stored_pre_fix_name(setup, *, original_text=None, wrong_name=None, followed_up=False, business_fact=False):
    """Construct old JSON directly; today's parser does not produce the bug."""
    from nmate.core_v1.review_migration import migrate_review_architecture
    repo, owner, _other, _model, _provider, _missions, _intake, chats = setup
    value = chats.prepare_chat_draft(*scope(owner), "Chị cần báo cáo bán hàng.", "v17-old-json-seed",
                                     task_hint="sales_inventory")
    text = original_text or QUESTION
    business = None
    if business_fact:
        business = repo.create_entity(*scope(owner), "enterprise", "Cơ sở V17")
        text += " Tên cơ sở: Cơ sở V17."
    name = wrong_name or NAME + " tồn"
    original_iid = value["active_intake_id"]
    iid = "pre-v17-" + original_iid
    start = text.index(name)
    source = {"kind": "server_text_extract", "simulation": False, "locator": "Tin nhắn hiện tại",
              "quote": name, "value_quote": name, "text_sha256": hashlib.sha256(text.encode()).hexdigest(),
              "start_offset": start, "end_offset": start + len(name),
              "assertion_role": "intended_identity", "review_state": "owner_confirmation_required"}
    candidate = {"id": "pre-v17-bad-name", "entity_id": "new_product", "entity_type": "product",
                 "field": "name", "base_field": "name", "label_vi": "Tên sản phẩm", "value": name,
                 "value_type": "string", "unit": None, "period": None, "status": "candidate",
                 "source": source, "sources": [copy.deepcopy(source)]}
    with repo.connection(write=True) as db:
        payload = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (original_iid,)).fetchone()[0])
        payload.update(id=iid, text="Chị bổ sung ngày 26/10/2026." if followed_up else text, status="awaiting_confirmation", candidates=[candidate],
                       product={"id": "new_product", "name": name, "version": 0},
                       product_binding={"state": "new_product_draft", "declared_name": name, "confirmed": False})
        payload["expected_entity_versions"]["new_product"] = 0
        if business:
            declaration = "Tên cơ sở: Cơ sở V17"
            offset = text.index(declaration)
            business_source = {"kind": "server_text_extract", "quote": declaration, "value_quote": "Cơ sở V17",
                "text_sha256": hashlib.sha256(text.encode()).hexdigest(), "start_offset": offset,
                "end_offset": offset + len(declaration), "review_state": "owner_confirmation_required"}
            payload["candidates"].append({"id": "pre-v17-business-name", "entity_id": business["id"], "entity_type": "enterprise",
                "field": "trading_name", "base_field": "trading_name", "label_vi": "Tên cơ sở", "value": "Cơ sở V17",
                "value_type": "string", "unit": None, "period": None, "status": "candidate",
                "source": business_source, "sources": [business_source]})
            payload["enterprise_entity"] = {key: business[key] for key in ("id", "name", "version")}
            payload["expected_entity_versions"][business["id"]] = business["version"]
        for key in ("review", "confirmation_receipt", "latest_confirmation_receipt"):
            payload.pop(key, None)
        db.execute("INSERT INTO v04_intakes VALUES(?,?,?,?,?,?,?)", (iid, owner["enterprise_id"], owner["account_id"],
                   payload["status"], json_text(payload), payload["created_at"], payload["created_at"]))
        conversation = json.loads(db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (value["id"],)).fetchone()[0])
        conversation.update(intake_ids=[iid], active_intake_id=iid,
                            messages=[{"id": "pre-v17-owner", "role": "user", "text": text,
                                       "intake_id": iid, "created_at": value["created_at"], "attachments": []}])
        db.execute("UPDATE v04_conversations SET payload_json=? WHERE id=?", (json_text(conversation), value["id"]))
    result = migrate_review_architecture(repo)
    assert result["frozen_exclusions"] == []
    item = chats.free_intake.get(*scope(owner), iid)
    assert item["candidates"][0]["value"] == name
    return item, candidate


def _confirm_name(setup, item, *, edits=None, operation="v17-old-name-confirm"):
    _repo, owner, _other, _model, _provider, _missions, _intake, chats = setup
    ids = [item["candidates"][0]["id"]]
    return chats.free_intake.confirm(*scope(owner), item["id"], ids, item["expected_entity_versions"], operation,
        edits=edits, expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={key: item["review"]["proposal_hashes"][key] for key in ids})


@pytest.mark.parametrize("edit_same,followed_up", [(False, False), (True, False), (False, True)])
def test_stored_pre_fix_stock_name_cannot_be_confirmed_or_case_edited_into_ssot(setup, edit_same, followed_up):
    from test_review_commands_v2 import data_snapshot
    repo, _owner, _other, model, _provider, _missions, _intake, _chats = setup
    item, raw = _stored_pre_fix_name(setup, followed_up=followed_up)
    before = data_snapshot(repo)
    edits = {raw["id"]: raw["value"].upper()} if edit_same else None
    with pytest.raises(CoreError) as rejected:
        _confirm_name(setup, item, edits=edits)
    assert rejected.value.code == "product_name_boundary_review_required"
    assert "tên sản phẩm" in str(rejected.value).casefold()
    assert data_snapshot(repo) == before and model.calls == []


def test_stored_pre_fix_name_explicit_correction_preserves_raw_proposal_and_exact_replay(setup):
    from test_review_commands_v2 import data_snapshot
    repo, owner, _other, model, _provider, _missions, _intake, _chats = setup
    item, raw = _stored_pre_fix_name(setup)
    saved = _confirm_name(setup, item, edits={raw["id"]: NAME})
    assert saved["product"]["name"] == NAME
    with repo.connection() as db:
        observations = list(db.execute("SELECT observed_json,source_json FROM core_review_proposals WHERE workspace_id=? ORDER BY proposal_revision", (item["id"],)))
    assert json.loads(observations[0]["observed_json"])["value"] == raw["value"]
    assert json.loads(observations[0]["source_json"])["source"]["quote"] == raw["source"]["quote"]
    before = data_snapshot(repo)
    replayed = _confirm_name(setup, item, edits={raw["id"]: NAME})
    assert replayed["confirmation_receipt"] == saved["confirmation_receipt"]
    assert data_snapshot(repo) == before and model.calls == []
    assert len(repo.list_entities(*scope(owner), "product")) == 1


def test_stored_name_correction_cannot_implicitly_bind_existing_product(setup):
    from test_review_commands_v2 import data_snapshot
    repo, owner, _other, _model, _provider, _missions, _intake, _chats = setup
    repo.create_entity(*scope(owner), "product", NAME)
    item, raw = _stored_pre_fix_name(setup)
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as rejected:
        _confirm_name(setup, item, edits={raw["id"]: NAME})
    assert rejected.value.code == "product_binding_required"
    assert data_snapshot(repo) == before


def test_unselected_bad_name_cannot_materialize_and_does_not_block_independent_business_fact(setup):
    repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    item, raw = _stored_pre_fix_name(setup, business_fact=True)
    business_fact = next(candidate for candidate in item["candidates"] if candidate["field"] == "trading_name")
    saved = chats.free_intake.confirm(*scope(owner), item["id"], [business_fact["id"]], item["expected_entity_versions"],
        "v17-confirm-independent-business", expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={business_fact["id"]: item["review"]["proposal_hashes"][business_fact["id"]]})
    assert repo.list_entities(*scope(owner), "product") == []
    pending_name = next(candidate for candidate in saved["candidates"] if candidate["id"] == raw["id"])
    assert pending_name["status"] == "candidate" and pending_name["value"] == raw["value"]
    assert saved["review"]["pending_candidate_ids"] == [raw["id"]]
    assert model.calls == []


@pytest.mark.parametrize("change", ["wrong_hash", "wrong_offset", "wrong_quote", "no_offsets", "no_hash",
                                    "negated", "hypothetical", "explicit_literal", "explicit_owner", "valid_ton_name"])
def test_unknown_negative_or_declared_legacy_name_is_not_inferred_invalid(change):
    from nmate.v04.extraction import proven_product_name_boundary_error
    name = NAME + " tồn"
    text = QUESTION
    if change == "negated":
        text = "Chị không có " + text
    elif change == "hypothetical":
        text = "Ví dụ " + text
    elif change == "explicit_literal":
        text = "Tên sản phẩm: " + text
    elif change == "explicit_owner":
        text = "Chị có " + text
    elif change == "valid_ton_name":
        name, text = "Trà Tồn Tâm", "Trà Tồn Tâm tồn 30 hộp."
    start = text.index(name)
    candidate = {"field": "name", "value": name, "source": {"kind": "server_text_extract",
        "quote": name, "value_quote": name, "start_offset": start, "end_offset": start + len(name),
        "text_sha256": hashlib.sha256(text.encode()).hexdigest()}}
    if change == "wrong_hash":
        candidate["source"]["text_sha256"] = "0" * 64
    elif change == "wrong_offset":
        candidate["source"]["end_offset"] -= 1
    elif change == "wrong_quote":
        candidate["source"]["quote"] = "Trà Sen"
    elif change == "no_offsets":
        candidate["source"].pop("start_offset")
    elif change == "no_hash":
        candidate["source"].pop("text_sha256")
    before = copy.deepcopy(candidate)
    assert proven_product_name_boundary_error(text, candidate) is False
    assert candidate == before
