"""Real loopback BFF/MCP/LangGraph transport; injected stub, no provider calls."""
import asyncio
import socket
import threading
import time

import httpx
import pytest
import uvicorn

from nmate.v03.app import create_app
from nmate.v03.live_review import LiveReviewMissionService
from nmate.v03.mcp import create_mcp


TEA = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh."
PASSWORD = "HTTP-only-test-secret-03A"
NAMESPACE = "nmate_v03_live_http_test"


class Stub:
    """Only input/output fixture generation; deliberately no SDK or network."""
    def __init__(self):
        self.calls = []

    async def __call__(self, kind, payload, **scope):
        self.calls.append((kind, scope))
        await asyncio.sleep(.015)
        if kind == "intake":
            result = {"scope": "us_food", "outcomes": [
                {"id": "registration", "question_quote": "đăng ký cơ sở FDA"},
                {"id": "label", "question_quote": "nhãn tiếng Anh"},
            ], "product_name": "Trà Sen Tây Hồ", "product_quote": "Trà Sen Tây Hồ", "ambiguities": []}
        else:
            result = {"answers": [], "actions": []}
            for outcome in payload["input"]["outcomes"]:
                oid = outcome["id"]
                topic = "facility_registration" if oid == "registration" else "food_label"
                record = next(r for r in payload["input"]["reference_records"] if topic in r["topics"])
                result["answers"].append({"outcome_id": oid, "status": "artifact_ready" if oid == "label" else "answered_general", "text": "Nguồn tham khảo đã lưu cần đối chiếu phạm vi; chưa kết luận áp dụng riêng cho doanh nghiệp.", "details_vi": "Bản nháp tham khảo chưa được chuyên gia duyệt, không phải phê duyệt sản phẩm.", "citations": [{"source_id": record["id"], "quote_en": record["excerpt"]}], "missing_fields": []})
                result["actions"].append({"id": "action-" + oid, "title": "Điền khung nhãn tiếng Anh" if oid == "label" else "Bổ sung dữ kiện cơ sở", "kind": "edit_label" if oid == "label" else "supply_facts", "outcome_ids": [oid], "reason": "Để hoàn thành đúng ý người dùng hỏi."})
        return {"data": result, "attempt_id": "stub-" + str(len(self.calls)), "model": "NO-PROVIDER-test-stub", "usage": {"input_tokens": 0, "output_tokens": 0}, "request_id": "fake-request"}


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    stub = Stub()
    app = create_app(tmp_path_factory.mktemp("v03-live-http") / "test.sqlite3", port=port,
        task_delay=.04, service_factory=lambda repo, **kw: LiveReviewMissionService(repo, model_call=stub, **kw),
        mcp_factory=lambda repo, missions: create_mcp(repo, missions, live=True),
        mode="live_claude_review", cookie_namespace=NAMESPACE, mcp_timeout=10,
        metadata_provider=lambda: {"paid_calls": 0, "provider_attempts": 0, "stub_invocations": len(stub.calls)})
    instance = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port,
                                            log_level="error", access_log=False))
    thread = threading.Thread(target=instance.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not instance.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    yield {"url": f"http://127.0.0.1:{port}", "app": app, "stub": stub}
    instance.should_exit = True
    thread.join(10)
    assert not thread.is_alive()


def register(web, username):
    pre = web.get("/api/v03/session").json()
    assert pre["mode"] == "live_claude_review" and not pre["authenticated"]
    response = web.post("/api/v03/register", headers={"Origin": str(web.base_url).rstrip("/"),
        "X-CSRF-Token": pre["csrf_token"]}, json={"username": username, "password": PASSWORD,
        "enterprise_name": "Doanh nghiệp Trà Sen HTTP giả lập"})
    assert response.status_code == 200, response.text
    assert NAMESPACE + "_session=" in response.headers["set-cookie"]
    assert "HttpOnly" in response.headers["set-cookie"]
    assert "nmate_v03_session=" not in response.headers["set-cookie"]
    return response.json()


def call(web, session, name, **arguments):
    response = web.post("/api/v03/mcp/call", headers={"Origin": str(web.base_url).rstrip("/"),
        "X-CSRF-Token": session["csrf_token"]}, json={"name": name, "arguments": {
            "enterprise_id": session["enterprise"]["id"], **arguments}})
    assert response.status_code == 200, response.text
    return response.json()


def data(web, session, name, **arguments):
    envelope = call(web, session, name, **arguments)
    assert envelope["ok"], envelope
    return envelope["data"]


def finish(web, session, mission_id):
    deadline = time.monotonic() + 10
    while True:
        result = data(web, session, "get_mission", mission_id=mission_id)
        if result["status"] not in {"queued", "running"}:
            return result
        assert time.monotonic() < deadline
        time.sleep(.03)


def test_live_injected_async_intake_actual_mcp_reload_and_no_duplicate_synthesis(server):
    with httpx.Client(base_url=server["url"], timeout=10) as web:
        session = register(web, "live-http-owner")
        prepared = data(web, session, "prepare_mission", user_text=TEA, operation_id="http-live-prepare-01")
        assert prepared["status"] == "planned"
        assert prepared["mode"] == "live_claude_review"
        assert prepared["intent"]["interpretation_mode"] == "claude_validated_intake"
        assert prepared["product"]["name"] == "Trà Sen Tây Hồ"
        assert len(server["stub"].calls) == 1
        replayed = data(web, session, "prepare_mission", user_text=TEA, operation_id="http-live-prepare-01")
        assert replayed["id"] == prepared["id"] and len(server["stub"].calls) == 1
        data(web, session, "start_mission", mission_id=prepared["id"], operation_id="http-live-start-001")
        refreshed = web.get("/api/v03/session").json()
        assert refreshed["account"] == session["account"] and refreshed["csrf_token"] == session["csrf_token"]
        done = finish(web, refreshed, prepared["id"])
        assert done["status"] == "completed_partial", done
        assert [c[0] for c in server["stub"].calls] == ["intake", "research"]
        assert all(t["status"] == "succeeded" for t in done["plan"]["tasks"])
        assert {a["outcome_id"] for a in done["answers"]} == {"registration", "label"}
        assert all(a["citations"] for a in done["answers"])
        assert all(f["value"] is None for f in done["label"]["fields"])
        label = done["label"]
        saved = data(web, session, "update_label", mission_id=done["id"], artifact_id=label["id"],
            expected_version=1, fields={"statement_of_identity": "Lotus-scented tea"}, operation_id="http-live-label-save-01")
        assert saved["label"]["version"] == 2
        data(web, session, "start_mission", mission_id=done["id"], operation_id="http-live-start-extra")
        assert len(server["stub"].calls) == 2
        health = web.get("/health").json()
        assert health["mode"] == "live_claude_review" and health["stub_invocations"] == 2
        assert health["paid_calls"] == health["provider_attempts"] == 0
        assert health["mcp_calls"] >= 6
    _assert_same_account_reopen_and_profile_isolation(server)


def _assert_same_account_reopen_and_profile_isolation(server):
    with httpx.Client(base_url=server["url"], timeout=10) as profile:
        pre = profile.get("/api/v03/session").json()
        response = profile.post("/api/v03/login", headers={"Origin": server["url"], "X-CSRF-Token": pre["csrf_token"]},
            json={"username": "live-http-owner", "password": PASSWORD})
        assert response.status_code == 200
        session = response.json()
        missions = data(profile, session, "list_missions")
        assert len(missions) == 1 and missions[0]["label"]["version"] == 2
        known = data(profile, session, "get_enterprise_context")
        assert known["entities"][0]["name"] == "Trà Sen Tây Hồ"
    with httpx.Client(base_url=server["url"], timeout=10) as other:
        session = register(other, "live-http-other")
        assert data(other, session, "list_missions") == []
        denied = call(other, session, "get_mission", enterprise_id=missions[0]["enterprise_id"], mission_id=missions[0]["id"])
        assert not denied["ok"]
        assert other.post("/mcp", json={}).status_code == 401
        other.cookies.clear()
        other.cookies.set("nmate_v03_session", "fake-old-baseline-session", domain="127.0.0.1", path="/")
        assert other.get("/api/v03/session").json()["authenticated"] is False
    assert len(server["stub"].calls) == 2


def test_live_transport_rejects_baseline_cookie_and_missing_csrf(server):
    with httpx.Client(base_url=server["url"], timeout=10) as web:
        web.cookies.set("nmate_v03_session", "opaque-baseline-cookie", domain="127.0.0.1", path="/")
        pre = web.get("/api/v03/session").json()
        assert not pre["authenticated"]
        assert NAMESPACE + "_preauth" in web.cookies
        assert web.post("/mcp", json={}).status_code == 401
        denied = web.post("/api/v03/login", json={"username": "unused", "password": PASSWORD})
        assert denied.status_code == 403
