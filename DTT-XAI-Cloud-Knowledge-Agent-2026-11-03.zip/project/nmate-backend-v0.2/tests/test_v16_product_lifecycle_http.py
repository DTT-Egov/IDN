"""Two-product lifecycle identity through the actual HTTP MCP boundary; no AI."""
import httpx

from nmate.core_v1.integration import CoreIntegration
from test_core_policy_http import running, register, good, call
from test_review_commands_v2 import data_snapshot


def test_archive_identity_receipt_replay_stale_version_and_other_enterprise(tmp_path, monkeypatch):
    transport_calls = []

    async def forbidden(*args, **kwargs):
        transport_calls.append(True)
        raise AssertionError('A lifecycle command must never invoke a provider')

    async def idle(self):
        return False

    monkeypatch.setattr(CoreIntegration, 'execute_next', idle)
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web, \
             httpx.Client(base_url=url, trust_env=False, timeout=20) as outsider:
            session = register(web, url, 'v16-lifecycle-owner')
            other = register(outsider, url, 'v16-lifecycle-other')
            tea = good(web, url, session, 'core_create_entity', entity_type='product',
                       name='Trà sen Tây Hồ', operation_id='v16-create-tea')
            zzz = good(web, url, session, 'core_create_entity', entity_type='product',
                       name='zzz kiểm thử', operation_id='v16-create-zzz')
            repo = app.state.repo
            before = data_snapshot(repo)
            archived = good(web, url, session, 'archive_product', entity_id=zzz['id'],
                            expected_version=zzz['version'], operation_id='v16-archive-exact-zzz')
            assert archived['id'] == archived['entity_id'] == zzz['id']
            assert archived['archived'] and not archived['can_select_for_ai']
            products = good(web, url, session, 'list_products', include_archived=True)['items']
            by_id = {product['id']: product for product in products}
            assert by_id[tea['id']]['archived'] is False
            assert by_id[zzz['id']]['archived'] is True
            active = good(web, url, session, 'list_products', include_archived=False)['items']
            assert [product['id'] for product in active] == [tea['id']]
            committed = data_snapshot(repo)
            assert committed != before

            # Reusing an operation for another row must conflict, never retarget.
            rejected = call(web, url, session, 'archive_product', entity_id=tea['id'],
                            expected_version=tea['version'], operation_id='v16-archive-exact-zzz')
            assert not rejected['ok']
            assert data_snapshot(repo) == committed
            foreign = call(outsider, url, other, 'archive_product',
                           enterprise_id=session['enterprise']['id'], entity_id=tea['id'],
                           expected_version=tea['version'], operation_id='v16-foreign-archive')
            assert not foreign['ok'] and data_snapshot(repo) == committed

            restored = good(web, url, session, 'restore_product', entity_id=zzz['id'],
                            expected_version=archived['version'], operation_id='v16-restore-zzz')
            assert restored['entity_id'] == zzz['id'] and not restored['archived']
            final = data_snapshot(repo)
            replay = good(web, url, session, 'archive_product', entity_id=zzz['id'],
                          expected_version=zzz['version'], operation_id='v16-archive-exact-zzz')
            assert replay['entity_id'] == zzz['id'] and not replay['archived']
            assert replay['lifecycle_receipt']['state_at_commit'] == 'archived'
            assert data_snapshot(repo) == final
            stale = call(web, url, session, 'archive_product', entity_id=zzz['id'],
                         expected_version=archived['version'], operation_id='v16-stale-zzz')
            assert not stale['ok'] and data_snapshot(repo) == final
            with repo.connection() as db:
                events = list(db.execute('SELECT entity_id,state FROM v03_entity_lifecycle_events'))
                assert [(row['entity_id'], row['state']) for row in events] == [(zzz['id'], 'archived'), (zzz['id'], 'active')]
                assert db.execute('SELECT COUNT(*) FROM core_model_attempts').fetchone()[0] == 0
            assert not transport_calls
