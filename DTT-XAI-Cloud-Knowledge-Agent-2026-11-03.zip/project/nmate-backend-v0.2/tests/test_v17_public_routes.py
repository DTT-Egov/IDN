"""Public identity and human-readable PDF denial preserve the same ACL."""
import httpx
from test_core_policy_http import running, register, good


def test_health_and_status_have_one_release_identity(tmp_path):
    with running(tmp_path) as (_, url), httpx.Client(base_url=url, trust_env=False) as client:
        health = client.get('/health').json()
        status = client.get('/api/main/status').json()
        assert health['version'] == status['version'] == '0.5'
        assert health['build_revision'] == status['build_revision']


def test_pdf_denial_is_friendly_for_browser_but_still_denies_and_never_leaks(tmp_path):
    with running(tmp_path) as (_, url), \
            httpx.Client(base_url=url, trust_env=False, timeout=20) as owner, \
            httpx.Client(base_url=url, trust_env=False, timeout=20) as other:
        session = register(owner, url, 'v17-pdf-owner')
        register(other, url, 'v17-pdf-other')
        draft = good(owner, url, session, 'policy05_create_draft', question='Chị kiến nghị lớp sổ sách buổi tối.',
                     kind='business_petition', operation_id='v17-pdf-once')['policy_draft']
        path = f"/api/main/policy05/drafts/{draft['id']}/pdf?e={session['enterprise']['id']}&revision=1"
        denied = other.get(path, headers={'Accept': 'text/html,application/pdf'})
        assert denied.status_code == 403
        assert denied.headers['content-type'].startswith('text/html')
        assert '<h1>' in denied.text and '/web/' in denied.text
        assert draft['body']['situation'] not in denied.text and draft['id'] not in denied.text
        api_denied = other.get(path, headers={'Accept': 'application/json'})
        assert api_denied.status_code == 403 and api_denied.json()['ok'] is False
        pdf = owner.get(path, headers={'Accept': 'text/html,application/pdf'})
        assert pdf.status_code == 200 and pdf.content.startswith(b'%PDF')
