"""Old owner-excluded parser mistakes are evidence, not an active SSOT draft."""
import copy
import hashlib
import json

import pytest

from nmate.main.draft_projection import project_excluded_legacy_draft, preserve_archived_exclusions
from nmate.main.history import history_metadata
from nmate.v03.core import CoreError, json_text
from nmate.core_v1.review_migration import migrate_review_architecture
from test_unified_main import setup as setup, scope


FIRST = ("Chị kiểm kê Trà Sen Tây Hồ: tồn trên sổ 120 hộp, đếm thực tế 110 hộp. "
         "Chị nên đối chiếu gì trước, chưa rõ nguyên nhân lệch?")
FOLLOWUP = "Ngày 18/10/2026, mã TS01. Chị muốn đối chiếu phiếu nhập và xuất."
WRONG_NAME = "Trà Sen Tây Hồ: tồn trên sổ"


def old_view():
    candidate = {"id": "old-name", "field": "name", "value": WRONG_NAME, "status": "candidate",
                 "source": {"kind": "server_text_extract", "quote": WRONG_NAME,
                            "text_sha256": hashlib.sha256(FIRST.encode()).hexdigest()}}
    return {"status": "awaiting_confirmation", "task_hint": "sales_inventory",
            "drafts": {"old-intake": {"selected": {"old-name": False}, "edits": {}, "choices": {}}},
            "messages": [{"role": "user", "text": FIRST, "intake_id": "old-intake"},
                         {"role": "user", "text": FOLLOWUP, "intake_id": "old-intake"}],
            "intake": {"id": "old-intake", "status": "awaiting_confirmation", "text": FOLLOWUP,
                       "product": {"id": "new_product", "name": WRONG_NAME, "version": 0},
                       "product_binding": {"state": "new_product_draft", "declared_name": WRONG_NAME},
                       "candidates": [candidate], "intent": {"focus": "inventory_accuracy", "primary": "digitize_operations",
                           "primary_label": "Số hóa bán hàng và tồn kho",
                           "working_answers": {"book_quantity": 120, "physical_quantity": 110, "count_date": "2026-10-18",
                                               "product_code": "TS01", "quantity_unit": "hộp"}},
                       "plan": [{"id": "understand_intent"}, {"id": "confirm_facts"}, {"id": "remember_facts"}],
                       "questions": []}}


def test_owner_excluded_bad_name_is_inspectable_without_pending_ssot_form_or_title():
    view = old_view()
    before = copy.deepcopy(view)
    projected = project_excluded_legacy_draft(view)
    item = projected["intake"]
    assert projected["status"] == item["status"] == "ready"
    assert item["candidates"] == []
    assert [task["id"] for task in item["plan"]] == ["understand_intent"]
    assert not item["product"].get("name") and not item["product_binding"].get("declared_name")
    projection = item["draft_projection"]
    archived = projection["archived_candidates"][0]
    assert archived["value"] == WRONG_NAME and archived["source"] == before["intake"]["candidates"][0]["source"]
    assert projection["source_status"] == "awaiting_confirmation"
    assert projection["model_called"] is projection["ssot_changed"] is False
    assert projection["active_candidate_count"] == 0
    history = history_metadata(projected)
    assert history["display_title"] == "Số hóa kho"
    assert history["history_state_vi"] == "Trao đổi đã lưu"
    assert not history.get("history_extraction_review_needed")
    assert view == before
    assert project_excluded_legacy_draft(projected) == projected


@pytest.mark.parametrize("change", ["unreviewed", "selected", "edited", "choice", "file", "model", "confirmed",
                                    "confirmed_intake", "existing_entity", "other_work", "assistant", "wrong_hash"])
def test_does_not_hide_unproven_or_owner_confirmable_observations(change):
    view = old_view()
    candidate, draft = view["intake"]["candidates"][0], view["drafts"]["old-intake"]
    if change == "unreviewed":
        draft["selected"] = {}
    elif change == "selected":
        draft["selected"]["old-name"] = True
    elif change == "edited":
        draft["edits"]["old-name"] = "Trà Sen Tây Hồ"
    elif change == "choice":
        draft["choices"]["old-name"] = "current"
    elif change in {"file", "model"}:
        candidate["source"]["kind"] = "spreadsheet" if change == "file" else "claude"
    elif change == "confirmed":
        candidate["status"] = "confirmed"
    elif change == "confirmed_intake":
        view["intake"]["status"] = "confirmed"
    elif change == "existing_entity":
        view["intake"]["product"]["id"] = "entity-existing"
    elif change == "other_work":
        view["messages"][0]["intake_id"] = "other-intake"
    elif change == "assistant":
        view["messages"][0]["role"] = "assistant"
    elif change == "wrong_hash":
        candidate["source"]["text_sha256"] = "0" * 64
    original = copy.deepcopy(view)
    assert project_excluded_legacy_draft(view) == original
    assert view == original


def test_unchecked_valid_fact_stays_available_for_owner_to_reselect():
    view = old_view()
    view["intake"]["text"] = "Chị có Mứt Sen, hộp 200 g"
    view["intake"]["product"]["name"] = "Mứt Sen"
    view["intake"]["candidates"][0].update(value="Mứt Sen", source={"kind": "server_text_extract", "quote": "Mứt Sen"})
    assert project_excluded_legacy_draft(view) == view
    assert project_excluded_legacy_draft(view)["intake"]["candidates"]


def test_other_pending_candidate_keeps_real_confirmation_and_source_is_preserved():
    view = old_view()
    view["intake"]["candidates"].append({"id": "new-code", "field": "product_code", "status": "candidate", "value": "TS01"})
    projected = project_excluded_legacy_draft(view)
    assert projected["status"] == projected["intake"]["status"] == "awaiting_confirmation"
    assert projected["intake"]["candidates"] == [view["intake"]["candidates"][1]]
    assert projected["intake"]["draft_projection"]["active_candidate_count"] == 1


@pytest.mark.parametrize("state", ["failed", "preparing", "completed_partial", "needs_clarification"])
def test_projection_never_clears_unrelated_conversation_state(state):
    view = old_view()
    view["status"] = state
    assert project_excluded_legacy_draft(view)["status"] == state


def test_compact_client_cannot_erase_archived_exclusion_by_omitting_candidate():
    view = old_view()
    incoming = {"selected": {}, "edits": {}, "choices": {}}
    original = copy.deepcopy(incoming)
    result = preserve_archived_exclusions(view, incoming)
    assert result == {**incoming, "selected": {"old-name": False}}
    assert incoming == original
    assert preserve_archived_exclusions(view, {"selected": {"old-name": True}})["selected"]["old-name"] is True
    assert preserve_archived_exclusions(view, {"selected": "invalid"}) == {"selected": "invalid"}
    view["drafts"]["old-intake"]["selected"]["old-name"] = True
    assert preserve_archived_exclusions(view, incoming) == incoming


def test_real_main_get_reload_and_list_preserve_every_stored_row_and_ownership(setup, monkeypatch):
    repo, owner, other, model, _, _, _, chat = setup
    value = chat.prepare_chat_draft(*scope(owner), "Chị muốn đối chiếu tồn kho", "legacy-draft-prepare", task_hint="sales_inventory")
    source = old_view()
    original_iid = value["active_intake_id"]
    iid = "legacy-" + original_iid
    with repo.connection(write=True) as db:
        intake = json.loads(db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (original_iid,)).fetchone()[0])
        intake.update(source["intake"], id=iid)
        # Construct a genuine pre-ledger record, rather than corrupting a new
        # aggregate's cached projection with an unregistered candidate.
        for key in ("review", "confirmation_receipt", "latest_confirmation_receipt"):
            intake.pop(key, None)
        intake["candidates"][0].update(entity_id="new_product", entity_type="product", base_field="name",
            value_type="string", unit=None, period=None,
            sources=[copy.deepcopy(intake["candidates"][0]["source"])])
        intake["expected_entity_versions"]["new_product"] = 0
        payload = json.loads(db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (value["id"],)).fetchone()[0])
        payload["intake_ids"] = [iid if key == original_iid else key for key in payload["intake_ids"]]
        payload["active_intake_id"] = iid
        payload["drafts"] = {iid: source["drafts"]["old-intake"]}
        payload["messages"] = [{**message, "id": f"legacy-{idx}", "intake_id": iid, "created_at": value["created_at"]}
                               for idx, message in enumerate(source["messages"])]
        db.execute("INSERT INTO v04_intakes VALUES(?,?,?,?,?,?,?)", (iid, owner["enterprise_id"], owner["account_id"],
            intake["status"], json_text(intake), intake["created_at"], intake["created_at"]))
        db.execute("UPDATE v04_conversations SET payload_json=? WHERE id=?", (json_text(payload), value["id"]))

    migration = migrate_review_architecture(repo)
    assert migration["migrated_workspace_count"] == 1
    assert {c["candidate_id"] for c in migration["frozen_exclusions"]} == {"old-name"}
    assert migrate_review_architecture(repo)["migrated_workspace_count"] == 0
    def parser_must_not_run_during_read(_text):
        raise AssertionError("GET must use the frozen legacy decision, not re-run the current parser")
    monkeypatch.setattr("nmate.main.draft_projection.extract_product_text", parser_must_not_run_during_read)

    def snapshot():
        with repo.connection() as db:
            return {table: [tuple(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')]
                    for table in ("v04_intakes", "v04_conversations", "v03_fact_assertions", "v03_entities", "v03_live_attempts",
                        "core_review_workspaces", "core_review_proposals", "core_review_entity_bindings", "core_review_decisions",
                        "core_review_group_resolutions", "core_review_command_receipts", "core_review_ui_drafts")}

    before = snapshot()
    for _ in range(2):
        projected = chat.get(*scope(owner), value["id"])
        assert projected["status"] == "ready" and projected["intake"]["candidates"] == []
        assert projected["intake"]["draft_projection"]["archived_count"] == 1
        assert history_metadata(projected)["display_title"] == "Số hóa kho"
        assert not projected["cost"]["paid_calls"]
    assert chat.list(*scope(owner))[0]["status"] == "ready"
    with pytest.raises(CoreError) as error:
        chat.get(*scope(other), value["id"])
    assert error.value.status_code in {403, 404}
    assert snapshot() == before
    assert not model.calls

    # Navigating to History/Profile saves a compact draft with no active IDs.
    # It must not make the quarantined name reappear on the next reload.
    saved = chat.save_draft(*scope(owner), value["id"], iid, {"selected": {}, "edits": {}, "choices": {}}, "compact-save-001")
    assert saved["drafts"][iid]["selected"] == {"old-name": False}
    assert chat.get(*scope(owner), value["id"])["intake"]["candidates"] == []
    after = snapshot()
    for table in ("v04_intakes", "v03_fact_assertions", "v03_entities", "v03_live_attempts"):
        assert after[table] == before[table]
    assert not model.calls

    # The explicitly free preparation service shares the same durable choices.
    continued = chat.prepare_chat_draft(*scope(owner), "Chị tiếp tục đối chiếu phiếu nhập và xuất của ngày đã nêu.",
                                       "compact-free-followup", value["id"],
                                       draft={"intake_id": iid, "selected": {}, "edits": {}, "choices": {}},
                                       target_intake_id=iid, task_hint="sales_inventory")
    assert continued["drafts"][iid]["selected"] == {"old-name": False}
    assert continued["intake"]["candidates"] == []
    assert continued["status"] != "awaiting_confirmation"
    assert chat.get(*scope(owner), value["id"])["intake"]["draft_projection"]["archived_count"] == 1
    after_free = snapshot()
    for table in ("v03_fact_assertions", "v03_entities", "v03_live_attempts"):
        assert after_free[table] == before[table]
    assert not model.calls
