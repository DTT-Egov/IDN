"""No paid transport: deterministic responses exercise actual reservation boundaries."""
import asyncio
import json
from datetime import datetime, timedelta, timezone

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


OUTPUT = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "gateway.sqlite")
    owner = LocalAccounts(repo).register("gateway-owner", "Password12345", "Trà Sen")
    calls = []

    async def transport(model, body, limit):
        calls.append((model, body, limit))
        return {"text": '{"answer":"Nguồn chưa đủ để kết luận."}', "model": model,
                "usage": {"input_tokens": 100, "output_tokens": 50}, "stop_reason": "end_turn"}

    gateway = ModelGateway(repo, request_fn=transport, enabled=True)
    return repo, owner, gateway, calls


def grant(owner, gateway, **kwargs):
    return gateway.authorize_budget(owner["account_id"], owner["enterprise_id"], approval_id="TEST-NO-PAID-IO",
        max_calls=kwargs.pop("max_calls", 2), max_cost_usd=kwargs.pop("max_cost_usd", 2),
        purposes=["policy_synthesis"], roles=["standard", "complex"],
        expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(), **kwargs)["id"]


async def invoke(owner, gateway, budget, **kwargs):
    return await gateway.call_once(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"],
        operation_id=kwargs.pop("operation_id", "op-1"), task_id="summary", role="standard", purpose="policy_synthesis",
        context=kwargs.pop("context", {"question": "Có hỗ trợ số hóa kho không?"}), output_schema=OUTPUT,
        budget_grant_id=budget, **kwargs)


def test_no_approval_or_global_enable_means_no_transport(setup):
    repo, owner, gateway, calls = setup
    with pytest.raises(CoreError) as unapproved:
        asyncio.run(invoke(owner, gateway, "invented"))
    assert unapproved.value.code == "BUDGET_NOT_GRANTED"
    budget = grant(owner, gateway)
    gateway.enabled = False
    with pytest.raises(CoreError) as disabled:
        asyncio.run(invoke(owner, gateway, budget))
    assert disabled.value.code == "BUDGET_NOT_GRANTED"
    assert calls == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0


def test_accepted_raw_is_retained_and_repeated_read_spends_nothing(setup):
    repo, owner, gateway, calls = setup
    budget = grant(owner, gateway)
    first = asyncio.run(invoke(owner, gateway, budget))
    second = asyncio.run(invoke(owner, gateway, budget))
    assert first["data"] == second["data"] and second["cached"]
    assert len(calls) == 1
    with repo.connection() as db:
        row = db.execute("SELECT * FROM core_model_attempts").fetchone()
        assert json.loads(row["raw_text"]) == first["data"]
        assert row["raw_sha256"] and row["actual_microusd"] == 700
        assert row["validation_state"] == "accepted"
    with pytest.raises(CoreError) as changed:
        asyncio.run(invoke(owner, gateway, budget, context={"question": "Nội dung khác"}))
    assert changed.value.code == "IDEMPOTENCY_CONFLICT" and len(calls) == 1


@pytest.mark.parametrize("response", [{"text": "NOT JSON"}, {"text": '{"wrong":true}'}, {"text": None}, None])
def test_invalid_response_retained_never_calls_repair(setup, response):
    repo, owner, gateway, calls = setup
    budget = grant(owner, gateway)

    async def invalid(*args):
        calls.append(1)
        return response

    gateway.request_fn = invalid
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(owner, gateway, budget))
    assert error.value.code == "OUTPUT_REJECTED"
    with pytest.raises(CoreError):
        asyncio.run(invoke(owner, gateway, budget))
    assert len(calls) == 1
    with repo.connection() as db:
        row = db.execute("SELECT * FROM core_model_attempts").fetchone()
        assert row["state"] == "response_received" and row["validation_state"] == "rejected" and row["raw_sha256"]


def test_unknown_transport_and_restart_do_not_replay_or_refund(setup):
    repo, owner, gateway, calls = setup
    budget = grant(owner, gateway)

    async def timeout(*args):
        calls.append(1)
        raise TimeoutError()

    gateway.request_fn = timeout
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(owner, gateway, budget))
    assert error.value.code == "OUTCOME_UNKNOWN"
    gateway.recover_interrupted()
    with pytest.raises(CoreError):
        asyncio.run(invoke(owner, gateway, budget))
    assert len(calls) == 1
    with repo.connection() as db:
        row = db.execute("SELECT * FROM core_model_attempts").fetchone()
        assert row["state"] == "outcome_unknown" and row["held_microusd"] > 0


def test_call_and_money_caps_are_checked_before_transport(setup):
    _, owner, gateway, calls = setup
    tiny = grant(owner, gateway, max_cost_usd="0.000001")
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(owner, gateway, tiny))
    assert error.value.code == "BUDGET_EXCEEDED" and calls == []
    budget = grant(owner, gateway, max_calls=1)
    asyncio.run(invoke(owner, gateway, budget))
    with pytest.raises(CoreError):
        asyncio.run(invoke(owner, gateway, budget, operation_id="op-2"))
    assert len(calls) == 1


def test_parallel_duplicate_one_network_boundary(setup):
    _, owner, gateway, calls = setup
    budget = grant(owner, gateway)

    async def race():
        return await asyncio.gather(invoke(owner, gateway, budget), invoke(owner, gateway, budget), return_exceptions=True)

    values = asyncio.run(race())
    assert sum(isinstance(v, dict) for v in values) >= 1
    assert len(calls) == 1


@pytest.mark.parametrize("context", [{"attachments": ["secret"]}, {"nested": {"ocr_text": "financial raw"}},
                                    {"revenue": 100}, {"financial_metrics": [{"revenue": 100}]}])
def test_raw_finance_and_unapproved_metrics_block_before_transport(setup, context):
    _, owner, gateway, calls = setup
    with pytest.raises(CoreError):
        asyncio.run(invoke(owner, gateway, grant(owner, gateway), context=context))
    assert not calls


def test_missing_key_is_not_a_charged_unknown_attempt(setup):
    repo, owner, gateway, calls = setup
    gateway.request_fn = None
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(owner, gateway, grant(owner, gateway)))
    assert error.value.code == "MODEL_NOT_CONFIGURED" and not calls
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
