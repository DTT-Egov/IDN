"""Product identity, reversible lifecycle and shared value boundaries; no AI."""
from __future__ import annotations

import copy
import json
import unicodedata
import sqlite3
from concurrent.futures import ThreadPoolExecutor

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository, json_text
from nmate.v03.domain_validation import validate_field_value
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from nmate.v03.live_review import LiveReviewMissionService, previous_mission_summary, selected_product_projection, ssot_context_projection
from test_review_commands_v2 import data_snapshot
from test_ssot_field_scope import legacy_fact


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "lifecycle.sqlite3")
    identity = LocalAccounts(repo)
    owner = identity.register("lifecycle-owner", "Local-only-password-2026", "Trà Sen QA")
    other = identity.register("lifecycle-other", "Local-only-password-2026", "Doanh nghiệp khác")
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    return repo, owner, other, product


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


@pytest.mark.parametrize("field,value", [
    ("net_quantity", "abc"), ("net_quantity", "100"), ("net_quantity", "0 g"), ("net_quantity", "-1 g"),
    ("net_quantity", "100 hộp"), ("net_quantity", True), ("net_weight", "10 ml"),
    ("product_code", "TS 001"), ("sku", "A<script>"), ("sku", "A" * 65),
    ("employee_count", -1), ("employee_count", 1.5), ("employee_count", True),
])
def test_invalid_values_fail_at_common_write_boundary_atomically(setup, field, value):
    repo, owner, _, product = setup
    before = data_snapshot(repo)
    with pytest.raises(CoreError):
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": field, "value": value}], 0, "invalid-fact")
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("field,value", [("net_quantity", "100 g"), ("net_quantity", "100g"), ("net_quantity", "0,1 kg"), ("net_quantity", "250 ml"),
                                         ("net_weight", "2 lb"), ("product_code", "TS-001/A.2"), ("sku", "TRÀ-SEN_01"), ("employee_count", 0)])
def test_valid_domain_values_keep_original_spelling(field, value):
    original = copy.deepcopy(value)
    assert validate_field_value(field, value) is None
    assert value == original


def test_duplicate_normalization_does_not_use_sku_or_merge_existing_profiles(setup):
    repo, owner, other, product = setup
    before = data_snapshot(repo)
    for name in ["  trà  sen tây hồ ", unicodedata.normalize("NFD", "TRÀ SEN TÂY HỒ")]:
        with pytest.raises(CoreError) as error:
            repo.create_entity(*scope(owner), "product", name)
        assert error.value.code == "product_name_exists"
    assert data_snapshot(repo) == before
    repo.create_entity(*scope(other), "product", "Trà Sen Tây Hồ")
    saved = repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "name", "value": "TRÀ SEN TÂY HỒ"}, {"field": "product_code", "value": "TS02"}], 0, "same-identity-confirm")
    assert saved["version"] == 1 and len(repo.list_entities(*scope(owner), "product")) == 1


def test_create_duplicate_name_is_serialized_across_connections(setup):
    repo, owner, _, _ = setup
    def create(name):
        try:
            return repo.create_entity(*scope(owner), "product", name)["id"]
        except CoreError as error:
            return error.code
    with ThreadPoolExecutor(2) as pool:
        outcomes = list(pool.map(create, ["Mứt Sen", "  MỨT  SEN  "]))
    assert outcomes.count("product_name_exists") == 1
    assert len(repo.list_entities(*scope(owner), "product")) == 2


def test_archive_restore_preserve_facts_history_and_replayed_receipt_is_not_current_state(setup):
    repo, owner, _, product = setup
    repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "seed")
    raw_history = repo.get_fact_history(*scope(owner), product["id"])
    archived = repo.archive_entity(*scope(owner), product["id"], 1, "archive", "Ngừng bán")
    assert archived["archived"] and not archived["can_select_for_ai"] and archived["version"] == 2
    assert repo.list_entities(*scope(owner), "product") == []
    assert repo.list_entities(*scope(owner), "product", include_archived=True)[0]["id"] == product["id"]
    with pytest.raises(CoreError):
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "200 g"}], 2, "no-write-archived")
    with pytest.raises(CoreError):
        repo.get_context(*scope(owner), [product["id"]])
    restored = repo.restore_entity(*scope(owner), product["id"], 2, "restore")
    assert restored["lifecycle_state"] == "active" and restored["version"] == 3
    before = data_snapshot(repo)
    replay = repo.archive_entity(*scope(owner), product["id"], 1, "archive", "Ngừng bán")
    assert replay["lifecycle_state"] == "active" and replay["lifecycle_receipt"]["state_at_commit"] == "archived"
    assert data_snapshot(repo) == before and repo.get_fact_history(*scope(owner), product["id"]) == raw_history
    history = repo.entity_versions(*scope(owner), product["id"])
    assert {event["kind"] for event in history["events"]} >= {"fact_select", "product_archived", "product_restored"}


def test_restore_name_collision_is_explicit_no_merge_or_delete(setup):
    repo, owner, other, product = setup
    repo.archive_entity(*scope(owner), product["id"], 0, "archive")
    replacement = repo.create_entity(*scope(owner), "product", "TRÀ SEN TÂY HỒ")
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        repo.restore_entity(*scope(owner), product["id"], 1, "restore-collision")
    assert error.value.code == "product_name_exists" and data_snapshot(repo) == before
    assert len(repo.list_entities(*scope(owner), "product", include_archived=True)) == 2
    with pytest.raises(CoreError):
        repo.archive_entity(*scope(other), replacement["id"], 0, "cross-owner")
    assert data_snapshot(repo) == before


def test_legacy_invalid_quantity_is_visible_for_repair_but_not_copied_to_context_or_new_us_label(setup):
    repo, owner, _, product = setup
    legacy_fact(repo, owner, product["id"], "net_quantity", "một hộp lớn tùy ý")
    before = data_snapshot(repo)
    view = repo.get_entity(*scope(owner), product["id"])
    assert view["validation_issues"][0]["value"] == "một hộp lớn tùy ý"
    context = repo.get_context(*scope(owner), [product["id"]])
    assert "net_quantity" not in context["entities"][0]["values"]
    assert data_snapshot(repo) == before
    service = MissionService(repo)
    plan = service.prepare(*scope(owner), "Chuẩn bị nhãn Trà Sen Tây Hồ cho Mỹ", "legacy-bad-label", product["id"])
    service.start(*scope(owner), plan["id"], "start")
    import asyncio
    assert asyncio.run(service.execute_next())
    result = service.get(*scope(owner), plan["id"])
    assert next(field for field in result["label"]["fields"] if field["id"] == "net_quantity")["value"] is None
    before_edit = data_snapshot(repo)
    with pytest.raises(CoreError):
        service.update_label(*scope(owner), result["id"], result["label"]["id"], {"net_quantity": "tùy ý"}, result["label"]["version"], "invalid-label")
    assert data_snapshot(repo) == before_edit


def test_archived_product_old_mission_is_readable_but_cannot_restart_or_enter_core_context(setup):
    repo, owner, _, product = setup
    service = MissionService(repo)
    plan = service.prepare(*scope(owner), "Chuẩn bị nhãn Trà Sen Tây Hồ cho Mỹ", "plan", product["id"])
    entity = repo.get_entity(*scope(owner), product["id"])
    repo.archive_entity(*scope(owner), product["id"], entity["version"], "archive")
    before = data_snapshot(repo)
    old = service.get(*scope(owner), plan["id"])
    assert old["product"]["archived"] and old["question"] == plan["question"]
    with pytest.raises(CoreError):
        service.start(*scope(owner), plan["id"], "start-archived")
    assert data_snapshot(repo) == before
    core = CoreSSOTService(repo)
    with pytest.raises(CoreError):
        core.get_context(*scope(owner), [product["id"]], save_snapshot=False)


def test_invalid_quantity_in_a_legacy_saved_context_cannot_reenter_model_input():
    entity = {"id": "old-product", "entity_type": "product", "name": "Trà Sen", "version": 1,
              "facts": [{"field": "name", "value": "Trà Sen", "value_state": "known", "freshness_state": "self_declared"},
                        {"field": "net_quantity", "value": "nặng vừa ý", "value_state": "known", "freshness_state": "self_declared"}]}
    context = {"entities": [entity], "values": {"name": "Trà Sen", "net_quantity": "nặng vừa ý"},
               "shared_values": {"net_quantity": "nặng vừa ý"}, "fact_refs": [{"entity_id": "old-product", "field": "net_quantity", "version": 1, "assertion_id": "old-assertion"}]}
    before = copy.deepcopy(context)
    assert "net_quantity" not in selected_product_projection(entity)["values"]
    projected = ssot_context_projection(context)
    assert "net_quantity" not in projected["values"] and "net_quantity" not in projected["shared_values"]
    assert context == before


def test_bad_old_saved_label_is_flagged_without_modifying_its_immutable_revision(setup):
    repo, owner, _, product = setup
    service = MissionService(repo)
    value = service.prepare(*scope(owner), "Chuẩn bị nhãn Trà Sen Tây Hồ cho Mỹ", "old-label", product["id"])
    service.start(*scope(owner), value["id"], "start")
    import asyncio
    assert asyncio.run(service.execute_next())
    with repo.connection(write=True) as db:
        raw = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (value["id"],)).fetchone()[0])
        label = next(item for item in raw["artifacts"] if item["kind"] == "food_label_workbook")
        next(field for field in label["fields"] if field["id"] == "net_quantity")["value"] = "tùy ý"
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(raw), value["id"]))
    before = data_snapshot(repo)
    view = service.get(*scope(owner), value["id"])
    assert view["label"]["validation_issues"][0]["saved_value"] == "tùy ý"
    assert view["label"]["can_export_document"] is False
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("label_location", ["label", "artifacts"])
@pytest.mark.parametrize("bad_value", ["khối lượng tùy ý", "", True, "100 hộp"])
def test_previous_label_model_projection_omits_invalid_value_without_rewriting_history(label_location, bad_value):
    label = {"kind": "food_label_workbook", "version": 2, "market_code": "US", "label_language": "en",
             "fields": [{"id": "net_quantity", "value": bad_value, "state": "self_declared"},
                        {"id": "ingredients", "value": "Green tea", "state": "self_declared"}]}
    previous = {"question": "Cần nhãn cho Mỹ", "status": "completed_partial", "intent": {"outcomes": []},
                label_location: label if label_location == "label" else [label]}
    original = copy.deepcopy(previous)
    result = previous_mission_summary(previous, include_label=True)["label_work_state"]
    assert result["fields"][0] == {"id": "net_quantity", "value": None, "state": "invalid_value", "has_conflict": False}
    assert result["validation_issues"] == [{"field": "net_quantity", "code": "invalid_quantity"}]
    assert result["fields"][1]["value"] == "Green tea"
    assert previous == original
    assert previous_mission_summary(previous)["label_work_state"] is None


@pytest.mark.asyncio
@pytest.mark.parametrize("current_quantity", [None, "100g"])
async def test_new_live_label_excludes_invalid_legacy_overlay_without_losing_valid_paid_results(setup, current_quantity):
    from test_v03_live_review import ModelStub, TEA

    repo, owner, _, product = setup
    if current_quantity:
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": current_quantity}],
                                   product["version"], "current-valid-quantity")
    model = ModelStub()
    service = LiveReviewMissionService(repo, model_call=model)
    first = await service.prepare_async(*scope(owner), TEA, "legacy-first", product["id"])
    service.start(*scope(owner), first["id"], "legacy-first-start")
    assert await service.execute_next()
    with repo.connection(write=True) as db:
        raw = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (first["id"],)).fetchone()[0])
        label = next(item for item in raw["artifacts"] if item["kind"] == "food_label_workbook")
        next(field for field in label["fields"] if field["id"] == "net_quantity")["value"] = "khối lượng tùy ý"
        old_payload = json_text(raw)
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (old_payload, first["id"]))
        old_revision = json_text(label)
        db.execute("UPDATE v03_artifact_revisions SET data_json=? WHERE id=? AND version=?", (old_revision, label["id"], label["version"]))
    second = await service.prepare_async(*scope(owner), TEA, "legacy-followup", product["id"], continuation_mission_id=first["id"])
    intent_payload = model.calls[-1][1]["input"]["previous_mission_context"]["label_work_state"]
    assert next(field for field in intent_payload["fields"] if field["id"] == "net_quantity")["value"] is None
    assert "khối lượng tùy ý" not in json_text(intent_payload)
    service.start(*scope(owner), second["id"], "legacy-followup-start")
    assert await service.execute_next()
    completed = service.get(*scope(owner), second["id"])
    assert completed["status"] == "completed_partial" and len(completed["answers"]) == 2
    new_label = completed["label"]
    field = next(field for field in new_label["fields"] if field["id"] == "net_quantity")
    assert field["value"] == current_quantity
    assert field["state"] == ("self_declared" if current_quantity else "needs_input")
    assert new_label["parent_artifact_ref"]["artifact_id"] == label["id"]
    assert new_label["parent_artifact_ref"]["version"] == label["version"]
    assert new_label["parent_artifact_ref"]["excluded_invalid_fields"] == [{"field": "net_quantity", "code": "invalid_quantity"}]
    assert "không được dùng lại" in new_label["limitations_vi"]
    assert "khối lượng tùy ý" not in json_text(model.calls[2:])
    assert len(model.calls) == 4
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (first["id"],)).fetchone()[0] == old_payload
        assert db.execute("SELECT data_json FROM v03_artifact_revisions WHERE id=? AND version=?", (label["id"], label["version"])).fetchone()[0] == old_revision


def test_additive_lifecycle_tables_enforce_tenant_and_actor_membership_foreign_keys(setup):
    repo, owner, other, product = setup
    with pytest.raises(sqlite3.IntegrityError):
        with repo.connection(write=True) as db:
            db.execute("INSERT INTO v03_entity_lifecycle VALUES(?,?,?,?,?,?,?)",
                       (product["id"], other["enterprise_id"], "archived", 1, "2026-10-22", other["account_id"], None))
    with pytest.raises(sqlite3.IntegrityError):
        with repo.connection(write=True) as db:
            db.execute("INSERT INTO v03_entity_lifecycle VALUES(?,?,?,?,?,?,?)",
                       (product["id"], owner["enterprise_id"], "archived", 1, "2026-10-22", other["account_id"], None))


def test_existing_duplicate_rows_are_not_merged_and_same_entity_reconfirmation_remains_available(setup):
    repo, owner, _, product = setup
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_entities(id,enterprise_id,entity_type,name,created_by,created_at) VALUES(?,?,'product',?,?,?)",
                   ("legacy-duplicate", owner["enterprise_id"], "TRÀ  SEN TÂY HỒ", owner["account_id"], "2026-10-21"))
    before_ids = {entity["id"] for entity in repo.list_entities(*scope(owner), "product")}
    repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "name", "value": "Trà Sen Tây Hồ"}], 0, "same-existing")
    assert {entity["id"] for entity in repo.list_entities(*scope(owner), "product")} == before_ids


def test_legacy_invalid_quantity_can_be_corrected_with_new_audited_version(setup):
    repo, owner, _, product = setup
    legacy_fact(repo, owner, product["id"], "net_quantity", "tùy ý")
    result = repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "owner-correction")
    assert result["version"] == 1
    view = repo.get_entity(*scope(owner), product["id"])
    assert view["validation_issues"] == [] and next(f for f in view["facts"] if f["field"] == "net_quantity")["value"] == "100 g"
    history = repo.entity_versions(*scope(owner), product["id"])
    assert {event["to_value"] for event in history["events"] if event["field"] == "net_quantity"} == {"tùy ý", "100 g"}


def test_concurrent_archive_and_fact_commit_have_one_consistent_cas_winner(setup):
    repo, owner, _, product = setup
    def archive():
        try:
            repo.archive_entity(*scope(owner), product["id"], 0, "race-archive")
            return "archived"
        except CoreError as error:
            return error.code
    def commit():
        try:
            repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "race-fact")
            return "committed"
        except CoreError as error:
            return error.code
    with ThreadPoolExecutor(2) as pool:
        left, right = pool.submit(archive), pool.submit(commit)
        outcomes = [left.result(), right.result()]
    assert sum(item in {"archived", "committed"} for item in outcomes) == 1
    entity = repo.get_entity(*scope(owner), product["id"])
    assert entity["version"] == 1
    if "archived" in outcomes:
        assert entity["archived"] and not entity["facts"]
    else:
        assert not entity["archived"] and entity["facts"][0]["value"] == "100 g"
