"""Owner text stays a draft; product/market identity cannot come from defaults."""
import pytest

from nmate.v03.core import CoreError
from nmate.v04.conversations import ConversationService
from nmate.v04.extraction import extract_product_text
from nmate.v04.product_binding import detect_export_topics
from test_unified_main import setup as setup, scope
from test_v04_intake import workspace as workspace, prepare, confirm
from test_v03_live_review import TEA


def test_inline_question_preserves_name_code_quantity_and_provenance():
    text = "Chị muốn hỏi FDA cho Trà Sen Tây Hồ, 100 g, mã TS01 đi Mỹ có cần đăng ký không?"
    facts = extract_product_text(text)
    values = {fact["field"]: fact["value"] for fact in facts}
    assert values == {"name": "Trà Sen Tây Hồ", "net_quantity": "100 g", "product_code": "TS01"}
    assert all(fact["source"]["quote"] in text and fact["source"]["review_state"] == "owner_confirmation_required" for fact in facts)
    assert detect_export_topics("Số nhân viên và nhận dữ kiện") == []
    assert extract_product_text("Ngày 18/10/2026, mã TS01") == []


@pytest.mark.parametrize("text,name", [(TEA, "Trà Sen Tây Hồ"),
    ("Chị có sản phẩm Mứt Sen An Nhiên gửi sang Los Angeles, hộp 100 g", "Mứt Sen An Nhiên"),
    ("Tôi muốn hỏi Trà Sen An Nhiên gửi tới Nhật có cần nhãn gì?", "Trà Sen An Nhiên")])
def test_transport_phrase_is_not_part_of_product_name(text, name):
    facts = extract_product_text(text)
    product = next(fact for fact in facts if fact["field"] == "name")
    assert product["value"] == name
    assert product["source"]["quote"] in text


def test_new_product_draft_never_borrows_only_saved_product_even_with_stale_client(workspace):
    repo, intake, owner, other = workspace
    saved = confirm(intake, owner, prepare(intake, owner))
    tea = saved["product"]["id"]
    before = repo.get_context(*scope(owner))
    question = "Chị muốn xuất khẩu Mứt Sen đi Los Angeles"
    new = intake.prepare(*scope(owner), question, [], "new-jam-draft", tea)
    assert new["product"]["id"] == "new_product"
    assert new["product_binding"]["state"] == "new_product_draft"
    assert new["candidates"][0]["value"] == "Mứt Sen"
    assert tea not in new["reused_context"]["entity_ids"]
    assert "Trà Sen Tây Hồ" not in str(new["business_plan"])
    assert tea not in {entity["id"] for entity in new["saved_context"]["entities"]}
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    with pytest.raises(CoreError):
        intake.get(*scope(other), new["id"])
    restored = intake.get(*scope(owner), new["id"])
    assert restored["candidates"] == new["candidates"]


def test_same_chat_new_product_uses_new_draft_without_clobbering_old(workspace):
    repo, intake, owner, _ = workspace
    chats = ConversationService(intake)
    first = chats.send(*scope(owner), "Chị có sản phẩm Trà Sen Tây Hồ, hộp 100 g", [], "first-tea-draft")
    tea_item = first["intake"]
    new = chats.send(*scope(owner), "Chị muốn xuất khẩu Mứt Sen đi Los Angeles", [], "next-jam-draft", first["id"])
    assert new["intake"]["id"] != tea_item["id"]
    assert new["intake"]["candidates"][0]["value"] == "Mứt Sen"
    assert intake.get(*scope(owner), tea_item["id"])["candidates"] == tea_item["candidates"]
    assert repo.get_context(*scope(owner))["fact_refs"] == []


def test_free_fda_chat_exposes_actual_confirmation_and_persists_reload(setup):
    repo, owner, other, model, provider, _missions, intake, chats = setup
    model.fail = True  # This action cannot dispatch even a faulted provider.
    text = "Chị muốn hỏi FDA cho Trà Sen Tây Hồ, 100 g, mã TS01 đi Mỹ có cần đăng ký không?"
    chat = chats.prepare_chat_draft(*scope(owner), text, "free-fda-draft")
    item = chat["intake"]
    assert chat["last_preparation"]["model_called"] is False
    assert chat["latest_operation_id"] == "free-fda-draft"
    assert chat["model_calls"] == provider.summary()["paid_calls"] == 0
    assert item["status"] == "awaiting_confirmation" and len(item["candidates"]) == 3
    assert "chưa" in chat["messages"][-1]["text"].casefold()
    assert repo.get_context(*scope(owner))["fact_refs"] == []
    same = chats.prepare_chat_draft(*scope(owner), text, "free-fda-draft")
    assert same["id"] == chat["id"] and same["messages"] == chat["messages"]
    saved = confirm(intake, owner, item)
    assert saved["status"] == "confirmed"
    assert saved["origins"]["business_plan"] == "bounded_local_parser"
    current = chats.get(*scope(owner), chat["id"])
    assert current["intake"]["product"]["id"] != "new_product"
    assert current["intake"]["product"]["name"] == "Trà Sen Tây Hồ"
    assert len(model.calls) == 0
    with pytest.raises(CoreError):
        chats.get(*scope(other), chat["id"])


@pytest.mark.asyncio
async def test_paid_research_rejects_unknown_product_before_dispatch(setup):
    repo, owner, _other, model, _provider, _missions, intake, chats = setup
    # Create confirmed tea without using the paid adapter.
    free = chats.free_intake
    tea = confirm(free, owner, prepare(free, owner))["product"]["id"]
    with pytest.raises(CoreError) as error:
        await chats.send_async(*scope(owner), "Chị muốn xuất khẩu Mứt Sen đi Los Angeles", [],
            "paid-wrong-product", product_entity_id=tea, task_hint="export_research", market_code="US", paid_consent=True)
    assert error.value.code == "product_confirmation_required"
    assert model.calls == []
    assert repo.get_context(*scope(owner))["entities"]


def test_free_inventory_followup_has_no_product_confirmation_detour(setup):
    _repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    first = chats.prepare_chat_draft(*scope(owner), "Chị muốn giảm sai lệch tồn kho", "free-inventory-goal")
    counts = chats.prepare_chat_draft(*scope(owner), "Tồn trên sổ 120, đếm thực tế 110", "free-inventory-counts", first["id"])
    restored = chats.get(*scope(owner), counts["id"])
    final = chats.prepare_chat_draft(*scope(owner), "Ngày 18/10/2026, mã TS01", "free-inventory-date-code", restored["id"])
    item = final["intake"]
    assert item["candidates"] == [] and item["product"] is None
    assert item["intent"]["working_answers"]["product_code"] == "TS01"
    assert "-10" in str(item["next_steps"]) and "phiếu" in str(item["next_steps"])
    assert not any("tên sản phẩm" in line for line in item["questions"])
    assert model.calls == []


@pytest.mark.asyncio
async def test_free_operation_id_cannot_be_reused_for_paid_dispatch(setup):
    _repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    chat = chats.prepare_chat_draft(*scope(owner), "Chị muốn giảm sai lệch tồn kho", "free-operation")
    with pytest.raises(CoreError) as error:
        await chats.send_async(*scope(owner), "Chị muốn giảm sai lệch tồn kho", [], "free-operation", chat["id"], paid_consent=True)
    assert error.value.code == "idempotency_conflict" and model.calls == []
