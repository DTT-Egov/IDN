"""Exercise the shipped sample against the actual D05 egress compiler.

No provider or gateway call is made; the legacy financial sample stays blocked.
"""
from pathlib import Path

import pytest

from nmate.v03.core import CoreError
from nmate.v04.extraction import parse_workbook
from test_legacy_model_gateway import payload, setup as setup


SAMPLES = Path(__file__).resolve().parents[2] / "nmate-mvp-v0.1" / "demo-files"


def test_default_business_sample_parses_and_passes_the_financial_guard(setup):
    facts, warnings = parse_workbook((SAMPLES / "tra-sen-ho-so-nghiep-vu.xlsx").read_bytes())
    assert facts and not warnings
    assert {"name", "net_quantity", "packaging"}.issubset({fact["field"] for fact in facts})
    assert not any(fact["field"].startswith(("revenue", "profit", "cash_flow")) for fact in facts)
    compiled = setup[5].compile_payload("intake", payload(parsed_xlsx_facts=facts))
    assert {fact["field"] for fact in compiled["input"]["parsed_xlsx_facts"]} == {fact["field"] for fact in facts}
    assert setup[-1] == []


def test_original_financial_sample_still_requires_separate_authorization(setup):
    facts, _warnings = parse_workbook((SAMPLES / "tra-sen-ho-so.xlsx").read_bytes())
    assert any(fact["field"] == "revenue" for fact in facts)
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("intake", payload(parsed_xlsx_facts=facts))
    assert error.value.code == "FINANCIAL_EGRESS_REQUIRED"
    assert setup[-1] == []
