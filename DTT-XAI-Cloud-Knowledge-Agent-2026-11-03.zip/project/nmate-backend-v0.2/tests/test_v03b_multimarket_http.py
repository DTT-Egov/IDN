"""Real BFF -> MCP transport, three scoped markets, no model providers."""
import httpx

from test_v03_http import call, data, finish, register, server  # noqa: F401


def values(mission):
    return {f["id"]: f["value"] for f in mission["label"]["fields"]}


def run(web, owner, question, op, **kwargs):
    mission = data(web, owner, "prepare_mission", user_text=question,
                   operation_id=f"v03b-prepare-{op}", **kwargs)
    assert mission["status"] == "planned", mission
    data(web, owner, "start_mission", mission_id=mission["id"], operation_id=f"v03b-start-{op}")
    result = finish(web, owner, mission["id"])
    assert result["status"] in {"completed", "completed_partial"}, result
    return result


def save(web, owner, mission, fields, op):
    return data(web, owner, "update_label_progress", mission_id=mission["id"],
        artifact_id=mission["label"]["id"], fields=fields, remember_fields=list(fields),
        expected_artifact_version=mission["label"]["version"],
        expected_entity_version=mission["product"]["version"],
        expected_market_profile_version=mission["market_profile"]["version"],
        operation_id=f"v03b-save-{op}")


def test_one_product_three_market_profiles_sources_drafts_reload_and_acl(server):  # noqa: F811
    with httpx.Client(base_url=server["url"]) as web, httpx.Client(base_url=server["url"]) as other:
        owner = register(web, "v03b-three-market-owner", "Trà Sen đa thị trường QA")
        outsider = register(other, "v03b-other-enterprise", "Doanh nghiệp khác 0.3B")
        registry = data(web, owner, "get_supported_markets")
        assert {m["code"] for m in registry["markets"]} == {"US", "DE", "JP"}
        us = run(web, owner, "Tôi có Trà Sen Tây Hồ gửi Mỹ, cần tìm hiểu đăng ký cơ sở và nhãn.", "us")
        assert us["market"]["code"] == "US"
        product = us["product"]["entity_id"]
        us = save(web, owner, us, {"statement_of_identity": "Lotus-scented Green Tea",
            "ingredients": "Green tea, Lotus flowers", "net_quantity": "100 g"}, "us")
        profiles = {us["market_profile"]["entity_id"]}
        mission_ids = [us["id"]]
        for code, market_name, identity in [("DE", "Đức", "Grüner Tee mit Lotusduft"),
                                           ("JP", "Nhật", "蓮の花で香り付けした緑茶")]:
            mission = run(web, owner, f"Giờ với cùng sản phẩm, cần điều kiện nhập khẩu và nhãn khi gửi sang {market_name}.",
                          code, product_entity_id=product, continuation_mission_id=us["id"])
            assert mission["market"]["code"] == code
            assert mission["product"]["entity_id"] == product
            assert values(mission)["statement_of_identity"] is None
            assert values(mission)["net_quantity"] == "100 g"
            assert values(mission)["ingredients"] == "Green tea, Lotus flowers"
            assert mission["label"].get("parent_artifact_ref") is None
            assert all(not r["id"].startswith("FDA_") for r in mission["knowledge"]["records"])
            declaration = "Grüner Tee, Lotusblüten (QA)" if code == "DE" else "緑茶、蓮の花（QA）"
            assert values(mission)["ingredients_declaration"] is None
            mission = save(web, owner, mission, {"statement_of_identity": identity,
                                                "ingredients_declaration": declaration}, code)
            assert values(data(web, owner, "get_mission", mission_id=mission["id"]))["statement_of_identity"] == identity
            assert mission["market_profile"]["values"]["ingredients_declaration"] == declaration
            assert values(mission)["ingredients"] == "Green tea, Lotus flowers"
            profiles.add(mission["market_profile"]["entity_id"])
            mission_ids.append(mission["id"])
        assert len(profiles) == 3
        again = run(web, owner, "Quay lại Mỹ, tiếp tục nhãn của Trà Sen.", "us-return",
                    product_entity_id=product, continuation_mission_id=mission["id"])
        assert again["market"]["code"] == "US"
        assert values(again)["statement_of_identity"] == "Lotus-scented Green Tea"
        assert again["label"]["parent_artifact_ref"]["artifact_id"] == us["label"]["id"]
        context = data(web, owner, "get_enterprise_context")
        canonical = next(e for e in context["entities"] if e["id"] == product)
        assert canonical["values"]["ingredients"] == "Green tea, Lotus flowers"
        assert "statement_of_identity" not in canonical["values"]
        for mid in mission_ids:
            assert not call(other, outsider, "get_mission", mission_id=mid)["ok"]
        unresolved = data(web, owner, "prepare_mission", operation_id="v03b-unknown-market",
            user_text="Cùng sản phẩm này gửi Brazil, cần nhãn.", product_entity_id=product,
            continuation_mission_id=us["id"])
        assert unresolved["status"] == "waiting_input"
        assert not unresolved.get("market") or unresolved["market"].get("code") != "US"
        assert not unresolved["knowledge"]["records"]
        health = web.get("/health").json()
        assert health["version"] == "0.3B"
        assert health["paid_calls"] == health["provider_attempts"] == health["worker_errors"] == 0
