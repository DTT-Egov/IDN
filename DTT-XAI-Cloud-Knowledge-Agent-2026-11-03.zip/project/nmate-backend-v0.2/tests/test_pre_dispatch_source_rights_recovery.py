"""Only a proven zero-dispatch rights failure may return to a consent screen."""
import json

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.core_v1.ssot import CoreSSOTService
from nmate.main.pre_dispatch_recovery import RIGHTS_REJECTION, recover_source_rights_pre_dispatch
from nmate.v03.core import CoreError, json_text, now_iso
from test_unified_main import setup as shared_setup, docs, scope


@pytest.fixture(name="workspace")
def workspace_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


async def failed_before_dispatch(workspace, monkeypatch):
    repo, owner, _, model, provider, missions, _, chat = workspace
    conv = await docs(workspace)
    product = conv["intake"]["product"]["id"]
    callback = provider.request_fn
    question = "Chị có Trà Sen Tây Hồ đi Mỹ, ai nộp prior notice và nộp khi nào?"

    async def recorded(model_name, payload, limit):
        if "resolved_market" in payload["input"] and "reference_records" not in payload["input"]:
            model.calls.append((model_name, payload))
            data = {"scope": "us_food", "outcomes": [{"id": "prior_notice", "question_quote": "ai nộp prior notice và nộp khi nào?"}],
                    "product_name": "Trà Sen Tây Hồ", "product_quote": "Trà Sen Tây Hồ", "ambiguities": []}
            return {"text": json_text(data), "model": model_name, "request_id": "local-only",
                    "stop_reason": "end_turn", "usage": {"input_tokens": 5, "output_tokens": 5}}
        return await callback(model_name, payload, limit)

    provider.request_fn = recorded
    planned = await chat.send_async(*scope(owner), question, [], "rights-intake", conv["id"], product,
                                   paid_consent=True, task_hint="export_research", market_code="US")
    mid = planned["active_mission_id"]
    core = CoreSSOTService(repo)
    gateway = ModelGateway(repo, core=core, request_fn=lambda *args: pytest.fail("No gateway transport may run"), enabled=True)
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    provider.governed_adapter = adapter

    def old_classifier(_records, *, compact=False):
        raise CoreError("INVALID_PUBLIC_REFERENCE", RIGHTS_REJECTION, 409)

    missions.start(*scope(owner), mid, "old-rights-consent")
    with monkeypatch.context() as patch:
        patch.setattr(adapter, "_public_records", old_classifier)
        assert await missions.execute_next()
    failed = missions.get(*scope(owner), mid)
    assert failed["status"] == "failed" and failed["stale_reason"] == RIGHTS_REJECTION
    return mid, product, gateway


def immutable(repo):
    with repo.connection() as db:
        return {table: [tuple(row) for row in db.execute("SELECT * FROM " + table)] for table in (
            "v03_live_attempts", "core_model_attempts", "core_model_operations", "core_budget_grants", "v03_live_review_outputs",
            "v03_current_facts", "v03_fact_assertions", "v03_domain_sources", "v03_domain_references")}


@pytest.mark.asyncio
async def test_pre_dispatch_correction_keeps_failed_audit_and_requires_new_consent_without_spending(workspace, monkeypatch):
    repo, owner, _, model, _, missions, _, _ = workspace
    mid, _, _ = await failed_before_dispatch(workspace, monkeypatch)
    before, calls = immutable(repo), len(model.calls)
    result = recover_source_rights_pre_dispatch(missions, *scope(owner), mid)
    assert result["status"] == "planned"
    assert result["pre_dispatch_recovery"]["requires_fresh_paid_consent"]
    assert result["pre_dispatch_recovery"]["provider_calls"] == result["pre_dispatch_recovery"]["ssot_writes"] == 0
    assert immutable(repo) == before and len(model.calls) == calls
    assert not await missions.execute_next()
    with repo.connection() as db:
        audit = json.loads(db.execute("SELECT original_rows_json FROM main_pre_dispatch_recoveries WHERE mission_id=?", (mid,)).fetchone()[0])
        assert audit["mission"]["status"] == "failed"
        assert audit["stages"][0]["state"] == "stopped_no_replay" and audit["stages"][0]["error_message"] == RIGHTS_REJECTION
        assert not db.execute("SELECT 1 FROM main_research_authorizations WHERE mission_id=?", (mid,)).fetchone()
    # Reusing the old start operation does not recreate permission or a queue.
    assert missions.start(*scope(owner), mid, "old-rights-consent")["status"] == "planned"
    assert recover_source_rights_pre_dispatch(missions, *scope(owner), mid)["version"] == result["version"]
    assert not await missions.execute_next() and len(model.calls) == calls


@pytest.mark.asyncio
@pytest.mark.parametrize("drift", ["legacy_prepared", "legacy_unknown", "core_operation", "core_prepared", "core_dispatched", "facts", "different_error", "private_source"])
async def test_no_uncertain_reservation_paid_attempt_context_change_or_unclassified_source_can_be_reset(workspace, monkeypatch, drift):
    repo, owner, _, model, _, missions, _, _ = workspace
    mid, product, gateway = await failed_before_dispatch(workspace, monkeypatch)
    operation = "research:" + mid
    if drift == "facts":
        entity = repo.get_entity(*scope(owner), product)
        repo.propose_or_apply_facts(*scope(owner), product, [{"field": "net_quantity", "value": "200 g", "source": {"owner_confirmed": True}}], entity["version"], "rights-fact-drift")
    else:
        grant = None
        if drift.startswith("core_") and drift != "core_operation":
            grant = gateway.authorize_budget(*scope(owner), approval_id="LOCAL-INJECTED-NO-PAID", max_calls=1, max_cost_usd=1,
                                            purposes=["legacy_research"], roles=["standard"], expires_at="2099-01-01T00:00:00+00:00")["id"]
        with repo.connection(write=True) as db:
            if drift.startswith("legacy_"):
                db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,mission_id,model,state,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                           ("reserved-legacy", *scope(owner), operation, "research", "hash", mid, "claude-sonnet-5-5", "prepared" if drift == "legacy_prepared" else "outcome_unknown", now_iso()))
            elif drift.startswith("core_"):
                db.execute("INSERT INTO core_model_operations VALUES(?,?,?,?,?,?,?,?)", (owner["enterprise_id"], operation, owner["account_id"], "hash", "legacy_research", mid, "prepared", now_iso()))
                if grant:
                    db.execute("INSERT INTO core_model_attempts(id,enterprise_id,operation_id,task_id,step_key,actor_id,grant_id,profile_version,model,price_version,request_hash,input_upper_tokens,max_output_tokens,held_microusd,state,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                               ("reserved-core", owner["enterprise_id"], operation, "legacy_research", "one", owner["account_id"], grant, "standard/1", "claude-sonnet-5-5", "local", "hash", 10, 10, 10, "dispatch_committed" if drift == "core_dispatched" else "prepared", now_iso()))
            elif drift == "different_error":
                db.execute("UPDATE v03_missions SET stale_reason='Unknown provider error' WHERE id=?", (mid,))
            else:
                db.execute("UPDATE v03_domain_sources SET rights='private_owner' WHERE id='fda_prior_notice_20261019_v1'")
    before, calls = immutable(repo), len(model.calls)
    with pytest.raises(CoreError):
        recover_source_rights_pre_dispatch(missions, *scope(owner), mid)
    assert immutable(repo) == before and len(model.calls) == calls


@pytest.mark.asyncio
async def test_other_owner_cannot_read_or_reset_failed_mission(workspace, monkeypatch):
    _, _, other, model, _, missions, _, _ = workspace
    mid, _, _ = await failed_before_dispatch(workspace, monkeypatch)
    calls = len(model.calls)
    with pytest.raises(CoreError):
        recover_source_rights_pre_dispatch(missions, *scope(other), mid)
    assert len(model.calls) == calls
