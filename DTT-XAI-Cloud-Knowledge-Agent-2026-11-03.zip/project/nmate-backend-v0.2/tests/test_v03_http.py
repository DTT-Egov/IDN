"""End-to-end 0.3A: browser BFF -> actual MCP HTTP -> durable fake workflow."""
import socket
import threading
import time

import httpx
import pytest
import uvicorn

from nmate.v03.app import create_app


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    app = create_app(tmp_path_factory.mktemp("v03-http") / "test.sqlite3", port=port, task_delay=.07)
    instance = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port,
                                            log_level="error", access_log=False))
    thread = threading.Thread(target=instance.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not instance.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    yield {"url": f"http://127.0.0.1:{port}", "app": app}
    instance.should_exit = True
    thread.join(10)
    assert not thread.is_alive()


def register(web, username, enterprise):
    session = web.get("/api/v03/session").json()
    assert session["authenticated"] is False
    headers = {"Origin": str(web.base_url).rstrip("/"), "X-CSRF-Token": session["csrf_token"]}
    response = web.post("/api/v03/register", headers=headers,
        json={"username": username, "password": "Test-only-secret-03A", "enterprise_name": enterprise})
    assert response.status_code == 200, response.text
    result = response.json()
    assert result["authenticated"] and "token" not in result and "password" not in str(result)
    assert "HttpOnly" in response.headers["set-cookie"]
    return result


def call(web, session, name, **arguments):
    response = web.post("/api/v03/mcp/call", headers={"Origin": str(web.base_url).rstrip("/"),
        "X-CSRF-Token": session["csrf_token"]}, json={"name": name, "arguments": {
            "enterprise_id": session["enterprise"]["id"], **arguments}})
    assert response.status_code == 200, response.text
    # Count completed MCP transport requests, including an intentionally denied
    # owned-resource lookup. Poll count varies with worker scheduling.
    web._test_mcp_calls = getattr(web, "_test_mcp_calls", 0) + 1
    return response.json()


def data(web, session, name, **arguments):
    result = call(web, session, name, **arguments)
    assert result["ok"], result
    return result["data"]


def finish(web, session, mission_id):
    deadline = time.monotonic() + 12
    while True:
        result = data(web, session, "get_mission", mission_id=mission_id)
        if result["status"] not in {"queued", "running"}:
            return result
        assert time.monotonic() < deadline, result
        time.sleep(.05)


def test_tea_lotus_reload_reuse_save_and_two_profiles(server):
    with httpx.Client(base_url=server["url"]) as a, httpx.Client(base_url=server["url"]) as other:
        sa = register(a, "lotus-owner", "Doanh nghiệp Trà Sen QA")
        sb = register(other, "another-owner", "Doanh nghiệp khác QA")
        question = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh."
        args = {"user_text": question, "operation_id": "http-tea-prepare-0001"}
        prepared = data(a, sa, "prepare_mission", **args)
        assert data(a, sa, "prepare_mission", **args)["id"] == prepared["id"]
        assert {o["id"] for o in prepared["intent"]["outcomes"]} == {"registration", "label"}
        assert prepared["product"]["name"] == "Trà Sen Tây Hồ"
        started = data(a, sa, "start_mission", mission_id=prepared["id"], operation_id="http-tea-start-00001")
        assert started["status"] in {"queued", "running"}
        refreshed = a.get("/api/v03/session").json()
        assert refreshed["enterprise"] == sa["enterprise"] and refreshed["csrf_token"] == sa["csrf_token"]
        done = finish(a, refreshed, prepared["id"])
        assert done["status"] in {"completed", "completed_partial"}, done
        assert {answer["outcome_id"] for answer in done["answers"]} == {"registration", "label"}
        assert done["cost"]["paid_calls"] == done["cost"]["provider_attempts"] == 0
        label = next(x for x in done["artifacts"] if x["kind"] == "food_label_workbook")
        assert label["fields"] and any(x["value"] is None for x in label["fields"])
        field = label["fields"][0]["id"]
        saved = data(a, sa, "update_label", mission_id=done["id"], artifact_id=label["id"],
                     expected_version=label["version"], fields={field: "West Lake Lotus Tea"},
                     operation_id="http-tea-label-save-01")
        saved_label = next(x for x in saved["artifacts"] if x["id"] == label["id"])
        assert saved_label["version"] == label["version"] + 1
        assert next(x for x in saved_label["fields"] if x["id"] == field)["value"] == "West Lake Lotus Tea"
        denied = call(other, sb, "get_mission", mission_id=done["id"], enterprise_id=sa["enterprise"]["id"])
        assert not denied["ok"]
        assert data(other, sb, "list_missions") == []
        with httpx.Client(base_url=server["url"]) as second_profile:
            pre = second_profile.get("/api/v03/session").json()
            login = second_profile.post("/api/v03/login", headers={"Origin": server["url"],
                "X-CSRF-Token": pre["csrf_token"]}, json={"username": "lotus-owner", "password": "Test-only-secret-03A"}).json()
            assert login["enterprise"] == sa["enterprise"]
            opened = data(second_profile, login, "get_mission", mission_id=done["id"])
            assert next(x for x in opened["artifacts"] if x["id"] == label["id"])["version"] == saved_label["version"]
            new = data(second_profile, login, "prepare_mission", user_text=question,
                       product_entity_id=done["product"]["entity_id"], operation_id="http-tea-reuse-00001")
            assert new["product"]["entity_id"] == done["product"]["entity_id"]
        health = a.get("/health").json()
        expected_calls = sum(getattr(client, "_test_mcp_calls", 0) for client in (a, other, second_profile))
        assert health["mcp_calls"] == expected_calls
        assert health["paid_calls"] == health["provider_attempts"] == 0


def test_transport_auth_csrf_and_no_private_exposure(server):
    with httpx.Client(base_url=server["url"]) as web:
        assert web.post("/mcp", json={}).status_code == 401
        session = web.get("/api/v03/session").json()
        body = {"username": "csrf-owner", "password": "Test-only-secret-03A", "enterprise_name": "QA CSRF"}
        assert web.post("/api/v03/register", json=body).status_code == 403
        headers = {"Origin": "https://untrusted.invalid", "X-CSRF-Token": session["csrf_token"]}
        assert web.post("/api/v03/register", headers=headers, json=body).status_code == 403
        assert web.get("/favicon.ico").status_code == 204
        page = web.get("/web/", timeout=3)
        assert page.status_code == 200 and "mission-v03.js" in page.text
        assert web.get("/web/src/mission-v03.js", timeout=3).status_code == 200
        assert web.get("/.env").status_code in {401, 404}
        assert web.get("/web/src/../../.env").status_code in {401, 404}
        too_long = web.post("/api/v03/register", content=b"x" * 65537)
        assert too_long.status_code == 413
