"""Official-source pack and semantic boundaries; no network or provider calls."""
from copy import deepcopy
import hashlib
import json

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.evidence import outcome_topic, validate_citation
from nmate.v03.live_review import validate_intake
from nmate.v03.research_scope import allowed_intake_outcomes, project_research_scope


@pytest.fixture
def catalog(tmp_path):
    return DomainCatalog(CoreRepository(tmp_path / "pack.sqlite3"))


@pytest.mark.parametrize("market,outcome,topic", [
    ("US", "prior_notice", "prior_notice"), ("DE", "prior_notice", None),
    ("JP", "prior_notice", None), (None, "registration", None),
    ("unresolved", "label", None), ("DE", "registration", "facility_registration")])
def test_market_bound_shared_topic_registry(market, outcome, topic):
    assert outcome_topic(outcome, market) == topic


@pytest.mark.parametrize("market,question,expected", [
    ("DE", "Hãy nghiên cứu yêu cầu nhập khẩu và nhãn", {"registration", "label"}),
    ("JP", "Ai làm thông báo nhập khẩu", {"registration"}),
    ("US", "Ai nộp thông báo trước và khi nào", {"prior_notice"}),
    ("US", "Nhãn đã làm xong; tôi chỉ hỏi ai nộp thông báo trước và khi nào", {"prior_notice"}),
    ("US", "Tôi không cần nhãn; tôi hỏi đăng ký cơ sở", {"registration"}),
    ("US", "Tôi hỏi ba việc đầu tiên cho lô hàng", set()),
])
def test_intake_schema_does_not_force_triplet_or_reopen_resolved_topics(market, question, expected):
    assert set(allowed_intake_outcomes(question, market)) - {"clarification"} == expected


@pytest.mark.parametrize("market,question,outcome,quote", [
    ("DE", "Hãy nghiên cứu yêu cầu nhập khẩu", "prior_notice", "yêu cầu nhập khẩu"),
    ("US", "Nhãn đã xong; tôi chỉ hỏi thông báo trước", "label", "Nhãn"),
    ("US", "Ai nộp thông báo trước", "registration", "Ai nộp"),
])
def test_exact_quote_alone_cannot_launder_semantically_wrong_outcome(market, question, outcome, quote):
    data = {"scope": "us_food" if market == "US" else "export_food", "outcomes": [{"id": outcome, "question_quote": quote}],
            "product_name": None, "product_quote": None, "ambiguities": []}
    with pytest.raises(CoreError, match="Mục tiêu AI"):
        validate_intake({"data": data}, question, market)


def test_prior_notice_has_original_submitter_timing_sources_but_never_foreign_coverage(catalog):
    result = catalog.lookup_domain(["prior_notice"], market_code="US")
    assert result["coverage"]["supported"] == ["prior_notice"]
    assert len(result["records"]) == 3
    text = " ".join(r["excerpt"] for r in result["records"])
    assert "Any individual with knowledge" in text
    assert "No less than 8 hours" in text and "No less than 2 hours" in text
    for record in result["records"]:
        assert record["excerpt"] in catalog.get_source(record["source_id"])["text"]
        assert hashlib.sha256(record["excerpt"].encode()).hexdigest() == record["excerpt_sha256"]
        assert record["review_state"] == "reference_unreviewed"
        assert validate_citation(record["id"], quote_original=record["excerpt"], records=result["records"], outcome_id="prior_notice", expected_market_code="US")
    assert catalog.lookup_domain(["prior_notice"], market_code="DE")["records"] == []
    with pytest.raises(CoreError):
        validate_citation(result["records"][0]["id"], quote_original=result["records"][0]["excerpt"], records=result["records"], outcome_id="prior_notice", expected_market_code="JP")


def test_new_pack_selection_is_audited_and_does_not_rewrite_old_source_state_or_missions(catalog):
    repo = catalog.repo
    from nmate.v03.identity import LocalAccounts
    from nmate.v03.missions import MissionService
    service = MissionService(repo)
    owner = LocalAccounts(repo).register("pack-owner", "TestPassword12345", "Doanh nghiệp kiểm thử")
    service.prepare(owner["account_id"], owner["enterprise_id"], "Trà Sen xuất Nhật Bản, cần nhãn.", "before-reinstall")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation',version=8,invalidated_at='2026-10-18T01:00:00Z' WHERE id='jp_mhlw_import_notification'")
        before = [tuple(r) for r in db.execute("SELECT * FROM v03_domain_sources WHERE id NOT LIKE '%20261019%' ORDER BY id")]
        mission_before = [tuple(r) for r in db.execute("SELECT * FROM v03_missions ORDER BY id")]
    DomainCatalog(repo)
    with repo.connection() as db:
        assert [tuple(r) for r in db.execute("SELECT * FROM v03_domain_sources WHERE id NOT LIKE '%20261019%' ORDER BY id")] == before
        assert [tuple(r) for r in db.execute("SELECT * FROM v03_missions ORDER BY id")] == mission_before
        assert db.execute("SELECT COUNT(*) FROM v03_domain_pack_installations").fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM v03_domain_reference_supersessions").fetchone()[0] == 5
    current = catalog.lookup_domain(["registration", "label"], market_code="JP")
    assert all(r["source_id"] != "jp_mhlw_import_notification" for r in current["records"])
    assert all(r["source_id"] != "jp_caa_processed_food_label" for r in current["records"])
    original = catalog.lookup_domain(["registration", "label"], market_code="JP", as_of_date="2026-10-18")
    assert any(r["source_id"] == "jp_mhlw_import_notification" and not r["reusable"] for r in original["records"])
    # Invalidating the replacement cannot resurrect an older superseded source.
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='revoked' WHERE id='jp_mhlw_notification_20261019_v1'")
    replacement_invalid = catalog.lookup_domain(["registration"], market_code="JP")
    assert replacement_invalid["coverage"]["missing"] == ["facility_registration"]
    assert all(r["source_id"] != "jp_mhlw_import_notification" for r in replacement_invalid["records"])
    assert not any(ref["source_id"] == "jp_mhlw_notification_20261019_v1" for ref in replacement_invalid["source_refs"])


def test_pack_hash_cannot_be_mutated_in_place(catalog):
    from pathlib import Path
    import nmate.v03.catalog as module
    pack = json.loads((Path(module.__file__).parent / "data/authority_expansion_20261019.json").read_text(encoding="utf-8"))
    tampered = deepcopy(pack)
    tampered["coverage_note_vi"] += " changed"
    with catalog.repo.connection(write=True) as db:
        with pytest.raises(CoreError, match="Gói nguồn"):
            catalog._install_pack(db, tampered)


def test_scope_includes_every_requested_unsupported_outcome_before_paid_start(catalog):
    mission = {"market": {"code": "US"}, "intent": {"outcomes": [{"id": "prior_notice"}, {"id": "certification"}]},
               "knowledge": catalog.lookup_domain(["prior_notice", "certification"], market_code="US")}
    scope = project_research_scope(mission)
    assert scope["status"] == "partial" and scope["can_start_research"]
    assert scope["supported_outcomes"][0]["outcome_id"] == "prior_notice"
    assert scope["blocked_outcomes"][0]["outcome_id"] == "certification"
    mission["intent"]["outcomes"] = [{"id": "certification"}]
    assert project_research_scope(mission)["can_start_research"] is False


def test_partial_topic_coverage_cannot_publish_nonblocked_answer_despite_one_valid_citation(catalog):
    from nmate.v03.live_review import validate_research
    knowledge = catalog.lookup_domain(["food_label"], market_code="US")
    record = knowledge["records"][0]
    knowledge["coverage"].update(supported=[], missing=["food_label"])
    mission = {"market": {"code": "US"}, "intent": {"outcomes": [{"id": "label"}]},
               "context": {"entities": []}, "knowledge": knowledge}
    answer = {"outcome_id": "label", "status": "answered_general", "text": "Câu trả lời tham chiếu chưa đủ toàn bộ phạm vi.",
              "details_vi": "Không được kết luận khi chủ đề bị đánh dấu thiếu nguồn.",
              "citations": [{"source_id": record["id"], "quote_original": record["excerpt"]}], "missing_fields": []}
    with pytest.raises(CoreError, match="Phạm vi nguồn"):
        validate_research({"data": {"answers": [answer], "actions": []}}, mission)


@pytest.mark.asyncio
async def test_xml_network_check_reads_law_only_and_blocks_entities(catalog):
    from nmate.v03.source_refresh import AuthoritySourceRefresher
    body = b'<DataRoot><ApplData><LawFullText><Law><Sentence>Official food label rule with a complete reference sentence.</Sentence></Law></LawFullText><ImageData>NEVER_BINARY_DATA</ImageData></ApplData></DataRoot>'
    async def get(_):
        return 200, {"content-type": "text/xml; charset=utf-8"}, body
    async def dns(_):
        return None
    refresher = AuthoritySourceRefresher(catalog.repo, catalog, request_fn=get, dns_guard=dns)
    source = {"id": "test", "url": "https://laws.e-gov.go.jp/api/1/lawdata/427M60000002010"}
    result = await refresher._fetch(source)
    assert "Official food label rule" in result["text"]
    assert "NEVER_BINARY_DATA" not in result["text"]
    body = b'<!DOCTYPE test [<!ENTITY x "malicious">]><DataRoot><LawFullText>&x;</LawFullText></DataRoot>'
    with pytest.raises(CoreError) as error:
        await refresher._fetch(source)
    assert error.value.code == "authority_unsafe_xml"
