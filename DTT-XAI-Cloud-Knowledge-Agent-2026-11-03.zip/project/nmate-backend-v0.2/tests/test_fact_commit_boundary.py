"""Independent cross-adapter checks of the common authorized fact writer.

These exercise real repositories, bounded mission templates, and SQL rollback.
No provider is installed and network dispatch is prohibited.
"""
from __future__ import annotations

import socket

import pytest

from nmate.core_v1.fact_commit import FactCommitService
from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from nmate.v04.intake import IntakeService
from test_review_commands_v2 import data_snapshot
from test_v03_missions import complete


ROUTES = ["profile", "core_proposal", "intake", "mission_facts", "label_memory"]


@pytest.fixture(autouse=True)
def prohibit_network(monkeypatch):
    connect, connect_ex = socket.socket.connect, socket.socket.connect_ex
    def guard(original):
        def connect_local(sock, address):
            # Windows asyncio creates its self-pipe through a loopback socket.
            if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
                return original(sock, address)
            raise AssertionError("Fact-write acceptance must not call an external model or network")
        return connect_local
    monkeypatch.setattr(socket.socket, "connect", guard(connect))
    monkeypatch.setattr(socket.socket, "connect_ex", guard(connect_ex))


@pytest.fixture(params=ROUTES)
def case(tmp_path, request):
    repo = CoreRepository(tmp_path / (request.param + ".sqlite3"))
    accounts = LocalAccounts(repo)
    owner = accounts.register("boundary-owner", "Local-only-boundary-password", "Trà Sen QA")
    staff = accounts.register("boundary-staff", "Local-only-boundary-password", "Nhân viên")
    outsider = accounts.register("boundary-other", "Local-only-boundary-password", "Doanh nghiệp khác")
    core = CoreSSOTService(repo)
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    core.add_member(owner["account_id"], owner["enterprise_id"], staff["username"])
    core.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read"], ["*"])
    fact = {"field": "net_quantity", "value": "100 g", "source": {"kind": "owner_statement", "quote": "100 g"}}
    route = request.param
    version = entity["version"]
    if route == "core_proposal":
        proposal = core.propose_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [fact], version, "boundary-proposal")
    elif route == "intake":
        intake = IntakeService(repo)
        item = intake.prepare(owner["account_id"], owner["enterprise_id"], "Cập nhật hồ sơ: khối lượng tịnh: 100 g", [], "boundary-intake", entity["id"])
        candidate = next(c for c in item["candidates"] if c["field"] == "net_quantity")
    elif route in {"mission_facts", "label_memory"}:
        missions = MissionService(repo)
        mission = complete(missions, owner, product=entity["id"])
        version = mission["product"]["version"]

    def invoke(actor=None, operation="boundary-owner-save", enterprise=None):
        actor = actor or owner
        aid = actor["account_id"]
        eid = enterprise or owner["enterprise_id"]
        if route == "profile":
            return repo.propose_or_apply_facts(aid, eid, entity["id"], [fact], version, operation)
        if route == "core_proposal":
            return core.confirm_facts(aid, eid, proposal["proposal_id"], version, operation, proposal_hash=proposal["proposal_hash"])
        if route == "intake":
            return intake.confirm(aid, eid, item["id"], [candidate["id"]], item["expected_entity_versions"], operation,
                expected_review_revision=item["review"]["revision"], expected_proposal_hashes={candidate["id"]: candidate["proposal_hash"]})
        if route == "mission_facts":
            return missions.update_facts(aid, eid, mission["id"], [fact], version, operation)
        return missions.update_label_progress(aid, eid, mission["id"], mission["label"]["id"], {"net_quantity": "100 g"}, ["net_quantity"],
            mission["label"]["version"], version, operation, expected_market_profile_version=mission["market_profile"]["version"])

    return {"repo": repo, "core": core, "owner": owner, "staff": staff, "outsider": outsider,
            "entity": entity, "version": version, "invoke": invoke, "route": route}


def test_each_adapter_reaches_common_writer_with_same_transaction(case, monkeypatch):
    calls = []
    commit = FactCommitService.commit

    def observe(self, *args, **kwargs):
        calls.append({"entity": args[2], "db": kwargs.get("db")})
        return commit(self, *args, **kwargs)

    monkeypatch.setattr(FactCommitService, "commit", observe)
    case["invoke"]()
    assert calls and all(c["entity"] == case["entity"]["id"] for c in calls)
    if case["route"] != "profile":
        assert all(c["db"] is not None for c in calls)
    context = case["repo"].get_context(case["owner"]["account_id"], case["owner"]["enterprise_id"], [case["entity"]["id"]])
    fact = next(f for f in context["entities"][0]["facts"] if f["field"] == "net_quantity")
    assert fact["value"] == "100 g"
    assert fact["verification_state"] == "self_declared"
    with case["repo"].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_v1_egress_authorities").fetchone()[0] == 0
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []


@pytest.mark.parametrize("access", ["read_only_staff", "cross_tenant", "revoked_entity"])
def test_every_adapter_denies_without_current_authority_and_changes_nothing(case, access):
    if access == "revoked_entity":
        with case["repo"].connection(write=True) as db:
            db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (case["entity"]["id"],))
    before = data_snapshot(case["repo"])
    with pytest.raises(CoreError):
        if access == "read_only_staff":
            case["invoke"](case["staff"])
        elif access == "cross_tenant":
            case["invoke"](case["outsider"], enterprise=case["outsider"]["enterprise_id"])
        else:
            case["invoke"]()
    assert data_snapshot(case["repo"]) == before


def test_every_adapter_preserves_entity_cas(case):
    repo, owner, entity = case["repo"], case["owner"], case["entity"]
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
        [{"field": "ingredients", "value": "Trà xanh"}], case["version"], "boundary-concurrent-change")
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        case["invoke"]()
    assert error.value.status_code == 409
    assert data_snapshot(repo) == before


def test_failure_after_common_sql_write_rolls_back_all_adapter_side_effects(case, monkeypatch):
    repo = case["repo"]
    before = data_snapshot(repo)
    apply = repo._apply_authorized_facts

    def fail_after_apply(*args, **kwargs):
        connection = kwargs["db"]
        assert connection.in_transaction
        result = apply(*args, **kwargs)
        assert result["changed_fields"]
        raise RuntimeError("boundary fault after fact write")

    monkeypatch.setattr(repo, "_apply_authorized_facts", fail_after_apply)
    with pytest.raises(RuntimeError, match="boundary fault"):
        case["invoke"]()
    assert data_snapshot(repo) == before


def test_core_confirmation_replay_rechecks_private_acl(tmp_path):
    repo = CoreRepository(tmp_path / "replay-read-guard.sqlite3")
    owner = LocalAccounts(repo).register("replay-owner", "Local-only-boundary-password", "Trà Sen QA")
    core = CoreSSOTService(repo)
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    proposal = core.propose_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
        [{"field": "net_quantity", "value": "100 g"}], 0, "private-proposal")
    def confirm():
        return core.confirm_facts(owner["account_id"], owner["enterprise_id"], proposal["proposal_id"], 0, "private-confirm", proposal_hash=proposal["proposal_hash"])
    confirm()
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (entity["id"],))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm()  # Same operation is a read/replay, never a new write.
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before


def test_public_writer_joins_outer_uow_without_initializing_or_committing(tmp_path):
    repo = CoreRepository(tmp_path / "outer-uow.sqlite3")
    owner = LocalAccounts(repo).register("outer-owner", "Local-only-boundary-password", "Trà Sen QA")
    CoreSSOTService(repo)
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    before = data_snapshot(repo)
    with pytest.raises(RuntimeError, match="outer rollback"):
        with repo.connection(write=True) as db:
            result = repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
                [{"field": "net_quantity", "value": "100 g"}], 0, "boundary-outer", db=db)
            assert db.in_transaction and result["changed_fields"]
            raise RuntimeError("outer rollback")
    assert data_snapshot(repo) == before


def test_unknown_fields_and_unknown_values_keep_existing_restrictions(tmp_path):
    repo = CoreRepository(tmp_path / "unknowns.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("unknown-owner", "Local-only-boundary-password", "Trà Sen QA")
    staff = accounts.register("unknown-staff", "Local-only-boundary-password", "Nhân viên")
    core = CoreSSOTService(repo)
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    saved = repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
        [{"field": "net_quantity", "value": "100 g"}, {"field": "opaque_restricted", "value": "Nội bộ"}], 0, "boundary-known")
    core.add_member(owner["account_id"], owner["enterprise_id"], staff["username"])
    core.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read", "propose_fact"], ["*"])
    before = data_snapshot(repo)
    with pytest.raises(CoreError):
        core.propose_facts(staff["account_id"], owner["enterprise_id"], entity["id"], [{"field": "opaque_restricted", "value": "Mới"}], saved["version"], "boundary-opaque-wildcard")
    assert data_snapshot(repo) == before
    result = repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
        [{"field": "net_quantity", "value": None}], saved["version"], "boundary-unknown-not-clear")
    assert result["changed_fields"] == []
    assert next(f for f in result["facts"] if f["field"] == "net_quantity")["value"] == "100 g"
    assert all(f["certainty"] == "self_declared" for f in result["facts"])
