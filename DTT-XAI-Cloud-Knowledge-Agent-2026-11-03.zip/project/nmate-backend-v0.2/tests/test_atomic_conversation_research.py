"""Offline transaction, lost-response and ownership regressions; no SDK or network."""
import copy
from concurrent.futures import ThreadPoolExecutor

import pytest
from fastapi.testclient import TestClient

from nmate.app import create_app
from nmate.config import Settings
from nmate.conversations.models import FactsInput, ResearchCaseInput, ResearchCaseResponse
from nmate.conversations.service import SYSTEM
from nmate.conversations.store import ConversationStore
from nmate.models import AppError, Principal
from nmate.store import Store


P = Principal("TEST-ATOMIC-TENANT", "TEST-ATOMIC-OWNER")


def prepared(tmp_path, *, principal=P):
    store = Store(tmp_path / "TEST-ATOMIC.sqlite3")
    conversations = ConversationStore(store)
    body = conversations.create(principal, {"consent_model": True, "consent_storage": True})
    changes = FactsInput(expected_version=body["version"], idempotency_key="TEST-PREPARE-FACTS",
        changes=[{"field": "product.name", "value": "Trà Sen Tây Hồ"},
                 {"field": "question", "value": "Tôi cần tìm hiểu đăng ký cơ sở và nhãn cho Trà Sen Tây Hồ?"}])
    body = conversations.edit_facts(principal, body["conversation_id"], changes.model_dump())
    body = conversations.confirm(principal, body["conversation_id"],
        {"expected_version": body["version"], "idempotency_key": "TEST-PREPARE-CONFIRM"})
    return store, conversations, body


def launch_args(body, key="TEST-ATOMIC-LAUNCH", level="standard"):
    return ResearchCaseInput(expected_version=body["version"], idempotency_key=key,
                             processing_level=level).model_dump()


def launch(conversations, body, **kwargs):
    return conversations.research_case(P, body["conversation_id"], launch_args(body, **kwargs))


def start(store, payload):
    return store.start(P, payload["start_arguments"], mode="evidence_only", max_active=10, max_daily=50)


def counts(store):
    with store.connection() as db:
        return {table: db.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
                for table in ("cases", "runs", "artifacts", "conversation_research_requests")}


def test_atomic_snapshot_comes_only_from_confirmed_server_facts_and_persists_intent(tmp_path):
    store, conversations, body = prepared(tmp_path)
    result = launch(conversations, body)
    ResearchCaseResponse.model_validate(result)
    case, linked = result["case"], result["conversation"]
    assert case["product"]["name"] == "Trà Sen Tây Hồ"
    assert case["product"]["sku"] == "REF-" + body["conversation_id"][:12].upper()
    assert body["draft"]["product"]["sku"] is None
    assert case["consent_research"] and case["consent_model"]
    assert case["research_context"] == {key: body["draft"][key] for key in ("uncertain_fields", "field_sources")}
    assert linked["case_id"] == case["case_id"] and len(linked["research_links"]) == 1
    assert linked["pending_research_launch"] == result["start_arguments"]
    assert result["start_arguments"]["question"] == body["draft"]["question"]
    assert result["start_arguments"]["processing_level"] == "standard"
    assert counts(store) == {"cases": 1, "runs": 0, "artifacts": 0, "conversation_research_requests": 1}
    assert ConversationStore(Store(store.path)).get(P, body["conversation_id"]) == linked
    assert not linked["messages"][0]["content"].startswith("Mình")


@pytest.mark.parametrize("failure_point", ["_save", "_activity"])
def test_create_link_and_intent_rollback_even_if_disconnected_during_commit_preparation(tmp_path, monkeypatch, failure_point):
    store, conversations, body = prepared(tmp_path)
    original = getattr(conversations, failure_point)
    def disconnected(*args, **kwargs):
        raise ConnectionAbortedError("TEST browser disconnected")
    monkeypatch.setattr(conversations, failure_point, disconnected)
    with pytest.raises(ConnectionAbortedError):
        launch(conversations, body)
    monkeypatch.setattr(conversations, failure_point, original)
    assert counts(store) == {"cases": 0, "runs": 0, "artifacts": 0, "conversation_research_requests": 0}
    assert conversations.get(P, body["conversation_id"]) == body
    assert launch(conversations, body)["conversation"]["case_id"]


def test_duplicate_concurrent_same_key_replays_one_case_and_one_link(tmp_path):
    store, conversations, body = prepared(tmp_path)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda _: launch(conversations, body), range(2)))
    assert results[0] == results[1]
    assert counts(store)["cases"] == counts(store)["conversation_research_requests"] == 1
    assert len(conversations.get(P, body["conversation_id"])["research_links"]) == 1


def test_different_concurrent_keys_cannot_create_two_snapshots_from_same_version(tmp_path):
    store, conversations, body = prepared(tmp_path)
    def attempt(index):
        try:
            return launch(conversations, body, key=f"TEST-RACE-LAUNCH-{index}")
        except AppError as error:
            return error.code
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(attempt, range(2)))
    assert sum(isinstance(value, dict) for value in results) == 1
    assert "VERSION_CONFLICT" in results
    assert counts(store)["cases"] == 1


def test_response_lost_then_reload_exposes_intent_and_explicit_click_reuses_case_without_dispatch(tmp_path):
    store, conversations, body = prepared(tmp_path)
    lost_response = launch(conversations, body)
    reopened = ConversationStore(Store(store.path))
    restored = reopened.get(P, body["conversation_id"])
    assert restored["pending_research_launch"] == lost_response["start_arguments"]
    assert counts(store)["runs"] == 0
    explicit_click = launch(reopened, restored, key="TEST-SECOND-EXPLICIT-CLICK")
    assert explicit_click["case"] == lost_response["case"]
    assert explicit_click["start_arguments"] == lost_response["start_arguments"]
    assert counts(store)["cases"] == 1 and counts(store)["runs"] == 0
    with pytest.raises(AppError) as error:
        launch(reopened, restored, key="TEST-CHANGED-LEVEL", level="complex")
    assert error.value.code == "RESEARCH_LAUNCH_MISMATCH"
    assert counts(store)["cases"] == 1


def test_reused_idempotency_key_rejects_changed_payload_and_stale_new_key(tmp_path):
    store, conversations, body = prepared(tmp_path)
    launch(conversations, body)
    with pytest.raises(AppError) as error:
        launch(conversations, body, level="complex")
    assert error.value.code == "IDEMPOTENCY_CONFLICT"
    with pytest.raises(AppError) as error:
        launch(conversations, body, key="TEST-STALE-NEW-LAUNCH")
    assert error.value.code == "VERSION_CONFLICT"
    assert counts(store)["cases"] == 1


def test_start_and_run_link_rollback_together_then_exact_replay_never_duplicates(tmp_path, monkeypatch):
    store, conversations, body = prepared(tmp_path)
    result = launch(conversations, body)
    sync = store._sync_conversation_research
    def fail_sync(*args):
        sync(*args)
        raise ConnectionAbortedError("TEST lost while syncing run")
    monkeypatch.setattr(store, "_sync_conversation_research", fail_sync)
    with pytest.raises(ConnectionAbortedError):
        start(store, result)
    assert counts(store)["runs"] == 0
    assert conversations.get(P, body["conversation_id"]) == result["conversation"]
    monkeypatch.setattr(store, "_sync_conversation_research", sync)
    run = start(store, result)
    reopened = conversations.get(P, body["conversation_id"])
    assert reopened["run_id"] == run["run_id"] and reopened["pending_research_launch"] is None
    assert len(reopened["research_links"]) == 1
    assert reopened["research_links"][0]["run_id"] == run["run_id"]
    assert start(store, result) == run
    assert conversations.get(P, body["conversation_id"])["version"] == reopened["version"]
    assert counts(store)["runs"] == 1


def test_artifact_and_final_link_rollback_together_then_publish_without_browser_link(tmp_path, monkeypatch):
    store, conversations, body = prepared(tmp_path)
    result = launch(conversations, body)
    run = start(store, result)
    assert store.claim("TEST-WORKER")["run_id"] == run["run_id"]
    before = conversations.get(P, body["conversation_id"])
    report = {"summary": "TEST synthetic report; no model, no real source."}
    sync = store._sync_conversation_research
    def fail_sync(*args):
        sync(*args)
        raise ConnectionAbortedError("TEST lost while linking artifact")
    monkeypatch.setattr(store, "_sync_conversation_research", fail_sync)
    with pytest.raises(ConnectionAbortedError):
        store.finish(run["run_id"], "TEST-WORKER", report=report)
    assert counts(store)["artifacts"] == 0
    assert store.get_run(P, run["run_id"])["status"] == "running"
    assert conversations.get(P, body["conversation_id"]) == before
    monkeypatch.setattr(store, "_sync_conversation_research", sync)
    store.finish(run["run_id"], "TEST-WORKER", report=report)
    finished = store.get_run(P, run["run_id"])
    restored = conversations.get(P, body["conversation_id"])
    assert restored["artifact_id"] == finished["artifact_id"]
    assert restored["research_links"][0]["artifact_id"] == finished["artifact_id"]
    assert restored["activity_state"]["status"] == "ready"
    assert counts(store)["artifacts"] == 1


@pytest.mark.parametrize("principal", [Principal(P.tenant_id, "TEST-OTHER-OWNER"), Principal("TEST-OTHER-TENANT", P.subject)])
def test_foreign_principal_cannot_create_or_replay_another_conversation_launch(tmp_path, principal):
    store, conversations, body = prepared(tmp_path)
    launch(conversations, body)
    with pytest.raises(AppError) as error:
        conversations.research_case(principal, body["conversation_id"], launch_args(body))
    assert error.value.code == "NOT_FOUND"
    assert counts(store)["cases"] == 1


def test_browser_cannot_rewrite_confirmed_question_level_or_key_after_snapshot(tmp_path):
    store, conversations, body = prepared(tmp_path)
    result = launch(conversations, body)
    for key, value in (("question", "TEST attacker question"), ("processing_level", "complex"),
                       ("idempotency_key", "TEST-ATTACK-NEW-START")):
        tampered = copy.deepcopy(result)
        tampered["start_arguments"][key] = value
        with pytest.raises(AppError) as error:
            start(store, tampered)
        assert error.value.code == "RESEARCH_LAUNCH_MISMATCH"
    assert counts(store)["runs"] == 0


def test_same_tenant_foreign_owner_cannot_start_or_replay_managed_run(tmp_path):
    store, conversations, body = prepared(tmp_path)
    result = launch(conversations, body)
    other = Principal(P.tenant_id, "TEST-DIFFERENT-OWNER")
    for after_start in (False, True):
        if after_start:
            start(store, result)
        with pytest.raises(AppError) as error:
            store.start(other, result["start_arguments"], mode="evidence_only", max_active=10, max_daily=50)
        assert error.value.code == "NOT_FOUND"


def test_research_endpoint_has_csrf_owner_and_strict_payload_guards_without_model(tmp_path):
    def no_model(*args, **kwargs):
        raise AssertionError("No provider may initialize in this test")
    app = create_app(Settings(_env_file=None, data_dir=tmp_path, mode="evidence_only"), conversation_model_factory=no_model)
    a = TestClient(app, base_url="http://127.0.0.1:8022")
    b = TestClient(app, base_url="http://127.0.0.1:8022")
    ha = {"X-CSRF-Token": a.get("/api/session").json()["csrf_token"]}
    hb = {"X-CSRF-Token": b.get("/api/session").json()["csrf_token"]}
    p = app.state.auth.device_principal(a.cookies.get("nmate_device"))
    conversations = app.state.conversations.store
    body = conversations.create(p, {"consent_model": True, "consent_storage": True})
    body = conversations.edit_facts(p, body["conversation_id"], FactsInput(expected_version=body["version"],
        idempotency_key="TEST-HTTP-FACTS", changes=[{"field": "product.name", "value": "Trà Sen"},
        {"field": "question", "value": "Tôi cần tìm hiểu nhãn?"}]).model_dump())
    body = conversations.confirm(p, body["conversation_id"], {"expected_version": body["version"], "idempotency_key": "TEST-HTTP-CONFIRM"})
    url = f"/api/conversations/{body['conversation_id']}/research-case"
    args = launch_args(body)
    assert a.post(url, json=args).status_code == 403
    assert b.post(url, headers=hb, json=args).status_code == 404
    assert a.post(url, headers=ha, json={**args, "question": "TEST malicious override"}).status_code == 422
    response = a.post(url, headers=ha, json=args)
    assert response.status_code == 200
    ResearchCaseResponse.model_validate(response.json())
    assert response.json() == a.post(url, headers=ha, json=args).json()
    assert b.get("/api/cases").json() == []
    assert app.state.store.list_runs(p) == []
    a.close()
    b.close()


def test_prompt_distinguishes_conversation_from_immutable_research_snapshots():
    assert "một bản dữ kiện riêng, bất biến" in SYSTEM
    assert "tiếp tục bổ sung cùng hồ sơ" not in SYSTEM
    assert "Xưng 'mình', gọi người dùng là 'bạn'" in SYSTEM
