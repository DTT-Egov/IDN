"""Offline source/translation coverage; never performs model or network calls."""
from dataclasses import replace
import hashlib
from html import escape
import json
from pathlib import Path

import httpx
import pytest

from nmate.agents.shipment.models import Evidence, SourceDocument, SourceFailure
from nmate.agents.shipment.sources import (
    OfficialSourceProvider, SOURCE_CATALOG, SourceRetrievalError, parse_document,
    source_evidence_passages, validate_url,
)
from nmate.agents.shipment.translations import attach_reference_translation, excerpt_sha256

FIXTURE = json.loads((Path(__file__).parent / "fixtures/official_topic_passages.json").read_text(encoding="utf-8"))
ROWS = FIXTURE["sources"]
SPECS = {spec.id: spec for spec in SOURCE_CATALOG}


def document(row, text=None, **changes):
    text = text if text is not None else "\n".join(p["excerpt"] for p in row["passages"])
    values = dict(id=row["source_id"], url=row["url"], title=row["title"], publisher=row["publisher"],
                  accessed_at="2026-10-18T00:00:00Z", text=text, content_sha256=excerpt_sha256(text))
    values.update(changes)
    return SourceDocument(**values)


def test_fixed_catalog_covers_topics_without_arbitrary_url_or_host_expansion():
    assert [s.id for s in SOURCE_CATALOG[:3]] == ["fda_import", "fda_fsvp", "cbp_import"]
    assert len(SOURCE_CATALOG) == len({s.id for s in SOURCE_CATALOG}) == len({s.url for s in SOURCE_CATALOG}) == 9
    assert {row["source_id"] for row in ROWS} <= SPECS.keys()
    for spec in SOURCE_CATALOG[3:]:
        assert validate_url(spec.url) == "www.fda.gov"
        assert len(spec.markers) >= 3


@pytest.mark.parametrize("row", ROWS, ids=lambda r: r["source_id"])
def test_complete_retrieved_clauses_keep_offsets_originals_and_exact_vietnamese_drafts(row):
    doc = document(row)
    selected = source_evidence_passages(doc)
    assert {p[0] for p in selected} == {p["id"] for p in row["passages"]}
    normalized = " ".join(doc.text.split())
    for passage_id, excerpt, locator in selected:
        assert 0 < len(excerpt) <= 1400
        start, stop = map(int, locator.split(":")[1:])
        assert excerpt == normalized[start:stop]
        original = Evidence(id=f"ev_{doc.id}_{passage_id}_fixture", url=doc.url, title=doc.title,
                            publisher=doc.publisher, accessed_at=doc.accessed_at,
                            content_sha256=doc.content_sha256, excerpt=excerpt, locator=locator)
        result = attach_reference_translation(original)
        assert result.translation.method == "reference_catalog"
        assert result.translation.status == "draft_reference"
        assert result.translation.original_excerpt_sha256 == excerpt_sha256(excerpt)
        assert result.review_status == "candidate" and "chưa" in result.translation.note
        assert result.excerpt == original.excerpt and result.excerpt_vi != original.excerpt


@pytest.mark.parametrize("row", ROWS, ids=lambda r: r["source_id"])
def test_missing_end_or_overlong_clause_does_not_clip_into_fake_evidence(row):
    first = row["passages"][0]
    # A heading/keyword/partial statement alone is not enough.
    assert source_evidence_passages(document(row, first["excerpt"][:40])) == []
    oversized = first["excerpt"][:50] + " x" * 1500 + first["excerpt"][50:]
    assert source_evidence_passages(document(row, oversized)) == []


@pytest.mark.parametrize("row", ROWS, ids=lambda r: r["source_id"])
def test_changed_clause_or_provenance_never_gets_a_nearby_translation(row):
    doc = document(row)
    passage_id, excerpt, locator = source_evidence_passages(doc)[0]
    data = dict(id=f"ev_{doc.id}_{passage_id}_fixture", url=doc.url, title=doc.title,
                publisher=doc.publisher, accessed_at=doc.accessed_at,
                content_sha256=doc.content_sha256, excerpt=excerpt, locator=locator)
    for changes in ({"excerpt": excerpt + " altered"}, {"title": doc.title + " altered"},
                    {"url": "https://www.fda.gov/another-page"}, {"publisher": "Different publisher"}):
        result = attach_reference_translation(Evidence(**{**data, **changes}))
        assert result.translation.status == "unavailable" and result.excerpt_vi is None


def test_prior_notice_keeps_who_mode_deadlines_confirmation_and_both_mail_rules():
    row = next(r for r in ROWS if r["source_id"] == "fda_prior_notice")
    parts = {p[0]: p[1] for p in source_evidence_passages(document(row))}
    assert "Any individual with knowledge" in parts["prior_notice_who"]
    time = parts["prior_notice_when"]
    assert "receive and confirm" in time and "first port" in time
    assert all(value in time for value in ("30 days", "15 days", "2 hours", "4 hours", "8 hours", "Before the food is sent"))
    assert "samples" in parts["prior_notice_scope"]
    assert "for non-business reasons" in parts["prior_notice_exemptions"]
    assert "not for sale or other distribution" in parts["prior_notice_exemptions"]


def test_registration_and_label_rules_keep_exceptions_instead_of_certifying_a_case():
    rows = {r["source_id"]: r for r in ROWS}
    registration = dict((p[0], p[1]) for p in source_evidence_passages(document(rows["fda_registration"])))
    assert "unless a facility is specifically exempt" in registration["registration_rules"]
    assert "21 CFR 1.226" in registration["registration_rules"]
    assert "solely in Puerto Rico" in registration["label_english"]
    labels = dict((p[0], p[1]) for p in source_evidence_passages(document(rows["fda_labeling"])))
    assert "unless they qualify for an exemption" in labels["label_nutrition"]
    assert "only to nutrition" in labels["label_core"] and "all other mandatory" in labels["label_core"]


def test_detached_fda_accordion_is_read_only_for_the_fixed_affected_source():
    row = next(r for r in ROWS if r["source_id"] == "fda_us_agent")
    content = row["passages"][0]["excerpt"]
    raw = ("<html><body><main><h1>" + escape(row["title"]) + "</h1>" + "Intro " * 70 +
           "</main><div class='fda-accordion-panel'><p>" + escape(content) + "</p></div></body></html>").encode()
    doc = parse_document(SPECS["fda_us_agent"], row["url"], raw, "2026-10-18T00:00:00Z")
    assert source_evidence_passages(doc)[0][1] == content
    assert doc.content_sha256 == hashlib.sha256(doc.text.encode()).hexdigest()
    # An unrelated document cannot acquire those detached body fragments.
    other = replace(SPECS["fda_us_agent"], id="unrelated_fixture")
    with pytest.raises(SourceRetrievalError, match="markers missing"):
        parse_document(other, row["url"], raw, "2026-10-18T00:00:00Z")


@pytest.mark.parametrize("source_id", [spec.id for spec in SOURCE_CATALOG[3:]])
def test_new_catalog_pages_reject_200_challenges_instead_of_citing_them(source_id):
    shell = b"<main><h1>Verify browser</h1><p>Challenge required.</p></main>"
    with pytest.raises(SourceRetrievalError):
        parse_document(SPECS[source_id], SPECS[source_id].url, shell, "2026-10-18T00:00:00Z")


async def test_new_catalog_does_not_weaken_unsafe_redirect_or_size_guards(monkeypatch):
    async def public(_host):
        pass
    monkeypatch.setattr("nmate.agents.shipment.sources.validate_public_dns", public)
    requests = []
    def handle(request):
        requests.append(str(request.url))
        return httpx.Response(302, headers={"location": "https://127.0.0.1/private"})
    async with httpx.AsyncClient(transport=httpx.MockTransport(handle)) as client:
        result = await OfficialSourceProvider()._fetch_one(client, SPECS["fda_prior_notice"])
    assert isinstance(result, SourceFailure) and result.code == "UNSAFE_URL" and len(requests) == 1
    async with httpx.AsyncClient(transport=httpx.MockTransport(
        lambda _r: httpx.Response(200, headers={"content-type": "text/html", "content-length": "2000001"}))) as client:
        result = await OfficialSourceProvider()._fetch_one(client, SPECS["fda_labeling"])
    assert result.code == "BODY_TOO_LARGE"
