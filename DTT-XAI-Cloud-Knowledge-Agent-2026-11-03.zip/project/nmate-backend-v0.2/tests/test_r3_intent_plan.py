"""DF-015/022/024/025/026: plan semantics, never paid provider evaluation."""
from copy import deepcopy
import json

import pytest
from pydantic import ValidationError

from nmate.v03.intent_plan import (PlanProjection, compile_export_plan, compile_dialogue_plan,
                                  compile_policy_plan, broad_export_goal)
from nmate.v03.goal_readiness import project_delivery_status
from nmate.v03.live_review import LiveReviewMissionService, validate_intake, interpret_validated_intake
from nmate.v03.research_scope import project_research_scope, allowed_intake_outcomes, explicit_requested_outcomes
from nmate.v04.dialogue import interpret, working_answers


def export(question, market="US", outcomes=("registration", "label")):
    return {"question": question, "market": {"code": market}, "product": {"entity_id": "p1", "name": "Trà Sen"},
            "intent": {"scope": "export_food", "outcomes": [{"id": oid} for oid in outcomes]},
            "context": {"values": {"net_quantity": "100 g"}}, "knowledge": {"records": [], "coverage": {"supported": []}}}


@pytest.mark.parametrize("market,expected,absent", [
    ("US", {"facility_registration", "food_label", "prior_notice", "fsvp_importer", "origin_marking"}, {"eu_operator", "jp_importer"}),
    ("DE", {"facility_registration", "food_label", "eu_operator", "eu_import_controls"}, {"prior_notice", "fsvp_importer", "jp_importer"}),
    ("JP", {"facility_registration", "food_label", "jp_importer", "jp_product_scope"}, {"prior_notice", "fsvp_importer", "eu_operator"}),
])
def test_broad_preparation_is_market_specific_and_never_claims_legal_applicability(market, expected, absent):
    value = export("Chị muốn xuất Trà Sen, cần chuẩn bị lô hàng đầu tiên và ba việc đầu tiên.", market)
    original = deepcopy(value)
    result = compile_export_plan(value)
    assert {item["id"] for item in result["requirements"]} == expected
    assert not expected.intersection(absent)
    assert all(item["applicability"] == "not_assessed" and item["source_status"] == "needs_source" for item in result["requirements"])
    assert result["completeness"]["status"] == "partial"
    assert len(result["completeness"]["blockers"]) == len(expected)
    assert result["intent"]["product_ref"] == value["product"]
    assert result["does_not_change_saved_model_request"]
    assert value == original


@pytest.mark.parametrize("question", ["Chị chỉ muốn hỏi nhãn Trà Sen sang Mỹ cần ghi gì?",
    "Chị muốn bán sang Mỹ nhưng chỉ hỏi nhãn cần những gì và ba việc đầu tiên?",
    "Nhãn Trà Sen sang Mỹ cần ghi gì?", "Only ask about the label for the first shipment to US."])
def test_narrow_label_does_not_grow_into_a_standard_shipment_package(question):
    result = compile_export_plan(export(question, outcomes=("label",)))
    assert {item["id"] for item in result["requirements"]} == {"food_label"}
    assert len(result["first_actions"]) == 1
    action = result["first_actions"][0]
    assert action["requirement_ids"] == ["food_label"]
    assert "net_quantity" in action["reused_input_keys"]
    assert "net_quantity" not in action["missing_input_keys"]
    assert action["acceptance_vi"] and action["deliverable_vi"] and action["next_step_vi"]


@pytest.mark.parametrize("excluded,words", [("prior_notice", "không hỏi thông báo trước"),
    ("food_label", "bỏ qua nhãn"), ("facility_registration", "không cần đăng ký"),
    ("fsvp_importer", "không hỏi FSVP"), ("origin_marking", "không hỏi xuất xứ")])
def test_explicit_exclusion_does_not_return_as_supporting_task_or_action(excluded, words):
    question = "Chị muốn bán sang Mỹ, cần chuẩn bị lô hàng đầu tiên. Chị " + words + "."
    result = compile_export_plan(export(question))
    assert excluded in result["intent"]["exclusions"]
    assert excluded not in {item["id"] for item in result["requirements"]}
    assert not any(excluded in item["requirement_ids"] for item in result["first_actions"])


def test_negation_does_not_exclude_another_positive_clause():
    result = compile_export_plan(export("Chị muốn bán sang Mỹ, cần chuẩn bị lô hàng đầu tiên. Chị không hỏi thông báo trước, nhãn cần gì?"))
    assert result["intent"]["exclusions"] == ["prior_notice"]
    assert "food_label" in {item["id"] for item in result["requirements"]}


def test_foreign_sources_and_us_snapshot_cannot_make_de_plan_ready():
    value = export("Chị chỉ hỏi nhãn cho Đức", "DE", ("label",))
    value["knowledge"]["records"] = [{"id": "US-REF", "topics": ["food_label"], "scope": {"jurisdiction": "US"}}]
    value["goal_readiness_snapshot"] = {"market_code": "US", "requirements": [{"id": "food_label", "status": "reference_available", "citations": [{"reference_id": "US-REF"}]}]}
    result = compile_export_plan(value)
    assert result["requirements"][0]["source_refs"] == []
    assert result["requirements"][0]["source_status"] == "needs_source"


@pytest.mark.parametrize("state", ["needs_revalidation", "expired", "superseded"])
def test_source_freshness_is_not_same_as_a_topic_keyword(state):
    value = export("Chị chỉ hỏi nhãn đi Mỹ", outcomes=("label",))
    value["knowledge"]["records"] = [{"id": "label", "topics": ["food_label"], "scope": {"jurisdiction": "US"}, "freshness_state": state}]
    assert compile_export_plan(value)["requirements"][0]["source_status"] == "needs_source"


def test_answer_completeness_is_separate_from_saved_answer_correctness_and_source_blocker():
    value = export("Chị muốn bán sang Mỹ, cần ba việc đầu tiên.")
    value["answers"] = [{"outcome_id": "registration", "status": "answered_general", "text": "Saved answer; do not mutate"}]
    original = deepcopy(value)
    result = project_research_scope(value)
    assert result["can_start_research"] is False
    plan = result["intent_plan"]
    registration = next(item for item in plan["outcomes"] if item["goal_id"] == "export:facility_registration")
    assert registration["answer_status"] == "answered_general"
    assert registration["correctness"] == "not_assessed_by_plan"
    assert registration["source_status"] == "needs_source"
    assert value == original


def test_source_ready_subresearch_does_not_claim_whole_shipment_is_ready():
    value = export("Chị muốn bán sang Mỹ, cần ba việc đầu tiên.", outcomes=("registration",))
    value["knowledge"]["coverage"]["supported"] = ["facility_registration"]
    result = project_research_scope(value)
    assert result["can_start_research"]
    assert result["source_readiness_status"] == "ready"
    assert result["status"] == result["plan_completeness_status"] == "partial"
    assert result["can_start_scope"] == "independent_supported_requested_outcomes_only"


def test_legacy_delivery_complete_is_not_silently_upgraded_to_action_acceptance():
    value = export("Chị chỉ hỏi nhãn cho Mỹ", outcomes=("label",))
    value["intent"]["requested_action_count"] = 3
    value["knowledge"]["records"] = [{"id": "ref"}]
    value["actions"] = [{"id": str(i), "priority": i, "owner_vi": "Chủ cơ sở", "deliverable_vi": "Một bảng nhãn cần rà", "basis_source_ids": ["ref"]} for i in range(1, 4)]
    original = deepcopy(value)
    result = project_delivery_status(value)
    assert result["status"] == "complete"
    assert result["status_scope"] == "legacy_priority_owner_deliverable_basis_fields"
    assert result["action_brief_acceptance"]["status"] == "partial"
    assert "acceptance_vi" in result["action_brief_acceptance"]["actions"][0]["missing_fields"]
    assert value == original


def test_missing_market_does_not_default_to_us_or_invent_a_product():
    result = compile_export_plan({"question": "Tôi muốn xuất khẩu", "intent": {}, "context": {}, "knowledge": {}})
    assert result["intent"]["market_codes"] == []
    assert result["intent"]["product_ref"] == {}
    assert result["completeness"]["status"] == "needs_clarification"
    assert result["requirements"] == result["first_actions"] == []


def test_shared_policy_adapter_preserves_both_goals_and_distinct_source_blockers():
    question = "Cơ sở muốn hỗ trợ xúc tiến xuất khẩu trà sang Mỹ và đào tạo nhân viên làm sổ sách."
    result = compile_policy_plan(question, [
        {"goal": "market_development", "title_vi": "Phát triển thị trường / xuất khẩu", "status": "needs_source", "source_ids": []},
        {"goal": "workforce_training", "title_vi": "Đào tạo nhân viên", "status": "needs_source", "source_ids": []},
    ])
    assert {goal["id"] for goal in result["intent"]["goals"]} == {"market_development", "workforce_training"}
    assert len(result["outcomes"]) == len(result["completeness"]["blockers"]) == 2
    assert all(goal["quote"] == question for goal in result["intent"]["goals"])
    assert result["first_actions"][0]["title_vi"] != result["first_actions"][1]["title_vi"]
    assert all("duyệt" in task["acceptance_vi"] for task in result["tasks"])


def turn(question, previous=None):
    intent = interpret(question, previous=previous)
    intent["working_answers"] = working_answers(question, intent, (previous or {}).get("working_answers"))
    return intent


def test_inventory_followup_and_reload_preserve_working_inputs_without_ssot_or_sales_scope():
    first = turn("Tồn trên sổ 120, đếm thực tế 110")
    first = json.loads(json.dumps(first))
    reply = "Ngày 18/10/2026, mã TS01"
    second = turn(reply, first)
    plan = compile_dialogue_plan(second, reply)
    assert plan["intent"]["focus"] == "inventory_accuracy"
    assert plan["intent"]["known_inputs"] == {"book_quantity": 120.0, "physical_quantity": 110.0, "count_date": "2026-10-18", "product_code": "TS01"}
    assert all(item["missing_inputs"] == [] for item in plan["requirements"])
    assert plan["tasks"][1]["depends_on"] == [plan["tasks"][0]["id"]]
    assert all(not item["complete"] for item in plan["outcomes"])


def test_sales_month_survives_followup_and_does_not_turn_into_a_recurring_sales_rate():
    first = turn("Chị bán tháng 9 bán 120 hộp")
    first = json.loads(json.dumps(first))
    second = turn("Theo tháng và sản phẩm", first)
    plan = compile_dialogue_plan(second, "Theo tháng và sản phẩm")
    assert plan["intent"]["known_inputs"]["sales_period"] == "tháng 9"
    assert plan["intent"]["known_inputs"]["recent_sales_quantity"] == 120
    assert plan["requirements"][0]["missing_inputs"] == []


def test_focus_switch_rejects_inventory_slots_and_zero_is_not_missing():
    old = turn("Tồn trên sổ 120, đếm thực tế 110")
    after = turn("Chị muốn bán sang Mỹ", old)
    assert after["working_answers"] == {}
    intent = {"primary": "digitize_operations", "focus": "sales_reporting", "working_answers": {
        "recent_sales_quantity": 0, "sales_period": "tháng 9", "book_quantity": 999}}
    plan = compile_dialogue_plan(intent, "Tháng 9 bán 0 hộp")
    assert plan["intent"]["known_inputs"]["recent_sales_quantity"] == 0
    assert "book_quantity" not in plan["intent"]["known_inputs"]
    assert plan["requirements"][0]["missing_inputs"] == []


def test_source_preparation_is_not_false_completed_action_or_research():
    plan = compile_dialogue_plan(turn("Chị có nên nhập thêm hàng?"), "Chị có nên nhập thêm hàng?")
    assert len(plan["first_actions"]) == 3
    assert all(item["preparation_only"] for item in plan["first_actions"])
    assert all("FSVP" not in item["title_vi"] for item in plan["first_actions"])
    assert "lượng nên nhập" in plan["first_actions"][-1]["title_vi"]
    assert plan["completeness"]["does_not_mark_research_or_actions_complete"]


def test_plan_hash_is_pure_and_changes_only_with_projection_dependency():
    value = export("Chị chỉ hỏi nhãn sang Mỹ", outcomes=("label",))
    a = compile_export_plan(value)
    assert compile_export_plan(deepcopy(value)) == a
    value["context"]["values"]["net_quantity"] = "200 g"
    assert compile_export_plan(value)["plan_hash"] != a["plan_hash"]


def test_plan_validation_rejects_orphan_or_cyclic_tasks_and_excluded_requirements():
    plan = compile_export_plan(export("Chị chỉ hỏi nhãn sang Mỹ", outcomes=("label",)))
    for mutate in (
        lambda p: p["tasks"][0].update(requirement_id="absent"),
        lambda p: p["tasks"][0].update(depends_on=[p["tasks"][0]["id"]]),
        lambda p: p["intent"].update(exclusions=["food_label"]),
    ):
        changed = deepcopy(plan)
        mutate(changed)
        with pytest.raises(ValidationError):
            PlanProjection.model_validate(changed)


def test_unsupported_is_not_a_clarification_that_more_payment_can_solve():
    result = compile_dialogue_plan(turn("Chị muốn vay vốn ngân hàng"), "Chị muốn vay vốn ngân hàng")
    assert result["intent"]["domain"] == result["completeness"]["status"] == "unsupported"
    assert result["tasks"] == result["first_actions"] == []


@pytest.mark.parametrize("market", ["US", "DE", "JP"])
def test_broad_predicate_is_shared_but_legacy_us_request_contract_is_not_expanded(market):
    value = broad_export_goal("Chị muốn bán trà, cần ba việc đầu tiên", market)
    assert value["id"] == market.lower() + "_food_market_entry"


@pytest.mark.asyncio
@pytest.mark.parametrize("market", ["US", "DE", "JP"])
async def test_additive_plan_does_not_change_actual_canonical_model_request(market):
    value = export("Chị chỉ hỏi nhãn Trà Sen", market, ("label",))
    value.update(id="test-no-dispatch", owner_id="owner", enterprise_id="enterprise")
    value["context"]["entities"] = []
    service = object.__new__(LiveReviewMissionService)
    captured = []

    class CapturedBeforeProvider(Exception):
        pass

    async def before_provider(kind, payload, **scope):
        assert kind == "research"
        captured.append(deepcopy((payload, scope)))
        raise CapturedBeforeProvider

    service.model_call = before_provider
    with pytest.raises(CapturedBeforeProvider):
        await service._request_research(value, [])
    annotated = deepcopy(value)
    annotated["research_scope"] = project_research_scope(value)
    annotated["intent_plan"] = annotated["research_scope"]["intent_plan"]
    with pytest.raises(CapturedBeforeProvider):
        await service._request_research(annotated, [])
    assert captured[0] == captured[1]


COMMA_REQUEST = ("Chị có Trà sen Tây Hồ (THỬ NGHIỆM), khối lượng tịnh 100 g, mã TS-QA-R23, bao bì hộp giấy. "
    "Chị muốn xuất khẩu sang Mỹ, cần đăng ký FDA, thông báo trước lô hàng, nhãn và ba việc đầu tiên.")


def test_comma_request_explicit_keeps_every_requested_research_topic():
    assert set(explicit_requested_outcomes(COMMA_REQUEST, "US")) == {"registration", "label", "prior_notice"}


def test_comma_request_allowlist_already_contains_the_three_real_topics():
    assert set(allowed_intake_outcomes(COMMA_REQUEST, "US")) == {"registration", "label", "prior_notice", "clarification"}


def test_comma_request_validated_model_topics_are_not_demoted_or_removed():
    raw = {"scope": "us_food", "outcomes": [
        {"id": "registration", "question_quote": "đăng ký FDA"},
        {"id": "label", "question_quote": "nhãn"},
        {"id": "prior_notice", "question_quote": "thông báo trước lô hàng"}],
        "product_name": None, "product_quote": None, "ambiguities": []}
    parsed = validate_intake({"data": raw}, COMMA_REQUEST, "US")
    intent, _ = interpret_validated_intake(parsed, COMMA_REQUEST, "US")
    assert {item.id for item in intent.outcomes} == {"registration", "label", "prior_notice"}
    assert intent.requested_action_count == 3
    assert parsed.model_dump() == raw


def test_comma_request_plan_keeps_requested_origin_instead_of_hiding_under_supporting():
    plan = compile_dialogue_plan(interpret(COMMA_REQUEST), COMMA_REQUEST)
    requested = {item["id"] for item in plan["requirements"] if item["origin"] == "requested"}
    assert requested == {"facility_registration", "food_label", "prior_notice"}


@pytest.mark.parametrize("question,market,expected", [
    ("Chị cần tìm hiểu đăng ký FDA, nhãn tiếng Anh và prior notice.", "US", {"registration", "label", "prior_notice"}),
    ("Tôi hỏi nhãn, đăng ký FDA, prior notice.", "US", {"registration", "label", "prior_notice"}),
    ("Chị cần nghiên cứu chứng nhận, nhãn, thông báo trước.", "US", {"certification", "label", "prior_notice"}),
    ("Tôi chỉ hỏi nhãn, prior notice.", "US", {"label", "prior_notice"}),
    ("Chỉ cần nhãn, chứng nhận cho sản phẩm.", "US", {"label", "certification"}),
    ("Chị cần tìm hiểu thông báo nhập khẩu, nhãn tiếng Nhật.", "JP", {"registration", "label"}),
    ("Chị cần tìm hiểu điều kiện nhập khẩu, nhãn tiếng Đức.", "DE", {"registration", "label"}),
    ("Chị hỏi đăng ký FDA, không hỏi nhãn, prior notice.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA, bao bì là hộp giấy, nhãn.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA. Nhãn, prior notice.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA; nhãn, prior notice.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA, mã TS01, nhãn.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA, nhãn 100 g, prior notice.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA, nhãn đã xong, prior notice.", "US", {"registration"}),
    ("Chị hỏi đăng ký FDA, nhãn hiện tại là tiếng Anh, prior notice.", "US", {"registration"}),
    ("Chị đã đăng ký FDA, đã chuẩn bị nhãn, ai nộp prior notice?", "US", {"prior_notice"}),
    ("Chị hỏi đăng ký FDA nhưng không hỏi nhãn và thông báo trước.", "US", {"registration"}),
    ("Chị không hỏi nhãn mà cần tìm hiểu đăng ký FDA, thông báo trước.", "US", {"registration", "prior_notice"}),
])
def test_comma_request_operator_inheritance_has_bounded_role_and_sentence_scope(question, market, expected):
    assert set(explicit_requested_outcomes(question, market)) == expected


def test_negative_comma_request_list_is_not_resurrected_by_broad_supporting_requirements():
    question = "Chị muốn bán trà sang Mỹ, cần ba việc đầu tiên. Chị không hỏi đăng ký FDA, nhãn, thông báo trước."
    plan = compile_dialogue_plan(interpret(question), question)
    assert {"facility_registration", "food_label", "prior_notice"} <= set(plan["intent"]["exclusions"])
    assert {item["id"] for item in plan["requirements"]}.isdisjoint({"facility_registration", "food_label", "prior_notice"})


def test_negative_comma_request_list_is_not_allowed_as_model_research_candidates():
    question = "Chị không hỏi đăng ký FDA, nhãn, thông báo trước."
    assert allowed_intake_outcomes(question, "US") == ["clarification"]


@pytest.mark.parametrize("question,expected", [
    ("Chị có Trà Sen Tây Hồ, hộp 100 g, mã TS01; gửi 500 hộp sang New York thì có phải đăng ký cơ sở với FDA không, nhãn hộp cần ghi những gì và ba việc đầu tiên nên làm?", {"registration", "label"}),
    ("Có phải đăng ký FDA không, nhãn hộp cần ghi những gì?", {"registration", "label"}),
    ("Nhan hop can ghi nhung gi?", {"label"}),
    ("Nhãn cần những nội dung gì, nhưng không hỏi thông báo trước.", {"label"}),
    ("Chị không hỏi nhãn và thông báo trước, nhưng cần đăng ký FDA.", {"registration"}),
    ("Chị đã chuẩn bị nhãn, nhưng giờ cần đăng ký FDA.", {"registration"}),
    ("Chi khong hoi nhan, nhung can dang ky FDA.", {"registration"}),
    ("Nhãn có cần ghi lượng tịnh không, prior notice?", {"label", "prior_notice"}),
    ("Chị không hỏi đăng ký FDA, nhãn, thông báo trước.", set()),
    ("Bao bì hiện tại là hộp giấy. Cơ sở có phải đăng ký FDA không?", {"registration"}),
    ("Chị đã chuẩn bị nhãn, nhưng hãy hỏi đăng ký FDA.", {"registration"}),
    ("Nhãn đã xong; chị chỉ hỏi ai nộp thông báo trước và khi nào?", {"prior_notice"}),
])
def test_quantifier_contrast_and_interrogative_polarity_preserve_requested_topics(question, expected):
    assert set(explicit_requested_outcomes(question, "US")) == expected


@pytest.mark.parametrize("outcomes,prepared", [(("label",), 1), (("registration", "label"), 2)])
def test_requested_three_actions_reports_honest_shortfall_without_extra_topics(outcomes, prepared):
    question = "Chị chỉ hỏi đăng ký FDA và nhãn; hãy nêu ba việc đầu tiên."
    value = export(question, outcomes=outcomes)
    value["intent"]["requested_action_count"] = 3
    before = deepcopy(value)
    plan = compile_export_plan(value)
    assert len(plan["first_actions"]) == prepared
    assert {item["id"] for item in plan["requirements"]} == {"food_label" if oid == "label" else "facility_registration" for oid in outcomes}
    assert plan["delivery"]["schema_version"] == "plan-delivery/1"
    assert plan["delivery"]["status"] == "partial"
    assert (plan["delivery"]["requested_count"], plan["delivery"]["prepared_count"], plan["delivery"]["missing_count"]) == (3, prepared, 3-prepared)
    assert plan["completeness"]["action_count_gap"]["missing_count"] == 3-prepared
    assert plan["completeness"]["status"] == "partial"
    assert "chuẩn bị" in plan["delivery"]["reason_vi"]
    assert value == before


def test_three_action_count_ready_is_not_legal_or_research_completeness():
    plan = compile_export_plan(export("Chị muốn bán sang Mỹ, cần ba việc đầu tiên."))
    assert plan["delivery"]["status"] == "ready"
    assert plan["delivery"]["prepared_count"] == len(plan["first_actions"]) == 3
    assert plan["delivery"]["missing_count"] == 0
    assert plan["completeness"]["action_count_gap"] is None
    assert plan["completeness"]["status"] == "partial"
    assert all(item["preparation_only"] for item in plan["first_actions"])
    assert all(item["applicability"] == "not_assessed" for item in plan["requirements"])


def test_action_count_not_requested_has_no_shortfall():
    plan = compile_export_plan(export("Chị chỉ hỏi nhãn.", outcomes=("label",)))
    assert plan["delivery"]["requested_count"] is None
    assert plan["delivery"]["prepared_count"] == 1
    assert plan["delivery"]["status"] == "not_requested"
    assert plan["delivery"]["missing_count"] == 0
    assert plan["completeness"]["action_count_gap"] is None


def test_action_delivery_cannot_claim_more_preparation_than_the_real_cards():
    plan = compile_export_plan(export("Chị chỉ hỏi nhãn và ba việc đầu tiên.", outcomes=("label",)))
    plan["delivery"].update(prepared_count=3, missing_count=0, status="ready")
    with pytest.raises(ValidationError):
        PlanProjection.model_validate(plan)
