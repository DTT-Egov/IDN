"""Lifecycle metadata and explicit human corrections, with synthetic facts only."""
import copy

import pytest

from nmate.conversations.models import FactsInput, MessageInput
from nmate.models import AppError
from test_conversations import P, actual_case, confirm, fact, finish_report, link, output, send, setup


async def test_product_name_preserves_uniquely_grounded_user_casing(tmp_path):
    service, _, body = setup(tmp_path, output([fact("product.name", "trà sen", "Trà Sen")]))
    body = await send(service, body, "THỬ NGHIỆM: Trà Sen hộp 100 g")
    assert body["pending_proposal"]["product"]["name"] == "Trà Sen"


async def test_explicit_human_same_product_name_and_sku_correction_keeps_old_report_immutable(tmp_path):
    service, fake, body = setup(tmp_path, output([fact("product.name", "Trà Sen", "Trà Sen"), fact("product.sku", "TEST-A", "TEST-A")]))
    body = confirm(service, await send(service, body, "THỬ NGHIỆM: Trà Sen TEST-A"))
    case = actual_case(service, body)
    run, artifact = finish_report(service, case)
    body = link(service, body, case, run_id=run["run_id"], artifact_id=artifact["artifact_id"])
    before = service.store.business.get_artifact(P, artifact["artifact_id"])
    args = FactsInput(expected_version=body["version"], idempotency_key="TEST-IDENTITY-CORRECTION",
        changes=[{"field": "product.name", "value": "Trà Sen Tây Hồ"}, {"field": "product.sku", "value": "TEST-A-CORRECTED"}]).model_dump()
    with pytest.raises(AppError) as error:
        service.store.edit_facts(P, body["conversation_id"], args)
    assert error.value.code == "PRODUCT_CONTEXT_CHANGE"
    body = service.store.edit_facts(P, body["conversation_id"], {**args, "same_product_correction": True})
    assert body["draft"]["product"]["name"] == "Trà Sen"
    assert body["pending_proposal"]["product"]["sku"] == "TEST-A-CORRECTED"
    assert body["pending_proposal"]["field_sources"]["product.name"]["source_quote"] == "Trà Sen Tây Hồ"
    body = confirm(service, body, "TEST-CONFIRM-CORRECTION")
    assert body["draft"]["product"]["name"] == "Trà Sen Tây Hồ"
    assert body["draft"]["product"]["sku"] == "TEST-A-CORRECTED"
    assert service.store.business.get_artifact(P, artifact["artifact_id"]) == before
    assert service.store.business.get_run(P, run["run_id"])["snapshot"]["product"]["sku"] == "TEST-A"
    assert len(fake.calls) == 1
    with pytest.raises(Exception):
        MessageInput(message="Sửa sản phẩm", expected_version=body["version"], idempotency_key="TEST-AI-CANNOT-ACK", same_product_correction=True)


def test_processing_and_interruption_are_list_metadata_without_transcript_or_retry(tmp_path):
    service, fake, body = setup(tmp_path)
    args = MessageInput(message="THỬ NGHIỆM", expected_version=1, idempotency_key="TEST-INTERRUPT-TURN").model_dump()
    token, _ = service.store.reserve(P, body["conversation_id"], args)
    assert token
    summary = service.store.list(P)[0]
    assert summary["activity_state"]["status"] == "sending" and not summary["activity_state"]["can_send"]
    assert "messages" not in summary and "draft" not in summary
    service.store.interrupt_processing()
    detail = service.store.get(P, body["conversation_id"])
    assert detail["version"] == 1 and detail["messages"] == []
    assert detail["activity_state"]["status"] == "interrupted" and detail["activity_state"]["can_send"]
    with pytest.raises(AppError) as error:
        service.store.reserve(P, body["conversation_id"], args)
    assert error.value.code == "TURN_INTERRUPTED" and not fake.calls


async def test_research_state_latest_case_run_and_duplicate_start_guard_survive_missing_final_link(tmp_path):
    service, fake, body = setup(tmp_path, output([fact("product.name", "Trà", "Trà")]))
    body = confirm(service, await send(service, body, "THỬ NGHIỆM Trà"))
    case = actual_case(service, body)
    body = link(service, body, case)  # Case linked before MCP, run response/link may be lost.
    args = {"case_id": case["case_id"], "expected_case_version": 1, "idempotency_key": "TEST-STATE-START", "question": "THỬ"}
    store = service.store.business
    run = store.start(P, args, mode="evidence_only", max_active=5, max_daily=30)
    state = service.store.get(P, body["conversation_id"])["activity_state"]
    assert state["status"] == "research_queued" and state["run_id"] == run["run_id"] and not state["can_send"]
    with pytest.raises(AppError) as error:
        store.start(P, {**args, "idempotency_key": "TEST-DUPLICATE-START"}, mode="evidence_only", max_active=5, max_daily=30)
    assert error.value.code == "RESEARCH_IN_PROGRESS"
    with pytest.raises(AppError) as error:
        await send(service, body, "Gửi thêm", "TEST-DURING-RESEARCH")
    assert error.value.code == "RESEARCH_IN_PROGRESS" and len(fake.calls) == 1
    claim = store.claim("TEST-WORKER")
    assert claim["run_id"] == run["run_id"]
    assert service.store.list(P)[0]["activity_state"]["status"] == "researching"
    store.finish(run["run_id"], "TEST-WORKER", error={"code": "MODEL_OUTPUT_INVALID", "message": "THỬ thất bại"})
    state = service.store.get(P, body["conversation_id"])["activity_state"]
    assert state["status"] == "research_failed" and state["error_code"] == "MODEL_OUTPUT_INVALID" and state["can_send"]
    assert store.list_cases(P)[0]["activity_state"]["status"] == "research_failed"
    assert store.start(P, args, mode="evidence_only", max_active=5, max_daily=30)["run_id"] == run["run_id"]
    new = store.start(P, {**args, "idempotency_key": "TEST-EXPLICIT-NEW-START"}, mode="evidence_only", max_active=5, max_daily=30)
    original_snapshot = copy.deepcopy(store.get_run(P, new["run_id"])["snapshot"])
    store.interrupt_incomplete_runs()
    assert store.claim("TEST-RESTARTED-WORKER") is None
    interrupted = store.get_run(P, new["run_id"])
    assert interrupted["status"] == "failed" and interrupted["stage"] == "interrupted"
    assert interrupted["snapshot"] == original_snapshot
    assert service.store.list(P)[0]["activity_state"]["status"] == "interrupted"
