"""Registered enterprise is explicitly bound to one SSOT profile, never by name."""
import json
import pytest

from nmate.main.app import make_main_app
from nmate.v03.core import CoreError


@pytest.fixture
def scope(tmp_path):
    app = make_main_app(tmp_path / 'enterprise.sqlite', refresh_sources=False, gateway_enabled=False)
    repo = app.state.repo
    accounts = app.state.accounts
    owner = accounts.register('v17-profile-owner', 'Synthetic-local-12345', 'Cơ sở thử Trà Sen')
    other = accounts.register('v17-profile-other', 'Synthetic-local-12345', 'Cơ sở khác')
    core = app.state.core_extension
    return repo, core, owner, other


def service(scope):
    return scope[1].enterprise_profiles


def command(scope, op='open-once', existing=None):
    _, _, owner, _ = scope
    return service(scope).open(owner['account_id'], owner['enterprise_id'], op, existing_entity_id=existing)


def dump(repo):
    with repo.connection() as db:
        return '\n'.join(db.iterdump())


@pytest.mark.parametrize('classification', ['restricted', 'finance', 'unclassified'])
def test_metadata_name_uses_complete_field_read_policy(scope, classification):
    repo, integration, owner, peer = scope
    result = command(scope)
    entity_id = result['entity_id']
    secret = 'PRIVATE NAME MUST NOT LEAK'
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], entity_id,
                              [{'field': 'name', 'value': secret}], 0, 'private-name')
    core = integration.core
    core.add_member(owner['account_id'], owner['enterprise_id'], peer['username'])
    core.grant_resource(owner['account_id'], owner['enterprise_id'], entity_id, peer['account_id'],
                        capabilities=['read'], field_keys=['*'])
    with repo.connection(write=True) as db:
        if classification == 'unclassified':
            db.execute("DELETE FROM core_v1_field_definitions WHERE field_key='name'")
        else:
            db.execute("UPDATE core_v1_field_definitions SET sensitivity=? WHERE field_key='name'", (classification,))
    before = dump(repo)
    assert not core.can_read(peer['account_id'], owner['enterprise_id'], entity_id, 'name')
    descriptor = service(scope).get(peer['account_id'], owner['enterprise_id'])
    entities = core.list_entities(peer['account_id'], owner['enterprise_id'])
    assert secret not in json.dumps([descriptor, entities])
    assert descriptor['entity']['name'] == 'Hồ sơ được chia sẻ'
    assert 'name_validation' not in descriptor['entity']
    assert dump(repo) == before
    core.grant_resource(owner['account_id'], owner['enterprise_id'], entity_id, peer['account_id'],
                        capabilities=['read', 'read_finance'], field_keys=['name'])
    assert core.can_read(peer['account_id'], owner['enterprise_id'], entity_id, 'name')
    assert service(scope).get(peer['account_id'], owner['enterprise_id'])['entity']['name'] == secret


def test_empty_registered_enterprise_read_is_pure_and_has_explicit_setup_path(scope):
    repo, core, owner, _ = scope
    before = dump(repo)
    profile = service(scope).get(owner['account_id'], owner['enterprise_id'])
    assert profile['schema_version'] == 'registered-enterprise-profile/1'
    assert profile['state'] == 'not_initialized' and profile['can_initialize'] is True
    assert profile['enterprise_id'] == owner['enterprise_id'] and profile['entity_id'] is None
    assert profile['display_name'] == owner['enterprise_name']
    assert profile['candidates'] == []
    assert dump(repo) == before


def test_explicit_open_creates_empty_profile_and_binding_atomically_without_business_facts(scope):
    repo, core, owner, _ = scope
    result = command(scope)
    assert result['state'] == 'ready' and result['entity']['entity_type'] == 'enterprise'
    assert result['entity']['facts'] == [] and result['entity']['version'] == 0
    assert result['entity']['name'] == owner['enterprise_name']
    assert result['command_receipt']['created'] is True
    assert service(scope).get(owner['account_id'], owner['enterprise_id'])['entity_id'] == result['entity_id']
    assert [e['id'] for e in core.core.list_entities(owner['account_id'], owner['enterprise_id'])] == [result['entity_id']]
    with repo.connection() as db:
        assert db.execute('SELECT count(*) FROM v03_enterprises WHERE id=?', (owner['enterprise_id'],)).fetchone()[0] == 1
        assert db.execute('SELECT count(*) FROM v03_fact_assertions').fetchone()[0] == 0


def test_exact_replay_and_second_open_do_not_create_duplicates(scope):
    first = command(scope)
    before = dump(scope[0])
    again = command(scope)
    assert again['command_receipt'] == first['command_receipt']
    assert again['entity_id'] == first['entity_id']
    assert dump(scope[0]) == before
    assert command(scope, 'another-open')['entity_id'] == first['entity_id']


def test_existing_profile_requires_explicit_id_and_preserves_all_facts(scope):
    repo, _, owner, _ = scope
    existing = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Tên hồ sơ đã có')
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], existing['id'],
        [{'field': 'trading_name', 'value': 'Tên giao dịch đã xác nhận'}], 0, 'seed-name')
    profile = service(scope).get(owner['account_id'], owner['enterprise_id'])
    assert profile['entity_id'] is None
    assert [e['id'] for e in profile['candidates']] == [existing['id']]
    result = command(scope, existing=existing['id'])
    assert result['entity_id'] == existing['id'] and result['command_receipt']['created'] is False
    assert result['entity']['values']['trading_name'] == 'Tên giao dịch đã xác nhận'
    with repo.connection() as db:
        assert db.execute('SELECT count(*) FROM v03_entities WHERE enterprise_id=?', (owner['enterprise_id'],)).fetchone()[0] == 1


def test_existing_unbound_profile_cannot_be_silently_duplicated(scope):
    repo, _, owner, _ = scope
    repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở đã có')
    before = dump(repo)
    with pytest.raises(CoreError) as exc:
        command(scope)
    assert exc.value.code == 'enterprise_profile_selection_required'
    assert dump(repo) == before


@pytest.mark.parametrize('target', ['product', 'cross_enterprise'])
def test_link_rejects_wrong_scope_without_side_effect(scope, target):
    repo, _, owner, other = scope
    who = other if target == 'cross_enterprise' else owner
    entity = repo.create_entity(who['account_id'], who['enterprise_id'],
                                'enterprise' if target == 'cross_enterprise' else 'product', 'Hồ sơ sai đích')
    before = dump(repo)
    with pytest.raises(CoreError):
        command(scope, existing=entity['id'])
    assert dump(repo) == before


def test_explicit_link_is_not_a_rebind_command(scope):
    first = command(scope)
    repo, _, owner, _ = scope
    another = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở thứ hai')
    before = dump(repo)
    with pytest.raises(CoreError) as exc:
        command(scope, 'do-not-rebind', another['id'])
    assert exc.value.code == 'enterprise_profile_already_linked'
    assert dump(repo) == before
    with pytest.raises(CoreError) as exc:
        command(scope, existing=another['id'])
    assert exc.value.code == 'idempotency_conflict'
    assert first['entity_id'] != another['id']


def test_replay_checks_current_read(scope):
    first = command(scope)
    repo, _, owner, _ = scope
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (first['entity_id'],))
    before = dump(repo)
    with pytest.raises(CoreError) as exc:
        command(scope)
    assert exc.value.status_code == 403
    assert dump(repo) == before


def test_replay_needs_current_read_not_new_owner_write(scope):
    first = command(scope)
    repo, core, owner, _ = scope
    core.core.grant_resource(owner['account_id'], owner['enterprise_id'], first['entity_id'],
                            owner['account_id'], capabilities=['read'], field_keys=['name'])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?",
                   (owner['account_id'], owner['enterprise_id']))
    before = dump(repo)
    assert command(scope)['command_receipt'] == first['command_receipt']
    assert dump(repo) == before
    with pytest.raises(CoreError) as exc:
        command(scope, 'staff-new-command-denied')
    assert exc.value.status_code == 403


def test_archived_binding_remains_readable_for_replay_but_not_new_open(scope):
    first = command(scope)
    repo, _, owner, _ = scope
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_entity_lifecycle VALUES(?,?,'archived',1,'2026-10-26T00:00:00+00:00',?,'fixture')",
                   (first['entity_id'], owner['enterprise_id'], owner['account_id']))
    before = dump(repo)
    assert command(scope)['command_receipt'] == first['command_receipt']
    assert dump(repo) == before
    with pytest.raises(CoreError) as exc:
        command(scope, 'archived-new-open-denied')
    assert exc.value.code == 'entity_archived'


def test_membership_does_not_share_the_registered_enterprise_profile(scope):
    result = command(scope)
    repo, core, owner, other = scope
    core.core.add_member(owner['account_id'], owner['enterprise_id'], other['username'])
    before = dump(repo)
    view = service(scope).get(other['account_id'], owner['enterprise_id'])
    assert view['state'] == 'unavailable' and view['entity'] is None
    assert view['candidates'] == [] and view['can_initialize'] is False
    assert result['entity_id'] not in json.dumps(view)
    with pytest.raises(CoreError):
        service(scope).open(other['account_id'], owner['enterprise_id'], 'staff-no-write')
    assert dump(repo) == before


def test_binding_and_entity_roll_back_together_on_receipt_failure(scope, monkeypatch):
    repo = scope[0]
    before = dump(repo)
    def fail(*args, **kwargs):
        raise RuntimeError('injected receipt failure')
    monkeypatch.setattr(repo, '_save_operation', fail)
    with pytest.raises(RuntimeError, match='injected receipt'):
        command(scope)
    assert dump(repo) == before
