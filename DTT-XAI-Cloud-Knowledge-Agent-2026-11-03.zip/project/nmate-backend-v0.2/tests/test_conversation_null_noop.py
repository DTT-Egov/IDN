"""Unknown-to-unknown is a no-op, not a grounded fact or permission to clear one.

All model responses are fixed local fixtures. No provider, live data or secrets.
"""
import copy
from typing import get_args

import pytest
from pydantic import ValidationError

from nmate.conversations.models import ConversationDraft, IntakeSynthesis
from nmate.conversations.service import _proposal
from nmate.models import AppError, CaseFactField

from test_conversations import P, actual_case, business_state, confirm, fact, output, send, setup


OPTIONAL_FACT_FIELDS = [field for field in get_args(CaseFactField) if field != "question"]
QUESTION = "THỬ NGHIỆM: Trà Sen cần nghiên cứu FDA và nhãn như thế nào?"


def synthesis(patch):
    return IntakeSynthesis.model_validate(output(patch))


def known_question_body():
    return {"draft": ConversationDraft(question=QUESTION).model_dump(mode="json"), "pending_proposal": None}


@pytest.mark.parametrize("field", OPTIONAL_FACT_FIELDS)
def test_optional_null_to_null_without_unknown_word_is_no_proposal_or_fact(field):
    body = known_question_body()
    before = copy.deepcopy(body)
    proposed = _proposal(body, synthesis([fact(field, None, "Trà Sen")]), "Trà Sen", "TEST-NOOP")
    assert proposed is None
    assert body == before


@pytest.mark.parametrize("pending", [False, True])
@pytest.mark.parametrize("certainty", ["provided", "estimate"])
def test_noop_keeps_existing_unknown_provenance_certainty_and_uncertainty(pending, certainty):
    body = known_question_body()
    draft = body["draft"]
    draft["product"]["name"] = "Trà Sen"
    draft["shipment"]["gross_weight_kg"] = 65
    draft["field_sources"]["product.certifications"] = {
        "message_id": "TEST-OLD-SOURCE", "source_quote": "chưa rõ chứng nhận",
        "certainty": "estimate", "confirmed": True,
    }
    draft["uncertain_fields"] = ["product.certifications", "shipment.gross_weight_kg"]
    if pending:
        body["pending_proposal"] = copy.deepcopy(draft)
    before = copy.deepcopy(body)
    proposed = _proposal(body, synthesis([fact("product.certifications", None, "Trà Sen", certainty)]),
                         "Trà Sen", "TEST-NEW-SOURCE")
    assert proposed == (before["pending_proposal"] if pending else None)
    assert body == before


async def test_tea_intake_ignores_unknown_list_without_losing_grounded_facts_or_downstream_unknowns(tmp_path):
    # Synthetic reconstruction of the failed branch, not a claimed copy of the unpersisted response.
    message = ("THỬ NGHIỆM KIỂM THỬ: Trà Sen Tây Hồ, SKU TEST-TEA-NULL, trà khô và hoa sen; "
               "hộp 100 g, 500 hộp, 10 thùng. Quy cách đóng gói đang được rà lại; cả bì khoảng 65 kg. "
               "Incoterm, IOR, FSVP và chứng nhận đang đợi đối tác phản hồi. "
               "Cần nghiên cứu FDA và nhãn thế nào?")
    patch = [fact("product.name", "Trà Sen Tây Hồ", "Trà Sen Tây Hồ"),
             fact("product.sku", "TEST-TEA-NULL", "TEST-TEA-NULL"),
             fact("product.ingredients", ["trà khô", "hoa sen"], "trà khô và hoa sen"),
             fact("product.packaging", "hộp 100 g", "hộp 100 g"),
             fact("shipment.quantity_units", 500, "500 hộp"),
             fact("shipment.carton_count", 10, "10 thùng"),
             fact("shipment.gross_weight_kg", 65, "cả bì khoảng 65 kg", "estimate"),
             fact("product.certifications", None, "chứng nhận đang đợi đối tác phản hồi"),
             fact("shipment.incoterm", None, "Incoterm"),
             fact("shipment.importer_of_record", None, "IOR"),
             fact("shipment.fsvp_importer", None, "FSVP")]
    service, fake, body = setup(tmp_path, output(patch))
    original_draft = copy.deepcopy(body["draft"])
    body = await send(service, body, message)
    proposal = body["pending_proposal"]
    assert body["draft"] == original_draft
    assert proposal["product"]["name"] == "Trà Sen Tây Hồ"
    assert proposal["product"]["sku"] == "TEST-TEA-NULL"
    assert proposal["product"]["packaging"] == "hộp 100 g"
    assert proposal["product"]["ingredients"] == ["trà khô", "hoa sen"]
    assert proposal["shipment"]["quantity_units"] == 500
    assert proposal["shipment"]["carton_count"] == 10
    assert proposal["shipment"]["gross_weight_kg"] == 65
    assert proposal["question"] == message
    ignored = ("product.certifications", "shipment.incoterm", "shipment.importer_of_record", "shipment.fsvp_importer")
    for field in ignored:
        section, key = field.split(".")
        assert proposal[section][key] is None
        assert field not in proposal["field_sources"]
        assert field not in proposal["uncertain_fields"]
    assert proposal["uncertain_fields"] == ["shipment.gross_weight_kg"]
    assert not any(source["confirmed"] for source in proposal["field_sources"].values())
    assert len(fake.calls) == 1 and service.store.business.list_runs(P) == []
    body = confirm(service, body)
    case = actual_case(service, body)
    run = service.store.business.start(P, {"case_id": case["case_id"], "expected_case_version": case["version"],
        "idempotency_key": "TEST-UNKNOWN-SNAPSHOT", "question": body["draft"]["question"]},
        mode="evidence_only", max_active=5, max_daily=30)
    assert run["snapshot"]["product"]["certifications"] is None
    assert run["snapshot"]["shipment"]["incoterm"] is None
    assert run["snapshot"]["shipment"]["importer_of_record"] is None
    assert run["snapshot"]["shipment"]["fsvp_importer"] is None
    assert all(source["confirmed"] for source in case["research_context"]["field_sources"].values())
    assert set(ignored).isdisjoint(case["research_context"]["field_sources"])
    assert run["snapshot"]["research_context"]["uncertain_fields"] == ["shipment.gross_weight_kg"]
    assert len(fake.calls) == 1  # Creating an evidence-only queued snapshot does not invoke a model.


def test_unknown_certification_noop_does_not_change_an_unrelated_known_field():
    body = known_question_body()
    body["draft"]["product"]["packaging"] = "100 g/hộp"
    before = copy.deepcopy(body)
    assert _proposal(body, synthesis([fact("product.certifications", None, "100 g/hộp")]),
                     "100 g/hộp", "TEST-NOOP-OTHER-FIELD") is None
    assert body == before


@pytest.mark.parametrize("patch", [
    [fact("product.certifications", None, "Câu trích dẫn không có trong tin mới")],
    [fact("product.certifications", None, "Trà Sen"), fact("product.certifications", None, "Trà Sen")],
])
def test_noop_cannot_bypass_quote_membership_or_duplicate_guard(patch):
    body = known_question_body()
    before = copy.deepcopy(body)
    with pytest.raises(AppError) as error:
        _proposal(body, synthesis(patch), "Trà Sen", "TEST-NOOP-BAD-QUOTE")
    assert error.value.code == "MODEL_OUTPUT_INVALID"
    assert body == before


@pytest.mark.parametrize("confirmed", [False, True])
@pytest.mark.parametrize(("message", "quote"), [
    ("chưa biết kích thước", "chưa biết kích thước"),
    ("chứng nhận đang được đối tác rà soát", "chứng nhận đang được đối tác rà soát"),
    ("Trà Sen", "chưa có chứng nhận"),
])
async def test_known_certifications_cannot_be_cleared_from_unrelated_ambiguous_or_fabricated_quote(tmp_path, confirmed, message, quote):
    service, _, body = setup(tmp_path,
        output([fact("product.name", "Trà Sen", "Trà Sen"), fact("product.certifications", ["TEST-GIẤY"], "TEST-GIẤY")]),
        output([fact("product.certifications", None, quote)]))
    body = await send(service, body, "Trà Sen có TEST-GIẤY")
    if confirmed:
        body = confirm(service, body)
    before = copy.deepcopy(body)
    with pytest.raises(AppError) as error:
        await send(service, body, message, "TEST-CERT-CLEAR-BLOCKED")
    assert error.value.code == "MODEL_OUTPUT_INVALID"
    assert business_state(service.store.get(P, body["conversation_id"])) == business_state(before)
    effective = before["pending_proposal"] or before["draft"]
    assert effective["product"]["certifications"] == ["TEST-GIẤY"]


@pytest.mark.parametrize("confirmed", [False, True])
async def test_explicit_supported_certification_clear_stays_pending_until_confirm(tmp_path, confirmed):
    service, _, body = setup(tmp_path,
        output([fact("product.name", "Trà Sen", "Trà Sen"), fact("product.certifications", ["TEST-GIẤY"], "TEST-GIẤY")]),
        output([fact("product.certifications", None, "xóa chứng nhận TEST-GIẤY, chưa có hồ sơ xác minh")]))
    body = await send(service, body, "Trà Sen có TEST-GIẤY")
    if confirmed:
        body = confirm(service, body)
    old_draft = copy.deepcopy(body["draft"])
    body = await send(service, body, "xóa chứng nhận TEST-GIẤY, chưa có hồ sơ xác minh", "TEST-CERT-CLEAR-EXPLICIT")
    assert body["draft"] == old_draft
    assert body["pending_proposal"]["product"]["certifications"] is None
    source = body["pending_proposal"]["field_sources"]["product.certifications"]
    assert source["source_quote"] == "xóa chứng nhận TEST-GIẤY, chưa có hồ sơ xác minh"
    assert source["confirmed"] is False
    body = confirm(service, body, "TEST-CERT-CLEAR-CONFIRM")
    assert body["draft"]["product"]["certifications"] is None
    assert body["draft"]["field_sources"]["product.certifications"]["confirmed"] is True


@pytest.mark.parametrize("explicit", [False, True])
def test_empty_list_is_not_unknown_to_unknown_noop(explicit):
    body = known_question_body()
    quote = "chưa có chứng nhận" if explicit else "Trà Sen"
    response = synthesis([fact("product.certifications", [], quote)])
    if explicit:
        proposed = _proposal(body, response, quote, "TEST-EMPTY-LIST")
        assert proposed["product"]["certifications"] == []
        assert proposed["field_sources"]["product.certifications"]["source_quote"] == quote
    else:
        with pytest.raises(AppError) as error:
            _proposal(body, response, quote, "TEST-EMPTY-LIST")
        assert error.value.code == "MODEL_OUTPUT_INVALID"


async def test_noop_mixed_with_malicious_nonnull_fact_rejects_whole_turn_atomically(tmp_path):
    service, fake, body = setup(tmp_path, output([
        fact("product.name", "Trà Sen", "Trà Sen"),
        fact("product.certifications", None, "Trà Sen"),
        fact("shipment.quantity_units", 500, "10 thùng")]))
    before = copy.deepcopy(body)
    with pytest.raises(AppError) as error:
        await send(service, body, "Trà Sen có 10 thùng.")
    assert error.value.code == "MODEL_OUTPUT_INVALID"
    assert error.value.fact_diagnostic["invalid_field"] == "shipment.quantity_units"
    assert business_state(service.store.get(P, body["conversation_id"])) == business_state(before)
    assert len(fake.calls) == 1


def test_null_noop_does_not_bypass_model_field_or_type_schema():
    with pytest.raises(ValidationError):
        synthesis([fact("product.admin_override", None, "Trà Sen")])
    with pytest.raises(ValidationError):
        synthesis([fact("question", None, "Trà Sen")])
    with pytest.raises(ValidationError):
        synthesis([fact("product.certifications", "chưa biết", "chưa biết")])


async def test_null_noop_does_not_bypass_legal_reply_guard(tmp_path):
    service, _, body = setup(tmp_path, output([fact("product.certifications", None, "Trà Sen")],
                                             reply="Trà Sen được miễn đăng ký FDA."))
    before = copy.deepcopy(body)
    with pytest.raises(AppError) as error:
        await send(service, body, "Trà Sen")
    assert error.value.code == "MODEL_OUTPUT_INVALID"
    assert business_state(service.store.get(P, body["conversation_id"])) == business_state(before)
