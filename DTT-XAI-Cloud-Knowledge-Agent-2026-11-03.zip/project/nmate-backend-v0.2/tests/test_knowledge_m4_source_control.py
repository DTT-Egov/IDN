"""DF-027/033/048: same-transaction causal bridge, no legacy backfill."""
from datetime import datetime,timedelta,timezone
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed,attest,review
from test_knowledge_m4_serving import serving,release,lookup
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError

@pytest.mark.parametrize('rewind',['snapshot','snapshot_and_gate','all_heads'])
def test_catalog_rewind_cannot_resurrect_release(serving,rewind):
    repo,_,s,author,_,_,user,_=serving;release(serving);ref=lookup(serving)[0]['wiki_revision_refs'][0]
    catalog=KnowledgeCatalog(repo)
    with repo.connection() as db:
        old=db.execute("SELECT current_snapshot_id FROM pol_sources WHERE id='KB-TEST-A'").fetchone()[0]
        gate=dict(db.execute("SELECT * FROM pol_source_gates WHERE source_id='KB-TEST-A'").fetchone())
        head=dict(db.execute("SELECT * FROM ks_source_control_heads WHERE source_id='KB-TEST-A'").fetchone())
    text='SYNTHETIC new source exception';catalog.add_snapshot(author,'KB-TEST-A',text.encode(),text)
    catalog.record_source_check(author,'KB-TEST-A',result='verified_current',current_until=(datetime.now(timezone.utc)+timedelta(hours=4)).isoformat(),rationale='Synthetic check')
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_sources SET current_snapshot_id=? WHERE id='KB-TEST-A'",(old,))
        if rewind!='snapshot':
            keys=('availability','checked_at','current_until','reason_code','observation_id','version')
            db.execute("UPDATE pol_source_gates SET availability=?,checked_at=?,current_until=?,reason_code=?,observation_id=?,version=? WHERE source_id='KB-TEST-A'",tuple(gate[k] for k in keys))
        if rewind=='all_heads':db.execute("UPDATE ks_source_control_heads SET decision_id=?,sequence=? WHERE source_id='KB-TEST-A'",(head['decision_id'],head['sequence']))
    with pytest.raises(CoreError):lookup(serving)
    assert s.read_reference(user['account_id'],ref,mode='history')['body']
    # Neither a new check nor a new acquisition silently blesses corruption.
    with repo.connection() as db:before=list(db.iterdump())
    with pytest.raises(CoreError):catalog.record_source_check(author,'KB-TEST-A',result='unavailable',rationale='Must not repair')
    with repo.connection() as db:assert list(db.iterdump())==before

@pytest.mark.parametrize('action',['check','snapshot'])
def test_catalog_and_control_event_are_atomic(serving,monkeypatch,action):
    from nmate.knowledge_v1 import source_control
    repo,_,_,author,_,_,_,_=serving;release(serving);catalog=KnowledgeCatalog(repo)
    with repo.connection() as db:before=list(db.iterdump())
    def crash(*args):raise RuntimeError('Synthetic crash before causal decision')
    monkeypatch.setattr(source_control,'append_observation',crash)
    with pytest.raises(RuntimeError):
        if action=='check':catalog.record_source_check(author,'KB-TEST-A',result='unavailable',rationale='Synthetic crash')
        else:catalog.add_snapshot(author,'KB-TEST-A',b'New source','New source')
    with repo.connection() as db:assert list(db.iterdump())==before

def test_migrated_legacy_source_needs_new_explicit_observation_read_never_anchors(serving):
    repo,g,s,author,expert,page,_,payload=serving
    s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-legacy')
    attest((repo,g,author,expert,page))
    with repo.connection() as db:before=list(db.iterdump())
    for _ in range(3):
        view=g.workbench(expert,page['page_id'])
        assert 'upstream_source_control_unanchored' in view['blockers']
        assert lookup(serving)[0]['wiki_revision_refs']==[]
    with repo.connection() as db:assert list(db.iterdump())==before
    with pytest.raises(CoreError):review((repo,g,author,expert,page))

def test_repeated_success_check_keeps_semantic_review_manifest(serving):
    repo,g,_,author,_,page,_,_=serving;release(serving)
    prior=g.workbench(author,page['page_id'])['review_manifest_hash']
    with repo.connection() as db:first=dict(db.execute('SELECT * FROM ks_source_control_heads').fetchone())
    KnowledgeCatalog(repo).record_source_check(author,'KB-TEST-A',result='verified_current',
      current_until=(datetime.now(timezone.utc)+timedelta(hours=6)).isoformat(),rationale='Same bytes checked again')
    assert g.workbench(author,page['page_id'])['review_manifest_hash']==prior
    assert lookup(serving)[0]['wiki_revision_refs']
    with repo.connection() as db:
        head=dict(db.execute('SELECT * FROM ks_source_control_heads').fetchone())
        assert head['sequence']==first['sequence']+1 and head['decision_id']!=first['decision_id']
