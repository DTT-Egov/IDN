"""DF-015/024: a quoted field is data, not an instruction to redesign it.

These bounded local-intake tests do not use a model or confirm SSOT facts.
"""
import copy

import pytest

from nmate.v04.conversations import ConversationService
from nmate.v04.dialogue import SELECTED_TASK_HINT, business_plan, interpret, next_steps
from nmate.v04.intake import IntakeService
from test_v04_intake import workspace as shared_workspace


DECLARATION = ("THỬ NGHIỆM: Bột sen (THỬ NGHIỆM) khối lượng tịnh 200 g, "
               "mã BS-02, bao bì túi zip.")


@pytest.mark.parametrize("text", [
    DECLARATION,
    "Bao bì: túi zip.",
    "Bao bì là hộp giấy hai lớp.",
    "Chị đang đóng gói bằng túi zip.",
    "Thông tin bao bì hiện tại: hộp giấy.",
    "Chị cập nhật hồ sơ: bao bì túi zip, mã BS-02.",
    "Sản phẩm Bột sen có bao bì túi zip, lượng tịnh 200 g.",
    "Bao bì túi zip; chị chưa muốn cải thiện bao bì.",
    "Chị không cần thiết kế bao bì, chỉ ghi nhớ hồ sơ bao bì túi zip.",
    "Hồ sơ có nhãn sản phẩm tiếng Việt, bao bì túi zip.",
    "Bao bì cần ghi nhớ vào hồ sơ là túi zip.",
    "Chị đã kiểm tra bao bì: túi zip.",
])
@pytest.mark.parametrize("hint", [None, "profile_intake"])
def test_packaging_field_declaration_is_profile_data_not_improvement(text, hint):
    intent = interpret(text, task_hint=hint)
    assert intent["primary"] == "understand_business"
    assert intent["focus"] is None
    steps = next_steps({"intent": intent, "saved_context": {"entities": []}, "product": None})
    assert "cải thiện bảo quản" not in " ".join(steps)
    assert "nháp" in " ".join(steps)
    assert [step["id"] for step in business_plan(intent, {})] == ["profile_review"]


@pytest.mark.parametrize("text", [
    "Chị muốn cải thiện bao bì Bột sen.",
    "Cải thiện bao bì, đây là Excel doanh nghiệp.",
    "Tư vấn bao bì chống ẩm cho chị.",
    "Thiết kế hộp trà sen giúp chị.",
    "Chị cần đổi bao bì từ túi zip sang hộp giấy.",
    "Bao bì túi zip có phù hợp để giữ hương trà không?",
    "Bao bì nên thay thế nào để tránh ẩm?",
    "Chị nên đóng gói trà thế nào để đi xa?",
    "Chị có nên dùng túi zip làm bao bì?",
    "Loại bao bì nào giúp giữ hương tốt?",
    "Đóng gói bằng túi zip có bị ẩm không?",
    "Kiểm tra bao bì giúp chị.",
    "Góp ý giúp chị về bao bì trà sen.",
    "Chị cần nhận xét bao bì hiện tại.",
    "Chị muốn xem lại bao bì trước khi gửi hàng.",
    "Nhãn sản phẩm cần thay đổi không?",
    "Bao bì cần chống ẩm tốt hơn.",
    "Bao bì: túi zip; chị muốn cải thiện bảo quản bao bì.",
    "Chị chỉ muốn tư vấn bao bì, chưa cần xuất khẩu.",
])
def test_real_packaging_action_or_question_wins_profile_task_hint(text):
    intent = interpret(text, task_hint="profile_intake")
    assert intent["primary"] == "improve_packaging"


@pytest.mark.parametrize("text,focus", [
    ("Bao bì: túi zip. Chị muốn quản lý tồn kho bằng Excel.", "inventory_accuracy"),
    ("Bao bì: túi zip. Chị muốn tổng hợp bán hàng theo tháng.", "sales_reporting"),
    ("Bao bì túi zip; chị có nên nhập thêm hàng? Tồn kho còn 120 hộp.", "restocking_planning"),
])
def test_packaging_data_cannot_steal_an_explicit_operation_need(text, focus):
    intent = interpret(text, task_hint="profile_intake")
    assert intent["primary"] == "digitize_operations"
    assert intent["focus"] == focus


@pytest.mark.parametrize("text", [
    "Chị muốn nhận sản phẩm vào ngày mai.",
    "Chị cần nhận sản phẩm từ nhà cung cấp.",
    "Chị nhận sản phẩm rồi ghi vào hồ sơ.",
])
def test_receiving_a_product_is_not_a_label_request(text):
    assert interpret(text, task_hint="profile_intake")["primary"] == "understand_business"


@pytest.mark.parametrize("text,topics", [
    ("Bao bì túi zip; chị hỏi FDA cho Bột sen đi Mỹ.", ["facility_registration"]),
    ("Chị cần nhãn thực phẩm và prior notice cho trà đi Mỹ.", ["food_label", "prior_notice"]),
    ("Chị muốn cải thiện bao bì và hỏi đăng ký FDA, nhãn, prior notice khi xuất khẩu đi Mỹ.",
     ["facility_registration", "food_label", "prior_notice"]),
])
def test_export_questions_keep_all_requested_regulatory_topics(text, topics):
    intent = interpret(text, task_hint="profile_intake")
    assert intent["primary"] == "export_readiness"
    assert intent["market_codes"] == ["US"]
    assert intent["export_question_topics"] == topics


@pytest.fixture
def workspace(tmp_path):
    return shared_workspace.__wrapped__(tmp_path)


def test_declaration_reload_then_requested_improvement_keep_unconfirmed_draft(workspace):
    repo, intake, owner, _ = workspace
    a, e = owner["account_id"], owner["enterprise_id"]
    token = SELECTED_TASK_HINT.set("profile_intake")
    try:
        result = ConversationService(intake).send(a, e, DECLARATION, [], "closure-packaging-declaration")
        item = result["intake"]
        assert item["intent"]["primary"] == "understand_business"
        assert {candidate["field"] for candidate in item["candidates"]} == {
            "name", "net_quantity", "product_code", "packaging"}
        candidates = copy.deepcopy(item["candidates"])
        assert repo.get_context(a, e)["fact_refs"] == []
        reloaded = ConversationService(IntakeService(repo)).get(a, e, result["id"])
        assert reloaded["intake"]["intent"] == item["intent"]
        assert reloaded["intake"]["candidates"] == candidates
        assert reloaded["intake"]["model_calls"] == 0
        followup = ConversationService(IntakeService(repo)).send(
            a, e, "Chị muốn cải thiện bao bì chống ẩm.", [],
            "closure-packaging-improvement", conversation_id=result["id"])
        assert followup["intake"]["intent"]["primary"] == "improve_packaging"
        assert followup["intake"]["id"] == item["id"]
        assert followup["intake"]["candidates"] == candidates
        assert repo.get_context(a, e)["fact_refs"] == []
        assert followup["intake"]["model_calls"] == 0
    finally:
        SELECTED_TASK_HINT.reset(token)
