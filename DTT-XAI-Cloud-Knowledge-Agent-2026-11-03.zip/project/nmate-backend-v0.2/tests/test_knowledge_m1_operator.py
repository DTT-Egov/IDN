"""M1 target readiness and operator chain, distinct from active V17 runtime."""
from contextlib import closing
import json
from pathlib import Path
import sqlite3

import pytest

from nmate.main.app import make_main_app
from nmate.core_v1.runtime_schema import verify_runtime_database, read_runtime_contract
from nmate.core_v1.schema_lifecycle import apply_plan
from nmate.knowledge_v1.operator import install_on_clone, target_runtime_contract, open_runtime


def dump(path):
    with closing(sqlite3.connect(path)) as db:
        return list(db.iterdump())


def test_v17_clone_upgrade_target_readiness_and_readonly_startup(tmp_path):
    database = tmp_path / 'synthetic-main.sqlite'
    def denied(*args, **kwargs):
        pytest.fail('No provider permitted')
    make_main_app(database, request_fn=denied, gateway_request_fn=denied,
                  refresh_sources=True, gateway_enabled=False)
    with closing(sqlite3.connect(database)) as db:
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        before = {t: db.execute('SELECT * FROM "'+t+'"').fetchall() for t in tables}
    result = install_on_clone(database, backup_path=tmp_path / 'original.sqlite')
    target = target_runtime_contract()
    assert target['required_seeds'] == read_runtime_contract()['required_seeds']
    assert target['optional_objects'] == read_runtime_contract()['optional_objects']
    contract = tmp_path / 'target.json'
    contract.write_text(json.dumps(target), encoding='utf-8')
    assert verify_runtime_database(database, contract_path=contract)['ready']
    prior = dump(database)
    service = open_runtime(database, contract_path=contract)
    assert service.repo.managed_runtime
    assert dump(database) == prior
    with closing(sqlite3.connect(database)) as db:
        assert {t: db.execute('SELECT * FROM "'+t+'"').fetchall() for t in tables} == before
    source = Path(__file__).resolve().parents[1] / 'src'
    assert apply_plan(database, result['plan'], source_root=source,
                      backup_path=tmp_path / 'unused.sqlite') == result['receipt']
    assert not (tmp_path / 'unused.sqlite').exists()


def test_target_rejects_unknown_object_before_service_opens(tmp_path):
    database = tmp_path / 'synthetic-main.sqlite'
    make_main_app(database, refresh_sources=True, gateway_enabled=False)
    install_on_clone(database, backup_path=tmp_path / 'original.sqlite')
    contract = tmp_path / 'target.json'
    contract.write_text(json.dumps(target_runtime_contract()), encoding='utf-8')
    with closing(sqlite3.connect(database)) as db:
        db.execute('CREATE TABLE unexpected_object (id TEXT)')
    prior = dump(database)
    with pytest.raises(RuntimeError):
        open_runtime(database, contract_path=contract)
    assert dump(database) == prior
