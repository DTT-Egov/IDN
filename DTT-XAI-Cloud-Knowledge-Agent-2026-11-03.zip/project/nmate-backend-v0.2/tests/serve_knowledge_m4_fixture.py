"""Full main UI, synthetic isolated corpus/accounts, forbidden provider/network.

Only this fixture grants synthetic expert roles. Never opens MAIN or .env.
"""
from pathlib import Path
import argparse,json
from nmate.main.app import make_main_app
from nmate.v03.core import now_iso
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.knowledge_v1.operator import install_on_clone
from nmate.knowledge_v1.serving import PublishedKnowledge
from nmate.knowledge_v1.host import attach_workbench
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed
from test_knowledge_m4_serving import serving,release

def build(path,port=8034,web_dir=None):
    path=Path(path);path.mkdir(parents=True,exist_ok=True)
    database=path/'synthetic-main.sqlite'
    if database.exists():raise ValueError('Use a fresh namespace; never overwrite history.')
    def forbidden(*args,**kwargs):raise AssertionError('M4 fixture forbids AI/network')
    app=make_main_app(database,port=port,web_dir=Path(web_dir) if web_dir else None,request_fn=forbidden,gateway_request_fn=forbidden,
                      cookie_namespace='nmate_m4_qa',refresh_sources=True,gateway_enabled=False)
    repo=app.state.repo;accounts=app.state.accounts;catalog=KnowledgeCatalog(repo)
    # Constructor installs the full known baseline; actual background fetch is disabled below.
    app.state.missions.source_refresher=None
    author=accounts.register('kb_author','synthetic-password-123','THỬ NGHIỆM DTT')
    expert=accounts.register('kb_other','synthetic-password-456','THỬ NGHIỆM Chuyên gia')
    actor=author['account_id']
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)",(actor,'TEST-ONLY',now_iso()))
    catalog.register_source(actor,'KB-TEST-A','THỬ NGHIỆM nguồn đào tạo','THỬ NGHIỆM','https://hanoi.gov.vn/test-only/kb-a')
    raw='THỬ NGHIỆM nguồn công khai, không phải chính sách có thật.'
    snapshot=catalog.add_snapshot(actor,'KB-TEST-A',raw.encode(),raw)
    install_on_clone(database,backup_path=path/'before-m1.sqlite')
    from nmate.knowledge_v1.service import KnowledgeService
    initial=KnowledgeService(repo)
    initial.set_source_rights(actor,'KB-TEST-A',expected_version=0,allow_read=True,allow_export=True,reason='Synthetic only',operation_id='rights-1')
    with repo.connection() as db:chunk=db.execute('SELECT id FROM pol_chunks WHERE snapshot_id=?',(snapshot['snapshot_id'],)).fetchone()[0]
    ref=initial.evidence_ref(actor,chunk,raw)
    first=(repo,initial,actor,expert['account_id'],ref)
    environment=serving.__wrapped__(governed.__wrapped__(pipe.__wrapped__(first,path),path),path)
    release(environment)
    # Reconstruct the whole host after schema preparation so the same production
    # composition mounts its authenticated workbench before the MCP catch-all.
    from nmate.core_v1.runtime_schema import managed_runtime
    with managed_runtime():
        app=make_main_app(database,port=port,web_dir=Path(web_dir) if web_dir else None,request_fn=forbidden,
              gateway_request_fn=forbidden,cookie_namespace='nmate_m4_qa',refresh_sources=True,gateway_enabled=False)
    app.state.missions.source_refresher=None
    # Background scheduler has no external fetch capability in this fixture.
    async def no_source_jobs():return await app.state.policy.execute_next()
    app.state.core_extension.execute_next=no_source_jobs
    from test_knowledge_m4_policy_flow import company
    customer=environment[6]
    company(repo,app.state.core_extension.core,customer,'THỬ NGHIỆM Trà Sen A')
    other=accounts.register('test-other-shop','Synthetic-password-abc','THỬ NGHIỆM Tiệm B')
    company(repo,app.state.core_extension.core,other,'THỬ NGHIỆM Hồ sơ B riêng')
    (path/'fixture-public.json').write_text(json.dumps(dict(no_ai=True,synthetic=True,port=port,
      owner_username='test-customer',other_username='test-other-shop',expert_username='kb_other',page_id=environment[5]['page_id']),ensure_ascii=False,indent=2),encoding='utf-8')
    return app

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--directory',required=True);parser.add_argument('--port',type=int,default=8034);parser.add_argument('--web-dir');args=parser.parse_args()
    import uvicorn
    uvicorn.run(build(args.directory,args.port,args.web_dir),host='127.0.0.1',port=args.port,log_level='warning')
