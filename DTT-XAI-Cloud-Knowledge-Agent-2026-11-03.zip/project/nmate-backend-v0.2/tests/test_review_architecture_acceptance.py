"""Independent behavioral acceptance for the review aggregate.

These tests drive public services, restart repositories and inspect the actual
SQL facts.  Expected pending sets come from the owner's actions, not from the
implementation's state transition helpers.  No model fixture or provider is
needed for these local commands.
"""
from __future__ import annotations

import copy
import base64
import hashlib
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from itertools import combinations
import json
import socket
import threading
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED

import pytest

from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.v04.intake import IntakeService
from nmate.v04.extraction import XLSX


TEXT = ("Cơ sở Trà sen Quảng An của chị đang bán khoảng 300 hộp trà mỗi tháng. "
        "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSB01, thành phần trà xanh và hoa sen. "
        "Hãy bóc tách đúng tên cơ sở và tên sản phẩm thành nháp riêng; chị chưa đồng ý sửa hồ sơ đã có.")
EXPECTED = {"trading_name": "Trà sen Quảng An", "name": "Trà sen Tây Hồ ướp bông",
            "product_code": "TSB01", "net_quantity": "100 g", "packaging": "hộp",
            "ingredients": "trà xanh và hoa sen"}


@pytest.fixture(autouse=True)
def prohibit_network(monkeypatch):
    calls = []

    def denied(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("Review commands must not invoke a model or network")

    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)
    yield calls
    assert calls == []


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "review-acceptance.sqlite3")
    service = IntakeService(repo)
    accounts = LocalAccounts(repo)
    owner = accounts.register("review-owner", "Only-local-test-password", "Trà Sen QA")
    other = accounts.register("other-owner", "Only-local-test-password", "Doanh nghiệp khác")
    return repo, service, owner, other


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


def prepare(service, owner, suffix="one", text=TEXT):
    return service.prepare(*scope(owner), text, [], "acceptance-prepare-" + suffix)


def by_field(item):
    return {c["field"]: c for c in item["candidates"]}


def confirm(service, owner, item, fields, operation, **extra):
    candidates = by_field(item)
    ids = [candidates[field]["id"] for field in fields]
    review = item["review"]
    return service.confirm(*scope(owner), item["id"], ids,
                           copy.deepcopy(item["expected_entity_versions"]), operation,
                           expected_review_revision=review["revision"],
                           expected_proposal_hashes={key: review["proposal_hashes"][key] for key in ids},
                           **extra)


def reload(service, repo, owner, intake_id):
    # A different connection/service instance is an independent browser reload.
    restarted = IntakeService(CoreRepository(repo.db_path))
    return restarted, restarted.get(*scope(owner), intake_id)


def pending_fields(item):
    pending_ids = set(item["review"]["pending_candidate_ids"])
    return {c["field"] for c in item["candidates"] if c["id"] in pending_ids}


def data_snapshot(repo):
    def sql_value(value):
        if isinstance(value, bytes):
            return {"blob_sha256": hashlib.sha256(value).hexdigest(), "size": len(value)}
        raise TypeError("Unsupported SQL snapshot value")
    with repo.connection() as db:
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        return {table: sorted(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, default=sql_value)
                              for row in db.execute('SELECT * FROM "' + table + '"'))
                for table in tables}


def facts(repo, owner):
    context = repo.get_context(*scope(owner))
    return context, {e["id"]: e["values"] for e in context["entities"]}


def test_six_fields_remain_confirmable_across_four_batches_and_restart(setup):
    repo, service, owner, _other = setup
    item = prepare(service, owner)
    assert {c["field"]: c["value"] for c in item["candidates"]} == EXPECTED
    assert pending_fields(item) == set(EXPECTED)
    name_id = by_field(item)["name"]["id"]
    ids = {field: c["id"] for field, c in by_field(item).items()}
    for index, (selected, remaining) in enumerate([
        (["trading_name"], {"name", "product_code", "net_quantity", "packaging", "ingredients"}),
        (["name", "product_code"], {"net_quantity", "packaging", "ingredients"}),
        (["net_quantity"], {"packaging", "ingredients"}),
        (["packaging", "ingredients"], set()),
    ]):
        item = confirm(service, owner, item, selected, f"acceptance-batch-{index}")
        assert pending_fields(item) == remaining
        assert {field: c["id"] for field, c in by_field(item).items()} == ids
        service, item = reload(service, repo, owner, item["id"])
        assert pending_fields(item) == remaining
        assert item["review"]["lifecycle"] == ("settled" if not remaining else "partially_committed")
    context, _ = facts(repo, owner)
    products = [e for e in context["entities"] if e["entity_type"] == "product"]
    assert len(products) == 1
    assert products[0]["values"] == {k: v for k, v in EXPECTED.items() if k != "trading_name"}
    assert by_field(item)["name"]["id"] == name_id
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_fact_assertions").fetchone()[0] == 6
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []


@pytest.mark.parametrize("batches", [
    [["name"], ["ingredients"], ["trading_name"], ["packaging", "product_code", "net_quantity"]],
    [["trading_name", "name", "product_code", "net_quantity", "packaging", "ingredients"]],
    [["name", "packaging"], ["product_code", "ingredients"], ["trading_name", "net_quantity"]],
])
def test_independent_partition_orders_have_identical_final_ssot(setup, batches):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    remaining = set(EXPECTED)
    for index, batch in enumerate(batches):
        item = confirm(service, owner, item, batch, f"partition-{index}")
        remaining.difference_update(batch)
        assert pending_fields(item) == remaining
    context, _ = facts(repo, owner)
    combined = {k: v for entity in context["entities"] for k, v in entity["values"].items()}
    assert combined == EXPECTED
    assert len(context["entities"]) == 2


def test_sku_without_name_rolls_back_and_draft_survives_reload(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm(service, owner, item, ["product_code"], "sku-prerequisite")
    assert error.value.code == "product_name_required"
    assert data_snapshot(repo) == before
    service, item = reload(service, repo, owner, item["id"])
    assert pending_fields(item) == set(EXPECTED)
    assert facts(repo, owner)[0]["entities"] == []


def test_receipt_is_historical_while_current_view_keeps_advancing(setup):
    repo, service, owner, _ = setup
    original = prepare(service, owner)
    first = confirm(service, owner, original, ["trading_name"], "receipt-company")
    receipt1 = copy.deepcopy(first["latest_confirmation_receipt"])
    second = confirm(service, owner, first, ["name", "product_code"], "receipt-name-code")
    before = data_snapshot(repo)
    replay = confirm(service, owner, original, ["trading_name"], "receipt-company")
    assert replay["confirmation_receipt"] == receipt1
    assert replay["latest_confirmation_receipt"] == second["latest_confirmation_receipt"]
    assert replay["review"]["revision"] == second["review"]["revision"]
    assert pending_fields(replay) == {"net_quantity", "packaging", "ingredients"}
    lookup = service.get_review_receipt(*scope(owner), original["id"], "receipt-company")
    assert lookup["receipt"] == receipt1
    assert pending_fields(lookup["current_view"]) == {"net_quantity", "packaging", "ingredients"}
    assert data_snapshot(repo) == before


def test_same_operation_with_changed_owner_edits_is_rejected(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    candidate = by_field(item)["trading_name"]
    confirm(service, owner, item, ["trading_name"], "same-key-edits", edits={candidate["id"]: "Trà Sen An Nhiên"})
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm(service, owner, item, ["trading_name"], "same-key-edits", edits={candidate["id"]: "Trà Sen Khác"})
    assert "operation" in error.value.code or "idempot" in error.value.code
    assert data_snapshot(repo) == before


def test_typed_edits_keep_observation_and_effective_receipt_distinct(setup):
    repo, service, owner, _ = setup
    original = prepare(service, owner)
    c = by_field(original)["trading_name"]
    saved = confirm(service, owner, original, ["trading_name"], "owner-amended", edits={c["id"]: "Trà Sen An Nhiên"})
    company = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "enterprise")
    assert company["values"]["trading_name"] == "Trà Sen An Nhiên"
    fact = next(f for f in company["facts"] if f["field"] == "trading_name")
    assert fact["source"]["original_value"] == "Trà sen Quảng An"
    assert fact["source"]["owner_edited"] is True
    receipt = json.dumps(saved["latest_confirmation_receipt"], ensure_ascii=False, sort_keys=True)
    # An effective proposal/hash must describe the committed amendment.
    assert "Trà Sen An Nhiên" in receipt or "effective" in receipt
    assert by_field(original)["trading_name"]["value"] == "Trà sen Quảng An"
    service, refreshed = reload(service, repo, owner, saved["id"])
    assert refreshed["latest_confirmation_receipt"] == saved["latest_confirmation_receipt"]


def test_two_tabs_cannot_confirm_a_stale_workspace(setup):
    repo, service, owner, _ = setup
    tab_a = prepare(service, owner)
    tab_b = copy.deepcopy(tab_a)
    updated = confirm(service, owner, tab_a, ["trading_name"], "tab-a-company")
    before = data_snapshot(repo)
    second_service = IntakeService(CoreRepository(repo.db_path))
    with pytest.raises(CoreError) as error:
        confirm(second_service, owner, tab_b, ["name", "product_code"], "tab-b-stale")
    assert error.value.status_code == 409
    assert "revision" in error.value.code or "workspace" in error.value.code
    assert data_snapshot(repo) == before
    assert pending_fields(updated) == {"name", "product_code", "net_quantity", "packaging", "ingredients"}


def test_wrong_proposal_hash_is_atomic_and_does_not_create_entities(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    altered = copy.deepcopy(item)
    name_id = by_field(item)["name"]["id"]
    altered["review"]["proposal_hashes"][name_id] = "0" * 64
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm(service, owner, altered, ["name", "product_code"], "tampered-hash")
    assert error.value.status_code == 409
    assert data_snapshot(repo) == before


def test_cross_profile_cannot_get_confirm_or_replay_receipts(setup):
    repo, service, owner, other = setup
    item = prepare(service, owner)
    saved = confirm(service, owner, item, ["trading_name"], "private-receipt")
    before = data_snapshot(repo)
    for enterprise in (owner["enterprise_id"], other["enterprise_id"]):
        with pytest.raises(CoreError):
            service.get(other["account_id"], enterprise, item["id"])
        with pytest.raises(CoreError):
            service.get_review_receipt(other["account_id"], enterprise, item["id"], "private-receipt")
        intruder = {**other, "enterprise_id": enterprise}
        with pytest.raises(CoreError):
            confirm(service, intruder, saved, ["name"], "private-write")
    assert data_snapshot(repo) == before


def test_explicit_dismiss_is_terminal_but_unselected_fields_remain_pending(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    dismissed = by_field(item)["ingredients"]["id"]
    saved = service.dismiss_candidates(*scope(owner), item["id"], [dismissed], "dismiss-one",
        expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={dismissed: item["review"]["proposal_hashes"][dismissed]})
    assert pending_fields(saved) == set(EXPECTED) - {"ingredients"}
    service, saved = reload(service, repo, owner, item["id"])
    assert pending_fields(saved) == set(EXPECTED) - {"ingredients"}
    with pytest.raises(CoreError):
        confirm(service, owner, saved, ["ingredients"], "cannot-revive-dismissed")
    assert facts(repo, owner)[0]["entities"] == []


def test_get_list_and_receipt_queries_do_not_write_data(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    saved = confirm(service, owner, item, ["trading_name"], "read-only-proof")
    before = data_snapshot(repo)
    for _ in range(3):
        assert service.get(*scope(owner), item["id"])["id"] == item["id"]
        assert service.list(*scope(owner))[0]["id"] == item["id"]
        assert service.get_review_receipt(*scope(owner), item["id"], "read-only-proof")["receipt"] == saved["latest_confirmation_receipt"]
    assert data_snapshot(repo) == before


def test_failure_after_fact_application_rolls_back_whole_confirmation(setup, monkeypatch):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    before = data_snapshot(repo)
    apply = repo.propose_or_apply_facts

    def fail_after_write(*args, **kwargs):
        apply(*args, **kwargs)
        raise RuntimeError("acceptance fault after SQL fact application")

    monkeypatch.setattr(repo, "propose_or_apply_facts", fail_after_write)
    with pytest.raises(RuntimeError, match="acceptance fault"):
        confirm(service, owner, item, ["trading_name", "name", "product_code"], "atomic-fault")
    assert data_snapshot(repo) == before
    assert facts(repo, owner)[0]["entities"] == []
    assert pending_fields(service.get(*scope(owner), item["id"])) == set(EXPECTED)


def test_external_ssot_change_cannot_be_overwritten_by_remaining_draft(setup):
    repo, service, owner, _ = setup
    initial = prepare(service, owner)
    partial = confirm(service, owner, initial, ["name", "product_code"], "partial-before-external")
    product = next(e for e in partial["saved_context"]["entities"] if e["entity_type"] == "product")
    another_repo = CoreRepository(repo.db_path)
    another_repo.propose_or_apply_facts(*scope(owner), product["id"],
        [{"field": "net_quantity", "value": "120 g"}], product["version"], "external-product-change")
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm(service, owner, partial, ["net_quantity"], "stale-product-fact")
    assert error.value.status_code == 409
    assert data_snapshot(repo) == before
    current_product = next(e for e in facts(repo, owner)[0]["entities"] if e["id"] == product["id"])
    assert current_product["values"]["net_quantity"] == "120 g"


def workbook(rows):
    """Small literal workbook fixture: no formulas, macros or extra libraries."""
    values = [["Đối tượng", "Trường", "Giá trị", "Đơn vị"], *rows]
    xml_rows = []
    for number, cells in enumerate(values, 1):
        cells_xml = "".join(f'<c r="{chr(65 + index)}{number}" t="inlineStr"><is><t>{escape(value)}</t></is></c>'
                            for index, value in enumerate(cells))
        xml_rows.append(f'<row r="{number}">{cells_xml}</row>')
    stream = BytesIO()
    with ZipFile(stream, "w", ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        archive.writestr("xl/workbook.xml", '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Hồ sơ" sheetId="1" r:id="rId1"/></sheets></workbook>')
        archive.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        archive.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + "".join(xml_rows) + '</sheetData></worksheet>')
    return {"filename": "two-conflicting-values.xlsx", "media_type": XLSX,
            "data_base64": base64.b64encode(stream.getvalue()).decode("ascii")}


def test_conflicting_alternative_is_superseded_without_discarding_other_groups(setup):
    repo, service, owner, _ = setup
    item = service.prepare(*scope(owner), "Chị muốn cập nhật hồ sơ từ Excel", [workbook([
        ["Sản phẩm", "name", "Trà Sen hai nguồn", ""],
        ["Sản phẩm", "net_quantity", "100", "g"],
        ["Sản phẩm", "net_quantity", "120", "g"],
        ["Sản phẩm", "product_code", "TSC02", ""],
    ])], "group-conflict-prepare")
    name = next(c for c in item["candidates"] if c["field"] == "name")
    quantities = [c for c in item["candidates"] if c["field"] == "net_quantity"]
    winner = next(c for c in quantities if c["value"] == "100 g")
    loser = next(c for c in quantities if c["value"] == "120 g")
    selected = [name["id"], winner["id"]]
    saved = service.confirm(*scope(owner), item["id"], selected, item["expected_entity_versions"], "group-winner",
        conflict_choices={winner["id"]: "incoming"}, expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={key: item["review"]["proposal_hashes"][key] for key in selected})
    assert pending_fields(saved) == {"product_code"}
    assert next(c for c in saved["candidates"] if c["id"] == loser["id"])["decision_state"] == "superseded"
    service, saved = reload(service, repo, owner, saved["id"])
    assert pending_fields(saved) == {"product_code"}
    product = next(e for e in facts(repo, owner)[0]["entities"] if e["entity_type"] == "product")
    assert product["values"]["net_quantity"] == "100 g"
    completed = confirm(service, owner, saved, ["product_code"], "group-code-later")
    assert pending_fields(completed) == set()


def test_legacy_confirmed_flag_with_mismatched_assertion_is_archived_not_trusted(setup):
    repo, service, owner, _ = setup
    initial = prepare(service, owner)
    company = repo.create_entity(*scope(owner), "enterprise", "Trà Sen QA")
    candidate = copy.deepcopy(by_field(initial)["trading_name"])
    candidate["entity_id"] = company["id"]
    candidate["status"] = "confirmed"
    candidate["confirmed_value"] = "Trà sen Quảng An"
    legacy_id = "intake_legacy_wrong_assertion"
    repo.propose_or_apply_facts(*scope(owner), company["id"], [{"field": "trading_name", "value": "Tên thực tế khác",
        "source": {"intake_id": legacy_id, "candidate_id": candidate["id"], "owner_confirmed": True}}],
        company["version"], "legacy-source-wrong-value")
    payload = copy.deepcopy(initial)
    payload.update(id=legacy_id, status="confirmed", candidates=[candidate], product=None)
    payload.pop("review", None)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v04_intakes VALUES(?,?,?,?,?,?,?)", (legacy_id, owner["enterprise_id"], owner["account_id"],
            "confirmed", json_text(payload), now_iso(), now_iso()))
    before = facts(repo, owner)[1]
    service.migrate_reviews()
    migrated = service.get(*scope(owner), legacy_id)
    assert migrated["candidates"][0]["decision_state"] == "legacy_archived"
    assert facts(repo, owner)[1] == before


@pytest.mark.parametrize("chosen", [list(group) for length in (1, 2, 3)
    for group in combinations(("net_quantity", "packaging", "ingredients"), length)])
def test_every_subset_of_bound_product_fields_keeps_its_complement(setup, chosen):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    bound = confirm(service, owner, item, ["name", "product_code", "trading_name"], "bind-first")
    saved = confirm(service, owner, bound, chosen, "arbitrary-subset")
    expected = {"net_quantity", "packaging", "ingredients"} - set(chosen)
    assert pending_fields(saved) == expected
    service, saved = reload(service, repo, owner, item["id"])
    assert pending_fields(saved) == expected
    if expected:
        saved = confirm(service, owner, saved, sorted(expected), "complement-after-reload")
    assert pending_fields(saved) == set()
    context, _ = facts(repo, owner)
    assert {k: v for entity in context["entities"] for k, v in entity["values"].items()} == EXPECTED


def test_simultaneous_sql_connections_have_one_winner_and_one_revision_conflict(setup):
    repo, service, owner, _ = setup
    item = prepare(service, owner)
    barrier = threading.Barrier(2)

    def attempt(fields, operation):
        isolated_service = IntakeService(CoreRepository(repo.db_path))
        barrier.wait(timeout=10)
        try:
            return {"saved": confirm(isolated_service, owner, copy.deepcopy(item), fields, operation), "fields": fields}
        except CoreError as error:
            return {"error": error, "fields": fields}

    with ThreadPoolExecutor(max_workers=2) as executor:
        first = executor.submit(attempt, ["trading_name"], "simultaneous-company")
        second = executor.submit(attempt, ["name", "product_code"], "simultaneous-product")
        outcomes = [first.result(timeout=20), second.result(timeout=20)]
    successes = [r for r in outcomes if "saved" in r]
    failures = [r for r in outcomes if "error" in r]
    assert len(successes) == len(failures) == 1
    assert failures[0]["error"].status_code == 409
    final = service.get(*scope(owner), item["id"])
    assert pending_fields(final) == set(EXPECTED) - set(successes[0]["fields"])
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_review_command_receipts").fetchone()[0] == 1
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


@pytest.mark.parametrize("legacy_value,checked,archived", [
    ("Trà Sen Tây Hồ: tồn trên sổ", False, True),
    ("Trà Sen Tây Hồ", False, False),
    ("Trà Sen Tây Hồ: tồn trên sổ", True, False),
])
def test_migration_freezes_only_proven_owner_excluded_inventory_error(setup, monkeypatch, legacy_value, checked, archived):
    from nmate.core_v1.review_migration import migrate_review_architecture
    from nmate.v04.conversations import ConversationService
    import nmate.main.draft_projection as draft_projection

    repo, service, owner, _ = setup
    ConversationService(service)  # Creates the real conversation schema.
    text = "Chị kiểm kê Trà Sen Tây Hồ: tồn trên sổ 120 hộp, đếm thực tế 110 hộp. Chị nên đối chiếu gì trước?"
    original = prepare(service, owner, "inventory-source", text=text)
    legacy = copy.deepcopy(original)
    legacy_id = "intake_legacy_inventory_exclusion"
    legacy.update(id=legacy_id, status="awaiting_confirmation")
    legacy.pop("review", None)
    legacy.pop("product_binding", None)
    # A pre-upgrade observation is evidence, not a call to today's proposal
    # extractor. Pure inventory references no longer produce new name proposals;
    # that must not prevent testing or preserving the real historical record.
    offset = text.index(legacy_value)
    source = {"kind": "server_text_extract", "quote": legacy_value, "value_quote": legacy_value,
              "text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
              "start_offset": offset, "end_offset": offset + len(legacy_value),
              "review_state": "owner_confirmation_required"}
    candidate = {"id": "candidate_legacy_inventory_name", "entity_id": "new_product", "entity_type": "product",
                 "field": "name", "base_field": "name", "label_vi": "Tên sản phẩm", "value": legacy_value,
                 "value_type": "string", "unit": None, "period": None, "status": "candidate",
                 "confidence": "explicit_user_declaration_unverified", "source": source, "sources": [copy.deepcopy(source)]}
    legacy["candidates"] = [candidate]
    legacy["product"] = {"id": "new_product", "name": legacy_value, "version": 0}
    legacy["expected_entity_versions"]["new_product"] = 0
    conversation = {"id": "conversation_legacy_inventory", "intake_ids": [legacy_id],
        "active_intake_id": legacy_id, "status": legacy["status"],
        "messages": [{"role": "user", "intake_id": legacy_id, "text": text}],
        "drafts": {legacy_id: {"selected": {candidate["id"]: checked}, "edits": {}, "choices": {}}}}
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v04_intakes VALUES(?,?,?,?,?,?,?)", (legacy_id, owner["enterprise_id"], owner["account_id"],
            legacy["status"], json_text(legacy), now_iso(), now_iso()))
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (conversation["id"], owner["enterprise_id"],
            owner["account_id"], json_text(conversation), now_iso(), now_iso()))
    result = migrate_review_architecture(repo)
    migrated = service.get(*scope(owner), legacy_id)
    observed = next(c for c in migrated["candidates"] if c["id"] == candidate["id"])
    assert observed["decision_state"] == ("legacy_archived" if archived else "pending")
    assert (candidate["id"] not in migrated["review"]["pending_candidate_ids"]) is archived
    assert len(result["frozen_exclusions"]) == int(archived)
    if archived:
        def parser_must_not_run(*args, **kwargs):
            raise AssertionError("A frozen historical decision cannot be reevaluated by today's parser")
        monkeypatch.setattr(draft_projection, "extract_product_text", parser_must_not_run)
        before = data_snapshot(repo)
        rendered = draft_projection.project_excluded_legacy_draft({**conversation, "intake": migrated})
        assert rendered["intake"]["draft_projection"]["archived_count"] == 1
        assert rendered["intake"]["intent"]["working_answers"]["book_quantity"] == 120
        assert rendered["intake"]["intent"]["working_answers"]["physical_quantity"] == 110
        assert data_snapshot(repo) == before
    assert facts(repo, owner)[0]["entities"] == []
