"""New delivery context retains the existing financial/public-source boundary."""
import copy

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError
from test_legacy_model_gateway import payload, setup  # noqa: F401 -- isolated fixture, never paid


def test_delivery_count_and_supporting_public_reference_are_classified_without_dispatch(setup):
    repo, _owner, _other, _provider, _gateway, adapter, calls = setup
    catalog = DomainCatalog(repo)
    record = catalog.lookup_domain(["prior_notice"], market_code="US")["records"][0]
    value = payload(requested_action_count=3,
                    delivery_requirements={"action_count": 3, "needs_owner_and_deliverable": True},
                    supporting_requirements=[{"id": "prior_notice", "status": "reference_available"}],
                    supporting_reference_records=[record])
    result = adapter.compile_payload("research", value)["input"]
    assert result["requested_action_count"] == 3
    assert result["supporting_reference_records"][0]["excerpt"] == record["excerpt"]
    assert calls == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0


@pytest.mark.parametrize("count", [False, True, 0, 2, 4, "3", [], {"value": 3}])
def test_invalid_requested_count_is_rejected_before_any_reservation(setup, count):
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("research", payload(requested_action_count=count))
    assert error.value.code == "UNSUPPORTED_MODEL_CONTEXT" and setup[6] == []


def test_delivery_keys_cannot_widen_intake_capability(setup):
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("intake", payload(supporting_requirements=[]))
    assert error.value.code == "UNSUPPORTED_MODEL_CONTEXT" and setup[6] == []


def test_public_supporting_record_cannot_carry_private_or_forged_text(setup):
    catalog = DomainCatalog(setup[0])
    record = copy.deepcopy(catalog.lookup_domain(["prior_notice"], market_code="US")["records"][0])
    record["excerpt"] = "Doanh thu của cơ sở là 1200000000 VND"
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("research", payload(supporting_reference_records=[record]))
    assert error.value.code == "INVALID_PUBLIC_REFERENCE" and setup[6] == []


def test_supporting_metadata_does_not_bypass_financial_text_scanner(setup):
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("research", payload(supporting_requirements=[{
            "id": "prior_notice", "reason_vi": "Doanh thu cơ sở là 1200000000 VND"}]))
    assert error.value.code == "FINANCIAL_EGRESS_REQUIRED" and setup[6] == []
