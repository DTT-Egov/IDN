"""Only a US prior-notice request receives the supported research capability."""
import pytest

from nmate.v03.missions import make_plan
from nmate.v03.models import Intent, Outcome


@pytest.mark.parametrize("market", ["US", "DE", "JP", None])
def test_prior_notice_capability_is_market_bound(market):
    intent = Intent(scope="us_food" if market == "US" else "export_food" if market else "unsupported",
                    market_code=market, outcomes=[Outcome(id="prior_notice", title="Thông báo trước", question_part="Ai nộp thông báo trước?")])
    plan = make_plan(intent)
    if market == "US":
        assert plan.tasks[0].id == "prior_notice-research"
        assert plan.tasks[0].capability_id == "export_us.prior_notice"
    else:
        assert plan.tasks[0].capability_id == "coverage.explicit_gap"


def test_three_explicit_us_questions_keep_distinct_research_and_label_dependency():
    intent = Intent(scope="us_food", market_code="US", outcomes=[
        Outcome(id=oid, title=oid, question_part=question) for oid, question in (
            ("registration", "cơ sở có phải đăng ký FDA"),
            ("prior_notice", "ai nộp thông báo trước và khi nào"),
            ("label", "chuẩn bị khung nhãn tiếng Anh"),
        )])
    plan = make_plan(intent)
    assert {task.capability_id for task in plan.tasks} == {
        "export_us.facility_registration", "export_us.prior_notice", "export_us.food_label", "artifact.food_label_workbook",
    }
    assert next(task for task in plan.tasks if task.id == "label-workbook").depends_on == ["label-research"]
    assert {oid for task in plan.tasks for oid in task.outcome_ids} == {"registration", "prior_notice", "label"}
