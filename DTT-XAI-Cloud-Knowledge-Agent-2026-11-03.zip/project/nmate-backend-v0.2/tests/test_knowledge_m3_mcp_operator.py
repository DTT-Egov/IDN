"""M3 actual SDK + full managed migration, no paid calls or MAIN writes."""
from contextlib import closing
import json,sqlite3
import pytest
from mcp import Client
from nmate.v03.mcp import create_mcp,account_context
from nmate.core_v1.gateway import ModelGateway
from nmate.knowledge_v1.mcp_m3 import register_tools,NAMES
from test_knowledge_m3_governance import governed,attest,review
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb

@pytest.mark.asyncio
async def test_governance_actual_mcp_identity_and_no_model(governed):
    repo,g,author,reviewer,p=governed
    gateway=ModelGateway(repo,enabled=False)
    server=create_mcp(repo,None,extra_register=lambda server,call:register_tools(server,g,call,gateway),tool_allowlist=NAMES)
    token=account_context.set(reviewer)
    try:
        async with Client(server,mode='2026-07-28',cache=None) as client:
            names=await client.list_tools();assert {t.name for t in names.tools}==NAMES
            for t in names.tools:
                assert not {'actor','account_id','api_key','paid_consent','budget_grant_id'}&set(t.input_schema.get('properties',{}))
            result=await client.call_tool('knowledge_wiki_workbench',{'page_id':p['page_id']})
            assert result.structured_content['data']['candidate']['body']==p['body']
            assert result.structured_content['data']['governance']['publication_state']=='not_published'
    finally: account_context.reset(token)
    async with Client(server,mode='2026-07-28',cache=None) as client:
        result=await client.call_tool('knowledge_wiki_queue',{})
        assert result.is_error and result.structured_content['error']['code']=='UNAUTHORIZED'

def test_full_v17_m1_m2_m3_preserves_old_data_and_startup_is_readonly(tmp_path):
    from nmate.main.app import make_main_app
    from nmate.knowledge_v1.operator import install_on_clone
    from nmate.knowledge_v1.operator_m2 import install_m2_on_clone
    from nmate.knowledge_v1.operator_m3 import install_m3_on_clone,target_m3_contract,open_m3_runtime
    database=tmp_path/'whole.sqlite'
    def denied(*a,**kw): pytest.fail('No provider')
    make_main_app(database,request_fn=denied,gateway_request_fn=denied,refresh_sources=True,gateway_enabled=False)
    install_on_clone(database,backup_path=tmp_path/'m1.sqlite');install_m2_on_clone(database,backup_path=tmp_path/'m2.sqlite')
    with closing(sqlite3.connect(database)) as db:
        tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name!='core_schema_migration_receipts'")]
        before={t:db.execute('SELECT * FROM "'+t+'"').fetchall() for t in tables}
    install_m3_on_clone(database,backup_path=tmp_path/'m3.sqlite')
    contract=tmp_path/'contract.json';contract.write_text(json.dumps(target_m3_contract()),encoding='utf-8')
    with closing(sqlite3.connect(database)) as db: prior=list(db.iterdump())
    service=open_m3_runtime(database,contract_path=contract)
    ModelGateway(service.repo,enabled=False)
    with closing(sqlite3.connect(database)) as db:
        assert list(db.iterdump())==prior
        assert {t:db.execute('SELECT * FROM "'+t+'"').fetchall() for t in tables}==before
