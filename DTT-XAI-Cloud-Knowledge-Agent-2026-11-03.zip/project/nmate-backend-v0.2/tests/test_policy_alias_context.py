"""Read-only compatibility for owner-confirmed legal SSOT aliases; no paid IO."""
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.policy_v1 import PolicyService
from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.v03.core import CoreRepository
from test_ssot_field_scope import legacy_fact


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "policy-alias-fixtures.sqlite")
    owner = LocalAccounts(repo).register("alias-owner", "Password12345", "KIỂM THỬ — Trà Sen")
    core = CoreSSOTService(repo)
    service = PolicyService(repo, core=core)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)",
                   (owner["account_id"], "TEST-FIXTURE", now_iso()))
    company = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "KIỂM THỬ — Trà Sen")
    return repo, owner, core, service, company


def confirm(setup, facts, *, version=0, operation="alias-facts"):
    _, owner, core, _, company = setup
    proposal = core.propose_facts(owner["account_id"], owner["enterprise_id"], company["id"], facts,
        version, operation + "-proposal", source={"kind": "user_statement"})
    return core.confirm_facts(owner["account_id"], owner["enterprise_id"], proposal["proposal_id"], version,
        operation + "-confirm", proposal_hash=proposal["proposal_hash"])


def reviewed_canonical_rule(setup):
    _, owner, _, service, _ = setup
    catalog = service.catalog
    catalog.register_source(owner["account_id"], "ALIAS-TEST-SOURCE", "DỮ LIỆU KIỂM THỬ", "Cơ quan KIỂM THỬ",
                            "https://hanoi.gov.vn/test-fixture/aliases")
    text = "DỮ LIỆU KIỂM THỬ. Tư vấn chuyển đổi số. Điều kiện: Hà Nội, Công ty trách nhiệm hữu hạn, Chế biến trà."
    snapshot = catalog.add_snapshot(owner["account_id"], "ALIAS-TEST-SOURCE", text.encode(), text,
        complete_policy=True, effective_from="2026-01-01", effective_until="2030-01-01")
    catalog.record_source_check(owner["account_id"], "ALIAS-TEST-SOURCE", result="verified_current",
        current_until=(datetime.now(timezone.utc)+timedelta(days=1)).isoformat(), rationale="DỮ LIỆU KIỂM THỬ")
    with service.repo.connection() as db:
        chunk = dict(db.execute("SELECT * FROM pol_chunks WHERE snapshot_id=? LIMIT 1", (snapshot["snapshot_id"],)).fetchone())
    conditions = [{"id": field, "expression": {"field": field, "op": "eq", "value": value}}
                  for field, value in (("province", "Hà Nội"), ("enterprise_type", "Công ty trách nhiệm hữu hạn"), ("industry", "Chế biến trà"))]
    rule = catalog.propose_member(owner["account_id"], kind="rule", policy_id="ALIAS-TEST-POLICY", title_vi="DỮ LIỆU KIỂM THỬ",
        payload={"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]}, "conditions": conditions},
        evidence=[{"chunk_id": chunk["id"], "quote_original": text, "supports_id": condition["id"]} for condition in conditions],
        effective_from="2026-01-01", effective_until="2030-01-01")
    review = catalog.review_member(owner["account_id"], rule["member_id"], rule["content_hash"], approve=True, rationale="DỮ LIỆU KIỂM THỬ")
    catalog.publish_member(owner["account_id"], rule["member_id"], rule["content_hash"], review["review_event_id"])
    catalog.release_pack(owner["account_id"], "DỮ LIỆU KIỂM THỬ", [rule["member_id"]])


def alias_values():
    return [{"field": "legal_form", "value": "Công ty trách nhiệm hữu hạn"},
            {"field": "registration_province", "value": "Hà Nội"},
            {"field": "business_sector", "value": "Chế biến trà"}]


def prepare(setup, operation="prepare-alias"):
    _, owner, _, service, company = setup
    return service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp?",
        operation, entity_ids=[company["id"]])


def test_owner_confirmed_aliases_reused_for_canonical_rules_with_original_dependencies_and_no_write(setup):
    repo, _, _, service, company = setup
    confirm(setup, alias_values())
    reviewed_canonical_rule(setup)
    with repo.connection() as db:
        before = [dict(row) for row in db.execute("SELECT * FROM v03_current_facts ORDER BY field")]
    result = prepare(setup)
    eligibility = next(outcome for outcome in result["outcomes"] if outcome["id"] == "eligibility")
    assert eligibility["status"] == "answered" and not eligibility["missing_fields"]
    assert all(condition["state"] == "met" for condition in eligibility["condition_results"])
    candidates = service._analysis_candidates(result, service.catalog.retrieve(result["question"]), result["intent"])
    assert not candidates["ssot_questions"]
    assert service._company_profile(result["context"]) == {
        "entity_types": ["enterprise"], "registration_province": "VN-HN", "enterprise_type": "limited_company"}
    assert {"legal_form", "registration_province", "business_sector", "enterprise_type", "province", "industry"} <= set(result["context_fields"])
    for condition in eligibility["condition_results"]:
        refs = condition["fact_version_refs"]
        assert any(ref["assertion_id"] and ref["version"] == 1 for ref in refs)
        assert any(ref["assertion_id"] is None and ref["version"] == 0 for ref in refs)
        assert all(ref in result["context"]["fact_refs"] for ref in refs)
    with repo.connection() as db:
        assert [dict(row) for row in db.execute("SELECT * FROM v03_current_facts ORDER BY field")] == before
        fields = {row[0] for row in db.execute("SELECT field FROM v03_current_facts WHERE entity_id=?", (company["id"],))}
        assert fields == {"legal_form", "registration_province", "business_sector"}
        dependencies = {row[0] for row in db.execute("SELECT identity FROM pol_mission_dependencies WHERE mission_id=? AND kind='fact'", (result["id"],))}
        assert f"{company['id']}:registration_province" in dependencies and f"{company['id']}:province" in dependencies


def test_conflicting_canonical_and_alias_are_not_chosen_or_sent_as_known_profile(setup):
    confirm(setup, [*alias_values(), {"field": "province", "value": "Hải Phòng"}])
    reviewed_canonical_rule(setup)
    result = prepare(setup)
    eligibility = next(outcome for outcome in result["outcomes"] if outcome["id"] == "eligibility")
    assert eligibility["status"] == "needs_confirmation"
    assert next(condition for condition in eligibility["condition_results"] if condition["field"] == "province")["state"] == "conflict"
    assert setup[3]._company_profile(result["context"])["registration_province"] == "unknown"


def test_product_legal_aliases_do_not_establish_company_eligibility_or_profile(setup):
    repo, owner, _, service, _ = setup
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    with pytest.raises(CoreError) as blocked:
        repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"], alias_values(), 0, "product-aliases")
    assert blocked.value.code == "invalid_field_scope"
    # Legacy compatibility is exercised with a pre-registry DB fixture. The
    # normal public write is intentionally no longer allowed to create it.
    for fact in alias_values():
        legacy_fact(repo, owner, product["id"], fact["field"], fact["value"])
    reviewed_canonical_rule(setup)
    result = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp?",
        "product-legal", entity_ids=[product["id"]])
    assert service._company_profile(result["context"]) == {"entity_types": [], "registration_province": "unknown", "enterprise_type": "unknown"}
    eligibility = next(outcome for outcome in result["outcomes"] if outcome["id"] == "eligibility")
    assert eligibility["status"] == "needs_input"
    assert all(condition["state"] == "unknown" for condition in eligibility["condition_results"])


def test_alias_change_marks_saved_result_historical_and_keeps_original_context(setup):
    _, owner, _, service, _ = setup
    confirm(setup, alias_values())
    saved = prepare(setup)
    confirm(setup, [{"field": "registration_province", "value": "Hải Phòng"}], version=1, operation="alias-moved")
    viewed = service.get(owner["account_id"], owner["enterprise_id"], saved["id"])
    assert viewed["is_historical"]
    assert any("Dữ kiện doanh nghiệp" in text for text in viewed["current_warnings_vi"])
    assert viewed["context"] == saved["context"]


def test_unreadable_canonical_counterpart_keeps_shared_alias_unknown(setup):
    repo, owner, core, service, company = setup
    confirm(setup, alias_values())
    staff = LocalAccounts(repo).register("alias-staff", "Password12345", "Công ty khác")
    core.add_member(owner["account_id"], owner["enterprise_id"], "alias-staff")
    core.grant_resource(owner["account_id"], owner["enterprise_id"], company["id"], staff["account_id"], ["read"], ["legal_form", "registration_province", "business_sector"])
    result = service.prepare(staff["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp?",
        "staff-aliases", entity_ids=[company["id"]])
    profile = service._company_profile(result["context"])
    assert profile["enterprise_type"] == profile["registration_province"] == "unknown"
    assert all(item["reason_code"] == "ALIAS_SCOPE_NOT_FULLY_READABLE" for item in result["context"]["policy_alias_resolution"])


def test_alias_normalization_never_emits_free_text_or_financial_classification(setup):
    repo, _, _, service, _ = setup
    confirm(setup, [{"field": "legal_form", "value": "Công ty TNHH lãi ròng 987654321"},
                    {"field": "registration_province", "value": "Hà Nội"},
                    {"field": "business_sector", "value": "Số dư tài khoản 999999999"}])
    result = prepare(setup)
    profile = service._company_profile(result["context"])
    assert profile["enterprise_type"] == "unknown" and profile["registration_province"] == "VN-HN"
    assert "987654321" not in json.dumps(profile) and "999999999" not in json.dumps(profile)
    with repo.connection(write=True) as db:
        db.execute("INSERT OR REPLACE INTO core_v1_field_definitions VALUES('legal_form','finance','owner_required',1)")
        with pytest.raises(CoreError) as blocked:
            service._check_nonfinancial_context(db, result["context"])
        assert blocked.value.code == "finance_egress_required"


def test_legal_value_synonyms_are_not_guessed_for_rule_evaluation(setup):
    confirm(setup, [*alias_values(), {"field": "enterprise_type", "value": "Công ty TNHH"}])
    result = prepare(setup)
    assert setup[3]._company_profile(result["context"])["enterprise_type"] == "unknown"
    projection = next(item for item in result["context"]["policy_alias_resolution"] if item["canonical_field"] == "enterprise_type")
    assert projection["value_state"] == "conflicted" and not projection["ssot_write"]
    assert json_text(result["context"])  # audit projection remains serializable, private and non-authoritative.
