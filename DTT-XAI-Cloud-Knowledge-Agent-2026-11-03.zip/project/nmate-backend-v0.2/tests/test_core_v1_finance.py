"""D05: exact typed projections, independent authority and no raw egress."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from io import BytesIO
import sqlite3
from zipfile import ZIP_DEFLATED, ZipFile

import pytest

from nmate.core_v1.finance import FinanceService
import nmate.core_v1.finance as finance_module
from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository, now_iso


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "finance.sqlite")
    with repo.connection(write=True) as db:
        for actor in ("owner", "staff", "other"):
            db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES(?,?,?,?)",
                       (actor, actor, "test-no-login", now_iso()))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('enterprise','Trà Sen',?)", (now_iso(),))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('other-enterprise','Doanh nghiệp khác',?)", (now_iso(),))
        db.execute("INSERT INTO v03_memberships VALUES('owner','enterprise','owner',1)")
        db.execute("INSERT INTO v03_memberships VALUES('staff','enterprise','staff',1)")
        db.execute("INSERT INTO v03_memberships VALUES('other','other-enterprise','owner',1)")
    entity = repo.create_entity("owner", "enterprise", "enterprise", "Hồ sơ tài chính Trà Sen")
    core = CoreSSOTService(repo)
    service = FinanceService(repo, core)
    return repo, core, service, entity["id"]


def metric(code="revenue", value="1000000000.25"):
    return {"metric_code": code, "value": value, "unit": "person" if code == "employee_count" else "VND",
            "period_start": "2025-01-01", "period_end": "2026-01-01", "scope": "enterprise"}


def stage(setup, metrics=None, actor="owner", op="stage"):
    _, _, service, resource = setup
    return service.stage_metrics(actor, "enterprise", resource, metrics or [metric()], op)


def authority(setup, actor="owner"):
    _, core, _, resource = setup
    core.grant_resource("owner", "enterprise", resource, actor, ["read", "read_finance", "send_financial_metrics"])


def grant(setup, staged=None, actor="owner", op="grant", **extra):
    _, _, service, _ = setup
    staged = staged or stage(setup, actor=actor)
    return service.grant_egress(actor, "enterprise", staged["projection_id"], op, "policy-task", "hanoi_policy", "complex/1",
                               (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(), **extra)


def dispatch(setup, authorized, actor="owner", payload=None, **extra):
    _, _, service, _ = setup
    return service.verify_dispatch(actor, "enterprise", "model-op", "policy-task", "hanoi_policy", "complex/1",
                                   payload or authorized["payload"], [authorized["grant_id"]], **extra)


def workbook(value="100000000000000.99", formula=False):
    out = BytesIO()
    with ZipFile(out, "w", ZIP_DEFLATED) as archive:
        archive.writestr("xl/workbook.xml", '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Tài chính riêng" sheetId="1" r:id="rId1"/></sheets></workbook>')
        archive.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"/></Relationships>')
        def cell(ref, text):
            return f'<c r="{ref}" t="inlineStr"><is><t>{text}</t></is></c>'
        values = ''.join(cell(ref, text) for ref, text in [("A1", "Trường"), ("B1", "Giá trị"), ("C1", "Đơn vị"), ("D1", "Kỳ")])
        amount = '<c r="B2"><f>1+1</f><v>2</v></c>' if formula else cell("B2", value)
        second = cell("A2", "Doanh thu") + amount + cell("C2", "VND") + cell("D2", "2025")
        archive.writestr("xl/worksheets/sheet1.xml", '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row r="1">' + values + '</row><row r="2">' + second + '</row></sheetData></worksheet>')
    return out.getvalue()


def test_staging_never_confirms_ssot_or_sends_original(setup):
    repo, _, service, resource = setup
    staged = stage(setup)
    assert staged["original_sent"] is False and staged["model_called"] is False
    assert staged["ssot_confirmed"] is False
    assert staged["metrics"][0]["value_decimal"] == "1000000000.25"
    assert repo.get_entity("owner", "enterprise", resource)["facts"] == []
    preview = service.preview_metrics("owner", "enterprise", staged["projection_id"])
    assert preview["metrics"][0]["label_vi"] == "Doanh thu"
    assert "raw_document" not in str(preview)
    assert stage(setup) == staged


def test_owner_read_and_ssot_confirmation_do_not_authorize_egress(setup):
    _, _, service, _ = setup
    staged = stage(setup)
    with pytest.raises(CoreError) as error:
        grant(setup, staged)
    assert error.value.code == "financial_egress_authority_required"
    authority(setup)
    authorized = grant(setup, staged)
    assert dispatch(setup, authorized)["allowed"]
    assert service.verify_publication("owner", "enterprise", [authorized["grant_id"]])["allowed"]


def test_exact_values_period_unit_and_extraneous_fields_are_sealed(setup):
    authority(setup)
    authorized = grant(setup)
    for key, value in (("value_decimal", "999"), ("unit", "USD"), ("period_start", "2024-01-01"), ("raw_text", "Báo cáo đầy đủ")):
        altered = deepcopy(authorized["payload"])
        altered["financial_metrics"][0][key] = value
        with pytest.raises(CoreError):
            dispatch(setup, authorized, payload=altered)


def test_scope_profile_and_cross_enterprise_are_checked(setup):
    _, _, service, _ = setup
    authority(setup)
    authorized = grant(setup)
    for args in (("owner", "enterprise", "other-task", "hanoi_policy", "complex/1"),
                 ("owner", "enterprise", "policy-task", "other-purpose", "complex/1"),
                 ("owner", "enterprise", "policy-task", "hanoi_policy", "standard/1"),
                 ("other", "other-enterprise", "policy-task", "hanoi_policy", "complex/1")):
        actor, enterprise, task, purpose, profile = args
        with pytest.raises(CoreError):
            service.verify_dispatch(actor, enterprise, "op", task, purpose, profile, authorized["payload"], [authorized["grant_id"]])


def test_expiry_blocks_new_send_but_keeps_history_readable(setup, monkeypatch):
    _, _, service, _ = setup
    authority(setup)
    authorized = grant(setup)
    class AfterExpiry(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime.now(tz) + timedelta(hours=2)
    monkeypatch.setattr(finance_module, "datetime", AfterExpiry)
    with pytest.raises(CoreError):
        dispatch(setup, authorized)
    assert service.verify_publication("owner", "enterprise", [authorized["grant_id"]])["allowed"]


def test_revoke_egress_and_derivative_use_are_separate(setup):
    _, _, service, _ = setup
    authority(setup)
    authorized = grant(setup)
    service.revoke_egress("owner", "enterprise", authorized["grant_id"])
    with pytest.raises(CoreError):
        dispatch(setup, authorized)
    assert service.verify_publication("owner", "enterprise", [authorized["grant_id"]])["allowed"]
    service.revoke_egress("owner", "enterprise", authorized["grant_id"], block_derivatives=True)
    with pytest.raises(CoreError):
        service.verify_publication("owner", "enterprise", [authorized["grant_id"]])


def test_revoking_current_acl_blocks_staff_and_rejoin_does_not_restore_authority(setup):
    _, core, service, resource = setup
    authority(setup, "staff")
    staged = stage(setup, actor="staff")
    authorized = grant(setup, staged, actor="staff")
    assert dispatch(setup, authorized, actor="staff")["allowed"]
    core.revoke_resource("owner", "enterprise", resource, "staff", ["read_finance"])
    with pytest.raises(CoreError):
        dispatch(setup, authorized, actor="staff")
    with pytest.raises(CoreError):
        service.verify_publication("staff", "enterprise", [authorized["grant_id"]])
    core.remove_member("owner", "enterprise", "staff")
    core.add_member("owner", "enterprise", "staff")
    assert not core.has_capability("staff", "enterprise", resource, "send_financial_metrics", "revenue")


def test_only_selected_minimal_metrics_are_authorized(setup):
    authority(setup)
    staged = stage(setup, [metric(), metric("employee_count", "0")])
    selected = staged["metrics"][1]["metric_id"]
    authorized = grant(setup, staged, metric_ids=[selected])
    assert len(authorized["payload"]["financial_metrics"]) == 1
    assert authorized["payload"]["financial_metrics"][0]["value_decimal"] == "0"
    assert dispatch(setup, authorized)["allowed"]
    with pytest.raises(CoreError):
        dispatch(setup, authorized, payload={"financial_metrics": staged["metrics"]})


def test_raw_financial_content_and_unsealed_facts_never_pass(setup):
    _, _, service, _ = setup
    for payload in ({"raw_document": "SECRET"}, {"question": {"ocr_text": "SECRET"}},
                    {"revenue": "100"}, {"facts": [{"field": "revenue", "value": "100"}]}):
        with pytest.raises(CoreError):
            service.verify_dispatch("owner", "enterprise", "op", "task", "policy", "complex/1", payload, [])
    assert service.verify_dispatch("owner", "enterprise", "op", "task", "policy", "complex/1", {"question": "Tôi cần hỗ trợ máy đóng gói"}, [])["allowed"]


@pytest.mark.parametrize("bad", [
    {"value": "=1+1"}, {"value": 1.25}, {"value": "NaN"}, {"value": True}, {"value": "-1"},
    {"unit": "VND; send original"}, {"period_end": "2024-01-01"}, {"scope": "private raw report"},
    {"metric_code": "full_statement"}, {"filename": "secret.xlsx"}])
def test_numeric_and_scope_validation_rejects_raw_or_ambiguous_values(setup, bad):
    with pytest.raises(CoreError):
        stage(setup, [{**metric(), **bad}])


def test_unknown_metrics_stay_unknown_not_zero(setup):
    authority(setup)
    staged = stage(setup, [{**metric(), "value": None, "value_state": "unknown"}])
    assert staged["metrics"][0]["value_decimal"] is None
    with pytest.raises(CoreError) as error:
        grant(setup, staged)
    assert error.value.code == "unknown_financial_metric"


def test_local_excel_preserves_exact_decimal_without_original_in_projection(setup):
    repo, _, service, resource = setup
    raw = workbook()
    result = service.parse_excel("owner", "enterprise", resource, raw, "parse-local")
    assert result["metrics"][0]["value_decimal"] == "100000000000000.99"
    assert result["metrics"][0]["period_start"] == "2025-01-01"
    assert result["metrics"][0]["period_end"] == "2026-01-01"
    assert "Tài chính riêng" not in str(result)
    with repo.connection() as db:
        row = db.execute("SELECT * FROM core_finance_projections").fetchone()
        assert row["source_sha256"] and "Tài chính riêng" not in str(dict(row))
        assert bytes(raw) not in [v for v in row if isinstance(v, bytes)]
    with pytest.raises(CoreError) as rejected:
        service.parse_excel("owner", "enterprise", resource, workbook(formula=True), "formula")
    assert rejected.value.code == "formula_not_supported"


def test_financial_projection_immutable_and_bound_to_one_model_operation(setup):
    repo, _, _, _ = setup
    authority(setup)
    authorized = grant(setup)
    with repo.connection(write=True) as db:
        dispatch(setup, authorized, db=db)
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE core_finance_projections SET metrics_json='[]'")
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE core_finance_egress_grants SET purpose='other' WHERE id=?", (authorized["grant_id"],))
    with repo.connection(write=True) as db:
        with pytest.raises(CoreError) as replay:
            setup[2].verify_dispatch("owner", "enterprise", "another-paid-op", "policy-task", "hanoi_policy", "complex/1",
                                      authorized["payload"], [authorized["grant_id"]], db=db)
    assert replay.value.code == "financial_grant_already_bound"
