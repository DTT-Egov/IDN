"""Same product, three private market dossiers and bounded no-paid-call research."""
import asyncio
import json

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService, resolve_market


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "multimarket.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("market-owner", "TestPassword12345", "Doanh nghiệp Sen")
    other = accounts.register("market-other", "TestPassword12345", "Doanh nghiệp khác")
    return repo, owner, other, MissionService(repo)


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


def complete(service, owner, code="US", key="first", product=None, parent=None, text=None):
    destination = {"US": "Mỹ", "DE": "Đức", "JP": "Nhật Bản"}[code]
    text = text or f"Tôi có Trà Sen Tây Hồ gửi {destination}, cần điều kiện nhập khẩu và chuẩn bị nhãn."
    mission = service.prepare(*args(owner), text, f"prepare-{key}", product, parent, market_code=code)
    assert mission["status"] == "planned", mission["intent"]
    service.start(*args(owner), mission["id"], f"start-{key}")
    assert asyncio.run(service.execute_next())
    result = service.get(*args(owner), mission["id"])
    assert result["status"] == "completed_partial", result.get("stale_reason")
    return result


def field_values(mission):
    return {field["id"]: field["value"] for field in mission["label"]["fields"]}


def save(service, owner, mission, fields, remember, key="save"):
    return service.update_label_progress(*args(owner), mission["id"], mission["label"]["id"], fields,
        remember, mission["label"]["version"], mission["product"]["version"], key,
        expected_market_profile_version=mission["market_profile"]["version"])


def three(service, owner):
    us = complete(service, owner)
    supplied = {"statement_of_identity": "Lotus-scented green tea", "ingredients": "Green tea, Lotus flowers", "net_quantity": "100 g", "responsible_business": "QA US importer"}
    us = save(service, owner, us, supplied, list(supplied))
    de = complete(service, owner, "DE", "germany", parent=us["id"])
    jp = complete(service, owner, "JP", "japan", parent=de["id"])
    return us, de, jp


def test_three_dossiers_share_raw_product_facts_not_translations_or_importers(setup):
    repo, owner, _, service = setup
    us, de, jp = three(service, owner)
    assert len({m["product"]["entity_id"] for m in (us, de, jp)}) == 1
    assert len({m["market_profile"]["entity_id"] for m in (us, de, jp)}) == 3
    for mission in (de, jp):
        values = field_values(mission)
        assert values["statement_of_identity"] is None and values["responsible_business"] is None
        assert values["ingredients"] == "Green tea, Lotus flowers" and values["net_quantity"] == "100 g"
        assert mission["label"]["parent_artifact_ref"] is None
        assert mission["label"]["label_language"] in {"de", "ja"}
        assert values["date_marking"] is None and values["storage_instructions"] is None
        assert values["ingredients_declaration"] is None
        assert len(values) == 9
        raw = next(f for f in mission["label"]["fields"] if f["id"] == "ingredients")
        assert raw["state"] == "needs_review"
        assert raw["provenance"]["translation_state"] == "original_user_value_untranslated"
        assert all(source["market_code"] == mission["market"]["code"] for source in mission["sources"])
        assert mission["cost"] == {"paid_calls": 0, "provider_attempts": 0}
    assert len(us["label"]["fields"]) == 6
    product = repo.get_entity(*args(owner), us["product"]["entity_id"])
    assert not any(f["field"] in {"target_market", "statement_of_identity", "responsible_business"} for f in product["facts"])
    returned = complete(service, owner, "US", "us-return", parent=jp["id"])
    assert returned["label"]["parent_artifact_ref"]["artifact_id"] == us["label"]["id"]
    assert field_values(returned)["responsible_business"] == "QA US importer"


def test_market_fact_change_invalidates_only_its_market_and_shared_change_all(setup):
    _, owner, _, service = setup
    us, de, jp = three(service, owner)
    changed = service.update_facts(*args(owner), de["id"], [{"field": "responsible_business", "value": "QA EU importer"}], de["product"]["version"], "de-operator", expected_market_profile_version=de["market_profile"]["version"])
    assert changed["status"] == "needs_revalidation"
    # Original US result was already stale after its selected-memory save. A
    # refreshed US mission is required to test cross-market invalidation.
    us_current = complete(service, owner, "US", "us-current", parent=jp["id"])
    de_current = complete(service, owner, "DE", "de-current", parent=de["id"])
    assert service.get(*args(owner), jp["id"])["status"] == "completed_partial"
    service.update_facts(*args(owner), de_current["id"], [{"field": "responsible_business", "value": "QA EU importer 2"}], de_current["product"]["version"], "de-operator-2", expected_market_profile_version=de_current["market_profile"]["version"])
    assert service.get(*args(owner), us_current["id"])["status"] == "completed_partial"
    assert service.get(*args(owner), jp["id"])["status"] == "completed_partial"
    current = service.get(*args(owner), jp["id"])
    service.update_facts(*args(owner), jp["id"], [{"field": "ingredients", "value": "Green tea only"}], current["product"]["version"], "shared-formula")
    assert all(service.get(*args(owner), m["id"])["status"] == "needs_revalidation" for m in (us_current, de_current, jp))


def test_source_change_is_bound_to_right_market(setup):
    _, owner, _, service = setup
    us, de, jp = three(service, owner)
    us = complete(service, owner, "US", "us-fresh", parent=us["id"])
    source = de["knowledge"]["source_refs"][0]
    service.catalog.observe_source(*args(owner), source["source_id"], "a" * 64, "de-source-change")
    assert service.get(*args(owner), de["id"])["status"] == "needs_revalidation"
    assert service.get(*args(owner), us["id"])["status"] == "completed_partial"
    assert service.get(*args(owner), jp["id"])["status"] == "completed_partial"


def test_ambiguous_and_unknown_destinations_never_borrow_us_context(setup):
    _, owner, _, service = setup
    first = complete(service, owner)
    for index, (text, candidates) in enumerate([
        ("Chuẩn bị nhãn sang EU", ["EU"]),
        ("Chuẩn bị nhãn xuất Mỹ và Nhật", ["US", "JP"]),
        ("Chuẩn bị nhãn sang Nepal", ["OTHER"]),
        ("Chuẩn bị nhãn đi Brazil", ["OTHER"]),
        ("Cùng Trà Sen này, cần nhãn cho thị trường UAE.", ["OTHER"]),
        ("Đổi thị trường thành UAE, chỉ chuẩn bị nhãn.", ["OTHER"]),
        ("Trà Sen này đã có hồ sơ Mỹ. Giờ tôi muốn bán sang UAE, cần nhãn.", ["OTHER"]),
        ("Đã có hồ sơ Nhật. Bây giờ tôi muốn gửi sang Dubai, chuẩn bị nhãn.", ["OTHER"]),
        ("Đã có hồ sơ Mỹ, tôi muốn bán sang UAE và cần nhãn.", ["OTHER"]),
    ]):
        mission = service.prepare(*args(owner), text, f"ambiguous-{index}", continuation_mission_id=first["id"])
        assert mission["status"] == "waiting_input" and mission["market"] is None
        assert mission["intent"]["market_candidates"] == candidates
        assert mission["sources"] == [] and mission["market_profile"] is None
        with pytest.raises(CoreError):
            service.start(*args(owner), mission["id"], f"no-start-{index}")
    missing = service.prepare(*args(owner), "Chuẩn bị nhãn cho hồ sơ này", "no-market", first["product"]["entity_id"])
    assert missing["status"] == "waiting_input"
    continued = service.prepare(*args(owner), "Chuẩn bị nhãn cho hồ sơ này", "with-parent", continuation_mission_id=first["id"])
    assert continued["status"] == "planned" and continued["market"]["code"] == "US"
    changed = service.prepare(*args(owner), "Trà Sen này đã làm hồ sơ Mỹ. Giờ tôi muốn bán sang Nhật và chuẩn bị nhãn.", "explicit-new-market", continuation_mission_id=first["id"])
    assert changed["status"] == "planned" and changed["market"]["code"] == "JP"


def test_explicit_market_choice_resolves_eu_but_conflicting_single_destination_waits(setup):
    _, owner, _, service = setup
    first = complete(service, owner)
    de = service.prepare(*args(owner), "Chuẩn bị nhãn sang EU", "eu-select", continuation_mission_id=first["id"], market_code="DE")
    assert de["status"] == "planned" and de["market"]["code"] == "DE"
    mismatch = service.prepare(*args(owner), "Chuẩn bị nhãn sang Mỹ", "wrong-picker", continuation_mission_id=first["id"], market_code="JP")
    assert mismatch["status"] == "waiting_input" and mismatch["market"] is None
    selected = service.prepare(*args(owner), "Chuẩn bị nhãn sang EU. Tôi chọn thị trường Đức (EU) cho lượt này.", "eu-explicit-choice", continuation_mission_id=first["id"], market_code="DE")
    assert selected["status"] == "planned" and selected["market"]["code"] == "DE"


def test_market_cas_and_atomic_rollback_keep_both_product_and_draft(setup, monkeypatch):
    repo, owner, _, service = setup
    first = complete(service, owner)
    fields = {"statement_of_identity": "Lotus tea", "ingredients": "Green tea"}
    with pytest.raises(CoreError, match="phiên bản hồ sơ thị trường"):
        service.update_label_progress(*args(owner), first["id"], first["label"]["id"], fields, list(fields), 1, first["product"]["version"], "no-market-cas")
    service.update_facts(*args(owner), first["id"], [{"field": "responsible_business", "value": "QA US importer"}], first["product"]["version"], "profile-update", expected_market_profile_version=0)
    with pytest.raises(CoreError, match="thị trường vừa thay đổi"):
        save(service, owner, first, fields, list(fields), "stale-market-cas")
    unchanged = service.get(*args(owner), first["id"])
    assert unchanged["label"]["version"] == 1 and "ingredients" not in unchanged["current_context"]["shared_values"]
    monkeypatch.setattr(service, "_insert_artifact", lambda *_: (_ for _ in ()).throw(CoreError("test_failure", "Storage failure", 500)))
    with pytest.raises(CoreError, match="Storage failure"):
        save(service, owner, unchanged, fields, list(fields), "rollback-both-scopes")
    after = service.get(*args(owner), first["id"])
    assert "ingredients" not in after["current_context"]["shared_values"]
    assert "statement_of_identity" not in after["market_profile"]["values"]
    assert after["label"]["version"] == 1
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 1


def test_market_profile_acl_and_legacy_product_declaration_never_auto_confirms_for_any_market(setup):
    repo, owner, other, service = setup
    product = repo.create_entity(*args(owner), "product", "Trà Sen Tây Hồ", operation_id="legacy-product")
    from test_ssot_field_scope import legacy_fact
    legacy_fact(repo, owner, product["id"], "statement_of_identity", "Legacy English tea")
    legacy_fact(repo, owner, product["id"], "target_market", "US")
    original_history = repo.get_fact_history(*args(owner), product["id"])
    jp = complete(service, owner, "JP", "legacy-jp", product=product["id"])
    us = complete(service, owner, "US", "legacy-us", product=product["id"])
    assert field_values(jp)["statement_of_identity"] is None
    assert field_values(us)["statement_of_identity"] is None
    assert us["market_profile"]["facts"] == []
    assert repo.get_fact_history(*args(owner), product["id"]) == original_history
    assert next(f for f in repo.get_entity(*args(owner), product["id"])["invalid_facts"]
                if f["field"] == "statement_of_identity")["value"] == "Legacy English tea"
    with pytest.raises(CoreError):
        service.prepare(*args(other), "Chuẩn bị nhãn sang Nhật", "foreign-parent", continuation_mission_id=us["id"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (jp["market_profile"]["entity_id"],))
    with pytest.raises(CoreError):
        service.get(*args(owner), jp["id"])
    assert jp["id"] not in {m["id"] for m in service.list(*args(owner))}


def test_scoped_dates_storage_remember_idempotently_without_product_pollution(setup):
    repo, owner, _, service = setup
    jp = complete(service, owner, "JP")
    fields = {"date_marking": "QA — see approved batch expiry", "storage_instructions": "QA — dry, cool place"}
    saved = save(service, owner, jp, fields, list(fields))
    replay = save(service, owner, jp, fields, list(fields))
    assert saved["label"]["version"] == replay["label"]["version"] == 2
    assert saved["product"]["version"] == jp["product"]["version"]
    assert all(saved["market_profile"]["values"][k] == value for k, value in fields.items())
    assert not set(fields).intersection(saved["current_context"]["shared_values"])
    with repo.connection() as db:
        old = json.loads(db.execute("SELECT data_json FROM v03_artifact_revisions WHERE id=? AND version=1", (jp["label"]["id"],)).fetchone()[0])
        assert all(f["value"] is None for f in old["fields"] if f["id"] in fields)


@pytest.mark.parametrize("text", [
    "Chuyển từ Mỹ sang UAE, cần chuẩn bị nhãn.",
    "Đổi hồ sơ Mỹ thành hồ sơ thị trường UAE.",
    "Tôi không xuất sang Mỹ nữa mà chuyển sang Dubai.",
    "Trà Sen này đã có hồ sơ Mỹ. Giờ tôi muốn bán sang UAE, cần nhãn.",
    "Đã có hồ sơ Nhật. Bây giờ tôi muốn gửi sang Dubai, chuẩn bị nhãn.",
])
def test_unknown_new_destination_cannot_be_masked_by_recognized_history(text):
    code, candidates, reasons = resolve_market(text, previous="US")
    assert code is None and candidates == ["OTHER"] and reasons


def test_revoked_source_cannot_start_even_with_same_hash_and_version(setup):
    repo, owner, _, service = setup
    mission = service.prepare(*args(owner), "Tôi có Trà Sen Tây Hồ gửi New York, cần nhãn.", "source-revoked")
    source = mission["knowledge"]["source_refs"][0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='revoked' WHERE id=?", (source["source_id"],))
    assert service.get(*args(owner), mission["id"])["status"] == "needs_revalidation"
    with pytest.raises(CoreError, match="đã đổi"):
        service.start(*args(owner), mission["id"], "revoked-start")
    assert not asyncio.run(service.execute_next())


@pytest.mark.parametrize("code", ["DE", "JP"])
def test_translated_ingredient_declaration_is_scoped_and_raw_recipe_readonly(setup, code):
    _, owner, _, service = setup
    us, de, jp = three(service, owner)
    us = complete(service, owner, "US", "fresh-us-before-translation", parent=us["id"])
    mission = de if code == "DE" else jp
    other = jp if code == "DE" else de
    declaration = "Grüner Tee, Lotusblüten" if code == "DE" else "緑茶、ハスの花"
    saved = save(service, owner, mission, {"ingredients_declaration": declaration}, ["ingredients_declaration"], "translated-declaration")
    assert saved["current_context"]["shared_values"]["ingredients"] == "Green tea, Lotus flowers"
    assert saved["market_profile"]["values"]["ingredients_declaration"] == declaration
    assert saved["product"]["version"] == mission["product"]["version"]
    assert service.get(*args(owner), us["id"])["status"] == "completed_partial"
    assert service.get(*args(owner), other["id"])["status"] == "completed_partial"
    assert field_values(service.get(*args(owner), other["id"]))["ingredients_declaration"] is None
    with pytest.raises(CoreError, match="công thức gốc"):
        save(service, owner, saved, {"ingredients": declaration}, ["ingredients"], "forbidden-raw-memory")
    with pytest.raises(CoreError, match="Thành phần gốc chỉ đọc"):
        service.update_label(*args(owner), saved["id"], saved["label"]["id"], {"ingredients": declaration}, saved["label"]["version"], "forbidden-legacy-raw")
    changed = service.update_facts(*args(owner), saved["id"], [{"field": "ingredients", "value": "Green tea only"}], saved["product"]["version"], "explicit-recipe-correction")
    field = next(f for f in changed["label"]["fields"] if f["id"] == "ingredients_declaration")
    assert field["value"] == declaration and field["state"] == "needs_review"
    assert "ingredients" in field["conflict"]["changed_fields"]
    assert field_values(changed)["ingredients"] == "Green tea only"
    assert "Dữ kiện tham chiếu — nguyên liệu gốc chưa dịch" in saved["label"]["markdown"]


def test_continuing_old_eight_slot_market_workbook_adds_ninth_without_rewriting_history(setup):
    repo, owner, _, service = setup
    jp = complete(service, owner, "JP", "old-eight")
    # Simulate an already persisted eight-slot 0.3B workbook from before the
    # separate translated-ingredients contract was introduced.
    with repo.connection(write=True) as db:
        payload = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (jp["id"],)).fetchone()[0])
        artifact = payload["artifacts"][0]
        artifact["fields"] = [field for field in artifact["fields"] if field["id"] != "ingredients_declaration"]
        artifact["schema_version"] = "food-label-workbook-v1"
        artifact["fields"][0]["value"] = "ハスの花の香りを付けた緑茶"
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json.dumps(payload), jp["id"]))
        old_json = json.dumps(artifact)
        db.execute("UPDATE v03_artifact_revisions SET data_json=? WHERE id=? AND version=1", (old_json, artifact["id"]))
    continued = complete(service, owner, "JP", "new-nine", parent=jp["id"])
    assert len(continued["label"]["fields"]) == 9
    assert continued["label"]["schema_version"] == "food-label-workbook-v2-multimarket"
    assert field_values(continued)["ingredients_declaration"] is None
    assert field_values(continued)["statement_of_identity"] == "ハスの花の香りを付けた緑茶"
    assert continued["label"]["parent_artifact_ref"]["artifact_id"] == jp["label"]["id"]
    with repo.connection() as db:
        original = db.execute("SELECT data_json FROM v03_artifact_revisions WHERE id=? AND version=1", (jp["label"]["id"],)).fetchone()[0]
        assert original == old_json and len(json.loads(original)["fields"]) == 8
