"""Regressions from the owner's 0.4A review; all data and file inputs are fake."""
import json

import httpx
import pytest

from nmate.v03.core import CoreError
from nmate.v04.conversations import ConversationService
from nmate.v04.dialogue import interpret
from nmate.v04.intake import IntakeService
from test_v04_intake import ASSETS, confirm, prepare, upload, synthetic_workbook
from test_v04_intake import workspace as shared_workspace, server as shared_server


@pytest.fixture
def workspace(tmp_path):
    return shared_workspace.__wrapped__(tmp_path)


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    yield from shared_server.__wrapped__(tmp_path_factory)


@pytest.fixture
def chat(workspace):
    repo, intake, owner, other = workspace
    return repo, intake, ConversationService(intake), owner, other


def send(service, owner, text="Tôi muốn cải thiện bao bì", op="conversation-send-0001", **kwargs):
    return service.send(owner["account_id"], owner["enterprise_id"], text,
                        kwargs.pop("attachments", []), op, **kwargs)


def test_draft_and_files_survive_goal_change_reload_and_another_conversation(chat):
    repo, intake, conversations, owner, _ = chat
    initial = send(conversations, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx"), upload(ASSETS / "tra-sen-bao-bi-mau.png")])
    item = initial["intake"]
    packaging = next(c["id"] for c in item["candidates"] if c["field"] == "packaging")
    employee = next(c["id"] for c in item["candidates"] if c["field"] == "employee_count")
    draft = {"selected": {c["id"]: c["id"] != employee for c in item["candidates"]},
             "edits": {packaging: "Hộp giấy hai lớp"}, "choices": {}}
    conversations.save_draft(owner["account_id"], owner["enterprise_id"], initial["id"], item["id"], draft, "conversation-save-draft")
    changed = send(conversations, owner, "Tôi không muốn cải thiện bao bì nữa, giờ muốn số hóa bán hàng và tồn kho",
                   op="conversation-goal-change", conversation_id=initial["id"], draft={"intake_id": item["id"], **draft})
    assert changed["intake"]["id"] == item["id"]
    assert changed["intake"]["candidates"] == item["candidates"]
    assert changed["intake"]["attachments"] == item["attachments"]
    assert changed["intake"]["expected_entity_versions"] == item["expected_entity_versions"]
    assert changed["intake"]["intent"]["primary"] == "digitize_operations"
    changed_draft = changed["drafts"][item["id"]]
    assert {key: changed_draft[key] for key in ("selected", "edits", "choices")} == draft
    assert changed_draft["base_review_revision"] == changed["intake"]["review"]["revision"]
    assert changed_draft["ui_revision"] == 2
    send(conversations, owner, "Chỉ cập nhật hồ sơ", op="conversation-other-new")
    restored = conversations.get(owner["account_id"], owner["enterprise_id"], initial["id"])
    assert len(restored["messages"]) == 4 and restored["drafts"][item["id"]] == changed_draft
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []
    result = confirm(intake, owner, restored["intake"], selected=[key for key, value in draft["selected"].items() if value], edits=draft["edits"])
    facts = {f["field"]: f for e in result["saved_context"]["entities"] for f in e["facts"]}
    assert len(facts) == 8 and "employee_count" not in facts
    assert facts["packaging"]["value"] == "Hộp giấy hai lớp"
    restored = conversations.get(owner["account_id"], owner["enterprise_id"], initial["id"])
    assert restored["status"] == "awaiting_confirmation"
    assert restored["intake"]["review"]["lifecycle"] == "partially_committed"
    assert restored["intake"]["review"]["pending_candidate_ids"] == [employee]
    assert restored["workspace_view"]["latest_confirmation_receipt"]["applied_fact_count"] == 8
    assert not [m for m in restored["messages"] if m["kind"] == "confirmation"]
    assert conversations.get(owner["account_id"], owner["enterprise_id"], initial["id"])["messages"] == restored["messages"]


def test_followup_counts_keep_task_without_becoming_ssot(chat):
    repo, _intake, conversations, owner, _ = chat
    initial = send(conversations, owner, "Tôi muốn giảm sai lệch tồn kho")
    followup = send(conversations, owner, "Có rồi, tồn trên sổ 120 hộp, kiểm đếm 110 hộp vào cuối ngày hôm qua",
                    op="conversation-count-reply", conversation_id=initial["id"])
    intent = followup["intake"]["intent"]
    assert intent["primary"] == "digitize_operations" and intent["focus"] == "inventory_accuracy"
    assert intent["working_answers"]["book_quantity"] == 120
    assert intent["working_answers"]["physical_quantity"] == 110
    assert intent["working_answers"]["count_date_phrase"] == "hôm qua"
    assert "count_date" not in intent["working_answers"]
    assert "-10" in str(followup["intake"]["next_steps"])
    assert "ngày/tháng/năm" in str(followup["intake"]["next_steps"])
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    dated = send(conversations, owner, "18/10/2026", op="conversation-date-reply", conversation_id=initial["id"])
    assert dated["intake"]["intent"]["working_answers"]["count_date"] == "2026-10-18"
    assert dated["intake"]["intent"]["working_answers"]["book_quantity"] == 120


@pytest.mark.parametrize("book,physical", [(120, 110), (27, 32)])
def test_compact_mock_chat_exposes_counts_and_current_request_without_opening_plan(chat, book, physical):
    repo, _intake, conversations, owner, _ = chat
    initial = send(conversations, owner, "Tôi muốn giảm sai lệch tồn kho")
    result = send(conversations, owner, f"Tồn sổ {book} hộp, kiểm đếm {physical} hộp",
                  op="compact-count-reply", conversation_id=initial["id"])
    text = result["messages"][-1]["text"]
    assert text == result["intake"]["assistant_text"]
    assert f"tồn sổ {book}" in text and f"kiểm đếm {physical} hộp" in text
    assert f"Chênh lệch tạm tính {physical-book}" in text
    current = result["intake"]["pending_question"]
    assert "ngày kiểm kê cụ thể" in current and "mã sản phẩm" in current
    assert not current.endswith("?")  # A request is visible even with a full stop.
    assert str(book) not in current and str(physical) not in current
    dated = send(conversations, owner, "Ngày 25/10/2026, mã LOT-B07", op="compact-date-code-reply", conversation_id=initial["id"])
    reply = dated["messages"][-1]["text"]
    current = dated["intake"]["pending_question"]
    assert f"tồn sổ {book}" in reply and f"Chênh lệch tạm tính {physical-book}" in reply
    assert "25/10/2026" in current and "LOT-B07" in current
    assert "đối chiếu phiếu nhập/xuất" in current
    assert "xác nhận ngày" not in current and "cho biết mã" not in current
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


@pytest.mark.parametrize("text,previous,primary,focus,markets", [
    ("Tôi không muốn cải thiện bao bì nữa, giờ muốn số hóa bán hàng và tồn kho", None, "digitize_operations", "sales_inventory_overview", []),
    ("Chỉ cập nhật hồ sơ để sau này giảm sai lệch tồn kho", None, "understand_business", None, []),
    ("Tôi muốn cập nhật doanh thu quý 2 từ Excel mới.", None, "understand_business", None, []),
    ("Không xuất khẩu đi Mỹ nữa, tôi muốn xuất khẩu đi Nhật", {"primary": "export_readiness", "market_codes": ["US"]}, "export_readiness", None, ["JP"]),
    ("Nhật", {"primary": "export_readiness", "market_codes": ["US"]}, "export_readiness", None, ["JP"]),
    ("Theo tháng và sản phẩm", {"primary": "digitize_operations", "focus": "sales_reporting"}, "digitize_operations", "sales_reporting", []),
    ("Dự báo thời tiết ngày mai", {"primary": "digitize_operations", "focus": "inventory_accuracy"}, "needs_clarification", None, []),
    ("Có mưa ngày mai không?", {"primary": "digitize_operations", "focus": "inventory_accuracy"}, "needs_clarification", None, []),
    ("Theo bạn thời tiết ngày mai ra sao?", {"primary": "digitize_operations", "focus": "inventory_accuracy"}, "needs_clarification", None, []),
    ("Tôi không rõ cần chuẩn bị gì để xuất khẩu Nhật", None, "export_readiness", None, ["JP"]),
    ("Tôi chưa số hóa bán hàng và tồn kho, muốn bắt đầu", None, "digitize_operations", "sales_inventory_overview", []),
    ("Tôi muốn xuất khẩu vào thị trường thuận lợi nhất", None, "export_readiness", None, []),
    ("Tôi muốn xuất khẩu mỹ phẩm đi Đức", None, "export_readiness", None, ["DE"]),
    ("Giờ tôi muốn xuất khẩu đi Canada", {"primary": "export_readiness", "market_codes": ["US"]}, "export_readiness", None, []),
])
def test_intent_respects_negation_restriction_and_waiting_task(text, previous, primary, focus, markets):
    intent = interpret(text, previous)
    assert (intent["primary"], intent["focus"], intent["market_codes"]) == (primary, focus, markets)


def test_unknown_photo_is_not_claimed_read_or_saved(chat, tmp_path):
    from PIL import Image
    repo, _intake, conversations, owner, _ = chat
    image = tmp_path / "unknown.png"
    Image.new("RGB", (50, 50), "blue").save(image)
    result = send(conversations, owner, attachments=[upload(image)])
    assert result["intake"]["attachments"][0]["extraction_status"] == "stored_not_read"
    assert "chưa đọc" in result["messages"][-1]["text"]
    assert "chưa được xác nhận" in str(result["intake"]["next_steps"])
    assert result["intake"]["candidates"] == []
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


def test_send_atomicity_idempotency_and_no_duplicate_messages(chat, monkeypatch):
    repo, intake, conversations, owner, _ = chat
    original = repo._save_operation
    def fail_last(db, account, enterprise, kind, *args):
        if kind == "v04_conversation_send":
            raise RuntimeError("injected-last-write-failure")
        return original(db, account, enterprise, kind, *args)
    monkeypatch.setattr(repo, "_save_operation", fail_last)
    files = [upload(ASSETS / "tra-sen-ho-so.xlsx")]
    with pytest.raises(RuntimeError, match="injected-last-write-failure"):
        send(conversations, owner, attachments=files)
    with repo.connection() as db:
        for table in ["v04_intakes", "v04_attachments", "v04_conversations", "v03_operations"]:
            assert db.execute(f"SELECT count(*) FROM {table}").fetchone()[0] == 0
    monkeypatch.setattr(repo, "_save_operation", original)
    first = send(conversations, owner, attachments=files)
    again = send(conversations, owner, attachments=files)
    assert again["id"] == first["id"] and again["messages"] == first["messages"]
    assert len(intake.list(owner["account_id"], owner["enterprise_id"])) == 1
    with pytest.raises(CoreError) as error:
        send(conversations, owner, text="Nội dung khác", attachments=files)
    assert error.value.code == "idempotency_conflict"


def test_thread_and_draft_are_owner_private_even_with_membership(chat):
    repo, _intake, conversations, owner, other = chat
    first = send(conversations, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")])
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_memberships(account_id,enterprise_id,role) VALUES(?,?,'owner')", (other["account_id"], owner["enterprise_id"]))
    assert conversations.list(other["account_id"], owner["enterprise_id"]) == []
    for action in [
        lambda: conversations.get(other["account_id"], owner["enterprise_id"], first["id"]),
        lambda: conversations.save_draft(other["account_id"], owner["enterprise_id"], first["id"], first["intake"]["id"], {}, "other-owner-draft"),
        lambda: conversations.send(other["account_id"], owner["enterprise_id"], "Xin đọc tiếp", [], "other-owner-send", first["id"]),
    ]:
        with pytest.raises(CoreError) as error:
            action()
        assert error.value.code in {"not_found", "forbidden"}


def test_invalid_draft_rolls_back_and_legacy_work_can_continue(chat):
    repo, intake, conversations, owner, _ = chat
    legacy = prepare(intake, owner)
    with pytest.raises(CoreError) as error:
        send(conversations, owner, draft={"intake_id": legacy["id"], "choices": {legacy["candidates"][0]["id"]: []}})
    assert error.value.code == "invalid_draft"
    assert conversations.list(owner["account_id"], owner["enterprise_id"]) == []
    result = send(conversations, owner, "Giờ tôi muốn cải thiện bao bì", draft={"intake_id": legacy["id"], "selected": {legacy["candidates"][0]["id"]: False}})
    assert result["intake"]["id"] == legacy["id"]
    assert len(result["messages"]) == 3 and result["messages"][0]["attachments"] == legacy["attachments"]
    assert conversations.list(owner["account_id"], owner["enterprise_id"])[0]["intake_ids"] == [legacy["id"]]
    assert repo.list_entities(owner["account_id"], owner["enterprise_id"]) == []


def test_equivalent_confirmed_name_edit_can_restore_presentation_alias_without_fact_changes(workspace):
    repo, intake, owner, _ = workspace
    initial = prepare(intake, owner)
    name = next(c for c in initial["candidates"] if c["field"] == "name")
    saved = confirm(intake, owner, initial, edits={name["id"]: "TRÀ SEN TÂY HỒ"})
    product = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "product")
    with repo.connection(write=True) as db:
        db.execute("DELETE FROM v03_entity_names WHERE entity_id=? AND name_key=?", (product["id"], name["value"].casefold()))
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    restored = IntakeService(repo)
    with repo.connection() as db:
        assert not db.execute("SELECT 1 FROM v03_entity_names WHERE entity_id=? AND name_key=?",
                              (product["id"], name["value"].casefold())).fetchone()
    assert repo.migrate_name_aliases()["aliases_added"] == 1
    assert repo.migrate_name_aliases()["aliases_added"] == 0
    repeat = prepare(restored, owner, op="legacy-alias-reimport")
    assert repeat["product"]["id"] == product["id"]
    assert next(c for c in repeat["candidates"] if c["field"] == "name")["status"] == "already_known"
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["context_hash"] == before["context_hash"]


@pytest.mark.parametrize("corruption", ["source_original", "source_owner_confirmation", "unchecked_candidate"])
def test_alias_migration_never_promotes_unproven_original_name(workspace, corruption):
    repo, intake, owner, _ = workspace
    initial = prepare(intake, owner)
    name = next(c for c in initial["candidates"] if c["field"] == "name")
    saved = confirm(intake, owner, initial, edits={name["id"]: "Trà Sen Tây Hồ Cao Cấp"})
    product = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "product")
    with repo.connection(write=True) as db:
        db.execute("DELETE FROM v03_entity_names WHERE entity_id=? AND name_key=?", (product["id"], name["value"].casefold()))
        if corruption == "unchecked_candidate":
            row = db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (initial["id"],)).fetchone()
            payload = json.loads(row[0])
            next(c for c in payload["candidates"] if c["id"] == name["id"])["status"] = "candidate"
            db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json.dumps(payload, ensure_ascii=False), initial["id"]))
        else:
            assertion = db.execute("SELECT id,source_json FROM v03_fact_assertions WHERE entity_id=? AND field='name'", (product["id"],)).fetchone()
            source = json.loads(assertion["source_json"])
            if corruption == "source_original":
                source["original_value"] = "Tên giả không được chủ xác nhận"
            else:
                source["owner_confirmed"] = False
            db.execute("UPDATE v03_fact_assertions SET source_json=? WHERE id=?", (json.dumps(source, ensure_ascii=False), assertion["id"]))
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    assert repo.migrate_name_aliases()["aliases_added"] == 0
    assert repo.migrate_name_aliases()["aliases_added"] == 0
    with repo.connection() as db:
        assert not db.execute("SELECT 1 FROM v03_entity_names WHERE entity_id=? AND name_key=?",
            (product["id"], name["value"].casefold())).fetchone()
        assert not db.execute("SELECT 1 FROM v03_entity_names WHERE entity_id=? AND name_key=?",
            (product["id"], "Tên giả không được chủ xác nhận".casefold())).fetchone()
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["context_hash"] == before["context_hash"]


def test_resume_older_work_in_same_thread_does_not_overwrite_newer_draft(chat):
    _repo, _intake, conversations, owner, _ = chat
    first = send(conversations, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")])
    second = send(conversations, owner, "Tôi muốn xuất khẩu đi Mỹ", op="send-second-document", conversation_id=first["id"],
                  attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")])
    old, new = first["intake"]["id"], second["intake"]["id"]
    assert old != new
    selected = second["intake"]["candidates"][0]["id"]
    new_draft = {"selected": {selected: False}}
    conversations.save_draft(owner["account_id"], owner["enterprise_id"], first["id"], new, new_draft, "newer-document-draft")
    resumed = send(conversations, owner, "Tôi muốn giảm sai lệch tồn kho", op="send-resume-old-document",
                   conversation_id=first["id"], target_intake_id=old)
    assert resumed["intake"]["id"] == old and resumed["active_intake_id"] == old
    assert resumed["intake"]["intent"]["focus"] == "inventory_accuracy"
    assert resumed["drafts"][new]["selected"] == new_draft["selected"]
    assert resumed["drafts"][new]["edits"] == resumed["drafts"][new]["choices"] == {}
    assert resumed["drafts"][new]["ui_revision"] == 1
    assert resumed["drafts"][new]["base_review_revision"] == second["intake"]["review"]["revision"]
    with pytest.raises(CoreError) as error:
        send(conversations, owner, op="send-invalid-document-context", conversation_id=first["id"], target_intake_id="not-in-this-thread")
    assert error.value.code == "invalid_context"


@pytest.mark.parametrize("reply", ["Ngày 18/10/2026, mã sản phẩm TS01", "18/10/2026, TS01"])
def test_inventory_reply_accepts_requested_date_and_product_code(chat, reply):
    repo, _intake, conversations, owner, _ = chat
    first = send(conversations, owner, "Tôi muốn giảm sai lệch tồn kho")
    send(conversations, owner, "Tồn sổ 120 hộp, kiểm đếm 110 hộp", op="inventory-reply-counts", conversation_id=first["id"])
    result = send(conversations, owner, reply, op="inventory-reply-date-and-code", conversation_id=first["id"])
    assert result["intake"]["intent"]["focus"] == "inventory_accuracy"
    slots = result["intake"]["intent"]["working_answers"]
    assert slots["book_quantity"] == 120 and slots["physical_quantity"] == 110
    assert slots["count_date"] == "2026-10-18" and slots["product_code"] == "TS01"
    assert "TS01" in str(result["intake"]["next_steps"])
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


def test_explicit_different_product_changes_context_without_borrowing_facts(chat):
    _repo, intake, conversations, owner, _ = chat
    for number, name, packaging in [(1, "Trà Sen Tây Hồ", "Hộp giấy"), (2, "Trà Hoa Cúc", "Túi bạc")]:
        pending = prepare(intake, owner, op=f"prepare-product-{number}", files=[synthetic_workbook([
            ["product", "name", name, "", ""], ["product", "packaging", packaging, "", ""]])])
        confirm(intake, owner, pending, op=f"confirm-product-{number}")
    first = send(conversations, owner, "Tôi muốn cải thiện bao bì Trà Sen Tây Hồ")
    result = send(conversations, owner, "Còn Trà Hoa Cúc thì cải thiện bao bì thế nào?", op="switch-explicit-product", conversation_id=first["id"])
    assert result["intake"]["id"] != first["intake"]["id"]
    assert result["intake"]["product"]["id"] != first["intake"]["product"]["id"]
    assert "Túi bạc" in str(result["intake"]["next_steps"])
    assert "Hộp giấy" not in str(result["intake"]["next_steps"])
    send(conversations, owner, "Tôi muốn giảm sai lệch tồn kho. Tồn sổ 120 hộp, kiểm đếm 110 hộp", op="count-productB",
         conversation_id=first["id"])
    switched_back = send(conversations, owner, "Với Trà Sen Tây Hồ, tôi muốn giảm sai lệch tồn kho", op="return-productA",
                         conversation_id=first["id"])
    assert switched_back["intake"]["intent"]["focus"] == "inventory_accuracy"
    assert not switched_back["intake"]["intent"]["working_answers"]
    assert "120" not in str(switched_back["intake"]["next_steps"])


@pytest.mark.parametrize("confirmed", [True, False])
def test_enterprise_only_work_does_not_select_unmentioned_single_product(chat, confirmed):
    _repo, intake, conversations, owner, _ = chat
    saved = confirm(intake, owner, prepare(intake, owner))
    product = next(e for e in saved["saved_context"]["entities"] if e["entity_type"] == "product")
    first = send(conversations, owner, "Cập nhật hồ sơ", attachments=[synthetic_workbook([
        ["enterprise", "employee_count", "14", "người", "2026"]])])
    if confirmed:
        confirm(intake, owner, first["intake"], op="confirm-enterprise-only-work", conflict_choices={c["id"]: "incoming" for c in first["intake"]["candidates"]})
    result = send(conversations, owner, "Tôi muốn xuất khẩu đi Nhật", op="export-after-enterprise-only", conversation_id=first["id"])
    assert result["intake"]["product"] is None
    assert product["id"] not in result["intake"]["reused_context"]["entity_ids"]
    assert "Trà Sen Tây Hồ" not in str(result["intake"]["business_plan"])
    assert any("Cần xác nhận hồ sơ sản phẩm" in item for item in result["intake"]["next_steps"])


def test_http_mcp_conversation_draft_roundtrip(server):
    with httpx.Client(base_url=server["url"], timeout=20) as web:
        pre = web.get("/api/v03/session").json()
        headers = {"Origin": server["url"], "X-CSRF-Token": pre["csrf_token"]}
        session = web.post("/api/v03/register", headers=headers, json={"username": "http-conversation-v04", "password": "Test-only-secret-v04", "enterprise_name": "Trà Sen Hội Thoại"}).json()
        headers["X-CSRF-Token"] = session["csrf_token"]
        def tool(name, **arguments):
            response = web.post("/api/v03/mcp/call", headers=headers, json={"name": name, "arguments": {"enterprise_id": session["enterprise"]["id"], **arguments}})
            assert response.status_code == 200, response.text
            payload = response.json()
            assert payload["ok"], payload
            return payload["data"]
        result = tool("send_message", text="Cập nhật hồ sơ", attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")], operation_id="http-conversation-prepare")
        candidate = result["intake"]["candidates"][0]["id"]
        draft = {"selected": {candidate: False}, "edits": {}, "choices": {},
                 "base_review_revision": result["intake"]["review"]["revision"], "ui_revision": 0}
        tool("save_conversation_draft", conversation_id=result["id"], intake_id=result["intake"]["id"], draft=draft, operation_id="http-conversation-draft")
        followup = tool("send_message", conversation_id=result["id"], text="Giờ tôi muốn xuất khẩu đi Nhật", attachments=[], operation_id="http-conversation-followup")
        assert followup["intake"]["id"] == result["intake"]["id"]
        reloaded = tool("get_conversation", conversation_id=result["id"])
        expected_draft = {**draft, "ui_revision": 1}
        assert reloaded["drafts"][result["intake"]["id"]] == expected_draft
        assert reloaded["intake"]["intent"]["market_codes"] == ["JP"]
        assert len(reloaded["messages"]) == 4
        assert tool("list_conversations")[0]["intake_ids"] == [result["intake"]["id"]]
        assert web.get("/health").json()["paid_calls"] == 0
