"""R1/DF-017/021: status is a projection; only an authorized begin activates.

All approvals/transport are synthetic and scoped to the private temporary DB.
"""
import asyncio
from datetime import datetime, timedelta, timezone
import json

import pytest
from jsonschema.exceptions import SchemaError

from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.integration import CoreIntegration
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


OUTPUT = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


def ledger(repo):
    with repo.connection() as db:
        names = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' "
                                        "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {name: sorted([tuple(row) for row in db.execute(f'SELECT * FROM "{name}"')], key=repr)
                for name in names}


@pytest.fixture
def case(tmp_path):
    repo = CoreRepository(tmp_path / "r1-query.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("r1-query-owner", "Synthetic-password-123", "R1 Synthetic")
    calls = []

    async def transport(model, body, limit):
        calls.append((model, body, limit))
        return {"text": '{"answer":"Synthetic saved result"}', "model": model,
                "usage": {"input_tokens": 10, "output_tokens": 10}, "stop_reason": "end_turn"}

    gateway = ModelGateway(repo, enabled=True, request_fn=transport)
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    pool = gateway.budget_pool.authorize("R1-SYNTHETIC-APPROVAL", "standard", 2, 1,
                                        ["legacy_intake", "hanoi_policy_synthesis"], expiry)
    return repo, owner, gateway, pool, calls


def query(case, **options):
    return case[2].status(case[1]["account_id"], case[1]["enterprise_id"], **options)


@pytest.mark.parametrize("options", [{}, {"provision": False}, {"provision": True}])
def test_every_gateway_status_mode_is_readonly_but_preserves_pool_readiness(case, options):
    before = ledger(case[0])
    for _ in range(3):
        status = query(case, **options)
        assert status["approved"] is True
        assert status["paid_calls"] == 0
        assert len(status["grants"]) == 1
        assert status["grants"][0]["remaining_calls"] == 2
        assert status["grants"][0]["roles"] == ["standard"]
    assert ledger(case[0]) == before
    assert case[4] == []


def test_integration_and_legacy_status_do_not_activate(case):
    integration = object.__new__(CoreIntegration)
    integration.gateway = case[2]
    integration.legacy_adapter = GovernedLegacyAdapter(case[0], case[2], None)
    before = ledger(case[0])
    for _ in range(3):
        value = integration.gateway_status(case[1]["account_id"], case[1]["enterprise_id"])
        assert value["approved"] and value["legacy_paid_gate"]["purposes"]["legacy_intake"]["approved"]
    assert ledger(case[0]) == before
    assert case[4] == []


def invoke(case, grant, operation="r1-first", role="standard", purpose="legacy_intake", **changes):
    options = dict(account_id=case[1]["account_id"], enterprise_id=case[1]["enterprise_id"],
        operation_id=operation, task_id="r1-task", role=role, purpose=purpose,
        context={"question": "Synthetic stock question"}, output_schema=OUTPUT, budget_grant_id=grant)
    options.update(changes)
    return asyncio.run(case[2].call_once(**options))


def test_begin_activates_only_selected_pool_then_terminal_replay_never_activates(case):
    grant = query(case)["grants"][0]["id"]
    before = ledger(case[0])
    assert before["core_budget_grants"] == [] and before["core_budget_pool_links"] == []
    receipt = invoke(case, grant)
    after_begin = ledger(case[0])
    assert len(after_begin["core_budget_grants"]) == 1
    assert len(after_begin["core_budget_pool_links"]) == 1
    assert len(case[4]) == 1
    # A new eligible pool appears after the committed result; reading/replay
    # cannot activate it, even when the original approval is no longer usable.
    case[2].budget_pool.authorize("R1-UNRELATED-APPROVAL", "complex", 3, 2,
        ["legacy_research"], (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    with case[0].connection(write=True) as db:
        db.execute("UPDATE core_budget_pools SET state='closed' WHERE id=?", (case[3]["id"],))
    before_replay = ledger(case[0])
    for _ in range(2):
        assert query(case)["approved"]
        replay = invoke(case, grant)
        assert replay["attempt_id"] == receipt["attempt_id"] and replay["cached"] is True
    assert ledger(case[0]) == before_replay
    assert len(case[4]) == 1


@pytest.mark.parametrize("role,purpose", [("complex", "legacy_intake"), ("standard", "legacy_research")])
def test_wrong_role_or_purpose_does_not_activate(case, role, purpose):
    grant = query(case)["grants"][0]["id"]
    before = ledger(case[0])
    with pytest.raises(CoreError) as error:
        invoke(case, grant, role=role, purpose=purpose)
    assert error.value.code == "BUDGET_NOT_GRANTED"
    assert ledger(case[0]) == before and case[4] == []


@pytest.mark.parametrize("state", ["closed", "expired"])
def test_preview_is_not_authority_after_pool_closure_or_expiry(case, state):
    grant = query(case)["grants"][0]["id"]
    with case[0].connection(write=True) as db:
        if state == "closed":
            db.execute("UPDATE core_budget_pools SET state='closed' WHERE id=?", (case[3]["id"],))
        else:
            db.execute("UPDATE core_budget_pools SET expires_at=? WHERE id=?",
                ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(), case[3]["id"]))
    before = ledger(case[0])
    assert query(case)["approved"] is False
    with pytest.raises(CoreError) as error:
        invoke(case, grant)
    assert error.value.code == "BUDGET_NOT_GRANTED"
    assert ledger(case[0]) == before and case[4] == []


def test_preview_identity_is_scoped_and_cannot_be_used_by_another_owner(case):
    grant = query(case)["grants"][0]["id"]
    other = LocalAccounts(case[0]).register("r1-other-owner", "Synthetic-password-123", "Other")
    other_case = case[0], other, case[2], case[3], case[4]
    own_preview = query(other_case)["grants"][0]
    assert own_preview["id"] != grant
    assert case[1]["account_id"] not in json.dumps(own_preview)
    before = ledger(case[0])
    with pytest.raises(CoreError):
        invoke(other_case, grant)
    assert ledger(case[0]) == before and case[4] == []


@pytest.mark.parametrize("configured", [False, True])
def test_failed_begin_does_not_leave_activation_outside_command(case, configured):
    grant = query(case)["grants"][0]["id"]
    if not configured:
        case[2].request_fn = None
    before = ledger(case[0])
    with pytest.raises(CoreError):
        invoke(case, grant, context={"question": "Synthetic", "financial_metrics": [{"amount": 1}]}
               if configured else {"question": "Synthetic"})
    assert ledger(case[0]) == before and case[4] == []


def test_staff_and_revoked_owner_never_gain_pool_activation(case):
    grant = query(case)["grants"][0]["id"]
    with case[0].connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?",
                   (case[1]["account_id"], case[1]["enterprise_id"]))
    before = ledger(case[0])
    assert query(case)["approved"] is False
    with pytest.raises(CoreError):
        invoke(case, grant)
    assert ledger(case[0]) == before
    with case[0].connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?",
                   (case[1]["account_id"], case[1]["enterprise_id"]))
    before_revoke = ledger(case[0])
    with pytest.raises(CoreError):
        query(case)
    with pytest.raises(CoreError):
        invoke(case, grant)
    assert ledger(case[0]) == before_revoke and case[4] == []


def test_historical_link_id_wins_over_new_preview_identity(case):
    current = case[2].budget_pool.provision(case[1]["account_id"], case[1]["enterprise_id"])[0]
    old_id = "budget_historical_original_id"
    with case[0].connection(write=True) as db:
        db.execute("INSERT INTO core_budget_grants SELECT ?,enterprise_id,account_id,approval_id,max_calls,cap_microusd,"
                   "purposes_json,roles_json,expires_at,state,created_at FROM core_budget_grants WHERE id=?", (old_id, current))
        db.execute("UPDATE core_budget_pool_links SET grant_id=? WHERE grant_id=?", (old_id, current))
        db.execute("DELETE FROM core_budget_grants WHERE id=?", (current,))
    before = ledger(case[0])
    projected = query(case)["grants"]
    assert len(projected) == 1 and projected[0]["id"] == old_id
    assert ledger(case[0]) == before
    with pytest.raises(CoreError):
        invoke(case, current)
    assert ledger(case[0]) == before
    assert invoke(case, old_id)["data"]["answer"] == "Synthetic saved result"
    assert len(ledger(case[0])["core_budget_grants"]) == 1 and len(case[4]) == 1


def test_two_new_owners_contend_for_last_call_without_query_activation(case):
    # Consume one of the two approved calls, then race actual begin commands
    # from two owners whose preview reads created no child grants.
    invoke(case, query(case)["grants"][0]["id"], operation="r1-first-used")
    accounts = LocalAccounts(case[0])
    owners = [accounts.register(f"r1-last-owner-{i}", "Synthetic-password-123", f"Synthetic {i}") for i in range(2)]
    contexts = [(case[0], owner, case[2], case[3], case[4]) for owner in owners]
    before_reads = ledger(case[0])
    grants = [query(context)["grants"][0]["id"] for context in contexts]
    assert ledger(case[0]) == before_reads

    async def scenario():
        started, release = asyncio.Event(), asyncio.Event()

        async def pending(model, body, limit):
            case[4].append((model, body, limit))
            started.set()
            await release.wait()
            return {"text": '{"answer":"Synthetic last call"}', "model": model,
                    "usage": {"input_tokens": 10, "output_tokens": 10}, "stop_reason": "end_turn"}

        case[2].request_fn = pending

        async def begin(index):
            return await case[2].call_once(account_id=owners[index]["account_id"], enterprise_id=owners[index]["enterprise_id"],
                operation_id=f"r1-last-{index}", task_id="r1-task", role="standard", purpose="legacy_intake",
                context={"question": "Synthetic stock question"}, output_schema=OUTPUT, budget_grant_id=grants[index])

        first = asyncio.create_task(begin(0))
        await started.wait()
        before_rejected = ledger(case[0])
        try:
            with pytest.raises(CoreError) as rejected:
                await begin(1)
            assert rejected.value.code == "BUDGET_EXCEEDED"
            assert query(contexts[1])["approved"] is False
            assert query(contexts[1])["grants"][0]["remaining_calls"] == 0
            assert ledger(case[0]) == before_rejected
        finally:
            release.set()
        await first

    asyncio.run(scenario())
    assert len(case[4]) == 2
    with case[0].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts WHERE dispatched_at IS NOT NULL").fetchone()[0] == 2
        assert db.execute("SELECT COUNT(*) FROM core_budget_pool_links WHERE account_id=?", (owners[1]["account_id"],)).fetchone()[0] == 0


@pytest.mark.parametrize("guard", ["context", "schema", "egress_authority", "disabled", "egress_after_activation"])
def test_begin_guards_leave_no_activation_or_reservation(case, guard):
    grant = query(case)["grants"][0]["id"]
    changes = {}
    expected = CoreError
    if guard == "context":
        changes["context"] = []
    elif guard == "schema":
        changes["output_schema"] = {"type": "unrecognized_type"}
        expected = SchemaError
    elif guard == "egress_authority":
        changes["financial_egress_grant_ids"] = ["synthetic-unverified-egress"]
    elif guard == "disabled":
        case[2].enabled = False
    else:
        class DeniedFinance:
            def verify_dispatch(self, *_args, **_kwargs):
                raise CoreError("DATA_EGRESS_BLOCKED", "Synthetic exact egress denied", 409)
        case[2].finance = DeniedFinance()
        changes["financial_egress_grant_ids"] = ["synthetic-denied-egress"]
    before = ledger(case[0])
    with pytest.raises(expected):
        invoke(case, grant, **changes)
    assert ledger(case[0]) == before and case[4] == []
