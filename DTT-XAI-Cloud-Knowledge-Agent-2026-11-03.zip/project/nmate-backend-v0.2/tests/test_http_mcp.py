"""Exercise the actual MCP v2 SDK over localhost HTTP, including the web BFF."""

import hashlib
import socket
import threading
import time

import httpx
import httpx2
import pytest
import uvicorn
from mcp import Client
from mcp.client.streamable_http import streamable_http_client

from nmate.agents.shipment.graph import build_graph
from nmate.agents.shipment.models import SourceBatch, SourceDocument, SourceFailure
from nmate.app import create_app
from nmate.config import Settings


class FixtureSources:
    async def fetch_all(self):
        # Synthetic source bodies are injected only in tests; no test result becomes pilot evidence.
        text = "Test fixture: import preparation and prior notice need review.\nFSVP importer is a US owner or consignee."
        return SourceBatch(sources=[SourceDocument(
            id="fda_import", url="https://www.fda.gov/food/food-imports-exports/importing-food-products-united-states",
            title="Synthetic FDA test fixture", publisher="TEST ONLY", accessed_at="2026-10-17T00:00:00Z",
            content_sha256=hashlib.sha256(text.encode()).hexdigest(), text=text)],
            failures=[SourceFailure(source_id="cbp_import", url="https://www.cbp.gov/", code="HTTP_403", detail="TEST ONLY")])


def fixture_graph(cp, **kwargs):
    return build_graph(cp, source_provider=FixtureSources(), **kwargs)


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    settings = Settings(data_dir=tmp_path_factory.mktemp("http-mcp"), port=port)
    app = create_app(settings, graph_factory=fixture_graph)
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error", access_log=False)
    instance = uvicorn.Server(config)
    thread = threading.Thread(target=instance.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not instance.started:
        if not thread.is_alive() or time.monotonic() > deadline:
            pytest.fail("HTTP test server did not start")
        time.sleep(0.02)
    yield settings
    instance.should_exit = True
    thread.join(timeout=10)
    assert not thread.is_alive()


def test_frontend_session_and_csrf(server):
    with httpx.Client(base_url=server.base_url) as web:
        response = web.get("/api/session")
        assert response.status_code == 200
        assert "HttpOnly" in response.headers["set-cookie"]
        data = response.json()
        assert data["mode"] == "evidence_only"
        assert "mcp_token" not in data
        body = {"product": {"sku": "TEST", "name": "Miến khô TEST"}, "consent_research": True}
        assert web.post("/api/cases", json=body).status_code == 403
        headers = {"X-CSRF-Token": data["csrf_token"]}
        bad = web.post("/api/cases", json=body, headers={**headers, "Origin": "https://attacker.invalid"})
        assert bad.status_code == 403
        created = web.post("/api/cases", json=body, headers=headers)
        assert created.status_code == 201
        args = {"case_id": created.json()["case_id"], "expected_case_version": 1,
                "idempotency_key": "test-http-mcp-unique"}
        start = web.post("/api/mcp/call", headers=headers,
                         json={"name": "nmate_shipment_readiness_start", "arguments": args})
        assert start.status_code == 200, start.text
        envelope = start.json()
        assert envelope["ok"], envelope
        run_id = envelope["data"]["run_id"]
        assert "snapshot" not in envelope["data"]
        deadline = time.monotonic() + 15
        while True:
            result = web.post("/api/mcp/call", headers=headers,
                      json={"name": "nmate_research_get", "arguments": {"run_id": run_id}}).json()
            assert result["ok"], result
            run = result["data"]
            if run["status"] not in ("queued", "running"):
                break
            assert time.monotonic() < deadline
            time.sleep(0.05)
        assert run["status"] == "succeeded", run
        artifact = web.post("/api/mcp/call", headers=headers,
                           json={"name": "nmate_artifact_get", "arguments": {"artifact_id": run["artifact_id"]}}).json()
        assert artifact["ok"]
        assert artifact["data"]["review_status"] == "draft"
        report = artifact["data"]["report"]
        assert report["mode"] == "evidence_only" and not report["llm_used"]
        assert report["source_failures"][0]["code"] == "HTTP_403"
        assert len(report["next_steps"]) <= 3
        assert all(e["review_status"] == "candidate" for e in report["evidence"])
        assert "mcp_token" not in str(artifact)
        retry = web.post("/api/mcp/call", headers=headers,
                         json={"name": "nmate_shipment_readiness_start", "arguments": args}).json()
        assert retry["data"]["run_id"] == run_id


async def test_actual_mcp_2026_tools_and_auth(server):
    token = (server.data_dir / "mcp-token.txt").read_text()
    async with httpx.AsyncClient() as raw:
        rejected = await raw.post(server.base_url + "/mcp", json={})
        assert rejected.status_code == 401
    async with httpx2.AsyncClient(headers={"Authorization": f"Bearer {token}"}, trust_env=False) as http:
        async with Client(streamable_http_client(server.base_url + "/mcp", http_client=http),
                          mode="2026-07-28", cache=None) as client:
            tools = await client.list_tools()
            names = {t.name for t in tools.tools}
            assert names == {"nmate_shipment_readiness_start", "nmate_research_get",
                             "nmate_research_cancel", "nmate_artifact_get", "nmate_case_get"}
            result = await client.call_tool("nmate_research_get", {"run_id": "missing"})
            assert result.is_error
            assert result.structured_content["error"]["code"] == "NOT_FOUND"


async def test_two_cookie_jars_and_raw_mcp_bearer_cannot_cross_browser_workspace(server):
    from nmate.auth import LocalAuth
    from nmate.store import Store

    with httpx.Client(base_url=server.base_url) as a, httpx.Client(base_url=server.base_url) as b:
        sa, sb = a.get("/api/session").json(), b.get("/api/session").json()
        ha, hb = {"X-CSRF-Token": sa["csrf_token"]}, {"X-CSRF-Token": sb["csrf_token"]}
        assert sa["browser_user_id"] != sb["browser_user_id"]
        conv = a.post("/api/conversations", headers=ha, json={"consent_model": True, "consent_storage": True}).json()
        case = a.post("/api/cases", headers=ha, json={"product": {"sku": "TEST-ISOLATION", "name": "Sản phẩm THỬ A"},
                    "consent_research": True}).json()
        start = a.post("/api/mcp/call", headers=ha, json={"name": "nmate_shipment_readiness_start", "arguments": {
            "case_id": case["case_id"], "expected_case_version": 1, "idempotency_key": "TEST-ISOLATION-START"}}).json()
        assert start["ok"]
        rid = start["data"]["run_id"]
        deadline = time.monotonic() + 15
        while True:
            result = a.post("/api/mcp/call", headers=ha, json={"name": "nmate_research_get", "arguments": {"run_id": rid}}).json()
            assert result["ok"]
            run = result["data"]
            if run["status"] not in ("queued", "running"):
                break
            assert time.monotonic() < deadline
            time.sleep(0.03)
        assert run["status"] == "succeeded"
        aid = run["artifact_id"]
        for tool, args in (("nmate_case_get", {"case_id": case["case_id"]}),
                           ("nmate_research_get", {"run_id": rid}), ("nmate_research_cancel", {"run_id": rid}),
                           ("nmate_artifact_get", {"artifact_id": aid}),
                           ("nmate_shipment_readiness_start", {"case_id": case["case_id"], "expected_case_version": 1, "idempotency_key": "TEST-FOREIGN-START"})):
            denied = b.post("/api/mcp/call", headers=hb, json={"name": tool, "arguments": args}).json()
            assert not denied["ok"] and denied["error"]["code"] == "NOT_FOUND"
        assert b.get(f"/api/artifacts/{aid}/translations").status_code == 404
        assert b.get(f"/api/conversations/{conv['conversation_id']}").status_code == 404
        assert b.post(f"/api/conversations/{conv['conversation_id']}/messages", headers=hb, json={
            "message": "Đọc bản nghiên cứu A", "expected_version": 1, "idempotency_key": "TEST-FOREIGN-CHAT", "artifact_id": aid}).status_code == 404
        for collection in ("conversations", "cases", "runs"):
            assert b.get("/api/" + collection).json() == []
        auth = LocalAuth(Store(server.data_dir / "business.sqlite3"), server.data_dir)
        pb = auth.device_principal(b.cookies.get("nmate_device"))
        raw_token = auth.create_session(pb)["mcp_token"]
        async with httpx2.AsyncClient(headers={"Authorization": "Bearer " + raw_token}, trust_env=False) as http:
            async with Client(streamable_http_client(server.base_url + "/mcp", http_client=http), mode="2026-07-28", cache=None) as client:
                for tool, args in (("nmate_case_get", {"case_id": case["case_id"]}), ("nmate_research_get", {"run_id": rid}),
                                   ("nmate_artifact_get", {"artifact_id": aid})):
                    response = await client.call_tool(tool, args)
                    assert response.is_error and response.structured_content["error"]["code"] == "NOT_FOUND"


def test_http_limits_validation_and_unavailable_tools(server):
    with httpx.Client(base_url=server.base_url) as web:
        assert web.get("/health", headers={"Host": "attacker.invalid"}).status_code == 400
        assert web.get("/api/runs").status_code == 401
        data = web.get("/api/session").json()
        headers = {"X-CSRF-Token": data["csrf_token"]}
        assert web.post("/api/cases", content=b"x" * 66000, headers=headers).status_code == 413
        response = web.post("/api/cases", json={"product": {"sku": "a", "name": "b"}, "org_id": "evil"}, headers=headers)
        assert response.status_code == 422
        response = web.post("/api/mcp/call", json={"name": "nmate_market_research_start", "arguments": {}}, headers=headers)
        assert response.json()["error"]["code"] == "TOOL_NOT_AVAILABLE"


def test_web01_same_origin_assets_without_exposing_project_files(server):
    with httpx.Client(base_url=server.base_url) as web:
        page = web.get("/web/")
        assert page.status_code == 200
        assert "live-research.js" in page.text
        script = web.get("/web/src/live-research.js")
        assert script.status_code == 200
        assert "/api/mcp/call" in script.text
        assert web.get("/web/.env").status_code in (401, 404)
        assert web.get("/web/.git/config").status_code in (401, 404)
        assert web.get("/web/scripts/build.mjs").status_code in (401, 404)
        assert web.get("/web/src/%2e%2e/%2e%2e/.env").status_code in (401, 404)
