"""Free qualification only: no network, grants on live DBs, or paid recovery."""

import json
import pytest
from nmate.v03.core import CoreError


def item(key, text="Chưa có đủ nguồn"):
    return dict(id=key, text=text, status="gap", evidence=[], gap="Thiếu toàn văn hiện hành")


def artifact(kind="overview_faq"):
    base = dict(contract_version="policy-demo/1", kind=kind, title="THỬ NGHIỆM chính sách")
    if kind == "overview_faq":
        return base | dict(
            overview=[item("overview")],
            faq=[item("faq" + str(i)) | dict(question="Câu hỏi " + str(i) + "?") for i in range(5)],
        )
    if kind == "checklist":
        return base | dict(
            actions=[
                item("action" + str(i)) | dict(inputs=["Cần xác minh"], output="Danh sách câu hỏi")
                for i in range(5)
            ]
        )
    return base | dict(
        findings=[item("finding1") | dict(target_id="faq0", severity="major")],
        assessed_target_ids=["faq0"],
        unassessed=["faq1"],
    )


def test_demo_contract_requires_five_faq_and_actionable_checklist():
    from nmate.knowledge_v1.demo_artifacts import validate_artifact

    validate_artifact(artifact())
    validate_artifact(artifact("checklist"))
    broken = artifact()
    broken["faq"].pop()
    with pytest.raises(CoreError):
        validate_artifact(broken)
    broken = artifact("checklist")
    broken["actions"][0]["inputs"] = []
    with pytest.raises(CoreError):
        validate_artifact(broken)


def test_gap_cannot_smuggle_supported_claim_or_duplicate_item_identity():
    from nmate.knowledge_v1.demo_artifacts import validate_artifact

    broken = artifact()
    broken["faq"][0]["status"] = "supported"
    with pytest.raises(CoreError):
        validate_artifact(broken)
    broken = artifact()
    broken["faq"][0]["id"] = "overview"
    with pytest.raises(CoreError):
        validate_artifact(broken)


def test_execution_tiers_are_bounded_and_frozen_in_canonical_manifest():
    from nmate.core_v1.execution_profiles import compile_profile
    from nmate.core_v1.model_contract import canonical_request

    base = dict(
        payload={"test": True},
        output_schema={"type": "object"},
        purpose="policy_knowledge_build",
        role="complex",
        profile_version="complex/1",
        model="claude-opus-5-5",
        max_output_tokens=1024,
        dependencies={},
    )
    legacy = canonical_request(**base)
    high = compile_profile("complex", "high", input_upper=10000)
    assert high["cap_microusd"] == 500000 and high["max_output_tokens"] > 3072
    assert (
        compile_profile("complex", "low", input_upper=10000)["max_output_tokens"] < high["max_output_tokens"]
    )
    new = canonical_request(
        **(base | {"max_output_tokens": high["max_output_tokens"]}), execution_profile=high
    )
    assert new["manifest"]["execution_profile"] == high and new["request_hash"] != legacy["request_hash"]
    assert "execution_profile" not in legacy["manifest"] and "execution_profile" not in legacy["body"]
    with pytest.raises(CoreError):
        compile_profile("complex", "low", input_upper=100000)


def test_profile_read_uses_original_price_version_not_current_defaults(monkeypatch):
    from nmate.core_v1.execution_profiles import compile_profile, validate_profile
    from nmate.core_v1 import gateway

    original = compile_profile("complex", "high", input_upper=10000)
    monkeypatch.setattr(gateway, "PRICE_VERSION", "future-prices-test-only")
    monkeypatch.setattr(
        gateway, "PROFILES", {"complex": dict(model="new-test", input_rate="100", output_rate="100")}
    )
    assert validate_profile(original, "complex") == original
    with pytest.raises(CoreError):
        validate_profile({k: v for k, v in original.items() if k != "price_version"}, "complex")


@pytest.mark.asyncio
async def test_completion_receipt_persists_stop_reason_with_raw_before_reject(domain):
    from test_knowledge_m3_domain_gateway import invoke

    g, _, _, _, _, _, _, calls = domain

    async def incomplete(model, body, limit):
        calls.append("one")
        return dict(
            model=model,
            text='{"draft":"unfinished',
            stop_reason="max_tokens",
            usage=dict(input_tokens=100, output_tokens=limit),
            thinking="MUST NOT STORE",
        )

    g.request_fn = incomplete
    with pytest.raises(CoreError):
        await invoke(domain)
    with g.repo.connection() as db:
        event = json.loads(
            db.execute(
                "SELECT detail_json FROM core_domain_model_events WHERE kind='response_received'"
            ).fetchone()[0]
        )
        rejected = json.loads(
            db.execute(
                "SELECT detail_json FROM core_domain_model_events WHERE kind='output_rejected'"
            ).fetchone()[0]
        )
        assert event["completion"]["stop_reason"] == "max_tokens"
        assert event["completion"]["visible_text_length"] == 20
        assert rejected["reason_code"] == "OUTPUT_INCOMPLETE"
        assert "MUST NOT STORE" not in "\n".join(db.iterdump())
    assert len(calls) == 1


# Import existing fixtures explicitly: pytest does not discover other test files.
from test_knowledge_m3_domain_gateway import domain
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb
