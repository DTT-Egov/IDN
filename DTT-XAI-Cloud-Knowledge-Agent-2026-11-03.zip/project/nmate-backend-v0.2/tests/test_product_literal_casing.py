"""Case restoration never weakens literal quote grounding; offline model fixtures."""
import pytest

from test_conversations import fact, output, send, setup


async def test_repeated_product_in_message_uses_exact_quote_casing(tmp_path):
    service, _, body = setup(tmp_path, output([fact("product.name", "trà sen tây hồ", "Trà Sen Tây Hồ")]))
    body = await send(service, body, "Tôi làm Trà Sen Tây Hồ. Nhãn cho Trà Sen Tây Hồ cần gì?")
    assert body["pending_proposal"]["product"]["name"] == "Trà Sen Tây Hồ"
    assert body["messages"][-2]["content"] == "Tôi làm Trà Sen Tây Hồ. Nhãn cho Trà Sen Tây Hồ cần gì?"


async def test_sku_casing_is_restored_only_from_exact_quote(tmp_path):
    service, _, body = setup(tmp_path, output([fact("product.name", "trà sen", "Trà Sen"), fact("product.sku", "ts-A01", "TS-A01")]))
    body = await send(service, body, "Tôi làm Trà Sen, SKU TS-A01.")
    assert body["pending_proposal"]["product"]["sku"] == "TS-A01"


async def test_existing_fold_grounding_keeps_exact_user_diacritics_for_minimal_name_quote(tmp_path):
    service, _, body = setup(tmp_path, output([fact("product.name", "tra sen tay ho", "Trà Sen Tây Hồ")]))
    body = await send(service, body, "Tôi làm Trà Sen Tây Hồ.")
    assert body["pending_proposal"]["product"]["name"] == "Trà Sen Tây Hồ"


@pytest.mark.parametrize("quote", ["Trà Sen không có trong tin", "Trà Sen".upper()])
async def test_invented_or_case_changed_source_quote_still_rejected(tmp_path, quote):
    service, _, body = setup(tmp_path, output([fact("product.name", "trà sen", quote)]))
    with pytest.raises(Exception) as error:
        await send(service, body, "Tôi làm Trà Sen.")
    assert getattr(error.value, "code", None) == "MODEL_OUTPUT_INVALID"
