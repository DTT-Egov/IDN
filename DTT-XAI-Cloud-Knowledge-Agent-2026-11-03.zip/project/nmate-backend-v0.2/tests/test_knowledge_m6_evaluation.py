"""Frozen synthetic evaluation corpus, never a legal or AI quality benchmark."""
from pathlib import Path
import json
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed
from test_knowledge_m4_serving import serving,release
from nmate.knowledge_v1.evaluation_m6 import evaluate
from nmate.v03.core import CoreError

def questions():return json.loads((Path(__file__).parent/'data/knowledge_m6_questions.json').read_text(encoding='utf8'))

def test_thirty_distinct_questions_and_100_reuses_are_no_write_or_model(serving):
    repo,g,s,author,expert,page,customer,_=serving;release(serving)
    with repo.connection() as db:before=list(db.iterdump())
    result=evaluate(repo,customer['account_id'],questions(),source_ids=['KB-TEST-A'],repeat_reads=100)
    assert result['question_count']==30 and result['unique_question_count']==30
    assert result['intent_matches']==30 and result['reuse_reads']==100
    assert result['model_calls']==0 and result['legal_quality']=='not_evaluable'
    assert result['expert_review_minutes'] is None and result['maintenance_minutes'] is None
    assert result['model_mode']=='none_retrieval_only' and result['answer_quality_score'] is None
    assert result['data_unchanged'] and result['db_writes']==0
    assert all(row['B']['wiki_goals']==[v for v in row['goals'] if v=='workforce_training'] for row in result['questions'])
    with repo.connection() as db:assert list(db.iterdump())==before

def test_revoke_does_not_leak_source_or_wiki_in_evaluation(serving):
    repo,g,s,author,expert,page,customer,_=serving;release(serving)
    g.set_source_rights(author,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,reason='TEST revoke',operation_id='test-m6-revoke')
    with pytest.raises(CoreError):evaluate(repo,customer['account_id'],questions(),source_ids=['KB-TEST-A'],repeat_reads=1)

def test_withdraw_is_measured_as_gap_not_cached_current_release(serving):
    repo,g,s,author,expert,page,customer,_=serving;r=release(serving)
    g.withdraw_wiki(expert,page['page_id'],expected_release_id=r['release_event_id'],rationale='TEST ONLY',operation_id='test-m6-withdraw')
    result=evaluate(repo,customer['account_id'],questions(),source_ids=['KB-TEST-A'],repeat_reads=1)
    assert all(not row['B']['wiki_goals'] for row in result['questions'])
    assert result['model_calls']==0 and result['legal_quality']=='not_evaluable'
