"""Migrate a false intake blocker from stored model intent; never call AI again."""
import json

import pytest

from nmate.main.plan_recovery import recover_nonblocking_intake_gaps
from test_unified_main import setup as setup_fixture, docs, scope
from test_v03_live_review import TEA


@pytest.fixture(name="workspace")
def recovery_workspace(tmp_path):
    return setup_fixture.__wrapped__(tmp_path)


async def legacy_waiting(workspace, *, server_conflict=False):
    repo, owner, _, model, _, _, _, chat = workspace
    conv = await docs(workspace)
    product = conv["intake"]["product"]["id"]
    value = await chat.send_async(*scope(owner), TEA, [], "legacy-gaps-p1", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    mid = value["active_mission_id"]
    with repo.connection(write=True) as db:
        old = json.loads(db.execute("SELECT output_json FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (mid,)).fetchone()[0])
        old["ambiguities"] = ["Ảnh cũ ghi 120 g nhưng hồ sơ đã xác nhận 100 g."]
        db.execute("UPDATE v03_live_review_outputs SET output_json=? WHERE mission_id=? AND kind='intake'", (json.dumps(old), mid))
        payload = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mid,)).fetchone()[0])
        payload["intent"]["ambiguities"] = old["ambiguities"] + (["Tên sản phẩm khác hồ sơ đang chọn."] if server_conflict else [])
        payload["intent"].pop("preliminary_information_gaps", None)
        db.execute("UPDATE v03_missions SET status='waiting_input',payload_json=? WHERE id=?", (json.dumps(payload), mid))
    return mid, json.dumps(old), product


@pytest.mark.asyncio
async def test_recover_original_explicit_plan_without_model_or_ssot_mutation(workspace):
    repo, owner, _, model, provider, missions, _, _ = workspace
    mid, original, _ = await legacy_waiting(workspace)
    context = repo.get_context(*scope(owner))
    assert recover_nonblocking_intake_gaps(repo) == [mid]
    view = missions.get(*scope(owner), mid)
    assert view["status"] == "planned" and view["intent"]["ambiguities"] == []
    assert view["intent"]["preliminary_information_gaps"] == ["Ảnh cũ ghi 120 g nhưng hồ sơ đã xác nhận 100 g."]
    assert view["plan_recovery"]["model_calls"] == view["plan_recovery"]["ssot_writes"] == 0
    with repo.connection() as db:
        assert db.execute("SELECT output_json FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (mid,)).fetchone()[0] == original
    assert repo.get_context(*scope(owner))["context_hash"] == context["context_hash"]
    assert len(model.calls) == provider.summary()["paid_calls"] == 2
    assert recover_nonblocking_intake_gaps(repo) == []


@pytest.mark.asyncio
async def test_deterministic_product_guard_is_never_cleared(workspace):
    repo, _, _, model, _, _, _, _ = workspace
    await legacy_waiting(workspace, server_conflict=True)
    assert recover_nonblocking_intake_gaps(repo) == [] and len(model.calls) == 2


@pytest.mark.asyncio
async def test_changed_ssot_snapshot_never_promoted(workspace):
    repo, owner, _, model, _, missions, _, _ = workspace
    mid, _, product = await legacy_waiting(workspace)
    entity = repo.get_entity(*scope(owner), product)
    repo.propose_or_apply_facts(*scope(owner), product, [{"field": "net_quantity", "value": "200 g", "source": {"owner_confirmed": True}}], entity["version"], "legacy-gaps-change")
    assert recover_nonblocking_intake_gaps(repo) == []
    assert missions.get(*scope(owner), mid)["status"] != "planned" and len(model.calls) == 2


@pytest.mark.asyncio
async def test_attempted_research_cannot_be_recovered_or_replayed(workspace):
    repo, _, _, model, _, _, _, _ = workspace
    mid, _, _ = await legacy_waiting(workspace)
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_task_attempts SET state='running' WHERE mission_id=?", (mid,))
    assert recover_nonblocking_intake_gaps(repo) == [] and len(model.calls) == 2
