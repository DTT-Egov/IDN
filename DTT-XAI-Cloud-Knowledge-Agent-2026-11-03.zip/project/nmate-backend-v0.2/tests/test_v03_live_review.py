"""No network or paid calls: test the isolated live-review adapter with a stub."""
import asyncio
import copy
import json

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_review import LiveReviewMissionService, validate_intake, validate_research
from nmate.v03.live_provider import ReviewProvider


TEA = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh."


def intake(question=TEA):
    return {"scope": "us_food", "outcomes": [
        {"id": "registration", "question_quote": "đăng ký cơ sở FDA"},
        {"id": "label", "question_quote": "nhãn tiếng Anh"},
    ], "product_name": "Trà Sen Tây Hồ", "product_quote": "Trà Sen Tây Hồ", "ambiguities": []}


def research(payload):
    records = payload["input"]["reference_records"]
    answers, actions = [], []
    for outcome in payload["input"]["outcomes"]:
        oid = outcome["id"]
        topic = {"registration": "facility_registration", "label": "food_label"}.get(oid)
        record = next((r for r in records if topic in r["topics"]), None)
        answers.append({"outcome_id": oid, "status": ("artifact_ready" if oid == "label" else "answered_general") if record else "blocked_source", "text": "Theo nguồn đã lưu, cần đối chiếu phạm vi và ngoại lệ; chưa đủ dữ kiện để kết luận riêng.", "details_vi": "Trích đoạn tham khảo chưa được chuyên gia duyệt; dữ kiện doanh nghiệp tự khai.", "citations": [{"source_id": record["id"], "quote_en": record["excerpt"]}] if record else [], "missing_fields": []})
        if topic:
            actions.append({"id": f"action-{oid}", "title": "Điền khung nhãn tiếng Anh" if oid == "label" else "Bổ sung dữ kiện cơ sở", "kind": "edit_label" if oid == "label" else "supply_facts", "outcome_ids": [oid], "reason": "Để hoàn thành đúng ý người dùng hỏi."})
    return {"answers": answers, "actions": actions}


class ModelStub:
    def __init__(self):
        self.calls = []
        self.intake_transform = lambda result: result
        self.research_transform = lambda result: result
        self.delay = 0
        self.research_started = asyncio.Event()

    async def __call__(self, kind, payload, **scope):
        self.calls.append((kind, payload, scope))
        if kind == "research":
            self.research_started.set()
        if self.delay:
            await asyncio.sleep(self.delay)
        result = self.intake_transform(intake()) if kind == "intake" else self.research_transform(research(payload))
        return {"data": result, "attempt_id": f"stub-{len(self.calls)}", "model": "fake-for-tests", "usage": {"input_tokens": 10, "output_tokens": 10}, "request_id": "fake-request", "api_key": "SHOULD-NOT-PERSIST"}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "live.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("owner", "TestPassword12345", "Doanh nghiệp Sen")
    other = accounts.register("other", "TestPassword12345", "Doanh nghiệp khác")
    model = ModelStub()
    service = LiveReviewMissionService(repo, model_call=model)
    return repo, owner, other, model, service


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


async def complete(service, owner, key="one"):
    prepared = await service.prepare_async(*args(owner), TEA, f"p-{key}")
    service.start(*args(owner), prepared["id"], f"s-{key}")
    assert await service.execute_next()
    return service.get(*args(owner), prepared["id"])


@pytest.mark.asyncio
async def test_real_dag_two_model_stages_grounded_sources_and_deterministic_empty_label(setup):
    repo, owner, _, model, service = setup
    mission = await complete(service, owner)
    assert [c[0] for c in model.calls] == ["intake", "research"]
    assert mission["mode"] == "live_claude_review"
    assert mission["intent"]["interpretation_mode"] == "claude_validated_intake"
    assert mission["status"] == "completed_partial"
    assert mission["cost"]["paid_calls"] == 2
    assert all(t["status"] == "succeeded" for t in mission["plan"]["tasks"])
    assert all(f["value"] is None for f in mission["label"]["fields"])
    assert len(mission["answers"]) == 2 and all(a["citations"] for a in mission["answers"])
    assert "SHOULD-NOT-PERSIST" not in str(mission)
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_review_outputs").fetchone()[0] == 2
    assert model.calls[1][2]["enterprise_id"] == owner["enterprise_id"]


@pytest.mark.asyncio
async def test_idempotent_prepare_and_start_never_redispatch_on_reload(setup):
    _, owner, _, model, service = setup
    mission = await complete(service, owner)
    assert (await service.prepare_async(*args(owner), TEA, "p-one"))["id"] == mission["id"]
    service.start(*args(owner), mission["id"], "extra-start")
    assert not await service.execute_next()
    assert service.get(*args(owner), mission["id"])["cost"]["paid_calls"] == 2
    assert len(model.calls) == 2


@pytest.mark.asyncio
async def test_concurrent_same_operation_uses_one_intake_not_one_per_request(setup):
    _, owner, _, model, service = setup
    model.delay = 0.015
    values = await asyncio.gather(*[service.prepare_async(*args(owner), TEA, "parallel") for _ in range(3)])
    assert len({v["id"] for v in values}) == 1
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_cross_enterprise_read_and_intake_denied_before_callback(setup):
    _, owner, other, model, service = setup
    mission = await complete(service, owner)
    with pytest.raises(CoreError):
        service.get(*args(other), mission["id"])
    with pytest.raises(CoreError):
        await service.prepare_async(other["account_id"], owner["enterprise_id"], TEA, "spoof")
    assert len(model.calls) == 2


@pytest.mark.parametrize("mutate", [
    lambda d: d.update(product_name="Trà sen tây hồ cao cấp"),
    lambda d: d.update(product_quote=None),
    lambda d: d["outcomes"][0].update(question_quote="Không nằm trong câu hỏi"),
    lambda d: d["outcomes"].append(d["outcomes"][0]),
    lambda d: d.update(extra_field="forbidden"),
])
def test_intake_rejects_hallucination_different_product_duplicate_or_extra(mutate):
    data = intake()
    mutate(data)
    with pytest.raises(CoreError):
        validate_intake({"data": data}, TEA)


def test_intake_rejects_markets_overridden_by_old_us_context():
    data = intake()
    with pytest.raises(CoreError):
        validate_intake({"data": data}, TEA + " Nhưng lô này sang Nhật.")


@pytest.mark.asyncio
async def test_clarification_is_waiting_input_and_cannot_launch_research(setup):
    _, owner, _, model, service = setup
    model.intake_transform = lambda d: {**d, "outcomes": [{"id": "clarification", "question_quote": "cần tìm hiểu"}], "ambiguities": []}
    question = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu thêm."
    mission = await service.prepare_async(*args(owner), question, "ambiguous")
    assert mission["status"] == "waiting_input" and mission["intent"]["ambiguities"]
    with pytest.raises(CoreError):
        service.start(*args(owner), mission["id"], "cannot-start")
    assert not await service.execute_next()
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_structural_or_quote_failure_stops_without_publish_or_retry(setup):
    _, owner, _, model, service = setup
    model.research_transform = lambda d: {**d, "answers": [{**d["answers"][0], "citations": [{"source_id": d["answers"][0]["citations"][0]["source_id"], "quote_en": "This sentence was invented by the model."}]}, d["answers"][1]]}
    mission = await complete(service, owner)
    assert mission["status"] == "failed"
    assert not mission["answers"] and not mission["artifacts"]
    assert "Trích dẫn" in mission["stale_reason"]
    assert "giả lập" not in mission["stale_reason"]
    assert not await service.execute_next()
    assert len(model.calls) == 2


@pytest.mark.asyncio
async def test_research_cannot_omit_one_asked_outcome_or_cite_wrong_topic(setup):
    _, owner, _, model, service = setup
    prepared = await service.prepare_async(*args(owner), TEA, "validate")
    mission = service._internal(prepared["id"])
    valid = research({"input": {"reference_records": mission["knowledge"]["records"], "outcomes": mission["intent"]["outcomes"]}})
    omitted = copy.deepcopy(valid)
    omitted["answers"].pop()
    with pytest.raises(CoreError):
        validate_research({"data": omitted}, mission)
    wrong_topic = copy.deepcopy(valid)
    wrong_topic["answers"][0]["citations"] = copy.deepcopy(valid["answers"][1]["citations"])
    with pytest.raises(CoreError, match="chưa phù hợp với ý") as topic_error:
        validate_research({"data": wrong_topic}, mission)
    assert topic_error.value.code == "live_output_invalid"
    wrong_quote = copy.deepcopy(valid)
    wrong_quote["answers"][0]["citations"][0]["quote_en"] = "This exact quote does not exist in the permitted record."
    with pytest.raises(CoreError, match="khớp nguyên văn") as quote_error:
        validate_research({"data": wrong_quote}, mission)
    assert quote_error.value.code == "live_output_invalid"
    assert len(model.calls) == 1


@pytest.mark.asyncio
async def test_fact_change_while_paid_synthesis_inflight_blocks_publication(setup):
    _, owner, _, model, service = setup
    prepared = await service.prepare_async(*args(owner), TEA, "race")
    model.delay = 0.06
    service.start(*args(owner), prepared["id"], "race-start")
    running = asyncio.create_task(service.execute_next())
    await asyncio.wait_for(model.research_started.wait(), timeout=3)
    service.update_facts(*args(owner), prepared["id"], [{"field": "net_quantity", "value": "100 g"}], prepared["product"]["version"], "race-fact")
    await running
    current = service.get(*args(owner), prepared["id"])
    assert current["status"] == "needs_revalidation"
    assert not current["answers"] and not current["artifacts"]
    assert len(model.calls) == 2 and not await service.execute_next()


@pytest.mark.asyncio
async def test_already_known_ssot_field_not_asked_again(setup):
    _, owner, _, _, service = setup
    prepared = await service.prepare_async(*args(owner), TEA, "known")
    service.update_facts(*args(owner), prepared["id"], [{"field": "facility_type", "value": "Đóng gói"}], prepared["product"]["version"], "fact")
    # A fresh context is required after the deliberate correction.
    next_mission = await service.prepare_async(*args(owner), TEA, "known-new", prepared["product"]["entity_id"])
    internal = service._internal(next_mission["id"])
    valid = research({"input": {"reference_records": internal["knowledge"]["records"], "outcomes": internal["intent"]["outcomes"]}})
    valid["answers"][0]["missing_fields"] = ["facility_type"]
    with pytest.raises(CoreError, match="SSOT"):
        validate_research({"data": valid}, internal)


@pytest.mark.asyncio
async def test_recovery_is_honest_about_paid_uncertain_state_and_never_replays(setup):
    repo, owner, _, model, service = setup
    prepared = await service.prepare_async(*args(owner), TEA, "crash")
    service.start(*args(owner), prepared["id"], "crash-start")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_missions SET status='running' WHERE id=?", (prepared["id"],))
    assert service.recover_interrupted() == 1
    current = service.get(*args(owner), prepared["id"])
    assert current["status"] == "failed" and "không tự gửi lại" in current["stale_reason"]
    assert not await service.execute_next() and len(model.calls) == 1


@pytest.mark.asyncio
async def test_unsupported_source_gap_does_not_pay_to_guess(setup):
    _, owner, _, model, service = setup
    text = "Tôi có Trà Sen Tây Hồ gửi New York, cần chứng nhận gì?"
    model.intake_transform = lambda d: {**d, "outcomes": [{"id": "certification", "question_quote": "chứng nhận"}]}
    mission = await service.prepare_async(*args(owner), text, "prior")
    assert mission["research_scope"]["can_start_research"] is False
    with pytest.raises(CoreError) as error:
        service.start(*args(owner), mission["id"], "prior-start")
    assert error.value.code == "research_source_gap"
    assert not await service.execute_next()
    result = service.get(*args(owner), mission["id"])
    assert result["status"] == "planned"
    assert result["answers"] == []
    assert len(model.calls) == 1 and result["cost"]["paid_calls"] == 1


@pytest.mark.asyncio
async def test_provider_exception_after_dispatch_not_replayed_by_second_parallel_node(setup):
    _, owner, _, model, service = setup
    mission = await service.prepare_async(*args(owner), TEA, "timeout")

    async def failing_call(kind, payload, **scope):
        model.calls.append((kind, payload, scope))
        raise TimeoutError("Private raw provider trace MUST NOT BE PUBLIC")

    service.model_call = failing_call
    service.start(*args(owner), mission["id"], "timeout-start")
    assert await service.execute_next()
    stopped = service.get(*args(owner), mission["id"])
    assert stopped["status"] == "failed"
    assert "Private raw" not in str(stopped)
    assert len(model.calls) == 2 and not await service.execute_next()


@pytest.mark.asyncio
@pytest.mark.parametrize("failure", ["quote", "json"])
async def test_provider_ledger_counts_failed_or_rejected_paid_output_and_restart_does_not_replay(setup, failure):
    """The callback ledger, rather than validated output count, is billing SSOT.

    This tests the provider and adapter together without a provider SDK/network.
    The dedicated runner overlays this ledger on the public mission separately.
    """
    repo, owner, _, _, _ = setup
    requests = []

    async def request_fn(model, payload, output_limit):
        requests.append((model, output_limit))
        if output_limit == 2500:
            output = json.dumps(intake(), ensure_ascii=False)
        elif failure == "json":
            output = "This response is not valid JSON."
        else:
            result = research(payload)
            result["answers"][0]["citations"][0]["quote_en"] = "The model invented this unsupported sentence."
            output = json.dumps(result, ensure_ascii=False)
        return {"text": output, "model": model, "request_id": f"test-request-{len(requests)}",
                "stop_reason": "end_turn", "usage": {"input_tokens": 100, "output_tokens": 50}}

    provider = ReviewProvider(repo, request_fn=request_fn)
    service = LiveReviewMissionService(repo, model_call=provider)
    mission = await complete(service, owner, key="ledger")
    assert mission["status"] == "failed" and not mission["answers"] and not mission["artifacts"]
    assert len(requests) == 2
    # The intake can only be bound once its mission has been created.
    provider.bind_attempts(*args(owner), mission["id"], [c["attempt_id"] for c in mission["cost"]["calls"]])
    ledger = provider.summary(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"], mission_id=mission["id"])
    assert mission["cost"]["paid_calls"] == 1  # One output passed adapter validation.
    assert ledger["paid_calls"] == ledger["provider_attempts"] == 2
    assert len(ledger["attempts"]) == 2 and ledger["estimated_usd"] > 0
    assert ledger["completed_provider_calls"] == (2 if failure == "quote" else 1)
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_review_outputs WHERE mission_id=?", (mission["id"],)).fetchone()[0] == 1
        assert db.execute("SELECT state FROM v03_live_review_stages WHERE mission_id=?", (mission["id"],)).fetchone()[0] == "stopped_no_replay"

    restarted_provider = ReviewProvider(CoreRepository(repo.db_path), request_fn=request_fn)
    assert restarted_provider.recover() == 0
    restarted = LiveReviewMissionService(restarted_provider.repo, model_call=restarted_provider)
    assert restarted.recover_interrupted() == 0
    assert not await restarted.execute_next()
    with pytest.raises(CoreError):
        restarted.start(*args(owner), mission["id"], "no-replay-start")
    assert len(requests) == 2
    assert restarted_provider.summary(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"], mission_id=mission["id"])["provider_attempts"] == 2


@pytest.mark.asyncio
async def test_research_contract_enumerates_excerpt_ids_and_removes_competing_page_identity(setup):
    from anthropic import transform_schema

    _, owner, _, model, service = setup
    mission = await complete(service, owner)
    payload = next(call[1] for call in model.calls if call[0] == "research")
    records = payload["input"]["reference_records"]
    enum = payload["response_schema"]["$defs"]["Citation"]["properties"]["source_id"]["enum"]
    expected = sorted(r["id"] for r in mission["knowledge"]["records"] if r["reusable"] is True)
    assert enum == expected
    assert sorted(r["id"] for r in records) == expected
    assert all("source_id" not in r and "page_source_id" not in r for r in records)
    assert all(r["source_id"] not in enum for r in mission["knowledge"]["records"])
    # Provenance remains complete in the authoritative snapshot, not rewritten.
    assert all(r["source_id"] for r in mission["knowledge"]["records"])
    assert "reference_records[].id" in payload["response_schema"]["$defs"]["Citation"]["properties"]["source_id"]["description"]
    transport_schema = transform_schema(payload["response_schema"])
    assert transport_schema["$defs"]["Citation"]["properties"]["source_id"]["enum"] == expected

    response = research(payload)
    internal = service._internal(mission["id"])
    assert len(validate_research({"data": response}, internal).answers) == 2
    response["answers"][0]["citations"][0]["source_id"] = next(
        r["source_id"] for r in internal["knowledge"]["records"]
        if r["id"] == response["answers"][0]["citations"][0]["source_id"])
    with pytest.raises(CoreError, match="gắn nhầm nguồn trích dẫn") as identity_error:
        validate_research({"data": response}, internal)
    assert identity_error.value.code == "live_output_invalid"
