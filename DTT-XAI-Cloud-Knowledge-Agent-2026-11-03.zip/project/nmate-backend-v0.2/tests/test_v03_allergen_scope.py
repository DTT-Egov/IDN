"""Product allergen facts are distinct from each market's label declaration."""
import json

import pytest

from nmate.v03.core import CoreError
from nmate.v03.live_review import ssot_context_projection
from test_ssot_field_scope import legacy_fact
from test_v03b_market_missions import setup as setup, complete, save, args, field_values


def product_with_allergen(repo, owner):
    product = repo.create_entity(*args(owner), "product", "Trà Sen Tây Hồ")
    repo.propose_or_apply_facts(*args(owner), product["id"], [{"field": "allergens", "value": ["Vừng"]}], 0, "product-allergen-fact")
    return repo.get_entity(*args(owner), product["id"])


@pytest.mark.parametrize("code,text", [("US", "Contains sesame"), ("DE", "Enthält Sesam"), ("JP", "ごまを含む")])
def test_market_prepare_and_fact_update_never_reinterpret_product_allergen(code, text, setup):
    repo, owner, _, service = setup
    product = product_with_allergen(repo, owner)
    before_history = repo.get_fact_history(*args(owner), product["id"])
    mission = complete(service, owner, code, product=product["id"])
    assert field_values(mission)["allergens"] is None
    assert mission["market_profile"]["facts"] == []
    assert mission["context"]["shared_values"]["allergens"] == ["Vừng"]
    assert "allergens" not in mission["context"]["values"]
    assert repo.get_fact_history(*args(owner), product["id"]) == before_history
    updated = service.update_facts(*args(owner), mission["id"], [{"field": "allergens", "value": text}],
        mission["product"]["version"], "market-allergen-update", expected_market_profile_version=0)
    assert updated["market_profile"]["values"] == {"allergen_declaration": text}
    assert updated["current_context"]["values"]["allergens"] == text
    assert updated["current_context"]["shared_values"]["allergens"] == ["Vừng"]
    projection = ssot_context_projection(updated["current_context"])
    assert projection["values"]["allergens"] == projection["values"]["allergen_declaration"] == text
    assert projection["label_fact_aliases"] == {"allergens": "allergen_declaration"}
    assert repo.get_fact_history(*args(owner), product["id"]) == before_history
    assert all(ref["entity_id"] == updated["market_profile"]["entity_id"] for ref in
               updated["current_context"]["fact_refs"] if ref["field"] == "allergen_declaration")
    different = "JP" if code != "JP" else "US"
    other = complete(service, owner, different, "other-market", product=product["id"])
    assert field_values(other)["allergens"] is None and other["market_profile"]["facts"] == []


@pytest.mark.parametrize("code,text", [("US", "Contains sesame"), ("DE", "Enthält Sesam"), ("JP", "ごまを含む")])
def test_label_memory_uses_canonical_market_fact_preserves_cas_idempotency_and_lineage(code, text, setup):
    repo, owner, _, service = setup
    product = product_with_allergen(repo, owner)
    before_history = repo.get_fact_history(*args(owner), product["id"])
    mission = complete(service, owner, code, product=product["id"])
    saved = save(service, owner, mission, {"allergens": text}, ["allergens"], "remember-allergen")
    repeated = save(service, owner, mission, {"allergens": text}, ["allergens"], "remember-allergen")
    assert repeated["label"]["version"] == saved["label"]["version"] == 2
    assert field_values(saved)["allergens"] == text
    assert saved["market_profile"]["values"] == {"allergen_declaration": text}
    assert saved["product"]["version"] == mission["product"]["version"]
    assert repo.get_fact_history(*args(owner), product["id"]) == before_history
    with pytest.raises(CoreError) as stale:
        save(service, owner, mission, {"allergens": "Changed"}, ["allergens"], "stale-new-operation")
    assert stale.value.code == "version_conflict"
    continued = complete(service, owner, code, "continue-allergen", parent=mission["id"])
    assert field_values(continued)["allergens"] == text
    assert continued["label"]["parent_artifact_ref"]["artifact_id"] == saved["label"]["id"]
    assert not continued["label"]["conflicts"]
    with repo.connection() as db:
        original = json.loads(db.execute("SELECT data_json FROM v03_artifact_revisions WHERE id=? AND version=1",
                                         (mission["label"]["id"],)).fetchone()[0])
        assert next(field["value"] for field in original["fields"] if field["id"] == "allergens") is None
        assert db.execute("SELECT COUNT(*) FROM v03_product_markets WHERE product_id=?", (product["id"],)).fetchone()[0] == 1


def test_old_wrong_market_allergens_are_quarantined_and_original_draft_stays(setup):
    repo, owner, _, service = setup
    mission = complete(service, owner)
    draft = save(service, owner, mission, {"allergens": "Old draft phrase"}, [], "draft-only")
    legacy_fact(repo, owner, mission["market_profile"]["entity_id"], "allergens", "Old wrongly scoped phrase")
    current = service.get(*args(owner), mission["id"])
    assert field_values(current)["allergens"] == "Old draft phrase"
    assert "allergens" not in current["market_profile"]["values"]
    assert "allergen_declaration" not in current["market_profile"]["values"]
    assert "Old wrongly scoped phrase" not in str(current["current_context"])
    entity = repo.get_entity(*args(owner), mission["market_profile"]["entity_id"])
    assert entity["facts"] == [] and entity["invalid_facts"][0]["field"] == "allergens"
    assert current["label"]["version"] == draft["label"]["version"]


def test_null_unknown_and_explicit_absence_never_infer_no_allergens(setup):
    repo, owner, _, service = setup
    product = product_with_allergen(repo, owner)
    mission = complete(service, owner, product=product["id"])
    product_history = repo.get_fact_history(*args(owner), product["id"])
    unchanged = service.update_facts(*args(owner), mission["id"], [{"field": "allergen_declaration", "value": None}],
        mission["product"]["version"], "unknown-declaration", expected_market_profile_version=0)
    assert unchanged["market_profile"]["facts"] == []
    absent = service.update_facts(*args(owner), mission["id"], [{"field": "allergen_declaration", "value": None, "value_state": "known_absent"}],
        mission["product"]["version"], "absent-declaration", expected_market_profile_version=0)
    assert absent["market_profile"]["facts"][0]["value_state"] == "known_absent"
    assert absent["market_profile"]["values"] == {}
    assert "allergens" not in absent["current_context"]["values"]
    assert field_values(absent)["allergens"] is None
    assert repo.get_fact_history(*args(owner), product["id"]) == product_history
    with pytest.raises(CoreError) as denied:
        repo.propose_or_apply_facts(*args(owner), product["id"], [{"field": "allergen_declaration", "value": "No allergens"}],
                                    product["version"], "wrong-product-declaration")
    assert denied.value.code == "invalid_field_scope"


@pytest.mark.parametrize("code", ["DE", "JP"])
def test_fda_status_cannot_be_written_to_non_us_profile(code, setup):
    repo, owner, _, service = setup
    mission = complete(service, owner, code)
    with pytest.raises(CoreError) as denied:
        service.update_facts(*args(owner), mission["id"], [{"field": "fda_registration_status", "value": "Registered"}],
            mission["product"]["version"], "wrong-market-status", expected_market_profile_version=0)
    assert denied.value.code == "invalid_market_field"
    assert repo.get_entity(*args(owner), mission["market_profile"]["entity_id"])["facts"] == []
