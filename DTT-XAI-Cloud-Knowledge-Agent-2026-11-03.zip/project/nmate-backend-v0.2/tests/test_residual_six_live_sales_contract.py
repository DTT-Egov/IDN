"""DF-006/015/024: saved/injected Claude envelopes share bounded sales slots.

No real provider is called; the only async fixture uses an in-process stub.
"""
import copy

import pytest

from nmate.v03.core import CoreError
from nmate.v04.live_review import validate_output
from test_v04_live_review import result, send, services, workspace as shared_workspace


TEXT = "Chị cần tổng hợp bán hàng: tháng 9 bán 120 hộp."


def request(text=TEXT, previous=None):
    return {"messages": [{"role": "user", "text": text}], "files": [], "previous_intent": previous}


def answer(key, value, quote=TEXT):
    return {"key": key, "value": value, "quote": quote, "message_index": 0}


def envelope(text=TEXT, answers=None, **changes):
    return {"data": result(text, focus="sales_reporting", working_answers=answers or [],
        assistant_text="Mình đã nhận số bán; chưa ghi vào hồ sơ.", pending_question="Chị gửi mã sản phẩm và bảng giao dịch nhé.", **changes)}


def test_live_sales_accepts_closed_grounded_count_calendar_and_unit():
    output, slots = validate_output(envelope(answers=[answer("recent_sales_quantity", "120"),
        answer("sales_period", "tháng 9"), answer("quantity_unit", "hộp")]), request())
    assert output.focus == "sales_reporting"
    assert slots == {"recent_sales_quantity": 120, "sales_period": "tháng 9",
        "sales_period_kind": "calendar_month", "quantity_unit": "hộp", "recent_sales_quantity_unit": "hộp",
        "report_period": "tháng 9"}


def test_cached_old_envelope_with_no_new_keys_retains_current_bounded_sales_statement():
    _output, slots = validate_output(envelope(), request())
    assert slots["recent_sales_quantity"] == 120
    assert slots["sales_period"] == "tháng 9"
    assert slots["sales_period_kind"] == "calendar_month"


@pytest.mark.parametrize("text,value", [
    ("Tháng 9 năm 2026 bán 120 hộp.", "tháng 9/2026"),
    ("Tháng 09 bán 120 hộp.", "tháng 9"),
])
def test_live_period_uses_bounded_calendar_identity_without_invented_year(text, value):
    _, slots = validate_output(envelope(text, [answer("sales_period", value, text)]), request(text))
    assert slots["sales_period"] == value
    assert slots["recent_sales_quantity"] == 120


@pytest.mark.parametrize("text,key,value", [
    (TEXT, "recent_sales_quantity", "130"),
    (TEXT, "sales_period", "tháng 10"),
    (TEXT, "sales_period", "tháng 9/2026"),
    (TEXT, "quantity_unit", "kg"),
    ("Tháng 9 bán 120 nghìn đồng.", "recent_sales_quantity", "120"),
    ("Tháng 9 dự kiến bán 120 hộp.", "recent_sales_quantity", "120"),
    ("Tháng 9 chưa bán 120 hộp.", "sales_period", "tháng 9"),
])
def test_live_rejects_wrong_count_period_unit_money_or_target(text, key, value):
    with pytest.raises(CoreError) as exc:
        validate_output(envelope(text, [answer(key, value, text)]), request(text))
    assert exc.value.code in {"LIVE_ANSWER_UNGROUNDED", "LIVE_ANSWER_INVALID"}


def test_sales_slot_cannot_be_attached_to_inventory_focus():
    value = envelope(answers=[answer("recent_sales_quantity", "120")])
    value["data"]["focus"] = "inventory_accuracy"
    with pytest.raises(CoreError) as exc:
        validate_output(value, request())
    assert exc.value.code == "LIVE_ANSWER_INVALID"


def test_new_actual_count_without_period_does_not_borrow_previous_calendar():
    previous = {"primary": "digitize_operations", "focus": "sales_reporting", "working_answers": {
        "recent_sales_quantity": 90, "sales_period": "tháng 8", "sales_period_kind": "calendar_month", "quantity_unit": "hộp"}}
    before = copy.deepcopy(previous)
    text = "Chị bán được 120 hộp."
    _, slots = validate_output(envelope(text), request(text, previous))
    assert previous == before
    assert slots["recent_sales_quantity"] == 120
    assert not slots.get("sales_period")


def test_requested_period_reply_can_complete_known_count_but_not_relabel_known_period():
    previous = {"primary": "digitize_operations", "focus": "sales_reporting", "working_answers": {
        "recent_sales_quantity": 120, "quantity_unit": "hộp"}}
    text = "Tháng 9"
    _, slots = validate_output(envelope(text, [answer("sales_period", "tháng 9", text)]), request(text, previous))
    assert slots["recent_sales_quantity"] == 120 and slots["sales_period"] == "tháng 9"
    previous["working_answers"].update(sales_period="tháng 8", sales_period_kind="calendar_month")
    with pytest.raises(CoreError):
        validate_output(envelope(text, [answer("sales_period", "tháng 9", text)]), request(text, previous))


@pytest.mark.parametrize("text,quote", [
    ("Tháng 9 dự kiến bán 120 hộp.", "bán 120 hộp"),
    ("Tháng 9 chưa bán 120 hộp.", "bán 120 hộp"),
    ("Nếu tháng 9 bán 120 hộp thì sao?", "bán 120 hộp"),
])
def test_truncated_quote_cannot_remove_target_or_negation(text, quote):
    with pytest.raises(CoreError) as exc:
        validate_output(envelope(text, [answer("recent_sales_quantity", "120", quote)]), request(text))
    assert exc.value.code == "LIVE_ANSWER_UNGROUNDED"


@pytest.fixture
def workspace(tmp_path):
    return shared_workspace.__wrapped__(tmp_path)


@pytest.mark.asyncio
async def test_injected_live_flow_keeps_sales_slots_after_reload_without_ssot(workspace):
    repo, owner, _ = workspace
    _provider, intake, chat, stub = services(workspace, [envelope()["data"]])
    before = repo.get_context(owner["account_id"], owner["enterprise_id"])
    value = await send(chat, owner, TEXT, op="residual-sales-envelope")
    slots = value["intake"]["intent"]["working_answers"]
    assert slots["recent_sales_quantity"] == 120 and slots["sales_period"] == "tháng 9"
    assert len(stub.calls) == 1  # In-process JSON fixture, no external model IO.
    reopened = type(chat)(type(intake)(repo, provider=intake.provider))
    assert reopened.get(owner["account_id"], owner["enterprise_id"], value["id"])["intake"]["intent"]["working_answers"] == slots
    after = repo.get_context(owner["account_id"], owner["enterprise_id"])
    assert {key: item for key, item in before.items() if key != "as_of"} == {
        key: item for key, item in after.items() if key != "as_of"}
