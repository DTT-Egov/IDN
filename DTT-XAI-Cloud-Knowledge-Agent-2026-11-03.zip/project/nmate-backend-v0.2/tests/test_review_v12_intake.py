"""Product-bound drafts and local document failures; real SQL, no paid IO."""
import copy
import socket
import unicodedata
from concurrent.futures import ThreadPoolExecutor

import httpx
import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.extraction import extract_product_text
from nmate.v04.intake import IntakeService
from test_core_policy_http import call, good, register, running
from test_review_commands_v2 import data_snapshot
from test_workspace_management import attachment, pdf_bytes


@pytest.fixture(autouse=True)
def local_only_services(monkeypatch):
    from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
    async def no_source_refresh(_self):
        return False
    monkeypatch.setattr(SourceRefreshJobs, "execute_next", no_source_refresh)
    connect, connect_ex = socket.socket.connect, socket.socket.connect_ex
    def guard(original):
        def local(sock, address):
            if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
                return original(sock, address)
            raise AssertionError("Intake checks allow loopback MCP only, no external service")
        return local
    monkeypatch.setattr(socket.socket, "connect", guard(connect))
    monkeypatch.setattr(socket.socket, "connect_ex", guard(connect_ex))


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "review-v12-intake.sqlite3")
    owner = LocalAccounts(repo).register("v12-local-owner", "Only-local-test-password", "Cơ sở QA")
    service = IntakeService(repo)
    return repo, owner, service


def confirm(service, owner, item, operation, edits=None, choices=None):
    selected = [c["id"] for c in item["candidates"] if c["field"] in {"name", "net_quantity"}]
    return service.confirm(*scope(owner), item["id"], selected, item["expected_entity_versions"], operation,
        edits=edits, conflict_choices=choices, expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={key: item["review"]["proposal_hashes"][key] for key in selected})


@pytest.mark.parametrize("text", ["Bột sen khối lượng tịnh 200 g", "Chị có Bột sen khối lượng tịnh 200 g",
                                  "Tên sản phẩm: Bột sen lượng tịnh 200 g"])
def test_quantity_field_caption_is_not_part_of_product_name(text):
    fields = {item["field"]: item for item in extract_product_text(text)}
    assert fields["name"]["value"] == "Bột sen"
    assert fields["net_quantity"]["value"] == "200 g"
    assert fields["name"]["source"]["value_quote"] in text


def test_owner_edit_is_the_created_identity_and_observation_remains_immutable(workspace):
    repo, owner, service = workspace
    item = service.prepare(*scope(owner), "Chị có Bột sen xanh, khối lượng tịnh 200 g", [], "prepare-edited-name")
    name = next(c for c in item["candidates"] if c["field"] == "name")
    before = copy.deepcopy(name)
    saved = confirm(service, owner, item, "confirm-edited-name", edits={name["id"]: "Bột Sen Hoàng Gia"})
    products = repo.list_entities(*scope(owner), "product")
    assert len(products) == 1 and products[0]["name"] == "Bột Sen Hoàng Gia"
    with repo.connection() as db:
        rows = db.execute("SELECT * FROM core_review_proposals WHERE candidate_id=? ORDER BY proposal_revision", (name["id"],)).fetchall()
        assert len(rows) == 2 and rows[0]["proposal_hash"] == before["proposal_hash"]
    assert saved["product"]["name"] == "Bột Sen Hoàng Gia"
    assert repo.find_entities_by_name(*scope(owner), "Bột sen xanh") == []
    assert repo.migrate_name_aliases()["aliases_added"] == 0
    assert repo.find_entities_by_name(*scope(owner), "Bột sen xanh") == []


@pytest.mark.parametrize("edited_name", ["Bột sen", "  BỘT   SEN ", unicodedata.normalize("NFD", "Bột sen")])
def test_edit_to_existing_identity_requires_explicit_binding_without_any_write(workspace, edited_name):
    repo, owner, service = workspace
    product = repo.create_entity(*scope(owner), "product", "Bột sen")
    repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "existing-quantity")
    item = service.prepare(*scope(owner), "Chị có Bột sen xanh, khối lượng tịnh 200 g", [], "prepare-existing-edit")
    name = next(c for c in item["candidates"] if c["field"] == "name")
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as blocked:
        confirm(service, owner, item, "confirm-existing-edit", edits={name["id"]: edited_name})
    assert blocked.value.code == "product_binding_required"
    assert blocked.value.details["matched_entities"] == [{"id": product["id"], "name": "Bột sen", "version": 1}]
    assert data_snapshot(repo) == before
    # An explicit owner-selected target creates a fresh derived draft, then
    # selected conflict resolution is still required before changing SSOT.
    derived = service.prepare(*scope(owner), "Tên sản phẩm: Bột sen; Khối lượng tịnh: 200 g", [], "prepare-explicit-target", product["id"])
    assert derived["product"]["id"] == product["id"]
    assert data_snapshot(repo)["v03_current_facts"] == before["v03_current_facts"]
    quantity = next(c for c in derived["candidates"] if c["field"] == "net_quantity")
    saved = confirm(service, owner, derived, "confirm-explicit-target", choices={quantity["id"]: "incoming"})
    assert saved["product"]["id"] == product["id"]
    assert len(repo.list_entities(*scope(owner), "product")) == 1
    assert [entry["value"] for entry in repo.get_fact_history(*scope(owner), product["id"], "net_quantity")] == ["100 g", "200 g"]


def test_natural_quantity_phrase_reuses_exact_existing_product_and_replay(workspace):
    repo, owner, service = workspace
    existing = repo.create_entity(*scope(owner), "product", "Bột sen")
    item = service.prepare(*scope(owner), "Bột sen khối lượng tịnh 200 g", [], "natural-existing-product")
    assert item["product"]["id"] == existing["id"]
    saved = confirm(service, owner, item, "natural-existing-confirm")
    before = data_snapshot(repo)
    replayed = confirm(service, owner, item, "natural-existing-confirm")
    assert replayed["confirmation_receipt"] == saved["confirmation_receipt"]
    assert data_snapshot(repo) == before and len(repo.list_entities(*scope(owner), "product")) == 1


def test_exact_concurrent_confirmations_create_one_product_and_require_binding_for_loser(workspace):
    repo, owner, service = workspace
    drafts = [service.prepare(*scope(owner), "Chị có Bột sen, khối lượng tịnh 200 g", [], "parallel-prepare-" + str(i)) for i in range(2)]
    def finish(index):
        try:
            return {"saved": confirm(service, owner, drafts[index], "parallel-confirm-" + str(index))}
        except CoreError as error:
            return {"code": error.code, "details": error.details, "index": index}
    with ThreadPoolExecutor(2) as workers:
        results = list(workers.map(finish, range(2)))
    assert sum("saved" in result for result in results) == 1
    loser = next(result for result in results if "code" in result)
    assert loser["code"] == "product_binding_required"
    products = repo.list_entities(*scope(owner), "product")
    assert len(products) == 1 and loser["details"]["matched_entities"][0]["id"] == products[0]["id"]
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        confirm(service, owner, service.get(*scope(owner), drafts[loser["index"]]["id"]), "parallel-confirm-reload")
    assert error.value.code == "product_binding_required" and data_snapshot(repo) == before


def test_private_intake_entity_writer_does_not_bypass_shared_name_limit(workspace):
    repo, owner, service = workspace
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        with repo.connection(write=True) as db:
            service._create_entity(db, *scope(owner), "product", "S" * 300)
    assert error.value.code == "invalid_name" and "sản phẩm" in str(error.value)
    assert data_snapshot(repo) == before


def test_document_preflight_errors_cross_http_mcp_as_typed_not_started_and_no_pending(tmp_path, monkeypatch):
    # HTTP app's source scheduler is unrelated to document preflight. Keep it
    # off so the full DB before/after assertion measures this command alone.
    from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
    async def no_source_refresh(_self):
        return False
    monkeypatch.setattr(SourceRefreshJobs, "execute_next", no_source_refresh)
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("Document preflight must not dispatch AI")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "v12-document-owner")
            good_pdf = attachment(pdf_bytes(["Tên sản phẩm: Bột sen", "Khối lượng tịnh: 200 g"]))
            malformed = [attachment(b"PK\x03\x04Excel renamed PDF"), attachment(b"%PDF-1.7\nnot a PDF structure")]
            wrong_extension = {**good_pdf, "filename": "renamed.xlsx", "media_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
            before = data_snapshot(app.state.repo)
            for index, files in enumerate([[malformed[0]], [malformed[1]], [wrong_extension], [good_pdf, malformed[0]]]):
                result = call(web, url, session, "prepare_document_draft", text="Chị đọc tài liệu này", attachments=files,
                    operation_id="invalid-document-" + str(index))
                assert result["ok"] is False and result["error"]["code"] in {"invalid_pdf", "invalid_workbook"}
                assert result["error"]["commit_state"] == "not_started"
                assert data_snapshot(app.state.repo) == before
            success = good(web, url, session, "prepare_document_draft", text="Chị đọc tài liệu này", attachments=[good_pdf], operation_id="valid-document-prepare")
            assert success["intake"]["attachments"][0]["extraction_status"] == "parsed_local_pdf"
            after = data_snapshot(app.state.repo)
            replayed = good(web, url, session, "prepare_document_draft", text="Chị đọc tài liệu này", attachments=[good_pdf], operation_id="valid-document-prepare")
            assert replayed["id"] == success["id"] and data_snapshot(app.state.repo) == after
            assert app.state.repo.get_context(session["account"]["id"], session["enterprise"]["id"])["entities"] == []
            assert calls == []


def test_frontend_existing_product_choice_creates_fresh_draft_over_real_mcp(tmp_path):
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("Product choice must not call a model")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "v12-binding-owner")
            product = good(web, url, session, "core_create_entity", entity_type="product", name="Bột Sen", operation_id="existing-product")
            proposal = good(web, url, session, "core_propose_facts", entity_id=product["id"],
                facts=[{"field": "net_quantity", "value": "100 g"}], expected_version=0, operation_id="existing-quantity-proposal")
            good(web, url, session, "core_confirm_facts", proposal_id=proposal["proposal_id"], expected_version=0,
                operation_id="existing-quantity-confirm", proposal_hash=proposal["proposal_hash"])
            chat = good(web, url, session, "prepare_chat_draft", text="Chị có Trà sen, khối lượng tịnh 200 g", operation_id="initial-free-question", task_hint="profile_intake")
            item = chat["intake"]
            ids = [c["id"] for c in item["candidates"] if c["field"] in {"name", "net_quantity"}]
            name = next(c for c in item["candidates"] if c["field"] == "name")
            old_draft = {"selected": {key: True for key in ids}, "edits": {name["id"]: "Bột Sen"}, "choices": {},
                         "base_review_revision": item["review"]["revision"], "ui_revision": 0}
            good(web, url, session, "save_conversation_draft", conversation_id=chat["id"], intake_id=item["id"],
                draft=old_draft, operation_id="preserve-old-ui-draft")
            before = data_snapshot(app.state.repo)
            blocked = call(web, url, session, "confirm_intake", intake_id=item["id"], selected_fact_ids=ids,
                expected_entity_versions=item["expected_entity_versions"], operation_id="old-draft-confirm", edits=old_draft["edits"],
                expected_review_revision=item["review"]["revision"], expected_proposal_hashes={key: item["review"]["proposal_hashes"][key] for key in ids})
            assert blocked["error"]["code"] == "product_binding_required" and blocked["error"]["commit_state"] == "not_committed"
            assert blocked["error"]["details"]["matched_entities"][0]["id"] == product["id"]
            assert data_snapshot(app.state.repo) == before
            derived = good(web, url, session, "prepare_chat_draft", text="Đối chiếu dữ kiện đã chỉnh với hồ sơ sản phẩm đã chọn.\nTên sản phẩm: Bột Sen\nKhối lượng tịnh: 200 g",
                conversation_id=chat["id"], product_entity_id=product["id"], operation_id="explicit-product-choice", task_hint="profile_intake")
            assert derived["id"] == chat["id"] and derived["intake"]["id"] != item["id"]
            assert derived["intake"]["product"]["id"] == product["id"]
            assert derived["drafts"][item["id"]]["edits"][name["id"]] == "Bột Sen"
            assert data_snapshot(app.state.repo)["v03_current_facts"] == before["v03_current_facts"]
            current = derived["intake"]
            selected = [c["id"] for c in current["candidates"] if c["field"] in {"name", "net_quantity"}]
            quantity = next(c for c in current["candidates"] if c["field"] == "net_quantity")
            assert quantity["status"] == "conflict" and quantity["current_value"] == "100 g"
            result = good(web, url, session, "confirm_intake", intake_id=current["id"], selected_fact_ids=selected,
                expected_entity_versions=current["expected_entity_versions"], operation_id="derived-separate-confirm",
                conflict_choices={quantity["id"]: "incoming"}, expected_review_revision=current["review"]["revision"],
                expected_proposal_hashes={key: current["review"]["proposal_hashes"][key] for key in selected})
            assert result["product"]["id"] == product["id"]
            assert len(app.state.repo.list_entities(session["account"]["id"], session["enterprise"]["id"], "product")) == 1
            assert calls == []
