"""Purpose and topic are independent: user examples must survive bounded routing."""
from nmate.policy_v1.service import resolve_intent


def test_register_bookkeeping_class_is_training_not_generic_clarification():
    value = resolve_intent("Chị muốn đăng ký tham gia lớp kế toán cho hộ kinh doanh ở Hà Nội.")
    assert "workforce_training" in value["goals"]
    assert "participation_request" in value["purpose_types"]
    assert value["request_scope"] == "in_scope"


def test_petition_topic_and_negative_equipment_are_separate():
    value = resolve_intent("Không xin mua thiết bị. Chị chỉ muốn kiến nghị đào tạo nhân viên sổ sách.")
    assert value["goals"] == ["workforce_training"]
    assert "business_petition" in value["purpose_types"]
    assert "participation_request" not in value["purpose_types"]


def test_three_purposes_survive_one_mixed_question():
    value = resolve_intent("Giải thích hỗ trợ xuất khẩu trà sen, đăng ký lớp sổ sách và soạn kiến nghị thủ tục khó hiểu.")
    assert set(value["goals"]) == {"market_development", "workforce_training"}
    assert {"policy_explanation", "participation_request", "business_petition"} <= set(value["purpose_types"])


def test_explicit_not_register_does_not_create_registration_purpose():
    value = resolve_intent("Chưa đăng ký, chỉ giải thích lớp kế toán và giúp chị soạn kiến nghị.")
    assert "participation_request" not in value["purpose_types"]
    assert "policy_explanation" in value["purpose_types"]
    assert "business_petition" in value["purpose_types"]


def test_consultation_of_draft_is_distinct_from_business_petition():
    value = resolve_intent("Chị muốn góp ý dự thảo chính sách đào tạo nhân viên.")
    assert "draft_consultation" in value["purpose_types"]
    assert "business_petition" not in value["purpose_types"]


def test_training_registration_as_petition_subject_is_not_a_registration_command():
    value = resolve_intent("Chị muốn phản ánh thủ tục đăng ký đào tạo yêu cầu giấy tờ trùng lặp.")
    assert "workforce_training" in value["goals"]
    assert value["purpose_types"] == ["business_petition"]


def test_training_ai_model_is_not_workforce_training():
    value = resolve_intent("Chị cần hỗ trợ đào tạo mô hình AI để phân loại ảnh sản phẩm.")
    assert "workforce_training" not in value["goals"]
