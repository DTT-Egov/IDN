"""V12: bounded answers use explicit operation needs, never fabricate analysis."""
import pytest

from nmate.main.history import history_metadata
from nmate.v04.dialogue import interpret, working_answers, next_steps


def response(text, previous=None):
    intent=interpret(text,previous=previous,task_hint='sales_inventory')
    intent['working_answers']=working_answers(text,intent,(previous or {}).get('working_answers'))
    payload={'intent':intent,'saved_context':{'entities':[]},'product':None,'attachments':[]}
    return intent,next_steps(payload)


@pytest.mark.parametrize(('text','focus'),[
    ('Chị muốn quản lý tồn kho Trà Sen cho chính xác.','inventory_accuracy'),
    ('Chị cần tổng hợp bán hàng theo tháng và sản phẩm.','sales_reporting'),
])
def test_explicit_operation_need_never_asks_to_choose_it_again(text,focus):
    intent,steps=response(text)
    assert intent['focus']==focus
    assert not any('giảm sai lệch tồn kho hay' in x for x in steps)
    assert not any('theo ngày hay tháng' in x for x in steps) if 'theo tháng' in text else True
    assert all('Bạn' not in x and 'Anh/chị' not in x for x in steps)


def test_two_operation_needs_are_preserved_with_concrete_inputs():
    intent,steps=response('Chị cần quản lý bán hàng và tồn kho cho Trà Sen.')
    assert set(intent.get('operation_topics',[]))=={'sales_reporting','inventory_accuracy'}
    assert any('mã sản phẩm' in x for x in steps)
    assert not any('giảm sai lệch tồn kho hay tổng hợp' in x for x in steps)


def test_date_code_followup_still_reconciles_after_new_operation_focus():
    first,_=response('Chị muốn đối chiếu tồn kho, tồn sổ 120 hộp, thực tế 110 hộp.')
    after,steps=response('Ngày 18/10/2026, mã TS01',first)
    assert after['working_answers']['book_quantity']==120
    assert after['working_answers']['physical_quantity']==110
    assert any('phiếu nhập/xuất' in x for x in steps)


def test_history_has_topic_separate_from_confirmation_state():
    meta=history_metadata({'status':'awaiting_confirmation','task_hint':'sales_inventory',
        'messages':[{'role':'user','text':'Chị cần đối chiếu tồn kho Trà Sen.'}],
        'intake':{'intent':{'primary':'digitize_operations','focus':'inventory_accuracy'},'candidates':[]}})
    assert 'tồn kho' in meta.get('topic_title','').lower()
    assert 'xác nhận' not in meta['topic_title'].lower()


def test_policy_history_names_unsupported_domain_topics_instead_of_status():
    meta=history_metadata({'status':'prepared','task_hint':'hanoi_policy',
        'policy_cases':[{'id':'p1','intent':{'goals':['trademark_protection','ocop_program'],'request_scope':'in_scope'},
                         'result_status':'partially_answered'}], 'active_policy_case_id':'p1'})
    assert 'nhãn hiệu' in meta.get('topic_title','').lower() and 'OCOP' in meta['topic_title']
