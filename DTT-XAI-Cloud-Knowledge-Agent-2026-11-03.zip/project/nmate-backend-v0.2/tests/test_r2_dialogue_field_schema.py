"""DF-001/034: registry schema and exact historic request recovery, no paid IO."""
from __future__ import annotations

import asyncio
from copy import deepcopy
import json

from anthropic import transform_schema
from jsonschema import Draft202012Validator
import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.main.provider import MainProvider, canonical_main_request, historic_main_request_hashes
from nmate.v03.core import CoreError
from nmate.v03.domain_validation import validate_field_value
from nmate.v03.field_registry import REGISTRY_VERSION
from nmate.v04.dialogue_contracts import (dialogue_response_schema, exact_prior_dialogue_schemas,
                                        legacy_dialogue_schema_v2)
from nmate.v04.live_review import DialogueOutput, INSTRUCTIONS, historic_dialogue_contract_payloads
from test_design_gateway_invariants import workspace as private_workspace
from test_residual_six_dialogue_contract_replay import request, digest
from test_v04_live_review import result


def test_frozen_v2_matches_previous_model_schema_and_generated_contract_is_detached():
    assert legacy_dialogue_schema_v2() == DialogueOutput.model_json_schema()
    new = dialogue_response_schema()
    assert new["x-field-registry-version"] == REGISTRY_VERSION
    assert new != legacy_dialogue_schema_v2()
    new["$defs"]["VisionFact"]["properties"]["field"]["enum"].clear()
    assert dialogue_response_schema()["$defs"]["VisionFact"]["properties"]["field"]["enum"]


@pytest.mark.parametrize("field,good,bad", [
    ("name", "Trà Sen Tây Hồ", "x" * 251),
    ("net_quantity", "3.5 oz", "một trăm gam abc"),
    ("net_quantity", "100 fl oz", "0 g"),
    ("packaging", "hộp giấy", {"value": "hộp"}),
    ("ingredients", "trà và sen", ["trà", "sen"]),  # Vision is a text-only adapter.
    ("origin_country", "VN", True),
])
def test_field_specific_schema_never_accepts_a_different_adapter_type(field, good, bad):
    sha = "a" * 64
    vision = dialogue_response_schema([sha])["$defs"]["VisionFact"]
    validator = Draft202012Validator(vision)
    observation = {"sha256": sha, "field": field, "value": good, "quote": str(good), "location": "Ảnh 1"}
    assert validator.is_valid(observation)
    assert validate_field_value(field, good) is None
    assert not validator.is_valid({**observation, "value": bad})
    # Every anyOf branch must remain bound to the same exact image list, not
    # just the outer base property that old code addresses by its stable path.
    assert all(branch["properties"]["sha256"]["enum"] == [sha] for branch in vision["anyOf"])
    assert not validator.is_valid({**observation, "sha256": "b" * 64})


def test_sdk_transform_supports_existing_anyof_shape_without_changing_original_contract():
    schema = dialogue_response_schema(["a" * 64])
    before = deepcopy(schema)
    native = transform_schema(schema)
    assert schema == before
    branches = native["$defs"]["VisionFact"]["anyOf"]
    assert len(branches) == 5
    assert all(branch["properties"]["sha256"]["enum"] == ["a" * 64] for branch in branches)
    # SDK treats length/pattern as descriptive hints. The server must still
    # enforce the original registry contract after transport; no API guarantee.
    name = next(branch for branch in branches if branch["properties"]["field"]["enum"] == ["name"])
    assert "maxLength: 250" in name["properties"]["value"]["description"]


@pytest.mark.parametrize("hashes", [None, [], ["a" * 64], ["a" * 64, "b" * 64]])
def test_whole_known_schema_reconstructs_both_old_versions_without_changing_input(hashes):
    payload = request()
    payload["response_schema"] = dialogue_response_schema(hashes)
    before = deepcopy(payload)
    variants = historic_dialogue_contract_payloads(payload)
    assert len(variants) == 3
    assert variants[1]["response_schema"] == legacy_dialogue_schema_v2(hashes)
    assert variants[2]["response_schema"]["properties"]["working_answers"]["maxItems"] == 9
    assert payload == before
    variants[1]["input"]["current_question"] = "Must not mutate source or another variant"
    assert payload == before and variants[2]["input"] == before["input"]
    for where in ("value", "branch", "prompt"):
        changed = deepcopy(payload)
        if where == "value":
            changed["response_schema"]["$defs"]["VisionFact"]["properties"]["value"]["maxLength"] = 9999
        elif where == "branch":
            changed["response_schema"]["$defs"]["VisionFact"]["anyOf"][0]["properties"]["value"]["maxLength"] = 9999
        else:
            changed["instructions_vi"] = INSTRUCTIONS + " unknown decoration"
        assert historic_dialogue_contract_payloads(changed) == [changed]


def test_historical_hashes_are_exact_full_manifest_across_field_contracts():
    new = request()
    new["response_schema"] = dialogue_response_schema()
    allowed = historic_main_request_hashes("intake", new, "sales_inventory")
    for old in [request(), request(old=True)]:
        for version in (1, 2, 3):
            for address in (None, "chị", "bác"):
                exact = digest(canonical_main_request("intake", old, "sales_inventory", contract_version=version, address=address))
                assert exact in allowed
    assert exact_prior_dialogue_schemas(None) == []
    assert exact_prior_dialogue_schemas({"$defs": None}) == []
    assert exact_prior_dialogue_schemas({"$defs": {"VisionFact": []}}) == []


@pytest.fixture
def gateway_workspace(tmp_path):
    return private_workspace.__wrapped__(tmp_path)


@pytest.mark.parametrize("old_v1", [False, True])
def test_old_paid_envelope_is_read_exactly_with_new_field_schema_and_current_acl(gateway_workspace, old_v1):
    repo, core, _, gateway, _, resource, calls, _ = gateway_workspace

    async def injected(model, body, limit):
        calls.append(deepcopy((model, body, limit)))
        return {"text": json.dumps(result(), ensure_ascii=False), "model": model,
                "usage": {"input_tokens": 10, "output_tokens": 5}, "stop_reason": "end_turn"}

    gateway.request_fn = injected
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native or paid transport"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    old = request(old=old_v1, resource=resource)
    new = request(resource=resource)
    new["response_schema"] = dialogue_response_schema()
    kwargs = {"operation_id": "field-contract-prior", "account_id": "owner", "enterprise_id": "enterprise"}
    expected = asyncio.run(provider("intake", old, **kwargs))
    from test_review_commands_v2 import data_snapshot
    before = data_snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        assert asyncio.run(provider("intake", new, **kwargs)) == expected
        assert len(calls) == 1 and data_snapshot(repo) == before
        with repo.connection(write=True) as db:
            db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (resource,))
        revoked = data_snapshot(repo)
        with pytest.raises(CoreError):
            asyncio.run(provider("intake", new, **kwargs))
        assert len(calls) == 1 and data_snapshot(repo) == revoked
    finally:
        provider.recorded_only.reset(token)
