"""Real HTTP→MCP transport contracts with injected responses; no paid IO."""
import socket
import threading
import time

import httpx
import uvicorn

from nmate.main.app import make_main_app
from test_unified_main import Model
from test_v03_live_review import TEA
from test_v04_intake import ASSETS, upload


def test_main_three_tasks_shared_ssot_real_transport_and_paid_start_gate(tmp_path):
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    model = Model()
    app = make_main_app(tmp_path / "http.sqlite3", port=port, request_fn=model, refresh_sources=False, enforce_d06=False)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error", access_log=False))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 15
    while not server.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    try:
        url = f"http://127.0.0.1:{port}"
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web:
            pre = web.get("/api/v03/session").json()
            session = web.post("/api/v03/register", headers={"Origin": url, "X-CSRF-Token": pre["csrf_token"]}, json={
                "username": "http-owner", "password": "TestPassword12345", "enterprise_name": "Trà Sen HTTP"}).json()
            enterprise = session["enterprise"]["id"]
            headers = {"Origin": url, "X-CSRF-Token": session["csrf_token"]}

            def call(name, **args):
                response = web.post("/api/v03/mcp/call", headers=headers, json={"name": name, "arguments": {"enterprise_id": enterprise, **args}})
                assert response.status_code == 200, response.text
                return response.json()

            stale_client = call("send_message", text="Tôi muốn số hóa bán hàng và tồn kho", attachments=[], operation_id="old-cached-client", paid_consent=True)
            assert not stale_client["ok"] and stale_client["error"]["code"] == "APP_REFRESH_REQUIRED"
            assert not model.calls

            # The selected task crosses the real HTTP/MCP schema boundary.
            # A short natural destination reply must not reset to four goals.
            free_export = call("prepare_chat_draft", text="Chị muốn đi Mỹ", operation_id="http-free-export-hint",
                               task_hint="export_research")
            assert free_export["ok"], free_export
            assert free_export["data"]["intake"]["intent"]["primary"] == "export_readiness"
            assert free_export["data"]["intake"]["intent"]["market_codes"] == ["US"]
            assert not model.calls

            documents = call("send_message", text="Tôi muốn số hóa bán hàng và tồn kho", attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")], operation_id="http-documents-01", task_hint="profile_intake", paid_consent=True)
            assert documents["ok"], documents
            conv = documents["data"]
            intake = conv["intake"]
            confirmed = call("confirm_intake", intake_id=intake["id"], selected_fact_ids=[c["id"] for c in intake["candidates"]],
                expected_entity_versions=intake["expected_entity_versions"], operation_id="http-confirm-001",
                expected_review_revision=intake["review"]["revision"],
                expected_proposal_hashes=intake["review"]["proposal_hashes"])
            assert confirmed["ok"], confirmed
            planned = call("send_message", conversation_id=conv["id"], product_entity_id=confirmed["data"]["product"]["id"], text=TEA, attachments=[], operation_id="http-export-0001", task_hint="export_research", market_code="US", paid_consent=True)
            assert planned["ok"], planned
            mission_id = planned["data"]["active_mission_id"]
            denied = call("start_mission", mission_id=mission_id, operation_id="http-start-0001")
            assert not denied["ok"] and denied["error"]["code"] == "PAID_CONSENT_REQUIRED"
            assert len(model.calls) == 2
            accepted = call("start_mission", mission_id=mission_id, operation_id="http-start-0001", paid_consent=True)
            assert accepted["ok"], accepted
            deadline = time.monotonic() + 10
            while True:
                latest = call("get_mission", mission_id=mission_id)["data"]
                if latest["status"] not in {"queued", "running"}:
                    break
                assert time.monotonic() < deadline
                time.sleep(.05)
            assert latest["status"] == "completed_partial" and latest["label"]
            assert len(model.calls) == 3
            reopened = call("get_conversation", conversation_id=conv["id"])["data"]
            assert reopened["active_mission_id"] == mission_id and reopened["model_calls"] == 3
            blocked = web.post("/api/v03/mcp/call", headers=headers, json={"name": "prepare_mission", "arguments": {"enterprise_id": enterprise, "user_text": TEA, "operation_id": "http-blocked-01"}})
            assert blocked.status_code == 400
            assert web.get("/api/main/status").json()["provider_attempts"] == 3
            with httpx.Client(base_url=url, trust_env=False) as fresh_profile:
                anonymous = fresh_profile.get("/api/main/status").json()
                assert anonymous["provider_attempts"] == 0 and "estimated_usd" not in anonymous
                assert fresh_profile.get("/health").json()["paid_calls"] is None
            assert len(model.calls) == 3
    finally:
        server.should_exit = True
        thread.join(10)
        assert not thread.is_alive()
