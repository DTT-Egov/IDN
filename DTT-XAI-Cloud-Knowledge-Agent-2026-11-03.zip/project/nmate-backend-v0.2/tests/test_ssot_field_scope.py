"""Scope contracts protect all write paths and quarantine legacy projections.

Only synthetic SQLite data and previously saved response shapes are used. No
network/provider is involved in these tests.
"""
import hashlib

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository, json_text, new_id, now_iso
from nmate.v03.field_scope import field_is_in_scope, scope_contract
from nmate.v03.identity import LocalAccounts
from nmate.v04.effective_context import project_owner_context


@pytest.fixture
def scope_workspace(tmp_path):
    repo = CoreRepository(tmp_path / "scope.sqlite")
    owner = LocalAccounts(repo).register("scope-owner", "scope-password", "Trà Sen")
    args = owner["account_id"], owner["enterprise_id"]
    product = repo.create_entity(*args, "product", "Trà Sen Tây Hồ")
    company = repo.create_entity(*args, "enterprise", "Công ty Trà Sen")
    service = CoreSSOTService(repo)
    return repo, service, owner, product, company


def legacy_fact(repo, owner, entity_id, field="legal_form", value="Công ty trách nhiệm hữu hạn"):
    """Model a write from the pre-registry release; preserve its audit exactly."""
    assertion, resolution, stamp = new_id("assertion"), new_id("resolution"), now_iso()
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_fact_assertions VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (
            assertion, owner["enterprise_id"], entity_id, field, json_text(value), "string", "known",
            owner["account_id"], json_text({"kind": "owner_confirmed_legacy", "quote": "Private original"}),
            "self_declared", None, None, stamp, 0))
        db.execute("INSERT INTO v03_fact_resolutions VALUES(?,?,?,?,?,?,?,?,?,?,?)", (
            resolution, owner["enterprise_id"], entity_id, field, assertion, None, owner["account_id"],
            "select", "owner-explicit-v1", "Pre-registry owner choice", stamp))
        db.execute("INSERT INTO v03_current_facts VALUES(?,?,?,?,?,1)", (
            owner["enterprise_id"], entity_id, field, assertion, resolution))
    return assertion


@pytest.mark.parametrize("entity_type,field,allowed", [
    ("product", "legal_form", False), ("product", "enterprise_type", False),
    ("product", "registration_province", False), ("enterprise", "net_quantity", False),
    ("product", "business_sector", False), ("enterprise", "business_sector", True),
    ("company", "legal_form", True), ("business", "inventory_management", True),
    ("product", "ingredients", True), ("financial_period", "revenue.2025", True),
    ("product", "revenue.2025", False), ("market", "market_code", True),
    ("unknown_type", "private_field", False), (None, "name", False),
])
def test_field_registry_binds_aliases_and_period_fields(entity_type, field, allowed):
    assert field_is_in_scope(entity_type, field) is allowed
    assert "legal_form" not in scope_contract("product")["allowed_fields"]
    assert "legal_form" in scope_contract("company")["allowed_fields"]


def test_wrong_scope_rejected_by_direct_and_proposal_writes_without_any_partial_commit(scope_workspace):
    repo, service, owner, product, company = scope_workspace
    args = owner["account_id"], owner["enterprise_id"]
    facts = [{"field": "ingredients", "value": "Trà và sen"}, {"field": "legal_form", "value": "TNHH"}]
    for call in (
        lambda: repo.propose_or_apply_facts(*args, product["id"], facts, 0, "wrong-direct"),
        lambda: service.propose_facts(*args, product["id"], facts, 0, "wrong-proposal"),
        lambda: service.propose_facts(*args, company["id"], [{"field": "ingredients", "value": "Trà"}], 0, "wrong-company"),
    ):
        with pytest.raises(CoreError) as error:
            call()
        assert error.value.code == "invalid_field_scope"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_fact_assertions").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM core_v1_proposals").fetchone()[0] == 0


def test_company_alias_entity_uses_enterprise_registry_and_listing(scope_workspace):
    repo, service, owner, _, _ = scope_workspace
    args = owner["account_id"], owner["enterprise_id"]
    company = repo.create_entity(*args, "company", "Công ty cũ")
    repo.propose_or_apply_facts(*args, company["id"], [{"field": "legal_form", "value": "TNHH"}], 0, "company-alias")
    assert any(entity["id"] == company["id"] for entity in repo.list_entities(*args, "enterprise"))
    view = next(entity for entity in service.list_entities(*args, "enterprise") if entity["id"] == company["id"])
    assert view["field_scope"]["entity_type"] == "enterprise"
    assert view["values"]["legal_form"] == "TNHH"


def test_legacy_invalid_fact_keeps_audit_and_versions_but_never_enters_current_context(scope_workspace):
    repo, service, owner, product, company = scope_workspace
    args = owner["account_id"], owner["enterprise_id"]
    assertion = legacy_fact(repo, owner, product["id"])
    history = repo.get_fact_history(*args, product["id"])
    for _ in range(2):
        CoreSSOTService(repo)  # deployment/startup is idempotent, no data movement
        for view in (repo.get_entity(*args, product["id"]), service.list_entities(*args, "product")[0]):
            assert view["version"] == 0 and view["facts"] == []
            assert view["invalid_facts"][0]["assertion_id"] == assertion
            assert view["invalid_facts"][0]["scope_state"] == "invalid_entity_scope"
            assert view["invalid_facts"][0]["allowed_entity_types"] == ["enterprise"]
        for context in (repo.get_context(*args, [product["id"]]),
                        repo.get_context(*args, [product["id"]], ["legal_form"]),
                        service.get_context(*args, [product["id"]]),
                        service.get_context(*args, [product["id"]], ["legal_form"])):
            assert context["entities"][0]["values"] == {}
            assert context["entities"][0]["facts"] == []
            assert context["fact_refs"] == []
            assert "Private original" not in json_text(context)
            assert "Công ty trách nhiệm hữu hạn" not in json_text(context)
            assert "invalid_facts" not in context["entities"][0]
        assert repo.get_fact_history(*args, product["id"]) == history
        assert repo.get_entity(*args, company["id"])["facts"] == []
    check = repo.validate_context(*args, [{"entity_id": product["id"], "field": "legal_form", "version": 1, "assertion_id": assertion}])
    assert check["valid"] is False and check["reasons"][0]["reason"] == "invalid_entity_scope"


def test_old_wrong_scope_proposal_cannot_be_confirmed_after_upgrade(scope_workspace):
    repo, service, owner, product, _ = scope_workspace
    args = owner["account_id"], owner["enterprise_id"]
    facts = [repo._normalize_fact({"field": "legal_form", "value": "TNHH"})]
    digest = hashlib.sha256(json_text(facts).encode()).hexdigest()
    observation, proposal, stamp = new_id("observation"), new_id("proposal"), now_iso()
    with repo.connection(write=True) as db:
        revision = db.execute("SELECT context_revision FROM v03_enterprises WHERE id=?", (owner["enterprise_id"],)).fetchone()[0]
        db.execute("INSERT INTO core_v1_observations VALUES(?,?,?,?,?,?,?,?)", (
            observation, owner["enterprise_id"], product["id"], owner["account_id"], json_text(facts), digest, "{}", stamp))
        db.execute("INSERT INTO core_v1_proposals VALUES(?,?,?,?,?,?,?,?,?,?,?)", (
            proposal, owner["enterprise_id"], product["id"], observation, owner["account_id"], json_text(facts), digest,
            0, json_text({"legal_form": 0}), revision, stamp))
    assert service.list_proposals(*args)[0]["status"] == "invalid_scope"
    with pytest.raises(CoreError) as error:
        service.confirm_facts(*args, proposal, 0, "confirm-old")
    assert error.value.code == "invalid_field_scope"
    assert repo.get_fact_history(*args, product["id"]) == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_v1_decisions").fetchone()[0] == 0


def test_unregistered_field_never_becomes_wildcard_shared_by_registry(scope_workspace):
    repo, service, owner, product, _ = scope_workspace
    staff = LocalAccounts(repo).register("scope-staff", "scope-password", "Private")
    args = owner["account_id"], owner["enterprise_id"]
    repo.propose_or_apply_facts(*args, product["id"], [{"field": "private_formula", "value": "SECRET"}], 0, "private")
    service.add_member(*args, staff["username"])
    service.grant_resource(*args, product["id"], staff["account_id"], ["read"], ["*"])
    visible = service.get_context(staff["account_id"], owner["enterprise_id"], [product["id"]])
    assert visible["entities"][0]["values"] == {}
    assert "SECRET" not in json_text(visible)


def test_financial_period_field_keeps_separate_finance_permission(scope_workspace):
    repo, service, owner, _, company = scope_workspace
    staff = LocalAccounts(repo).register("finance-scope-staff", "scope-password", "Private")
    args = owner["account_id"], owner["enterprise_id"]
    repo.propose_or_apply_facts(*args, company["id"], [{"field": "revenue.2025", "value": 123456789}], 0, "annual")
    service.add_member(*args, staff["username"])
    service.grant_resource(*args, company["id"], staff["account_id"], ["read"], ["revenue.2025"])
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [company["id"]])
    assert context["entities"][0]["values"] == {}
    service.grant_resource(*args, company["id"], staff["account_id"], ["read_finance"], ["revenue.2025"])
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [company["id"]])
    assert context["entities"][0]["values"] == {"revenue.2025": 123456789}


def test_legacy_intake_observations_and_drafts_cannot_reintroduce_quarantined_facts_to_ai():
    ssot = {"entities": [{"id": "product", "entity_type": "product", "values": {"legal_form": "BAD-SCOPE"},
                          "facts": [{"field": "legal_form", "value": "BAD-SCOPE"}],
                          "invalid_facts": [{"field": "legal_form", "value": "BAD-SCOPE"}]}],
            "fact_refs": [{"entity_id": "product", "field": "legal_form", "version": 1}]}
    candidate = {"id": "candidate", "entity_id": "product", "entity_type": "product", "field": "legal_form",
                 "base_field": "name", "value": "BAD-SCOPE", "status": "confirmed", "source": {"quote": "BAD-SOURCE"}}
    confirmed = {"id": "old", "status": "confirmed", "confirmed_at": now_iso(), "candidates": [candidate]}
    pending = {"id": "pending", "status": "awaiting_confirmation", "candidates": [{**candidate, "status": "candidate"}]}
    result = project_owner_context(ssot, [confirmed], pending, {})
    assert result["confirmed_ssot"]["entities"][0]["values"] == {}
    assert result["confirmed_ssot"]["fact_refs"] == []
    assert result["owner_decisions"] == result["active_editable_draft"] == result["archived_observations"] == []
    assert "BAD-SCOPE" not in json_text(result) and "BAD-SOURCE" not in json_text(result)
    assert ssot["entities"][0]["values"] == {"legal_form": "BAD-SCOPE"}  # audit input is never edited
