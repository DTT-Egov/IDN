"""Business names are scoped owner proposals, not implicit legal renames.

All state uses isolated temporary SQLite data; no provider or HTTP is involved.
"""
import copy
import hashlib

import pytest

from nmate.core_v1.ssot import BUSINESS_FIELDS
from nmate.v03.core import CoreError, json_text
from nmate.v03.field_scope import field_is_in_scope
from nmate.v04.extraction import extract_business_text, extract_enterprise_text
from nmate.v04.effective_context import project_owner_context
from nmate.v04.intake import IntakeService
from nmate.v04.live_review import LiveIntakeService
from test_v04_intake import confirm
from test_v04_live_review import workspace as workspace


TEXT = ("Cơ sở Trà sen Quảng An của chị đang bán khoảng 300 hộp trà mỗi tháng. "
        "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSB01, thành phần trà xanh và hoa sen. "
        "Hãy bóc tách đúng tên cơ sở và tên sản phẩm thành nháp riêng; chị chưa đồng ý sửa hồ sơ đã có.")


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


def prepare(service, owner, text=TEXT, op="trading-name-draft"):
    return service.prepare(*scope(owner), text, [], op)


def test_introduction_extracts_two_distinct_scopes_with_literal_private_provenance():
    facts = extract_business_text(TEXT)
    assert len(facts) == 6
    business = next(fact for fact in facts if fact["entity_type"] == "enterprise")
    assert business["field"] == "trading_name" and business["value"] == "Trà sen Quảng An"
    assert business["label_vi"] == "Tên cơ sở (tên giao dịch)"
    assert "không đổi tên pháp lý" in business["note_vi"]
    for fact in facts:
        source = fact["source"]
        assert source["kind"] == "server_text_extract" and source["simulation"] is False
        assert source["value_quote"] in source["quote"]
        assert TEXT[source["start_offset"]:source["end_offset"]] == source["quote"]
        assert source["text_sha256"] == hashlib.sha256(TEXT.encode()).hexdigest()
        assert source["review_state"] == "owner_confirmation_required"
    assert next(fact["value"] for fact in facts if fact["field"] == "name") == "Trà sen Tây Hồ ướp bông"
    assert not any(fact["field"] in {"legal_name", "name"} for fact in facts if fact["entity_type"] == "enterprise")


@pytest.mark.parametrize("text", [
    "Tên cơ sở: Trà Sen?", "Tên cơ sở là gì?", "Ví dụ tên cơ sở: Trà Sen.",
    "Chị chưa biết tên cơ sở: Trà Sen.", "Nếu chị là chủ Cơ sở Trà Sen ở Hà Nội.",
    "Hãy đặt tên cơ sở: Trà Sen.", "Đổi tên cơ sở: Trà Sen.",
    "Tên cơ sở: Trà Sen hay Trà Hoa.", "Tên cơ sở: Trà Sen; tên cơ sở: Trà Hoa.",
    "Cơ sở Trà Sen của người khác đang bán trà.",
])
def test_question_hypothetical_negation_other_business_and_ambiguity_are_not_business_facts(text):
    assert extract_enterprise_text(text) == []


@pytest.mark.parametrize("text", ["Tên cơ sở: Trà Sen Quảng An.",
    "Tên giao dịch là Trà Sen Quảng An.", "Chị là chủ Cơ sở Trà Sen Quảng An ở Tây Hồ, Hà Nội."])
def test_enterprise_only_introduction_never_becomes_a_product(text):
    facts = extract_business_text(text)
    assert len(facts) == 1 and facts[0]["entity_type"] == "enterprise"
    assert facts[0]["value"] == "Trà Sen Quảng An"


def test_free_prepare_keeps_all_existing_ssot_and_separates_new_product(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    company = repo.create_entity(*scope(owner), "enterprise", "Tên quản lý đã có")
    repo.propose_or_apply_facts(*scope(owner), company["id"],
        [{"field": "legal_name", "value": "Tên pháp lý đã xác nhận"}], 0, "seed-company")
    tea = repo.create_entity(*scope(owner), "product", "Trà Sen Tây Hồ")
    repo.propose_or_apply_facts(*scope(owner), tea["id"],
        [{"field": "net_quantity", "value": "200 g"}], 0, "seed-product")
    before = repo.get_context(*scope(owner))
    item = prepare(service, owner)
    business = next(c for c in item["candidates"] if c["field"] == "trading_name")
    assert business["entity_id"] == company["id"] and business["status"] == "candidate"
    assert item["product"]["id"] == "new_product" and item["product"]["name"] == "Trà sen Tây Hồ ướp bông"
    assert all(c["entity_id"] == "new_product" for c in item["candidates"] if c["entity_type"] == "product")
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    assert item["status"] == "awaiting_confirmation" and item["model_calls"] == 0


def test_confirm_enterprise_only_preserves_legal_and_display_name_and_creates_no_product(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    company = repo.create_entity(*scope(owner), "enterprise", "Tên quản lý đã có")
    repo.propose_or_apply_facts(*scope(owner), company["id"],
        [{"field": "legal_name", "value": "Tên pháp lý đã xác nhận"}], 0, "seed-company")
    item = prepare(service, owner)
    business = next(c for c in item["candidates"] if c["field"] == "trading_name")
    saved = confirm(service, owner, item, selected=[business["id"]])
    assert saved["status"] == "awaiting_confirmation" and saved["product"]["id"] == "new_product"
    assert len([c for c in saved["candidates"] if c["status"] in {"candidate", "conflict"}]) == 5
    entity = next(e for e in repo.get_context(*scope(owner))["entities"] if e["id"] == company["id"])
    assert entity["name"] == "Tên quản lý đã có"
    assert entity["values"]["legal_name"] == "Tên pháp lý đã xác nhận"
    assert entity["values"]["trading_name"] == "Trà sen Quảng An"
    source = next(f["source"] for f in entity["facts"] if f["field"] == "trading_name")
    assert source["owner_confirmed"] is True and source["original_value"] == "Trà sen Quảng An"
    assert source["quote"] == "Cơ sở Trà sen Quảng An"
    assert [e["entity_type"] for e in repo.list_entities(*scope(owner))] == ["enterprise"]


def test_company_only_new_draft_confirms_once_without_product_or_account_rename(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    original_account_name = repo.get_context(*scope(owner))["enterprise_name"]
    item = prepare(service, owner, "Tên cơ sở: Trà sen Quảng An.")
    assert item["product"] is None and len(item["candidates"]) == 1
    saved = confirm(service, owner, item)
    repeated = confirm(service, owner, item)
    assert repeated["id"] == saved["id"] and repeated["confirmed_at"] == saved["confirmed_at"]
    context = repo.get_context(*scope(owner))
    assert context["enterprise_name"] == original_account_name
    assert len(context["entities"]) == 1 and context["entities"][0]["name"] == original_account_name
    assert context["entities"][0]["values"] == {"trading_name": "Trà sen Quảng An"}


def test_partial_company_confirmation_keeps_product_and_can_finish_without_retyping(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    item = prepare(service, owner)
    business = next(c for c in item["candidates"] if c["field"] == "trading_name")
    product_candidates = [copy.deepcopy(c) for c in item["candidates"] if c["entity_type"] == "product"]
    partial = confirm(service, owner, item, selected=[business["id"]], op="partial-company")
    assert partial["status"] == "awaiting_confirmation"
    assert partial["product_binding"] == {"state": "new_product_draft", "declared_name": "Trà sen Tây Hồ ướp bông", "confirmed": False}
    assert [c for c in partial["candidates"] if c["entity_type"] == "product"] == product_candidates
    assert partial["expected_entity_versions"]["new_product"] == 0
    replay = confirm(service, owner, item, selected=[business["id"]], op="partial-company")
    assert replay == partial and len(replay["partial_confirmations"]) == 1
    with repo.connection() as db:
        stored_before_read = db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (item["id"],)).fetchone()[0]
    reloaded = service.get(*scope(owner), item["id"])
    # A current query adds versioned projections; the committed command's
    # complete snapshot and the still-unconfirmed product remain unchanged.
    added_read_fields = {"intent_plan", "intent_plan_basis", "workspace_contract"}
    assert set(reloaded) - set(partial) == added_read_fields
    assert {key: value for key, value in reloaded.items() if key not in added_read_fields} == partial
    assert not reloaded["product_binding"]["confirmed"]
    assert reloaded["intent_plan"]["schema_version"] == "intent-plan/1"
    assert reloaded["intent_plan_basis"]["does_not_rewrite_saved_analysis"] is True
    assert reloaded["workspace_contract"]["schema_version"] == "workspace-contract/1"
    assert reloaded["workspace_contract"]["projection_only"] is True
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM v04_intakes WHERE id=?", (item["id"],)).fetchone()[0] == stored_before_read
    with pytest.raises(CoreError) as already_saved:
        confirm(service, owner, reloaded, selected=[business["id"]], op="duplicate-partial-company")
    assert already_saved.value.code == "candidate_already_confirmed"
    assert all(e["entity_type"] == "enterprise" for e in partial["saved_context"]["entities"])
    projected = project_owner_context(partial["saved_context"], [partial], partial, None)
    assert len(projected["owner_decisions"]) == 1
    decision = projected["owner_decisions"][0]
    assert decision["field"] == "trading_name" and decision["requires_choice_again"] is False
    assert len(projected["active_editable_draft"]) == 5
    final = confirm(service, owner, partial, selected=[c["id"] for c in product_candidates], op="finish-product-draft")
    assert final["status"] == "confirmed" and len(final["partial_confirmations"]) == 1
    context = repo.get_context(*scope(owner))
    company = next(e for e in context["entities"] if e["entity_type"] == "enterprise")
    product = next(e for e in context["entities"] if e["entity_type"] == "product")
    assert company["values"]["trading_name"] == "Trà sen Quảng An"
    assert product["values"]["name"] == "Trà sen Tây Hồ ướp bông"
    assert product["values"]["product_code"] == "TSB01" and len(context["entities"]) == 2
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_fact_assertions WHERE field='trading_name'").fetchone()[0] == 1


def test_conflicting_trading_name_requires_explicit_choice_and_cas(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    company = repo.create_entity(*scope(owner), "enterprise", "Tên quản lý")
    repo.propose_or_apply_facts(*scope(owner), company["id"],
        [{"field": "trading_name", "value": "Trà Sen cũ"}], 0, "old-trading-name")
    item = prepare(service, owner, "Tên cơ sở: Trà sen Quảng An.")
    candidate = item["candidates"][0]
    assert candidate["status"] == "conflict" and candidate["current_value"] == "Trà Sen cũ"
    before = repo.get_context(*scope(owner))
    with pytest.raises(CoreError) as required:
        confirm(service, owner, item)
    assert required.value.code == "conflict_choice_required"
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    kept = confirm(service, owner, item, op="keep-current-name", conflict_choices={candidate["id"]: "current"})
    assert kept["candidates"][0]["status"] == "kept_current"
    assert next(e for e in repo.get_context(*scope(owner))["entities"] if e["id"] == company["id"])["values"]["trading_name"] == "Trà Sen cũ"
    again = prepare(service, owner, "Tên cơ sở: Trà sen Quảng An.", "new-trading-name-cas")
    repo.propose_or_apply_facts(*scope(owner), company["id"],
        [{"field": "business_goal", "value": "Nâng năng lực"}], 1, "concurrent-business-change")
    with pytest.raises(CoreError) as stale:
        confirm(service, owner, again, op="stale-trading-name", conflict_choices={again["candidates"][0]["id"]: "incoming"})
    assert stale.value.code == "version_conflict"


def test_enterprise_name_cannot_be_rebound_to_product_or_read_by_other_owner(workspace):
    repo, owner, other = workspace
    service = IntakeService(repo)
    item = prepare(service, owner, "Tên cơ sở: Trà sen Quảng An.")
    product = repo.create_entity(*scope(owner), "product", "Trà Sen")
    corrupt = copy.deepcopy(item)
    corrupt["candidates"][0]["entity_id"] = product["id"]
    corrupt["expected_entity_versions"][product["id"]] = 0
    with repo.connection(write=True) as db:
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(corrupt), item["id"]))
    with pytest.raises(CoreError) as mismatch:
        confirm(service, owner, corrupt)
    assert mismatch.value.code == "invalid_field_scope"
    with pytest.raises(CoreError):
        service.get(*scope(other), item["id"])
    with pytest.raises(CoreError):
        service.confirm(*scope(other), item["id"], [corrupt["candidates"][0]["id"]], corrupt["expected_entity_versions"], "other-owner")
    assert repo.get_context(*scope(owner))["fact_refs"] == []
    assert field_is_in_scope("product", "trading_name") is False
    assert "trading_name" in BUSINESS_FIELDS


def test_staff_cannot_prepare_or_confirm_owner_company_draft(workspace):
    repo, owner, _ = workspace
    service = IntakeService(repo)
    item = prepare(service, owner, "Tên cơ sở: Trà sen Quảng An.")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?", scope(owner))
    with pytest.raises(CoreError) as denied:
        confirm(service, owner, item)
    assert denied.value.code == "forbidden"
    with pytest.raises(CoreError):
        prepare(service, owner, op="staff-prepare")


def test_free_recovery_adds_only_company_candidate_and_preserves_draft_and_ssot(workspace):
    repo, owner, _ = workspace
    local = IntakeService(repo)
    company = repo.create_entity(*scope(owner), "enterprise", "Tên quản lý")
    item = prepare(local, owner)
    # A legacy product-only result contains an immutable audit / paid prose.
    legacy = copy.deepcopy(item)
    legacy["candidates"] = [c for c in legacy["candidates"] if c["entity_type"] == "product"]
    legacy["assistant_text"] = "Phản hồi Claude đã lưu, không sửa."
    with repo.connection(write=True) as db:
        db.execute("UPDATE v04_intakes SET payload_json=? WHERE id=?", (json_text(legacy), item["id"]))
    before = repo.get_context(*scope(owner))
    live = LiveIntakeService(repo, provider=object())
    recovered = live.recover_text_observations(*scope(owner), item["id"], "recover-company-free")
    replay = live.recover_text_observations(*scope(owner), item["id"], "recover-company-free")
    assert recovered == replay and recovered["assistant_text"] == legacy["assistant_text"]
    assert [c for c in recovered["candidates"] if c["entity_type"] == "product"] == legacy["candidates"]
    added = [c for c in recovered["candidates"] if c["entity_type"] == "enterprise"]
    assert len(added) == 1 and added[0]["entity_id"] == company["id"]
    assert recovered["text_observation_recoveries"][-1]["model_called"] is False
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    with repo.connection() as db:
        assert db.execute("SELECT name FROM sqlite_master WHERE name='v03_live_attempts'").fetchone() is None


def test_recovery_cannot_use_new_enterprise_snapshot_after_other_intake_created_it(workspace):
    repo, owner, _ = workspace
    local = IntakeService(repo)
    item = prepare(local, owner, "Tên cơ sở: Trà sen Quảng An.")
    repo.create_entity(*scope(owner), "enterprise", "Hồ sơ tạo từ lượt khác")
    with pytest.raises(CoreError) as stale:
        LiveIntakeService(repo, provider=object()).recover_text_observations(*scope(owner), item["id"], "recover-stale-company")
    assert stale.value.code == "version_conflict"
    assert len(repo.list_entities(*scope(owner))) == 1
