"""Causal lifecycle and schema extension; offline original bindings retained."""
import json,sqlite3
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m6_worker import batch,decision
from nmate.knowledge_v1 import worker_m6,public_batch,batch_lifecycle
from nmate.knowledge_v1.operator_m6 import install_m6
from nmate.v03.core import CoreError

@pytest.fixture
def legacy(kb,tmp_path,monkeypatch):
    repo,_,actor,other,_=kb
    with repo.connection(write=True) as db:db.execute("UPDATE v03_accounts SET username='trung@dtt.vn' WHERE id=?",(other,))
    monkeypatch.setattr(public_batch,'_APPROVAL_REGISTRY_DIR',tmp_path/'TEST-registry')
    folder=tmp_path/'legacy';prepared=public_batch.prepare(repo.db_path,folder);grant=public_batch.issue_grant(prepared,folder)
    return folder,prepared,grant

def dump(repo):
    with repo.connection() as db:return list(db.iterdump())

@pytest.mark.asyncio
async def test_legacy_read_requires_explicit_operator_before_key_or_dispatch(legacy):
    folder,prepared,grant=legacy;repo=public_batch.existing_repository(prepared);before=dump(repo)
    status=worker_m6.snapshot(folder)
    assert not status['operator_schema_ready'] and status['next_slot'] is None
    result=await worker_m6.run_once(folder,env_file=folder/'MUST-NOT-READ.env')
    assert result['state']=='stopped_no_dispatch'
    async def forbidden(*a):pytest.fail('No SDK')
    await public_batch.execute(folder,'',request_fn=forbidden,max_new_calls=1)
    assert dump(repo)==before

def test_extension_preserves_original_prepared_and_every_existing_row(legacy,tmp_path):
    folder,prepared,grant=legacy;repo=public_batch.existing_repository(prepared)
    before=dump(repo);prepared_bytes=(folder/'prepared.json').read_bytes()
    receipt=install_m6(prepared['database'],prepared=prepared,backup_path=folder/'before-m6.sqlite')['receipt']
    extended=public_batch.existing_repository(prepared)
    with extended.connection() as db:
        assert db.execute('SELECT count(*) FROM kw_batch_controls').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM kw_batch_control_heads').fetchone()[0]==0
        assert not db.execute('SELECT 1 FROM core_domain_model_attempts').fetchone()
    with sqlite3.connect(folder/'before-m6.sqlite') as saved:assert list(saved.iterdump())==before
    assert (folder/'prepared.json').read_bytes()==prepared_bytes
    assert install_m6(prepared['database'],prepared=prepared,backup_path=folder/'MUST-NOT-CREATE.sqlite')['receipt']==receipt
    assert not (folder/'MUST-NOT-CREATE.sqlite').exists()

def test_wrong_target_and_partial_extension_stop_before_any_operator_write(legacy,tmp_path):
    folder,prepared,grant=legacy;repo=public_batch.existing_repository(prepared);before=dump(repo)
    with pytest.raises(CoreError):install_m6(tmp_path/'OTHER-MUST-NOT-CREATE.sqlite',prepared=prepared,backup_path=tmp_path/'NO.sqlite')
    assert dump(repo)==before and not (tmp_path/'OTHER-MUST-NOT-CREATE.sqlite').exists()
    install_m6(prepared['database'],prepared=prepared,backup_path=folder/'before-m6.sqlite')
    with repo.connection(write=True) as db:db.execute('DROP TRIGGER kw_batch_controls_no_delete')
    broken=dump(repo)
    with pytest.raises(CoreError):install_m6(prepared['database'],prepared=prepared,backup_path=folder/'NO-REPAIR.sqlite')
    assert dump(repo)==broken and not (folder/'NO-REPAIR.sqlite').exists()

@pytest.mark.asyncio
async def test_stop_resume_stop_has_causal_successor_and_old_resume_is_readonly(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=public_batch.existing_repository(prepared);attempt=worker_m6.snapshot(folder)['attempts'][0]['id']
    first=public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    command=decision(worker_m6.snapshot(folder));receipt=worker_m6.resume(folder,command)
    second=public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    assert first['id']!=second['id'] and worker_m6.snapshot(folder)['grant_state']=='paused_admission_review'
    before=dump(repo);assert worker_m6.resume(folder,command)==receipt;assert dump(repo)==before
    with repo.connection() as db:
        rows=db.execute('SELECT * FROM kw_batch_controls ORDER BY sequence').fetchall()
        assert [r['action'] for r in rows]==['pause','resume','pause']
        assert rows[1]['previous_id']==rows[0]['id'] and rows[2]['previous_id']==rows[1]['id']
    assert len(calls)==1

@pytest.mark.asyncio
async def test_immutable_controls_head_rewind_and_projection_rewind_fail_common_fence(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=public_batch.existing_repository(prepared);attempt=worker_m6.snapshot(folder)['attempts'][0]['id']
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    worker_m6.resume(folder,decision(worker_m6.snapshot(folder)))
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop again')
    with repo.connection(write=True) as db:
        for sql in ('DELETE FROM kw_batch_controls',"UPDATE kw_batch_controls SET to_state='active'"):
            with pytest.raises(sqlite3.IntegrityError):db.execute(sql)
        old=db.execute("SELECT id,sequence FROM kw_batch_controls WHERE action='resume'").fetchone()
        db.execute('UPDATE kw_batch_control_heads SET decision_id=?,sequence=? WHERE grant_id=?',(old['id'],old['sequence'],grant['id']))
        db.execute("UPDATE core_domain_budget_grants SET state='active' WHERE id=?",(grant['id'],))
    with pytest.raises(CoreError):worker_m6.snapshot(folder)
    await public_batch.execute(folder,'',request_fn=request,max_new_calls=1)
    assert len(calls)==1

@pytest.mark.asyncio
async def test_resume_fault_after_all_control_writes_rolls_back_one_unit(batch,monkeypatch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=public_batch.existing_repository(prepared);attempt=worker_m6.snapshot(folder)['attempts'][0]['id']
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    args=decision(worker_m6.snapshot(folder));before=dump(repo)
    append=batch_lifecycle.append
    def fail(*a,**kw):append(*a,**kw);raise RuntimeError('TEST crash after head/event/state before commit')
    monkeypatch.setattr(batch_lifecycle,'append',fail)
    with pytest.raises(RuntimeError):worker_m6.resume(folder,args)
    assert dump(repo)==before and len(calls)==1

@pytest.mark.asyncio
async def test_lifecycle_events_cannot_be_rewritten_or_deleted_at_storage(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=public_batch.existing_repository(prepared);attempt=worker_m6.snapshot(folder)['attempts'][0]['id']
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    before=dump(repo)
    with repo.connection(write=True) as db:
        for sql in ("UPDATE core_domain_model_events SET scope_id='wrong' WHERE kind='batch_paused_admission'",
                    "DELETE FROM core_domain_model_events WHERE kind='batch_paused_admission'"):
            with pytest.raises(sqlite3.IntegrityError):db.execute(sql)
    assert dump(repo)==before and worker_m6.snapshot(folder)['grant_state']=='paused_admission_review' and len(calls)==1

@pytest.mark.asyncio
async def test_kernel_terminal_evidence_survives_projection_rewind(batch):
    folder,prepared,grant,request,calls=batch
    async def overrun(*args):
        result=await request(*args)
        return result|dict(usage=dict(input_tokens=50000,output_tokens=100))
    await worker_m6.run_once(folder,request_fn=overrun)
    repo=public_batch.existing_repository(prepared)
    before=dump(repo)
    assert worker_m6.snapshot(folder)['grant_state']=='needs_reconciliation'
    assert dump(repo)==before
    with repo.connection(write=True) as db:
        for sql in ("DELETE FROM core_domain_model_events WHERE kind='estimate_overrun'",
                    "UPDATE core_domain_model_events SET kind='ignored' WHERE kind='estimate_overrun'"):
            with pytest.raises(sqlite3.IntegrityError):db.execute(sql)
        db.execute("UPDATE core_domain_budget_grants SET state='active' WHERE id=?",(grant['id'],))
    with pytest.raises(CoreError):worker_m6.snapshot(folder)
    await public_batch.execute(folder,'',request_fn=request,max_new_calls=1)
    assert len(calls)==1

@pytest.mark.asyncio
async def test_observed_terminal_stop_cannot_be_reactivated_or_resumed(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=public_batch.existing_repository(prepared)
    status=worker_m6.snapshot(folder);attempt=status['attempts'][0]['id']
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='stop')
    args=decision(worker_m6.snapshot(folder));receipt=worker_m6.resume(folder,args)
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_domain_budget_grants SET state='revoked' WHERE id=?",(grant['id'],))
    public_batch.pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='retain terminal')
    before=dump(repo)
    assert worker_m6.snapshot(folder)['next_slot'] is None
    assert worker_m6.resume(folder,args)==receipt
    assert dump(repo)==before
    with repo.connection(write=True) as db:
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("DELETE FROM core_domain_model_events WHERE kind='batch_stop_terminal'")
        db.execute("UPDATE core_domain_budget_grants SET state='active' WHERE id=?",(grant['id'],))
    with pytest.raises(CoreError):worker_m6.snapshot(folder)
    await public_batch.execute(folder,'',request_fn=request,max_new_calls=1)
    assert len(calls)==1
