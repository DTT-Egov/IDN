"""Independent Claude configuration checks; no real key or network call is used.

Script integration runs only a copied helper inside pytest's temporary folder.
It replaces Read-Host with an explicitly invalid-for-service TEST credential.
Neither the repository .env nor any existing credential store is inspected.
"""

import os
import json
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace

import pytest
from pydantic import SecretStr, ValidationError

from nmate.config import Settings
from nmate import cli


BACKEND = Path(__file__).resolve().parents[1]
FAKE_ANTHROPIC = "sk-ant-FAKE_TEST_ONLY_NEVER_VALID"
FAKE_OPENAI = "sk-FAKE_TEST_ONLY_NEVER_VALID"


@pytest.fixture(autouse=True)
def isolated_config_environment(monkeypatch):
    # Never load the project's .env, and do not rely on developer credentials.
    for name in tuple(os.environ):
        if name.startswith("NMATE_") or name in {"ANTHROPIC_API_KEY", "OPENAI_API_KEY"}:
            monkeypatch.delenv(name, raising=False)


def settings(**overrides):
    return Settings(_env_file=None, **overrides)


def test_default_provider_is_claude_but_without_key_or_model_stays_unconfigured():
    config = settings()
    assert config.model_provider == "anthropic"
    assert config.credential_env_name == "ANTHROPIC_API_KEY"
    assert config.selected_api_key is None
    assert not config.model_configured


def test_default_two_level_model_policy_is_explicit_and_has_no_key():
    config = settings()
    assert config.simple_model == "claude-sonnet-5-5"
    assert config.complex_model == "claude-opus-5-5"
    assert config.routing_models_valid
    assert config.safe_model_policy == {
        "simple": "claude-sonnet-5-5", "complex": "claude-opus-5-5",
    }
    assert not config.model_configured


def test_explicit_anthropic_key_is_secret_and_selected_without_openai_fallback():
    config = settings(
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
        OPENAI_API_KEY=FAKE_OPENAI,
    )
    assert config.model_configured
    assert isinstance(config.selected_api_key, SecretStr)
    assert config.selected_api_key.get_secret_value() == FAKE_ANTHROPIC
    assert config.api_key_for("openai").get_secret_value() == FAKE_OPENAI
    assert config.api_key_for("unknown") is None
    assert FAKE_ANTHROPIC not in repr(config)
    assert FAKE_OPENAI not in repr(config)
    assert FAKE_ANTHROPIC not in config.model_dump_json()
    assert FAKE_OPENAI not in config.model_dump_json()


@pytest.mark.parametrize("model", [None, "gpt-5-mini", "unit-model"])
def test_claude_provider_rejects_missing_or_other_provider_model_namespace(model):
    config = settings(model_name=model, ANTHROPIC_API_KEY=FAKE_ANTHROPIC)
    assert not config.provider_model_valid
    assert not config.model_configured


def test_openai_credential_alone_cannot_enable_anthropic():
    config = settings(model_name="claude-sonnet-5-5", OPENAI_API_KEY=FAKE_OPENAI)
    assert config.selected_api_key is None
    assert not config.model_configured


@pytest.mark.parametrize("credential", [None, ""])
def test_missing_selected_key_does_not_fall_back_to_existing_other_key(credential):
    config = settings(
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=credential,
        OPENAI_API_KEY=FAKE_OPENAI,
    )
    assert not config.model_configured


def test_explicit_openai_mode_retains_legacy_unit_model_contract():
    config = settings(
        model_provider="openai", model_name="unit-model", OPENAI_API_KEY=FAKE_OPENAI,
        ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
    )
    assert config.model_configured
    assert config.selected_api_key.get_secret_value() == FAKE_OPENAI
    assert config.credential_env_name == "OPENAI_API_KEY"


def test_claude_model_does_not_activate_under_openai_provider():
    config = settings(
        model_provider="openai", model_name="claude-sonnet-5-5", OPENAI_API_KEY=FAKE_OPENAI,
    )
    assert not config.model_configured


def test_unknown_provider_cannot_select_an_implicit_adapter():
    with pytest.raises(ValidationError):
        settings(model_provider="automatic", model_name="claude-sonnet-5-5")


def test_documented_environment_names_load_the_selected_key(monkeypatch):
    monkeypatch.setenv("NMATE_MODEL_PROVIDER", "anthropic")
    monkeypatch.setenv("NMATE_MODE", "llm")
    monkeypatch.setenv("NMATE_MODEL_NAME", "claude-sonnet-5-5")
    monkeypatch.setenv("ANTHROPIC_API_KEY", FAKE_ANTHROPIC)
    monkeypatch.setenv("OPENAI_API_KEY", FAKE_OPENAI)
    config = settings()
    assert config.mode == "llm"
    assert config.model_configured
    assert config.selected_api_key.get_secret_value() == FAKE_ANTHROPIC


def test_documented_simple_and_complex_environment_names_are_independent(monkeypatch):
    monkeypatch.setenv("NMATE_MODEL_NAME", "claude-legacy-cli")
    monkeypatch.setenv("NMATE_SIMPLE_MODEL", "claude-test-simple")
    monkeypatch.setenv("NMATE_COMPLEX_MODEL", "claude-test-complex")
    monkeypatch.setenv("ANTHROPIC_API_KEY", FAKE_ANTHROPIC)
    config = settings()
    assert config.model_name == "claude-legacy-cli"
    assert config.simple_model == "claude-test-simple"
    assert config.complex_model == "claude-test-complex"
    assert config.model_configured


@pytest.mark.parametrize("field", ["simple_model", "complex_model"])
def test_other_provider_namespace_disables_claude_routing(field):
    config = settings(
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC, **{field: "gpt-5-mini"},
    )
    assert not config.routing_models_valid
    assert not config.model_configured


@pytest.mark.asyncio
@pytest.mark.parametrize("field", ["simple_model", "complex_model"])
@pytest.mark.parametrize("accidental_secret", [FAKE_ANTHROPIC, "claude-" + FAKE_ANTHROPIC])
async def test_routing_model_policy_metadata_hides_accidental_secret_in_either_model_field(
    tmp_path, monkeypatch, capsys, field, accidental_secret,
):
    import httpx

    from nmate.app import create_app

    config = settings(
        data_dir=tmp_path, model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
        OPENAI_API_KEY=FAKE_OPENAI, **{field: accidental_secret},
    )
    policy_key = "simple" if field == "simple_model" else "complex"
    assert not config.routing_models_valid
    assert not config.model_configured
    assert config.safe_model_policy[policy_key] is None
    assert accidental_secret not in repr(config)
    monkeypatch.setattr(cli, "Settings", lambda: config)
    monkeypatch.setattr("sys.argv", ["nmate", "doctor"])
    cli.main()
    doctor_output = capsys.readouterr().out
    assert FAKE_ANTHROPIC not in doctor_output
    assert FAKE_OPENAI not in doctor_output
    assert json.loads(doctor_output)["model_policy"][policy_key] is None
    app = create_app(config)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url=config.base_url) as client:
        for route in ("/health", "/api/session"):
            response = await client.get(route)
            assert response.status_code == 200
            assert response.json()["model_policy"][policy_key] is None
            assert response.json()["model_configured"] is False
            assert FAKE_ANTHROPIC not in response.text
            assert FAKE_OPENAI not in response.text


def test_doctor_metadata_does_not_expose_either_configured_key(monkeypatch, capsys):
    config = settings(
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
        OPENAI_API_KEY=FAKE_OPENAI,
    )
    monkeypatch.setattr(cli, "Settings", lambda: config)
    monkeypatch.setattr("sys.argv", ["nmate", "doctor"])
    cli.main()
    output = capsys.readouterr().out
    assert FAKE_ANTHROPIC not in output
    assert FAKE_OPENAI not in output
    assert '"live_model_verified": false' in output
    assert '"credential_variable": "ANTHROPIC_API_KEY"' in output


@pytest.mark.parametrize("invalid_model", [
    FAKE_ANTHROPIC, "claude-" + FAKE_ANTHROPIC, "Bearer_FAKE_TEST_ONLY", "claude-sonnet-5-5\nTEST",
])
def test_doctor_hides_secret_or_invalid_value_accidentally_pasted_as_model(
    monkeypatch, capsys, invalid_model,
):
    config = settings(model_name=invalid_model, ANTHROPIC_API_KEY=FAKE_ANTHROPIC)
    assert not config.model_configured
    assert config.safe_model_name is None
    assert invalid_model not in repr(config)
    monkeypatch.setattr(cli, "Settings", lambda: config)
    monkeypatch.setattr("sys.argv", ["nmate", "doctor"])
    cli.main()
    output = capsys.readouterr().out
    assert invalid_model not in output
    assert FAKE_ANTHROPIC not in output
    assert '"model_name": null' in output


def test_settings_validation_error_hides_accidental_secret_in_wrong_field():
    with pytest.raises(ValidationError) as caught:
        settings(model_provider=FAKE_ANTHROPIC)
    assert FAKE_ANTHROPIC not in str(caught.value)


@pytest.mark.asyncio
@pytest.mark.parametrize("invalid_model", [FAKE_ANTHROPIC, "claude-" + FAKE_ANTHROPIC])
async def test_health_and_browser_session_never_return_accidental_model_field_secret(tmp_path, invalid_model):
    import httpx

    from nmate.app import create_app

    config = settings(
        data_dir=tmp_path, model_name=invalid_model, ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
        OPENAI_API_KEY=FAKE_OPENAI,
    )
    app = create_app(config)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url=config.base_url) as client:
        for route in ("/health", "/api/session"):
            response = await client.get(route)
            assert response.status_code == 200
            data = response.json()
            assert data["model_name"] is None
            assert data["model_configured"] is False
            assert FAKE_ANTHROPIC not in response.text
            assert FAKE_OPENAI not in response.text


@pytest.mark.asyncio
async def test_model_verification_requires_selected_key_before_constructing_sdk(monkeypatch):
    import anthropic

    def forbidden_client(**_kwargs):
        raise AssertionError("A missing selected key must not reach the SDK")

    monkeypatch.setattr(anthropic, "AsyncAnthropic", forbidden_client)
    config = settings(model_name="claude-sonnet-5-5", OPENAI_API_KEY=FAKE_OPENAI)
    result = await cli.verify_model(config)
    assert result["ok"] is False
    assert result["code"] == "MODEL_NOT_CONFIGURED"


@pytest.mark.asyncio
async def test_model_verification_is_explicit_tiny_anthropic_request(monkeypatch):
    import anthropic

    observed = {}

    class FakeClient:
        def __init__(self, **kwargs):
            observed["client"] = kwargs
            self.messages = self

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return False

        async def create(self, **kwargs):
            observed["request"] = kwargs
            return SimpleNamespace(
                model="claude-sonnet-5-5", usage=SimpleNamespace(input_tokens=12, output_tokens=1),
            )

    monkeypatch.setattr(anthropic, "AsyncAnthropic", FakeClient)
    config = settings(
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC,
        OPENAI_API_KEY=FAKE_OPENAI,
    )
    result = await cli.verify_model(config)
    assert result["ok"] and result["live_model_verified"]
    assert observed["client"] == {
        "api_key": FAKE_ANTHROPIC, "base_url": "https://api.anthropic.com", "max_retries": 0, "timeout": 30,
    }
    assert observed["request"]["model"] == "claude-sonnet-5-5"
    assert observed["request"]["max_tokens"] == 32
    assert "tools" not in observed["request"]
    assert "temperature" not in observed["request"]
    assert FAKE_ANTHROPIC not in repr(result)
    assert FAKE_OPENAI not in repr(result)


@pytest.mark.asyncio
async def test_model_verification_sanitizes_provider_error_body(monkeypatch, capsys):
    import anthropic

    class FakeAuthenticationError(Exception):
        pass

    def reject_key(**_kwargs):
        raise FakeAuthenticationError(f"Provider echoed secret: {FAKE_ANTHROPIC}")

    monkeypatch.setattr(anthropic, "AuthenticationError", FakeAuthenticationError)
    monkeypatch.setattr(anthropic, "AsyncAnthropic", reject_key)
    config = settings(model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY=FAKE_ANTHROPIC)
    result = await cli.verify_model(config)
    assert result["ok"] is False
    assert result["code"] == "INVALID_API_KEY"
    assert FAKE_ANTHROPIC not in repr(result)
    captured = capsys.readouterr()
    assert FAKE_ANTHROPIC not in captured.out + captured.err


def powershell_string(value):
    return "'" + str(value).replace("'", "''") + "'"


@pytest.fixture(params=["powershell", "pwsh"])
def powershell_executable(request):
    executable = shutil.which(request.param)
    if not executable:
        pytest.skip(f"{request.param} is unavailable; this runtime has not been tested")
    return executable


def run_copied_helper(tmp_path, executable, fake_key=FAKE_ANTHROPIC, model=None, complex_model=None):
    target = tmp_path / "backend with spaces"
    target.mkdir(exist_ok=True)
    script = target / "configure-claude.ps1"
    shutil.copyfile(BACKEND / "configure-claude.ps1", script)
    command = (
        "function global:Read-Host { param([string]$Prompt, [switch]$AsSecureString) "
        "$testSecret = [Security.SecureString]::new(); "
        f"$testValue = {powershell_string(fake_key)}; "
        "foreach ($testChar in $testValue.ToCharArray()) { $testSecret.AppendChar($testChar) }; "
        "return $testSecret }; "
        f"& {powershell_string(script)}"
    )
    if model is not None:
        command += f" -Model {powershell_string(model)}"
    if complex_model is not None:
        command += f" -ComplexModel {powershell_string(complex_model)}"
    result = subprocess.run(
        [executable, "-NoProfile", "-NonInteractive", "-Command", command],
        cwd=target, capture_output=True, text=True, timeout=20, check=False,
    )
    if "PSSecurityException" in result.stderr or "running scripts is disabled" in result.stderr:
        pytest.skip("Machine script policy blocked the helper; no execution policy was changed")
    return target, result


def test_helper_creates_local_claude_settings_without_echoing_the_key(tmp_path, powershell_executable):
    target, result = run_copied_helper(tmp_path, powershell_executable)
    assert result.returncode == 0, result.stderr
    contents = (target / ".env").read_text(encoding="utf-8")
    assert contents.splitlines() == [
        "NMATE_MODEL_PROVIDER=anthropic", "NMATE_MODE=llm",
        "NMATE_MODEL_NAME=claude-sonnet-5-5", "NMATE_SIMPLE_MODEL=claude-sonnet-5-5",
        "NMATE_COMPLEX_MODEL=claude-opus-5-5", f"ANTHROPIC_API_KEY={FAKE_ANTHROPIC}",
    ]
    assert FAKE_ANTHROPIC not in result.stdout + result.stderr
    assert list(target.glob(".env.setup-*.tmp")) == []


def test_helper_replaces_export_assignments_and_preserves_other_settings(tmp_path, powershell_executable):
    target = tmp_path / "backend with spaces"
    target.mkdir()
    original_lines = [
        "# local configuration", "NMATE_PORT=8029", f"OPENAI_API_KEY={FAKE_OPENAI}",
        "UNRELATED_MODE=keep-this", "export ANTHROPIC_API_KEY=obsolete-test-key",
        "  export NMATE_MODEL_PROVIDER = openai", "NMATE_MODE=evidence_only",
        "NMATE_MODEL_NAME=unit-model", "export NMATE_SIMPLE_MODEL=obsolete-simple",
        "export NMATE_COMPLEX_MODEL=obsolete-complex", "# NMATE_MODE=comment-only", "",
    ]
    (target / ".env").write_text("\n".join(original_lines) + "\n", encoding="utf-8")
    target, result = run_copied_helper(
        tmp_path, powershell_executable, model="claude-test-alternate", complex_model="claude-test-deep",
    )
    assert result.returncode == 0, result.stderr
    lines = (target / ".env").read_text(encoding="utf-8").splitlines()
    assert lines[:6] == original_lines[:4] + original_lines[10:]
    assert lines[6:] == [
        "NMATE_MODEL_PROVIDER=anthropic", "NMATE_MODE=llm",
        "NMATE_MODEL_NAME=claude-test-alternate", "NMATE_SIMPLE_MODEL=claude-test-alternate",
        "NMATE_COMPLEX_MODEL=claude-test-deep", f"ANTHROPIC_API_KEY={FAKE_ANTHROPIC}",
    ]
    assert "obsolete-test-key" not in "\n".join(lines)
    assert "obsolete-simple" not in "\n".join(lines)
    assert "obsolete-complex" not in "\n".join(lines)
    assert FAKE_OPENAI not in result.stdout + result.stderr
    assert FAKE_ANTHROPIC not in result.stdout + result.stderr
    assert list(target.glob(".env.setup-*.tmp")) == []


@pytest.mark.parametrize("invalid_key", [
    "not-an-api-key", "sk-ant-test\nNMATE_PORT=8999", "sk-ant-oat-FAKE_SUBSCRIPTION_TOKEN",
])
def test_helper_rejects_bad_key_before_changing_existing_file(tmp_path, powershell_executable, invalid_key):
    target = tmp_path / "backend with spaces"
    target.mkdir()
    original = b"NMATE_PORT=8029\nOPENAI_API_KEY=FAKE_KEEP\n"
    (target / ".env").write_bytes(original)
    target, result = run_copied_helper(tmp_path, powershell_executable, fake_key=invalid_key)
    assert result.returncode != 0
    assert "Expected an Anthropic API key" in result.stderr
    assert (target / ".env").read_bytes() == original
    assert list(target.glob(".env.setup-*.tmp")) == []
    assert invalid_key not in result.stdout + result.stderr


def test_helper_rejects_empty_key_without_creating_file(tmp_path, powershell_executable):
    target, result = run_copied_helper(tmp_path, powershell_executable, fake_key="")
    assert result.returncode != 0
    assert "No API key entered" in result.stderr
    assert not (target / ".env").exists()


def test_helper_rejects_other_provider_model_before_any_write(tmp_path, powershell_executable):
    target, result = run_copied_helper(tmp_path, powershell_executable, model="gpt-5-mini")
    assert result.returncode != 0
    assert not (target / ".env").exists()


def test_helper_rejects_other_provider_complex_model_before_any_write(tmp_path, powershell_executable):
    target, result = run_copied_helper(tmp_path, powershell_executable, complex_model="gpt-5-mini")
    assert result.returncode != 0
    assert not (target / ".env").exists()


def test_cmd_launcher_does_not_bypass_or_change_script_policy():
    contents = (BACKEND / "configure-claude.cmd").read_text(encoding="utf-8").lower()
    assert "-noprofile -file" in contents
    assert "-executionpolicy" not in contents
    assert "set-executionpolicy" not in contents
    assert "configure-claude.ps1" in contents
