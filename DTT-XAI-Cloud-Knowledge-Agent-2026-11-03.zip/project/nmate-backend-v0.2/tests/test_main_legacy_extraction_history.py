"""Old unconfirmed parser observations do not become navigation identities."""
import copy

from nmate.main.history import history_metadata


def old_rate_draft():
    return {"status": "awaiting_confirmation", "intake": {
        "text": "Chị bán khoảng 300 hộp trà mỗi tháng",
        "product": {"id": "new_product", "name": "trà mỗi tháng"},
        "candidates": [{"field": "name", "value": "trà mỗi tháng", "status": "candidate",
                        "source": {"kind": "server_text_extract", "quote": "trà mỗi tháng"}}]}}


def test_old_rate_phrase_is_not_republished_as_a_product_history_title():
    view = old_rate_draft()
    original = copy.deepcopy(view)
    result = history_metadata(view)
    assert "trà mỗi tháng" not in result["display_title"]
    assert result["history_state_vi"] == "Cần rà lại dữ kiện nháp"
    assert result["history_details_vi"] and result["history_extraction_review_needed"] is True
    assert view == original


def test_an_owner_confirmed_name_is_not_reinterpreted_by_the_new_parser():
    view = old_rate_draft()
    view["status"] = "confirmed"
    view["intake"]["candidates"][0]["status"] = "confirmed"
    assert history_metadata(view)["display_title"].startswith("trà mỗi tháng")


def test_valid_literal_product_draft_keeps_its_original_case():
    view = old_rate_draft()
    view["intake"].update(text="Chị có Mứt Sen, hộp 200 g",
                         product={"id": "new_product", "name": "Mứt Sen"})
    view["intake"]["candidates"][0].update(value="Mứt Sen", source={"kind": "server_text_extract"})
    assert history_metadata(view)["display_title"].startswith("Mứt Sen")


def test_model_or_file_observations_are_not_silently_reclassified_as_text_parsing():
    view = old_rate_draft()
    view["intake"]["candidates"][0]["source"]["kind"] = "spreadsheet"
    assert history_metadata(view)["display_title"].startswith("trà mỗi tháng")
