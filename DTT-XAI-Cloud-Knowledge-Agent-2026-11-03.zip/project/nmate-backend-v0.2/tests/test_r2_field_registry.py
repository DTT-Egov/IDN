"""P3/DF-001/002/003/009: one field contract, no provider or MAIN writes."""
from __future__ import annotations

import socket
import asyncio
from copy import deepcopy
from itertools import product as combinations

import pytest
from jsonschema import Draft202012Validator

from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.extraction import typed_value
from nmate.v03.domain_validation import field_advisories, field_value_contract, validate_field_value
from nmate.v03.field_registry import (FIELDS, FIELD_ENTITY_TYPES, INGESTION_FIELD_SPECS,
                                      REGISTRY_VERSION, FactActionError, adapter_contract,
                                      classify_fact_action, field_contract, finance_metric_contract, value_schema)
from nmate.v03.field_scope import field_is_in_scope, scope_contract
from test_ssot_field_scope import legacy_fact
from test_review_commands_v2 import data_snapshot
from test_r1_query_adapters import Registry


@pytest.fixture(autouse=True)
def local_only(monkeypatch):
    connect, connect_ex = socket.socket.connect, socket.socket.connect_ex

    def bounded(method):
        def run(sock, address):
            # Windows asyncio creates an internal loopback socket pair. This
            # permits that mechanism; every external address still fails.
            if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
                return method(sock, address)
            raise AssertionError("R2 field tests must not use external network or a provider")
        return run

    monkeypatch.setattr(socket.socket, "connect", bounded(connect))
    monkeypatch.setattr(socket.socket, "connect_ex", bounded(connect_ex))


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "r2-fields.sqlite3")
    owner = LocalAccounts(repo).register("r2-field-owner", "Local-field-test-password", "Trà Sen QA")
    service = CoreSSOTService(repo)
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    return repo, service, owner, product


@pytest.mark.parametrize("value", [False, {"label": "hộp"}, ["hộp"]])
def test_document_text_contract_also_applies_at_canonical_writes(workspace, value):
    repo, service, owner, product = workspace
    with pytest.raises(CoreError):
        typed_value("packaging", value)
    before = data_snapshot(repo)
    for kind, invoke in (
        ("direct", repo.propose_or_apply_facts), ("proposal", service.propose_facts),
    ):
        with pytest.raises(CoreError):
            invoke(owner["account_id"], owner["enterprise_id"], product["id"],
                   [{"field": "packaging", "value": value}], 0, "invalid-" + kind)
        assert data_snapshot(repo) == before


def test_qualified_name_inherits_length_validation_without_rewriting_exact_key(workspace):
    repo, service, owner, product = workspace
    before = data_snapshot(repo)
    for kind, invoke in (("direct", repo.propose_or_apply_facts), ("proposal", service.propose_facts)):
        with pytest.raises(CoreError):
            invoke(owner["account_id"], owner["enterprise_id"], product["id"],
                   [{"field": "Name.alternate", "value": "x" * 251}], 0, "long-" + kind)
        assert data_snapshot(repo) == before


def test_contracts_have_one_immutable_versioned_source_and_return_detached_metadata():
    from nmate.v03 import field_scope
    from nmate.v04.extraction import FIELD_SPECS
    assert field_scope.FIELD_ENTITY_TYPES is FIELD_ENTITY_TYPES
    assert FIELD_SPECS is INGESTION_FIELD_SPECS
    assert scope_contract("product")["field_registry_version"] == REGISTRY_VERSION
    with pytest.raises(TypeError):
        FIELDS["arbitrary_extension"] = FIELDS["name"]
    with pytest.raises(Exception):
        FIELDS["name"].kind = "object"
    first = field_contract("Net_Quantity.batch-1")
    first["entity_types"].clear()
    first["value_schema"]["x-units"].clear()
    assert field_contract("Net_Quantity.batch-1")["entity_types"] == ["product"]
    assert "g" in field_contract("Net_Quantity.batch-1")["value_schema"]["x-units"]
    assert field_value_contract("Net_Quantity.batch-1")["base_field"] == "net_quantity"
    assert field_contract("private_extension") is None and value_schema("private_extension") is None


def test_every_enabled_ingestion_field_has_matching_scope_and_output_type():
    examples = {
        "trading_name": "Cơ sở Trà Sen", "name": "Trà Sen Tây Hồ", "product_code": "TS-01",
        "net_quantity": "3.5 oz", "packaging": "hộp giấy", "ingredients": "Trà và sen",
        "origin_country": "VN", "sales_management": "Sổ", "inventory_management": "Excel",
        "employee_count": "0", "revenue": {"amount": 0, "currency": "VND", "period": "2026"},
        "business_goal": "Xuất khẩu",
    }
    metadata = adapter_contract()
    assert set(metadata["fields"]) == set(examples)
    for field, original in examples.items():
        label, entity, declared_type = INGESTION_FIELD_SPECS[field]
        original_copy = deepcopy(original)
        value, kind = typed_value(field, original)
        assert kind == declared_type
        assert original == original_copy
        assert field_is_in_scope(entity, field)
        assert validate_field_value(field, value) is None
        Draft202012Validator(value_schema(field)).validate(value)
        assert metadata["fields"][field]["entity_type"] == entity
        assert metadata["fields"][field]["label_vi"] == label


@pytest.mark.parametrize("field,good,bad", [
    ("net_quantity", "100 g", "100 g abc"), ("net_weight", "0,1 kg", "100 ml"),
    ("product_code", "TS-01", "TS 01"), ("sku", "AB/01", "A<>B"),
    ("employee_count", 0, True), ("employees", 2, -1),
    ("packaging", "túi zip", {"value": "túi zip"}),
    ("ingredients", ["Trà", "Sen"], ["Trà", 1]),
    ("certifications", [], [False]), ("name", "Trà Sen Tây Hồ", "x" * 251),
])
def test_base_case_and_qualifier_share_value_and_scope_not_exact_identity(field, good, bad):
    expected_scope = FIELD_ENTITY_TYPES[field]
    for key in [field, field.upper(), field + ".2026", field.upper() + ".private.1"]:
        assert validate_field_value(key, good) is None
        assert validate_field_value(key, bad)["field"] == key
        assert field_contract(key)["entity_types"] == sorted(expected_scope)
        for entity in {"enterprise", "product", "facility", "market_profile"}:
            assert field_is_in_scope(entity, key) is (entity in expected_scope)


def test_quantity_advisory_distinguishes_mass_volume_and_never_converts():
    for value, code in [("3.5 oz", "ounce_mass"), ("3.5 OZ", "ounce_mass"), ("3.5 fl oz", "ounce_volume")]:
        assert field_advisories("Net_Quantity.batch", value)[0]["code"] == code
        assert CoreRepository._normalize_fact({"field": "Net_Quantity.batch", "value": value})["value"] == value
    assert field_advisories("net_quantity", "100 g") == []
    assert field_advisories("net_weight", "3.5 fl oz") == []
    assert field_advisories("private_quantity", "3.5 oz") == []
    assert field_advisories("net_quantity", "nan oz") == []


def test_falsy_and_clear_state_machine_matches_canonical_command_contract():
    # Exhaustive finite transition corpus; field-specific type validation is
    # independent. A zero/list/False/empty extension is never an inferred clear.
    for value, state, clear in combinations([None, 0, False, [], "", "x"],
        ["known", "unknown", "known_absent", "not_applicable", "withheld", "conflicted"], [False, True]):
        item = {"field": "private_extension", "value": deepcopy(value), "value_state": state, "explicit_clear": clear}
        if (clear and value is not None) or (not clear and state != "known" and value is not None):
            with pytest.raises(FactActionError) as action_error:
                classify_fact_action(item)
            with pytest.raises(CoreError) as command_error:
                CoreRepository._normalize_fact(item)
            assert action_error.value.code == command_error.value.code
        else:
            action = classify_fact_action(item)
            normalized = CoreRepository._normalize_fact(item)
            if action.action == "noop":
                assert normalized is None
            else:
                assert normalized["value"] == value and normalized["value_state"] == action.value_state
                assert normalized["explicit_clear"] is clear


def test_legacy_invalid_text_is_quarantined_without_rewriting_history_or_decisions(workspace):
    repo, service, owner, entity = workspace
    assertion = legacy_fact(repo, owner, entity["id"], "packaging", {"malformed": "hộp"})
    before = data_snapshot(repo)
    args = owner["account_id"], owner["enterprise_id"]
    for context in (repo.get_context(*args, [entity["id"]]), service.get_context(*args, [entity["id"]], save_snapshot=False)):
        assert "packaging" not in context["entities"][0]["values"]
    view = repo.get_entity(*args, entity["id"])
    assert all(fact["field"] != "packaging" for fact in view["facts"])
    assert view["validation_issues"][0]["code"] == "invalid_field_value"
    assert repo.get_fact_history(*args, entity["id"])[0]["id"] == assertion
    assert repo.get_fact_history(*args, entity["id"])[0]["value"] == {"malformed": "hộp"}
    assert data_snapshot(repo) == before


def test_qualifier_classification_never_widens_exact_extension_grants(workspace):
    repo, service, owner, entity = workspace
    args = owner["account_id"], owner["enterprise_id"]
    facts = [{"field": "Name.alternate", "value": "Tên phụ"}, {"field": "custom.private", "value": False}]
    saved = repo.propose_or_apply_facts(*args, entity["id"], facts, 0, "exact-key")
    assert {fact["field"]: fact["value"] for fact in saved["facts"]}["Name.alternate"] == "Tên phụ"
    staff = LocalAccounts(repo).register("r2-field-staff", "Local-field-test-password", "Riêng")
    service.add_member(*args, staff["username"])
    service.grant_resource(*args, entity["id"], staff["account_id"], ["read"], ["name", "custom"])
    assert not service.can_read(staff["account_id"], args[1], entity["id"], "Name.alternate")
    assert not service.can_read(staff["account_id"], args[1], entity["id"], "custom.private")
    service.grant_resource(*args, entity["id"], staff["account_id"], ["read"], ["Name.alternate", "custom.private"])
    assert service.can_read(staff["account_id"], args[1], entity["id"], "Name.alternate")
    assert service.can_read(staff["account_id"], args[1], entity["id"], "custom.private")


def test_d05_metrics_use_registry_units_without_becoming_ssot_value_or_egress_authority():
    from nmate.core_v1.finance import METRIC_LABELS, FinanceService
    from nmate.v03.field_registry import FINANCE_METRIC_LABELS
    assert METRIC_LABELS is FINANCE_METRIC_LABELS
    for code in METRIC_LABELS:
        contract = finance_metric_contract(code)
        assert contract["egress"] == "exact_metric_grant_seal_required"
        assert contract["registry_version"] == REGISTRY_VERSION
        assert field_contract(code)["sensitivity"] == "finance"
        good = {"metric_code": code, "value": "0", "unit": "person" if contract["whole_number_required"] else "USD",
                "period_start": "2026-01-01", "period_end": "2027-01-01"}
        assert FinanceService._metric(good)["value_decimal"] == "0"
        for raw in [True, "nan", "Infinity", "1,000", "1e3"]:
            with pytest.raises(CoreError):
                FinanceService._metric({**good, "value": raw})
    assert finance_metric_contract("Revenue.2026") is None


def test_registered_mcp_fact_commands_use_the_same_field_guard_and_keep_proposals_separate(workspace):
    from nmate.core_v1.integration import CoreIntegration
    repo, service, owner, entity = workspace
    integration = object.__new__(CoreIntegration)
    integration.core = service
    # The partial-constructor unit harness must initialize new registration
    # dependencies; the production factory never skips this capability.
    from nmate.policy_v05.integration import Policy05Integration
    integration.repo, integration.policy = repo, None
    integration.policy05 = Policy05Integration(integration)
    registry = Registry()

    async def authorized(command):
        return command(owner["account_id"])

    integration.register_tools(registry, authorized)
    before = data_snapshot(repo)
    for index, (field, value) in enumerate([("packaging", False), ("name", "x" * 251),
                                           ("NET_QUANTITY.batch", "100 ml abc"), ("sku", "TS 01")]):
        with pytest.raises(CoreError):
            asyncio.run(registry.tools["core_propose_facts"](owner["enterprise_id"], entity["id"],
                [{"field": field, "value": value}], 0, "invalid-mcp-" + str(index)))
        assert data_snapshot(repo) == before
    proposal = asyncio.run(registry.tools["core_propose_facts"](owner["enterprise_id"], entity["id"],
                [{"field": "net_quantity", "value": "3.5 oz"}], 0, "valid-mcp-proposal"))
    assert proposal["status"] == "awaiting_owner"
    assert repo.get_entity(owner["account_id"], owner["enterprise_id"], entity["id"])["facts"] == []


def test_quantity_schema_never_rewrites_valid_unicode_or_finite_decimal_representation():
    for field in ("net_quantity", "net_weight"):
        schema = Draft202012Validator(value_schema(field))
        for value in ("١٠٠ g", "100 µg", "100 μg", "100 UG", "0,1 kg", "000.0010 g", "100G", " 100 g "):
            assert validate_field_value(field, value) is None
            assert schema.is_valid(value)
