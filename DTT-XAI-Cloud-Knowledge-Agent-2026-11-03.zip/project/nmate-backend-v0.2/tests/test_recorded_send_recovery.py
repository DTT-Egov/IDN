"""False application rejection can reuse the exact SDK response with no SDK path."""
import json

import pytest

from nmate.v03.core import CoreError
import nmate.v04.live_review as live
from test_unified_main import setup as setup_fixture, scope, docs


@pytest.fixture(name="workspace")
def recorded_workspace(tmp_path):
    return setup_fixture.__wrapped__(tmp_path)


async def rejected(workspace, monkeypatch):
    repo, owner, _, _, _, _, _, chat = workspace
    conversation = await docs(workspace)
    request = dict(text="Tôi muốn số hóa bán hàng và tồn kho", attachments=[], conversation_id=conversation["id"],
                   product_entity_id=conversation["intake"]["product"]["id"], draft=None,
                   target_intake_id=None, task_hint="sales_inventory", market_code=None)
    original = live.validate_output

    def old_false_rejection(*args):
        raise CoreError("LIVE_SAVE_CLAIM_INVALID", "Old false-positive guard", 502)

    monkeypatch.setattr(live, "validate_output", old_false_rejection)
    with pytest.raises(CoreError):
        await chat.send_async(*scope(owner), operation_id="recorded-stock", paid_consent=True, **request)
    monkeypatch.setattr(live, "validate_output", original)
    with repo.connection() as db:
        response = db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id='recorded-stock'").fetchone()[0]
        facts = [tuple(r) for r in db.execute("SELECT * FROM v03_fact_assertions ORDER BY id")]
    return request, response, facts


@pytest.mark.asyncio
async def test_exact_recorded_send_recovers_with_same_attempt_and_no_ssot_write(workspace, monkeypatch):
    repo, owner, _, model, provider, _, _, chat = workspace
    request, original_response, facts = await rejected(workspace, monkeypatch)
    calls = len(model.calls)
    result = await chat.recover_recorded_send_async(*scope(owner), "recorded-stock", request)
    assert result["status"] != "failed" and result["model_calls"] == 2
    assert len(model.calls) == calls and provider.summary()["provider_attempts"] == 2
    assert result["application_recoveries"][0]["provider_calls"] == 0
    again = await chat.recover_recorded_send_async(*scope(owner), "recorded-stock", request)
    assert len(again["application_recoveries"]) == 1 and len(model.calls) == calls
    with repo.connection() as db:
        assert db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id='recorded-stock'").fetchone()[0] == original_response
        assert [tuple(r) for r in db.execute("SELECT * FROM v03_fact_assertions ORDER BY id")] == facts
        audit = db.execute("SELECT * FROM main_application_recoveries").fetchone()
        assert audit["original_error_code"] == "LIVE_SAVE_CLAIM_INVALID" and audit["recovered_at"]


@pytest.mark.asyncio
@pytest.mark.parametrize("mutation", ["request", "context", "owner", "invalid_output"])
async def test_recovery_fails_closed_without_a_new_dispatch(workspace, monkeypatch, mutation):
    repo, owner, other, model, provider, _, _, chat = workspace
    request, _, _ = await rejected(workspace, monkeypatch)
    calls = len(model.calls)
    who = other if mutation == "owner" else owner
    if mutation == "request":
        request["text"] += " changed"
    elif mutation == "context":
        product = repo.get_entity(*scope(owner), request["product_entity_id"])
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "999 g"}], product["version"], "new-fact")
    elif mutation == "invalid_output":
        with repo.connection(write=True) as db:
            row = db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id='recorded-stock'").fetchone()
            data = json.loads(row[0])
            data["data"]["assistant_text"] = "Mình đã lưu dữ liệu vào hồ sơ."
            db.execute("UPDATE v03_live_attempts SET response_json=? WHERE operation_id='recorded-stock'", (json.dumps(data),))
    with pytest.raises(CoreError):
        await chat.recover_recorded_send_async(*scope(who), "recorded-stock", request)
    assert len(model.calls) == calls and provider.summary()["provider_attempts"] == 2
