"""DF-029/046: synthetic old-start receipts; never reserve or dispatch a model.

The fixture inserts only an isolated operation record to exercise replay. It
does not create a usable D06 grant, attempt, provider result or main-app record.
"""
import json

import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.policy_v1.catalog import digest
from nmate.policy_v1.service import PolicyService
from nmate.v03.core import CoreError, CoreRepository, now_iso
from nmate.v03.identity import LocalAccounts


class NoDispatchGateway:
    def _grant(self, *args, **kwargs):
        pytest.fail("Replay must not reserve a grant or attempt")


@pytest.fixture
def replay_scope(tmp_path):
    repo = CoreRepository(tmp_path / "private-replay-acl.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("replay-design-owner", "Synthetic-owner-pass-123", "Cơ sở QA riêng")
    staff = accounts.register("replay-design-staff", "Synthetic-staff-pass-456", "Cơ sở khác QA")
    core = CoreSSOTService(repo)
    core.add_member(owner["account_id"], owner["enterprise_id"], "replay-design-staff")
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Tên QA riêng")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
                               [{"field": "name", "value": "Tên QA chỉ đọc khi có quyền"}], 0, "fixture-name")
    core.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"],
                        ["read"], ["name", "legal_name"])
    service = PolicyService(repo, core=core, gateway=NoDispatchGateway())
    return repo, core, service, owner, staff, entity


def old_start(repo, service, actor, enterprise, entity):
    case = service.prepare(actor, enterprise, "Số hóa kho có chương trình nào phù hợp?", "prepare-fixture",
                           entity_ids=[entity["id"]])
    assert case["context"]["fact_refs"]
    request = {"mission_id": case["id"], "budget_grant_id": "fixture-no-usable-grant", "model_role": "complex"}
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_operations VALUES(?,?,?,?,?,?,?)",
                   (enterprise, actor, "start", "start-fixture", digest(request), case["id"], now_iso()))
        db.execute("UPDATE pol_missions SET status='completed_partial' WHERE id=?", (case["id"],))
        raw = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (case["id"],)).fetchone()[0]
    return case, request, raw


@pytest.mark.parametrize("field_keys", [["name"], None], ids=["field-read-revoked", "resource-read-revoked"])
def test_policy_start_replay_rechecks_original_current_read_permissions(replay_scope, field_keys):
    repo, core, service, owner, staff, entity = replay_scope
    actor, enterprise = staff["account_id"], owner["enterprise_id"]
    case, request, raw = old_start(repo, service, actor, enterprise, entity)
    core.revoke_resource(owner["account_id"], enterprise, entity["id"], actor, ["read"], field_keys)
    with pytest.raises(CoreError) as get_denied:
        service.get(actor, enterprise, case["id"])
    assert get_denied.value.status_code == 403
    with pytest.raises(CoreError) as replay_denied:
        service.start(actor, enterprise, case["id"], "start-fixture", request["budget_grant_id"])
    assert replay_denied.value.status_code == 403
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (case["id"],)).fetchone()[0] == raw
        assert db.execute("SELECT COUNT(*) FROM pol_operations WHERE kind='start'").fetchone()[0] == 1


def test_policy_start_replay_keeps_archived_history_readable_without_new_write_or_dispatch(replay_scope):
    repo, _, service, owner, _, entity = replay_scope
    actor, enterprise = owner["account_id"], owner["enterprise_id"]
    case, request, raw = old_start(repo, service, actor, enterprise, entity)
    current = repo.get_entity(actor, enterprise, entity["id"])
    repo.archive_entity(actor, enterprise, entity["id"], current["version"], "archive-fixture-product")
    replay = service.start(actor, enterprise, case["id"], "start-fixture", request["budget_grant_id"])
    assert replay["id"] == case["id"] and replay["status"] == "completed_partial"
    assert replay["is_historical"]
    assert any("cất" in warning or "lưu trữ" in warning for warning in replay["current_warnings_vi"])
    assert replay["context"] == json.loads(raw)["context"]
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (case["id"],)).fetchone()[0] == raw
        assert db.execute("SELECT COUNT(*) FROM pol_operations WHERE kind='start'").fetchone()[0] == 1


def test_policy_start_replay_still_requires_exact_original_request_hash(replay_scope):
    repo, _, service, owner, _, entity = replay_scope
    actor, enterprise = owner["account_id"], owner["enterprise_id"]
    case, request, raw = old_start(repo, service, actor, enterprise, entity)
    with pytest.raises(CoreError) as mismatch:
        service.start(actor, enterprise, case["id"], "start-fixture", "different-fixture-no-grant")
    assert mismatch.value.code == "idempotency_conflict"
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (case["id"],)).fetchone()[0] == raw
