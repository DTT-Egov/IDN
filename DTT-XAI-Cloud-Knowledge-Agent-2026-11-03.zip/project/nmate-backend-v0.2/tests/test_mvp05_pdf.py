from io import BytesIO

from pypdf import PdfReader

from nmate.policy_v05.pdf import render_policy_draft


def text(draft):
    return "\n".join(page.extract_text() for page in PdfReader(BytesIO(render_policy_draft(draft))).pages)


def draft():
    return {"title": "Đề nghị hướng dẫn đào tạo", "version": 2, "kind": "request_guidance",
            "body": {"enterprise_summary": "Cơ sở Trà Sen", "request": "Xin lịch lớp kế toán buổi tối."},
            "checklist": [], "status": "draft"}


def test_pdf_uses_vietnamese_labels_and_guidance_limit():
    value = text(draft())
    assert "Thông tin cơ sở" in value and "enterprise_summary" not in value
    assert "Đề nghị hướng dẫn" in value
    assert "chưa xác minh đủ chương trình" in value
    assert "BẢN NHÁP" in value and "Chưa gửi" in value


def test_historical_pdf_keeps_saved_body_but_prints_current_warning():
    saved = draft()
    saved.update(is_historical=True, current_warnings_vi=["Dữ kiện cơ sở đã đổi; bản nháp giữ thông tin tại lúc lập."])
    value = text(saved)
    assert "Cơ sở Trà Sen" in value
    assert "Dữ kiện cơ sở đã đổi" in value
    assert "Bản nháp lịch sử" in value


def test_pdf_has_narrative_order_even_when_sql_json_keys_are_sorted():
    item = draft()
    item['body'] = dict(sorted({'enterprise_summary': 'Cơ sở Trà Sen', 'requested_support': 'Đào tạo',
                               'situation': 'Cần lớp buổi tối', 'impact': '', 'request': 'Đề nghị hướng dẫn'}.items()))
    value = text(item)
    labels = ['Thông tin cơ sở', 'Hỗ trợ mong muốn', 'Tình hình và nhu cầu', 'Ảnh hưởng', 'Nội dung đề nghị']
    assert [value.index(label) for label in labels] == sorted(value.index(label) for label in labels)
    assert '[Chưa cung cấp]' in value
