"""V17: typed enterprise identity and useful policy artifacts, without AI.

All identities and claims are synthetic. The tests exercise the real SSOT,
ACL, immutable receipt, draft-version and PDF paths on temporary databases.
"""
from io import BytesIO
import json

from pypdf import PdfReader
import pytest

from nmate.core_v1.ssot import CoreSSOTService
from nmate.policy_v05.pdf import render_policy_draft
from nmate.policy_v05.workbench import PolicyWorkbench, request_details
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


QUESTION = ('Chị muốn hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách, '
            'đồng thời kiến nghị mở lớp buổi tối vì ban ngày nhân viên phải bán hàng.')


@pytest.fixture
def scoped(tmp_path):
    repo = CoreRepository(tmp_path / 'v17-policy.sqlite3')
    accounts = LocalAccounts(repo)
    owner = accounts.register('v17-policy-owner', 'Synthetic-Only-12345', 'Cơ sở kiểm thử')
    peer = accounts.register('v17-policy-peer', 'Synthetic-Only-12345', 'Cơ sở khác')
    core = CoreSSOTService(repo)
    company = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Hồ sơ cơ sở thử')
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'], [
        {'field': 'trading_name', 'value': 'Cơ sở Trà Sen kiểm thử'},
        {'field': 'legal_form', 'value': 'Hộ kinh doanh'}, {'field': 'province', 'value': 'Hà Nội'},
    ], 0, 'company-facts')
    return repo, core, PolicyWorkbench(repo, core), owner, peer, company


def make(scoped, question=QUESTION, kind='business_petition', operation='create'):
    _, _, workbench, owner, _, company = scoped
    return workbench.create_draft(owner['account_id'], owner['enterprise_id'], question, kind, operation,
                                  enterprise_entity_id=company['id'])


def pdf_text(payload):
    return '\n'.join(page.extract_text() for page in PdfReader(BytesIO(render_policy_draft(payload))).pages)


def test_confirmed_trading_name_is_not_missing_or_promoted_to_legal_identity(scoped):
    draft = make(scoped)
    summary = draft['body']['enterprise_summary']
    assert 'Tên giao dịch đã xác nhận: Cơ sở Trà Sen kiểm thử' in summary
    assert 'Tên pháp lý chưa có dữ kiện xác nhận' in summary
    assert 'Tên cơ sở/pháp lý chưa có dữ kiện xác nhận' not in summary
    refs = draft['context_manifest']['fact_refs']
    assert any(ref['field'] == 'trading_name' and ref['assertion_id'] for ref in refs)
    assert 'Tên giao dịch đã xác nhận: Cơ sở Trà Sen kiểm thử' in pdf_text(draft)


def test_trading_and_legal_names_remain_distinct_exact_facts(scoped):
    repo, _, _, owner, _, company = scoped
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'], [
        {'field': 'legal_name', 'value': 'Hộ kinh doanh kiểm thử pháp lý'},
    ], 1, 'legal-name')
    draft = make(scoped)
    assert 'Tên giao dịch đã xác nhận: Cơ sở Trà Sen kiểm thử' in draft['body']['enterprise_summary']
    assert 'Tên pháp lý đã xác nhận: Hộ kinh doanh kiểm thử pháp lý' in draft['body']['enterprise_summary']
    assert 'Tên pháp lý chưa có' not in draft['body']['enterprise_summary']
    assert {ref['field'] for ref in draft['context_manifest']['fact_refs']} >= {'trading_name', 'legal_name'}


def test_exact_field_acl_is_not_opened_by_identity_rendering(scoped):
    repo, _, workbench, owner, peer, company = scoped
    # A wildcard resource READ must not open an explicitly restricted exact key.
    with repo.connection(write=True) as db:
        db.execute('INSERT INTO v03_memberships VALUES(?,?,?,1)',
                   (peer['account_id'], owner['enterprise_id'], 'staff'))
        db.execute("INSERT OR REPLACE INTO core_v1_field_definitions VALUES('trading_name','restricted','owner_required',1)")
        db.execute("INSERT INTO core_v1_resources VALUES(?,?,'ssot_entity',?,1,datetime('now'))",
                   (owner['enterprise_id'], company['id'], owner['account_id']))
        db.execute("INSERT INTO core_v1_grants VALUES(?,?,?,'read','*',?,datetime('now'),NULL)",
                   (owner['enterprise_id'], company['id'], peer['account_id'], owner['account_id']))
    draft = workbench.create_draft(peer['account_id'], owner['enterprise_id'], QUESTION,
        'business_petition', 'staff-create', enterprise_entity_id=company['id'])
    assert 'Cơ sở Trà Sen kiểm thử' not in draft['body']['enterprise_summary']
    assert not any(ref['field'] == 'trading_name' for ref in draft['context_manifest']['fact_refs'])
    with pytest.raises(CoreError):
        workbench.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])


def test_petition_keeps_specific_request_and_does_not_use_registration_checklist(scoped):
    draft = make(scoped)
    assert 'mở lớp buổi tối vì ban ngày nhân viên phải bán hàng' in draft['body']['request']
    assert draft['body']['situation'] == QUESTION
    assert sum(value.count(QUESTION) for value in draft['body'].values()) == 1
    assert draft['body']['impact'] == ''
    checklist = ' '.join(item['label_vi'] for item in draft['checklist'])
    assert 'đăng ký' not in checklist and 'đợt tiếp nhận' not in checklist
    assert 'kiến nghị' in checklist and 'nơi nhận' in checklist
    assert draft['program_readiness']['application_open'] is None
    assert draft['provider_calls'] == 0
    assert draft['artifact_contract_version'] == 'policy-artifact/2'
    assert draft['request_details']
    for detail in draft['request_details']:
        assert detail['source'] == 'question'
        assert QUESTION[detail['start']:detail['end']] == detail['text']


def test_need_explanations_follow_petition_artifact_purpose(scoped):
    petition = make(scoped)
    guidance = make(scoped, kind='participation_request', operation='guidance-for-need-copy')
    assert petition['needs'] and guidance['needs']
    for need in petition['needs']:
        assert 'kiến nghị' in need['reason_vi']
        assert 'nơi nhận' in need['reason_vi']
        assert 'bằng chứng' in need['reason_vi']
        assert not any(word in need['reason_vi'] for word in ('đăng ký', 'đợt tiếp nhận', 'điều kiện'))
        assert need['status'] == 'needs_verification'
    assert all('đợt tiếp nhận' in need['reason_vi'] and 'đăng ký' in need['reason_vi'] for need in guidance['needs'])
    assert petition['purposes'] == guidance['purposes']


@pytest.mark.parametrize('question, wanted, excluded', [
    ('Chị muốn kiến nghị đào tạo nhân viên sổ sách buổi tối.', 'đào tạo nhân viên sổ sách buổi tối', ''),
    ('Chị không đề nghị mua thiết bị; chị chỉ đề nghị mở lớp sổ sách buổi tối.',
     'mở lớp sổ sách buổi tối', 'mua thiết bị'),
    ('Chị muốn đào tạo nhân viên; cơ sở chưa có thiệt hại. Chị kiến nghị mở lớp buổi tối.',
     'mở lớp buổi tối', 'đã thiệt hại'),
    ('Chị đề nghị mở lớp sổ sách buổi tối và đề nghị công bố lịch học sớm.',
     'mở lớp sổ sách buổi tối', ''),
    ('Chị đề nghị mở lớp sổ sách buổi tối ngày 26.10.2026 cho 3.5 giờ mỗi tuần.',
     'ngày 26.10.2026 cho 3.5 giờ mỗi tuần', ''),
])
def test_verbatim_request_corpus_has_no_negated_or_invented_request(scoped, question, wanted, excluded):
    draft = make(scoped, question=question)
    assert wanted in draft['body']['request']
    if excluded:
        assert excluded not in draft['body']['request']
    assert 'được phê duyệt' not in draft['body']['request']
    assert draft['body']['impact'] == ''


def test_all_explicit_petition_actions_survive_and_an_edit_has_its_own_provenance(scoped):
    _, _, workbench, owner, *_ = scoped
    question = 'Chị đề nghị mở lớp sổ sách buổi tối và đề nghị công bố lịch học sớm.'
    draft = make(scoped, question=question)
    assert 'mở lớp sổ sách buổi tối' in draft['body']['request']
    assert 'công bố lịch học sớm' in draft['body']['request']
    assert len(draft['request_details']) == 2
    edited = workbench.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1,
        {'request': 'Chị đề nghị lớp vào thứ Bảy.'}, 'edit-specific-request')
    assert edited['request_details'] == [{'source': 'draft_edit', 'actor_id': owner['account_id'],
                                        'version': 2, 'text': 'Chị đề nghị lớp vào thứ Bảy.'}]
    assert draft['request_details'][0]['source'] == 'question'


def test_guidance_has_its_own_preparation_and_keeps_original_request(scoped):
    draft = make(scoped, kind='participation_request')
    assert draft['kind'] == 'request_guidance'
    assert 'mở lớp buổi tối' in draft['body']['request']
    assert any(item['id'] == 'verify_programme' for item in draft['checklist'])
    assert 'chưa phải mẫu đăng ký chính thức' in ' '.join(draft['limitations_vi'])
    assert draft['program_readiness']['eligibility'] == 'not_assessed'


def test_approval_pdf_exact_revision_state_and_brand(scoped):
    _, _, workbench, owner, *_ = scoped
    draft = make(scoped)
    unapproved = pdf_text(draft)
    assert 'nMate' in unapproved and 'DTT XAI' not in unapproved
    assert 'Phiên bản này chưa được duyệt nội dung' in unapproved
    approved = workbench.approve_draft(owner['account_id'], owner['enterprise_id'], draft['id'],
        1, draft['content_hash'], True, 'approve-v1')
    approved_text = pdf_text(workbench.export_payload(owner['account_id'], owner['enterprise_id'], draft['id']))
    assert 'Đã duyệt nội dung phiên bản 1' in approved_text
    assert 'Chưa gửi' in approved_text
    edited = workbench.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1,
        {'impact': 'Hai nhân viên muốn tham gia.'}, 'edit-v2')
    edited_text = pdf_text(edited)
    assert 'Phiên bản này chưa được duyệt nội dung' in edited_text
    assert 'Lần duyệt trước không áp dụng' in edited_text
    # A mismatched approval DTO cannot make another revision appear approved.
    mismatched = dict(edited, approval=approved['approval'], status='approved')
    assert 'Đã duyệt nội dung phiên bản 2' not in pdf_text(mismatched)


def test_stale_edit_is_explicitly_blocked_without_rebase_or_old_receipt_mutation(scoped):
    repo, _, workbench, owner, _, company = scoped
    draft = make(scoped)
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'],
        [{'field': 'trading_name', 'value': 'Cơ sở đã đổi tên'}], 1, 'change-company')
    with pytest.raises(CoreError) as exc:
        workbench.update_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1,
            {'request': 'Nội dung đang sửa'}, 'stale-edit')
    assert exc.value.code == 'context_changed'
    saved = workbench.get_draft(owner['account_id'], owner['enterprise_id'], draft['id'])
    assert saved['is_historical'] and saved['version'] == 1
    assert saved['body'] == draft['body'] and saved['content_hash'] == draft['content_hash']
    assert make(scoped) == draft  # exact replay is READ and preserves old context.
    with repo.connection() as db:
        assert db.execute('SELECT COUNT(*) FROM pol05_revisions WHERE draft_id=?', (draft['id'],)).fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM v03_operations WHERE operation_id='stale-edit'").fetchone()[0] == 0
        raw = json.loads(db.execute('SELECT payload_json FROM pol05_drafts WHERE id=?', (draft['id'],)).fetchone()[0])
        assert 'is_historical' not in raw


def test_trading_name_change_invalidates_approval_and_revocation_wins_replay(scoped):
    repo, _, workbench, owner, _, company = scoped
    draft = make(scoped)
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], company['id'],
        [{'field': 'trading_name', 'value': 'Cơ sở đã đổi tên'}], 1, 'change-name')
    with pytest.raises(CoreError) as exc:
        workbench.approve_draft(owner['account_id'], owner['enterprise_id'], draft['id'], 1,
                               draft['content_hash'], True, 'new-approval')
    assert exc.value.code == 'context_changed'
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (company['id'],))
    with pytest.raises(CoreError) as exc:
        make(scoped)
    assert exc.value.status_code == 403


def test_old_artifact_contract_remains_exact_history_but_needs_new_draft_for_mutation(scoped, monkeypatch):
    import nmate.policy_v05.workbench as module
    _, _, workbench, owner, *_ = scoped
    # Build a synthetic older-contract artifact through the real command path;
    # no stored assertion, revision or receipt is rewritten for this fixture.
    with monkeypatch.context() as historical:
        historical.setattr(module, 'ARTIFACT_CONTRACT_VERSION', 'policy-artifact/1')
        old = make(scoped)
    current = workbench.get_draft(owner['account_id'], owner['enterprise_id'], old['id'])
    assert current['is_historical']
    assert any('hợp đồng trước' in note for note in current['current_warnings_vi'])
    assert current['content_hash'] == old['content_hash'] and current['body'] == old['body']
    assert make(scoped) == old  # existing receipt stays a READ, not a new write.
    with pytest.raises(CoreError) as exc:
        workbench.update_draft(owner['account_id'], owner['enterprise_id'], old['id'], 1,
                               {'impact': 'Nội dung mới'}, 'edit-old-contract')
    assert exc.value.code == 'draft_contract_outdated'
    with pytest.raises(CoreError) as exc:
        workbench.approve_draft(owner['account_id'], owner['enterprise_id'], old['id'], 1,
                                old['content_hash'], True, 'approve-old-contract')
    assert exc.value.code == 'draft_contract_outdated'


def test_new_implicit_draft_uses_explicit_profile_binding_not_another_company(scoped):
    from nmate.core_v1.enterprise_profile import EnterpriseProfileService, SCHEMA
    repo, core, workbench, owner, _, company = scoped
    with repo.connection(write=True) as db:
        db.executescript(SCHEMA)
    other = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở phụ')
    EnterpriseProfileService(repo, core).open(owner['account_id'], owner['enterprise_id'], 'link-company',
                                             existing_entity_id=company['id'])
    draft = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                   'business_petition', 'implicit-bound')
    assert draft['context_manifest']['enterprise_entity_id'] == company['id']
    assert other['id'] not in {item['entity_id'] for item in draft['context_manifest']['entities']}
    # Losing current READ must deny a new command, never select the remaining
    # visible company as a convenient implicit replacement.
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (company['id'],))
    with pytest.raises(CoreError) as exc:
        workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                               'business_petition', 'implicit-after-revoke')
    assert exc.value.status_code == 403


def test_later_profile_binding_never_reinterprets_an_exact_draft_receipt(scoped):
    from nmate.core_v1.enterprise_profile import EnterpriseProfileService, SCHEMA
    repo, core, workbench, owner, _, company = scoped
    with repo.connection(write=True) as db:
        db.executescript(SCHEMA)
    original = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                     'business_petition', 'old-implicit')
    other = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở phụ được liên kết')
    EnterpriseProfileService(repo, core).open(owner['account_id'], owner['enterprise_id'], 'link-other',
                                             existing_entity_id=other['id'])
    replay = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                   'business_petition', 'old-implicit')
    assert replay == original
    assert replay['context_manifest']['enterprise_entity_id'] == company['id']
    fresh = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                   'business_petition', 'new-implicit')
    assert fresh['context_manifest']['enterprise_entity_id'] == other['id']


def case_with_later_canonical(scoped, *, case_enterprises=None, product_only=False):
    from nmate.core_v1.enterprise_profile import EnterpriseProfileService
    repo, core, workbench, owner, _, company = scoped
    other = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở B của ca cũ')
    canonical = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở C liên kết sau')
    product = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'product', 'Trà Sen của ca cũ')
    EnterpriseProfileService(repo, core).open(owner['account_id'], owner['enterprise_id'], 'case-later-canonical',
                                             existing_entity_id=canonical['id'])
    class CaseService:
        entities = ([product] if product_only else
                    [company] if case_enterprises == 'one' else [company, other])
        def get(self, account, enterprise, identity):
            return {'id': identity, 'conversation_id': None, 'context': {'entities': self.entities}}
    workbench.policy = CaseService()
    return company, other, canonical, product


def test_ambiguous_case_requires_choice_before_new_canonical_default(scoped):
    _, _, workbench, owner, *_ = scoped
    case_with_later_canonical(scoped)
    with scoped[0].connection() as db:
        before = {name: db.execute('SELECT COUNT(*) FROM ' + name).fetchone()[0]
                  for name in ('pol05_drafts', 'pol05_revisions', 'v03_operations')}
    with pytest.raises(CoreError) as exc:
        workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                              'business_petition', 'ambiguous-with-later-canonical', policy_case_id='legacy-case')
    assert exc.value.code == 'enterprise_entity_required'
    with scoped[0].connection() as db:
        assert before == {name: db.execute('SELECT COUNT(*) FROM ' + name).fetchone()[0] for name in before}


@pytest.mark.parametrize('choice', ['first', 'second'])
def test_ambiguous_case_accepts_only_explicit_in_case_enterprise(scoped, choice):
    _, _, workbench, owner, *_ = scoped
    company, other, canonical, _ = case_with_later_canonical(scoped)
    selected = company if choice == 'first' else other
    draft = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
        'business_petition', 'explicit-in-case', policy_case_id='legacy-case', enterprise_entity_id=selected['id'])
    assert draft['context_manifest']['enterprise_entity_id'] == selected['id']
    with pytest.raises(CoreError) as exc:
        workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
            'business_petition', 'explicit-out-of-case', policy_case_id='legacy-case', enterprise_entity_id=canonical['id'])
    assert exc.value.code == 'context_scope_conflict'


def test_single_enterprise_case_stays_pinned_over_later_canonical(scoped):
    _, _, workbench, owner, *_ = scoped
    company, _, _, _ = case_with_later_canonical(scoped, case_enterprises='one')
    draft = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                   'business_petition', 'one-case-company', policy_case_id='legacy-case')
    assert draft['context_manifest']['enterprise_entity_id'] == company['id']


def test_product_only_case_allows_canonical_enterprise_default(scoped):
    _, _, workbench, owner, *_ = scoped
    _, _, canonical, product = case_with_later_canonical(scoped, product_only=True)
    draft = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                   'business_petition', 'product-only-case', policy_case_id='legacy-case')
    assert draft['context_manifest']['enterprise_entity_id'] == canonical['id']
    assert draft['context_manifest']['product_entity_id'] == product['id']


def test_exact_case_draft_receipt_is_read_before_new_ambiguity_rules(scoped):
    repo, _, workbench, owner, _, company = scoped
    class CaseService:
        entities = [company]
        def get(self, account, enterprise, identity):
            return {'id': identity, 'conversation_id': None, 'context': {'entities': self.entities}}
    workbench.policy = CaseService()
    original = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                      'business_petition', 'existing-case-receipt', policy_case_id='legacy-case')
    later = repo.create_entity(owner['account_id'], owner['enterprise_id'], 'enterprise', 'Cơ sở xuất hiện sau')
    workbench.policy.entities = [company, later]
    replay = workbench.create_draft(owner['account_id'], owner['enterprise_id'], QUESTION,
                                    'business_petition', 'existing-case-receipt', policy_case_id='legacy-case')
    assert replay == original


@pytest.mark.parametrize('question, expected, excluded', [
    ('Chị kiến nghị: mở lớp sổ sách vào buổi tối.', ['mở lớp sổ sách vào buổi tối'], []),
    ('Chị kiến nghị:mở lớp sổ sách vào buổi tối.', ['mở lớp sổ sách vào buổi tối'], []),
    ('Chị đề nghị： mở lớp vào tối thứ Bảy.', ['mở lớp vào tối thứ Bảy'], []),
    ('Chị muốn mở lớp buổi tối, không đề nghị mua thiết bị.', ['mở lớp buổi tối'], ['mua thiết bị']),
    ('Chị muốn mở lớp buổi tối và không đề nghị mua thiết bị.', ['mở lớp buổi tối'], ['mua thiết bị']),
    ('Chị không chỉ đề nghị mở lớp buổi tối mà còn đề nghị công bố lịch sớm.',
     ['mở lớp buổi tối', 'công bố lịch sớm'], []),
    ('Chị muốn mở lớp buổi tối, đồng thời đề nghị công bố lịch sớm.',
     ['mở lớp buổi tối', 'công bố lịch sớm'], []),
    ('Chị đề nghị mở lớp buổi tối và muốn công bố lịch sớm.',
     ['mở lớp buổi tối', 'công bố lịch sớm'], []),
    ('Chị không đề nghị mua thiết bị và không muốn xin trợ cấp.', [], ['mua thiết bị', 'trợ cấp']),
    ('Chị muốn học sổ sách 3,5 giờ ngày 26.10.2026, không đề nghị mua máy.',
     ['học sổ sách 3,5 giờ ngày 26.10.2026'], ['mua máy']),
    ('Chị không xin mua thiết bị nhưng đề nghị mở lớp sổ sách buổi tối.',
     ['mở lớp sổ sách buổi tối'], ['mua thiết bị']),
    ('Chị đề nghị không mua thiết bị mà mở lớp buổi tối.',
     ['không mua thiết bị mà mở lớp buổi tối'], []),
])
def test_request_grammar_preserves_each_affirmative_clause_and_exact_spans(question, expected, excluded):
    details = request_details(question)
    assert [item['text'] for item in details] == expected
    for detail in details:
        assert detail['source'] == 'question'
        assert question[detail['start']:detail['end']] == detail['text']
    for omitted in excluded:
        assert all(omitted not in detail['text'] for detail in details)


@pytest.mark.parametrize('question', [
    'Chị kiến nghị: mở lớp sổ sách vào buổi tối.',
    'Chị muốn mở lớp sổ sách buổi tối, không đề nghị mua thiết bị.',
])
def test_grammar_variants_reach_saved_petition_and_pdf_without_paid_call(scoped, question):
    draft = make(scoped, question=question)
    assert 'lớp sổ sách' in draft['body']['request']
    assert 'buổi tối' in draft['body']['request']
    assert 'mua thiết bị' not in draft['body']['request']
    assert 'buổi tối' in pdf_text(draft)
    assert draft['provider_calls'] == 0

