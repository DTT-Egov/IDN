"""DF-014/048: SSOT provenance, not input/timestamp order, chooses owner context."""
import copy
import itertools

import pytest

from nmate.v04.effective_context import project_owner_context


def fixture_data():
    stamp = '2026-10-22T00:00:00Z'
    def intake(identity, value):
        return {'id': identity, 'status': 'confirmed', 'confirmed_at': stamp,
                'candidates': [{'id': identity + '-candidate', 'field': 'net_quantity',
                    'base_field': 'net_quantity', 'entity_id': 'product-a', 'entity_type': 'product',
                    'value': value, 'confirmed_value': value, 'status': 'confirmed',
                    'source': {'kind': 'server_text_extract', 'quote': value}}]}
    old, latest = intake('intake-old', '100 g'), intake('intake-current', '200 g')
    fact = {'field': 'net_quantity', 'value': '200 g', 'value_state': 'known',
            'assertion_id': 'assertion-current', 'version': 2,
            'source': {'intake_id': latest['id'], 'candidate_id': latest['candidates'][0]['id'],
                       'owner_confirmed': True}}
    context = {'entities': [{'id': 'product-a', 'entity_type': 'product', 'version': 2,
                            'facts': [fact], 'values': {'net_quantity': '200 g'}}], 'fact_refs': []}
    return context, old, latest


@pytest.mark.parametrize('order', list(itertools.permutations((0, 1))))
def test_current_assertion_provenance_wins_equal_clock_regardless_order(order):
    context, old, latest = fixture_data()
    values = [old, latest]
    inputs = copy.deepcopy([context, values])
    result = project_owner_context(context, [values[i] for i in order], None, None)
    decision = result['owner_decisions'][0]
    assert decision['chosen_candidate_id'] == 'intake-current-candidate'
    assert decision['status'] == 'committed'
    assert decision['committed_value'] == decision['current_value'] == '200 g'
    assert [context, values] == inputs


@pytest.mark.parametrize('order', list(itertools.permutations((0, 1))))
def test_clock_skew_cannot_override_current_assertion(order):
    context, old, latest = fixture_data()
    old['confirmed_at'] = '2099-01-01T00:00:00Z'
    values = [old, latest]
    result = project_owner_context(context, [values[i] for i in order], None, None)
    assert result['owner_decisions'][0]['chosen_candidate_id'] == 'intake-current-candidate'


def test_repeated_same_value_does_not_guess_which_candidate_was_committed():
    context, old, latest = fixture_data()
    old['candidates'][0].update(value='200 g', confirmed_value='200 g')
    old['confirmed_at'] = '2099-01-01T00:00:00Z'
    result = project_owner_context(context, [latest, old], None, None)
    assert result['owner_decisions'][0]['chosen_candidate_id'] == 'intake-current-candidate'
