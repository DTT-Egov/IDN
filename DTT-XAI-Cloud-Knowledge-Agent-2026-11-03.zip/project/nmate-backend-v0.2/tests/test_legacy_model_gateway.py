"""Governed main-app transport using injected responses only; no paid IO."""
import asyncio
import copy
import json
from datetime import datetime, timedelta, timezone

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.core_v1.ssot import CoreSSOTService
from nmate.main.provider import MainProvider
from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


OUTPUT = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "legacy-gateway.sqlite")
    owner = LocalAccounts(repo).register("gateway-owner", "Password12345", "Trà Sen")
    other = LocalAccounts(repo).register("gateway-other", "Password12345", "Khác")
    core = CoreSSOTService(repo)
    calls = []

    async def transport(model, body, limit):
        calls.append((model, body, limit))
        return {"text": '{"answer":"Mình sẽ dùng hồ sơ Trà Sen Tây Hồ."}', "model": model,
                "request_id": "unit-not-paid", "stop_reason": "end_turn",
                "usage": {"input_tokens": 100, "output_tokens": 50}}

    async def forbidden_legacy(*args):
        raise AssertionError("The ungoverned provider must never dispatch")

    provider = MainProvider(repo, request_fn=forbidden_legacy, max_attempts=20)
    gateway = ModelGateway(repo, core=core, request_fn=transport, enabled=True)
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    return repo, owner, other, provider, gateway, adapter, calls


def payload(**inputs):
    return {"instructions_vi": "Chỉ dựa vào câu hỏi và dữ kiện đã xác nhận; giữ nguyên tên riêng.",
            "response_schema": copy.deepcopy(OUTPUT), "input": {"current_question": "Tôi muốn số hóa quản lý tồn kho Trà Sen Tây Hồ.", **inputs}}


def grant(setup, *, owner=None, purposes=None, roles=None, cap=2, calls=4):
    _, actual_owner, _, _, gateway, _, _ = setup
    owner = owner or actual_owner
    return gateway.authorize_budget(owner["account_id"], owner["enterprise_id"],
        approval_id="INJECTED-TEST-NO-PAID-IO", max_calls=calls, max_cost_usd=cap,
        purposes=purposes or ["legacy_intake", "legacy_research"], roles=roles or ["standard", "complex"],
        expires_at=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())["id"]


def invoke(setup, value=None, *, kind="intake", operation="op-main-1", owner=None):
    _, actual_owner, _, _, _, adapter, _ = setup
    owner = owner or actual_owner
    return adapter(kind, value or payload(), operation_id=operation,
        account_id=owner["account_id"], enterprise_id=owner["enterprise_id"])


def test_no_grant_never_uses_either_transport_or_legacy_reservation(setup):
    repo, owner, _, _, _, adapter, calls = setup
    assert adapter.status(owner["account_id"], owner["enterprise_id"])["approved"] is False
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(setup))
    assert error.value.code == "BUDGET_NOT_GRANTED" and calls == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0


@pytest.mark.parametrize("purposes,roles", [(["hanoi_policy_synthesis"], ["standard"]),
    (["legacy_intake"], ["complex"]), (["legacy_research"], ["standard"])])
def test_no_cross_purpose_or_silent_model_escalation(setup, purposes, roles):
    grant(setup, purposes=purposes, roles=roles)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    assert setup[-1] == []


def test_budget_is_scoped_to_current_owner_enterprise(setup):
    grant(setup, owner=setup[2])
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    assert not setup[-1]


def test_one_gateway_receipt_compatible_ledger_and_free_exact_replay(setup):
    repo, owner, _, provider, _, adapter, calls = setup
    grant(setup, calls=1)
    first = asyncio.run(invoke(setup))
    second = asyncio.run(invoke(setup))
    assert first == second
    assert first["attempt_id"] != first["gateway_attempt_id"]
    assert len(calls) == 1 and calls[0][0] == "claude-sonnet-5-5" and calls[0][2] == 4096
    assert calls[0][1]["task_instructions_vi"] == payload()["instructions_vi"]
    summary = provider.summary(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"])
    assert summary["paid_calls"] == 1 and summary["attempts"][0]["state"] == "succeeded"
    assert adapter.status(owner["account_id"], owner["enterprise_id"])["approved"] is False
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts WHERE dispatched_at IS NOT NULL").fetchone()[0] == 1
        assert json.loads(db.execute("SELECT response_json FROM v03_live_attempts").fetchone()[0]) == first
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, payload(current_question="Câu hỏi đã đổi")))
    assert len(calls) == 1


def test_research_complexity_uses_only_exact_approved_opus_role(setup):
    grant(setup, purposes=["legacy_research"], roles=["complex"])
    value = payload()
    value.update(complexity="complex")
    result = asyncio.run(invoke(setup, value, kind="research"))
    assert result["model"] == "claude-opus-5-5" and len(setup[-1]) == 1


def test_insufficient_money_blocks_before_both_ledgers(setup):
    grant(setup, cap="0.000001")
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    assert not setup[-1]
    with setup[0].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0


@pytest.mark.parametrize("inputs", [
    {"current_question": "Doanh thu năm 2025 là 500 triệu, hãy gửi sang AI."},
    {"current_question": "Lãi ròng của tôi là 123456789."},
    {"current_question": "Net income is 123456789."},
    {"messages": [{"role": "user", "text": "Revenue: 500000 USD"}]},
    {"parsed_xlsx_facts": [{"field": "revenue", "value": {"amount": 500}}]},
    {"selected_product": {"name": "Trà Sen; lợi nhuận 500 triệu"}},
    {"selected_product": {"name": "1|2|3|4|5|6"}},
    {"parsed_xlsx_facts": [{"field": "name", "value": "Trà Sen", "raw_document": "private"}]},
])
def test_private_finance_cannot_hide_in_text_business_name_or_workbook(setup, inputs):
    grant(setup)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, payload(**inputs)))
    assert not setup[-1]


def test_images_fail_closed_without_silently_dropping_them(setup):
    grant(setup)
    provider = setup[3]
    token = provider.images.set([{"media_type": "image/png", "data_base64": "privateimage"}])
    try:
        with pytest.raises(CoreError) as error:
            asyncio.run(invoke(setup))
        assert error.value.code == "VISION_EGRESS_NOT_ENABLED"
    finally:
        provider.images.reset(token)
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, payload(files=[{"kind": "image", "sha256": "a"*64}])))
    assert not setup[-1]


@pytest.mark.parametrize("inputs", [
    {"selected_product": {"name": {"amount": 123456789, "currency": "VND"}}},
    {"ssot": {"values": {"name": {"amount": 123456789, "currency": "VND"}}}},
    {"ssot": {"facts": [{"field": "name", "value": {"amount": 123456789, "currency": "VND"}}]}},
    {"parsed_xlsx_facts": [{"field": "ingredients", "value": [123456789, 2222222]}]},
    {"ssot": {"values": {"certifications": [{"amount": 123456789, "currency": "VND"}]}}},
    {"ssot": {"values": {"nutrition_information": {"amount": 123456789, "currency": "VND"}}}},
    {"ssot": {"values": {"responsible_business": {"name": "Trà Sen", "balance": 123456789}}}},
])
def test_financial_json_cannot_hide_under_allowed_business_field_names(setup, inputs):
    grant(setup)
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(setup, payload(**inputs)))
    assert error.value.code == "BUSINESS_VALUE_TYPE_UNSUPPORTED" and not setup[-1]
    with setup[0].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0


def test_closed_business_shapes_preserve_legitimate_product_lists_and_label_values(setup):
    inputs = {"ssot": {"values": {"name": "Trà Sen Tây Hồ", "ingredients": ["Trà Xanh", "Hoa Sen"],
        "certifications": ["Chứng nhận cần đối chiếu"], "allergens": ["Cần xác nhận"],
        "responsible_business": {"name": "Công ty Trà Sen", "address": "Hà Nội", "role": "Nhà sản xuất"},
        "nutrition_information": {"energy_kcal": 100, "protein_g": 2.5, "serving_size": "100 g"}}}}
    compiled = setup[5].compile_payload("intake", payload(**inputs))
    assert compiled["input"]["ssot"]["values"] == inputs["ssot"]["values"]


def test_business_projection_preserves_case_and_omits_private_provenance_and_finance(setup):
    grant(setup)
    repo, owner = setup[:2]
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen Tây Hồ")
    value = payload(ssot={"entities": [{"id": entity["id"], "name": "Trà Sen Tây Hồ", "values": {
        "name": "Trà Sen Tây Hồ", "ingredients": "Trà, Hoa Sen", "revenue": 999999999},
        "facts": [{"field": "name", "value": "Trà Sen Tây Hồ", "source": {"filename": "private.xlsx", "quote": "secret"}},
                  {"field": "revenue", "value": 999999999}]}]},
        parsed_xlsx_facts=[{"field": "packaging", "value": "Hộp 100 g", "filename": "internal.xlsx",
                            "source": {"quote": "private raw", "cell": "A1"}}],
        available_capabilities={"ssot_fields": ["name", "employee_count", "revenue", "ingredients"]},
        files=[{"kind": "spreadsheet", "sha256": "a"*64, "filename": "private.xlsx"}])
    result = asyncio.run(invoke(setup, value))
    assert result["data"]["answer"]
    wire = json.dumps(setup[-1][0][1]["input"], ensure_ascii=False)
    assert "Trà Sen Tây Hồ" in wire and "Trà, Hoa Sen" in wire
    assert "999999999" not in wire and "private.xlsx" not in wire and "private raw" not in wire
    assert "internal.xlsx" not in wire
    assert "withheld_private_field_count" not in setup[-1][0][1]["input"]


@pytest.mark.parametrize("text", ["Lãi 125000000", "$12000 dư ngân hàng của tôi", "Số dư TK ngân hàng 987654321",
                                  "Lỗ 125000000", "BCTC năm nay", "USD 12000"])
def test_financial_prose_cannot_bypass_with_short_labels_or_prefix_currency(setup, text):
    grant(setup)
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(setup, payload(current_question=text, messages=[{"role": "user", "text": text}])))
    assert error.value.code == "FINANCIAL_EGRESS_REQUIRED"
    assert setup[-1] == []


def test_public_source_requires_installed_identity_exact_excerpt_and_official_url(setup):
    repo, owner = setup[:2]
    catalog = DomainCatalog(repo)
    records = catalog.lookup_domain(["food_label"], owner["account_id"], owner["enterprise_id"])["records"]
    assert records
    record = {key: val for key, val in records[0].items() if key != "source_id"}
    record["title"] = "Private lãi ròng 123456789"
    grant(setup)
    asyncio.run(invoke(setup, payload(reference_records=[record]), kind="research"))
    outbound = setup[-1][0][1]["input"]["input"]["reference_records"][0]
    assert outbound["id"] == record["id"] and outbound["excerpt"] == record["excerpt"]
    assert "123456789" not in json.dumps(outbound)
    forged = {**record, "excerpt": "private company finance"}
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(setup, payload(reference_records=[forged]), kind="research", operation="op-forged"))
    assert error.value.code == "INVALID_PUBLIC_REFERENCE" and len(setup[-1]) == 1


def test_transport_timeout_keeps_charge_unknown_and_never_replays(setup):
    grant(setup)
    gateway, calls = setup[4], setup[-1]

    async def timeout(*args):
        calls.append("timeout")
        raise TimeoutError()

    gateway.request_fn = timeout
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    with setup[0].connection() as db:
        assert db.execute("SELECT state FROM v03_live_attempts").fetchone()[0] == "outcome_unknown"
        assert db.execute("SELECT held_microusd FROM core_model_attempts").fetchone()[0] > 0
    assert calls == ["timeout"]


def test_schema_rejection_retains_raw_without_paid_repair(setup):
    grant(setup)
    gateway, calls = setup[4], setup[-1]

    async def invalid(model, body, limit):
        calls.append("invalid")
        return {"text": "not JSON", "model": model}

    gateway.request_fn = invalid
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup))
    with setup[0].connection() as db:
        assert db.execute("SELECT state FROM v03_live_attempts").fetchone()[0] == "failed"
        assert db.execute("SELECT raw_text FROM core_model_attempts").fetchone()[0] == "not JSON"
    assert calls == ["invalid"]


def test_receipt_recovery_after_compatibility_write_gap_is_free(setup):
    grant(setup)
    result = asyncio.run(invoke(setup))
    with setup[0].connection(write=True) as db:
        db.execute("UPDATE v03_live_attempts SET state='prepared',response_json=NULL")
    assert setup[5].recover() == 1
    assert asyncio.run(invoke(setup)) == result
    assert len(setup[-1]) == 1


def test_old_research_consent_cannot_consume_new_app_pool_on_startup(setup):
    from nmate.core_v1.budget_pool import BudgetPool
    from nmate.v03.core import now_iso

    repo, owner, _, _, _, adapter, calls = setup
    pool = BudgetPool(repo)
    pool.authorize("NEW-MAIN-APPROVAL", "standard", 2, 1, ["legacy_research"],
                   (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    pool.provision(owner["account_id"], owner["enterprise_id"])
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE main_research_authorizations(mission_id TEXT PRIMARY KEY,account_id TEXT,enterprise_id TEXT,operation_id TEXT,consent_at TEXT)")
        db.execute("INSERT INTO main_research_authorizations VALUES(?,?,?,?,?)", ("old-mission", owner["account_id"], owner["enterprise_id"], "old-start", "2020-01-01T00:00:00+00:00"))
    with pytest.raises(CoreError) as error:
        asyncio.run(adapter("research", payload(), operation_id="op-stale", account_id=owner["account_id"],
                            enterprise_id=owner["enterprise_id"], mission_id="old-mission"))
    assert error.value.code == "FRESH_PAID_CONSENT_REQUIRED" and not calls
    with repo.connection(write=True) as db:
        db.execute("UPDATE main_research_authorizations SET consent_at=?", (now_iso(),))
    assert asyncio.run(adapter("research", payload(), operation_id="op-fresh", account_id=owner["account_id"],
                               enterprise_id=owner["enterprise_id"], mission_id="old-mission"))["data"]
    assert len(calls) == 1


def test_parallel_same_operation_dispatches_at_most_once(setup):
    grant(setup)

    async def race():
        return await asyncio.gather(invoke(setup), invoke(setup), return_exceptions=True)

    results = asyncio.run(race())
    assert any(isinstance(result, dict) for result in results)
    assert len(setup[-1]) == 1

