"""No provider calls: the exact same excerpt identity guards both execution modes."""
import copy
import hashlib

import pytest

from nmate.v03.core import CoreError
from nmate.v03.evidence import bind_answer_citations, citation_contract, validate_citation
from nmate.v03.live_review import ResearchOutput


def record():
    excerpt = "Food labels in interstate commerce must be in English."
    return {"id": "EXCERPT_ENGLISH_1", "source_id": "fda_registration", "excerpt": excerpt,
            "excerpt_sha256": hashlib.sha256(excerpt.encode()).hexdigest(), "source_version": 1,
            "reusable": True, "topics": ["food_label"], "review_state": "reference_unreviewed",
            "scope": {"jurisdiction": "US"}, "market_code": "US", "original_language": "en"}


def test_schema_only_allows_excerpt_namespace_and_sdk_preserves_enum():
    from anthropic import transform_schema
    original = ResearchOutput.model_json_schema()
    untouched = copy.deepcopy(original)
    schema, inputs = citation_contract(original, [record()])
    assert original == untouched
    assert "source_id" not in inputs[0] and inputs[0]["id"] == record()["id"]
    converted = transform_schema(schema)
    assert converted["$defs"]["Citation"]["properties"]["source_id"]["enum"] == ["EXCERPT_ENGLISH_1"]


def test_fake_answers_have_versioned_exact_excerpt_citations_not_page_aliases():
    item = record()
    answers = [{"outcome_id": "label", "status": "artifact_ready", "source_ids": [item["id"]]}]
    result = bind_answer_citations(answers, [item], expected_market_code="US")[0]["citations"][0]
    assert result["reference_id"] == item["id"]
    assert result["page_source_id"] == item["source_id"]
    assert result["quote_en"] == item["excerpt"] and result["source_version"] == 1
    assert "citations" not in answers[0]


@pytest.mark.parametrize("kind", ["page", "quote", "topic", "stale", "hash", "length"])
def test_invalid_citation_never_repaired_or_silently_published(kind):
    item = record()
    reference_id, quote, outcome = item["id"], item["excerpt"], "label"
    if kind == "page":
        reference_id = item["source_id"]
    elif kind == "quote":
        quote = quote.replace("English", "ENGLISH")
    elif kind == "topic":
        outcome = "registration"
    elif kind == "stale":
        item["reusable"] = False
    elif kind == "hash":
        item["excerpt_sha256"] = "0" * 64
    elif kind == "length":
        quote = "Food"
    with pytest.raises(CoreError):
        validate_citation(reference_id, quote, [item], outcome, expected_market_code="US")


def test_blocked_gap_can_have_no_citation_but_answered_claim_cannot():
    assert bind_answer_citations([{"outcome_id": "prior_notice", "status": "blocked_source", "source_ids": []}], [record()])[0]["citations"] == []
    with pytest.raises(CoreError) as error:
        bind_answer_citations([{"outcome_id": "label", "status": "answered_general", "source_ids": []}], [record()])
    assert error.value.code == "evidence_missing"
