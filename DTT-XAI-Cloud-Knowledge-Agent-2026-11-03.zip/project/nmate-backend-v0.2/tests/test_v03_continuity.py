"""Owner intent, stable identity and explicit draft-to-SSOT continuity; no model."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService, interpret


TEA = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh."
THREE = {"statement_of_identity": "Lotus-scented tea", "net_quantity": "100 g", "ingredients": "Green tea, Lotus scent"}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "continuity.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("continuity-owner", "TestPassword12345", "Doanh nghiệp Sen")
    other = accounts.register("continuity-other", "TestPassword12345", "Doanh nghiệp khác")
    return repo, owner, other, MissionService(repo)


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


def complete(service, owner, key="first", text=TEA, product=None, parent=None):
    mission = service.prepare(*args(owner), text, f"prepare-{key}", product, parent)
    service.start(*args(owner), mission["id"], f"start-{key}")
    assert asyncio.run(service.execute_next())
    return service.get(*args(owner), mission["id"])


def save(service, owner, mission, fields=THREE, remember=None, key="save", choices=None):
    return service.update_label_progress(*args(owner), mission["id"], mission["label"]["id"], fields,
        remember or [], mission["label"]["version"], mission["product"]["version"], key, choices,
        expected_market_profile_version=mission["market_profile"]["version"])


def values(mission):
    return {f["id"]: f["value"] for f in mission["label"]["fields"]}


def test_facility_only_correction_preserves_three_draft_fields_and_explicit_lineage(setup):
    repo, owner, _, service = setup
    first = complete(service, owner)
    saved = save(service, owner, first)
    changed = service.update_facts(*args(owner), first["id"], [{"field": "facility_activity", "value": "Đóng gói trà"}, {"field": "facility_type", "value": "Cơ sở sản xuất tại Việt Nam"}], saved["product"]["version"], "facility")
    assert changed["status"] == "needs_revalidation"
    assert not changed["label"]["conflicts"]
    continued = complete(service, owner, "continued", "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", parent=first["id"])
    assert {k: values(continued)[k] for k in THREE} == THREE
    assert not continued["label"]["conflicts"]
    assert continued["label"]["parent_artifact_ref"]["version"] == 2
    assert continued["label"]["parent_artifact_ref"]["artifact_id"] == saved["label"]["id"]
    with repo.connection() as db:
        old = json.loads(db.execute("SELECT data_json FROM v03_artifact_revisions WHERE id=? AND version=2", (saved["label"]["id"],)).fetchone()[0])
        assert old["fields"][0]["value"] == THREE["statement_of_identity"]


def test_selected_memory_only_atomic_idempotent_and_self_declared(setup):
    repo, owner, _, service = setup
    first = complete(service, owner)
    saved = save(service, owner, first, remember=["ingredients", "net_quantity"])
    current = saved["current_context"]["entities"][0]
    assert current["values"]["ingredients"] == THREE["ingredients"]
    assert current["values"]["net_quantity"] == THREE["net_quantity"]
    assert "statement_of_identity" not in current["values"]
    assert saved["label"]["version"] == 2 and saved["product"]["version"] == first["product"]["version"] + 1
    history = repo.get_fact_history(*args(owner), first["product"]["entity_id"], "ingredients")
    assert history[-1]["certainty"] == "self_declared"
    assert history[-1]["source"]["kind"] == "user_selected_draft"
    assert history[-1]["source"]["artifact_version"] == 2
    replay = save(service, owner, first, remember=["ingredients", "net_quantity"])
    assert replay["label"]["version"] == 2
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 2


def test_draft_save_without_tick_never_promotes_to_ssot(setup):
    _, owner, _, service = setup
    saved = save(service, owner, complete(service, owner))
    assert all(k not in saved["current_context"]["entities"][0]["values"] for k in THREE)
    assert saved["draft_save"]["remembered_fields"] == []


def test_formula_conflict_preserves_user_work_and_requires_choice(setup):
    _, owner, _, service = setup
    first = save(service, owner, complete(service, owner), remember=list(THREE))
    changed = service.update_facts(*args(owner), first["id"], [{"field": "ingredients", "value": ["Green tea"]}], first["product"]["version"], "formula-change")
    assert values(changed)["ingredients"] == THREE["ingredients"]
    conflict = next(c for c in changed["label"]["conflicts"] if c["field"] == "ingredients")
    assert conflict["ssot_value"] == "Green tea" and conflict["draft_value"] == THREE["ingredients"]
    continued = complete(service, owner, "conflict", "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", parent=first["id"])
    assert values(continued)["ingredients"] == THREE["ingredients"]
    with pytest.raises(CoreError, match="Chọn giữ bản nháp"):
        save(service, owner, continued, {"ingredients": THREE["ingredients"]}, ["ingredients"], "must-choose")
    chosen = save(service, owner, continued, {}, [], "choose-ssot", {"ingredients": "ssot"})
    assert values(chosen)["ingredients"] == "Green tea" and not chosen["label"]["conflicts"]


def test_explicit_keep_draft_can_be_remembered_but_not_externally_verified(setup):
    _, owner, _, service = setup
    first = save(service, owner, complete(service, owner), remember=list(THREE))
    changed = service.update_facts(*args(owner), first["id"], [{"field": "ingredients", "value": "Green tea"}], first["product"]["version"], "formula-change")
    resolved = save(service, owner, changed, {}, ["ingredients"], "keep-draft", {"ingredients": "draft"})
    assert resolved["current_context"]["entities"][0]["values"]["ingredients"] == THREE["ingredients"]
    assert not resolved["label"]["conflicts"]
    assert all(f["verification_state"] == "self_declared" for f in resolved["current_context"]["entities"][0]["facts"])


def test_concurrent_stale_saves_commit_one_atomic_revision_and_one_fact(setup):
    repo, owner, _, service = setup
    first = complete(service, owner)

    def attempt(index):
        try:
            return save(service, owner, first, {"net_quantity": f"{index}00 g"}, ["net_quantity"], f"concurrent-{index}")
        except CoreError as exc:
            return exc

    with ThreadPoolExecutor(2) as pool:
        results = list(pool.map(attempt, [1, 2]))
    assert sum(isinstance(r, dict) for r in results) == 1
    assert next(r for r in results if isinstance(r, CoreError)).code == "version_conflict"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 2
    assert len(repo.get_fact_history(*args(owner), first["product"]["entity_id"], "net_quantity")) == 1


def test_failure_after_facts_before_artifact_rolls_back_both(setup, monkeypatch):
    repo, owner, _, service = setup
    first = complete(service, owner)

    def fail(*_):
        raise CoreError("test_storage_failure", "Lỗi lưu giả lập.", 500)

    monkeypatch.setattr(service, "_insert_artifact", fail)
    with pytest.raises(CoreError, match="Lỗi lưu giả lập"):
        save(service, owner, first, remember=list(THREE))
    unchanged = service.get(*args(owner), first["id"])
    assert unchanged["label"]["version"] == 1 and unchanged["product"]["version"] == first["product"]["version"]
    assert all(k not in unchanged["current_context"]["entities"][0]["values"] for k in THREE)
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 1


def test_product_rename_and_legacy_stale_entity_title_keep_same_identity(setup):
    repo, owner, _, service = setup
    first = complete(service, owner)
    renamed = service.update_facts(*args(owner), first["id"], [{"field": "name", "value": "Trà Sen HỒ TÂY"}], first["product"]["version"], "rename")
    assert renamed["product"]["name"] == "Trà Sen HỒ TÂY"
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET name='Trà Sen Tây Hồ' WHERE id=?", (first["product"]["entity_id"],))
    # Simulate the old bug's persisted shape, then reopen the repository.
    service = MissionService(CoreRepository(repo.db_path))
    new = service.prepare(*args(owner), "Tôi có Trà Sen HỒ TÂY gửi New York cần nhãn tiếng Anh.", "new-name")
    old_alias = service.prepare(*args(owner), TEA, "old-alias")
    assert new["product"]["entity_id"] == old_alias["product"]["entity_id"] == first["product"]["entity_id"]
    assert new["product"]["name"] == "Trà Sen HỒ TÂY"
    assert len(repo.list_entities(*args(owner), "product")) == 1


def test_duplicate_alias_requires_selection_instead_of_merging(setup):
    repo, owner, _, service = setup
    first = complete(service, owner)
    service.update_facts(*args(owner), first["id"], [{"field": "name", "value": "Trà Sen Mới"}], first["product"]["version"], "rename")
    repo.create_entity(*args(owner), "product", "Trà Sen Tây Hồ", operation_id="separate-variant")
    mission = service.prepare(*args(owner), TEA, "ambiguous-alias")
    assert mission["status"] == "waiting_input" and mission["product"] is None
    assert len(mission["product_candidates"]) == 2
    assert len(repo.list_entities(*args(owner), "product")) == 2


def test_other_enterprise_cannot_inherit_or_save_private_draft(setup):
    repo, owner, other, service = setup
    first = save(service, owner, complete(service, owner))
    with pytest.raises(CoreError):
        service.prepare(*args(other), TEA, "other-parent", continuation_mission_id=first["id"])
    with pytest.raises(CoreError):
        service.update_label_progress(*args(other), first["id"], first["label"]["id"], THREE, list(THREE), 2, first["product"]["version"], "other-save")
    separate = complete(service, other, "other")
    assert all(v is None for v in values(separate).values())
    assert separate["label"]["parent_artifact_ref"] is None
    product = repo.create_entity(*args(owner), "product", "Bột Sen", operation_id="other-product")
    with pytest.raises(CoreError, match="sản phẩm khác"):
        service.prepare(*args(owner), TEA, "cross-product", product["id"], first["id"])


def test_source_change_blocks_current_findings_without_erasing_editable_user_draft(setup):
    _, owner, _, service = setup
    first = save(service, owner, complete(service, owner))
    source = first["knowledge"]["source_refs"][0]
    service.catalog.observe_source(*args(owner), source["source_id"], "b" * 64, "source-change")
    stale = service.get(*args(owner), first["id"])
    assert stale["status"] == "needs_revalidation" and stale["label"]["source_review_required"]
    assert {k: values(stale)[k] for k in THREE} == THREE
    saved = save(service, owner, stale, {"net_quantity": "120 g"}, key="stale-draft-edit")
    assert values(saved)["net_quantity"] == "120 g"
    assert saved["status"] == "needs_revalidation"


def test_clarification_hop_keeps_authorized_ancestor_draft(setup):
    _, owner, _, service = setup
    first = save(service, owner, complete(service, owner))
    vague = service.prepare(*args(owner), "Hỗ trợ tiếp cho hồ sơ này.", "clarification-hop", continuation_mission_id=first["id"])
    assert vague["status"] == "waiting_input" and not vague["artifacts"]
    continued = complete(service, owner, "after-clarification", "Chỉ chuẩn bị nhãn tiếng Anh cho hồ sơ này.", parent=vague["id"])
    assert {k: values(continued)[k] for k in THREE} == THREE
    assert continued["label"]["parent_artifact_ref"]["mission_id"] == first["id"]


@pytest.mark.parametrize("bad_parent", ["cycle", "foreign"])
def test_corrupted_continuation_chain_cannot_bypass_bound_or_enterprise_acl(setup, bad_parent):
    repo, owner, other, service = setup
    first = complete(service, owner)
    vague = service.prepare(*args(owner), "Hỗ trợ tiếp cho hồ sơ này.", "chain-vague", continuation_mission_id=first["id"])
    target = vague["id"]
    if bad_parent == "foreign":
        target = service.prepare(*args(other), TEA, "foreign-prepare")["id"]
    with repo.connection(write=True) as db:
        payload = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (vague["id"],)).fetchone()[0])
        payload["continuation_mission_id"] = target
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json.dumps(payload), vague["id"]))
    prepared = service.prepare(*args(owner), "Chỉ chuẩn bị nhãn tiếng Anh.", "chain-check", continuation_mission_id=vague["id"])
    service.start(*args(owner), prepared["id"], "chain-check-start")
    assert asyncio.run(service.execute_next())
    stopped = service.get(*args(owner), prepared["id"])
    assert stopped["status"] == "failed" and not stopped["artifacts"]


@pytest.mark.parametrize("text", [
    "Tôi có Trà Sen gửi New York, chỉ chuẩn bị nhãn; không nghiên cứu đăng ký cơ sở FDA.",
    "Tôi có Trà Sen gửi New York, chỉ chuẩn bị nhãn; không nghiên cứu lại đăng ký cơ sở FDA.",
])
def test_bounded_explicit_negative_research_intent_only_selects_label(text):
    assert [o.id for o in interpret(text).outcomes] == ["label"]


def test_legal_negative_question_still_is_registration_and_vague_waits_input(setup):
    _, owner, _, service = setup
    assert [o.id for o in interpret("Trà Sen đi Mỹ có phải không cần đăng ký không?").outcomes] == ["registration"]
    vague = service.prepare(*args(owner), "Tôi có Trà Sen gửi New York, hãy hỗ trợ tôi.", "vague")
    assert vague["status"] == "waiting_input" and vague["intent"]["outcomes"][0]["id"] == "clarification"
    with pytest.raises(CoreError):
        service.start(*args(owner), vague["id"], "vague-start")
    assert not asyncio.run(service.execute_next())
