"""Legacy wrong-product plans remain readable but cannot start a paid task."""
import json

import pytest

from nmate.v03.core import CoreError, json_text
from test_unified_main import setup as setup, docs, scope, TEA


async def prepared(setup, question):
    repo, owner, _, model, _, missions, _, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    planned = await chat.send_async(*scope(owner), TEA, [], "legacy-binding-plan", conv["id"], product,
                                   paid_consent=True, task_hint="export_research", market_code="US")
    mission = planned["missions"][0]
    # Explicit pre-fix fixture: retain the old Tea intent/context while the
    # owner's stored question identifies a different product.
    with repo.connection(write=True) as db:
        payload = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mission["id"],)).fetchone()[0])
        payload["question"] = question
        raw = json_text(payload)
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (raw, mission["id"]))
    return repo, owner, model, missions, mission["id"], raw


@pytest.mark.asyncio
async def test_legacy_mismatch_is_readable_and_blocks_before_queue_or_provider(setup):
    repo, owner, model, missions, mid, raw = await prepared(
        setup, "Chị muốn xuất khẩu Mứt Sen đi Los Angeles và cần nhãn thực phẩm")
    before_calls = len(model.calls)
    view = missions.get(*scope(owner), mid)
    assert view["status"] == "needs_product_confirmation"
    assert view["binding_warning"]["declared_name"] == "Mứt Sen"
    assert view["research_scope"]["can_start_research"] is False
    assert view["binding_warning"]["provider_dispatched"] is True
    assert view["binding_warning"]["provider_attempt_count"] == 1
    assert "đã gửi Claude" in view["binding_warning"]["message_vi"]
    assert "chưa gửi Claude" not in view["binding_warning"]["message_vi"]
    with pytest.raises(CoreError) as error:
        missions.start(*scope(owner), mid, "legacy-mismatch-start")
    assert error.value.code == "product_confirmation_required"
    with pytest.raises(CoreError):
        await missions._ensure_research(mid)
    assert len(model.calls) == before_calls
    with repo.connection() as db:
        stored = db.execute("SELECT status,payload_json FROM v03_missions WHERE id=?", (mid,)).fetchone()
        assert stored["status"] == "planned" and stored["payload_json"] == raw
        assert db.execute("SELECT COUNT(*) FROM main_research_authorizations WHERE mission_id=?", (mid,)).fetchone()[0] == 0


@pytest.mark.asyncio
@pytest.mark.parametrize("question", [TEA, "Chị muốn nghiên cứu thị trường Mỹ"])
async def test_matching_or_unproven_identity_does_not_invent_a_mismatch(setup, question):
    _, owner, _, missions, mid, _ = await prepared(setup, question)
    view = missions.get(*scope(owner), mid)
    assert not view.get("binding_warning")
    assert view["status"] == "planned"
