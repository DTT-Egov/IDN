"""Secondary R1 preview boundary: a reference never bypasses fresh consent."""
import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.main.provider import MainProvider
from nmate.v03.core import CoreError, now_iso
from nmate.v03.identity import LocalAccounts
from test_legacy_model_gateway import payload
from test_r1_query_gateway import case as private_case, ledger, query


@pytest.fixture
def case(tmp_path):
    return private_case.__wrapped__(tmp_path)


def research_case(case):
    pool = case[2].budget_pool.authorize("R1-LATER-RESEARCH-APPROVAL", "standard", 2, 1,
        ["legacy_research"], (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    grant = next(g["id"] for g in query(case)["grants"] if "legacy_research" in g["purposes"])
    with case[0].connection(write=True) as db:
        db.execute("CREATE TABLE main_research_authorizations(mission_id TEXT PRIMARY KEY,account_id TEXT,"
                   "enterprise_id TEXT,operation_id TEXT,consent_at TEXT)")
        db.execute("INSERT INTO main_research_authorizations VALUES(?,?,?,?,?)",
            ("old-mission", case[1]["account_id"], case[1]["enterprise_id"], "old-start", "2020-01-01T00:00:00+00:00"))
    adapter = GovernedLegacyAdapter(case[0], case[2], MainProvider(case[0]))
    return pool, grant, adapter


def test_new_unactivated_pool_does_not_bypass_stale_research_consent(case):
    _pool, _grant, adapter = research_case(case)
    before = ledger(case[0])
    with pytest.raises(CoreError) as error:
        asyncio.run(adapter("research", payload(), operation_id="r1-stale-preview", account_id=case[1]["account_id"],
            enterprise_id=case[1]["enterprise_id"], mission_id="old-mission"))
    assert error.value.code == "FRESH_PAID_CONSENT_REQUIRED"
    assert ledger(case[0]) == before and case[4] == []


def test_fresh_consent_allows_one_begin_without_query_activation(case):
    _pool, grant, adapter = research_case(case)
    with case[0].connection(write=True) as db:
        db.execute("UPDATE main_research_authorizations SET consent_at=?", (now_iso(),))
    before = ledger(case[0])
    assert before["core_budget_grants"] == []
    answer = asyncio.run(adapter("research", payload(), operation_id="r1-fresh-preview", account_id=case[1]["account_id"],
        enterprise_id=case[1]["enterprise_id"], mission_id="old-mission"))
    assert answer["data"]["answer"] == "Synthetic saved result" and len(case[4]) == 1
    with case[0].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_budget_pool_links WHERE grant_id=?", (grant,)).fetchone()[0] == 1


@pytest.mark.parametrize("invalidate", ["expired", "revoked_owner"])
def test_stale_preview_cannot_dispatch_after_expiry_or_revoke(case, invalidate):
    pool, _grant, adapter = research_case(case)
    with case[0].connection(write=True) as db:
        db.execute("UPDATE main_research_authorizations SET consent_at=?", (now_iso(),))
        if invalidate == "expired":
            db.execute("UPDATE core_budget_pools SET expires_at=? WHERE id=?",
                ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(), pool["id"]))
        else:
            db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?",
                       (case[1]["account_id"], case[1]["enterprise_id"]))
    before = ledger(case[0])
    with pytest.raises(CoreError):
        asyncio.run(adapter("research", payload(), operation_id="r1-denied-preview", account_id=case[1]["account_id"],
            enterprise_id=case[1]["enterprise_id"], mission_id="old-mission"))
    assert ledger(case[0]) == before and case[4] == []


def test_consent_lookup_resolves_only_exact_owner_scoped_preview(case):
    pool, grant, _adapter = research_case(case)
    other = LocalAccounts(case[0]).register("r1-consent-other", "Synthetic-password-123", "Other")
    before = ledger(case[0])
    budgets = case[2].budget_pool
    with case[0].connection() as db:
        assert budgets.resolve_preview(db, case[1]["account_id"], case[1]["enterprise_id"], grant,
                                       purpose="legacy_research")["id"] == pool["id"]
        assert budgets.resolve_preview(db, case[1]["account_id"], case[1]["enterprise_id"], "wrong-pool-id",
                                       purpose="legacy_research") is None
        assert budgets.resolve_preview(db, other["account_id"], other["enterprise_id"], grant,
                                       purpose="legacy_research") is None
        assert budgets.resolve_preview(db, case[1]["account_id"], case[1]["enterprise_id"], grant,
                                       purpose="legacy_intake") is None
    assert ledger(case[0]) == before and case[4] == []
