"""M3 domain calls must use one shared Gateway engine, never fake enterprises."""
import json
from datetime import datetime,timedelta,timezone
import pytest
from test_knowledge_m2 import pipe,extracted
from test_knowledge_m1 import kb
from nmate.core_v1.gateway import ModelGateway
from nmate.v03.core import CoreError
from nmate.core_v1.domain_gateway import PublicDomainScope,install_domain_schema_for_fixture


@pytest.fixture
def domain(pipe,tmp_path):
    repo,source,actor,other=pipe
    calls=[]
    async def request(model,body,limit):
        calls.append((model,body,limit))
        return {'text':json.dumps({'draft':'Nháp công khai chưa duyệt'}),'model':model,
                'stop_reason':'end_turn','usage':{'input_tokens':100,'output_tokens':50}}
    gateway=ModelGateway(repo,enabled=True,request_fn=request)
    from nmate.knowledge_v1.operator_m3 import install_m3_on_clone
    install_m3_on_clone(repo.db_path,backup_path=tmp_path/'domain-m3.sqlite')
    ex=extracted(pipe)
    ref=source.pipeline_evidence(actor,ex['chunks'][0]['id'],'Training for enterprises.')
    scope=PublicDomainScope(domain='hanoi_policy',policy_id='TEST-POLICY')
    grant=gateway.authorize_domain_budget(actor,scope,approval_id='TEST-D06-ONLY',max_calls=6,max_cost_usd='2',
        per_role={'standard':{'max_calls':4,'max_cost_usd':'0.25'},'complex':{'max_calls':2,'max_cost_usd':'0.50'}},
        source_ids=['KB-TEST-A'],source_refs=[ref],expires_at=(datetime.now(timezone.utc)+timedelta(hours=48)).isoformat())
    return gateway,source,actor,other,scope,grant['id'],ref,calls


async def invoke(domain,**changes):
    g,source,a,_,scope,grant,ref,_=domain
    values=dict(account_id=a,scope=scope,operation_id='domain-operation-1',task_id='S1',role='standard',
        purpose='policy_knowledge_build',source_refs=[ref],output_schema={'type':'object','properties':{'draft':{'type':'string'}},'required':['draft'],'additionalProperties':False},
        budget_grant_id=grant,max_output_tokens=1024,recipe='policy-knowledge-draft/1')
    values.update(changes)
    reader=values.pop('source_reader',source)
    return await g.call_domain_once(source_reader=reader,**values)


@pytest.mark.asyncio
async def test_public_domain_uses_same_execute_engine_and_no_fake_enterprise(domain):
    g,source,actor,_,scope,grant,ref,calls=domain
    assert hasattr(g,'_execute_once')
    with g.repo.connection() as db:
        before=db.execute('SELECT count(*) FROM v03_enterprises').fetchone()[0]
    result=await invoke(domain)
    assert result['data']['draft']=='Nháp công khai chưa duyệt'
    assert len(calls)==1 and calls[0][0]=='claude-sonnet-5-5'
    assert await invoke(domain)=={**result,'cached':True}
    with g.repo.connection() as db:
        assert db.execute('SELECT count(*) FROM v03_enterprises').fetchone()[0]==before
        assert db.execute('SELECT count(*) FROM core_model_attempts').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM core_domain_model_attempts').fetchone()[0]==1


@pytest.mark.asyncio
async def test_domain_revoke_blocks_cached_read_without_paid_retry(domain):
    g,source,a,_,scope,grant,ref,calls=domain
    await invoke(domain)
    source.set_source_rights(a,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,
                             reason='TEST revoke',operation_id='revoke-domain-source')
    with pytest.raises(CoreError): await invoke(domain)
    assert len(calls)==1


@pytest.mark.asyncio
async def test_grant_other_actor_and_source_scope_are_rejected(domain):
    g,source,a,other,scope,grant,ref,calls=domain
    with pytest.raises(CoreError): await invoke(domain,account_id=other)
    with pytest.raises(CoreError): await invoke(domain,scope=PublicDomainScope(domain='hanoi_policy',policy_id='DIFFERENT'))
    assert calls==[]


@pytest.mark.asyncio
async def test_new_operation_cannot_repeat_consumed_slot(domain):
    await invoke(domain)
    with pytest.raises(CoreError): await invoke(domain,operation_id='changed-operation')
    assert len(domain[-1])==1


@pytest.mark.asyncio
async def test_invalid_output_and_timeout_never_retry(domain):
    g,*_=domain
    async def broken(model,body,limit):
        domain[-1].append(model)
        raise TimeoutError('TEST ONLY')
    g.request_fn=broken
    with pytest.raises(CoreError): await invoke(domain)
    with pytest.raises(CoreError): await invoke(domain)
    with pytest.raises(CoreError): await invoke(domain,operation_id='different')
    assert len(domain[-1])==1


@pytest.mark.asyncio
async def test_opus_must_receive_actual_saved_sonnet_drafts(domain):
    with pytest.raises(CoreError):
        await invoke(domain,task_id='O1',role='complex',recipe='policy-knowledge-critique/1')
    await invoke(domain)
    await invoke(domain,task_id='S2',operation_id='s2')
    await invoke(domain,task_id='O1',operation_id='o1',role='complex',recipe='policy-knowledge-critique/1')
    assert len(domain[-1])==3
    drafts=domain[-1][-1][1]['input']['prior_proposals']
    assert len(drafts)==2 and all(p['data']['draft'] for p in drafts)


@pytest.mark.asyncio
async def test_fixed_corpus_rejects_new_ref_same_source_and_weak_reader(domain):
    from test_knowledge_m2 import acquire
    g,s,a,other,scope,grant,ref,calls=domain
    acquired=acquire((g.repo,s,a,other),raw=b'New corpus, same source.',operation='updated',version=2)
    ex=s.extract_local(a,acquired['rendition_id'],operation_id='parse-updated')
    new=s.pipeline_evidence(a,ex['chunks'][0]['id'],'New corpus, same source.')
    class WeakReader:
        repo=g.repo
        def _resolve(self,*args,**kw): return {'KB-TEST-A'}
    with pytest.raises(CoreError): await invoke(domain,source_refs=[new],source_reader=WeakReader())
    invalid=dict(ref,quote='fabricated')
    with pytest.raises(CoreError): await invoke(domain,source_refs=[invalid],source_reader=WeakReader())
    assert calls==[]
    # Current READ allows the original historical corpus; never substitute bytes.
    await invoke(domain)
    assert len(calls)==1


def test_approval_replay_cannot_extend_expiry_or_mint_calls(domain):
    g,s,a,other,scope,grant,ref,calls=domain
    with g.repo.connection() as db: expiry=db.execute('SELECT expires_at FROM core_domain_budget_grants WHERE id=?',(grant,)).fetchone()[0]
    args=dict(approval_id='TEST-D06-ONLY',max_calls=6,max_cost_usd='2',
        per_role={'standard':{'max_calls':4,'max_cost_usd':'0.25'},'complex':{'max_calls':2,'max_cost_usd':'0.50'}},
        source_ids=['KB-TEST-A'],source_refs=[ref],expires_at=expiry)
    assert g.authorize_domain_budget(a,scope,**args)['id']==grant
    with pytest.raises(CoreError): g.authorize_domain_budget(a,scope,**(args|{'expires_at':(datetime.now(timezone.utc)+timedelta(hours=49)).isoformat()}))
    with g.repo.connection() as db: assert db.execute('SELECT count(*) FROM core_domain_budget_grants').fetchone()[0]==1


@pytest.mark.asyncio
async def test_public_input_sealed_before_transport_and_receipt_is_read_only(domain):
    g,s,a,_,scope,grant,ref,calls=domain
    original=g.request_fn
    async def guarded(model,body,limit):
        with g.repo.connection() as db:
            sealed=db.execute('SELECT * FROM core_domain_request_inputs').fetchone()
            assert json.loads(sealed['body_json'])==body
        return await original(model,body,limit)
    g.request_fn=guarded
    result=await invoke(domain)
    with g.repo.connection() as db: before=list(db.iterdump())
    assert g.read_domain_receipt(s,a,scope,result['attempt_id'])['cached']
    with g.repo.connection() as db: assert before==list(db.iterdump())
    assert len(calls)==1


@pytest.mark.asyncio
async def test_role_caps_status_and_offline_recovery_cannot_dispatch(domain):
    g,s,a,_,scope,grant,ref,calls=domain
    for slot in ('S1','S2','S3','S4'):
        await invoke(domain,operation_id='role-'+slot,task_id=slot)
    for slot in ('O1','O2'):
        await invoke(domain,operation_id='role-'+slot,task_id=slot,role='complex',recipe='policy-knowledge-critique/1')
    assert len(calls)==6
    with pytest.raises(CoreError): await invoke(domain,operation_id='extra')
    with g.repo.connection() as db: before=list(db.iterdump())
    status=g.domain_status(a,scope,grant)
    assert status['used_calls']==6 and status['expires_at']
    with g.repo.connection() as db: assert before==list(db.iterdump())
    assert g.recover_domain_interrupted()==0
    assert len(calls)==6
