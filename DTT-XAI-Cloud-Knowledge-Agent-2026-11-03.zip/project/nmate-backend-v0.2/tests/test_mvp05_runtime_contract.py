from nmate.core_v1.runtime_schema import verify_runtime_database
from nmate.main.app import make_main_app


def test_new_database_and_managed_contract_agree_on_policy_draft_objects(tmp_path):
    database = tmp_path / "new.sqlite"
    # Construct the production schema, including authority-check tables. No
    # lifespan/worker is started by this contract-only test.
    make_main_app(database, refresh_sources=True, gateway_enabled=False)
    result = verify_runtime_database(database)
    assert result["ready"] is True
    assert result["writes"] == 0 and result["provider_calls"] == 0
    assert result["contract_version"] == "nmate-main-20261026-v17"
