"""HTTP uses actual MCP and host session callback, no model endpoint."""
import pytest
from fastapi import FastAPI
from httpx import ASGITransport,AsyncClient
from nmate.core_v1.gateway import ModelGateway
from nmate.knowledge_v1.workbench import router
from test_knowledge_m3_governance import governed
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb

@pytest.mark.asyncio
async def test_workbench_adapter_auth_origin_and_tools(governed):
    repo,g,author,reviewer,page=governed;actor=[None]
    app=FastAPI();app.include_router(router(g,ModelGateway(repo,enabled=False),lambda r:actor[0]))
    async with AsyncClient(transport=ASGITransport(app=app),base_url='http://test') as c:
        html=await c.get('/knowledge/');assert html.status_code==200 and 'lang="vi"' in html.text
        request=dict(tool='knowledge_wiki_queue',arguments={})
        assert (await c.post('/knowledge/rpc',json=request)).status_code==401
        actor[0]=reviewer
        assert (await c.post('/knowledge/rpc',json=request,headers={'Origin':'https://other'})).status_code==403
        result=(await c.post('/knowledge/rpc',json=request)).json()
        assert result['ok'] and result['data'][0]['page_id']==page['page_id']
        result=await c.post('/knowledge/rpc',json=dict(tool='grant_budget',arguments={}))
        assert result.status_code==400
        result=await c.post('/knowledge/rpc',json=dict(tool='knowledge_wiki_workbench',arguments={'page_id':page['page_id'],'actor':author}))
        assert result.status_code==400 and result.json()['ok'] is False
