"""DF-019/036: bounded free policy prepare outcome; never guess paid/IO state."""
import json

import httpx
import pytest

from nmate.main.app import make_main_app
from nmate.v03.core import CoreError, json_text, now_iso
from test_core_policy_http import call, good, register, running
from test_review_commands_v2 import data_snapshot


QUESTION = "Chị cần chính sách hỗ trợ chuyển đổi số và đào tạo nhân viên làm sổ sách."


@pytest.fixture
def policy_workspace(tmp_path):
    calls = []

    async def forbidden(*args, **kwargs):
        calls.append(1)
        raise AssertionError("Free policy prepare/read must not dispatch AI")

    app = make_main_app(tmp_path / "policy-boundary.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("policy-boundary-owner", "Synthetic-password-123", "Cơ sở QA riêng")
    service = app.state.core_extension
    return app, service, (owner["account_id"], owner["enterprise_id"]), calls


def test_typed_policy_write_rollback_is_proven_without_any_persisted_snapshot(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    before = data_snapshot(app.state.repo)

    def rejected(db, *args):
        # Runs inside the real transaction, after read-only plan construction.
        raise CoreError("LOCAL_POLICY_REJECTED", "Chị cần đối chiếu kế hoạch.", 409)

    monkeypatch.setattr(service.policy, "before_prepare_commit", rejected)
    for _ in range(2):
        with pytest.raises(CoreError) as caught:
            service.prepare(*scope, QUESTION, "policy-rollback-exact-command")
        assert getattr(caught.value, "commit_state", None) == "not_committed"
        assert data_snapshot(app.state.repo) == before
    assert calls == []


def test_policy_transaction_rollback_leaves_no_detached_context_snapshot(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    before = data_snapshot(app.state.repo)

    def rejected(*args):
        raise CoreError("LOCAL_POLICY_REJECTED", "Chị cần đối chiếu kế hoạch.", 409)

    monkeypatch.setattr(service.policy, "before_prepare_commit", rejected)
    with pytest.raises(CoreError):
        service.prepare(*scope, "Chị có đủ điều kiện nhận hỗ trợ số hóa kho không?", "policy-no-detached-context")
    after = data_snapshot(app.state.repo)
    changed = [name for name in before if before[name] != after[name]]
    assert changed == [], f"Rows persisted outside policy transaction: {changed}"
    assert calls == []


def test_policy_typed_invalid_date_is_not_started_but_old_receipt_cannot_be_relabelled(policy_workspace):
    app, service, scope, calls = policy_workspace
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as invalid:
        service.prepare(*scope, QUESTION, "policy-invalid-date-new", target_date="not-a-date")
    assert getattr(invalid.value, "commit_state", None) == "not_started"
    assert data_snapshot(app.state.repo) == before
    service.prepare(*scope, QUESTION, "policy-already-committed")
    committed = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as replay:
        service.prepare(*scope, QUESTION, "policy-already-committed", target_date="not-a-date")
    assert getattr(replay.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == committed and calls == []


def test_policy_io_rollback_and_postcommit_read_are_not_claimed_uncommitted(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    before = data_snapshot(app.state.repo)

    def io_failure(*args):
        raise OSError("Synthetic unknown IO")

    with monkeypatch.context() as change:
        change.setattr(service.policy, "before_prepare_commit", io_failure)
        with pytest.raises(OSError) as unknown:
            service.prepare(*scope, QUESTION, "policy-io-uncertain")
        assert getattr(unknown.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == before

    def read_failure(*args):
        raise CoreError("POSTCOMMIT_READ_FAILED", "Chị chưa đọc được kết quả đã lưu.", 409)

    with monkeypatch.context() as change:
        change.setattr(service, "get_case", read_failure)
        with pytest.raises(CoreError) as committed:
            service.prepare(*scope, QUESTION, "policy-commit-projection-fails")
        assert getattr(committed.value, "commit_state", None) is None
    saved = data_snapshot(app.state.repo)
    replay = service.prepare(*scope, QUESTION, "policy-commit-projection-fails")
    assert replay["policy_case"]["conversation_id"] == replay["conversation_id"]
    assert data_snapshot(app.state.repo) == saved and calls == []


def test_policy_replay_revoked_membership_and_collision_never_claim_no_commit(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    service.prepare(*scope, QUESTION, "policy-before-revoked-membership")
    with app.state.repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=? AND enterprise_id=?", scope)
    before = data_snapshot(app.state.repo)
    for operation in ["policy-before-revoked-membership", "policy-new-after-revoked-membership"]:
        with pytest.raises(CoreError) as denied:
            service.prepare(*scope, QUESTION, operation)
        assert getattr(denied.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == before and calls == []


def test_policy_failure_evidence_check_failure_is_uncertainty(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    original = service.policy._membership
    seen = []

    def membership(*args, **kwargs):
        if seen:
            raise OSError("Synthetic evidence lookup failed")
        return original(*args, **kwargs)

    def rejected(*args):
        seen.append(1)
        raise CoreError("LOCAL_POLICY_REJECTED", "Chị đối chiếu lại kế hoạch.", 409)

    monkeypatch.setattr(service.policy, "_membership", membership)
    monkeypatch.setattr(service.policy, "before_prepare_commit", rejected)
    with pytest.raises(CoreError) as caught:
        service.prepare(*scope, QUESTION, "policy-evidence-lookup-failed")
    assert caught.value.code == "LOCAL_POLICY_REJECTED"
    assert getattr(caught.value, "commit_state", None) is None and calls == []


def test_policy_partial_chat_callback_rolls_back_inside_real_uow(policy_workspace):
    app, service, scope, calls = policy_workspace
    before = data_snapshot(app.state.repo)

    def partially_linked(db, payload):
        stamp = now_iso()
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)",
                   ("partial-policy-chat", scope[1], scope[0], "{}", stamp, stamp))
        raise CoreError("LOCAL_LINK_REJECTED", "Chị cần đối chiếu cuộc trao đổi.", 409)

    with pytest.raises(CoreError) as caught:
        service.policy.prepare(*scope, QUESTION, "policy-partial-chat-rollback", on_commit=partially_linked)
    assert caught.value.commit_state == "not_committed"
    assert data_snapshot(app.state.repo) == before and calls == []


def test_policy_archived_preflight_is_not_started_but_exact_replay_stays_read_only(policy_workspace):
    app, service, scope, calls = policy_workspace
    original = service.prepare(*scope, QUESTION, "policy-before-archive")
    service._visibility(*scope, original["conversation_id"], "policy-archive-chat", True)
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as caught:
        service.prepare(*scope, QUESTION, "new-policy-in-archived-chat", conversation_id=original["conversation_id"])
    assert caught.value.code == "CONVERSATION_ARCHIVED" and caught.value.commit_state == "not_started"
    replay = service.prepare(*scope, QUESTION, "policy-before-archive")
    assert replay["policy_case"]["id"] == original["policy_case"]["id"]
    assert data_snapshot(app.state.repo) == before and calls == []


def test_policy_unreadable_product_keeps_generic_error_without_no_commit_claim(policy_workspace):
    app, service, scope, calls = policy_workspace
    entity = app.state.repo.create_entity(*scope, "product", "Sản phẩm QA bị thu hồi")
    with app.state.repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (entity["id"],))
    before = data_snapshot(app.state.repo)
    for product in [entity["id"], "does-not-exist"]:
        with pytest.raises(CoreError) as caught:
            service.prepare(*scope, QUESTION, "policy-unreadable-target", product_entity_id=product)
        assert caught.value.code == "not_found" and caught.value.status_code == 404
        assert str(caught.value) == "Không tìm thấy hồ sơ sản phẩm được phép sử dụng."
        assert getattr(caught.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == before and calls == []


@pytest.mark.parametrize("ledger", ["main", "policy_start"])
def test_policy_failed_invocation_cannot_relabel_existing_paid_or_start_receipt(policy_workspace, monkeypatch, ledger):
    app, service, scope, calls = policy_workspace
    original = service.prepare(*scope, QUESTION, "policy-link-for-ledger")
    operation = "policy-existing-other-receipt"
    with app.state.repo.connection(write=True) as db:
        if ledger == "main":
            db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,?,NULL,?)",
                       (*scope, operation, "fixture-request-hash", original["conversation_id"], "profile_intake", "completed", now_iso()))
        else:
            db.execute("INSERT INTO pol_operations VALUES(?,?,?,?,?,?,?)",
                       (scope[1], scope[0], "start", operation, "fixture-request-hash", original["policy_case"]["id"], now_iso()))
    before = data_snapshot(app.state.repo)

    def rejected(*args):
        raise CoreError("LOCAL_POLICY_REJECTED", "Chị đối chiếu lại kế hoạch.", 409)

    monkeypatch.setattr(service.policy, "before_prepare_commit", rejected)
    with pytest.raises(CoreError) as caught:
        service.prepare(*scope, QUESTION, operation)
    assert getattr(caught.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == before and calls == []


def test_policy_pins_full_context_without_detached_snapshot_and_keeps_history_after_change(policy_workspace):
    app, service, scope, calls = policy_workspace
    entity = app.state.repo.create_entity(*scope, "enterprise", "Cơ sở QA có hồ sơ")
    app.state.repo.propose_or_apply_facts(*scope, entity["id"], [{"field": "registration_province", "value": "Hà Nội"}], 0, "policy-original-location")
    case = service.prepare(*scope, "Chị có đủ điều kiện nhận hỗ trợ số hóa kho không?", "policy-pinned-context")["policy_case"]
    context = case["context"]
    assert context["context_hash"] and context["policy_dependency_hash"]
    assert any(ref["field"] == "registration_province" for ref in context["fact_refs"])
    assert not context.get("context_snapshot_id") and not context.get("context_snapshot_ids")
    with app.state.repo.connection() as db:
        raw = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (case["id"],)).fetchone()[0]
        assert json.loads(raw)["context"] == context
        assert db.execute("SELECT COUNT(*) FROM core_v1_context_snapshots").fetchone()[0] == 0
    current = app.state.repo.get_entity(*scope, entity["id"])
    app.state.repo.propose_or_apply_facts(*scope, entity["id"], [{"field": "registration_province", "value": "Đà Nẵng"}], current["version"], "policy-new-location")
    before = data_snapshot(app.state.repo)
    reloaded = service.prepare(*scope, case["question"], "policy-pinned-context")["policy_case"]
    assert reloaded["context"] == context and reloaded["is_historical"]
    assert any("Dữ kiện doanh nghiệp" in warning for warning in reloaded["current_warnings_vi"])
    assert data_snapshot(app.state.repo) == before and calls == []


def test_policy_concurrent_exact_receipt_cannot_bypass_current_field_read(policy_workspace, monkeypatch):
    app, service, owner_scope, calls = policy_workspace
    staff = app.state.accounts.register("policy-boundary-staff", "Synthetic-staff-pass-123", "Cơ sở khác QA")
    scope = staff["account_id"], owner_scope[1]
    service.core.add_member(*owner_scope, "policy-boundary-staff")
    entity = app.state.repo.create_entity(*owner_scope, "enterprise", "Cơ sở QA có quyền theo trường")
    app.state.repo.propose_or_apply_facts(*owner_scope, entity["id"], [{"field": "registration_province", "value": "Hà Nội"}], 0, "policy-race-location")
    service.core.grant_resource(*owner_scope, entity["id"], scope[0], ["read"], ["registration_province"])
    question, operation = "Chị có đủ điều kiện hỗ trợ số hóa kho không?", "policy-concurrent-exact-receipt"
    original = service.policy._retrieve_for_intent
    interleaved = []
    saved_snapshots = []

    def race(*args, **kwargs):
        if not interleaved:
            interleaved.append(True)
            case = service.policy.prepare(*scope, question, operation, entity_ids=[entity["id"]])
            assert case["context"]["fact_refs"]
            service.core.revoke_resource(*owner_scope, entity["id"], scope[0], ["read"], ["registration_province"])
            saved_snapshots.append(data_snapshot(app.state.repo))
        return original(*args, **kwargs)

    monkeypatch.setattr(service.policy, "_retrieve_for_intent", race)
    with pytest.raises(CoreError) as denied:
        service.policy.prepare(*scope, question, operation, entity_ids=[entity["id"]])
    assert denied.value.status_code == 403
    assert getattr(denied.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == saved_snapshots[0] and calls == []


@pytest.mark.asyncio
async def test_policy_execution_keeps_canonical_snapshot_and_gateway_acl_without_grant_or_dispatch(policy_workspace, monkeypatch):
    app, service, scope, calls = policy_workspace
    entity = app.state.repo.create_entity(*scope, "enterprise", "Cơ sở QA kiểm thực thi")
    app.state.repo.propose_or_apply_facts(*scope, entity["id"], [{"field": "registration_province", "value": "Hà Nội"}], 0, "policy-execution-location")
    case = service.prepare(*scope, "Chị có đủ điều kiện nhận hỗ trợ số hóa kho không?", "policy-execution-context")["policy_case"]
    # Isolated queue fixture only: no usable grant, model attempt or authority.
    queued = {**case, "status": "running", "research_operation_id": "policy-no-authority-execution"}
    with app.state.repo.connection(write=True) as db:
        db.execute("UPDATE pol_missions SET status='running',payload_json=?,budget_grant_id=?,model_role='complex' WHERE id=?",
                   (json_text(queued), "fixture-no-usable-grant", case["id"]))
    gateway_inputs = []
    original = service.gateway.call_once

    async def capture(**kwargs):
        gateway_inputs.append(kwargs)
        return await original(**kwargs)

    monkeypatch.setattr(service.gateway, "call_once", capture)
    result = await service.policy.run_research_async(case["id"], claimed=True)
    assert result["status"] == "failed" and result["error"]["code"] == "BUDGET_NOT_GRANTED"
    assert len(gateway_inputs) == 1
    expected_fields = [ref["field"] for ref in case["context"]["fact_refs"] if ref["entity_id"] == entity["id"]]
    assert gateway_inputs[0]["resource_dependencies"] == [{"resource_id": entity["id"], "fields": expected_fields}]
    with app.state.repo.connection() as db:
        snapshots = db.execute("SELECT payload_json,refs_json,authorization_json FROM core_v1_context_snapshots").fetchall()
        assert len(snapshots) == 1
        payload, refs, acl = (json.loads(value) for value in snapshots[0])
        assert payload["fact_refs"] == refs == case["context"]["fact_refs"]
        assert acl[0]["entity_id"] == entity["id"] and acl[0]["acl_revision"] >= 1
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
    assert calls == []


def test_policy_boundary_actual_http_mcp_rollback_reload_and_postcommit(tmp_path, monkeypatch):
    calls = []

    async def forbidden(*args, **kwargs):
        calls.append(1)
        raise AssertionError("No paid AI allowed")

    async def no_source_refresh(*args, **kwargs):
        return False

    # This test covers command/reload semantics against frozen source fixtures,
    # not scheduler/network refresh. Prevent unrelated background gate writes.
    monkeypatch.setattr("nmate.policy_v1.refresh_jobs.SourceRefreshJobs.execute_next", no_source_refresh)

    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "policy-boundary-http-owner")
            service = app.state.core_extension
            before = data_snapshot(app.state.repo)

            def rejected(*args):
                raise CoreError("LOCAL_POLICY_REJECTED", "Chị cần đối chiếu kế hoạch.", 409)

            with monkeypatch.context() as change:
                change.setattr(service.policy, "before_prepare_commit", rejected)
                for _ in range(2):
                    result = call(web, url, session, "policy_prepare", question=QUESTION, operation_id="http-policy-rollback")
                    assert not result["ok"]
                    assert result["error"].get("commit_state") == "not_committed"
                    assert data_snapshot(app.state.repo) == before
            prepared = good(web, url, session, "policy_prepare", question=QUESTION, operation_id="http-policy-new-success")
            saved = data_snapshot(app.state.repo)
            # Reload and duplicate request are authenticated reads; no second case.
            reloaded = good(web, url, session, "get_conversation", conversation_id=prepared["conversation_id"])
            replay = good(web, url, session, "policy_prepare", question=QUESTION, operation_id="http-policy-new-success")
            assert replay["policy_case"]["id"] == prepared["policy_case"]["id"]
            assert reloaded["policy_cases"][0]["id"] == replay["policy_case"]["id"]
            assert data_snapshot(app.state.repo) == saved

            def failed_projection(*args):
                raise CoreError("POSTCOMMIT_READ_FAILED", "Chị chưa đọc được kết quả đã lưu.", 409)

            with monkeypatch.context() as change:
                change.setattr(service, "get_case", failed_projection)
                result = call(web, url, session, "policy_prepare", question=QUESTION, operation_id="http-policy-commit-read-error")
                assert not result["ok"] and result["error"].get("commit_state") is None
            recovered = good(web, url, session, "policy_prepare", question=QUESTION, operation_id="http-policy-commit-read-error")
            assert recovered["policy_case"]["conversation_id"] == recovered["conversation_id"]
            assert app.state.gateway.status(session["account"]["id"], session["enterprise"]["id"])["paid_calls"] == 0
            assert calls == []
