"""OS process locks only: no repositories, credentials, network or Claude."""
from pathlib import Path
import queue
import subprocess
import sys
import threading
from types import SimpleNamespace

import pytest

from nmate.main.runtime_lock import EnterpriseRuntimeLock, RuntimeAlreadyRunning


CHILD = """
from pathlib import Path
import sys
from nmate.main.runtime_lock import EnterpriseRuntimeLock, RuntimeAlreadyRunning
try:
    with EnterpriseRuntimeLock(sys.argv[1]):
        Path(sys.argv[2]).write_text('callback-entered', encoding='utf-8')
        print('acquired', flush=True)
        if sys.argv[3] == 'hold':
            sys.stdin.readline()
except RuntimeAlreadyRunning:
    print('blocked-before-callback', flush=True)
    sys.exit(23)
"""
FLAGS = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def spawn_holder(database, marker):
    process = subprocess.Popen([sys.executable, "-c", CHILD, str(database), str(marker), "hold"],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, creationflags=FLAGS)
    lines = queue.Queue()
    threading.Thread(target=lambda: lines.put(process.stdout.readline()), daemon=True).start()
    try:
        assert lines.get(timeout=10).strip() == "acquired"
    except BaseException:
        process.kill()
        process.communicate(timeout=5)
        raise
    return process


def child_once(database, marker):
    return subprocess.run([sys.executable, "-c", CHILD, str(database), str(marker), "once"],
                          capture_output=True, text=True, timeout=10, creationflags=FLAGS)


def finish(process, *, kill=False):
    if kill:
        process.kill()
        process.communicate(timeout=5)
    else:
        process.communicate("exit\n", timeout=5)


def test_same_canonical_database_cannot_be_acquired_twice_and_lock_file_is_never_deleted(tmp_path):
    database = tmp_path / "data" / "enterprise.sqlite3"
    first = EnterpriseRuntimeLock(database)
    with first:
        original_size = first.lock_path.stat().st_size
        alias = tmp_path / "data" / "unused" / ".." / "enterprise.sqlite3"
        with pytest.raises(RuntimeAlreadyRunning):
            EnterpriseRuntimeLock(alias).acquire()
        # Windows correctly prevents reading the locked byte through another
        # handle; metadata can still prove rejection did not extend the file.
        assert first.lock_path.stat().st_size == original_size
        assert not database.exists()
    assert first.lock_path.is_file()
    assert first.lock_path.read_bytes() == b"\0"
    with EnterpriseRuntimeLock(database):
        pass
    assert first.lock_path.is_file()


def test_second_process_is_rejected_before_callback_without_database_writes_and_other_database_runs(tmp_path):
    database = tmp_path / "enterprise.sqlite3"
    database.write_bytes(b"original-database-file-must-remain-unchanged")
    holder = spawn_holder(database, tmp_path / "first-callback")
    try:
        rejected_marker = tmp_path / "rejected-callback"
        rejected = child_once(database, rejected_marker)
        assert rejected.returncode == 23
        assert rejected.stdout.strip() == "blocked-before-callback"
        assert not rejected_marker.exists()
        assert database.read_bytes() == b"original-database-file-must-remain-unchanged"
        other = tmp_path / "other.sqlite3"
        allowed = child_once(other, tmp_path / "other-callback")
        assert allowed.returncode == 0 and allowed.stdout.strip() == "acquired"
        assert not other.exists()
    finally:
        finish(holder)
    allowed_after_exit = child_once(database, tmp_path / "after-exit-callback")
    assert allowed_after_exit.returncode == 0
    assert database.read_bytes() == b"original-database-file-must-remain-unchanged"


def test_abrupt_process_exit_releases_os_lock_without_deleting_lock_file(tmp_path):
    database = tmp_path / "enterprise.sqlite3"
    holder = spawn_holder(database, tmp_path / "first")
    lock_file = EnterpriseRuntimeLock(database).lock_path
    finish(holder, kill=True)
    assert lock_file.is_file()
    after = child_once(database, tmp_path / "after-kill")
    assert after.returncode == 0 and after.stdout.strip() == "acquired"
    assert lock_file.is_file() and not database.exists()


def configured_settings():
    return SimpleNamespace(model_provider="anthropic", model_configured=True,
                           simple_model="claude-sonnet-5-5", complex_model="claude-opus-5-5",
                           anthropic_api_key=SimpleNamespace(get_secret_value=lambda: "unit-fixture-not-a-key"))


@pytest.mark.parametrize("port", [8025, 8039])
def test_cli_duplicate_rejected_before_app_repository_recovery_or_network_guard(monkeypatch, tmp_path, port):
    from nmate import config
    from nmate.main import app, local

    database = tmp_path / "enterprise.sqlite3"
    monkeypatch.setattr(config, "Settings", lambda **kwargs: configured_settings())
    monkeypatch.setattr(sys, "argv", ["nmate-main", "--data-dir", str(tmp_path), "--port", str(port)])
    calls = []
    monkeypatch.setattr(app, "make_main_app", lambda *args, **kwargs: calls.append("app-or-recovery"))
    monkeypatch.setattr(local, "network_guard", lambda: calls.append("network-guard"))
    with EnterpriseRuntimeLock(database):
        with pytest.raises(SystemExit, match="đang dùng dữ liệu"):
            local.main()
    assert calls == [] and not database.exists()


@pytest.mark.parametrize("failure", [False, True])
def test_cli_holds_lock_through_server_lifetime_and_releases_on_return_or_error(monkeypatch, tmp_path, failure):
    from nmate import config
    from nmate.main import app, local
    import uvicorn

    database = tmp_path / "enterprise.sqlite3"
    # Runtime now requires an explicitly initialized, compatible DB. Keep the
    # actual readiness gate in this ownership test rather than mocking it out.
    app.make_main_app(database, request_fn=lambda **kwargs: None, gateway_request_fn=lambda **kwargs: None)
    initialized_bytes = database.read_bytes()
    monkeypatch.setattr(config, "Settings", lambda **kwargs: configured_settings())
    monkeypatch.setattr(sys, "argv", ["nmate-main", "--data-dir", str(tmp_path)])
    monkeypatch.setattr(local, "network_guard", lambda: {"blocked_network_attempts": 0})
    calls = []

    def create(*args, **kwargs):
        assert Path(args[0]).resolve() == database.resolve()
        with pytest.raises(RuntimeAlreadyRunning):
            EnterpriseRuntimeLock(database).acquire()
        calls.append("app")
        return SimpleNamespace(state=SimpleNamespace())

    def serve(*args, **kwargs):
        with pytest.raises(RuntimeAlreadyRunning):
            EnterpriseRuntimeLock(database).acquire()
        calls.append("server")
        if failure:
            raise RuntimeError("test-server-exit")

    monkeypatch.setattr(app, "make_main_app", create)
    monkeypatch.setattr(uvicorn, "run", serve)
    if failure:
        with pytest.raises(RuntimeError, match="test-server-exit"):
            local.main()
    else:
        local.main()
    assert calls == ["app", "server"]
    with EnterpriseRuntimeLock(database):
        pass
    assert database.read_bytes() == initialized_bytes
