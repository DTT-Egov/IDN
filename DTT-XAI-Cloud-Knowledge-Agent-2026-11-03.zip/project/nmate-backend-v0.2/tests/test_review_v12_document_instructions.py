"""Document task instructions are not product assertions; free rollback is typed."""
import httpx
import pytest

from nmate.v04.extraction import extract_product_text
from nmate.v03.core import CoreError
from test_core_policy_http import call, good, register, running
from test_review_commands_v2 import data_snapshot
from test_review_v12_intake import local_only_services  # noqa: F401
from test_workspace_management import attachment, pdf_bytes, workspace as shared_workspace


@pytest.fixture
def workspace(tmp_path):
    return shared_workspace.__wrapped__(tmp_path)


def test_document_context_excludes_mentions_but_preserves_owner_declarations():
    question = "Chị đọc tài liệu Trà Sen để lập nháp hồ sơ"
    assert not extract_product_text(question, include_name_mentions=False)
    explicit = extract_product_text("Chị có Trà Sen Tây Hồ, khối lượng tịnh 100 g", include_name_mentions=False)
    assert next(item["value"] for item in explicit if item["field"] == "name") == "Trà Sen Tây Hồ"
    # Ordinary chat still proposes a named product. Document mode must not
    # weaken the common identity matcher or create prefix aliases.
    assert next(item["value"] for item in extract_product_text("Bột sen khối lượng tịnh 200 g")
                if item["field"] == "name") == "Bột sen"


def test_vietnamese_pdf_and_task_instruction_form_one_draft_over_http_mcp(tmp_path):
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("Document preparation must not dispatch AI")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "v12-document-instruction")
            question = "Chị đọc tài liệu Trà Sen để lập nháp hồ sơ"
            files = [attachment(pdf_bytes(["Tên sản phẩm: Trà sen Tây Hồ (THỬ NGHIỆM)",
                "Mã sản phẩm: TS100", "Khối lượng tịnh: 100 g", "Xuất xứ: Việt Nam"]))]
            result = good(web, url, session, "prepare_document_draft", text=question, attachments=files,
                          operation_id="vietnamese-document-instruction")
            item = result["intake"]
            names = [c["value"] for c in item["candidates"] if c["field"] == "name"]
            assert names == ["Trà sen Tây Hồ (THỬ NGHIỆM)"]
            assert item["product"]["name"] == names[0]
            assert item["product_binding"]["declared_name"] == names[0]
            assert any(c["field"] == "net_quantity" and c["value"] == "100 g" for c in item["candidates"])
            assert result["messages"][0]["text"] == question
            assert not result.get("pending_operation_id") and result["model_calls"] == 0
            account, enterprise = session["account"]["id"], session["enterprise"]["id"]
            assert app.state.repo.get_context(account, enterprise)["entities"] == []
            after = data_snapshot(app.state.repo)
            replay = good(web, url, session, "prepare_document_draft", text=question, attachments=files,
                          operation_id="vietnamese-document-instruction")
            assert replay["id"] == result["id"] and data_snapshot(app.state.repo) == after
            assert calls == []


@pytest.mark.parametrize("text,two_files", [
    ("Chị đọc tài liệu để lập nháp hồ sơ", True),
    ("Tên sản phẩm: Bột Sen; Chị đọc tài liệu để lập nháp hồ sơ", False),
])
def test_true_product_disagreement_is_rolled_back_not_uncertain(tmp_path, text, two_files):
    async def forbidden(*args, **kwargs):
        raise AssertionError("A rejected free document command must not dispatch AI")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "v12-document-disagreement")
            files = [attachment(pdf_bytes(["Tên sản phẩm: Trà sen Tây Hồ", "Lượng tịnh: 100 g"]))]
            if two_files:
                files.append(attachment(pdf_bytes(["Tên sản phẩm: Bột Sen", "Lượng tịnh: 200 g"]), "bot-sen.pdf"))
            before = data_snapshot(app.state.repo)
            for _ in range(2):
                result = call(web, url, session, "prepare_document_draft", text=text, attachments=files,
                              operation_id="true-document-name-disagreement")
                assert not result["ok"] and result["error"]["code"] == "multiple_products_not_supported"
                assert result["error"]["commit_state"] == "not_committed"
                assert data_snapshot(app.state.repo) == before


def test_document_mention_is_not_an_owner_selected_product_but_explicit_selection_is(workspace):
    app, service, owner, _ = workspace
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    shorter = app.state.repo.create_entity(account, enterprise, "product", "Trà Sen")
    actual = app.state.repo.create_entity(account, enterprise, "product", "Trà Sen Tây Hồ")
    files = [attachment(pdf_bytes(["Tên sản phẩm: Trà Sen Tây Hồ", "Lượng tịnh: 100 g"]))]
    before = app.state.repo.get_context(account, enterprise)
    view = service.prepare_document(account, enterprise, "Chị đọc tài liệu Trà Sen", files,
                                    "document-category-reference")
    assert view["intake"]["product"]["id"] == actual["id"]
    after = app.state.repo.get_context(account, enterprise)
    assert {k: v for k, v in after.items() if k != "as_of"} == {k: v for k, v in before.items() if k != "as_of"}
    # Owner selection is different from a mention or prior chat inference:
    # a conflicting explicit target is refused, never silently overridden.
    snapshot = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as blocked:
        service.prepare_document(account, enterprise, "Chị đọc tài liệu Trà Sen", files,
                                 "document-conflicting-selection", product_entity_id=shorter["id"])
    assert blocked.value.code == "product_selection_conflict"
    assert blocked.value.commit_state == "not_committed"
    assert data_snapshot(app.state.repo) == snapshot
