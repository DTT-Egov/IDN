"""Prerequisites are sourced advice, never hidden paid scope or SSOT writes."""
from __future__ import annotations

import copy
import json
import socket

import pytest

from nmate.v03.goal_readiness import market_entry_goal, project_goal_readiness, project_delivery_status, read_authority_records
from nmate.v03.core import CoreError, json_text
from nmate.v03.install_readiness import install_readiness_pack
from test_main_context_usage import setup, plan, get
from test_review_commands_v2 import data_snapshot


QUESTION = ("Chị có Trà Sen Tây Hồ, muốn bán sang Mỹ. Chị cần biết có phải đăng ký FDA không, "
            "nhãn cần những gì và ba việc đầu tiên chị nên làm.")


@pytest.fixture(autouse=True)
def deny_transport(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Readiness cannot invoke a network or model")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


def mission():
    return {"id": "mission-a", "market": {"code": "US"}, "question": QUESTION,
            "product": {"entity_id": "product-a", "name": "Trà Sen Tây Hồ"},
            "intent": {"scope": "us_food", "requested_action_count": 3, "outcomes": [{"id": "registration"}, {"id": "label"}]},
            "knowledge": {"records": [{"id": "label-ref"}]}, "answers": [{"outcome_id": "label", "text": "A saved cited answer"}], "actions": []}


@pytest.mark.parametrize("question,market", [
    (QUESTION, "JP"), (QUESTION, "DE"),
    ("Chị muốn bán sang Mỹ nhưng chỉ hỏi nhãn cần những gì và ba việc đầu tiên?", "US"),
    ("Ai nộp Prior Notice cho lô trà sang Mỹ?", "US"),
    ("Nhãn trà sang Mỹ cần gì?", "US"),
    ("Chị cần đăng ký FDA và chuẩn bị nhãn cho trà sang Mỹ", "US"),
])
def test_focused_or_other_market_request_does_not_manufacture_a_readiness_scope(question, market):
    assert market_entry_goal(question, market) is None


def test_goal_is_separate_from_explicit_outcomes_and_never_fabricates_a_quote():
    value = mission()
    before = copy.deepcopy(value)
    result = project_goal_readiness(value, [])
    assert result["goal"]["basis_quote"] == QUESTION
    assert result["market_code"] == "US" and result["mission_id"] == value["id"]
    assert result["does_not_change_saved_claude"] is True
    assert {item["id"] for item in result["requirements"]} == {"facility_registration", "food_label", "prior_notice", "fsvp_importer", "origin_marking"}
    assert all(item["status"] == "needs_source" and item["applicability"] == "not_assessed" for item in result["requirements"])
    assert result["first_actions"] == []
    assert value == before


def test_exact_v7_question_and_owner_self_reference_do_not_become_only_scope():
    text = "THỬ NGHIỆM: Chị là chủ cơ sở Trà sen Quảng An ở Tây Hồ. Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TEST-TRASEN-100-001, muốn bán sang Mỹ. Chị cần biết có phải đăng ký FDA không, nhãn cần những gì, và ba việc đầu tiên chị nên làm."
    assert market_entry_goal(text, "US") is not None
    assert market_entry_goal("Chị muốn bán sang Mỹ, cần ba việc đầu tiên.", "US") is not None
    assert market_entry_goal("Chỉ muốn hỏi nhãn cho lô hàng đầu tiên bán sang Mỹ.", "US") is None


@pytest.mark.parametrize("text", ["Tôi muốn xuất trà sang Mỹ, cần chuẩn bị những gì?", "Muốn bán trà sang Mỹ, bắt đầu từ đâu?", "Want to sell tea to US; what first steps?"])
def test_natural_broad_preparation_goals_are_not_limited_to_one_question_template(text):
    assert market_entry_goal(text, "US") is not None


def test_food_readiness_is_not_inferred_for_a_different_product_domain():
    value = mission()
    value["intent"]["scope"] = "unsupported"
    assert project_goal_readiness(value, []) is None


def test_explicit_negative_prior_notice_does_not_reappear_as_a_supporting_action():
    value = mission()
    value["question"] += " Chị không hỏi thông báo trước."
    result = project_goal_readiness(value, [])
    assert "prior_notice" not in {item["id"] for item in result["requirements"]}
    assert not any(action["id"] == "prepare-shipment" for action in result["first_actions"])


def test_installed_legacy_pn_excerpts_are_visible_but_coverage_still_names_missing_current_facets(setup):
    repo = setup[0]
    with repo.connection() as db:
        records = read_authority_records(db)
    result = project_goal_readiness(mission(), records)
    pn = next(item for item in result["requirements"] if item["id"] == "prior_notice")
    assert pn["origin"] == "supporting" and pn["status"] == "needs_source"
    assert {"exceptions", "international_mail_update"} <= set(pn["coverage"]["missing_facets"])
    assert {item["facet"] for item in pn["summary_items"]} == {"submitter", "timing"}
    assert all(item["citations"] for item in result["requirements"] if item["id"] in {"facility_registration", "food_label", "prior_notice"})
    assert len(result["first_actions"]) == 3
    assert [item["priority"] for item in result["first_actions"]] == [1, 2, 3]
    assert all(item["owner_vi"] and item["deliverable_vi"] and item["source_refs"] for item in result["first_actions"])
    assert result["first_actions"][0]["ui_action"]["field_keys"] == ["facility_activity", "facility_type", "facility_name", "facility_address"]


def test_new_prepare_snapshots_separate_checklist_and_repeated_get_keeps_raw_history_and_all_rows(setup):
    repo = setup[0]
    value = plan(setup, "readiness", QUESTION)
    assert {item["id"] for item in value["intent"]["outcomes"]} == {"registration", "label"}
    assert value["goal_readiness_snapshot"]["schema_version"] == "goal-readiness/1"
    assert value["readiness_source_refs"] == value["goal_readiness_snapshot"]["source_refs"]
    before = data_snapshot(repo)
    result = get(setup, value)
    assert result["goal_readiness"]["does_not_change_saved_claude"] is True
    assert result["intent"] == value["intent"] and result["context"] == value["context"]
    get(setup, value)
    assert data_snapshot(repo) == before
    with pytest.raises(CoreError):
        setup[5].get(setup[2]["account_id"], setup[2]["enterprise_id"], value["id"])
    assert data_snapshot(repo) == before


def test_old_paid_plan_get_adds_advice_without_backfilling_its_raw_snapshot(setup):
    repo = setup[0]
    value = plan(setup, "old-readiness", QUESTION)
    with repo.connection(write=True) as db:
        raw = json.loads(db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (value["id"],)).fetchone()[0])
        raw.pop("goal_readiness_snapshot")
        raw.pop("readiness_source_refs")
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(raw), value["id"]))
    before = data_snapshot(repo)
    result = get(setup, value)
    assert result["goal_readiness"]["origin"] == "server_bounded_authority_guidance"
    assert "goal_readiness_snapshot" not in result
    assert result["answers"] == raw["answers"] and result["intent"] == raw["intent"]
    assert data_snapshot(repo) == before


def test_delivery_gaps_do_not_discard_or_rewrite_valid_paid_answers():
    value = mission()
    value["actions"] = [{"id": "old-vague", "title": "Nhờ chuyên gia rà soát"}]
    before = copy.deepcopy(value)
    result = project_delivery_status(value)
    assert result["status"] == "partial" and result["actionable_count"] == 0
    assert result["does_not_invalidate_answers"] is True
    assert value == before


def test_complete_delivery_requires_scoped_basis_and_unique_real_priority():
    value = mission()
    value["actions"] = [{"id": str(i), "priority": i, "owner_vi": "Chủ cơ sở", "deliverable_vi": "Một bảng dữ kiện kiểm tra được", "basis_source_ids": ["label-ref"]} for i in range(1, 4)]
    assert project_delivery_status(value)["status"] == "complete"
    value["actions"][1]["priority"] = 1
    value["actions"][2]["basis_source_ids"] = ["foreign-private-ref"]
    result = project_delivery_status(value)
    assert result["status"] == "partial" and result["actionable_count"] == 0


def test_changed_supporting_source_invalidates_future_plan_before_model_dispatch(setup):
    repo, owner = setup[:2]
    value = plan(setup, "supporting-source", QUESTION)
    pn_source = next(ref["source_id"] for ref in value["readiness_source_refs"] if "PRIOR_NOTICE" in ref["reference_id"])
    assert pn_source not in {ref["source_id"] for ref in value["knowledge"]["source_refs"]}
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation' WHERE id=?", (pn_source,))
    before = data_snapshot(repo)
    current = get(setup, value)
    assert current["status"] == "needs_revalidation"
    with pytest.raises(CoreError) as caught:
        setup[5].start(owner["account_id"], owner["enterprise_id"], value["id"], "must-not-dispatch")
    assert caught.value.code == "context_changed"
    assert data_snapshot(repo) == before


def test_future_request_passes_delivery_and_supporting_sources_without_expanding_explicit_answers(setup):
    repo, _owner, _other, _product, _provider, service, bounded = setup
    value = plan(setup, "delivery-input", QUESTION)
    internal = bounded._internal(value["id"])
    internal["intent"]["requested_action_count"] = 3
    captured = []
    class StopBeforeDispatch(RuntimeError):
        pass
    async def capture(kind, payload, **_scope):
        captured.append((kind, payload))
        raise StopBeforeDispatch()
    service.model_call = capture
    before = data_snapshot(repo)
    with pytest.raises(StopBeforeDispatch):
        service._request_research(internal, internal["knowledge"]["records"]).send(None)
    kind, payload = captured[0]
    assert kind == "research" and payload["input"]["requested_action_count"] == 3
    assert {item["id"] for item in payload["input"]["outcomes"]} == {"registration", "label"}
    assert "prior_notice" in {item["id"] for item in payload["input"]["supporting_requirements"]}
    assert all("question_quote" not in item and "answer_vi" not in item and "citations" not in item for item in payload["input"]["supporting_requirements"])
    assert any("PRIOR_NOTICE" in item["id"] for item in payload["input"]["supporting_reference_records"])
    assert set(payload["input"]["delivery_requirements"]["fields"]) == {"priority", "owner_vi", "deliverable_vi", "basis_source_ids"}
    assert data_snapshot(repo) == before


def test_real_explicit_pack_completes_facets_without_deciding_tea_exception_or_fsvp_applicability(setup):
    repo = setup[0]
    install_readiness_pack(repo)
    before = data_snapshot(repo)
    with repo.connection() as db:
        records = read_authority_records(db)
    result = project_goal_readiness(mission(), records)
    requirements = {item["id"]: item for item in result["requirements"]}
    assert all(item["status"] == "reference_available" for item in requirements.values())
    assert all(item["applicability"] == "not_assessed" for item in requirements.values())
    assert requirements["origin_marking"]["coverage"]["available_facets"] == ["general_marking", "tea_exception"]
    pn = requirements["prior_notice"]
    assert {"submitter", "timing"} <= {item["facet"] for item in pn["summary_items"]}
    assert all(item["reference_ids"] for item in pn["summary_items"])
    assert "international_mail_update" in pn["coverage"]["available_facets"]
    assert any("US_FSVP_IMPORTER_20261022_V1" == citation["reference_id"] for citation in requirements["fsvp_importer"]["citations"])
    assert result["first_actions"][2]["ui_action"]["kind"] == "review_importer_shipping"
    assert data_snapshot(repo) == before


def test_non_tea_product_never_receives_tea_exception_or_a_tea_facility_template(setup):
    repo = setup[0]
    install_readiness_pack(repo)
    value = mission()
    value["product"]["name"] = "Mứt Sen Hạt"
    value["question"] = "Chị có Mứt Sen Hạt muốn bán sang Mỹ, cần ba việc đầu tiên."
    with repo.connection() as db:
        result = project_goal_readiness(value, read_authority_records(db))
    origin = next(item for item in result["requirements"] if item["id"] == "origin_marking")
    assert origin["coverage"]["required_facets"] == ["general_marking"]
    assert not any("TEA_EXCEPTION" in item["reference_id"] for item in origin["citations"])
    assert "tea_exception" not in origin["coverage"]["available_facets"]
    assert "ướp trà" not in result["first_actions"][0]["deliverable_vi"]


def test_existing_confirmed_facility_facts_are_reused_instead_of_asked_again(setup):
    repo = setup[0]
    value = mission()
    value["current_context"] = {"values": {"facility_name": "Cơ sở Quảng An", "facility_address": "Tây Hồ", "net_quantity": "100 g"}}
    with repo.connection() as db:
        result = project_goal_readiness(value, read_authority_records(db))
    action = result["first_actions"][0]
    assert action["reused_fact_keys"] == ["facility_name", "facility_address"]
    assert action["ui_action"]["field_keys"] == ["facility_activity", "facility_type"]
    assert "net_quantity" in result["first_actions"][1]["reused_fact_keys"]


def test_pack_supersession_invalidates_only_new_snapshot_not_old_paid_answers(setup):
    repo = setup[0]
    value = plan(setup, "prepack-future", QUESTION)
    before_context = copy.deepcopy(value["context"])
    before_answers = copy.deepcopy(value["answers"])
    install_readiness_pack(repo)
    before = data_snapshot(repo)
    result = get(setup, value)
    assert result["status"] == "needs_revalidation"
    assert result["answers"] == before_answers and result["context"] == before_context
    assert all("US_PN_" in citation["reference_id"] for requirement in result["goal_readiness"]["requirements"] if requirement["id"] == "prior_notice" for citation in requirement["citations"])
    assert data_snapshot(repo) == before


def test_real_pack_future_prompt_passes_public_egress_and_fits_existing_gateway_limit(setup):
    from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
    repo, _owner, _other, _product, provider, service, bounded = setup
    install_readiness_pack(repo)
    value = plan(setup, "real-pack-wire", QUESTION)
    internal = bounded._internal(value["id"])
    internal["intent"]["requested_action_count"] = 3
    captured = []
    class StopBeforeDispatch(RuntimeError):
        pass
    async def capture(kind, payload, **_scope):
        captured.append((kind, payload))
        raise StopBeforeDispatch()
    service.model_call = capture
    before = data_snapshot(repo)
    with pytest.raises(StopBeforeDispatch):
        service._request_research(internal, internal["knowledge"]["records"]).send(None)
    kind, payload = captured[0]
    compiled = GovernedLegacyAdapter(repo, None, provider).compile_payload(kind, payload)
    assert any(item["id"].startswith("US_FSVP_") for item in compiled["input"]["supporting_reference_records"])
    assert len(json_text({"input": compiled, "response_schema": payload["response_schema"], "purpose": "legacy_research", "task_instructions_vi": payload["instructions_vi"]}).encode("utf-8")) <= 30000
    assert data_snapshot(repo) == before
