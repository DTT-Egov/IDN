"""Rich error hints are a small explicit contract, not arbitrary exception data."""
from nmate.v03.core import CoreError
from nmate.v03.mcp import public_core_error


def test_owner_binding_hint_survives_mcp_without_extra_data():
    error=CoreError('product_binding_required','Cần chọn hồ sơ hiện có.',409)
    error.commit_state='not_committed'
    error.details={'kind':'product_binding_required','requested_name':'Bột sen','intake_id':'intake_qa',
        'matched_entities':[{'id':'entity_qa','name':'Bột sen','version':1,'private_fact':'must-not-cross'}],
        'raw_document':'must-not-cross'}
    result=public_core_error(error)
    assert result['commit_state']=='not_committed'
    assert result['details']['matched_entities']==[{'id':'entity_qa','name':'Bột sen','version':1}]
    assert 'raw_document' not in result['details']


def test_other_errors_never_serialize_arbitrary_details():
    error=CoreError('invalid_quantity','Lượng tịnh chưa hợp lệ.')
    error.details={'raw_document':'must-not-cross'}
    assert public_core_error(error)=={'code':'invalid_quantity','message':'Lượng tịnh chưa hợp lệ.'}


def test_malformed_hint_stays_a_message_without_untrusted_target():
    error=CoreError('product_binding_required','Chọn lại hồ sơ.')
    error.details={'kind':'product_binding_required','requested_name':'Bột sen','intake_id':'qa',
        'matched_entities':[{'id':'entity_qa','name':'Bột sen','version':True}]}
    assert 'details' not in public_core_error(error)
