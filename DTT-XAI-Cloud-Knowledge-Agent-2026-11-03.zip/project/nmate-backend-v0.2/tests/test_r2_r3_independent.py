"""Independent R2/R3 acceptance, using only synthetic local state.

Expected goals derive from the owner's positive/negative instructions rather
than from planner internals. These tests do not call an external model.
"""
from copy import deepcopy
from pathlib import Path
import socket

import httpx
import pytest

from nmate.core_v1.integration import CoreIntegration
from nmate.v03.intent_plan import compile_dialogue_plan
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import json_text
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from nmate.v04.dialogue import interpret
from nmate.v04.intake import IntakeService
from test_review_architecture_acceptance import TEXT, confirm, pending_fields
from test_review_commands_v2 import data_snapshot
from test_r3_domain_graph import domain as domain_fixture, source, propose, publish
from test_core_policy_http import running, register, good, call


@pytest.fixture
def domain(tmp_path):
    return domain_fixture.__wrapped__(tmp_path)


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "independent-r2-r3.sqlite3")
    account = LocalAccounts(repo).register("independent-r2-r3", "Only-fixture-password", "Trà Sen QA")
    service = IntakeService(repo)
    intake = service.prepare(account["account_id"], account["enterprise_id"], TEXT, [], "independent-prepare")
    return repo, account, service, intake


@pytest.fixture(autouse=True)
def no_external_io(monkeypatch):
    original = socket.socket.connect
    original_ex = socket.socket.connect_ex

    def local_only(sock, address):
        if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
            return original(sock, address)
        raise AssertionError("Independent R2/R3 review must not use network/provider")

    def local_only_ex(sock, address):
        if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
            return original_ex(sock, address)
        raise AssertionError("Independent R2/R3 review must not use network/provider")
    monkeypatch.setattr(socket.socket, "connect", local_only)
    monkeypatch.setattr(socket.socket, "connect_ex", local_only_ex)


@pytest.mark.parametrize("question,retained,excluded", [
    ("Chị muốn xuất trà sang Mỹ, cần đăng ký FDA và không muốn hỏi nhãn.",
     {"facility_registration"}, {"food_label"}),
    ("Chị muốn xuất trà sang Mỹ, không cần đăng ký FDA mà cần tìm hiểu nhãn và thông báo trước.",
     {"food_label", "prior_notice"}, {"facility_registration"}),
])
def test_negative_request_cannot_erase_positive_goal_in_same_sentence(question, retained, excluded):
    intent = interpret(question)
    before = deepcopy(intent)
    plan = compile_dialogue_plan(intent, question)
    requirements = {item["id"] for item in plan["requirements"]}
    assert retained <= requirements
    assert requirements.isdisjoint(excluded)
    assert set(plan["intent"]["exclusions"]) == excluded
    assert intent == before


def test_negative_export_clause_does_not_pollute_current_inventory_task():
    question = "Chị không muốn xuất khẩu sang Mỹ nữa, giờ chị cần kiểm kê tồn kho."
    intent = interpret(question)
    plan = compile_dialogue_plan(intent, question)
    assert plan["intent"]["domain"] == "operations"
    assert plan["intent"]["focus"] == "inventory_accuracy"
    assert plan["intent"]["market_codes"] == []
    assert not any(item["id"] in {"facility_registration", "food_label", "prior_notice"}
                   for item in plan["requirements"])


def test_past_shipment_does_not_expand_current_label_question():
    question = "Chị đã xuất lô hàng đầu tiên sang Mỹ, nay hỏi nhãn cần ghi gì?"
    plan = compile_dialogue_plan(interpret(question), question)
    assert [item["id"] for item in plan["requirements"]] == ["food_label"]
    assert len(plan["first_actions"]) == 1
    assert plan["intent"]["goals"][0]["quote"] == question


@pytest.mark.parametrize("question,retained,excluded", [
    ("Chị muốn xuất trà sang Mỹ, cần đăng ký FDA nhưng không hỏi nhãn và thông báo trước.",
     {"facility_registration"}, {"food_label", "prior_notice"}),
    ("Chị muốn gửi trà sang Mỹ, không hỏi nhãn và thông báo trước mà cần tìm hiểu đăng ký FDA.",
     {"facility_registration"}, {"food_label", "prior_notice"}),
    ("Chị muốn gửi trà sang Mỹ, không cần đăng ký FDA và nhãn nhưng cần hỏi thông báo trước.",
     {"prior_notice"}, {"facility_registration", "food_label"}),
])
def test_negative_topic_list_and_explicit_positive_connector_keep_polarity(question, retained, excluded):
    plan = compile_dialogue_plan(interpret(question), question)
    assert {item["id"] for item in plan["requirements"]} == retained
    assert set(plan["intent"]["exclusions"]) == excluded


def test_past_completed_preparation_is_background_not_a_new_label_goal():
    question = "Chị đã đăng ký FDA và đã chuẩn bị nhãn; giờ hỏi ai nộp thông báo trước khi gửi trà sang Mỹ?"
    plan = compile_dialogue_plan(interpret(question), question)
    assert {item["id"] for item in plan["requirements"]} == {"prior_notice"}


def test_graph_field_dependencies_include_applicability_precondition(domain):
    """A graph consumer must see the same required facts as actual assessment."""
    _, owner, catalog = domain
    rule = propose(domain, source(domain), extra={"applies_when": {
        "field": "industry", "op": "eq", "value": "thực phẩm"}})
    publish(domain, rule)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ độc lập", [rule["member_id"]])
    finding = catalog.assess([{"field": "registration_province", "value": "Hà Nội"}])[0]
    assert finding["applies_when"]["state"] == "unknown"
    graph = catalog.domain_graph()
    dependencies = [edge for edge in graph["edges"]
                    if edge["from"]["id"] == rule["member_id"]
                    and edge["to"]["kind"] == "domain_field_requirement"]
    assert {edge["to"]["id"] for edge in dependencies} == {"industry", "registration_province"}


def test_old_exact_confirmation_after_later_partial_save_is_read_only_and_current(workspace):
    repo, owner, service, intake = workspace
    selected = [candidate["id"] for candidate in intake["candidates"] if candidate["field"] in {"name", "product_code"}]
    args = (owner["account_id"], owner["enterprise_id"], intake["id"], selected,
            deepcopy(intake["expected_entity_versions"]), "independent-original-confirmation")
    kwargs = {"expected_review_revision": intake["review"]["revision"],
              "expected_proposal_hashes": {key: intake["review"]["proposal_hashes"][key] for key in selected}}
    first = service.confirm(*args, **kwargs)
    first_receipt = deepcopy(first["confirmation_receipt"])
    later = confirm(service, owner, first, ["net_quantity"], "independent-later-confirmation")
    before = data_snapshot(repo)
    reloaded = IntakeService(CoreRepository(repo.db_path))
    replay = reloaded.confirm(*args, **kwargs)
    assert replay["confirmation_receipt"] == first_receipt
    assert pending_fields(replay) == pending_fields(later)
    assert "net_quantity" not in pending_fields(replay)
    assert replay["review"]["revision"] > first_receipt["workspace_revision_after"]
    assert replay["latest_confirmation_receipt"]["receipt_id"] != first_receipt["receipt_id"]
    assert data_snapshot(repo) == before


def test_stale_new_confirmation_is_atomic_and_cannot_rewrite_decided_name(workspace):
    repo, owner, service, intake = workspace
    first = confirm(service, owner, intake, ["name", "product_code"], "independent-name-first")
    before = data_snapshot(repo)
    with pytest.raises(CoreError):
        confirm(service, owner, intake, ["name", "net_quantity"], "independent-stale-tab")
    assert data_snapshot(repo) == before
    current = service.get(owner["account_id"], owner["enterprise_id"], intake["id"])
    assert pending_fields(current) == pending_fields(first)
    assert current["workspace_contract"]["review"]["pending_count"] == len(pending_fields(first))


def test_revoke_read_wins_prior_receipt_and_owned_workspace(workspace):
    repo, owner, service, intake = workspace
    first = confirm(service, owner, intake, ["name", "product_code"], "independent-before-revoke")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (first["product"]["id"],))
    before = data_snapshot(repo)
    with pytest.raises(CoreError):
        service.get(owner["account_id"], owner["enterprise_id"], intake["id"])
    with pytest.raises(CoreError):
        service.get_review_receipt(owner["account_id"], owner["enterprise_id"], intake["id"], "independent-before-revoke")
    assert data_snapshot(repo) == before


def test_current_plan_product_reference_follows_ssot_rename_without_rewriting_saved_analysis(workspace):
    repo, owner, service, intake = workspace
    saved = confirm(service, owner, intake, ["name", "product_code"], "independent-before-rename")
    original_name = saved["product"]["name"]
    renamed = "Trà Sen Hương Hồ"
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], saved["product"]["id"],
        [{"field": "name", "value": renamed}], saved["product"]["version"], "independent-owner-renames")
    before = data_snapshot(repo)
    view = service.get(owner["account_id"], owner["enterprise_id"], intake["id"])
    assert view["intent_plan_basis"]["kind"] == "current_read_projection"
    assert view["intent_plan"]["intent"]["product_ref"]["id"] == saved["product"]["id"]
    assert view["intent_plan"]["intent"]["product_ref"]["name"] == renamed
    assert view["saved_context"] == saved["saved_context"]
    assert saved["product"]["name"] == original_name
    assert data_snapshot(repo) == before


def test_same_owner_other_workspace_read_has_its_own_pending_set(workspace):
    repo, owner, service, intake = workspace
    first = confirm(service, owner, intake, ["name", "product_code"], "independent-first-product")
    second = service.prepare(owner["account_id"], owner["enterprise_id"],
        "Chị có Mứt sen sấy, khối lượng tịnh 200 g, mã MS-02, bao bì túi zip.", [], "independent-second-product")
    before = data_snapshot(repo)
    reloaded = IntakeService(CoreRepository(repo.db_path))
    a = reloaded.get(owner["account_id"], owner["enterprise_id"], first["id"])
    b = reloaded.get(owner["account_id"], owner["enterprise_id"], second["id"])
    assert a["workspace_contract"]["scope"]["workspace_id"] != b["workspace_contract"]["scope"]["workspace_id"]
    assert a["product"]["id"] != b["product"]["id"]
    assert set(a["review"]["pending_candidate_ids"]).isdisjoint(b["review"]["pending_candidate_ids"])
    assert pending_fields(a) == pending_fields(first)
    assert {"name", "product_code", "net_quantity", "packaging"} <= pending_fields(b)
    assert data_snapshot(repo) == before


def test_malformed_legacy_reference_translation_is_a_local_blocker_not_graph_crash(tmp_path):
    """A damaged reference must not discard other independent public evidence."""
    repo = CoreRepository(tmp_path / "legacy-translation.sqlite3")
    catalog = DomainCatalog(repo)
    original = catalog.lookup(["food_label"], market_code="US")["records"][0]
    import json
    with repo.connection(write=True) as db:
        row = db.execute("SELECT record_json FROM v03_domain_references WHERE id=?", (original["id"],)).fetchone()
        damaged = json.loads(row[0])
        damaged["excerpt_vi"] = {"not": "translated text"}
        db.execute("UPDATE v03_domain_references SET record_json=? WHERE id=?", (json_text(damaged), original["id"]))
    before = data_snapshot(repo)
    graph = catalog.domain_graph(market_code="US", as_of_date="2026-10-22")
    assert any(item["reference_id"] == original["id"] and item["reason_code"] == "REFERENCE_CONTRACT_INVALID"
               for item in graph["blocked"])
    assert any(item["reference_id"] != original["id"] for item in graph["dependencies"])
    assert data_snapshot(repo) == before


def test_actual_http_mcp_plan_uses_current_selected_product_and_static_module_is_public(tmp_path, monkeypatch):
    """Exercise BFF -> real HTTP MCP -> scoped query, beyond projector units."""
    calls = []

    async def forbidden(*_args, **_kwargs):
        calls.append(True)
        raise AssertionError("HTTP free/read workflow must not dispatch a model")

    async def idle(_self):
        return False

    monkeypatch.setattr(CoreIntegration, "execute_next", idle)
    web_dir = Path(__file__).resolve().parents[2] / "nmate-mvp-v0.1"
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden, web_dir=web_dir) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=25) as web, \
             httpx.Client(base_url=url, trust_env=False, timeout=25) as other:
            html = web.get("/web/")
            assert html.status_code == 200
            assert html.text.index("src/main-ui-contracts.js") < html.text.index("src/main-app.js")
            module = web.get("/web/src/main-ui-contracts.js")
            assert module.status_code == 200 and "NMateUIContracts" in module.text
            assert "javascript" in module.headers["content-type"]
            session = register(web, url, "independent-http-owner")
            outsider = register(other, url, "independent-http-other")
            account, enterprise = session["account"]["id"], session["enterprise"]["id"]
            chat = good(web, url, session, "prepare_chat_draft",
                text="Chị có Trà Sen Tây Hồ, khối lượng tịnh 100 g, mã TS-HTTP, bao bì hộp giấy. Chị chỉ hỏi nhãn khi bán sang Mỹ cần gì?",
                operation_id="independent-http-draft", task_hint="export_research")
            intake = chat["intake"]
            selected = [item["id"] for item in intake["candidates"] if item["field"] in {"name", "product_code", "net_quantity", "packaging"}]
            saved = good(web, url, session, "confirm_intake", intake_id=intake["id"], selected_fact_ids=selected,
                expected_entity_versions=intake["expected_entity_versions"], expected_review_revision=intake["review"]["revision"],
                expected_proposal_hashes={key: intake["review"]["proposal_hashes"][key] for key in selected},
                operation_id="independent-http-confirm")
            product = saved["product"]
            repo = app.state.core_extension.repo
            other_product = repo.create_entity(account, enterprise, "product", "Mứt Sen Riêng")
            repo.propose_or_apply_facts(account, enterprise, other_product["id"],
                [{"field": "net_quantity", "value": "999 g"}], 0, "independent-other-product")
            repo.propose_or_apply_facts(account, enterprise, product["id"],
                [{"field": "net_quantity", "value": "150 g"}], product["version"], "independent-current-quantity")
            before = data_snapshot(repo)
            for _ in range(2):
                view = good(web, url, session, "get_intake", intake_id=intake["id"])
                conversation = good(web, url, session, "get_conversation", conversation_id=chat["id"])
                workspace = good(web, url, session, "get_review_workspace", intake_id=intake["id"])
                assert view["intent_plan"]["intent"]["known_inputs"]["net_quantity"] == "150 g"
                assert conversation["intake"]["intent_plan"]["intent"]["known_inputs"]["net_quantity"] == "150 g"
                current = next(entity for entity in workspace["current_context"]["entities"] if entity["id"] == product["id"])
                historical = next(entity for entity in workspace["historical_analysis"]["saved_context"]["entities"] if entity["id"] == product["id"])
                assert current["values"]["net_quantity"] == "150 g"
                assert historical["values"]["net_quantity"] == "100 g"
                assert other_product["id"] not in view["workspace_contract"]["scope"]["entity_ids"]
                assert all(entity["id"] != other_product["id"] for entity in workspace["current_context"]["entities"])
                denied = call(other, url, outsider, "get_intake", enterprise_id=enterprise, intake_id=intake["id"])
                assert denied["ok"] is False
            assert data_snapshot(repo) == before
            assert calls == []

            # Build a synthetic historical mission using the existing free
            # service, then read it through MAIN's actual BFF/MCP projection.
            mission = MissionService(repo).prepare(account, enterprise,
                "Chị chỉ hỏi nhãn Trà Sen Tây Hồ gửi sang Mỹ cần ghi gì?", "independent-graph-mission", product["id"])
            snapshot = data_snapshot(repo)
            projected = good(web, url, session, "get_mission", mission_id=mission["id"])
            assert projected["domain_graph"]["market_code"] == "US"
            assert projected["domain_graph"]["dependencies"]
            assert projected["workspace_contract"]["scope"]["resource_kind"] == "research"
            assert product["id"] in projected["workspace_contract"]["scope"]["entity_ids"]
            assert other_product["id"] not in projected["workspace_contract"]["scope"]["entity_ids"]
            assert all(node["ref"]["kind"] not in {"claim_version", "rule_version"}
                       for node in projected["domain_graph"]["nodes"])
            assert data_snapshot(repo) == snapshot
            source_id = mission["knowledge"]["records"][0]["source_id"]
            with repo.connection(write=True) as db:
                db.execute("UPDATE v03_domain_sources SET rights='enterprise_private' WHERE id=?", (source_id,))
            revoked = data_snapshot(repo)
            denied = call(web, url, session, "get_mission", mission_id=mission["id"])
            assert denied["ok"] is False and denied["error"]["code"] == "domain_read_forbidden"
            assert data_snapshot(repo) == revoked and calls == []
