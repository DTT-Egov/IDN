"""Operator commands run only on isolated DBs; no real role/budget approvals."""
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.core_v1.operator import administer, main
from nmate.policy_v1.catalog import KnowledgeCatalog
from nmate.v03.core import CoreError, CoreRepository, now_iso


@pytest.fixture
def repo(tmp_path):
    value = CoreRepository(tmp_path / "operator.sqlite")
    with value.connection(write=True) as db:
        for account in ("owner", "staff"):
            db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES(?,?,?,?)",
                       (account, account, "private-credential-test-never-print", now_iso()))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('enterprise','Doanh nghiệp riêng',?)", (now_iso(),))
        db.execute("INSERT INTO v03_memberships VALUES('owner','enterprise','owner',1)")
        db.execute("INSERT INTO v03_memberships VALUES('staff','enterprise','staff',1)")
    return value


def budget(repo, approval="TEST-D06-LOCAL", **extra):
    return administer(repo, "budget-grant", approval_id=approval, username="owner", enterprise_id="enterprise",
                      max_calls=3, cap_usd="1.50", roles=["standard", "complex"], purposes=["hanoi_policy_synthesis"],
                      expires_at="2099-01-01T00:00:00+00:00", **extra)


def test_bootstrap_role_has_explicit_reference_and_no_enterprise_data_privilege(repo):
    result = administer(repo, "knowledge-grant", approval_id="TEST-ASSIGN-REVIEWER", username="staff", role="reviewer")
    assert result["role"] == "reviewer" and "expert" not in result
    with repo.connection() as db:
        row = db.execute("SELECT * FROM pol_knowledge_roles").fetchone()
        assert row["granted_by"] == "operator:TEST-ASSIGN-REVIEWER"
        assert db.execute("SELECT role FROM v03_memberships WHERE account_id='staff'").fetchone()[0] == "staff"
    assert administer(repo, "knowledge-grant", approval_id="TEST-ASSIGN-REVIEWER", username="staff", role="reviewer") == result
    with pytest.raises(CoreError) as conflict:
        administer(repo, "knowledge-grant", approval_id="TEST-ASSIGN-REVIEWER", username="owner", role="reviewer")
    assert conflict.value.code == "approval_conflict"


def test_domain_role_revocation_is_effective(repo):
    administer(repo, "knowledge-grant", approval_id="TEST-ADMIN", username="owner", role="admin")
    catalog = KnowledgeCatalog(repo)
    with repo.connection() as db:
        catalog._authority(db, "owner", "reviewer")
    administer(repo, "knowledge-revoke", approval_id="TEST-REVOKE-ADMIN", username="owner", role="admin")
    with repo.connection() as db:
        with pytest.raises(CoreError):
            catalog._authority(db, "owner", "reviewer")


def test_budget_grant_never_enables_inference_or_calls_provider_and_is_idempotent(repo):
    first = budget(repo)
    assert first["inference_enabled"] is False and first["max_calls"] == 3
    assert budget(repo) == first
    with repo.connection() as db:
        grants = db.execute("SELECT * FROM core_budget_grants").fetchall()
        assert len(grants) == 1 and grants[0]["cap_microusd"] == 1_500_000
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0


def test_budget_revocation_preserves_unknown_attempt_holds(repo):
    result = budget(repo)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO core_model_operations VALUES('enterprise','op','owner','hash','hanoi_policy_synthesis',NULL,'reserved',?)", (now_iso(),))
        db.execute("INSERT INTO core_model_attempts(id,enterprise_id,operation_id,task_id,step_key,actor_id,grant_id,profile_version,"
                   "model,price_version,request_hash,input_upper_tokens,max_output_tokens,held_microusd,state,created_at,dispatched_at) "
                   "VALUES('attempt','enterprise','op','task','synthesis','owner',?,'standard/1','test-only','test','hash',100,256,500,'outcome_unknown',?,?)",
                   (result["grant_id"], now_iso(), now_iso()))
    revoked = administer(repo, "budget-revoke", approval_id="TEST-REVOKE-BUDGET", username="owner", enterprise_id="enterprise", grant_id=result["grant_id"])
    assert revoked["status"] == "revoked"
    with repo.connection() as db:
        assert db.execute("SELECT state FROM core_budget_grants").fetchone()[0] == "revoked"
        attempt = db.execute("SELECT state,held_microusd FROM core_model_attempts").fetchone()
        assert tuple(attempt) == ("outcome_unknown", 500)


def test_cli_requires_existing_database_and_safe_metadata_only(repo, tmp_path, capsys):
    missing = tmp_path / "does-not-exist.sqlite"
    assert main(["--db", str(missing), "knowledge-grant", "--approval-id", "TEST-CLI", "--username", "owner", "--role", "admin"]) == 2
    assert not missing.exists()
    assert "database_required" in capsys.readouterr().err
    assert main(["--db", repo.db_path, "knowledge-grant", "--approval-id", "TEST-CLI", "--username", "owner", "--role", "admin"]) == 0
    out = capsys.readouterr().out
    assert json.loads(out)["ok"]
    assert "private-credential-test" not in out and "Doanh nghiệp riêng" not in out


def test_budget_cli_requires_exact_calls_cap_roles_purpose_expiry(repo, capsys):
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    code = main(["--db", repo.db_path, "budget-grant", "--approval-id", "TEST-CLI-D06", "--username", "owner",
                 "--enterprise-id", "enterprise", "--max-calls", "2", "--cap-usd", "1.25", "--roles", "standard",
                 "--purposes", "hanoi_policy_synthesis", "--expires-at", expiry])
    assert code == 0
    result = json.loads(capsys.readouterr().out)["result"]
    assert result["max_calls"] == 2 and result["cap_usd"] == "1.25" and result["inference_enabled"] is False
    assert result["roles"] == ["standard"]


def test_failed_or_pending_approval_never_retries_creating_another_budget(repo):
    with pytest.raises(CoreError):
        administer(repo, "budget-grant", approval_id="TEST-D06-INVALID", username="staff", enterprise_id="enterprise",
                   max_calls=1, cap_usd="1", roles=["standard"], purposes=["hanoi_policy_synthesis"],
                   expires_at="2099-01-01T00:00:00+00:00")
    with pytest.raises(CoreError) as pending:
        administer(repo, "budget-grant", approval_id="TEST-D06-INVALID", username="staff", enterprise_id="enterprise",
                   max_calls=1, cap_usd="1", roles=["standard"], purposes=["hanoi_policy_synthesis"],
                   expires_at="2099-01-01T00:00:00+00:00")
    assert pending.value.code == "operator_outcome_pending"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 0


def test_role_and_account_constraints(repo):
    for arguments in ({"role": "fake_expert", "username": "owner", "approval_id": "TEST-ROLE"},
                      {"role": "reviewer", "username": "missing", "approval_id": "TEST-NO-ACCOUNT"},
                      {"role": "reviewer", "username": "owner", "approval_id": ""}):
        with pytest.raises(CoreError):
            administer(repo, "knowledge-grant", **arguments)
