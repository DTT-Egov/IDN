"""Archived paid intake is visible privately; it is never a legal publication."""
import copy
import json

import pytest

from nmate.main.recorded_analysis import project_recorded_export_intake
from nmate.v03.core import CoreError, json_text, now_iso
from test_live_intake_clarification_separation import RECORDED_INTAKE
from test_unified_main import setup as shared_setup, scope


@pytest.fixture(name="setup")
def setup_fixture(tmp_path):
    fixture = shared_setup.__wrapped__(tmp_path)
    repo, owner, _, _, _, _, _, _ = fixture
    stamp = now_iso()
    payload = {"id": "archive-conversation", "enterprise_id": owner["enterprise_id"], "owner_id": owner["account_id"],
               "title": "A truncated old title", "messages": [], "drafts": {}, "created_at": stamp, "updated_at": stamp}
    envelope = {"data": copy.deepcopy(RECORDED_INTAKE), "attempt_id": "archive-attempt", "model": "claude-sonnet-5-5"}
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (payload["id"], owner["enterprise_id"], owner["account_id"], json_text(payload), stamp, stamp))
        db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'failed','live_output_invalid',?)",
                   (*scope(owner), "archive-operation", "original-app-request-hash", payload["id"], "export_research", stamp))
        db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,model,state,response_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                   ("archive-attempt", *scope(owner), "archive-operation", "intake", "original-provider-request-hash", "claude-sonnet-5-5", "succeeded", json_text(envelope), stamp))
    return fixture


def snapshot(repo):
    with repo.connection() as db:
        return {table: [tuple(row) for row in db.execute("SELECT * FROM " + table)] for table in (
            "v03_live_attempts", "main_operations", "v04_conversations", "v03_current_facts", "v03_fact_assertions",
            "v03_missions", "v03_task_attempts", "v03_artifact_revisions", "v03_live_review_outputs")}


def test_owner_can_read_structured_archive_repeatedly_without_plan_publication_model_or_ssot_write(setup):
    repo, owner, _, model, _, _, _, _ = setup
    original = snapshot(repo)
    projection = project_recorded_export_intake(repo, *scope(owner), "archive-conversation")
    assert projection == project_recorded_export_intake(repo, *scope(owner), "archive-conversation")
    assert projection["status"] == "saved_intake_not_revalidated"
    assert projection["verification_state"] == "structure_only_original_question_not_revalidated"
    assert "chưa có câu trả lời nghiên cứu" in projection["title_vi"]
    assert {outcome["id"] for outcome in projection["outcomes"]} == {"registration", "label"}
    assert all(outcome["verification_state"] == "archival_not_revalidated" for outcome in projection["outcomes"])
    assert projection["clarification_requests"] == ["ba việc đầu tiên nên làm"]
    assert projection["receipt"]["paid_calls_already_recorded"] == 1
    assert projection["new_model_calls"] == projection["ssot_writes"] == 0
    assert not projection["research_completed"] and not projection["can_start_research"]
    assert projection["answers"] == projection["actions"] == projection["artifacts"] == []
    assert projection["original_result_preserved"]
    assert snapshot(repo) == original and model.calls == []


def test_other_owner_or_foreign_enterprise_cannot_read_the_archival_content(setup):
    repo, owner, other, model, _, _, _, _ = setup
    with pytest.raises(CoreError) as missing:
        project_recorded_export_intake(repo, *scope(other), "archive-conversation")
    assert missing.value.code == "not_found"
    with pytest.raises(CoreError) as forbidden:
        project_recorded_export_intake(repo, other["account_id"], owner["enterprise_id"], "archive-conversation")
    assert forbidden.value.code == "forbidden"
    assert model.calls == []


@pytest.mark.parametrize("drift", ["uncommitted", "unknown", "bad_json", "bad_schema", "wrong_receipt", "linked", "different_error", "newer_operation"])
def test_archive_fails_closed_on_unknown_result_bad_schema_or_operation_drift(setup, drift):
    repo, owner, _, model, _, _, _, _ = setup
    with repo.connection(write=True) as db:
        if drift in {"uncommitted", "unknown"}:
            db.execute("UPDATE v03_live_attempts SET state=? WHERE id='archive-attempt'", ("prepared" if drift == "uncommitted" else "outcome_unknown",))
        elif drift == "bad_json":
            db.execute("UPDATE v03_live_attempts SET response_json='{' WHERE id='archive-attempt'")
        elif drift in {"bad_schema", "wrong_receipt"}:
            envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id='archive-attempt'").fetchone()[0])
            if drift == "bad_schema":
                envelope["data"]["invented_answer"] = "FDA approved"
            else:
                envelope["attempt_id"] = "another-attempt"
            db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id='archive-attempt'", (json_text(envelope),))
        elif drift == "linked":
            db.execute("UPDATE v03_live_attempts SET mission_id='another-mission' WHERE id='archive-attempt'")
        elif drift == "different_error":
            db.execute("UPDATE main_operations SET error_code='OUTCOME_UNKNOWN'")
        else:
            db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'completed',NULL,?)",
                       (*scope(owner), "newer-operation", "hash", "archive-conversation", "profile_intake", now_iso()))
    original = snapshot(repo)
    assert project_recorded_export_intake(repo, *scope(owner), "archive-conversation") is None
    assert snapshot(repo) == original and model.calls == []


def test_archival_question_quote_does_not_become_verified_without_the_original_request(setup):
    repo, owner, _, _, _, _, _, _ = setup
    with repo.connection(write=True) as db:
        envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id='archive-attempt'").fetchone()[0])
        envelope["data"]["outcomes"][0]["question_quote"] = "A quote which cannot be checked against the truncated title."
        db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id='archive-attempt'", (json_text(envelope),))
    projection = project_recorded_export_intake(repo, *scope(owner), "archive-conversation")
    assert projection["outcomes"][0]["verification_state"] == "archival_not_revalidated"
    assert not projection["can_start_research"] and not projection["research_completed"]
