"""Transport intent cannot become part of a proposed product name."""
import pytest

from nmate.v04.product_binding import declared_product_name
from test_main_legacy_binding_guard import prepared
from test_unified_main import setup as setup, scope


@pytest.mark.asyncio
@pytest.mark.parametrize("question", [
    "Trà Sen Tây Hồ muốn đi Mỹ cần nhãn như thế nào?",
    "Chị có sản phẩm Trà Sen Tây Hồ muốn đi Mỹ cần nhãn như thế nào?",
])
async def test_want_to_export_does_not_invent_a_name_or_legacy_mismatch(setup, question):
    assert declared_product_name(question) == "Trà Sen Tây Hồ"
    repo, owner, model, missions, mid, raw = await prepared(setup, question)
    before = len(model.calls)
    current = missions.get(*scope(owner), mid)
    assert not current.get("binding_warning")
    assert current["status"] == "planned"
    assert len(model.calls) == before
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mid,)).fetchone()[0] == raw


@pytest.mark.asyncio
async def test_distinct_product_suffix_still_requires_confirmation(setup):
    question = "Trà Sen Tây Hồ Cao Cấp muốn đi Mỹ cần nhãn như thế nào?"
    assert declared_product_name(question) == "Trà Sen Tây Hồ Cao Cấp"
    _repo, owner, model, missions, mid, _raw = await prepared(setup, question)
    before = len(model.calls)
    current = missions.get(*scope(owner), mid)
    assert current["binding_warning"]["declared_name"] == "Trà Sen Tây Hồ Cao Cấp"
    assert current["status"] == "needs_product_confirmation"
    assert len(model.calls) == before
