"""A real paid intake demoted explicit FDA/label questions to clarification.

The recorded response below is replayed only by injected local callbacks.
"""
from copy import deepcopy

import pytest

from nmate.v03.live_review import interpret_validated_intake, validate_intake
from nmate.v03.research_scope import explicit_requested_outcomes
from test_v03_live_review import setup as shared_setup


QUESTION = ("Chị có Trà Sen Tây Hồ, hộp 100 g, mã TS01, muốn xuất khẩu sang Mỹ. "
            "Cơ sở sản xuất của chị có phải đăng ký FDA không, nhãn cần những nội dung gì? "
            "Hãy nêu ba việc đầu tiên chị cần làm, dựa trên nguồn chính thức và chỉ rõ phần nào còn thiếu thông tin.")
RECORDED = {"scope": "us_food", "outcomes": [{"id": "clarification", "question_quote": "Cơ sở sản xuất của chị có phải đăng ký FDA không, nhãn cần những nội dung gì?"}],
    "product_name": "Trà Sen Tây Hồ", "product_quote": "Trà Sen Tây Hồ", "ambiguities": [
        "Chưa rõ cơ sở sản xuất có nằm ở Việt Nam hay không, và có sản xuất, chế biến, đóng gói hay lưu giữ thực phẩm hay không.",
        "Chưa rõ nhãn dành cho bao bì bán lẻ hay cho kênh bán khác, và nhãn đã có nội dung tiếng Anh chưa.",
        "Chưa có thông tin về công thức chi tiết, phụ gia, chất gây dị ứng hoặc tuyên bố trên nhãn để rà soát nhãn.",
        "Chưa rõ người dùng có hỏi thêm về Prior Notice hay không; câu hỏi hiện tại không nêu."]}


@pytest.fixture(name="workspace")
def workspace_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


def test_exact_recorded_clarification_is_not_allowed_to_remove_explicit_requested_work():
    original = deepcopy(RECORDED)
    parsed = validate_intake({"data": original}, QUESTION, "US")
    intent, name = interpret_validated_intake(parsed, QUESTION, "US")
    assert {outcome.id for outcome in intent.outcomes} == {"registration", "label"}
    assert set(intent.server_recovered_outcomes) == {"registration", "label"}
    assert all(outcome.question_part in QUESTION for outcome in intent.outcomes)
    assert intent.ambiguities == intent.clarification_requests == []
    assert intent.preliminary_information_gaps == RECORDED["ambiguities"]
    assert intent.requested_action_count == 3 and name == "Trà Sen Tây Hồ"
    assert "prior_notice" not in {outcome.id for outcome in intent.outcomes}
    assert original == RECORDED == parsed.model_dump()


@pytest.mark.asyncio
async def test_future_schema_and_execution_are_bound_to_clear_server_outcomes_even_with_old_bad_reply(workspace):
    repo, owner, _, model, service = workspace
    model.intake_transform = lambda _: deepcopy(RECORDED)
    planned = await service.prepare_async(owner["account_id"], owner["enterprise_id"], QUESTION, "explicit-request", market_code="US")
    assert planned["status"] == "planned"
    assert {outcome["id"] for outcome in planned["intent"]["outcomes"]} == {"registration", "label"}
    assert planned["research_scope"]["can_start_research"]
    schema = model.calls[0][1]["response_schema"]
    assert set(schema["$defs"]["IntakeOutcome"]["properties"]["id"]["enum"]) == {"registration", "label"}
    assert schema["properties"]["outcomes"]["minItems"] == schema["properties"]["outcomes"]["maxItems"] == 2
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_review_outputs WHERE mission_id=? AND kind='research'", (planned["id"],)).fetchone()[0] == 0
    assert len(model.calls) == 1


@pytest.mark.parametrize("question,expected", [
    ("Tôi có Trà Sen Tây Hồ đi Mỹ, chưa biết muốn app giúp việc gì.", set()),
    ("Nhãn đã xong; tôi chỉ hỏi ai nộp thông báo trước và khi nào ở Mỹ.", {"prior_notice"}),
    ("Tôi không cần nhãn; tôi hỏi đăng ký cơ sở ở Mỹ.", {"registration"}),
    ("FDA là gì?", set()),
    ("Ba việc đầu tiên cho lô hàng sang Mỹ là gì?", set()),
])
def test_server_binding_does_not_invent_tasks_from_negated_resolved_or_vague_mentions(question, expected):
    data = {"scope": "us_food", "outcomes": [{"id": "clarification", "question_quote": question}],
            "product_name": None, "product_quote": None, "ambiguities": ["Chưa rõ mục tiêu."]}
    parsed = validate_intake({"data": data}, question, "US")
    intent, _ = interpret_validated_intake(parsed, question, "US")
    assert {outcome.id for outcome in intent.outcomes} - {"clarification"} == expected
    assert bool(intent.ambiguities) == (not expected)


@pytest.mark.parametrize("question,expected", [
    ("Cơ sở chị sản xuất tại Hà Nội. Chị hỏi nhãn tiếng Anh cần nội dung gì khi đi Mỹ?", {"label"}),
    ("Bao bì hiện tại là hộp giấy. Chị hỏi ai nộp prior notice khi gửi Mứt Sen đi Mỹ?", {"prior_notice"}),
    ("Cơ sở chị sản xuất tại Hà Nội, chị hỏi nhãn tiếng Anh cần nội dung gì khi đi Mỹ?", {"label"}),
    ("Bao bì hiện tại là hộp giấy, chị hỏi ai nộp prior notice khi gửi Mứt Sen đi Mỹ?", {"prior_notice"}),
    ("Cơ sở đã đăng ký FDA và chị hỏi nhãn cần nội dung gì khi đi Mỹ?", {"label"}),
    ("Nhãn hiện tại đã đủ tiếng Anh, chị hỏi ai nộp prior notice khi đi Mỹ?", {"prior_notice"}),
    ("Chị cần tìm hiểu đăng ký cơ sở FDA và nhãn khi đi Mỹ.", {"registration", "label"}),
    ("Cơ sở có phải đăng ký FDA không, nhãn cần nội dung gì khi đi Mỹ?", {"registration", "label"}),
    ("Cơ sở sản xuất tại Hà Nội. Bao bì hiện tại là hộp giấy.", set()),
    ("Đăng ký cơ sở FDA và nhãn cho Mỹ", {"registration", "label"}),
])
def test_mandatory_tasks_come_only_from_positive_request_clauses(question, expected):
    assert set(explicit_requested_outcomes(question, "US")) == expected
    raw = {"scope": "us_food", "outcomes": [{"id": "clarification", "question_quote": question}],
           "product_name": None, "product_quote": None, "ambiguities": ["Mục tiêu do mô hình hỏi lại."]}
    projected, _ = interpret_validated_intake(validate_intake({"data": raw}, question, "US"), question, "US")
    assert set(projected.server_recovered_outcomes) == expected


def test_model_background_candidate_cannot_expand_the_explicit_paid_research_scope():
    question = "Cơ sở chị sản xuất tại Hà Nội. Chị hỏi nhãn tiếng Anh cần nội dung gì khi đi Mỹ?"
    raw = {"scope": "us_food", "outcomes": [
        {"id": "registration", "question_quote": "Cơ sở chị sản xuất tại Hà Nội"},
        {"id": "label", "question_quote": "Chị hỏi nhãn tiếng Anh cần nội dung gì khi đi Mỹ?"}],
        "product_name": None, "product_quote": None, "ambiguities": []}
    original = deepcopy(raw)
    projected, _ = interpret_validated_intake(validate_intake({"data": raw}, question, "US"), question, "US")
    assert [outcome.id for outcome in projected.outcomes] == ["label"]
    assert projected.model_unrequested_outcomes == ["registration"]
    assert projected.clarification_requests == []
    assert raw == original
