"""M2 TDD: offline public fixtures, no HTTP/provider/MAIN."""
import hashlib
import json
from pathlib import Path
import pytest

from test_knowledge_m1 import kb
from nmate.v03.core import CoreError
from nmate.knowledge_v1.pipeline import PipelineService
from nmate.knowledge_v1.operator_m2 import install_m2_on_clone


@pytest.fixture
def pipe(kb, tmp_path):
    repo, _, actor, other, ref = kb
    install_m2_on_clone(repo.db_path, backup_path=tmp_path / 'before-m2.sqlite')
    service = PipelineService(repo)
    service.configure_source(actor, 'KB-TEST-A', expected_version=0, operation_id='config-1',
        manifest={'url': 'https://hanoi.gov.vn/test-only/kb-a', 'mime_type': 'text/plain',
            'language': 'vi', 'operator': 'TEST ONLY', 'document_role': 'fixture',
            'rights_basis': 'synthetic public fixture', 'required_parts': ['body', 'annex'],
            'gaps': ['annex'], 'network_enabled': False})
    return repo, service, actor, other


def acquire(pipe, raw=b'TEST ONLY Training for enterprises.', operation='acq-1', version=1,
            filename='training.txt', mime='text/plain'):
    _, s, actor, _ = pipe
    return s.acquire_bytes(actor, 'KB-TEST-A', expected_version=version, filename=filename,
                           mime_type=mime, raw=raw, operation_id=operation)


def extracted(pipe, **kwargs):
    a = acquire(pipe, **kwargs)
    return pipe[1].extract_local(pipe[2], a['rendition_id'], operation_id='parse-'+a['rendition_id'])


def candidate(pipe):
    _, s, actor, _ = pipe
    ex = extracted(pipe)
    ref = s.pipeline_evidence(actor, ex['chunks'][0]['id'], 'Training for enterprises.')
    body = '# Training\n\nTraining for enterprises.\n'
    claim = {'kind':'source_excerpt', 'start':12, 'end':37,
             'text':'Training for enterprises.', 'evidence':[ref]}
    p = s.create_candidate(actor, policy_id='TEST-POLICY', title='Training', body=body,
        claims=[claim], aliases=['dao tao nhan vien'], links=[], operation_id='candidate-1')
    return p


def test_two_uow_bytes_retained_before_parse_and_exact_recovery(pipe):
    repo, s, actor, _ = pipe
    a = acquire(pipe)
    with repo.connection() as db:
        assert db.execute('SELECT raw_bytes FROM kp_renditions WHERE id=?',(a['rendition_id'],)).fetchone()[0] == b'TEST ONLY Training for enterprises.'
        assert db.execute('SELECT count(*) FROM kp_extractions').fetchone()[0] == 0
    ex = s.extract_local(actor, a['rendition_id'], operation_id='parse-1')
    assert ex['quality'] == 'text_extracted'
    assert ex['chunks'][0]['text'] == 'TEST ONLY Training for enterprises.'
    assert s.extract_local(actor, a['rendition_id'], operation_id='parse-1') == ex
    assert acquire(pipe) == a


def test_candidate_has_exact_claim_body_bindings_and_no_publication(pipe):
    p = candidate(pipe)
    read = pipe[1].get_candidate(pipe[2], p['page_id'])
    assert read['claims'][0]['text'] == 'Training for enterprises.'
    assert read['assessment_eligible'] is False
    assert read['publication_state'] == 'not_published'
    assert read['freshness']['decision'] == 'source_incomplete'
    assert read['freshness']['schema_version']=='policy-freshness-decision/1'
    with pytest.raises(CoreError):
        pipe[1].get_candidate(pipe[3], p['page_id'])


@pytest.mark.parametrize('change',['quote','span','missing_section','private','unknown_kind'])
def test_candidate_coverage_rejects_malformed_binding(pipe, change):
    _, s, actor, _ = pipe
    ex=extracted(pipe)
    ref=s.pipeline_evidence(actor, ex['chunks'][0]['id'], 'Training for enterprises.')
    body='Training for enterprises.'
    claims=[{'kind':'source_excerpt','start':0,'end':len(body),'text':body,'evidence':[ref]}]
    if change=='quote': ref['quote_hash']='0'*64
    if change=='span': claims[0]['start']=1
    if change=='missing_section': body+='\nUnsupported extra conclusion.'
    if change=='private': ref['kind']='private_file'
    if change=='unknown_kind': claims[0]['kind']='legal_rule'
    with pytest.raises(CoreError):
        s.create_candidate(actor,policy_id='TEST',title='TEST',body=body,claims=claims,
                            aliases=[],links=[],operation_id='bad-claim')


@pytest.mark.parametrize('point',['before_acquire_receipt','before_extract_commit'])
def test_crash_rolls_back_respective_unit_not_prior_bytes(pipe, point):
    repo,s,actor,_=pipe
    a=acquire(pipe) if point=='before_extract_commit' else None
    with repo.connection() as db: before=list(db.iterdump())
    def crash(p):
        if p==point: raise RuntimeError('TEST crash')
    s.fault_hook=crash
    with pytest.raises(RuntimeError):
        if a: s.extract_local(actor,a['rendition_id'],operation_id='parse-crash')
        else: acquire(pipe)
    s.fault_hook=None
    with repo.connection() as db: assert list(db.iterdump())==before


def test_source_changed_before_parse_does_not_promote_old_rendition(pipe):
    _,s,actor,_=pipe
    old=acquire(pipe)
    acquire(pipe,b'TEST ONLY New training rule.',operation='acq-new',version=2)
    ex=s.extract_local(actor,old['rendition_id'],operation_id='old-parse')
    assert ex['is_current'] is False


def test_source_change_invalidates_candidate_even_before_projection(pipe):
    p=candidate(pipe)
    acquire(pipe,b'TEST ONLY Different source.',operation='acq-2',version=2)
    read=pipe[1].get_candidate(pipe[2],p['page_id'])
    assert read['freshness']['decision']=='changed_needs_review'
    assert read['assessment_eligible'] is False


def test_projection_search_alias_and_rebuild_no_authority(pipe,tmp_path):
    repo,s,actor,_=pipe
    p=candidate(pipe)
    s.materialize(actor,p['page_id'],root=tmp_path/'wiki')
    assert s.search(actor,'đào tạo nhân viên')[0]['page_id']==p['page_id']
    path=tmp_path/'wiki'/(p['page_id']+'.md')
    assert 'Training for enterprises.' in path.read_text('utf-8')
    path.write_text('HAND EDIT DOES NOT CHANGE SQL',encoding='utf-8')
    s.materialize(actor,p['page_id'],root=tmp_path/'wiki')
    assert 'HAND EDIT' not in path.read_text('utf-8')
    with repo.connection(write=True) as db: db.execute('DELETE FROM kp_search_documents')
    assert s.search(actor,'Training')==[]
    s.materialize(actor,p['page_id'],root=tmp_path/'wiki')
    assert s.search(actor,'Training')


def test_revoke_blocks_all_derivatives_and_exact_receipts(pipe,tmp_path):
    _,s,actor,_=pipe
    p=candidate(pipe)
    s.materialize(actor,p['page_id'],root=tmp_path/'wiki')
    s.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,
                        reason='TEST revoke',operation_id='revoke')
    assert s.search(actor,'Training')==[]
    for read in [lambda:s.get_candidate(actor,p['page_id']),lambda:candidate(pipe),
                 lambda:s.export_markdown(actor,p['page_id'])]:
        with pytest.raises(CoreError): read()
    s.reconcile_exports(actor,root=tmp_path/'wiki')
    assert not (tmp_path/'wiki'/(p['page_id']+'.md')).exists()


def test_invalid_pdf_preserves_bytes_and_identifies_filename(pipe):
    repo,s,actor,_=pipe
    # Another representation is deliberately allowed only by a new manifest.
    s.configure_source(actor,'KB-TEST-A',expected_version=1,operation_id='pdf-config',
        manifest={**s.source_manifest(actor,'KB-TEST-A')['manifest'],'mime_type':'application/pdf'})
    a=acquire(pipe,b'PK\x03\x04not-pdf',version=2,filename='broken-attachment.pdf',mime='application/pdf')
    ex=s.extract_local(actor,a['rendition_id'],operation_id='broken-parse')
    assert ex['quality']=='failed'
    assert ex['error_code']=='invalid_pdf'
    assert ex['filename']=='broken-attachment.pdf'
    assert ex['chunks']==[]


def test_raw_tampering_cannot_be_extracted_or_replayed(pipe):
    repo,s,actor,_=pipe
    a=acquire(pipe)
    with repo.connection(write=True) as db:
        guard=db.execute("SELECT sql FROM sqlite_master WHERE name='kp_renditions_immutable'").fetchone()[0]
        db.execute('DROP TRIGGER kp_renditions_immutable')
        db.execute("UPDATE kp_renditions SET raw_bytes=x'4142'")
        db.execute(guard)
    with pytest.raises(CoreError): s.extract_local(actor,a['rendition_id'],operation_id='damaged')
    with pytest.raises(CoreError): acquire(pipe)


def test_repeated_quote_requires_explicit_span(pipe):
    _,s,actor,_=pipe
    ex=extracted(pipe,raw=b'Alpha Alpha')
    with pytest.raises(CoreError): s.pipeline_evidence(actor,ex['chunks'][0]['id'],'Alpha')
    ref=s.pipeline_evidence(actor,ex['chunks'][0]['id'],'Alpha',quote_start=6)
    assert ref['quote_start']==6 and ref['quote_end']==11


def test_missing_state_cannot_bootstrap_over_committed_source_history(pipe):
    repo,s,actor,_=pipe
    manifest=s.source_manifest(actor,'KB-TEST-A')['manifest']
    with repo.connection(write=True) as db: db.execute("DELETE FROM kp_source_state WHERE source_id='KB-TEST-A'")
    with pytest.raises(CoreError):
        s.configure_source(actor,'KB-TEST-A',expected_version=0,manifest=manifest,operation_id='reset-history')


def test_edit_candidate_cas_and_keeps_old_body_bindings(pipe):
    p=candidate(pipe); _,s,actor,_=pipe
    new=s.edit_candidate(actor,p['page_id'],expected_version=1,expected_revision_id=p['revision_id'],
        title='Updated title',body=p['body'],claims=p['claims'],aliases=['employee training'],links=[],operation_id='edit-candidate')
    assert new['version']==2
    assert s.get_candidate(actor,p['page_id'],revision_id=p['revision_id'])['title']=='Training'
    with pytest.raises(CoreError):
        s.edit_candidate(actor,p['page_id'],expected_version=True,expected_revision_id=new['revision_id'],
            title='Bad',body=p['body'],claims=p['claims'],aliases=[],links=[],operation_id='edit-bad')


def test_parser_revoke_cannot_commit_chunks(pipe):
    repo,s,actor,_=pipe; a=acquire(pipe)
    parser=s.parser
    def revoked(raw,mime,filename):
        result=parser(raw,mime,filename)
        s.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,reason='Revoke during parse',operation_id='during-parse')
        return result
    s.parser=revoked
    with pytest.raises(CoreError): s.extract_local(actor,a['rendition_id'],operation_id='revoked-parse')
    with repo.connection() as db: assert db.execute('SELECT count(*) FROM kp_extractions').fetchone()[0]==0


def test_after_commit_recovery_never_parses_twice(pipe):
    _,s,actor,_=pipe; a=acquire(pipe)
    def crash(point):
        if point=='after_extract_commit': raise RuntimeError('lost response')
    s.fault_hook=crash
    with pytest.raises(RuntimeError): s.extract_local(actor,a['rendition_id'],operation_id='lost-parse')
    s.fault_hook=None
    def forbidden(*a): pytest.fail('Replay cannot parse')
    s.parser=forbidden
    assert s.extract_local(actor,a['rendition_id'],operation_id='lost-parse')['chunks']


def test_file_crash_rebuild_and_export_deny_independent_from_read(pipe,tmp_path):
    _,s,actor,_=pipe; p=candidate(pipe)
    def crash(point):
        if point=='after_projection_replace': raise RuntimeError('file replaced, DB ack missing')
    s.fault_hook=crash
    with pytest.raises(RuntimeError): s.materialize(actor,p['page_id'],root=tmp_path/'projection')
    s.fault_hook=None
    s.materialize(actor,p['page_id'],root=tmp_path/'projection')
    s.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=True,allow_export=False,reason='No export',operation_id='export-deny')
    assert s.get_candidate(actor,p['page_id'])['body']
    with pytest.raises(CoreError): s.export_markdown(actor,p['page_id'])


def test_html_links_and_error_login_are_not_complete():
    from nmate.knowledge_v1.local_parser import parse_local
    html=b'<html><body><p>TEST ONLY training</p><a href="annex.pdf">Annex</a></body></html>'
    p=parse_local(html,'text/html','test.html')
    assert p['quality']=='source_incomplete' and p['gaps']==['linked_attachment_unread:annex.pdf']
    error=b'<html><body>Access denied. Please log in.</body></html>'
    p=parse_local(error,'text/html','blocked.html')
    assert p['quality']=='failed' and not p['chunks']


@pytest.mark.parametrize('html',[
    '<html><title>Sign in</title><body>Please sign in to continue</body></html>',
    '<html><title>Đăng nhập</title><body>Nhập tài khoản</body></html>',
    '<html><body><form action="/authenticate"><input type="password"></form></body></html>',
    '<html><title>403 Forbidden</title><body>Denied</body></html>',
])
def test_html_admission_is_separate_from_text_readability(html):
    from nmate.knowledge_v1.local_parser import parse_local
    result=parse_local(html.encode(),'text/html','portal.html')
    assert result['admission']['state']=='rejected'
    assert result['quality']=='failed' and not result['chunks']


def test_html_public_document_navigation_login_does_not_imply_auth_wall():
    from nmate.knowledge_v1.local_parser import parse_local
    raw=b'<html><title>Public notice</title><body><a href="/login">Sign in</a><p>TEST ONLY public training source</p></body></html>'
    result=parse_local(raw,'text/html','public.html')
    assert result['admission']['state']=='candidate_unverified'
    assert result['quality']=='text_extracted'


def test_outbox_drains_repeated_delivery_currenthead_and_revoke(pipe,tmp_path):
    repo,s,actor,_=pipe; p=candidate(pipe)
    result=s.drain_outbox(actor,root=tmp_path/'outbox-wiki')
    assert result['delivered_event_ids']
    assert s.search(actor,'Training')
    with repo.connection() as db: assert db.execute("SELECT count(*) FROM kp_pipeline_outbox WHERE delivery_state='pending'").fetchone()[0]==0
    assert s.drain_outbox(actor,root=tmp_path/'outbox-wiki')['delivered_event_ids']==[]
    s.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,reason='Revoked',operation_id='outbox-revoke')
    assert not s.search(actor,'Training')
    s.drain_outbox(actor,root=tmp_path/'outbox-wiki')
    assert not (tmp_path/'outbox-wiki'/(p['page_id']+'.md')).exists()


def test_denied_materializer_does_not_create_folder(pipe,tmp_path):
    _,s,_,other=pipe
    for action in (lambda:s.reconcile_exports(other,root=tmp_path/'unauthorized'),lambda:s.drain_outbox(other,root=tmp_path/'unauthorized')):
        with pytest.raises(CoreError): action()
        assert not (tmp_path/'unauthorized').exists()


def test_source_diff_preserves_added_exception_and_old_quote(pipe):
    _,s,actor,_=pipe; old=extracted(pipe)
    a=acquire(pipe,b'TEST ONLY Training for enterprises.\nExcept category X.',operation='new-exception',version=2)
    new=s.extract_local(actor,a['rendition_id'],operation_id='new-exception-extract')
    diff=s.source_diff(actor,old['extraction_id'],new['extraction_id'])
    assert diff['raw_changed'] and diff['text_changed'] and '+Except category X.' in diff['diff']


def test_m1_content_writer_cannot_drop_m2_binding_contract(pipe):
    _,s,actor,_=pipe; p=candidate(pipe)
    from nmate.knowledge_v1.service import KnowledgeService
    bare=KnowledgeService(s.repo)
    with pytest.raises(CoreError):
        bare.edit_page(actor,p['page_id'],expected_revision_id=p['revision_id'],expected_version=1,
            title='M1 bypass',body=p['body'],evidence=p['evidence'],operation_id='bypass-edit')
    assert s.get_candidate(actor,p['page_id'])['version']==1


def test_m1_reader_cannot_skip_candidate_binding_integrity(pipe):
    repo,s,actor,_=pipe; p=candidate(pipe)
    from nmate.knowledge_v1.service import KnowledgeService
    with repo.connection(write=True) as db:
        guard=db.execute("SELECT sql FROM sqlite_master WHERE name='kp_candidate_bindings_immutable'").fetchone()[0]
        db.execute('DROP TRIGGER kp_candidate_bindings_immutable')
        db.execute("UPDATE kp_candidate_bindings SET content_hash='damaged'")
        db.execute(guard)
    with pytest.raises(CoreError): KnowledgeService(repo).get_page(actor,p['page_id'])


@pytest.mark.parametrize('locator',[
    {'kind':'extracted_text_span','start':10,'end':-1},
    {'kind':'extracted_text_span','start':0,'end':99999999},
    {'kind':'pdf_page','page':-1},
    {'kind':'unknown','private_path':'C:/not-an-allowed-path'},
])
def test_locator_validation_with_complete_admission_contract(pipe,locator):
    repo,s,actor,_=pipe; a=acquire(pipe)
    def parser(*args):
        return {'quality':'text_extracted','error_code':None,'gaps':[],
                'chunks':[{'text':'TEST','locator':locator}],
                'admission':{'state':'candidate_unverified','reason_codes':['local_document_only_no_legal_verification']}}
    s.parser=parser
    with repo.connection() as db: before=list(db.iterdump())
    with pytest.raises(CoreError): s.extract_local(actor,a['rendition_id'],operation_id='invalid-locator')
    with repo.connection() as db: assert list(db.iterdump())==before


def test_quality_ready_requires_chunks_even_with_valid_admission(pipe):
    repo,s,actor,_=pipe; a=acquire(pipe)
    s.parser=lambda *_args:{'quality':'text_extracted','error_code':None,'gaps':[],'chunks':[],
                            'admission':{'state':'candidate_unverified','reason_codes':['local_document_only_no_legal_verification']}}
    with repo.connection() as db: before=list(db.iterdump())
    with pytest.raises(CoreError): s.extract_local(actor,a['rendition_id'],operation_id='empty-ready')
    with repo.connection() as db: assert list(db.iterdump())==before


def test_projection_cleanup_preserves_unregistered_hand_authored_file(pipe,tmp_path):
    _,s,actor,_=pipe; p=candidate(pipe)
    root=tmp_path/'wiki'
    s.materialize(actor,p['page_id'],root=root)
    manual=root/'operator-notes.md'; manual.write_text('Operator notes',encoding='utf-8')
    s.reconcile_exports(actor,root=root)
    assert manual.read_text('utf-8')=='Operator notes'


def test_navigation_cycle_is_bounded_not_recursive_legal_authority(pipe):
    _,s,actor,_=pipe; first=candidate(pipe)
    second=s.create_candidate(actor,policy_id='TEST-OTHER',title='Second',body=first['body'],claims=first['claims'],
        aliases=[],links=[{'relation':'see_also','page_id':first['page_id'],'revision_id':first['revision_id']}],operation_id='second')
    s.edit_candidate(actor,first['page_id'],expected_version=1,expected_revision_id=first['revision_id'],title=first['title'],
        body=first['body'],claims=first['claims'],aliases=[],links=[{'relation':'related_topic','page_id':second['page_id'],'revision_id':second['revision_id']}],operation_id='cycle')
    assert s.get_candidate(actor,first['page_id'])['assessment_eligible'] is False
    assert s.backlinks(actor,first['page_id'])[0]['page_id']==second['page_id']
