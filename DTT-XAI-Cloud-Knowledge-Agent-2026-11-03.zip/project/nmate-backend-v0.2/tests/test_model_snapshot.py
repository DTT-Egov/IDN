import pytest

from nmate.models import AppError, CaseCreate, Principal
from nmate.store import Store


def test_model_choice_is_persisted_and_idempotency_does_not_silently_switch_model(tmp_path):
    store = Store(tmp_path / "business.sqlite3")
    p = Principal("company-a", "person-a")
    data = CaseCreate(product={"sku": "TEST", "name": "TEST"}, consent_research=True, consent_model=True)
    case = store.create_case(p, data.model_dump(mode="json"))
    args = {"case_id": case["case_id"], "expected_case_version": 1,
            "idempotency_key": "pinned-model-test", "question": "TEST"}
    kwargs = {"mode": "llm", "max_active": 5, "max_daily": 30}
    original = store.start(p, args, model_name="model-a", **kwargs)
    reopened = Store(tmp_path / "business.sqlite3")
    assert reopened.get_run(p, original["run_id"])["model_name"] == "model-a"
    with pytest.raises(AppError) as caught:
        reopened.start(p, args, model_name="model-b", **kwargs)
    assert caught.value.code == "IDEMPOTENCY_CONFLICT"
