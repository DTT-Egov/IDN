"""Replace the SDK client entirely: verify actual dispatch arguments, zero IO."""
from types import SimpleNamespace

import pytest

from nmate.main.provider import MainProvider
from nmate.v03.core import CoreRepository
from nmate.v03.live_provider import ReviewProvider
from nmate.v03.live_review import ResearchOutput


@pytest.mark.asyncio
@pytest.mark.parametrize("provider_class", [ReviewProvider, MainProvider])
async def test_actual_sdk_boundary_has_closed_field_enums_structured_output_and_no_retries(tmp_path, monkeypatch, provider_class):
    import anthropic
    import httpx2
    observed = {}

    class FakeHttp:
        def __init__(self, **kwargs):
            observed["http"] = kwargs
        async def __aenter__(self):
            return self
        async def __aexit__(self, *_):
            pass

    class FakeClient:
        def __init__(self, **kwargs):
            observed["client"] = kwargs
            self.messages = self
        async def __aenter__(self):
            return self
        async def __aexit__(self, *_):
            pass
        async def create(self, **kwargs):
            observed["request"] = kwargs
            return SimpleNamespace(content=[SimpleNamespace(type="text", text='{"answers":[],"actions":[]}')],
                                   model=kwargs["model"], _request_id="sdk-contract-no-network", stop_reason="end_turn",
                                   usage=SimpleNamespace(model_dump=lambda **_: {"input_tokens": 0, "output_tokens": 0}))

    monkeypatch.setattr(httpx2, "AsyncClient", FakeHttp)
    monkeypatch.setattr(anthropic, "AsyncAnthropic", FakeClient)
    provider = provider_class(CoreRepository(tmp_path / "sdk.sqlite3"), api_key="unit-test-placeholder")
    schema = ResearchOutput.model_json_schema()
    schema["$defs"]["ResearchAnswer"]["properties"]["missing_fields"]["items"] = {"type": "string", "enum": ["english_name"]}
    schema["$defs"]["Citation"]["properties"]["source_id"]["enum"] = ["OFFICIAL_EXACT_EXCERPT"]
    await provider._request(provider.complex_model, {"response_schema": schema, "input": {}, "instructions_vi": "Kiểm tra hợp đồng.", "complexity": "complex"}, 5000)
    assert observed["client"]["max_retries"] == 0
    assert observed["http"]["trust_env"] is False
    output = observed["request"]["output_config"]["format"]
    assert output["type"] == "json_schema"
    definitions = output["schema"]["$defs"]
    assert definitions["ResearchAnswer"]["properties"]["missing_fields"]["items"]["enum"] == ["english_name"]
    assert definitions["Citation"]["properties"]["source_id"]["enum"] == ["OFFICIAL_EXACT_EXCERPT"]
