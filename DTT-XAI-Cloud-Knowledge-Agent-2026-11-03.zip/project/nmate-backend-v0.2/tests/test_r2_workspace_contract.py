"""DF-010/014/016/032/036/046: same current scope through partial/reload/replay."""
import copy
from itertools import permutations
import socket

import pytest

from nmate.core_v1.workspace_contract import resource_workspace_contract
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.intake import IntakeService
from test_review_architecture_acceptance import TEXT, confirm, pending_fields
from test_review_commands_v2 import data_snapshot


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('Workspace projection must not call provider/network')
    monkeypatch.setattr(socket.socket, 'connect', denied)
    monkeypatch.setattr(socket.socket, 'connect_ex', denied)


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / 'r2-workspace.sqlite3')
    accounts = LocalAccounts(repo)
    owner = accounts.register('r2-owner', 'Only-local-test-password', 'Trà Sen QA')
    other = accounts.register('r2-other', 'Only-local-test-password', 'Doanh nghiệp khác')
    service = IntakeService(repo)
    intake = service.prepare(owner['account_id'], owner['enterprise_id'], TEXT, [], 'r2-workspace-prepare')
    return repo, owner, other, service, intake


def project(setup, value=None, *, kind='intake', chat=None):
    repo, owner, _, _, intake = setup
    with repo.connection() as db:
        return resource_workspace_contract(repo, owner['account_id'], owner['enterprise_id'],
                                           value or intake, db, kind=kind, conversation=chat)


@pytest.mark.parametrize('order', list(permutations(('packaging', 'ingredients', 'net_quantity'))))
def test_partial_confirm_each_order_reload_and_replay_keeps_remainder_and_target(setup, order):
    repo, owner, _, service, intake = setup
    before_fields = pending_fields(intake)
    intake = confirm(service, owner, intake, ['trading_name'], 'r2-enterprise-name-first')
    intake = confirm(service, owner, intake, ['name', 'product_code'], 'r2-product-name-and-code')
    before_fields -= {'trading_name', 'name', 'product_code'}
    bound_product = intake['product']['id']
    for index, field in enumerate(order):
        result = confirm(service, owner, intake, [field], f'r2-sequence-{index}')
        before_read = data_snapshot(repo)
        service = IntakeService(CoreRepository(repo.db_path))
        intake = service.get(owner['account_id'], owner['enterprise_id'], intake['id'])
        contract = intake['workspace_contract']
        assert contract['schema_version'] == 'workspace-contract/1'
        assert contract['review']['pending_count'] == len(before_fields) - index - 1
        assert pending_fields(intake) == before_fields - set(order[:index+1])
        assert contract['revisions']['workspace'] == result['review']['revision']
        assert contract['billing']['projection_model_calls'] == 0
        assert intake['product']['id'] == bound_product
        assert data_snapshot(repo) == before_read
    assert pending_fields(intake) == set()
    assert contract['primary_action']['kind'] == 'continue_chat'
    assert contract['allowed_actions'] == []


def test_read_contract_is_detached_and_keeps_historical_context_separate(setup):
    repo, owner, _, service, intake = setup
    result = confirm(service, owner, intake, ['name', 'product_code'], 'r2-contract-confirm')
    historical = copy.deepcopy(result['saved_context'])
    product = next(e for e in historical['entities'] if e['entity_type'] == 'product')
    repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], product['id'],
        [{'field': 'ingredients', 'value': 'Trà xanh và hoa sen'}], product['version'], 'r2-later-owner-edit')
    before = data_snapshot(repo)
    view = project(setup, result)
    assert view['revisions']['context'] > view['revisions']['saved_context']
    assert result['saved_context'] == historical
    assert view['field_registry']['version'].startswith('ssot-field-registry/')
    view['scope']['entity_ids'].clear()
    view['intent_plan']['intent']['goals'].clear()
    assert result['saved_context'] == historical and data_snapshot(repo) == before


@pytest.mark.parametrize('kind', ['intake', 'policy', 'research'])
def test_error_and_pending_marker_do_not_create_contradictory_processing(setup, kind):
    resource = copy.deepcopy(setup[-1])
    resource['status'] = 'running'
    before = data_snapshot(setup[0])
    view = project(setup, resource, kind=kind, chat={'id': 'chat-a', 'pending_operation_id': 'op-old',
        'operation_error': {'operation_id': 'op-old', 'code': 'INTERRUPTED'}})
    assert view['operation']['state'] == 'failed'
    assert view['operation']['processing'] is False
    assert view['primary_action']['kind'] == 'read_error'
    assert data_snapshot(setup[0]) == before


@pytest.mark.parametrize('key', ['owner_id', 'enterprise_id'])
def test_contract_rejects_cross_scope_before_projection(setup, key):
    resource = copy.deepcopy(setup[-1])
    resource[key] = setup[2]['account_id' if key == 'owner_id' else 'enterprise_id']
    before = data_snapshot(setup[0])
    with pytest.raises(CoreError) as error:
        project(setup, resource)
    assert error.value.code == 'forbidden'
    assert data_snapshot(setup[0]) == before


def test_historical_receipt_does_not_claim_current_operation_succeeded(setup):
    result = confirm(setup[3], setup[1], setup[-1], ['name'], 'r2-history-receipt')
    view = project(setup, result)
    assert view['receipt_ref'] == result['latest_confirmation_receipt']['receipt_id']
    assert view['operation']['state'] == 'idle'
    assert view['review']['pending_count'] > 0
    assert view['primary_action']['kind'] == 'review_pending'


@pytest.mark.parametrize('chat', [
    {'id': 'chat-a', 'pending_operation_id': 'op-a'},
    {'id': 'chat-a', 'pending_operation_id': 'op-a', 'operation_error': {'operation_id': 'op-a', 'code': 'INTERRUPTED'}},
])
def test_legacy_review_adapter_and_common_contract_have_same_current_action(setup, chat):
    from nmate.main.workspace_view import intake_workspace_view
    repo, owner, _, _, intake = setup
    with repo.connection() as db:
        legacy = intake_workspace_view(repo, owner['account_id'], owner['enterprise_id'], intake, db, chat)
    current = project(setup, chat=chat)
    assert legacy['primary_action'] == current['primary_action']
    assert legacy['allowed_actions'] == current['allowed_actions']
