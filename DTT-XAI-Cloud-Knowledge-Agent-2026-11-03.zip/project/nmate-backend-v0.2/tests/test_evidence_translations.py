"""Vietnamese derived text: exact references, immutable originals, one model call."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import socket

from langgraph.checkpoint.memory import InMemorySaver
import pytest

from nmate.agents.shipment.graph import ModelSynthesis, build_graph
from nmate.agents.shipment.models import (
    Evidence, EvidenceTranslationDraft, ShipmentReport, ShipmentWorkflowError,
    SourceBatch, SourceDocument,
)
from nmate.agents.shipment.translations import (
    REFERENCE_CATALOG, apply_model_translations, attach_reference_translation,
    evidence_display_translations, excerpt_sha256,
)

ORIGINAL_FIELDS = ("id", "url", "title", "publisher", "accessed_at", "source_date",
                   "content_sha256", "excerpt", "locator", "review_status")


def original_evidence(reference=None):
    reference = reference or next(iter(REFERENCE_CATALOG.values()))
    return Evidence(
        id="MOCK-EVIDENCE", url=reference.url, title=reference.title, publisher=reference.publisher,
        accessed_at="2026-10-17T10:00:00Z", content_sha256="a" * 64,
        excerpt=reference.excerpt, locator="MOCK paragraph 2",
    )


def model_draft(evidence, **changes):
    values = {
        "evidence_id": evidence.id, "original_excerpt_sha256": excerpt_sha256(evidence.excerpt),
        "status": "translated", "title_vi": "Nguồn mô phỏng về chuẩn bị nhập thực phẩm",
        "excerpt_vi": "Nguồn mô phỏng: chuẩn bị thông báo trước về lô hàng. Dữ kiện về bên nhập khẩu còn chưa được kiểm chứng.",
        "publisher_vi": "Cơ quan mô phỏng",
    }
    values.update(changes)
    return EvidenceTranslationDraft.model_validate(values)


@pytest.mark.parametrize("reference", list(REFERENCE_CATALOG.values()))
def test_exact_reference_translation_preserves_every_original_field(reference):
    original = original_evidence(reference)
    before = original.model_dump(mode="json")
    result = attach_reference_translation(original)
    assert {key: result.model_dump(mode="json")[key] for key in ORIGINAL_FIELDS} == {
        key: before[key] for key in ORIGINAL_FIELDS
    }
    assert original.model_dump(mode="json") == before
    assert result.title_vi == reference.title_vi and result.excerpt_vi == reference.excerpt_vi
    assert result.publisher_vi == reference.publisher_vi
    assert result.translation.original_excerpt_sha256 == excerpt_sha256(reference.excerpt)
    assert result.translation.status == "draft_reference"
    assert result.translation.method == "reference_catalog"
    assert result.translation.model_provider is None and result.review_status == "candidate"


def test_reference_fidelity_preserves_conditions_and_flags_the_original_fsvp_typo():
    references = list(REFERENCE_CATALOG.values())
    importing = next(item for item in references if "IMPORT_" in item.reference_id)
    fsvp = next(item for item in references if "FSVP_" in item.reference_id)
    assert all(term in importing.excerpt_vi for term in ("miễn là", "thông báo trước", "có thể tạm giữ", "không trao cho FDA thẩm quyền"))
    assert all(term in fsvp.excerpt_vi for term in ("Nếu không có", "tại Hoa Kỳ", "tại thời điểm nhập khẩu", "văn bản đồng ý đã ký"))
    assert "foreign owner of consignee" in fsvp.excerpt and "foreign owner of consignee" in fsvp.note


@pytest.mark.parametrize("field,value", [
    ("excerpt", "Changed original source text."), ("excerpt", None),
    ("url", "https://www.fda.gov/another-page"), ("title", "Different title"),
    ("publisher", "Another publisher"),
])
def test_changed_excerpt_or_provenance_never_gets_a_nearby_generic_translation(field, value):
    original = original_evidence()
    data = original.model_dump(mode="json")
    data[field] = original.excerpt + " " if value is None else value
    result = attach_reference_translation(Evidence.model_validate(data))
    assert result.excerpt_vi is None and result.title_vi is None and result.publisher_vi is None
    assert result.translation.status == "unavailable" and result.translation.method == "unavailable"
    assert "đúng trích đoạn" in result.translation.note


def test_display_sidecar_never_mutates_saved_report_or_its_hash():
    original = original_evidence()
    legacy = {key: original.model_dump(mode="json")[key] for key in ORIGINAL_FIELDS}
    report = {"evidence": [legacy], "summary": "MOCK báo cáo bất biến"}
    before = deepcopy(report)
    digest = hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest()
    rows = evidence_display_translations(report)
    assert report == before
    assert hashlib.sha256(json.dumps(report, sort_keys=True).encode()).hexdigest() == digest
    assert rows[0]["evidence_id"] == original.id and rows[0]["excerpt_vi"]
    assert set(rows[0]) == {"evidence_id", "title_vi", "excerpt_vi", "publisher_vi", "translation"}
    assert not {"url", "content_sha256", "excerpt", "locator"}.intersection(rows[0])


def test_legacy_evidence_without_new_fields_remains_valid():
    original = original_evidence().model_dump(mode="json")
    legacy = {key: value for key, value in original.items() if key in ORIGINAL_FIELDS}
    parsed = Evidence.model_validate(legacy)
    assert parsed.translation is None and parsed.excerpt_vi is None


@pytest.mark.parametrize("mutation", ["missing", "unknown", "duplicate", "hash"])
def test_model_translation_mapping_must_be_complete_unique_and_exact(mutation):
    original = original_evidence()
    draft = model_draft(original)
    drafts = [] if mutation == "missing" else [draft]
    if mutation == "unknown":
        drafts = [model_draft(original, evidence_id="MOCK-INVENTED-ID")]
    elif mutation == "duplicate":
        drafts = [draft, draft]
    elif mutation == "hash":
        drafts = [model_draft(original, original_excerpt_sha256="b" * 64)]
    with pytest.raises(ShipmentWorkflowError) as caught:
        apply_model_translations([original], drafts, model_provider="anthropic", model_name="claude-sonnet-5-5")
    assert caught.value.code == "MODEL_OUTPUT_INVALID"


def test_model_cannot_include_writable_original_fields_or_inconsistent_status():
    original = original_evidence()
    with pytest.raises(ValueError):
        EvidenceTranslationDraft.model_validate({**model_draft(original).model_dump(), "url": "https://evil.invalid"})
    with pytest.raises(ValueError):
        model_draft(original, status="unavailable")
    translated = attach_reference_translation(original).model_dump(mode="json")
    translated["excerpt"] += " changed"
    with pytest.raises(ValueError):
        Evidence.model_validate(translated)


def test_uncatalogued_model_translation_records_actual_provider_without_changing_originals():
    original = original_evidence().model_copy(update={"excerpt": "MOCK Import preparation includes prior notice. Keep unknown importer information unverified."})
    before = original.model_dump(mode="json")
    result = apply_model_translations([original], [model_draft(original)],
                                      model_provider="anthropic", model_name="claude-sonnet-5-5")[0]
    assert {key: result.model_dump(mode="json")[key] for key in ORIGINAL_FIELDS} == {key: before[key] for key in ORIGINAL_FIELDS}
    assert original.model_dump(mode="json") == before
    assert result.translation.method == "model" and result.translation.model_provider == "anthropic"
    assert result.translation.model_name == "claude-sonnet-5-5"
    assert evidence_display_translations({"evidence": [result.model_dump(mode="json")]})[0]["excerpt_vi"] == result.excerpt_vi


def test_explicit_unavailable_is_not_a_fake_translation():
    original = original_evidence().model_copy(update={"excerpt": "MOCK changed excerpt"})
    draft = model_draft(original, status="unavailable", title_vi=None, excerpt_vi=None, publisher_vi=None)
    result = apply_model_translations([original], [draft], model_provider="anthropic", model_name="claude-sonnet-5-5")[0]
    assert result.excerpt_vi is None and result.translation.status == "unavailable"


def test_copying_uncatalogued_english_text_cannot_claim_to_be_a_vietnamese_translation():
    original = original_evidence().model_copy(update={"excerpt": "MOCK unchanged English source text."})
    with pytest.raises(ShipmentWorkflowError) as caught:
        apply_model_translations([original], [model_draft(original, excerpt_vi=original.excerpt)],
                                 model_provider="anthropic", model_name="claude-sonnet-5-5")
    assert caught.value.code == "MODEL_OUTPUT_INVALID"


def test_model_synthesis_legacy_parse_can_omit_translation_but_runtime_validation_will_not():
    parsed = ModelSynthesis(summary="MOCK tóm tắt đủ dài để kiểm định dạng cũ.", ordered_finding_ids=[], evidence_ids=[])
    assert parsed.evidence_translations == []


def sample_case():
    return {"product": {"sku": "MOCK-SKU", "name": "MOCK miến khô", "family": "dry_food", "origin_country": "VN"},
            "shipment": {"target_market": "US", "route": "importer"}, "consent_research": True, "consent_model": True}


def source_batch(*, exact):
    # This legacy graph fixture deliberately represents import + FSVP only;
    # the larger translation catalog must not turn new topics into duplicate
    # fda_fsvp documents. Topic fixtures are covered independently.
    references = [item for item in REFERENCE_CATALOG.values()
                  if item.reference_id in ("FDA_IMPORT_VI_20261017_DRAFT", "FDA_FSVP_VI_20261017_DRAFT")]
    sources = []
    for index, reference in enumerate(references):
        text = reference.excerpt if exact else (
            "MOCK Import preparation includes prior notice. Keep unknown importer information unverified."
            if index == 0 else "MOCK For FSVP, identify the U.S. owner or consignee. Do not assume the role is verified."
        )
        sources.append(SourceDocument(
            id="fda_import" if index == 0 else "fda_fsvp", url=reference.url, title=reference.title,
            publisher=reference.publisher, accessed_at="2026-10-17T10:00:00Z",
            text=text, content_sha256=excerpt_sha256(text),
        ))
    return SourceBatch(sources=sources)


class MockSourceProvider:
    def __init__(self, *, exact):
        self.batch = source_batch(exact=exact)
        self.calls = 0

    async def fetch_all(self):
        self.calls += 1
        return self.batch


async def invoke_graph(provider, **kwargs):
    graph = build_graph(InMemorySaver(), source_provider=provider, **kwargs)
    state = await graph.ainvoke({"case": sample_case(), "question": "MOCK câu hỏi"},
                               {"configurable": {"thread_id": "MOCK-TRANSLATION-RUN"}})
    return ShipmentReport.model_validate(state["report"])


async def test_evidence_only_can_use_exact_catalog_and_never_invokes_a_model_or_network(monkeypatch):
    def forbidden(*_args, **_kwargs):
        raise AssertionError("No model or network call permitted")
    monkeypatch.setattr("nmate.agents.shipment.graph.create_chat_model", forbidden)
    monkeypatch.setattr(socket, "getaddrinfo", forbidden)
    provider = MockSourceProvider(exact=True)
    report = await invoke_graph(provider)
    assert provider.calls == 1 and report.mode == "evidence_only" and not report.llm_used
    assert all(item.translation.method == "reference_catalog" for item in report.evidence)
    assert all(item.excerpt_vi and item.review_status == "candidate" for item in report.evidence)


async def test_changed_evidence_only_sources_have_explicit_unavailable_translation():
    report = await invoke_graph(MockSourceProvider(exact=False))
    assert all(item.translation.status == "unavailable" and item.excerpt_vi is None for item in report.evidence)


@pytest.mark.parametrize("translation_mode", ["complete", "missing", "unavailable"])
async def test_llm_translates_in_the_existing_single_call_with_strict_runtime_mapping(monkeypatch, translation_mode):
    calls = []

    class MockChat:
        def with_structured_output(self, schema, **_kwargs):
            self.schema = schema
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            payload = json.loads(messages[1][1])
            drafts = [{
                "evidence_id": row["id"], "original_excerpt_sha256": row["original_excerpt_sha256"],
                "status": "translated", "title_vi": "Tiêu đề nguồn mô phỏng",
                "excerpt_vi": ("Nguồn mô phỏng: chuẩn bị thông báo trước về lô hàng. Giữ dữ kiện về bên nhập khẩu ở trạng thái chưa xác minh."
                               if "fda_import" in row["id"] else "Nguồn mô phỏng: với FSVP, xác định chủ sở hữu hoặc bên nhận hàng tại Hoa Kỳ. Không mặc định vai trò đã được xác minh."),
                "publisher_vi": "Cơ quan mô phỏng",
            } for row in payload["evidence_candidates"]]
            if translation_mode == "missing":
                drafts = []
            elif translation_mode == "unavailable":
                drafts = [{**row, "status": "unavailable", "title_vi": None, "excerpt_vi": None, "publisher_vi": None} for row in drafts]
            return self.schema(summary="Bên nhập khẩu và vai trò FSVP chưa được xác minh. Dữ kiện lô hàng còn chưa đủ để đối chiếu việc hỏi báo cước.",
                               ordered_finding_ids=[], evidence_ids=[], evidence_translations=drafts)

    monkeypatch.setattr("nmate.agents.shipment.graph.create_chat_model", lambda *_args: MockChat())
    if translation_mode == "missing":
        with pytest.raises(ShipmentWorkflowError) as caught:
            await invoke_graph(MockSourceProvider(exact=False), mode="llm", model_provider="anthropic",
                               model_name="claude-sonnet-5-5", api_key="MOCK-NOT-A-LIVE-KEY")
        assert caught.value.code == "MODEL_OUTPUT_INVALID"
    else:
        report = await invoke_graph(MockSourceProvider(exact=False), mode="llm", model_provider="anthropic",
                                    model_name="claude-sonnet-5-5", api_key="MOCK-NOT-A-LIVE-KEY")
        assert report.llm_used and report.mode == "llm"
        assert all(item.translation.status == ("draft_reference" if translation_mode == "complete" else "unavailable") for item in report.evidence)
        assert all(item.review_status == "candidate" for item in report.evidence)
        assert not any(warning.startswith("Chế độ chỉ đọc nguồn:") for warning in report.warnings)
    assert len(calls) == 1
    assert len(calls[0][1][1].encode("utf-8")) <= 30000
    assert not any(word in calls[0][0][1] for word in ("facts", "shipment", "candidate", "workflow"))
