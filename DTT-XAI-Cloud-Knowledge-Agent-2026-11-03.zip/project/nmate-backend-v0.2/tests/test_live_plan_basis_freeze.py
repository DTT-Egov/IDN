"""A confirmation does not rewrite the evidence used by a recorded plan."""
import pytest

from nmate.main.history import history_metadata
from test_v04_live_review import workspace as workspace, services, result, send
from test_v04_intake import confirm


@pytest.mark.asyncio
async def test_recorded_plan_keeps_empty_basis_after_same_chat_confirmation(workspace):
    _, owner, _ = workspace
    text = "Chị có sản phẩm Trà Sen Tây Hồ, 100 g, mã TS01. Chị muốn số hóa tồn kho."
    _, intake, chat, stub = services(workspace, [result(text)])
    initial = await send(chat, owner, text=text)
    item = initial["intake"]
    assert item["reused_context"]["fact_count"] == 0
    assert len(item["candidates"]) == 3
    plan = item["business_plan"]
    saved = confirm(intake, owner, item)
    assert saved["business_plan"] == plan
    assert saved["plan_reused_context"]["fact_count"] == 0
    assert len(saved["saved_context"]["fact_refs"]) == 3
    assert len(stub.calls) == 1
    view = chat.get(owner["account_id"], owner["enterprise_id"], initial["id"])
    assert view["intake"]["plan_reused_context"]["fact_count"] == 0
    assert history_metadata(view)["history_reused_fact_count"] == 0


def test_old_recorded_plan_without_immutable_basis_has_unknown_usage():
    result = history_metadata({"status": "ready", "intake": {
        "origins": {"business_plan": "claude_recorded_before_owner_confirmation"},
        "reused_context": {"fact_count": 3}}})
    assert result["history_reused_fact_count"] is None
    assert result["history_state_vi"] == "Trao đổi đã lưu"
