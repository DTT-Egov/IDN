"""Offline public-domain graph contracts; no model or network calls."""
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.policy_v1 import KnowledgeCatalog, PolicyService
from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def domain(tmp_path):
    repo = CoreRepository(tmp_path / "domain.sqlite3")
    owner = LocalAccounts(repo).register("r3_domain_owner", "test-password-owner", "DỮ LIỆU KIỂM THỬ")
    catalog = KnowledgeCatalog(repo)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)",
                   (owner["account_id"], "test-fixture", now_iso()))
    return repo, owner, catalog


def source(domain, identity="R3-SOURCE-A"):
    repo, owner, catalog = domain
    text = f"DỮ LIỆU KIỂM THỬ {identity}. Tư vấn chuyển đổi số kho và đào tạo."
    catalog.register_source(owner["account_id"], identity, f"DỮ LIỆU KIỂM THỬ {identity}", "KIỂM THỬ",
                            f"https://hanoi.gov.vn/test-fixture/{identity}")
    snapshot = catalog.add_snapshot(owner["account_id"], identity, text.encode(), text,
                                   complete_policy=True, effective_from="2026-01-01", effective_until="2030-01-01")
    catalog.record_source_check(owner["account_id"], identity, result="verified_current",
        current_until=(datetime.now(timezone.utc) + timedelta(days=1)).isoformat(), rationale="KIỂM THỬ")
    with repo.connection() as db:
        chunk = dict(db.execute("SELECT * FROM pol_chunks WHERE snapshot_id=?", (snapshot["snapshot_id"],)).fetchone())
    return chunk


def propose(domain, chunk, *, policy="R3-POLICY-A", extra=None, kind="rule"):
    _, owner, catalog = domain
    payload = {"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]},
        "conditions": [{"id": "location", "expression": {"field": "registration_province", "op": "eq", "value": "Hà Nội"}}]}
    if kind == "claim":
        payload = {"scope": payload["scope"], "claim_type": "preparation", "items": [{"id": "paper", "text_vi": "Giấy KIỂM THỬ"}]}
    payload.update(extra or {})
    return catalog.propose_member(owner["account_id"], kind=kind, policy_id=policy, title_vi="KIỂM THỬ",
        payload=payload, evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"],
                                   "supports_id": "location" if kind == "rule" else "paper"}],
        effective_from="2026-01-01", effective_until="2030-01-01")


def publish(domain, member):
    _, owner, catalog = domain
    review = catalog.review_member(owner["account_id"], member["member_id"], member["content_hash"], approve=True, rationale="KIỂM THỬ")
    catalog.publish_member(owner["account_id"], member["member_id"], member["content_hash"], review["review_event_id"])


def test_rule_cannot_smuggle_claim_discriminator(domain):
    chunk = source(domain)
    with pytest.raises(CoreError) as denied:
        propose(domain, chunk, extra={"claim_type": "amount", "items": [{"id": "money", "text_vi": "Khoản tiền"}]})
    assert denied.value.code == "invalid_member_shape"


def test_rule_applies_when_validated_before_proposal(domain):
    chunk = source(domain)
    with pytest.raises(CoreError) as denied:
        propose(domain, chunk, extra={"applies_when": {"field": "province", "op": "eval", "value": "Hà Nội"}})
    assert denied.value.code == "invalid_condition"


def test_typed_projection_readonly_public_rebuild_and_field_requirements(domain):
    from nmate.policy_v1.knowledge_graph import DomainGraph
    repo, owner, catalog = domain
    chunk = source(domain)
    rule = propose(domain, chunk)
    publish(domain, rule)
    pack = catalog.release_pack(owner["account_id"], "KIỂM THỬ", [rule["member_id"]])
    private = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "BÍ MẬT DOANH NGHIỆP")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], private["id"],
                              [{"field": "name", "value": "TUYỆT MẬT"}], 0, "private")
    with repo.connection() as db:
        statements = []
        db.set_trace_callback(statements.append)
        before = db.total_changes
        graph = DomainGraph(db, catalog, target_date="2026-10-22").project()
        assert db.total_changes == before
        db.set_trace_callback(None)
    assert not any("v03_" in statement or "core_v1" in statement for statement in statements)
    assert "TUYỆT MẬT" not in json_text(graph) and private["id"] not in json_text(graph)
    assert graph["writes"] == graph["provider_calls"] == 0
    kinds = {node["ref"]["kind"] for node in graph["nodes"]}
    assert {"public_source", "source_snapshot", "source_excerpt", "rule_version", "policy_version", "pack_version", "domain_field_requirement"} <= kinds
    assert any(edge["relation"] == "cites" and edge["basis_role"] == "primary" and edge["supports_id"] == "location" for edge in graph["edges"])
    assert any(node["ref"]["id"] == pack["pack_version_id"] for node in graph["nodes"])
    assert graph == catalog.domain_graph(target_date="2026-10-22")


def test_policy_scoped_version_and_dependency_dont_change_for_unrelated_source(domain):
    _, owner, catalog = domain
    first = propose(domain, source(domain), policy="R3-A")
    second = propose(domain, source(domain, "R3-SOURCE-B"), policy="R3-B")
    for member in (first, second):
        publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ hai chính sách", [first["member_id"], second["member_id"]])
    before = {item["member_id"]: item for item in catalog.assess([], target_date="2026-10-22")}
    catalog.record_source_check(owner["account_id"], "R3-SOURCE-B", result="unavailable", rationale="KIỂM THỬ")
    after = {item["member_id"]: item for item in catalog.assess([], target_date="2026-10-22")}
    assert after[first["member_id"]]["status"] == "assessed"
    assert after[first["member_id"]]["policy_version"] == before[first["member_id"]]["policy_version"]
    assert after[first["member_id"]]["knowledge_dependency"] == before[first["member_id"]]["knowledge_dependency"]
    assert after[second["member_id"]]["status"] == "blocked"
    assert after[second["member_id"]]["knowledge_dependency"] != before[second["member_id"]]["knowledge_dependency"]


def test_policy_version_uses_only_its_members_not_pack_other_policy_members(domain):
    _, owner, catalog = domain
    first = propose(domain, source(domain), policy="R3-A")
    second = propose(domain, source(domain, "R3-SOURCE-B"), policy="R3-B")
    for member in (first, second):
        publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ A", [first["member_id"]])
    catalog.release_pack(owner["account_id"], "KIỂM THỬ A và B", [first["member_id"], second["member_id"]])
    found = [item for item in catalog.assess([], target_date="2026-10-22") if item["member_id"] == first["member_id"]]
    assert len(found) == 2 and found[0]["policy_version"] == found[1]["policy_version"]
    assert found[0]["pack_version_id"] != found[1]["pack_version_id"]


def test_draft_and_unreleased_member_cannot_become_advice(domain):
    _, _, catalog = domain
    first = propose(domain, source(domain))
    assert catalog.assess([]) == []
    assert not any(node["ref"]["kind"] == "rule_version" for node in catalog.domain_graph()["nodes"])
    publish(domain, first)
    assert catalog.assess([]) == []


@pytest.mark.parametrize("state", ["unavailable", "changed", "superseded", "snapshot_only"])
def test_source_state_blocks_only_dependent_knowledge(domain, state):
    _, owner, catalog = domain
    member = propose(domain, source(domain))
    publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [member["member_id"]])
    catalog.record_source_check(owner["account_id"], "R3-SOURCE-A", result=state, rationale="KIỂM THỬ")
    finding = catalog.assess([])[0]
    assert finding["status"] == "blocked" and finding["payload"] is None
    assert not catalog.retrieve("tư vấn", purpose="reviewed_policy_assessment")


def test_expired_or_incomplete_source_cannot_be_assessed(domain):
    repo, owner, catalog = domain
    member = propose(domain, source(domain))
    publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [member["member_id"]])
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_source_gates SET current_until=? WHERE source_id='R3-SOURCE-A'",
                   ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(),))
    assert catalog.assess([])[0]["reason_code"] == "SOURCE_CURRENT_CHECK_REQUIRED"
    catalog.add_snapshot(owner["account_id"], "R3-SOURCE-A", b"incomplete", "KIỂM THỬ — tư vấn nhưng thiếu phụ lục", complete_policy=False)
    catalog.record_source_check(owner["account_id"], "R3-SOURCE-A", result="verified_current",
        current_until=(datetime.now(timezone.utc) + timedelta(days=1)).isoformat(), rationale="KIỂM THỬ")
    assert catalog.assess([])[0]["status"] == "blocked"
    assert not catalog.retrieve("tư vấn", purpose="reviewed_policy_assessment")
    assert any(edge["relation"] == "supersedes_snapshot" for edge in catalog.domain_graph()["edges"])


def test_explicit_supersession_cannot_cross_policy_or_kind(domain):
    chunk = source(domain)
    old = propose(domain, chunk, policy="R3-OLD")
    with pytest.raises(CoreError) as cross_policy:
        propose(domain, chunk, policy="R3-NEW", extra={"supersedes_member_ids": [old["member_id"]]})
    assert cross_policy.value.code == "invalid_supersession"
    with pytest.raises(CoreError) as cross_kind:
        propose(domain, chunk, policy="R3-OLD", kind="claim", extra={"supersedes_member_ids": [old["member_id"]]})
    assert cross_kind.value.code == "invalid_supersession"


def test_supersession_only_after_review_release_and_no_silent_revival(domain):
    _, owner, catalog = domain
    chunk = source(domain)
    old = propose(domain, chunk)
    publish(domain, old)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ cũ", [old["member_id"]])
    replacement = propose(domain, chunk, extra={"supersedes_member_ids": [old["member_id"]]})
    assert catalog.assess([])[0]["status"] == "assessed"
    publish(domain, replacement)
    assert catalog.assess([])[0]["status"] == "assessed"  # not yet in a released pack
    catalog.release_pack(owner["account_id"], "KIỂM THỬ mới", [replacement["member_id"]])
    findings = {item["member_id"]: item for item in catalog.assess([])}
    assert findings[old["member_id"]]["reason_code"] == "MEMBER_SUPERSEDED"
    assert findings[replacement["member_id"]]["status"] == "assessed"
    catalog.withdraw_member(owner["account_id"], replacement["member_id"], replacement["content_hash"], "KIỂM THỬ")
    findings = {item["member_id"]: item for item in catalog.assess([])}
    assert findings[old["member_id"]]["reason_code"] == "MEMBER_SUPERSEDED"
    assert findings[replacement["member_id"]]["status"] == "blocked"


def test_exact_publication_lineage_is_required_not_just_approved_flags(domain):
    repo, owner, catalog = domain
    first = propose(domain, source(domain))
    second = propose(domain, source(domain, "R3-SOURCE-B"), policy="R3-OTHER")
    for member in (first, second):
        publish(domain, member)
    pack = catalog.release_pack(owner["account_id"], "KIỂM THỬ", [first["member_id"]])
    with repo.connection(write=True) as db:
        row = db.execute("SELECT * FROM pol_packs WHERE id=?", (pack["pack_version_id"],)).fetchone()
        manifest = json.loads(row["manifest_json"])
        manifest[0]["publication_event_id"] = db.execute("SELECT id FROM pol_publication_events WHERE member_id=?", (second["member_id"],)).fetchone()[0]
        # Private corruption fixture restores manifest+release agreement, to
        # isolate the publication->member identity guard from hash checking.
        from nmate.policy_v1.catalog import digest
        db.execute("UPDATE pol_packs SET manifest_json=?,manifest_hash=? WHERE id=?", (json_text(manifest), digest(manifest), pack["pack_version_id"]))
        db.execute("DROP TRIGGER pol_releases_immutable")
        db.execute("UPDATE pol_release_events SET manifest_hash=? WHERE pack_id=?", (digest(manifest), pack["pack_version_id"]))
    assert catalog.assess([])[0]["reason_code"] == "MEMBER_PUBLICATION_LINEAGE_INVALID"


def test_rule_applies_when_is_part_of_actual_condition_verdict(domain):
    _, owner, catalog = domain
    rule = propose(domain, source(domain), extra={"applies_when": {"field": "industry", "op": "eq", "value": "công nghệ"}})
    publish(domain, rule)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [rule["member_id"]])
    facts = [{"field": "registration_province", "value": "Hà Nội"}, {"field": "industry", "value": "thực phẩm"}]
    finding = catalog.assess(facts)[0]
    assert finding["conditions"][0]["condition_id"] == "applies_when"
    assert finding["conditions"][0]["state"] == "not_met"


def test_exception_has_primary_basis_and_is_evaluated_not_ignored(domain):
    _, owner, catalog = domain
    chunk = source(domain)
    exception = {"id": "already_supported", "title_vi": "Đã nhận hỗ trợ", "expression": {"field": "already_supported", "op": "eq", "value": True}}
    with pytest.raises(CoreError) as ungrounded:
        propose(domain, chunk, extra={"exceptions": [exception]})
    assert ungrounded.value.code == "evidence_coverage_gap"
    payload = {"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]},
        "conditions": [{"id": "location", "expression": {"field": "registration_province", "op": "present"}}], "exceptions": [exception]}
    rule = catalog.propose_member(owner["account_id"], kind="rule", policy_id="R3-EXCEPTION", title_vi="KIỂM THỬ", payload=payload,
        evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": identity} for identity in ("location", "already_supported")],
        effective_from="2026-01-01")
    publish(domain, rule)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [rule["member_id"]])
    finding = catalog.assess([{"field": "registration_province", "value": "Hà Nội"}, {"field": "already_supported", "value": True}])[0]
    assert finding["conditions"][-1]["condition_id"] == "exception:already_supported"
    assert finding["conditions"][-1]["state"] == "not_met"
    assert any(edge["relation"] == "exception_requires_fact" for edge in catalog.domain_graph()["edges"])


def test_two_policy_goals_share_plan_contract_without_rewriting_receipt(domain):
    repo, owner, _ = domain
    service = PolicyService(repo)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"],
        "Cơ sở muốn hỗ trợ xúc tiến xuất khẩu trà sen sang Mỹ và đào tạo nhân viên làm sổ sách.", "mixed")
    with repo.connection() as db:
        saved = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0]
    assert len(mission["intent_plan"]["intent"]["goals"]) == 2
    view = service.get(owner["account_id"], owner["enterprise_id"], mission["id"])
    assert len(view["intent_plan"]["intent"]["goals"]) == 2
    assert all(item["status"] == "needs_source" for item in view["goal_coverage"])
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0] == saved
    assert "intent_plan" not in json.loads(saved)


def test_legacy_wrong_type_is_quarantined_per_member_without_data_rewrite(domain):
    repo, owner, catalog = domain
    first = propose(domain, source(domain), policy="R3-GOOD")
    second = propose(domain, source(domain, "R3-SOURCE-B"), policy="R3-LEGACY")
    for member in (first, second):
        publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [first["member_id"], second["member_id"]])
    with repo.connection(write=True) as db:
        old = db.execute("SELECT payload_json FROM pol_members WHERE id=?", (second["member_id"],)).fetchone()[0]
        payload = json.loads(old)
        payload["claim_type"] = "amount"
        db.execute("DROP TRIGGER pol_member_content_immutable")
        db.execute("UPDATE pol_members SET payload_json=? WHERE id=?", (json_text(payload), second["member_id"]))
    findings = {item["member_id"]: item for item in catalog.assess([])}
    assert findings[first["member_id"]]["status"] == "assessed"
    assert findings[second["member_id"]]["reason_code"] == "MEMBER_CONTRACT_INVALID"
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_members WHERE id=?", (second["member_id"],)).fetchone()[0] == json_text(payload)


def test_pack_cannot_borrow_other_pack_release_with_identical_manifest(domain):
    repo, owner, catalog = domain
    rule = propose(domain, source(domain))
    publish(domain, rule)
    first = catalog.release_pack(owner["account_id"], "KIỂM THỬ A", [rule["member_id"]])
    second = catalog.release_pack(owner["account_id"], "KIỂM THỬ B", [rule["member_id"]])
    assert first["manifest_hash"] == second["manifest_hash"]
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_packs SET release_event_id=? WHERE id=?", (second["release_event_id"], first["pack_version_id"]))
    findings = catalog.assess([])
    assert len(findings) == 1 and findings[0]["pack_version_id"] == second["pack_version_id"]


def test_public_graph_does_not_accept_a_different_jurisdiction_source(domain):
    repo, owner, catalog = domain
    member = propose(domain, source(domain))
    publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [member["member_id"]])
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_sources SET jurisdiction='US' WHERE id='R3-SOURCE-A'")
    assert catalog.retrieve("tư vấn") == []
    assert catalog.assess([])[0]["status"] == "blocked"
    graph = catalog.domain_graph()
    assert not any(node["ref"]["kind"] in {"public_source", "source_snapshot", "source_excerpt"} for node in graph["nodes"])


def test_saved_result_rechecks_domain_dependency_without_model_or_rewrite(domain):
    repo, owner, catalog = domain
    source(domain)
    service = PolicyService(repo)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "saved")
    with repo.connection() as db:
        saved = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0]
        dependencies = [dict(row) for row in db.execute("SELECT * FROM pol_mission_dependencies WHERE mission_id=?", (mission["id"],))]
    assert any(item["kind"] == "domain_manifest" for item in dependencies)
    assert any(item["kind"] == "domain:public_source" for item in dependencies)
    catalog.record_source_check(owner["account_id"], "R3-SOURCE-A", result="unavailable", rationale="KIỂM THỬ")
    view = service.get(owner["account_id"], owner["enterprise_id"], mission["id"])
    assert view["is_historical"] and view["current_warnings_vi"]
    assert view["sources"] == mission["sources"]
    assert view["provider_calls"] == 0
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0] == saved


def test_saved_rule_result_warns_when_explicit_successor_replaces_old_version(domain):
    repo, owner, catalog = domain
    chunk = source(domain)
    old = propose(domain, chunk)
    publish(domain, old)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ cũ", [old["member_id"]])
    service = PolicyService(repo)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có đủ điều kiện không?", "old-result")
    assert mission["findings"]
    with repo.connection() as db:
        saved = db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0]
    replacement = propose(domain, chunk, extra={"supersedes_member_ids": [old["member_id"]]})
    publish(domain, replacement)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ mới", [replacement["member_id"]])
    view = service.get(owner["account_id"], owner["enterprise_id"], mission["id"])
    assert view["is_historical"]
    assert any("Phiên bản hoặc căn cứ quy tắc" in warning for warning in view["current_warnings_vi"])
    assert view["findings"] == mission["findings"]
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (mission["id"],)).fetchone()[0] == saved


@pytest.mark.parametrize("bad_bindings", [[{"role": "primary", "supports_id": "location"}], None, "bad"])
def test_bad_legacy_evidence_does_not_break_other_policy_projection(domain, bad_bindings):
    repo, owner, catalog = domain
    first = propose(domain, source(domain), policy="R3-GOOD")
    second = propose(domain, source(domain, "R3-SOURCE-B"), policy="R3-LEGACY")
    for member in (first, second):
        publish(domain, member)
    catalog.release_pack(owner["account_id"], "KIỂM THỬ", [first["member_id"], second["member_id"]])
    with repo.connection(write=True) as db:
        db.execute("DROP TRIGGER pol_member_content_immutable")
        db.execute("UPDATE pol_members SET evidence_json=? WHERE id=?", (json_text(bad_bindings), second["member_id"]))
    findings = {item["member_id"]: item for item in catalog.assess([])}
    assert findings[first["member_id"]]["status"] == "assessed"
    assert findings[second["member_id"]]["status"] == "blocked"
    assert catalog.domain_graph()["provider_calls"] == 0


@pytest.mark.parametrize("boundary", ["review", "publish", "release", "reject"])
def test_legacy_mixed_type_draft_cannot_cross_new_authority_boundary(domain, boundary):
    from nmate.policy_v1.catalog import digest
    repo, owner, catalog = domain
    proposed = propose(domain, source(domain))
    identity = proposed["member_id"]
    # Simulate an immutable, correctly hashed mixed-kind version that the R1
    # proposal writer demonstrably allowed. Historical authority events below
    # model that same pre-contract state, on this private fixture only.
    with repo.connection(write=True) as db:
        member = dict(db.execute("SELECT * FROM pol_members WHERE id=?", (identity,)).fetchone())
        payload = json.loads(member["payload_json"])
        payload.update({"claim_type": "amount", "items": [{"id": "money", "text_vi": "Khoản tiền KIỂM THỬ"}]})
        content_hash = digest({"kind": member["kind"], "policy_id": member["policy_id"], "title_vi": member["title_vi"],
            "payload": payload, "evidence": json.loads(member["evidence_json"]), "effective_from": member["effective_from"], "effective_until": member["effective_until"]})
        db.execute("DROP TRIGGER pol_member_content_immutable")
        db.execute("UPDATE pol_members SET payload_json=?,content_hash=? WHERE id=?", (json_text(payload), content_hash, identity))
        if boundary in {"publish", "release"}:
            db.execute("INSERT INTO pol_review_events VALUES(?,?,?,?,?,?,?)", ("legacy-review", identity, content_hash,
                owner["account_id"], "approved", "KIỂM THỬ lịch sử", now_iso()))
            db.execute("UPDATE pol_members SET review_state='approved',availability='usable' WHERE id=?", (identity,))
        if boundary == "release":
            db.execute("INSERT INTO pol_publication_events VALUES(?,?,?,?,?,?)", ("legacy-publication", identity, content_hash,
                "legacy-review", owner["account_id"], now_iso()))
            db.execute("UPDATE pol_members SET publication_state='published' WHERE id=?", (identity,))
    if boundary == "reject":
        rejected = catalog.review_member(owner["account_id"], identity, content_hash, approve=False, rationale="KIỂM THỬ từ chối phiên bản cũ sai loại")
        assert rejected["review_state"] == "rejected"
        return
    with pytest.raises(CoreError) as denied:
        if boundary == "review":
            catalog.review_member(owner["account_id"], identity, content_hash, approve=True, rationale="KIỂM THỬ")
        elif boundary == "publish":
            catalog.publish_member(owner["account_id"], identity, content_hash, "legacy-review")
        else:
            catalog.release_pack(owner["account_id"], "KIỂM THỬ không được phát hành", [identity])
    assert denied.value.code == "invalid_member_shape"


@pytest.mark.asyncio
async def test_translation_dependency_change_during_synthesis_prevents_publication(domain):
    # Availability/span do not change when an approved translation is withdrawn.
    repo, owner, catalog = domain
    catalog.register_source(owner["account_id"], "R3-EN", "KIỂM THỬ English", "KIỂM THỬ",
                            "https://hanoi.gov.vn/test-fixture/en", language="en")
    catalog.add_snapshot(owner["account_id"], "R3-EN", b"digital consulting", "digital consulting", complete_policy=False)
    chunk = catalog.retrieve("digital consulting")[0]
    translation = catalog.add_translation(owner["account_id"], chunk["chunk_id"], "KIỂM THỬ — tư vấn chuyển đổi số kho")
    with repo.connection() as db:
        text_hash = db.execute("SELECT text_hash FROM pol_translations WHERE id=?", (translation["translation_id"],)).fetchone()[0]
    catalog.review_translation(owner["account_id"], translation["translation_id"], text_hash)

    class Gateway:
        calls = 0

        async def call_once(self, **kwargs):
            self.calls += 1
            with repo.connection(write=True) as db:
                db.execute("UPDATE pol_translations SET review_state='withdrawn' WHERE id=?", (translation["translation_id"],))
            candidates = kwargs["context"]["analysis_candidates"]
            return {"data": {"schema_version": "policy-model-analysis/2", "evidence_choices": candidates["evidence"][:1],
                "next_task_ids": [item["id"] for item in candidates["next_tasks"][:1]], "ssot_question_ids": []}, "attempt": {"fixture": True}}

    gateway = Gateway()
    service = PolicyService(repo, gateway=gateway)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Tư vấn chuyển đổi số kho digital consulting", "translation")
    assert mission["sources"]
    service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "start", "test-only")
    result = await service.execute_next()
    assert gateway.calls == 1
    assert result["status"] == "failed"
    assert result["error"]["code"] == "source_changed"
