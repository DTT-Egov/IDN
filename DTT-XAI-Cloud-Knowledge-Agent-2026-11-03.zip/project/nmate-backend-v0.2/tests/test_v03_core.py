from concurrent.futures import ThreadPoolExecutor

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "core.sqlite")
    accounts = LocalAccounts(repo)
    alice = accounts.register("alice", "a-long-password", "Doanh nghiệp Sen")
    bob = accounts.register("bob", "b-long-password", "Doanh nghiệp khác")
    entity = repo.create_entity(alice["account_id"], alice["enterprise_id"], "product", "Trà Sen")
    return repo, accounts, alice, bob, entity


def apply(repo, owner, entity, facts, version=0, operation="save"):
    return repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
                                     facts, version, operation)


def test_literal_case_null_clear_and_history(setup):
    repo, _, alice, _, entity = setup
    result = apply(repo, alice, entity, [{"field": "product_name", "value": "Trà Sen ĐỒNG THÁP"},
                                      {"field": "ingredients", "value": ["Sen", "Trà Xanh"]}])
    assert result["version"] == 1
    null = apply(repo, alice, entity, [{"field": "product_name", "value": None}], 1, "null")
    assert null["version"] == 1
    context = repo.get_context(alice["account_id"], alice["enterprise_id"])
    assert context["entities"][0]["values"]["product_name"] == "Trà Sen ĐỒNG THÁP"
    assert all(f["certainty"] == "self_declared" and f["actor_id"] == alice["account_id"]
               for f in result["facts"])
    cleared = apply(repo, alice, entity, [{"field": "product_name", "value": None, "explicit_clear": True}], 1, "clear")
    assert cleared["version"] == 2
    current = repo.get_context(alice["account_id"], alice["enterprise_id"])
    assert "product_name" not in current["entities"][0]["values"]
    history = repo.get_fact_history(alice["account_id"], alice["enterprise_id"], entity["id"], "product_name")
    assert [h["value"] for h in history] == ["Trà Sen ĐỒNG THÁP", None]
    assert history[-1]["action"] == "clear"
    assert history[-1]["previous_assertion_id"] == history[0]["id"]


def test_cross_enterprise_and_resource_spoof_denied(setup):
    repo, _, alice, bob, entity = setup
    apply(repo, alice, entity, [{"field": "secret_formula", "value": "Only Alice"}])
    with pytest.raises(CoreError) as denied:
        repo.get_context(bob["account_id"], alice["enterprise_id"])
    assert denied.value.status_code == 403
    with pytest.raises(CoreError):
        repo.get_entity(bob["account_id"], bob["enterprise_id"], entity["id"])
    with pytest.raises(CoreError):
        repo.create_entity(bob["account_id"], bob["enterprise_id"], "formula", "x", entity["id"])
    with pytest.raises(CoreError):
        repo.propose_or_apply_facts(bob["account_id"], alice["enterprise_id"], entity["id"], [], 1, "spoof")
    assert repo.get_context(bob["account_id"], bob["enterprise_id"])["entities"] == []
    # Adding an unprivileged membership is insufficient for private-owner data.
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_memberships VALUES (?,?,'member',1)", (bob["account_id"], alice["enterprise_id"]))
    with pytest.raises(CoreError):
        repo.get_fact_history(bob["account_id"], alice["enterprise_id"], entity["id"])


def test_same_account_relogin_returns_persistent_enterprise_context(setup):
    repo, _, alice, _, entity = setup
    apply(repo, alice, entity, [{"field": "net_weight", "value": "200 g"}])
    reopened = CoreRepository(repo.db_path)
    browser_b = LocalAccounts(reopened).login("ALICE", "a-long-password")
    assert browser_b["enterprise_id"] == alice["enterprise_id"]
    assert reopened.get_context(browser_b["account_id"], browser_b["enterprise_id"])["entities"][0]["values"]["net_weight"] == "200 g"


def test_cas_concurrent_updates_and_idempotency(setup):
    repo, _, alice, _, entity = setup
    def update(value):
        try:
            return apply(repo, alice, entity, [{"field": "net_weight", "value": value}], 0, value)
        except CoreError as exc:
            return exc.code
    with ThreadPoolExecutor(max_workers=2) as pool:
        outcomes = list(pool.map(update, ["100 g", "200 g"]))
    assert sum(isinstance(o, dict) for o in outcomes) == 1
    assert "version_conflict" in outcomes
    winner = next(o for o in outcomes if isinstance(o, dict))
    value = winner["facts"][0]["value"]
    assert apply(repo, alice, entity, [{"field": "net_weight", "value": value}], 0, value) == winner
    with pytest.raises(CoreError) as error:
        apply(repo, alice, entity, [{"field": "net_weight", "value": "changed"}], 0, value)
    assert error.value.code == "idempotency_conflict"
    assert len(repo.get_fact_history(alice["account_id"], alice["enterprise_id"], entity["id"])) == 1


def test_field_version_gate_and_atomic_dependency_invalidation(setup):
    repo, _, alice, _, entity = setup
    apply(repo, alice, entity, [{"field": "ingredients", "value": "Sen, Trà"}, {"field": "net_weight", "value": "200 g"}])
    context = repo.get_context(alice["account_id"], alice["enterprise_id"], fields=["ingredients"])
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE v03_missions(id TEXT,enterprise_id TEXT,status TEXT,stale_reason TEXT)")
        db.execute("CREATE TABLE v03_dependencies(mission_id TEXT,enterprise_id TEXT,dependency_kind TEXT,dependency_key TEXT,dependency_version INTEGER)")
        db.execute("INSERT INTO v03_missions VALUES ('m',?,'ready',NULL)", (alice["enterprise_id"],))
        db.execute("INSERT INTO v03_dependencies VALUES ('m',?,'fact',?,1)", (alice["enterprise_id"], entity["id"] + ":ingredients"))
    apply(repo, alice, entity, [{"field": "net_weight", "value": "300 g"}], 1, "weight")
    assert repo.validate_context(alice["account_id"], alice["enterprise_id"], context["fact_refs"])["valid"]
    apply(repo, alice, entity, [{"field": "ingredients", "value": "Sen, Trà, Gừng"}], 2, "formula")
    assert not repo.validate_context(alice["account_id"], alice["enterprise_id"], context["fact_refs"])["valid"]
    with repo.connection() as db:
        assert db.execute("SELECT status FROM v03_missions WHERE id='m'").fetchone()[0] == "needs_revalidation"


def test_invalid_type_or_actor_rolls_back_all_facts(setup):
    repo, _, alice, bob, entity = setup
    with pytest.raises(CoreError):
        apply(repo, alice, entity, [{"field": "net_weight", "value": "200 g"},
                                  {"field": "amount", "value": "abc", "value_type": "number"}])
    assert repo.get_entity(alice["account_id"], alice["enterprise_id"], entity["id"])["version"] == 0
    with pytest.raises(CoreError):
        repo.propose_or_apply_facts(alice["account_id"], alice["enterprise_id"], entity["id"], [], 0, "actor", actor=bob["account_id"])
    assert repo.get_fact_history(alice["account_id"], alice["enterprise_id"], entity["id"]) == []


def test_membership_revoke_blocks_saved_refs(setup):
    repo, _, alice, _, entity = setup
    apply(repo, alice, entity, [{"field": "ingredients", "value": "Sen"}])
    refs = repo.get_context(alice["account_id"], alice["enterprise_id"])["fact_refs"]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=?", (alice["account_id"],))
    with pytest.raises(CoreError):
        repo.validate_context(alice["account_id"], alice["enterprise_id"], refs)


def test_missing_field_ref_and_time_bounds_gate(setup):
    repo, _, alice, _, entity = setup
    context = repo.get_context(alice["account_id"], alice["enterprise_id"], fields=["net_weight"])
    assert context["fact_refs"] == [{"entity_id": entity["id"], "field": "net_weight", "version": 0, "assertion_id": None}]
    assert repo.validate_context(alice["account_id"], alice["enterprise_id"], context["fact_refs"])["valid"]
    apply(repo, alice, entity, [{"field": "net_weight", "value": "200 g"},
                              {"field": "certificate", "value": "expired", "valid_to": "2000-01-01"},
                              {"field": "future_formula", "value": "Future", "valid_from": "2100-01-01"}])
    assert not repo.validate_context(alice["account_id"], alice["enterprise_id"], context["fact_refs"])["valid"]
    current = repo.get_context(alice["account_id"], alice["enterprise_id"])
    assert current["entities"][0]["values"] == {"net_weight": "200 g"}
    assert not repo.validate_context(alice["account_id"], alice["enterprise_id"], current["fact_refs"])["valid"]
