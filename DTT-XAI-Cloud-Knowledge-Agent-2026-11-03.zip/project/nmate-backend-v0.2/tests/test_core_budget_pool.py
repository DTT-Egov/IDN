"""The app-wide approval is never multiplied by account or enterprise count."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.core_v1.budget_pool import BudgetPool
from nmate.core_v1.gateway import ModelGateway
from nmate.v03.core import CoreError, CoreRepository, new_id, now_iso
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "budget-pool.sqlite")
    accounts = LocalAccounts(repo)
    first = accounts.register("pool-first", "Password12345", "Doanh nghiệp A")
    second = accounts.register("pool-second", "Password12345", "Doanh nghiệp B")
    ModelGateway(repo)  # schema only; no transport or credentials
    pool = BudgetPool(repo)
    return repo, first, second, pool


def authorize(setup, *, calls=2, cap=1, role="standard", approval="LOCAL-APP-TEST"):
    return setup[3].authorize(approval, role, calls, cap, ["legacy_intake", "hanoi_policy_synthesis"],
        (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())


def reserve(setup, grant, owner, hold=100000, state="outcome_unknown"):
    repo, _, _, pool = setup
    operation, attempt = new_id("operation"), new_id("attempt")
    with repo.connection(write=True) as db:
        pool.check_reservation(db, grant, hold)
        db.execute("INSERT INTO core_model_operations VALUES(?,?,?,?,?,NULL,'reserved',?)",
                   (owner["enterprise_id"], operation, owner["account_id"], "hash", "legacy_intake", now_iso()))
        db.execute("INSERT INTO core_model_attempts(id,enterprise_id,operation_id,task_id,step_key,actor_id,grant_id,profile_version,model,"
                   "price_version,request_hash,input_upper_tokens,max_output_tokens,held_microusd,state,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (attempt, owner["enterprise_id"], operation, "legacy_intake", "synthesis", owner["account_id"], grant,
                    "standard/1", "claude-sonnet-5-5", "test", "hash", 1000, 4096, hold, state, now_iso()))
    return attempt


def test_provision_is_owner_scoped_idempotent_and_no_private_data_returned(setup):
    repo, first, second, pool = setup
    authorize(setup)
    one = pool.provision(first["account_id"], first["enterprise_id"])
    assert pool.provision(first["account_id"], first["enterprise_id"]) == one
    two = pool.provision(second["account_id"], second["enterprise_id"])
    assert len(one) == len(two) == 1 and one != two
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 2
        status = pool.status_grant(db, one[0])
        assert status["remaining_calls"] == 2
        assert second["account_id"] not in json.dumps(status)
        assert second["enterprise_id"] not in json.dumps(status)


def test_total_calls_shared_by_distinct_owners_and_new_account_gets_no_refill(setup):
    repo, first, second, pool = setup
    authorize(setup, calls=2)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    two = pool.provision(second["account_id"], second["enterprise_id"])[0]
    reserve(setup, one, first)
    reserve(setup, two, second)
    with pytest.raises(CoreError) as error:
        reserve(setup, one, first)
    assert error.value.code == "BUDGET_EXCEEDED"
    third = LocalAccounts(repo).register("pool-third", "Password12345", "Doanh nghiệp C")
    assert pool.provision(third["account_id"], third["enterprise_id"]) == []
    with repo.connection() as db:
        assert pool.status_grant(db, one)["remaining_calls"] == 0
        assert pool.status_grant(db, two)["held_usd"] == .2


def test_money_is_global_and_unknown_hold_survives_restart(setup):
    repo, first, second, pool = setup
    authorize(setup, calls=20, cap=.15)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    two = pool.provision(second["account_id"], second["enterprise_id"])[0]
    reserve(setup, one, first, hold=100000)
    restarted = BudgetPool(repo)
    with repo.connection(write=True) as db:
        with pytest.raises(CoreError):
            restarted.check_reservation(db, two, 60000)
        assert restarted.status_grant(db, two)["held_usd"] == .1


def test_atomic_parallel_last_call_cannot_overspend_across_owners(setup):
    repo, first, second, pool = setup
    authorize(setup, calls=1)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    two = pool.provision(second["account_id"], second["enterprise_id"])[0]

    def run(args):
        try:
            reserve(setup, args[0], args[1])
            return True
        except CoreError:
            return False

    with ThreadPoolExecutor(max_workers=2) as executor:
        assert sorted(executor.map(run, [(one, first), (two, second)])) == [False, True]
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 1


def test_closed_or_expired_pool_stops_existing_child_grants(setup):
    repo, first, _, pool = setup
    definition = authorize(setup)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_pools SET state='closed' WHERE id=?", (definition["id"],))
        with pytest.raises(CoreError):
            pool.check_grant(db, one)
        assert pool.status_grant(db, one)["approved"] is False
    assert pool.provision(first["account_id"], first["enterprise_id"]) == []


def test_reapproving_same_id_cannot_change_cap_scope_or_expiry(setup):
    _, _, _, pool = setup
    expiry = (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
    one = pool.authorize("APPROVAL", "standard", 5, 1, ["legacy_intake"], expiry)
    assert pool.authorize("APPROVAL", "standard", 5, 1, ["legacy_intake"], expiry)["id"] == one["id"]
    with pytest.raises(CoreError) as error:
        pool.authorize("APPROVAL", "standard", 6, 1, ["legacy_intake"], expiry)
    assert error.value.code == "BUDGET_APPROVAL_CONFLICT"
    with pytest.raises(CoreError):
        pool.authorize("APPROVAL", "standard", 5, 1, ["legacy_intake", "legacy_research"], expiry)


def test_child_cannot_expand_role_scope_expiry_or_cross_owner(setup):
    repo, first, second, pool = setup
    authorize(setup)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_grants SET roles_json=? WHERE id=?", ('["complex"]', one))
        with pytest.raises(CoreError):
            pool.check_grant(db, one)
        db.execute("UPDATE core_budget_grants SET roles_json=?,account_id=? WHERE id=?", ('["standard"]', second["account_id"], one))
        with pytest.raises(CoreError):
            pool.check_grant(db, one)


def test_staff_membership_never_provisions_budget(setup):
    repo, first, second, pool = setup
    authorize(setup)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_memberships(account_id,enterprise_id,role) VALUES(?,?,'staff')",
                   (second["account_id"], first["enterprise_id"]))
    with pytest.raises(CoreError):
        pool.provision(second["account_id"], first["enterprise_id"])
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 0


def test_only_cancelled_before_dispatch_releases_pool_hold(setup):
    repo, first, _, pool = setup
    authorize(setup, calls=1)
    one = pool.provision(first["account_id"], first["enterprise_id"])[0]
    attempt = reserve(setup, one, first, state="cancelled_before_dispatch")
    with repo.connection() as db:
        assert pool.status_grant(db, one)["held_usd"] == 0
    reserve(setup, one, first)
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_model_attempts SET state='response_received' WHERE id=?", (attempt,))
        assert pool.status_grant(db, one)["remaining_calls"] == 0
        with pytest.raises(CoreError):
            pool.check_reservation(db, one, 1)

