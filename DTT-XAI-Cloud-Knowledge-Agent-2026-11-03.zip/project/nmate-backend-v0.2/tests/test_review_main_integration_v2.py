"""Frontend review-v2 DTOs cross real application/MCP adapters with no paid IO.

These tests intentionally use the same nested draft shape sent by main-app.js.
The provider is an injected, deterministic fixture and external sockets are
forbidden (Windows asyncio's local self-pipe is allowed). Only a temporary
database created by pytest is touched.
"""
from __future__ import annotations

import inspect
import json
import socket

import pytest

from nmate.core_v1.integration import CoreIntegration
from nmate.main.app import MainMissions, TOOLS
from nmate.main.conversations import MainConversationService, MainIntakeService
from nmate.main.provider import MainProvider
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.live_review import LiveConversationService
from nmate.v04.mcp import register_tools
from test_review_architecture_acceptance import TEXT
from test_unified_main import Model


class Registry:
    """Capture the actual registered handlers; no separate mock adapter logic."""

    def __init__(self):
        self.tools = {}

    def tool(self, **_options):
        def register(function):
            self.tools[function.__name__] = function
            return function
        return register

    def remove_tool(self, name):
        self.tools.pop(name, None)


@pytest.fixture(autouse=True)
def no_external_io(monkeypatch):
    connect, connect_ex = socket.socket.connect, socket.socket.connect_ex

    def guarded(original):
        def deny_external(sock, address, *args, **kwargs):
            if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
                return original(sock, address, *args, **kwargs)
            raise AssertionError("Review integration must use no external sockets or real model")
        return deny_external
    monkeypatch.setattr(socket.socket, "connect", guarded(connect))
    monkeypatch.setattr(socket.socket, "connect_ex", guarded(connect_ex))


@pytest.fixture
def integrated(tmp_path):
    repo = CoreRepository(tmp_path / "review-main-v2.sqlite3")
    owner = LocalAccounts(repo).register("review-main-v2", "Only-local-test-password", "Trà Sen QA")
    model = Model()
    provider = MainProvider(repo, request_fn=model, max_attempts=12, budget_scope="global")
    missions = MainMissions(repo, model_call=provider)
    intake = MainIntakeService(repo, provider=provider, missions=missions)
    chat = MainConversationService(intake)
    core = CoreIntegration(repo, missions, intake, gateway_enabled=False)
    core.conversations = chat
    registry = Registry()

    async def authorized(operation):
        value = operation(owner["account_id"])
        return await value if inspect.isawaitable(value) else value

    register_tools(registry, intake, authorized)
    core.register_tools(registry, authorized)
    return repo, owner, model, provider, intake, chat, registry


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


def prepared(integrated, operation="integration-free-initial"):
    _repo, owner, _model, _provider, _intake, chat, _registry = integrated
    return chat.prepare_chat_draft(*scope(owner), TEXT, operation, task_hint="profile_intake")


def editor(conversation, **patch):
    item = conversation["intake"]
    prior = conversation.get("drafts", {}).get(item["id"], {})
    return {"selected": {candidate["id"]: candidate["field"] in {"name", "product_code"}
                         for candidate in item["candidates"]},
            "edits": {}, "choices": {}, "base_review_revision": item["review"]["revision"],
            "ui_revision": prior.get("ui_revision", 0), **patch}


def ui_rows(repo):
    with repo.connection() as db:
        return [dict(row) for row in db.execute("SELECT * FROM core_review_ui_drafts ORDER BY enterprise_id,workspace_id,actor_id")]


@pytest.mark.asyncio
async def test_registered_v2_mcp_tools_and_immutable_receipt_match_frontend_shape(integrated):
    repo, owner, model, _provider, _intake, _chat, registry = integrated
    names = {"get_review_workspace", "get_review_receipt", "dismiss_review_candidates"}
    assert names <= registry.tools.keys() and names <= TOOLS
    assert "expected_review_revision" in inspect.signature(registry.tools["confirm_intake"]).parameters
    assert "expected_proposal_hashes" in inspect.signature(registry.tools["confirm_intake"]).parameters
    conversation = prepared(integrated)
    item = conversation["intake"]
    first = next(candidate for candidate in item["candidates"] if candidate["field"] == "trading_name")
    result = await registry.tools["confirm_intake"](enterprise_id=owner["enterprise_id"], intake_id=item["id"],
        selected_fact_ids=[first["id"]], expected_entity_versions=item["expected_entity_versions"],
        operation_id="integration-confirm-first", expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={first["id"]: item["review"]["proposal_hashes"][first["id"]]})
    receipt = await registry.tools["get_review_receipt"](enterprise_id=owner["enterprise_id"], intake_id=item["id"],
                                                       operation_id="integration-confirm-first")
    assert receipt["receipt"] == result["latest_confirmation_receipt"]
    assert receipt["receipt"]["operation_id"] == "integration-confirm-first"
    assert receipt["receipt"]["workspace_id"] == item["id"]
    assert receipt["current_view"]["id"] == item["id"]  # raw intake, not historical receipt
    assert len(receipt["current_view"]["review"]["pending_candidate_ids"]) == 5
    view = await registry.tools["get_review_workspace"](enterprise_id=owner["enterprise_id"], intake_id=item["id"])
    assert view["schema_version"] == "workspace-review/2" and view["scope"]["workspace_id"] == item["id"]
    assert view["latest_confirmation_receipt"] == receipt["receipt"]
    assert view["billing"]["local_review_model_calls"] == 0 and not model.calls
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0


@pytest.mark.asyncio
async def test_ui_draft_metadata_crosses_save_then_free_prepare_once(integrated):
    repo, owner, model, _provider, _intake, _chat, registry = integrated
    conversation = prepared(integrated)
    item = conversation["intake"]
    saved = await registry.tools["save_conversation_draft"](enterprise_id=owner["enterprise_id"],
        conversation_id=conversation["id"], intake_id=item["id"], draft=editor(conversation), operation_id="integration-save-editor")
    assert saved["drafts"][item["id"]]["ui_revision"] == 1
    assert len(ui_rows(repo)) == 1
    current = editor(saved)
    reply = await registry.tools["prepare_chat_draft"](enterprise_id=owner["enterprise_id"],
        conversation_id=conversation["id"], target_intake_id=item["id"],
        text="Chị muốn số hóa bán hàng và tồn kho.", operation_id="integration-free-followup",
        task_hint="sales_inventory", draft={"intake_id": item["id"], **current})
    assert reply["id"] == conversation["id"] and reply["intake"]["id"] == item["id"]
    assert reply["drafts"][item["id"]]["ui_revision"] == 2
    assert ui_rows(repo)[0]["ui_revision"] == 2 and not model.calls


@pytest.mark.asyncio
@pytest.mark.parametrize("existing_draft", [False, True])
async def test_live_preflight_validation_has_no_durable_ui_side_effect(integrated, existing_draft):
    repo, owner, model, _provider, intake, _chat, _registry = integrated
    conversation = prepared(integrated)
    item = conversation["intake"]
    if existing_draft:
        conversation = _chat.save_draft(*scope(owner), conversation["id"], item["id"], editor(conversation), "integration-editor-before-preflight")
    before = ui_rows(repo)
    chat = LiveConversationService(intake)
    with pytest.raises(CoreError) as rejected:
        await chat.send_async(*scope(owner), "Chị muốn số hóa bán hàng và tồn kho.", [], "integration-no-consent",
            conversation_id=conversation["id"], target_intake_id=item["id"],
            draft={"intake_id": item["id"], **editor(conversation)}, paid_consent=False)
    assert rejected.value.code == "PAID_CONSENT_REQUIRED"
    assert ui_rows(repo) == before and not model.calls
    assert len(before) == (1 if existing_draft else 0)
    if existing_draft:
        assert ui_rows(repo)[0]["ui_revision"] == 1


@pytest.mark.asyncio
async def test_main_fake_send_saves_ui_once_and_never_sends_ui_cas_metadata_to_model(integrated):
    repo, owner, model, _provider, _intake, chat, _registry = integrated
    conversation = prepared(integrated)
    item = conversation["intake"]
    result = await chat.send_async(*scope(owner), "Chị muốn số hóa bán hàng và tồn kho.", [], "integration-one-fake-send",
        conversation_id=conversation["id"], target_intake_id=item["id"],
        draft={"intake_id": item["id"], **editor(conversation)}, paid_consent=True, task_hint="sales_inventory")
    rows = ui_rows(repo)
    assert len(rows) == 1 and rows[0]["ui_revision"] == 1
    assert result["drafts"][item["id"]]["ui_revision"] == 1
    assert len(model.calls) == 1
    sent = model.calls[0][1]["input"]
    assert sent["draft"] and sent["draft"]["intake_id"] == item["id"]
    assert not {"base_review_revision", "ui_revision"} & sent["draft"].keys()
    assert "base_review_revision" not in json.dumps(sent) and "ui_revision" not in json.dumps(sent)
    # This request consumes only the injected model fixture, never an API key.
    assert result["workspace_view"]["billing"]["local_review_model_calls"] == 0


@pytest.mark.asyncio
@pytest.mark.parametrize("tool", ["save_conversation_draft", "prepare_chat_draft", "confirm_intake", "send_message"])
async def test_external_old_clients_without_cas_are_rejected_before_mutation(integrated, tool):
    repo, owner, model, _provider, _intake, _chat, registry = integrated
    conversation = prepared(integrated)
    item = conversation["intake"]
    draft = {key: value for key, value in editor(conversation).items() if key not in {"base_review_revision", "ui_revision"}}
    common = {"enterprise_id": owner["enterprise_id"], "operation_id": "integration-old-" + tool}
    if tool == "save_conversation_draft":
        args = {**common, "conversation_id": conversation["id"], "intake_id": item["id"], "draft": draft}
    elif tool == "prepare_chat_draft":
        args = {**common, "conversation_id": conversation["id"], "target_intake_id": item["id"],
                "text": "Chị muốn số hóa bán hàng và tồn kho.", "task_hint": "sales_inventory",
                "draft": {"intake_id": item["id"], **draft}}
    elif tool == "confirm_intake":
        candidate = next(c for c in item["candidates"] if c["field"] == "trading_name")
        args = {**common, "intake_id": item["id"], "selected_fact_ids": [candidate["id"]],
                "expected_entity_versions": item["expected_entity_versions"]}
    else:
        args = {**common, "conversation_id": conversation["id"], "target_intake_id": item["id"],
                "text": "Chị muốn số hóa bán hàng và tồn kho.", "attachments": [], "task_hint": "sales_inventory",
                "draft": {"intake_id": item["id"], **draft}, "paid_consent": True}
    before = ui_rows(repo)
    with pytest.raises(CoreError) as rejected:
        await registry.tools[tool](**args)
    assert rejected.value.code == "CLIENT_UPGRADE_REQUIRED"
    if tool == "confirm_intake":
        assert rejected.value.commit_state == "not_committed"
    assert ui_rows(repo) == before == [] and not model.calls
    assert repo.get_context(*scope(owner))["fact_refs"] == []
