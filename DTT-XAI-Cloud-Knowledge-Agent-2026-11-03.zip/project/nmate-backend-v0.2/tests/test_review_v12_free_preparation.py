"""One rollback/error contract for free chat, document and continuations."""
import httpx
import pytest

from nmate.main.app import make_main_app
from nmate.v03.core import CoreError
from test_core_policy_http import call, good, register, running
from test_review_commands_v2 import data_snapshot
from test_review_v12_intake import local_only_services  # noqa: F401
from test_workspace_management import attachment, pdf_bytes


@pytest.fixture
def free_workspace(tmp_path):
    async def forbidden(*args, **kwargs):
        raise AssertionError("Free preparation must never dispatch a model")
    app = make_main_app(tmp_path / "free-preparation.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("free-v12-owner", "Local-only-fixture-123", "Cơ sở thử")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    products = [app.state.repo.create_entity(account, enterprise, "product", name) for name in
                ["Trà Sen Tây Hồ (THỬ NGHIỆM)", "Bột sen (THỬ NGHIỆM)", "Mứt sen sấy", "Hồng Hà", "Bắc Sơn"]]
    return app, account, enterprise, products


def test_exact_reported_free_chat_conflict_is_typed_rollback_and_offers_owned_target(free_workspace):
    app, account, enterprise, products = free_workspace
    text = "THỬ NGHIỆM: Bột sen (THỬ NGHIỆM) khối lượng tịnh 200 g, mã BS-02, bao bì túi zip."
    before = data_snapshot(app.state.repo)
    for _ in range(2):
        with pytest.raises(CoreError) as blocked:
            app.state.core_extension.conversations.prepare_chat_draft(account, enterprise, text,
                "free-conflicting-product", product_entity_id=products[0]["id"], task_hint="profile_intake")
        assert blocked.value.code == "product_selection_conflict"
        assert blocked.value.commit_state == "not_committed"
        assert blocked.value.details["kind"] == "product_selection_required"
        assert blocked.value.details["matched_entities"] == [{k: products[1][k] for k in ("id", "name", "version")}]
        assert data_snapshot(app.state.repo) == before
    value = app.state.core_extension.conversations.prepare_chat_draft(account, enterprise, text,
        "free-owner-selected-product", product_entity_id=products[1]["id"], task_hint="profile_intake")
    assert value["intake"]["product"]["id"] == products[1]["id"]
    assert {c["field"] for c in value["intake"]["candidates"]} == {"name", "net_quantity", "product_code", "packaging"}
    assert app.state.repo.get_context(account, enterprise)["fact_refs"] == []


def test_ambiguous_reference_can_only_continue_after_owner_selects_an_offered_id(free_workspace):
    app, account, enterprise, products = free_workspace
    service = app.state.core_extension.conversations
    text = "Chị xem hồ sơ Hồng Hà và Bắc Sơn để đối chiếu tồn kho."
    before = data_snapshot(app.state.repo)
    with pytest.raises(CoreError) as blocked:
        service.prepare_chat_draft(account, enterprise, text, "free-ambiguous-reference", task_hint="profile_intake")
    assert blocked.value.code == "ambiguous_product" and blocked.value.commit_state == "not_committed"
    assert {c["id"] for c in blocked.value.details["matched_entities"]} == {products[3]["id"], products[4]["id"]}
    assert data_snapshot(app.state.repo) == before
    chosen = service.prepare_chat_draft(account, enterprise, text, "free-explicit-reference", product_entity_id=products[3]["id"])
    assert chosen["intake"]["product"]["id"] == products[3]["id"]
    with pytest.raises(CoreError) as unoffered:
        service.prepare_chat_draft(account, enterprise, text, "free-unoffered-reference", product_entity_id=products[0]["id"])
    assert unoffered.value.code == "ambiguous_product" and unoffered.value.commit_state == "not_committed"


@pytest.mark.parametrize("continuation", [False, True])
def test_typed_failure_after_intake_writes_rolls_back_all_free_state(free_workspace, monkeypatch, continuation):
    app, account, enterprise, products = free_workspace
    service = app.state.core_extension.conversations
    original = service.prepare_chat_draft(account, enterprise, "Tên sản phẩm: Bột sen (THỬ NGHIỆM)",
                                         "initial-free-draft") if continuation else None
    before = data_snapshot(app.state.repo)
    def rejected(*args, **kwargs):
        raise CoreError("LOCAL_REVIEW_REJECTED", "Dữ kiện cần đối chiếu; chưa ghi thay đổi.", 409)
    monkeypatch.setattr(service.free_intake, "refresh_dialogue", rejected)
    with pytest.raises(CoreError) as blocked:
        service.prepare_chat_draft(account, enterprise, "Tên sản phẩm: Mứt sen sấy; Lượng tịnh: 200 g",
            "free-domain-rejected", conversation_id=original["id"] if original else None)
    assert blocked.value.commit_state == "not_committed"
    assert data_snapshot(app.state.repo) == before


def test_uncertain_io_and_replay_read_failure_are_not_declared_rolled_back(free_workspace, monkeypatch):
    app, account, enterprise, _ = free_workspace
    service = app.state.core_extension.conversations
    text, op = "Tên sản phẩm: Bột sen (THỬ NGHIỆM)", "free-success-for-replay"
    service.prepare_chat_draft(account, enterprise, text, op)
    before = data_snapshot(app.state.repo)
    def read_failed(*args, **kwargs):
        raise CoreError("READ_PROJECTION_FAILED", "Chưa đọc được kết quả đã lưu.", 409)
    monkeypatch.setattr(service.free_conversations, "_view", read_failed)
    with pytest.raises(CoreError) as old_receipt:
        service.prepare_chat_draft(account, enterprise, text, op)
    assert getattr(old_receipt.value, "commit_state", None) not in {"not_started", "not_committed"}
    assert data_snapshot(app.state.repo) == before
    def io_failed(*args, **kwargs):
        raise OSError("Synthetic transport/IO uncertainty")
    monkeypatch.setattr(service.free_intake, "refresh_dialogue", io_failed)
    with pytest.raises(OSError) as unknown:
        service.prepare_chat_draft(account, enterprise, text, "free-uncertain-io")
    assert getattr(unknown.value, "commit_state", None) is None
    assert data_snapshot(app.state.repo) == before


def test_free_rollback_and_selection_details_cross_actual_http_mcp(tmp_path):
    async def forbidden(*args, **kwargs):
        raise AssertionError("No paid provider is allowed")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "free-v12-http-owner")
            tea = good(web, url, session, "core_create_entity", entity_type="product", name="Trà Sen Tây Hồ", operation_id="free-http-tea")
            powder = good(web, url, session, "core_create_entity", entity_type="product", name="Bột sen", operation_id="free-http-powder")
            before = data_snapshot(app.state.repo)
            result = call(web, url, session, "prepare_chat_draft", text="Bột sen khối lượng tịnh 200 g", operation_id="free-http-conflict",
                          product_entity_id=tea["id"], task_hint="profile_intake")
            assert not result["ok"] and result["error"]["commit_state"] == "not_committed"
            assert result["error"]["details"]["matched_entities"] == [{k: powder[k] for k in ("id", "name", "version")}]
            assert data_snapshot(app.state.repo) == before
            # Documents now use the exact same free-UoW error taxonomy.
            files = [attachment(pdf_bytes(["Tên sản phẩm: Bột sen"])), attachment(pdf_bytes(["Tên sản phẩm: Mứt sen"]), "mut.pdf")]
            rejected = call(web, url, session, "prepare_document_draft", text="Chị đọc các tệp", attachments=files,
                            operation_id="free-http-document-conflict")
            assert not rejected["ok"] and rejected["error"]["commit_state"] == "not_committed"
            assert data_snapshot(app.state.repo) == before


def test_http_tool_prevalidation_distinguishes_new_request_from_committed_replay(tmp_path):
    async def forbidden(*args, **kwargs):
        raise AssertionError("Tool prevalidation must not dispatch AI")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "free-v12-validation-owner")
            before = data_snapshot(app.state.repo)
            invalid = call(web, url, session, "prepare_chat_draft", text="Bột sen khối lượng tịnh 200 g",
                           operation_id="invalid-before-free-command", draft={"selected": []})
            assert invalid["error"]["code"] == "invalid_draft"
            assert invalid["error"]["commit_state"] == "not_started"
            assert data_snapshot(app.state.repo) == before
            text, operation = "Bột sen khối lượng tịnh 200 g", "committed-before-validation"
            value = good(web, url, session, "prepare_chat_draft", text=text, operation_id=operation)
            malformed = {"intake_id": value["intake"]["id"], "selected": []}
            after = data_snapshot(app.state.repo)
            new = call(web, url, session, "prepare_chat_draft", text=text, operation_id="new-client-upgrade-rejected", draft=malformed)
            assert new["error"]["code"] == "CLIENT_UPGRADE_REQUIRED"
            assert new["error"]["commit_state"] == "not_started"
            old = call(web, url, session, "prepare_chat_draft", text=text, operation_id=operation, draft=malformed)
            assert old["error"]["code"] == "CLIENT_UPGRADE_REQUIRED"
            assert old["error"].get("commit_state") not in {"not_started", "not_committed"}
            assert data_snapshot(app.state.repo) == after


def test_http_postcommit_projection_failure_never_claims_free_command_rolled_back(tmp_path, monkeypatch):
    async def forbidden(*args, **kwargs):
        raise AssertionError("Postcommit free read must not dispatch AI")
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "free-v12-postcommit-owner")
            text, operation = "Bột sen khối lượng tịnh 200 g", "free-committed-read-failed"
            def read_failed(*args, **kwargs):
                raise CoreError("POSTCOMMIT_READ_FAILED", "Chưa đọc được kết quả đã lưu.", 409)
            with monkeypatch.context() as current:
                current.setattr(app.state.core_extension, "get_chat", read_failed)
                result = call(web, url, session, "prepare_chat_draft", text=text, operation_id=operation)
            assert result["error"]["code"] == "POSTCOMMIT_READ_FAILED"
            assert result["error"].get("commit_state") not in {"not_started", "not_committed"}
            account, enterprise = session["account"]["id"], session["enterprise"]["id"]
            with app.state.repo.connection() as db:
                saved = db.execute("SELECT 1 FROM v03_operations WHERE account_id=? AND enterprise_id=? "
                    "AND kind='v04_conversation_send' AND operation_id=?", (account, enterprise, operation)).fetchall()
                assert len(saved) == 1
            before = data_snapshot(app.state.repo)
            replay = good(web, url, session, "prepare_chat_draft", text=text, operation_id=operation)
            assert replay["intake"] and not replay.get("pending_operation_id")
            assert data_snapshot(app.state.repo) == before

