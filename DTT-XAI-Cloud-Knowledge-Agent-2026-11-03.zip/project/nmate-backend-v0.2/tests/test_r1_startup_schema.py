"""DF-041: managed startup verifies compatibility before schema/seed writers."""
from pathlib import Path
import json
import sqlite3
import sys
from types import SimpleNamespace

import pytest

from nmate.core_v1.runtime_schema import (
    RuntimeSchemaError, managed_runtime, read_runtime_contract, verify_runtime_database,
)
from nmate.main.app import make_main_app


def denied(*args, **kwargs):
    raise AssertionError("No provider is authorized in startup tests")


@pytest.fixture
def ready(tmp_path):
    path = tmp_path / "private.sqlite3"
    app = make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    return path, app


def snapshot(path):
    with sqlite3.connect(path) as db:
        return list(db.iterdump())


def test_readiness_is_read_only_and_accepts_private_factory_schema(ready):
    path, _app = ready
    before = snapshot(path)
    result = verify_runtime_database(path)
    assert result["schema_version"] == "runtime-schema-readiness/1"
    # 0.5 adds three private policy-draft tables, with no business seed.
    assert result["ready"] is True and result["required_table_count"] == 95
    assert snapshot(path) == before


def test_missing_db_fails_without_creating_file_or_parent(tmp_path):
    path = tmp_path / "missing" / "enterprise.sqlite3"
    with pytest.raises(RuntimeSchemaError, match="khởi tạo"):
        verify_runtime_database(path)
    assert not path.parent.exists()


@pytest.mark.parametrize("mutation", [
    'DROP TABLE main_operations',
    'ALTER TABLE main_operations ADD COLUMN unexpected TEXT',
    'CREATE TABLE unregistered_writer(id TEXT)',
    'CREATE INDEX drift_index ON v03_entities(name)',
])
def test_unknown_or_missing_schema_refuses_without_repair(ready, mutation):
    path, _app = ready
    with sqlite3.connect(path) as db:
        db.execute(mutation)
    before = snapshot(path)
    with pytest.raises(RuntimeSchemaError, match="schema"):
        verify_runtime_database(path)
    assert snapshot(path) == before


@pytest.mark.parametrize("table,condition", [
    ("pol_aliases", "1=1"),
    ("v03_domain_references", "1=1"),
    ("core_v1_field_definitions", "field_key='name'"),
    ("pol_refresh_jobs", "1=1"),
])
def test_missing_managed_seed_refuses_and_never_reinstalls_it(ready, table, condition):
    path, _app = ready
    with sqlite3.connect(path) as db:
        db.execute(f"DELETE FROM {table} WHERE {condition}")
    before = snapshot(path)
    with pytest.raises(RuntimeSchemaError, match="khởi tạo|nguồn"):
        verify_runtime_database(path)
    assert snapshot(path) == before


def test_mutable_source_state_and_disabled_schedule_are_not_pinned(ready):
    path, _app = ready
    with sqlite3.connect(path) as db:
        db.execute("UPDATE pol_sources SET metadata_json='{}'")
        db.execute("UPDATE pol_refresh_jobs SET enabled=0")
    before = snapshot(path)
    assert verify_runtime_database(path)["ready"]
    assert snapshot(path) == before


def test_managed_factory_does_not_seed_or_enrich_and_context_does_not_leak(ready, tmp_path):
    path, _app = ready
    with sqlite3.connect(path) as db:
        db.execute("UPDATE pol_sources SET metadata_json='{}'")
        db.execute("UPDATE pol_refresh_jobs SET enabled=0")
    before = snapshot(path)
    verify_runtime_database(path)
    with managed_runtime():
        second = make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    assert second.state.repo.managed_runtime is True
    assert snapshot(path) == before
    fresh = make_main_app(tmp_path / "separate-explicit-bootstrap.sqlite3", request_fn=denied,
                          gateway_request_fn=denied)
    assert fresh.state.repo.managed_runtime is False
    assert verify_runtime_database(Path(fresh.state.repo.db_path))["ready"]


def test_managed_factory_does_not_recreate_deleted_seed_when_called_directly(ready):
    path, _app = ready
    with sqlite3.connect(path) as db:
        db.execute("DELETE FROM pol_aliases")
        db.execute("DELETE FROM v03_domain_references")
        db.execute("DELETE FROM core_v1_field_definitions")
        db.execute("DELETE FROM pol_refresh_jobs")
    before = snapshot(path)
    with managed_runtime():
        make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    assert snapshot(path) == before


def test_contract_file_is_versioned_and_has_no_private_account_or_business_seed():
    contract = read_runtime_contract()
    assert contract["version"] == "nmate-main-20261026-v17"
    assert contract["schema_version"] == "runtime-schema-contract/1"
    assert {item["table"] for item in contract["required_seeds"]}.isdisjoint({
        "v03_accounts", "v03_fact_assertions", "core_budget_grants", "pol_knowledge_roles"})
    assert "password" not in json.dumps(contract).casefold().replace("password_hash", "")


@pytest.mark.parametrize("existing", [False, True])
def test_cli_schema_rejection_is_clear_and_precedes_key_network_and_factory(tmp_path, monkeypatch, existing):
    from nmate import config
    from nmate.main import app, local
    path = tmp_path / "enterprise.sqlite3"
    if existing:
        with sqlite3.connect(path) as db:
            db.execute("CREATE TABLE incompatible(id TEXT)")
    before = path.read_bytes() if existing else None
    calls = []
    def secret():
        calls.append("read-secret")
        raise AssertionError("Schema rejection must precede secret access")
    settings = SimpleNamespace(model_provider="anthropic", model_configured=True,
                               simple_model="claude-sonnet-5-5", complex_model="claude-opus-5-5",
                               anthropic_api_key=SimpleNamespace(get_secret_value=secret))
    monkeypatch.setattr(config, "Settings", lambda **kwargs: settings)
    monkeypatch.setattr(sys, "argv", ["main", "--data-dir", str(tmp_path)])
    monkeypatch.setattr(local, "network_guard", lambda: calls.append("network"))
    monkeypatch.setattr(app, "make_main_app", lambda *args, **kwargs: calls.append("factory"))
    with pytest.raises(SystemExit, match="khởi tạo|schema"):
        local.main()
    assert calls == []
    assert (path.read_bytes() if path.exists() else None) == before
