"""M6 uses original authority, durable checkpoints and explicit human resume."""
import json
import pytest
from test_knowledge_m1 import kb
from nmate.v03.core import CoreError
from nmate.knowledge_v1.public_batch import prepare,issue_grant,pause_after_failure,existing_repository
from nmate.knowledge_v1 import worker_m6

@pytest.fixture
def batch(kb,tmp_path,monkeypatch):
    from nmate.knowledge_v1 import public_batch
    repo,_,actor,other,_=kb
    with repo.connection(write=True) as db:db.execute("UPDATE v03_accounts SET username='trung@dtt.vn' WHERE id=?",(other,))
    monkeypatch.setattr(public_batch,'_APPROVAL_REGISTRY_DIR',tmp_path/'TEST-ONLY-registry')
    folder=tmp_path/'batch';prepared=prepare(repo.db_path,folder);grant=issue_grant(prepared,folder)
    from nmate.knowledge_v1.operator_m6 import install_m6
    install_m6(prepared['database'],prepared=prepared,backup_path=folder/'TEST-before-M6.sqlite')
    calls=[]
    async def request(model,body,limit):
        calls.append((model,body,limit))
        quote=body['input']['source_excerpts'][0]['ref']['quote'][:160]
        return dict(text=json.dumps(dict(title='THỬ NGHIỆM nháp',claims=[dict(kind='source_excerpt',text=quote,
          evidence=[dict(evidence_id='1',quote=quote)])],gaps=['THỬ NGHIỆM chưa đủ toàn văn'],questions_for_expert=[]),ensure_ascii=False),
          model=model,stop_reason='end_turn',usage=dict(input_tokens=100,output_tokens=100))
    return folder,prepared,grant,request,calls

def decision(status,key='TEST-human-decision-1'):
    return dict(schema_version='knowledge-batch-resume/1',decision_id=key,approved_by='project_owner_operator',
      grant_id=status['grant_id'],batch_instance_id=status['batch_instance_id'],corpus_hash=status['corpus_hash'],
      pause_set_hash=status['pause_set_hash'],expires_at=status['expires_at'],remaining_slots=status['remaining_slots'],
      no_retry=True,no_new_sources=True,no_publication=True)

@pytest.mark.asyncio
async def test_single_step_checkpoint_restart_is_readonly_and_never_repeats_slot(batch):
    folder,prepared,grant,request,calls=batch
    first=await worker_m6.run_once(folder,request_fn=request)
    assert first['after']['completed_slots']==['S1'] and len(calls)==1
    repo=existing_repository(prepared)
    with repo.connection() as db:before=list(db.iterdump())
    status=worker_m6.snapshot(folder)
    with repo.connection() as db:assert list(db.iterdump())==before
    assert status['next_slot']=='S2' and status['provider_calls']==1
    second=await worker_m6.run_once(folder,request_fn=request)
    assert second['after']['completed_slots']==['S1','S2'] and len(calls)==2

@pytest.mark.asyncio
async def test_unknown_outcome_is_durable_stop_not_retry_or_next_slot(batch):
    folder,prepared,grant,_,calls=batch
    async def timeout(*args):calls.append('timeout');raise TimeoutError('TEST ONLY')
    await worker_m6.run_once(folder,request_fn=timeout)
    assert len(calls)==1
    old=worker_m6.snapshot(folder);assert old['grant_state']=='paused_admission_review'
    await worker_m6.run_once(folder,request_fn=timeout)
    assert len(calls)==1 and worker_m6.snapshot(folder)['next_slot'] is None
    with pytest.raises(CoreError):worker_m6.resume(folder,decision(old))

@pytest.mark.asyncio
async def test_recovered_proposal_requires_explicit_resume_without_changing_terms(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=existing_repository(prepared)
    with repo.connection() as db:attempt=db.execute('SELECT id FROM core_domain_model_attempts').fetchone()[0]
    pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='TEST manual admission review')
    old=worker_m6.snapshot(folder)
    assert old['next_slot'] is None and old['remaining_slots']==['S2','S3','S4','O1','O2']
    with repo.connection() as db:
        grant_before=dict(db.execute('SELECT * FROM core_domain_budget_grants').fetchone())
        scope_before=dict(db.execute('SELECT * FROM core_domain_grant_scopes').fetchone())
    receipt=worker_m6.resume(folder,decision(old))
    assert worker_m6.resume(folder,decision(old))==receipt  # exact replay, no second mutation
    with repo.connection() as db:
        new=dict(db.execute('SELECT * FROM core_domain_budget_grants').fetchone())
        assert {k:v for k,v in new.items() if k!='state'}=={k:v for k,v in grant_before.items() if k!='state'}
        assert dict(db.execute('SELECT * FROM core_domain_grant_scopes').fetchone())==scope_before
    assert len(calls)==1 and worker_m6.snapshot(folder)['next_slot']=='S2'

@pytest.mark.asyncio
async def test_changed_decision_and_stale_pause_cannot_resume(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=existing_repository(prepared)
    with repo.connection() as db:attempt=db.execute('SELECT id FROM core_domain_model_attempts').fetchone()[0]
    pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='TEST pause')
    status=worker_m6.snapshot(folder);args=decision(status)
    for change in ({'expires_at':'2099-01-01T00:00:00+00:00'},{'corpus_hash':'0'*64},{'remaining_slots':['S1','S2']},{'pause_set_hash':'0'*64}):
        with pytest.raises(CoreError):worker_m6.resume(folder,args|change)
    worker_m6.resume(folder,args)
    with pytest.raises(CoreError):worker_m6.resume(folder,args|{'no_publication':False})
    assert len(calls)==1

@pytest.mark.asyncio
async def test_single_worker_os_lock_blocks_before_any_provider(batch):
    folder,prepared,grant,request,calls=batch
    from nmate.main.runtime_lock import EnterpriseRuntimeLock,RuntimeAlreadyRunning
    with EnterpriseRuntimeLock(prepared['database']):
        with pytest.raises(RuntimeAlreadyRunning):await worker_m6.run_once(folder,request_fn=request)
    assert calls==[]

@pytest.mark.asyncio
async def test_finite_full_batch_uses_same_ledger_and_critics_receive_saved_inputs(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request,max_new_calls=6)
    status=worker_m6.snapshot(folder)
    assert status['completed_slots']==['S1','S2','S3','S4','O1','O2'] and status['next_slot'] is None
    assert len(calls)==6 and len(calls[4][1]['input']['prior_proposals'])==2 and len(calls[5][1]['input']['prior_proposals'])==2
    await worker_m6.run_once(folder,request_fn=request,max_new_calls=6)
    assert len(calls)==6
    repo=existing_repository(prepared)
    with repo.connection() as db:
        assert db.execute('SELECT count(*) FROM v03_enterprises').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM kp_wiki_pages').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM pol_wiki_reviews').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM core_model_attempts').fetchone()[0]==0

@pytest.mark.asyncio
async def test_source_revoke_blocks_status_run_and_resume_before_provider(batch):
    folder,prepared,grant,request,calls=batch
    repo=existing_repository(prepared)
    from nmate.knowledge_v1.governance import WikiGovernance
    service=WikiGovernance(repo)
    from nmate.knowledge_v1.public_batch import OPERATOR
    service.set_source_rights(OPERATOR,prepared['corpus'][0]['source_id'],expected_version=1,allow_read=False,allow_export=False,reason='TEST revoke',operation_id='test-revoke-m6')
    with pytest.raises(CoreError):worker_m6.snapshot(folder)
    with pytest.raises(CoreError):await worker_m6.run_once(folder,request_fn=request)
    assert calls==[]

@pytest.mark.asyncio
async def test_export_revocation_keeps_checkpoint_and_exact_resume_receipt_readable(batch):
    folder,prepared,grant,request,calls=batch
    await worker_m6.run_once(folder,request_fn=request)
    repo=existing_repository(prepared)
    with repo.connection() as db:attempt=db.execute('SELECT id FROM core_domain_model_attempts').fetchone()[0]
    pause_after_failure(repo,grant['id'],attempt,operator='TEST',reason='TEST review')
    args=decision(worker_m6.snapshot(folder));receipt=worker_m6.resume(folder,args)
    from nmate.knowledge_v1.governance import WikiGovernance
    from nmate.knowledge_v1.public_batch import OPERATOR
    WikiGovernance(repo).set_source_rights(OPERATOR,prepared['corpus'][0]['source_id'],expected_version=1,
      allow_read=True,allow_export=False,reason='TEST export revoke',operation_id='test-export-stop')
    assert worker_m6.snapshot(folder)['provider_calls']==1
    assert worker_m6.resume(folder,args)==receipt
    with pytest.raises(CoreError):await worker_m6.run_once(folder,request_fn=request)
    assert len(calls)==1

@pytest.mark.asyncio
async def test_expiry_stops_without_changing_original_expiry_or_loading_key(batch,monkeypatch):
    folder,prepared,grant,request,calls=batch
    monkeypatch.setattr(worker_m6,'now_iso',lambda:'2099-01-01T00:00:00+00:00')
    result=await worker_m6.run_once(folder,request_fn=request,env_file=folder/'MUST-NOT-READ.env')
    assert result['state']=='stopped_no_dispatch' and result['after']['expires_at']==grant['expires_at'] and calls==[]

@pytest.mark.asyncio
async def test_hard_process_exit_after_response_before_proposal_needs_explicit_resume(batch):
    import subprocess,sys,os
    from nmate.knowledge_v1 import public_batch
    folder,prepared,grant,request,calls=batch
    code='''
import asyncio,json,os,sys
from pathlib import Path
from nmate.knowledge_v1 import public_batch,worker_m6
public_batch._APPROVAL_REGISTRY_DIR=Path(sys.argv[2])
async def request(model,body,limit):
    Path(sys.argv[1],'TEST-provider-called').write_text('one fake SDK call')
    q=body['input']['source_excerpts'][0]['ref']['quote'][:160]
    return dict(text=json.dumps(dict(title='TEST',claims=[dict(kind='source_excerpt',text=q,evidence=[dict(evidence_id='1',quote=q)])],gaps=[],questions_for_expert=[])),model=model,stop_reason='end_turn',usage=dict(input_tokens=100,output_tokens=100))
public_batch.record_proposal=lambda *a,**kw:os._exit(41)
asyncio.run(worker_m6.run_once(sys.argv[1],request_fn=request))
'''
    result=subprocess.run([sys.executable,'-B','-X','utf8','-c',code,str(folder),str(public_batch._APPROVAL_REGISTRY_DIR)],
      capture_output=True,text=True,timeout=30,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    assert result.returncode==41,result.stderr
    interrupted=worker_m6.snapshot(folder)
    assert interrupted['grant_state']=='active' and interrupted['blocked_slots']==['S1'] and interrupted['provider_calls']==1
    await worker_m6.run_once(folder,request_fn=request)
    stopped=worker_m6.snapshot(folder)
    assert stopped['grant_state']=='paused_admission_review' and calls==[]
    from nmate.knowledge_v1.ai_proposals import record_proposal
    from nmate.knowledge_v1.governance import WikiGovernance
    from nmate.core_v1.gateway import ModelGateway
    repo=existing_repository(prepared)
    record_proposal(WikiGovernance(repo),ModelGateway(repo,enabled=False),prepared['account_id'],stopped['attempts'][0]['id'])
    assert worker_m6.snapshot(folder)['next_slot'] is None
    assert calls==[] and (folder/'TEST-provider-called').exists()
