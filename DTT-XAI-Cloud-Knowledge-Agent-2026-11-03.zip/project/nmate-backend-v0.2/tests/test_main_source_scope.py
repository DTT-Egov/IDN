"""Source-gap refusal commits neither paid permission nor queued work."""
import json
from types import SimpleNamespace

import pytest

from nmate.v03.core import CoreError
from nmate.v03.missions import MissionService
from test_unified_main import setup as setup_fixture, scope, docs
from test_v03_live_review import TEA, intake as export_intake


@pytest.fixture(name="workspace")
def main_workspace(tmp_path):
    return setup_fixture.__wrapped__(tmp_path)


def test_main_override_refuses_unsupported_source_scope_before_start_receipt(workspace):
    repo, owner, _, model, provider, missions, _, _ = workspace
    planned = MissionService(repo).prepare(*scope(owner),
        "Tôi có Trà Sen Tây Hồ gửi Mỹ, sản phẩm cần chứng nhận gì?", "unsupported-prepare")
    current = missions.get(*scope(owner), planned["id"])
    assert current["research_scope"]["can_start_research"] is False
    with pytest.raises(CoreError, match="Chưa đủ nguồn") as error:
        missions.start(*scope(owner), planned["id"], "unsupported-start")
    assert error.value.code == "research_source_gap"
    assert missions.get(*scope(owner), planned["id"])["status"] == "planned"
    assert provider.summary()["provider_attempts"] == 0 and model.calls == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM main_research_authorizations WHERE mission_id=?", (planned["id"],)).fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM v03_mission_operations WHERE mission_id=? AND kind='start'", (planned["id"],)).fetchone()[0] == 0


@pytest.mark.asyncio
async def test_main_free_refresh_includes_the_explicit_us_prior_notice_topic(workspace):
    _, owner, _, _, provider, missions, _, chat = workspace
    conversation = await docs(workspace)
    refreshed = []

    async def refresh(account, enterprise, market, topics):
        refreshed.append((account, enterprise, market, topics))

    async def model(model_name, payload, limit):
        data = export_intake()
        data["outcomes"].append({"id": "prior_notice", "question_quote": "thông báo trước"})
        return {"text": json.dumps(data, ensure_ascii=False), "model": model_name,
                "request_id": "unit-explicit-prior", "stop_reason": "end_turn",
                "usage": {"input_tokens": 1, "output_tokens": 1}}

    missions.source_refresher = SimpleNamespace(latest_checks=lambda source_ids: [])
    missions.refresh_sources_async = refresh
    provider._request_override = model
    planned = await chat.send_async(*scope(owner), TEA + " Ai nộp thông báo trước và khi nào?", [],
        "source-refresh-prior", conversation["id"], conversation["intake"]["product"]["id"],
        paid_consent=True, task_hint="export_research", market_code="US")
    assert len(refreshed) == 1 and set(refreshed[0][3]) == {"facility_registration", "food_label", "prior_notice"}
    assert set(planned["missions"][0]["knowledge"]["coverage"]["requested"]) == {"facility_registration", "food_label", "prior_notice"}
