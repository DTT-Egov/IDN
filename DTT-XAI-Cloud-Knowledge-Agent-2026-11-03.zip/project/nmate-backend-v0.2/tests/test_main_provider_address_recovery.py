"""Exact static address contracts survive preference changes; no retry path."""
import copy
import hashlib
import json

import pytest

from nmate.main.provider import MainProvider, _decorate_main_intake
from nmate.v03.core import CoreError, CoreRepository, json_text
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "address-recovery.sqlite3")
    owner = LocalAccounts(repo).register("address-owner", "Local-only-password-2026", "Trà Sen")
    other = LocalAccounts(repo).register("address-other", "Local-only-password-2026", "Khác")
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE main_account_preferences(account_id TEXT PRIMARY KEY,display_name TEXT NOT NULL,preferred_address TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL)")
        db.execute("INSERT INTO main_account_preferences VALUES(?,?,?,1,'2026-10-22')", (owner["account_id"], "Chủ cơ sở", "anh"))
    return repo, owner, other


def request(kind):
    return {"instructions_vi": "Chỉ trả JSON theo schema.", "response_schema": {"type": "object"},
            "input": {"current_question" if kind == "intake" else "question": "Cần chuẩn bị hồ sơ.",
                      "ssot_context": {"values": {"net_quantity": "100g"}}}}


def snapshot(repo):
    with repo.connection() as db:
        return [tuple(row) for row in db.execute("SELECT * FROM v03_live_attempts ORDER BY id")]


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", ["intake", "research"])
async def test_recorded_address_contract_recovers_after_preference_change_and_restart_without_dispatch(workspace, kind):
    repo, owner, other = workspace
    calls = []

    async def injected(model, payload, max_tokens):
        calls.append(copy.deepcopy(payload))
        return {"text": json.dumps({"result": "saved"}), "usage": {"input_tokens": 1, "output_tokens": 1}}

    provider = MainProvider(repo, request_fn=injected)
    kwargs = {"operation_id": "original-address", "account_id": owner["account_id"], "enterprise_id": owner["enterprise_id"]}
    original = request(kind)
    expected = await provider(kind, original, **kwargs)
    assert "gọi chủ cơ sở là anh" in calls[0]["instructions_vi"]
    assert "gọi chủ cơ sở" not in original["instructions_vi"]
    with repo.connection(write=True) as db:
        db.execute("UPDATE main_account_preferences SET preferred_address='bác',revision=2 WHERE account_id=?", (owner["account_id"],))

    async def forbidden(*args, **kwargs):
        raise AssertionError("Cache recovery must never dispatch")

    restarted = MainProvider(repo, request_fn=forbidden)
    before = snapshot(repo)
    token = restarted.recorded_only.set(True)
    try:
        assert await restarted(kind, original, **kwargs) == expected
        for mutate in ("question", "ssot", "instructions", "owner"):
            changed, scope = copy.deepcopy(original), dict(kwargs)
            if mutate == "question":
                key = "current_question" if kind == "intake" else "question"
                changed["input"][key] += " Đã đổi."
            elif mutate == "ssot":
                changed["input"]["ssot_context"]["values"]["net_quantity"] = "200g"
            elif mutate == "instructions":
                changed["instructions_vi"] += " Bỏ kiểm chứng."
            else:
                scope.update(account_id=other["account_id"], enterprise_id=other["enterprise_id"])
            with pytest.raises(CoreError) as refused:
                await restarted(kind, changed, **scope)
            assert refused.value.code == "RECORDED_CONTEXT_CHANGED"
    finally:
        restarted.recorded_only.reset(token)
    assert snapshot(repo) == before and len(calls) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("kind", ["intake", "research"])
async def test_historic_request_without_address_decoration_remains_exactly_recoverable(workspace, kind):
    repo, owner, _ = workspace

    async def forbidden(*args, **kwargs):
        raise AssertionError("Historic receipt has no dispatch path")

    provider = MainProvider(repo, request_fn=forbidden)
    original = request(kind)
    canonical = _decorate_main_intake(copy.deepcopy(original), None) if kind == "intake" else original
    digest = hashlib.sha256(json_text(canonical).encode()).hexdigest()
    envelope = {"data": {"result": "historic"}, "attempt_id": "historic-no-address", "model": "claude-sonnet-5-5"}
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,model,state,response_json,created_at) VALUES(?,?,?,?,?,?,?,'succeeded',?,'2026-10-21')",
                   (envelope["attempt_id"], owner["account_id"], owner["enterprise_id"], "historic", kind, digest, envelope["model"], json_text(envelope)))
    before = snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        assert await provider(kind, original, operation_id="historic", account_id=owner["account_id"], enterprise_id=owner["enterprise_id"]) == envelope
    finally:
        provider.recorded_only.reset(token)
    assert snapshot(repo) == before
