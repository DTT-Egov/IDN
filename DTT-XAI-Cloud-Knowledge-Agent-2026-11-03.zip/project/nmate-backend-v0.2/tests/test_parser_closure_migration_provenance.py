"""Migration audit identity must change with classifier dependencies, not UI code."""
import hashlib
import json
from pathlib import Path

import pytest

from nmate.core_v1 import review_migration
from nmate.v03.core import CoreRepository
from nmate.v04.conversations import ConversationService
from nmate.v04.intake import IntakeService


def test_classifier_dependency_change_changes_audit_identity(tmp_path):
    source_root = tmp_path / "sources"
    for name in review_migration.POLICY_SOURCE_FILES:
        file = source_root / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text("original source\n", encoding="utf8")
    first = review_migration.policy_source_provenance(source_root)
    # Keep the wrapper untouched; change the helper actually classifying names.
    (source_root / "main/draft_projection.py").write_text("updated positive proof\n", encoding="utf8")
    second = review_migration.policy_source_provenance(source_root)
    assert first["policy_source_hash"] != second["policy_source_hash"]
    changed = [name for name in first["policy_source_manifest"]["files"]
               if first["policy_source_manifest"]["files"][name] != second["policy_source_manifest"]["files"][name]]
    assert changed == ["main/draft_projection.py"]
    assert second["policy_source_hash"] == hashlib.sha256(json.dumps(
        second["policy_source_manifest"], ensure_ascii=False, sort_keys=True,
        separators=(",", ":")).encode("utf8")).hexdigest()


def test_real_migration_returns_versioned_source_evidence_without_rewriting_on_repeat(tmp_path):
    repo = CoreRepository(tmp_path / "private.sqlite3")
    ConversationService(IntakeService(repo))  # The explicit migration expects the app schema.
    result = review_migration.migrate_review_architecture(repo)
    expected = review_migration.policy_source_provenance()
    assert result["policy_source_hash_kind"] == "migration-classifier-source-bundle/1"
    assert {key: result[key] for key in expected} == expected
    files = result["policy_source_manifest"]["files"]
    root = Path(review_migration.__file__).resolve().parents[1]
    assert files["main/draft_projection.py"] == hashlib.sha256((root / "main/draft_projection.py").read_bytes()).hexdigest()
    assert {"core_v1/review_migration.py", "main/draft_projection.py", "v04/extraction.py",
            "v03/domain_validation.py", "v03/field_scope.py"}.issubset(files)
    assert result["exclusion_policy"] == result["policy_source_manifest"]["policy"]
    with repo.connection() as db:
        before = list(db.iterdump())
    repeated = review_migration.migrate_review_architecture(repo)
    with repo.connection() as db:
        assert list(db.iterdump()) == before
    assert repeated["frozen_exclusions"] == []
    assert repeated["model_calls"] == result["model_calls"] == 0
    assert repeated["policy_source_hash"] == result["policy_source_hash"]


def test_unreadable_source_evidence_fails_before_migration_side_effects(tmp_path, monkeypatch):
    repo = CoreRepository(tmp_path / "private.sqlite3")
    with repo.connection() as db:
        before = list(db.iterdump())

    def unavailable(*args, **kwargs):
        raise OSError("private fixture: source evidence unavailable")

    monkeypatch.setattr(review_migration, "policy_source_provenance", unavailable)
    with pytest.raises(OSError, match="source evidence unavailable"):
        review_migration.migrate_review_architecture(repo)
    with repo.connection() as db:
        assert list(db.iterdump()) == before
