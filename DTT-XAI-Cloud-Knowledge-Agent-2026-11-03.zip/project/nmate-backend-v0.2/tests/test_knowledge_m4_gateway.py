"""Typed wiki egress and READ replay stay in the one ModelGateway kernel."""
from datetime import datetime,timedelta,timezone
import json
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed
from test_knowledge_m4_serving import serving,release,lookup
from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.ssot import CoreSSOTService
from nmate.v03.core import CoreError

@pytest.fixture
def paid(serving):
    repo,g,s,author,expert,page,user,_=serving;release(serving)
    ref=lookup(serving)[0]['wiki_revision_refs'][0];calls=[]
    async def request(model,body,limit):
        calls.append(body)
        return dict(text='{"selected":true}',model=model,stop_reason='end_turn',usage=dict(input_tokens=100,output_tokens=20))
    gw=ModelGateway(repo,core=CoreSSOTService(repo),enabled=True,request_fn=request)
    grant=gw.authorize_budget(user['account_id'],user['enterprise_id'],approval_id='TEST-M4-NO-REAL-MONEY',
        max_calls=2,max_cost_usd='1',purposes=['hanoi_policy_synthesis'],roles=['standard'],
        expires_at=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    return gw,grant['id'],ref,calls

async def invoke(serving,paid,**changes):
    gw,grant,ref,calls=paid;user=serving[6]
    args=dict(account_id=user['account_id'],enterprise_id=user['enterprise_id'],operation_id='m4-paid-operation',task_id='test',
        role='standard',purpose='hanoi_policy_synthesis',context=dict(public_knowledge=[serving[2].read_reference(user['account_id'],ref)]),
        output_schema=dict(type='object',properties={'selected':{'type':'boolean'}},required=['selected'],additionalProperties=False),
        budget_grant_id=grant,public_wiki_refs=[ref])
    args.update(changes);return await gw.call_once(**args)

@pytest.mark.asyncio
async def test_typed_wiki_refs_are_sealed_and_replay_after_withdraw_is_read_only(serving,paid):
    gw,grant,ref,calls=paid
    first=await invoke(serving,paid)
    with gw.repo.connection() as db:
        dep=json.loads(db.execute('SELECT dependencies_json FROM core_model_attempts').fetchone()[0])
        assert dep['public_wiki_refs']==[ref]
    g=serving[1]
    g.withdraw_wiki(serving[4],serving[5]['page_id'],expected_release_id=ref['release_event_id'],rationale='TEST withdraw',operation_id='withdraw-after-paid')
    assert (await invoke(serving,paid))['cached'] is True
    with pytest.raises(CoreError):await invoke(serving,paid,operation_id='no-new-egress')
    assert len(calls)==1

@pytest.mark.asyncio
async def test_revoke_between_reserve_and_dispatch_cancels_without_provider(serving,paid):
    gw,_,ref,calls=paid;g=serving[1];original=gw._grant;triggered=False
    def at_fence(db,actor,scope,grant,purpose,role):
        nonlocal triggered
        row=original(db,actor,scope,grant,purpose,role)
        attempt=db.execute('SELECT 1 FROM core_model_attempts').fetchone()
        if attempt and not triggered:
            triggered=True
            # Fault injection in the final UoW, like existing ACL fence tests.
            db.execute("UPDATE pol_wiki_capabilities SET revoked_at='TEST revoked' WHERE account_id=? AND capability='publish'",(serving[4],))
        return row
    gw._grant=at_fence
    with pytest.raises(CoreError):await invoke(serving,paid)
    assert calls==[]
    with gw.repo.connection() as db:assert db.execute('SELECT state FROM core_model_attempts').fetchone()[0]=='cancelled_before_dispatch'

@pytest.mark.asyncio
async def test_dispatch_trace_pins_actual_fence_control_without_changing_input_or_replay(serving,paid):
    from nmate.policy_v1.catalog import KnowledgeCatalog
    gw,_,ref,calls=paid;original=gw._grant;advanced=False
    def at_fence(db,actor,scope,grant,purpose,role):
        nonlocal advanced
        value=original(db,actor,scope,grant,purpose,role)
        if not advanced and db.execute('SELECT 1 FROM core_model_attempts').fetchone():
            advanced=True
            KnowledgeCatalog._observation(db,serving[3],'KB-TEST-A',
              db.execute("SELECT current_snapshot_id FROM pol_sources WHERE id='KB-TEST-A'").fetchone()[0],
              'verified_current','verified_current',(datetime.now(timezone.utc)+timedelta(hours=4)).isoformat(),'Same source at fence')
        return value
    gw._grant=at_fence
    result=await invoke(serving,paid)
    with gw.repo.connection() as db:
        event=db.execute("SELECT detail_json FROM core_model_events WHERE attempt_id=? AND kind='dispatch_committed'",(result['attempt_id'],)).fetchone()[0]
        proof=json.loads(event)['public_wiki_authorizations'][0]
        current=db.execute('SELECT decision_id FROM ks_source_control_heads').fetchone()[0]
        assert proof['source_control_refs'][0]['decision_id']==current
        assert json.loads(db.execute('SELECT dependencies_json FROM core_model_attempts').fetchone()[0])['public_wiki_refs']==[ref]
    KnowledgeCatalog(gw.repo).record_source_check(serving[3],'KB-TEST-A',result='verified_current',
      current_until=(datetime.now(timezone.utc)+timedelta(hours=5)).isoformat(),rationale='Later identical source')
    assert (await invoke(serving,paid))['cached'] is True and len(calls)==1
    with gw.repo.connection() as db:
        assert db.execute("SELECT detail_json FROM core_model_events WHERE attempt_id=? AND kind='dispatch_committed'",(result['attempt_id'],)).fetchone()[0]==event
        assert db.execute('SELECT decision_id FROM ks_source_control_heads').fetchone()[0]!=current

@pytest.mark.asyncio
async def test_dispatch_proof_write_failure_cancels_before_transport(serving,paid):
    gw,_,_,calls=paid;original=gw._event
    def crash(db,scope,attempt,kind,detail=None):
        if kind=='dispatch_committed':raise RuntimeError('Synthetic proof event failure')
        return original(db,scope,attempt,kind,detail)
    gw._event=crash
    with pytest.raises(RuntimeError):await invoke(serving,paid)
    assert calls==[]
    with gw.repo.connection() as db:
        assert db.execute('SELECT state,held_microusd FROM core_model_attempts').fetchone()[:]==('cancelled_before_dispatch',0)
        assert not db.execute("SELECT 1 FROM core_model_events WHERE kind='dispatch_committed'").fetchone()

@pytest.mark.asyncio
async def test_source_read_revoke_denies_cached_wiki_result_without_another_call(serving,paid):
    gw,_,ref,calls=paid;result=await invoke(serving,paid)
    serving[1].set_source_rights(serving[3],'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,
        reason='TEST read revoke',operation_id='revoke-paid-wiki')
    with pytest.raises(CoreError):gw.read_receipt(serving[6]['account_id'],serving[6]['enterprise_id'],result['attempt_id'])
    assert len(calls)==1

@pytest.mark.asyncio
@pytest.mark.parametrize('changes',[{'goal':'\ud800'},{'body_hash':'not-hash'},{'target_date':True},{'schema_version':'released-wiki-ref/99'},{'private_chat':'DO NOT SEND'}])
async def test_malformed_public_reference_fails_before_manifest_or_reservation(serving,paid,changes):
    gw,_,ref,calls=paid
    with gw.repo.connection() as db:before=list(db.iterdump())
    with pytest.raises(CoreError):await invoke(serving,paid,public_wiki_refs=[ref|changes])
    assert calls==[]
    with gw.repo.connection() as db:assert list(db.iterdump())==before
