"""DF-006/008: product references do not absorb operational clauses.

Every sample is local text. No model, source refresh or persisted fixture is used.
"""
import pytest

from nmate.v04.extraction import extract_product_text
from nmate.v04.product_binding import declared_product_name


@pytest.mark.parametrize("suffix", [
    "khi tồn kho còn 120 hộp", "khi chỉ còn 120 hộp trong kho",
    "nếu tồn kho còn 120 hộp", "tồn kho còn 120 hộp",
    "còn trong kho 120 hộp", "đã bán 30 hộp mỗi tuần",
    "bán khoảng 30 hộp mỗi tuần", "sắp hết hàng",
])
def test_restock_reference_stops_before_business_observation(suffix):
    text = f"Chị có nên nhập thêm hàng Trà Sen {suffix}?"
    assert declared_product_name(text) == "Trà Sen"
    names = [item for item in extract_product_text(text) if item["field"] == "name"]
    assert not names or all(item["value"] == "Trà Sen" for item in names)
    assert not any(item["field"] in {"net_quantity", "packaging"} for item in extract_product_text(text))


@pytest.mark.parametrize("text, role", [
    ("Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TS-UPB-100.", "declared_identity"),
    ("THỬ NGHIỆM: Bột sen (THỬ NGHIỆM) khối lượng tịnh 200 g, mã BS-02, bao bì túi zip.", "subject_with_facts"),
    ("Tên sản phẩm: Trà Sen 2026; lượng tịnh 25,5 g; mã TS26", "declared_identity"),
])
def test_positive_declaration_has_unmodified_inspectable_provenance(text, role):
    facts = extract_product_text(text)
    assert {item["field"] for item in facts} >= {"name", "net_quantity", "product_code"}
    name = next(item for item in facts if item["field"] == "name")
    assert name["source"].get("assertion_role") == role
    for item in facts:
        source = item["source"]
        assert source["quote"] == text[source["start_offset"]:source["end_offset"]].strip()
        assert source["value_quote"] in source["quote"]
        assert source["review_state"] == "owner_confirmation_required"


@pytest.mark.parametrize("text", [
    "Nếu chị có Trà Sen khi tồn kho còn 120 hộp thì nên nhập không?",
    "Ví dụ chị có Trà Sen, hộp 100 g.",
    "Chị không có Trà Sen, hộp 100 g.",
    "Chị bán khoảng 300 hộp trà mỗi tháng.",
    "Chị có Trà Sen và Bột Sen, hộp 100 g.",
    "Tên sản phẩm: Trà Sen hoặc Bột Sen, lượng tịnh 100 g.",
    "Chị có Trà Sen, hộp 100 g. Chị cũng kiểm kê Bột Sen, tồn kho còn 50 hộp.",
    "Chị có Trà Sen, Bột Sen, hộp 100 g.",
])
def test_non_assertions_or_multiple_product_targets_do_not_create_facts(text):
    assert extract_product_text(text) == []


@pytest.mark.parametrize("name", ["Trà Sen", "TRÀ SEN", "Trà sen", "Trà Sén"])
def test_product_reference_retains_display_and_accents(name):
    assert declared_product_name(f"Chị có nên nhập thêm hàng {name} khi tồn kho còn 120 hộp?") == name


def test_explicit_product_name_contains_year_without_becoming_quantity():
    assert declared_product_name("Tên sản phẩm: Trà Sen 2026; mã TS26") == "Trà Sen 2026"


def test_question_particle_cannot_name_a_product_but_literal_name_still_works():
    assert declared_product_name("Bao bì túi zip có phù hợp để giữ hương trà không?") is None
    assert declared_product_name("Tên sản phẩm: Trà Không Độ; lượng tịnh 100 g") == "Trà Không Độ"


def test_repeated_equivalent_reference_cannot_invent_a_second_identity():
    text = "Chị có Trà Sen, hộp 100 g. Chị muốn gửi trà sen đi Mỹ."
    facts = extract_product_text(text)
    assert [item["value"] for item in facts if item["field"] == "name"] == ["Trà Sen"]
    assert next(item for item in facts if item["field"] == "name")["source"]["assertion_role"] == "declared_identity"


@pytest.mark.parametrize("text", ["Chị đã kiểm tra bao bì: túi zip.", "Chị muốn tra cứu chính sách.",
    "Chị kiểm tra dữ kiện trong hồ sơ."])
def test_lookup_and_inspection_verbs_are_not_unaccented_tea_names(text):
    assert not any(item["field"] == "name" for item in extract_product_text(text))


def test_inspection_verb_does_not_swallow_the_following_real_product_reference():
    assert declared_product_name("Chị kiểm tra Trà Sen khi tồn kho còn 120 hộp.") == "Trà Sen"


@pytest.mark.parametrize("text, expected", [
    ("Tên sản phẩm: Trà Sen, thành phần: trà sen và bột gạo.",
        {"name": "Trà Sen", "ingredients": "trà sen và bột gạo"}),
    ("Thành phần: trà sen và bột gạo.", {"ingredients": "trà sen và bột gạo"}),
])
def test_enumeration_inside_ingredient_value_is_not_another_product_subject(text, expected):
    assert {item["field"]: item["value"] for item in extract_product_text(text)} == expected
    assert declared_product_name(text) == expected.get("name")


@pytest.mark.parametrize("text, expected", [
    ("Chị cần tư vấn FDA cho Trà sen Tây Hồ hộp 100 g, mã TS01.",
        {"name": "Trà sen Tây Hồ", "net_quantity": "100 g", "packaging": "hộp", "product_code": "TS01"}),
    ("Chị cần tư vấn FDA cho Trà sen Tây Hồ 100 g mã TS01.",
        {"name": "Trà sen Tây Hồ", "net_quantity": "100 g", "product_code": "TS01"}),
    ("Chị muốn xuất khẩu Trà Sen 100 g đi Mỹ.", {"name": "Trà Sen", "net_quantity": "100 g"}),
])
def test_request_for_advice_does_not_erase_its_declared_subject_attributes(text, expected):
    assert {item["field"]: item["value"] for item in extract_product_text(text)} == expected


def test_purpose_clause_boundary_preserves_literal_de_ban_name():
    assert declared_product_name("Chị đọc tài liệu Trà Sen Tây Hồ để lập nháp hồ sơ.") == "Trà Sen Tây Hồ"
    assert declared_product_name("Tên sản phẩm: Trà Để Bàn; lượng tịnh 100 g") == "Trà Để Bàn"


@pytest.mark.parametrize("text, field, value", [
    ("Chị đổi khối lượng tịnh: 100 g theo nhãn mới vừa kiểm tra", "net_quantity", "100 g"),
    ("Sửa lượng tịnh: 200 g", "net_quantity", "200 g"),
    ("Chị muốn đổi bao bì: túi zip", "packaging", "túi zip"),
])
def test_explicit_literal_edit_is_a_proposal_not_an_implicit_current_observation(text, field, value):
    facts = extract_product_text(text)
    assert {item["field"]: item["value"] for item in facts} == {field: value}
    assert facts[0]["source"]["assertion_role"] == "explicit_field_edit"
    assert facts[0]["source"]["review_state"] == "owner_confirmation_required"

