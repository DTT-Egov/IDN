"""Contract fixtures only; no paid model call and no fixture enters the live catalog."""
from datetime import datetime, timedelta, timezone

import pytest
import json

from nmate.policy_v1 import KnowledgeCatalog, PolicyService
from nmate.policy_v1.rules import evaluate, validate_expression
from nmate.policy_v1.service import resolve_intent
from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "test-policy-fixtures.sqlite")
    accounts = LocalAccounts(repo)
    owner = accounts.register("policy_test_owner", "test-password-owner", "DỮ LIỆU KIỂM THỬ — Trà Sen")
    other = accounts.register("policy_test_other", "test-password-other", "DỮ LIỆU KIỂM THỬ — B")
    catalog = KnowledgeCatalog(repo)
    with repo.connection(write=True) as db:
        # Explicit test authority; runtime never bootstraps an expert identity.
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)", (owner["account_id"], "test-fixture", now_iso()))
    return repo, owner, other, catalog


def source(setup, identity="TEST-SOURCE-A", text="DỮ LIỆU KIỂM THỬ. Tư vấn chuyển đổi số. Doanh nghiệp đăng ký tại Hà Nội.", current=True):
    _, owner, _, catalog = setup
    catalog.register_source(owner["account_id"], identity, "DỮ LIỆU KIỂM THỬ — Tư vấn chuyển đổi số", "Cơ quan KIỂM THỬ",
                            f"https://hanoi.gov.vn/test-fixture/{identity}")
    result = catalog.add_snapshot(owner["account_id"], identity, text.encode(), text, complete_policy=True,
                                  effective_from="2026-01-01", effective_until="2030-01-01")
    if current:
        until = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        catalog.record_source_check(owner["account_id"], identity, result="verified_current", current_until=until,
                                    rationale="DỮ LIỆU KIỂM THỬ — toàn phần và tài liệu kèm đã kiểm")
    with catalog.repo.connection() as db:
        chunk = dict(db.execute("SELECT * FROM pol_chunks WHERE snapshot_id=? LIMIT 1", (result["snapshot_id"],)).fetchone())
    return result, chunk


def member(setup, *, kind="rule", identity="TEST-SOURCE-A", chunk=None, publish=True, goal="digital_inventory"):
    _, owner, _, catalog = setup
    if chunk is None:
        _, chunk = source(setup, identity)
    scope = {"jurisdiction": "VN-HN", "goal_types": [goal]}
    payload = {"scope": scope, "conditions": [{"id": "c_location", "title_vi": "Đăng ký tại Hà Nội",
               "expression": {"field": "registration_province", "op": "eq", "value": "Hà Nội"}}]} if kind == "rule" else {
                   "scope": scope, "claim_type": "preparation", "items": [{"id": "paper_1", "text_vi": "DỮ LIỆU KIỂM THỬ — mục hồ sơ có căn cứ"}]}
    evidence = [{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": "c_location" if kind == "rule" else "paper_1"}]
    result = catalog.propose_member(owner["account_id"], kind=kind, policy_id="TEST-POLICY", title_vi="DỮ LIỆU KIỂM THỬ",
                                    payload=payload, evidence=evidence, effective_from="2026-01-01", effective_until="2030-01-01")
    review = catalog.review_member(owner["account_id"], result["member_id"], result["content_hash"], approve=True, rationale="DỮ LIỆU KIỂM THỬ — review")
    if publish:
        catalog.publish_member(owner["account_id"], result["member_id"], result["content_hash"], review["review_event_id"])
    return result


def test_official_bootstrap_has_real_bytes_but_no_fake_rule_or_approval(setup):
    repo, _, _, catalog = setup
    first = catalog.bootstrap_official_notice()
    assert not first["unchanged"]
    assert catalog.bootstrap_official_notice()["unchanged"]
    found = catalog.retrieve("Tôi muốn số hóa quản lý kho Trà Sen, còn nhận hồ sơ không?")
    assert found and all(item["source_id"] == "HN-NOTICE-2026-14" for item in found)
    assert all(not item["usable_for_assessment"] for item in found)
    assert not catalog.retrieve("số hóa kho", purpose="reviewed_policy_assessment")
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_review_events").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM pol_members").fetchone()[0] == 0
        row = db.execute("SELECT raw_bytes,raw_sha256 FROM pol_source_snapshots LIMIT 1").fetchone()
        assert len(row["raw_bytes"]) > 1000


@pytest.mark.parametrize(("question", "expected"), [
    ("Số hóa kho có chương trình nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?", ["policy_discovery", "eligibility", "preparation", "application_window"]),
    ("Chương trình còn nhận hồ sơ không?", ["application_window"]),
    ("Tôi cần chuẩn bị giấy tờ gì cho tư vấn số hóa?", ["preparation"]),
    ("Có hỗ trợ mua máy đóng gói không?", ["policy_discovery"]),
])
def test_intent_is_question_bound_not_fixed_three(question, expected):
    assert resolve_intent(question)["outcome_types"] == expected


def test_discovery_is_not_eligibility_or_window_and_reuses_ssot(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen ĐỒNG THÁP")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"], [{"field": "name", "value": "Trà Sen ĐỒNG THÁP"}], 0, "fact-name")
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Tôi muốn số hóa kho Trà Sen, có chương trình nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?", "prepare")
    assert prepared["context"]["entities"][0]["values"]["name"] == "Trà Sen ĐỒNG THÁP"
    assert prepared["provider_calls"] == 0 and not prepared["provider_used"]
    assert len(prepared["outcomes"]) == 4
    discovery = next(o for o in prepared["outcomes"] if o["id"] == "policy_discovery")
    assert discovery["citations"] and all("Phụ lục 04" not in cite["quote_original"] for cite in discovery["citations"])
    assert next(o for o in prepared["outcomes"] if o["id"] == "eligibility")["status"] == "awaiting_rule_review"
    assert next(o for o in prepared["outcomes"] if o["id"] == "application_window")["status"] == "needs_source"
    assert "đủ chỉ tiêu" in next(o for o in prepared["outcomes"] if o["id"] == "application_window")["citations"][0]["quote_original"]
    assert service.prepare(owner["account_id"], owner["enterprise_id"], prepared["question"], "prepare")["id"] == prepared["id"]
    with pytest.raises(CoreError, match="khác"):
        service.prepare(owner["account_id"], owner["enterprise_id"], "Câu khác", "prepare")


def test_window_only_does_not_read_enterprise_or_financial_facts(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    result = service.prepare(owner["account_id"], owner["enterprise_id"], "Chương trình còn nhận hồ sơ không?", "window")
    assert result["context"]["entities"] == []
    assert result["context_fields"] == []
    assert len(result["outcomes"]) == 1
    assert result["next_action"]["kind"] == "verify_official_window"


def test_purchase_not_reframed_as_consulting_support(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    result = service.prepare(owner["account_id"], owner["enterprise_id"], "Có hỗ trợ mua máy đóng gói Trà Sen không?", "equipment")
    assert result["intent"]["goal"] == "equipment_purchase"
    assert "không đồng nghĩa" in result["lead_vi"]
    assert result["outcomes"][0]["status"] == "needs_source"


def test_private_policy_missions_not_readable_in_another_profile(setup):
    repo, owner, other, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    result = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "private")
    assert service.list(other["account_id"], other["enterprise_id"]) == []
    with pytest.raises(CoreError):
        service.get(other["account_id"], other["enterprise_id"], result["id"])
    separate = service.prepare(other["account_id"], other["enterprise_id"], "Số hóa kho có chương trình nào?", "private-other")
    assert separate["id"] != result["id"]
    assert separate["sources"][0]["source_snapshot_id"] == result["sources"][0]["source_snapshot_id"]
    assert separate["context"]["enterprise_id"] == other["enterprise_id"]
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_memberships VALUES(?,?,'owner',1)", (other["account_id"], owner["enterprise_id"]))
    with pytest.raises(CoreError):
        service.get(other["account_id"], owner["enterprise_id"], result["id"])


def test_domain_roles_not_implied_by_enterprise_owner_and_urls_allowlist(setup):
    _, owner, other, catalog = setup
    with pytest.raises(CoreError) as denied:
        catalog.register_source(other["account_id"], "x", "x", "x", "https://hanoi.gov.vn/x")
    assert denied.value.code == "knowledge_forbidden"
    for url in ("https://hanoi.gov.vn.evil.test/x", "http://hanoi.gov.vn/x", "https://user:password@hanoi.gov.vn/x", "https://hanoi.gov.vn/x?token=abc"):
        with pytest.raises(CoreError):
            catalog.register_source(owner["account_id"], "bad", "bad", "bad", url)


def test_exact_evidence_and_per_condition_coverage(setup):
    _, owner, _, catalog = setup
    _, chunk = source(setup)
    with pytest.raises(CoreError) as mismatch:
        catalog.bind_evidence(chunk["id"], "Đây là quote bịa")
    assert mismatch.value.code == "evidence_mismatch"
    with pytest.raises(CoreError) as missing:
        catalog.propose_member(owner["account_id"], kind="rule", policy_id="test", title_vi="test",
            payload={"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]}, "conditions": [{"id": "a", "expression": {"field": "x", "op": "present"}}]},
            evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": "wrong"}], effective_from="2026-01-01")
    assert missing.value.code == "evidence_coverage_gap"


def test_unknown_complete_source_or_effective_period_blocks_review(setup):
    _, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    chunk = catalog.retrieve("chuyển đổi số")[0]
    proposal = catalog.propose_member(owner["account_id"], kind="rule", policy_id="test", title_vi="test",
        payload={"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]}, "conditions": [{"id": "a", "expression": {"field": "x", "op": "present"}}]},
        evidence=[{"chunk_id": chunk["chunk_id"], "quote_original": chunk["quote_original"], "supports_id": "a"}], effective_from="2026-01-01")
    with pytest.raises(CoreError):
        catalog.review_member(owner["account_id"], proposal["member_id"], proposal["content_hash"], approve=True, rationale="Không được duyệt thông báo thiếu phụ lục")


def test_review_publication_release_and_dependency_graph(setup):
    _, owner, _, catalog = setup
    rule = member(setup)
    assert catalog.assess([]) == []  # published member without released pack is not an assessment.
    pack = catalog.release_pack(owner["account_id"], "DỮ LIỆU KIỂM THỬ", [rule["member_id"]])
    findings = catalog.assess([{"field": "registration_province", "value": "Hà Nội", "version": 1}], goal="digital_inventory")
    assert findings[0]["conditions"][0]["state"] == "met"
    assert findings[0]["pack_version_id"] == pack["pack_version_id"]
    assert any(edge["to_kind"] == "field" and edge["to_id"] == "registration_province" for edge in catalog.dependencies("rule", rule["member_id"]))
    assert catalog.assess([], goal="equipment_purchase") == []


def test_release_cannot_publish_unreviewed_member_or_wrong_hash(setup):
    _, owner, _, catalog = setup
    rule = member(setup, publish=False)
    with pytest.raises(CoreError):
        catalog.release_pack(owner["account_id"], "fixture", [rule["member_id"]])
    with pytest.raises(CoreError) as wrong:
        catalog.review_member(owner["account_id"], rule["member_id"], "wrong-hash", approve=True, rationale="fixture")
    assert wrong.value.code == "knowledge_hash_conflict"


def test_d07_blocks_only_dependent_member_not_entire_pack(setup):
    _, owner, _, catalog = setup
    rule = member(setup)
    _, second_chunk = source(setup, "TEST-SOURCE-B", "DỮ LIỆU KIỂM THỬ — giấy tờ tư vấn chuyển đổi số")
    claim = member(setup, kind="claim", chunk=second_chunk)
    catalog.release_pack(owner["account_id"], "DỮ LIỆU KIỂM THỬ", [rule["member_id"], claim["member_id"]])
    catalog.record_source_check(owner["account_id"], "TEST-SOURCE-A", result="unavailable", rationale="DỮ LIỆU KIỂM THỬ — lỗi mạng")
    findings = {item["member_id"]: item for item in catalog.assess([])}
    assert findings[rule["member_id"]]["status"] == "blocked"
    assert findings[rule["member_id"]]["reason_code"] == "SOURCE_CURRENT_CHECK_REQUIRED"
    assert findings[claim["member_id"]]["status"] == "assessed"


def test_changed_snapshot_requires_new_review_not_only_http_recovery(setup):
    _, owner, _, catalog = setup
    rule = member(setup)
    catalog.release_pack(owner["account_id"], "fixture", [rule["member_id"]])
    catalog.add_snapshot(owner["account_id"], "TEST-SOURCE-A", b"new-version", "DỮ LIỆU KIỂM THỬ — điều kiện đã đổi", complete_policy=True, effective_from="2026-01-01")
    catalog.record_source_check(owner["account_id"], "TEST-SOURCE-A", result="verified_current",
        current_until=(datetime.now(timezone.utc) + timedelta(days=1)).isoformat(), rationale="fixture restored")
    findings = catalog.assess([])
    assert findings[0]["status"] == "blocked"
    assert findings[0]["reason_code"] == "MEMBER_REVIEW_REQUIRED"


@pytest.mark.parametrize(("value", "state"), [(None, "unknown"), (False, "not_met"), (0, "met")])
def test_four_state_dsl_preserves_unknown_false_zero(value, state):
    assert evaluate({"field": "x", "op": "eq", "value": 0}, [{"field": "x", "value": value}])["state"] == state


def test_dsl_decimal_units_period_scope_and_no_code_execution():
    expression = {"field": "revenue", "op": "lte", "value": "1000000000.01", "unit": "VND", "period": "2025"}
    fact = {"field": "revenue", "value": "1000000000.01", "unit": "VND", "period": "2025"}
    assert evaluate(expression, [fact])["state"] == "met"
    assert evaluate(expression, [{**fact, "period": "2024"}])["state"] == "unknown"
    assert evaluate(expression, [{**fact, "value": 1.0}])["state"] == "unknown"
    assert evaluate({"field": "x", "op": "eq", "value": 1}, [{"field": "x", "value": 1}, {"field": "x", "value": 2}])["state"] == "conflict"
    with pytest.raises(CoreError):
        validate_expression({"field": "x", "op": "eval", "value": "__import__('os')"})


def analysis_response(context, *, reverse=False):
    candidates = context["analysis_candidates"]
    evidence = [dict(choice) for choice in candidates["evidence"][:3]]
    tasks = [task["id"] for task in candidates["next_tasks"]]
    return {"schema_version": "policy-model-analysis/2", "evidence_choices": evidence,
            "next_task_ids": list(reversed(tasks))[:6] if reverse else tasks[:6],
            "ssot_question_ids": [question["id"] for question in candidates["ssot_questions"]][:3]}


class FixtureGateway:
    """In-process deterministic contract fake, never a network client."""
    def __init__(self, *, mutate=None, fail=False):
        self.calls, self.mutate, self.fail, self.contexts = 0, mutate, fail, []

    async def call_once(self, **kwargs):
        self.calls += 1
        self.contexts.append(kwargs["context"])
        if self.fail:
            raise CoreError("provider_timeout", "fixture timeout")
        data = analysis_response(kwargs["context"])
        if self.mutate:
            self.mutate(data)
        return {"data": data, "attempt": {"fixture": True, "state": "succeeded"}}


@pytest.mark.asyncio
async def test_budget_gate_queue_reload_exactly_one_call_and_history_free(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    gateway = FixtureGateway()
    service = PolicyService(repo, gateway=gateway)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp và còn nhận hồ sơ không?", "paid-fixture")
    with pytest.raises(CoreError) as denied:
        service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], operation_id="start")
    assert denied.value.code == "budget_not_granted" and gateway.calls == 0
    first = service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], operation_id="start", budget_grant_id="test-only-grant")
    assert first["status"] == "queued"
    assert service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], operation_id="start", budget_grant_id="test-only-grant")["status"] == "queued"
    reloaded = PolicyService(repo, gateway=gateway)
    assert reloaded.get(owner["account_id"], owner["enterprise_id"], prepared["id"])["status"] == "queued"
    result = await reloaded.execute_next()
    assert result["status"] == "completed_partial"
    assert result["provider_used"] and gateway.calls == 1
    assert await reloaded.execute_next() is None
    assert reloaded.get(owner["account_id"], owner["enterprise_id"], prepared["id"])["status"] == "completed_partial"
    assert len(reloaded.list(owner["account_id"], owner["enterprise_id"])) == 1 and gateway.calls == 1
    assert "entities" not in gateway.contexts[0]
    assert "financial_metric" not in json_text(gateway.contexts[0])


@pytest.mark.asyncio
async def test_provider_failure_and_corrupt_citation_never_paid_retry(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    gateway = FixtureGateway(mutate=lambda data: data["evidence_choices"][0].update(chunk_id="invented"))
    service = PolicyService(repo, gateway=gateway)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "corrupt")
    service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "start", "test-only")
    result = await service.execute_next()
    assert result["status"] == "failed" and result["error"]["code"] == "invalid_policy_response"
    assert await service.execute_next() is None and gateway.calls == 1
    with pytest.raises(CoreError) as blocked:
        service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "start-again", "test-only")
    assert blocked.value.code == "new_paid_run_required"


@pytest.mark.asyncio
async def test_interrupted_running_is_not_replayed(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    gateway = FixtureGateway()
    service = PolicyService(repo, gateway=gateway)
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Còn nhận hồ sơ không?", "crash")
    service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "start", "test-only")
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_missions SET status='running' WHERE id=?", (mission["id"],))
    assert service.recover_interrupted() == 1
    assert await service.execute_next() is None and gateway.calls == 0
    assert service.get(owner["account_id"], owner["enterprise_id"], mission["id"])["status"] == "interrupted"


def test_financial_text_cannot_bypass_metric_preview_on_policy_paid_start(setup):
    repo, owner, _, _ = setup
    service = PolicyService(repo, gateway=FixtureGateway())
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Doanh thu 3000000000 có được hỗ trợ số hóa kho không?", "finance")
    with pytest.raises(CoreError) as denied:
        service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "start", "test-only")
    assert denied.value.code == "finance_egress_required"


def test_manifest_corruption_cannot_create_approved_result(setup):
    repo, owner, _, catalog = setup
    rule = member(setup)
    pack = catalog.release_pack(owner["account_id"], "test", [rule["member_id"]])
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_packs SET manifest_json=? WHERE id=?", (json_text([]), pack["pack_version_id"]))
    assert catalog.assess([]) == []


@pytest.mark.asyncio
async def test_new_core_adapter_dependency_hash_and_atomic_chat_callback(setup):
    from nmate.core_v1.ssot import CoreSSOTService
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    core = CoreSSOTService(repo)
    product = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"], [{"field": "name", "value": "Trà Sen"}], 0, "new-core-name")
    gateway = FixtureGateway()
    service = PolicyService(repo, core=core, gateway=gateway)
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE test_chat_link(id TEXT PRIMARY KEY,mission_id TEXT)")
        db.execute("CREATE TABLE v04_conversations(id TEXT PRIMARY KEY,enterprise_id TEXT,owner_id TEXT,payload_json TEXT,created_at TEXT,updated_at TEXT)")

    def link(db, payload):
        assert payload["conversation_id"] == "chat_test"
        db.execute("INSERT INTO test_chat_link VALUES(?,?)", ("chat_test", payload["id"]))
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", ("chat_test", owner["enterprise_id"], owner["account_id"], json_text({"policy_case_ids": [payload["id"]]}), now_iso(), now_iso()))

    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Tôi muốn số hóa kho có chương trình nào phù hợp?", "new-core", entity_ids=[product["id"]], conversation_id="chat_test", on_commit=link)
    with repo.connection() as db:
        assert db.execute("SELECT mission_id FROM test_chat_link WHERE id='chat_test'").fetchone()[0] == prepared["id"]
    service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], "start-new-core", "test-only")
    result = await service.execute_next()
    assert result["status"] == "completed_partial" and gateway.calls == 1


def test_atomic_chat_callback_failure_rolls_back_case_and_idempotency(setup):
    repo, owner, _, _ = setup
    service = PolicyService(repo)
    def fail(db, payload):
        raise ValueError("test transaction failure")
    with pytest.raises(ValueError):
        service.prepare(owner["account_id"], owner["enterprise_id"], "Còn nhận hồ sơ không?", "atomic-fail", on_commit=fail)
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_missions").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM pol_operations").fetchone()[0] == 0


def test_sql_canonical_snapshot_cannot_be_modified(setup):
    import sqlite3
    repo, _, _, catalog = setup
    snapshot, _ = source(setup)
    with pytest.raises(sqlite3.IntegrityError):
        with repo.connection(write=True) as db:
            db.execute("UPDATE pol_source_snapshots SET canonical_text='edited' WHERE id=?", (snapshot["snapshot_id"],))


def test_withdrawn_member_does_not_reappear_from_published_pack(setup):
    _, owner, _, catalog = setup
    rule = member(setup)
    catalog.release_pack(owner["account_id"], "test", [rule["member_id"]])
    catalog.withdraw_member(owner["account_id"], rule["member_id"], rule["content_hash"], "DỮ LIỆU KIỂM THỬ — rút")
    assert catalog.assess([])[0]["status"] == "blocked"


def test_financial_derived_condition_is_not_sent_without_exact_egress_manifest(setup):
    repo, owner, _, catalog = setup
    _, chunk = source(setup)
    rule = catalog.propose_member(owner["account_id"], kind="rule", policy_id="TEST-POLICY", title_vi="DỮ LIỆU KIỂM THỬ",
        payload={"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]}, "conditions": [{"id": "finance", "expression": {"field": "revenue", "op": "lte", "value": "3000000000"}}]},
        evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": "finance"}], effective_from="2026-01-01")
    reviewed = catalog.review_member(owner["account_id"], rule["member_id"], rule["content_hash"], approve=True, rationale="DỮ LIỆU KIỂM THỬ")
    catalog.publish_member(owner["account_id"], rule["member_id"], rule["content_hash"], reviewed["review_event_id"])
    catalog.release_pack(owner["account_id"], "DỮ LIỆU KIỂM THỬ", [rule["member_id"]])
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "DỮ LIỆU KIỂM THỬ")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "revenue", "value": "1000000000"}], 0, "finance-secret")
    gateway = FixtureGateway()
    service = PolicyService(repo, gateway=gateway)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Tôi muốn số hóa kho, có chương trình nào phù hợp?", "derived-finance")
    assert prepared["findings"][0]["conditions"][0]["state"] == "met"
    with pytest.raises(CoreError) as denied:
        service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], "start", "test-only")
    assert denied.value.code == "finance_egress_required" and gateway.calls == 0


def test_english_source_never_displays_english_as_vietnamese_translation(setup):
    _, owner, _, catalog = setup
    catalog.register_source(owner["account_id"], "TEST-EN", "TEST FIXTURE digital consulting", "TEST FIXTURE", "https://hanoi.gov.vn/test-fixture/en", language="en")
    snapshot = catalog.add_snapshot(owner["account_id"], "TEST-EN", b"TEST FIXTURE digital consulting", "TEST FIXTURE digital consulting", complete_policy=False)
    original = catalog.retrieve("digital consulting")[0]
    assert original["rendered_vi"] != original["quote_original"]
    assert original["translation_status"] == "translation_required"
    translated = catalog.add_translation(owner["account_id"], original["chunk_id"], "DỮ LIỆU KIỂM THỬ — tư vấn số hóa")
    with catalog.repo.connection() as db:
        text_hash = db.execute("SELECT text_hash FROM pol_translations WHERE id=?", (translated["translation_id"],)).fetchone()[0]
    catalog.review_translation(owner["account_id"], translated["translation_id"], text_hash)
    results = catalog.retrieve("tư vấn số hóa")
    found = next(item for item in results if item["source_snapshot_id"] == snapshot["snapshot_id"])
    assert found["rendered_vi"] == "DỮ LIỆU KIỂM THỬ — tư vấn số hóa"
    assert found["quote_original"] == "TEST FIXTURE digital consulting"


def test_old_private_field_cannot_be_read_after_revocation_even_with_resource_access(setup):
    from nmate.core_v1.ssot import CoreSSOTService
    repo, owner, staff, catalog = setup
    core = CoreSSOTService(repo)
    core.add_member(owner["account_id"], owner["enterprise_id"], "policy_test_other")
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen RIÊNG")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "name", "value": "Trà Sen RIÊNG"}], 0, "secret-name")
    core.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read"], ["name", "legal_name"])
    service = PolicyService(repo, core=core)
    prepared = service.prepare(staff["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp?", "staff-private", entity_ids=[entity["id"]])
    assert "Trà Sen RIÊNG" in json_text(prepared["context"])
    core.revoke_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read"], ["name"])
    with pytest.raises(CoreError) as denied:
        service.get(staff["account_id"], owner["enterprise_id"], prepared["id"])
    assert denied.value.status_code == 403


@pytest.mark.asyncio
async def test_daily_source_job_is_durable_free_bounded_and_has_no_review_authority(setup, monkeypatch):
    import nmate.policy_v1.refresh_jobs as refresh_jobs
    from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    with repo.connection() as db:
        retrieved = datetime.fromisoformat(db.execute("SELECT retrieved_at FROM pol_source_snapshots WHERE id=(SELECT current_snapshot_id FROM pol_sources WHERE id='HN-NOTICE-2026-14')").fetchone()[0])
    clock = {"now": retrieved + timedelta(hours=2)}

    class SourceJobClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return clock["now"].astimezone(tz) if tz else clock["now"].replace(tzinfo=None)

    monkeypatch.setattr(refresh_jobs, "datetime", SourceJobClock)
    monkeypatch.setattr(refresh_jobs, "now_iso", lambda: clock["now"].isoformat())
    calls = []
    def fetch(actor, identity, *, internal_job_id=None):
        assert actor == "system:source-acquisition" and identity == "HN-NOTICE-2026-14"
        assert internal_job_id
        calls.append(internal_job_id)
        return {"source_id": identity, "state": "snapshot_only", "unchanged": True, "provider_calls": 0}
    monkeypatch.setattr(catalog, "refresh_source", fetch)
    jobs = SourceRefreshJobs(catalog)
    jobs.bootstrap_official_notice()
    due = retrieved + timedelta(days=1)
    assert datetime.fromisoformat(jobs.list(owner["account_id"])[0]["next_due_at"]) == due
    assert await jobs.execute_next() is None and not calls
    clock["now"] = due - timedelta(seconds=1)
    assert await jobs.execute_next() is None and not calls
    clock["now"] = due
    assert (await jobs.execute_next())["provider_calls"] == 0
    assert await jobs.execute_next() is None and len(calls) == 1
    with repo.connection() as db:
        assert datetime.fromisoformat(db.execute("SELECT next_due_at FROM pol_refresh_jobs").fetchone()[0]) == due + timedelta(days=1)
        assert db.execute("SELECT COUNT(*) FROM pol_refresh_job_events").fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM pol_review_events").fetchone()[0] == 0
    jobs.disable(owner["account_id"], "HN-NOTICE-2026-14")
    assert jobs.list(owner["account_id"])[0]["enabled"] == 0


@pytest.mark.asyncio
async def test_bootstrap_does_not_postpone_an_already_due_source_check(setup, monkeypatch):
    """Bundled bytes keep their actual acquisition time after a later startup."""
    import nmate.policy_v1.refresh_jobs as refresh_jobs
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    with repo.connection() as db:
        retrieved = datetime.fromisoformat(db.execute("SELECT retrieved_at FROM pol_source_snapshots WHERE id=(SELECT current_snapshot_id FROM pol_sources WHERE id='HN-NOTICE-2026-14')").fetchone()[0])
    now = retrieved + timedelta(days=2)

    class SourceJobClock(datetime):
        @classmethod
        def now(cls, tz=None):
            return now.astimezone(tz) if tz else now.replace(tzinfo=None)

    monkeypatch.setattr(refresh_jobs, "datetime", SourceJobClock)
    monkeypatch.setattr(refresh_jobs, "now_iso", lambda: now.isoformat())
    calls = []

    def fetch(actor, identity, *, internal_job_id=None):
        assert actor == "system:source-acquisition" and internal_job_id
        calls.append(identity)
        return {"source_id": identity, "state": "snapshot_only", "provider_calls": 0}

    monkeypatch.setattr(catalog, "refresh_source", fetch)
    jobs = refresh_jobs.SourceRefreshJobs(catalog)
    jobs.bootstrap_official_notice()
    assert datetime.fromisoformat(jobs.list(owner["account_id"])[0]["next_due_at"]) == retrieved + timedelta(days=1)
    assert (await jobs.execute_next())["provider_calls"] == 0 and calls == ["HN-NOTICE-2026-14"]
    restarted = refresh_jobs.SourceRefreshJobs(catalog)
    restarted.bootstrap_official_notice()
    assert datetime.fromisoformat(restarted.list(owner["account_id"])[0]["next_due_at"]) == now + timedelta(days=1)
    assert await restarted.execute_next() is None and len(calls) == 1
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_review_events").fetchone()[0] == 0


@pytest.mark.asyncio
async def test_refresh_job_recovers_expired_free_lease_and_backs_off_failures(setup, monkeypatch):
    from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
    repo, _, _, catalog = setup
    catalog.bootstrap_official_notice()
    jobs = SourceRefreshJobs(catalog)
    jobs.bootstrap_official_notice()
    monkeypatch.setattr(catalog, "refresh_source", lambda *args, **kwargs: {"state": "unavailable", "provider_calls": 0})
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_refresh_jobs SET next_due_at='2000-01-01T00:00:00+00:00',state='running',lease_until='2000-01-01T00:00:00+00:00'")
    assert (await jobs.execute_next())["state"] == "unavailable"
    with repo.connection() as db:
        job = db.execute("SELECT * FROM pol_refresh_jobs").fetchone()
        assert job["state"] == "scheduled" and job["failure_count"] == 1
        assert datetime.fromisoformat(job["next_due_at"]) > datetime.now(timezone.utc)


def test_service_principal_cannot_refresh_without_approved_running_job(setup):
    _, _, _, catalog = setup
    catalog.bootstrap_official_notice()
    with pytest.raises(CoreError) as denied:
        catalog.refresh_source("system:source-acquisition", "HN-NOTICE-2026-14", internal_job_id="invented")
    assert denied.value.status_code == 403


def test_historical_report_has_current_source_warning_without_overwriting_original(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "history-source")
    catalog.record_source_check(owner["account_id"], "HN-NOTICE-2026-14", result="unavailable", rationale="DỮ LIỆU KIỂM THỬ lỗi mạng")
    viewed = service.get(owner["account_id"], owner["enterprise_id"], prepared["id"])
    assert viewed["is_historical"] and viewed["current_warnings_vi"]
    assert viewed["lead_vi"] == prepared["lead_vi"]
    with repo.connection() as db:
        assert "current_warnings_vi" not in db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (prepared["id"],)).fetchone()[0]


@pytest.mark.asyncio
async def test_real_gateway_contract_with_local_request_function_and_prequeue_scope_checks(setup):
    from nmate.core_v1.gateway import ModelGateway
    from nmate.core_v1.ssot import CoreSSOTService
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    core = CoreSSOTService(repo)
    calls = []
    async def request(model, body, max_tokens):
        calls.append(body)
        data = analysis_response(body["input"])
        return {"text": json_text(data), "model": model, "usage": {"input_tokens": 1000, "output_tokens": 500}, "stop_reason": "end_turn"}
    gateway = ModelGateway(repo, core=core, request_fn=request, enabled=True)
    service = PolicyService(repo, core=core, gateway=gateway)
    with repo.connection(write=True) as db:
        db.execute("CREATE TABLE v04_conversations(id TEXT PRIMARY KEY,enterprise_id TEXT,owner_id TEXT,payload_json TEXT,created_at TEXT,updated_at TEXT)")
    def commit(db, payload):
        payload["conversation_id"] = "chat_real_gateway_contract"
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (payload["conversation_id"], owner["enterprise_id"], owner["account_id"], json_text({"policy_case_ids": [payload["id"]]}), now_iso(), now_iso()))
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], "Tôi muốn số hóa kho Trà Sen, có chương trình nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?", "gateway-contract", on_commit=commit)
    assert service.get(owner["account_id"], owner["enterprise_id"], mission["id"])["conversation_id"] == "chat_real_gateway_contract"
    with pytest.raises(CoreError) as unknown:
        service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "unknown-grant", "client-invented")
    assert unknown.value.code == "BUDGET_NOT_GRANTED"
    assert service.get(owner["account_id"], owner["enterprise_id"], mission["id"])["status"] == "prepared"
    grant = gateway.authorize_budget(owner["account_id"], owner["enterprise_id"], approval_id="LOCAL-TEST-NO-NETWORK", max_calls=1, max_cost_usd="10",
        purposes=["hanoi_policy_synthesis"], roles=["complex"], expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "valid-grant-start", grant["id"])
    result = await service.execute_next()
    assert result["status"] == "completed_partial", result.get("error")
    assert len(calls) == 1
    assert result["provider_receipt"]["attempt_id"].startswith("model_attempt_")
    assert result["provider_receipt"]["usage"]["input_tokens"] == 1000
    assert "api_key" not in json.dumps(calls)
    with repo.connection() as db:
        assert db.execute("SELECT publication_state FROM core_model_attempts WHERE id=?", (result["provider_receipt"]["attempt_id"],)).fetchone()[0] == "published"


def test_changed_ssot_labels_saved_policy_historical_without_model_call(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "name", "value": "Trà Sen"}], 0, "old-name")
    gateway = FixtureGateway()
    service = PolicyService(repo, gateway=gateway)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Tôi muốn số hóa kho có chương trình nào phù hợp?", "ssot-history", entity_ids=[entity["id"]])
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "name", "value": "Trà Sen mới"}], 1, "new-name")
    viewed = service.get(owner["account_id"], owner["enterprise_id"], prepared["id"])
    assert viewed["is_historical"] and any("Dữ kiện doanh nghiệp" in warning for warning in viewed["current_warnings_vi"])
    assert viewed["context"]["entities"][0]["values"]["name"] == "Trà Sen"
    assert gateway.calls == 0


@pytest.mark.parametrize("field", ["lead_vi", "answer_vi", "next_action_vi"])
def test_real_quote_cannot_launder_invented_entitlement_or_amount(setup, field):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "invented-" + field)
    sources = catalog.retrieve(prepared["question"])
    data = {"lead_vi": prepared["lead_vi"], "next_action_vi": prepared["next_action"]["label_vi"], "outcomes": [
        {"id": item["id"], "answer_vi": item["answer_vi"], "citations": [{key: c[key] for key in ("source_snapshot_id", "chunk_id", "quote_original")} for c in item["citations"]]}
        for item in prepared["outcomes"]]}
    invented = "Doanh nghiệp được nhận hỗ trợ 500 triệu đồng và chắc chắn được duyệt."
    if field == "answer_vi":
        data["outcomes"][0][field] = invented
    else:
        data[field] = invented
    with pytest.raises(CoreError) as rejected:
        service._validate_synthesis(data, prepared, sources)
    assert rejected.value.code == "policy_governance_override"


def test_dsl_canonical_conflicted_and_known_absent_states():
    assert evaluate({"field": "province", "op": "eq", "value": "Hà Nội"},
                    [{"field": "province", "value": "Hà Nội", "value_state": "conflicted"}])["state"] == "conflict"
    for state in ("known_absent", "explicit_absent"):
        result = evaluate({"field": "certificate", "op": "present"}, [{"field": "certificate", "value": None, "value_state": state}])
        assert result["state"] == "not_met" and not result["missing_fact_keys"]


@pytest.mark.asyncio
async def test_raw_financial_prose_is_never_serialized_even_if_keyword_detector_misses_it(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    gateway = FixtureGateway()
    service = PolicyService(repo, gateway=gateway)
    raw_question = "Công ty lãi ròng 123456789 đồng năm 2025, có chương trình số hóa kho nào?"
    mission = service.prepare(owner["account_id"], owner["enterprise_id"], raw_question, "raw-prose")
    service.start(owner["account_id"], owner["enterprise_id"], mission["id"], "raw-prose-start", "test-only")
    result = await service.execute_next()
    assert result["status"] == "completed_partial"
    assert gateway.calls == 1
    outbound = json_text(gateway.contexts)
    assert "123456789" not in outbound and raw_question not in outbound and "lãi ròng" not in outbound


@pytest.mark.asyncio
async def test_model_research_decisions_are_used_persisted_and_different_from_canonical_result(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    gateway = FixtureGateway(mutate=lambda data: data.update(next_task_ids=list(reversed(data["next_task_ids"]))))
    service = PolicyService(repo, gateway=gateway)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"],
        "Số hóa kho có chương trình nào phù hợp, cần chuẩn bị gì và còn nhận hồ sơ không?", "real-decisions")
    service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], "start-decisions", "test-only")
    result = await service.execute_next()
    assert result["status"] == "completed_partial", result.get("error")
    candidates = gateway.contexts[0]["analysis_candidates"]
    expected_order = list(reversed([task["id"] for task in candidates["next_tasks"]][:6]))
    analysis = result["model_analysis"]
    assert [task["id"] for task in analysis["ordered_next_actions"]] == expected_order
    assert analysis["evidence"] and analysis["method"] == "claude_evidence_selection_and_research_ranking"
    assert result["outcomes"] == prepared["outcomes"] and result["lead_vi"] == prepared["lead_vi"]
    assert not analysis["changes_legal_verdict"]
    assert service.get(owner["account_id"], owner["enterprise_id"], prepared["id"])["model_analysis"] == analysis
    assert gateway.calls == 1


def test_analysis_projects_full_exact_chunk_so_model_cannot_crop_a_negation(setup):
    repo, owner, _, catalog = setup
    text = "DỮ LIỆU KIỂM THỬ. Tư vấn chuyển đổi số. Không hỗ trợ mua máy 500 triệu đồng."
    source(setup, text=text)
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "full-negation")
    sources = catalog.retrieve(prepared["question"])
    candidates = service._analysis_candidates(prepared, sources, prepared["intent"])
    data = analysis_response({"analysis_candidates": candidates})
    result = service._validate_synthesis(data, prepared, sources, candidates)
    assert result["evidence"][0]["quote_original"] == text
    assert "Không hỗ trợ" in result["evidence"][0]["excerpt_vi"]
    data["evidence_choices"][0]["quote_original"] = "hỗ trợ mua máy 500 triệu đồng"
    with pytest.raises(CoreError) as denied:
        service._validate_synthesis(data, prepared, sources, candidates)
    assert denied.value.code == "invalid_policy_response"


def test_analysis_candidates_exclude_unrelated_appendix_and_unrequested_outcome(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào?", "candidate-scope")
    sources = catalog.retrieve(prepared["question"])
    candidates = service._analysis_candidates(prepared, sources, prepared["intent"])
    by_id = {item["chunk_id"]: item["quote_original"] for item in sources}
    assert candidates["evidence"]
    assert all(item["outcome_id"] == "policy_discovery" for item in candidates["evidence"])
    assert all("Phụ lục 04" not in by_id[item["chunk_id"]] for item in candidates["evidence"])
    data = analysis_response({"analysis_candidates": candidates})
    data["evidence_choices"][0]["outcome_id"] = "application_window"
    with pytest.raises(CoreError) as denied:
        service._validate_synthesis(data, prepared, sources, candidates)
    assert denied.value.code == "invalid_policy_response"


def test_model_cannot_inject_paid_retry_or_duplicate_work_or_invented_task(setup):
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    service = PolicyService(repo)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho còn nhận hồ sơ không?", "forbidden-actions")
    sources = catalog.retrieve(prepared["question"])
    candidates = service._analysis_candidates(prepared, sources, prepared["intent"])
    data = analysis_response({"analysis_candidates": candidates})
    data["next_task_ids"] = ["paid_retry"]
    with pytest.raises(CoreError) as denied:
        service._validate_synthesis(data, prepared, sources, candidates)
    assert denied.value.code == "invalid_policy_response"
    data = analysis_response({"analysis_candidates": candidates})
    data["evidence_choices"] = [data["evidence_choices"][0]] * 2
    with pytest.raises(CoreError) as duplicate:
        service._validate_synthesis(data, prepared, sources, candidates)
    assert duplicate.value.code == "policy_duplicate_decision"


def test_minimal_company_profile_never_includes_arbitrary_ssot_or_finance_text():
    context = {"entities": [{"entity_type": "enterprise", "name": "BÍ MẬT lãi 99999999", "facts": [
        {"field": "legal_name", "value": "Tên công ty riêng"},
        {"field": "enterprise_type", "value": "Công ty TNHH", "value_state": "known"},
        {"field": "registration_province", "value": "Hà Nội", "value_state": "known"},
        {"field": "revenue", "value": "99999999"},
        {"field": "province", "value": "Hải Phòng", "value_state": "conflicted"}]}]}
    profile = PolicyService._company_profile(context)
    assert profile == {"entity_types": ["enterprise"], "registration_province": "unknown", "enterprise_type": "limited_company"}
    assert "99999999" not in json_text(profile) and "Tên công ty" not in json_text(profile)
    context["entities"][0]["facts"][1]["value"] = "Công ty TNHH lãi ròng 99999999"
    assert PolicyService._company_profile(context)["enterprise_type"] == "unknown"


def test_ssot_questions_only_ask_missing_permitted_facts_after_reviewed_conditions():
    result = {"outcomes": [{"id": "eligibility", "title_vi": "Đối chiếu điều kiện", "status": "needs_input",
               "missing_fields": ["registration_province", "revenue", "legal_name"], "citations": []}]}
    candidates = PolicyService._analysis_candidates(result, [], {"goal": "digital_inventory"})
    assert [question["field"] for question in candidates["ssot_questions"]] == ["registration_province"]
    result["outcomes"][0]["status"] = "awaiting_rule_review"
    assert PolicyService._analysis_candidates(result, [], {"goal": "digital_inventory"})["ssot_questions"] == []


@pytest.mark.asyncio
async def test_field_reclassified_restricted_while_queued_stops_before_model_dispatch(setup):
    from nmate.core_v1.ssot import CoreSSOTService
    repo, owner, _, catalog = setup
    catalog.bootstrap_official_notice()
    core = CoreSSOTService(repo)
    company = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "DỮ LIỆU KIỂM THỬ")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], company["id"],
        [{"field": "enterprise_type", "value": "Công ty TNHH"}], 0, "typed-company")
    gateway = FixtureGateway()
    service = PolicyService(repo, core=core, gateway=gateway)
    prepared = service.prepare(owner["account_id"], owner["enterprise_id"], "Số hóa kho có chương trình nào phù hợp?",
        "reclassified", entity_ids=[company["id"]])
    service.start(owner["account_id"], owner["enterprise_id"], prepared["id"], "start-reclassified", "test-only")
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_v1_field_definitions SET sensitivity='restricted' WHERE field_key='enterprise_type'")
    result = await service.execute_next()
    assert result["status"] == "failed" and result["error"]["code"] == "finance_egress_required"
    assert gateway.calls == 0 and result["provider_calls"] == 0


def test_successful_unchanged_http_refresh_records_check_without_renewing_legal_review(setup, monkeypatch):
    import httpx
    import nmate.policy_v1.catalog as module
    repo, owner, _, catalog = setup
    snapshot = catalog.bootstrap_official_notice()
    with repo.connection() as db:
        raw = db.execute("SELECT raw_bytes FROM pol_source_snapshots WHERE id=?", (snapshot["snapshot_id"],)).fetchone()[0]
    class Response:
        status_code = 200
        headers = {"content-type": "text/html"}
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def raise_for_status(self):
            pass
        def iter_bytes(self):
            yield raw
    class Client:
        def __init__(self, **kwargs):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *args):
            return False
        def stream(self, *args, **kwargs):
            return Response()
    monkeypatch.setattr(httpx, "Client", Client)
    monkeypatch.setattr(module.socket, "getaddrinfo", lambda *args, **kwargs: [(2, 1, 6, "", ("8.8.8.8", 443))])
    until = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    catalog.record_source_check(owner["account_id"], "HN-NOTICE-2026-14", result="verified_current", current_until=until, rationale="DỮ LIỆU KIỂM THỬ — gate riêng")
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_source_gates SET checked_at='2000-01-01T00:00:00+00:00' WHERE source_id='HN-NOTICE-2026-14'")
    result = catalog.refresh_source(owner["account_id"], "HN-NOTICE-2026-14")
    assert result["unchanged"]
    current = catalog.get_source("HN-NOTICE-2026-14")
    assert current["checked_at"] != "2000-01-01T00:00:00+00:00"
    assert current["availability"] == "verified_current" and current["current_until"] == until
    catalog.record_source_check(owner["account_id"], "HN-NOTICE-2026-14", result="unavailable", rationale="DỮ LIỆU KIỂM THỬ mất kết nối")
    catalog.refresh_source(owner["account_id"], "HN-NOTICE-2026-14")
    recovered = catalog.get_source("HN-NOTICE-2026-14")
    assert recovered["availability"] == "snapshot_only" and recovered["current_until"] is None
    assert all(not item["usable_for_assessment"] for item in catalog.retrieve("số hóa kho"))


@pytest.mark.parametrize("state", ["not_met", "unknown", "conflict"])
def test_window_claim_requires_applicability_and_current_scoped_check(state):
    from datetime import date
    now = datetime.now(timezone.utc)
    payload = {"claim_type": "application_window", "application_status": "open", "quota_verified": True,
               "application_checked_at": now.isoformat(), "window_valid_until": (now + timedelta(hours=1)).isoformat(),
               "items": [{"id": "window", "text_vi": "DỮ LIỆU KIỂM THỬ — đang nhận"}]}
    finding = {"kind": "claim", "status": "assessed", "payload": payload, "applies_when": {"state": state}, "evidence": []}
    request = {"target_date": date.today().isoformat()}
    intent = {"outcome_types": ["application_window"], "goal": "digital_inventory", "clarification_vi": None}
    result = PolicyService._result("test", request, intent, [], [finding])
    assert result["outcomes"][0]["status"] == "needs_source"
    stale = {**finding, "applies_when": {"state": "met"}, "payload": {**payload, "application_checked_at": "1999-01-01"}}
    assert PolicyService._result("test", request, intent, [], [stale])["outcomes"][0]["status"] == "needs_source"


def test_window_claim_proposal_rejects_stale_or_unzoned_timestamp(setup):
    _, owner, _, catalog = setup
    _, chunk = source(setup)
    with pytest.raises(CoreError) as denied:
        catalog.propose_member(owner["account_id"], kind="claim", policy_id="test", title_vi="DỮ LIỆU KIỂM THỬ",
            payload={"scope": {"jurisdiction": "VN-HN", "goal_types": ["digital_inventory"]}, "claim_type": "application_window",
                     "application_status": "open", "application_checked_at": "1999-01-01", "quota_verified": True,
                     "items": [{"id": "window", "text_vi": "DỮ LIỆU KIỂM THỬ"}]},
            evidence=[{"chunk_id": chunk["id"], "quote_original": chunk["text_original"], "supports_id": "window"}], effective_from="2026-01-01")
    assert denied.value.code == "invalid_window_claim"
