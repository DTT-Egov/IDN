"""Read recorded Claude JSON; never call a provider, network or repository."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from nmate.main.partial import STATUS, project_partial_research
from nmate.v03.core import CoreError, json_text


FIXTURE = Path(__file__).parent / "fixtures" / "unified_partial_us_failed_20261019.json"
FIXTURE_SHA256 = "50c782c0c150618f369eca9d81e410f17ae769671afcb15051b535aba49646f5"


@pytest.fixture
def recorded():
    value = json.loads(FIXTURE.read_text(encoding="utf-8"))
    return value["mission"], value["provider_envelope"]


def test_real_recorded_failed_output_has_verified_fixture_provenance():
    value = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == FIXTURE_SHA256
    assert value["provenance"]["kind"] == "actual_claude_output_on_synthetic_QA_enterprise"
    assert value["provenance"]["provider_attempt_id"] == "claude_fde243da3e434c8897f70d22af0dad86"
    assert len(value["provenance"]["source_raw_sha256"]) == 64


def test_actual_qa_answer_validates_registration_and_honest_prior_notice_gap_quarantines_whole_label(recorded):
    mission, envelope = recorded
    before = deepcopy((mission, envelope))
    result = project_partial_research(mission, envelope)
    assert (mission, envelope) == before
    assert result["status"] == STATUS and result["complete_report"] is False
    assert result["mission_status"] == "failed" and mission["status"] == "failed"
    assert result["model_calls"] == result["provider_attempts"] == result["ssot_writes"] == 0
    assert result["research_replayed"] is False
    assert result["actions"] == result["artifacts"] == []
    assert [answer["outcome_id"] for answer in result["validated_answers"]] == ["registration", "prior_notice"]
    assert result["validated_answers"][1]["status"] == "blocked_source"
    assert [item["outcome_id"] for item in result["blocked_outcomes"]] == ["label"]
    assert result["blocked_outcomes"][0]["title"] and result["blocked_outcomes"][0]["message"]
    assert result["audit"]["quarantined_answer_indexes"] == [2]
    assert result["audit"]["raw_output"] == envelope["data"]
    assert result["audit"]["raw_output_sha256"] == hashlib.sha256(json_text(envelope["data"]).encode()).hexdigest()
    assert result["audit"]["original_cost"] == mission["cost"]
    assert result["audit"]["original_error"]["stale_reason"] == mission["stale_reason"]
    invalid_fields = result["audit"]["raw_output"]["answers"][2]["missing_fields"]
    assert {"ingredients_declaration", "date_marking", "storage_instructions"} <= set(invalid_fields)
    citations = result["validated_answers"][0]["citations"]
    assert citations and all(citation["reference_id"] and citation["quote_original"] for citation in citations)
    assert all(citation["market_code"] == "US" and citation["original_language"] == "en" for citation in citations)


def test_one_tampered_quote_quarantines_whole_registration_answer_without_substring_repair(recorded):
    mission, envelope = recorded
    envelope["data"]["answers"][0]["citations"][0]["quote_original"] += " This additional sentence was invented."
    result = project_partial_research(mission, envelope)
    assert [answer["outcome_id"] for answer in result["validated_answers"]] == ["prior_notice"]
    assert {item["outcome_id"] for item in result["blocked_outcomes"]} == {"registration", "label"}
    assert result["audit"]["raw_output"] == envelope["data"]
    assert "khớp" in result["blocked_outcomes"][0]["message"]


def test_cross_market_reference_is_not_accepted_even_with_exact_quote_and_hash(recorded):
    mission, envelope = recorded
    reference = envelope["data"]["answers"][0]["citations"][0]["source_id"]
    record = next(record for record in mission["knowledge"]["records"] if record["id"] == reference)
    record["scope"]["jurisdiction"] = "DE"
    result = project_partial_research(mission, envelope)
    assert [answer["outcome_id"] for answer in result["validated_answers"]] == ["prior_notice"]
    assert next(item for item in result["blocked_outcomes"] if item["outcome_id"] == "registration")["error_code"] == "evidence_market_mismatch"


def test_context_market_mismatch_blocks_every_part(recorded):
    mission, envelope = recorded
    mission["knowledge"]["market_code"] = "DE"
    result = project_partial_research(mission, envelope)
    assert result["validated_answers"] == []
    assert len(result["blocked_outcomes"]) == 3


@pytest.mark.parametrize("mutation", ["duplicate", "known_field", "extra_field", "stale_source"])
def test_invalid_complete_answer_is_never_fixed_by_dropping_a_field_or_choosing_a_duplicate(recorded, mutation):
    mission, envelope = recorded
    answer = envelope["data"]["answers"][0]
    if mutation == "duplicate":
        envelope["data"]["answers"].append(deepcopy(answer))
    elif mutation == "known_field":
        answer["missing_fields"].append("net_quantity")
    elif mutation == "extra_field":
        answer["approved_by_government"] = True
    else:
        reference = answer["citations"][0]["source_id"]
        next(record for record in mission["knowledge"]["records"] if record["id"] == reference)["freshness_state"] = "needs_revalidation"
    before = deepcopy((mission, envelope))
    result = project_partial_research(mission, envelope)
    assert (mission, envelope) == before
    assert [item["outcome_id"] for item in result["validated_answers"]] == ["prior_notice"]
    assert "registration" in {item["outcome_id"] for item in result["blocked_outcomes"]}


def test_bad_json_retains_original_raw_data_and_blocks_all_outcomes_without_replay(recorded):
    mission, envelope = recorded
    envelope["data"] = "{Not valid JSON"
    result = project_partial_research(mission, envelope)
    assert result["validated_answers"] == [] and len(result["blocked_outcomes"]) == 3
    assert result["audit"]["raw_output"] == "{Not valid JSON"
    assert result["model_calls"] == 0


def test_malformed_outcome_type_is_quarantined_without_crashing_or_hiding_valid_other_answers(recorded):
    mission, envelope = recorded
    envelope["data"]["answers"][2]["outcome_id"] = ["label"]
    result = project_partial_research(mission, envelope)
    assert [item["outcome_id"] for item in result["validated_answers"]] == ["registration", "prior_notice"]
    assert result["audit"]["quarantined_answer_indexes"] == [2]


def test_metadata_allowlist_does_not_copy_credentials_or_arbitrary_headers_into_audit(recorded):
    mission, envelope = recorded
    envelope.update(api_key="PRIVATE_SENTINEL", headers={"authorization": "PRIVATE_SENTINEL"})
    result = project_partial_research(mission, envelope)
    assert "PRIVATE_SENTINEL" not in str(result)
    assert result["audit"]["provider_metadata"]["attempt_id"] == envelope["attempt_id"]


def test_partial_cannot_claim_an_artifact_was_created_when_failed_mission_has_no_saved_artifact(recorded):
    mission, envelope = recorded
    # An independent valid-shaped test response, not a runtime repair path.
    label = envelope["data"]["answers"][2]
    label["missing_fields"] = []
    label["status"] = "artifact_ready"
    assert mission.get("artifacts", []) == []
    result = project_partial_research(mission, envelope)
    blocked = next(item for item in result["blocked_outcomes"] if item["outcome_id"] == "label")
    assert blocked["error_code"] == "partial_artifact_missing"
    assert result["artifacts"] == []


def test_successful_or_stale_mission_cannot_be_reclassified_as_a_failed_partial(recorded):
    mission, envelope = recorded
    for status in ("completed_partial", "running", "needs_revalidation"):
        mission["status"] = status
        with pytest.raises(CoreError, match="đang báo lỗi"):
            project_partial_research(mission, envelope)
