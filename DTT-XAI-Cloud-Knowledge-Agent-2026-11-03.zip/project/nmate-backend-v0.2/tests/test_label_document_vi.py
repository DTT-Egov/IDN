"""New Vietnamese documents never rewrite previously saved label revisions."""
import asyncio
import hashlib
import json

import pytest

from nmate.v03.core import CoreRepository, json_text
from nmate.v03.identity import LocalAccounts
from nmate.v03.label_document import DOCUMENT_FORMAT_VERSION, UNKNOWN_VALUE_VI
from nmate.v03.markets import get_market
from nmate.v03.missions import MissionService, field_specs


@pytest.mark.parametrize("market", ["US", "DE", "JP"])
def test_vietnamese_document_preserves_values_and_optional_originals(market):
    registry = get_market(market)
    fields = [{"id": key, "label_en": original, "label_vi": vietnamese,
               "help_vi": help_vi, "state": state, "value": "Trà Sen Tây Hồ 2026" if key == "statement_of_identity" else "100 g" if key == "net_quantity" else None}
              for key, original, vietnamese, help_vi, state in field_specs(market)]
    result = MissionService._artifact("label-a", 1, {
        "product_reference": "Trà Sen Tây Hồ 2026", "market_code": market,
        "market_name_vi": registry["name_vi"], "label_language": registry["label_language"], "fields": fields,
    })
    assert result["document_format_version"] == DOCUMENT_FORMAT_VERSION
    assert hashlib.sha256(result["markdown"].encode()).hexdigest() == result["markdown_sha256"]
    assert "Not supplied" not in result["markdown"]
    assert UNKNOWN_VALUE_VI in result["markdown"]
    assert "## Tên thực phẩm" in result["markdown"]
    assert "Đối chiếu tên mục nguyên bản" in result["markdown"]
    assert "Trà Sen Tây Hồ 2026" in result["markdown"]
    assert "100 g" in result["markdown"]
    assert result["fields"][0]["value"] == "Trà Sen Tây Hồ 2026"
    assert result["fields"][-1]["value"] is None


def test_read_keeps_old_document_and_explicit_save_creates_localized_revision(tmp_path):
    repo = CoreRepository(tmp_path / "labels.sqlite3")
    owner = LocalAccounts(repo).register("labels-owner", "TestPassword12345", "Trà Sen")
    service = MissionService(repo)
    scope = owner["account_id"], owner["enterprise_id"]
    mission = service.prepare(*scope, "Tôi có Trà Sen Tây Hồ gửi Mỹ, cần chuẩn bị nhãn tiếng Anh.", "prepare")
    service.start(*scope, mission["id"], "start")
    assert asyncio.run(service.execute_next())
    # A genuine stored legacy shape, without the new render metadata.
    with repo.connection(write=True) as db:
        row = db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mission["id"],)).fetchone()
        payload = json.loads(row[0])
        old = payload["artifacts"][0]
        old["markdown"] = "# Khung nhãn cũ\n[Not supplied / applicability not established]\n"
        old.pop("document_format_version")
        old.pop("markdown_sha256")
        original_json = json_text(old)
        db.execute("UPDATE v03_artifact_revisions SET data_json=? WHERE id=? AND version=1", (original_json, old["id"]))
        db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(payload), mission["id"]))
    first = service.get(*scope, mission["id"])["label"]
    assert first["markdown"] == old["markdown"]
    assert "markdown_sha256" not in first
    revised = service.update_label(*scope, mission["id"], old["id"], {"net_quantity": "100 g"}, 1, "save")
    assert revised["label"]["version"] == 2
    assert revised["label"]["document_format_version"] == DOCUMENT_FORMAT_VERSION
    assert UNKNOWN_VALUE_VI in revised["label"]["markdown"]
    assert "Not supplied" not in revised["label"]["markdown"]
    same = service.update_label(*scope, mission["id"], old["id"], {"net_quantity": "100 g"}, 1, "save")
    assert same["label"]["version"] == 2
    with repo.connection() as db:
        rows = db.execute("SELECT version,data_json FROM v03_artifact_revisions WHERE id=? ORDER BY version", (old["id"],)).fetchall()
    assert len(rows) == 2 and rows[0]["data_json"] == original_json
