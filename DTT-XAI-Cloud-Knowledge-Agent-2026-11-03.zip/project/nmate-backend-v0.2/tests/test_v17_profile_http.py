"""Actual authenticated BFF→MCP ownership and registration/profile separation."""
import httpx
from test_core_policy_http import running, register, good, call


def test_new_owner_can_open_and_confirm_registered_profile_without_another_enterprise(tmp_path):
    calls = []
    async def forbidden(*args, **kwargs):
        calls.append(1)
        raise AssertionError('No model call authorized')
    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url), \
            httpx.Client(base_url=url, trust_env=False, timeout=20) as owner, \
            httpx.Client(base_url=url, trust_env=False, timeout=20) as other:
        session = register(owner, url, 'v17-profile-http-owner')
        outsider = register(other, url, 'v17-profile-http-other')
        enterprise = session['enterprise']['id']
        profile = good(owner, url, session, 'core_get_enterprise_profile')
        assert profile['state'] == 'not_initialized' and not profile['candidates']
        profile = good(owner, url, session, 'core_open_enterprise_profile', operation_id='open-registered-profile')
        entity_id = profile['entity_id']
        proposal = good(owner, url, session, 'core_propose_facts', entity_id=entity_id, expected_version=0,
                        operation_id='propose-trading-name', facts=[{'field': 'trading_name', 'value': 'Cơ sở Trà Sen đã xác nhận'}])
        good(owner, url, session, 'core_confirm_facts', proposal_id=proposal['proposal_id'], expected_version=0,
             operation_id='confirm-trading-name', proposal_hash=proposal['proposal_hash'],
             expected_field_versions=proposal['expected_field_versions'])
        reopened = good(owner, url, session, 'core_get_enterprise_profile')
        assert reopened['entity']['values']['trading_name'] == 'Cơ sở Trà Sen đã xác nhận'
        assert 'legal_name' not in reopened['entity']['values']
        case = good(owner, url, session, 'policy_prepare', question='Chị muốn kiến nghị mở lớp sổ sách buổi tối.',
                    operation_id='policy-for-registered-profile')['policy_case']
        draft = good(owner, url, session, 'policy05_create_draft', question=case['question'], kind='business_petition',
                     policy_case_id=case['id'], operation_id='draft-for-registered-profile')['policy_draft']
        assert draft['context_manifest']['enterprise_entity_id'] == entity_id
        assert 'Cơ sở Trà Sen đã xác nhận' in draft['body']['enterprise_summary']
        assert not call(other, url, outsider, 'core_get_enterprise_profile', enterprise_id=enterprise)['ok']
        with app.state.repo.connection() as db:
            assert db.execute('SELECT count(*) FROM v03_enterprises WHERE id=?', (enterprise,)).fetchone()[0] == 1
            assert db.execute('SELECT count(*) FROM v03_entities WHERE enterprise_id=?', (enterprise,)).fetchone()[0] == 1
        assert not calls
