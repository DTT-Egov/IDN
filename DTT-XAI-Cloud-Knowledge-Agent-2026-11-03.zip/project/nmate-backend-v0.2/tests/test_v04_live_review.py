"""Actual 0.4A state machine with injected Claude responses. No paid IO."""
import copy
import hashlib
import json
import socket
import threading
import time

import httpx
import pytest
import uvicorn

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.mcp import create_mcp
from nmate.v03.missions import MissionService
from nmate.v04.live_review import (LIVE_TOOLS, LiveConversationService, LiveIntakeService,
                                    V04ReviewProvider)
from nmate.v04.conversations import ConversationService
from nmate.v04.intake import IntakeService
from test_v04_intake import ASSETS, upload, confirm


def result(text="Tôi muốn số hóa bán hàng và tồn kho", **changes):
    value = {"primary": "digitize_operations", "primary_quote": text, "focus": None,
        "market_codes": [], "market_clarification_needed": False, "working_answers": [], "image_facts": [],
        "unread_image_sha256": [], "assistant_text": "Mình đang giữ dữ kiện trong bản nháp. Bạn muốn ưu tiên tồn kho hay bán hàng?",
        "next_steps": ["Đối chiếu những dữ kiện bạn muốn ghi vào hồ sơ."], "pending_question": "Bạn muốn ưu tiên vấn đề nào?",
        "actions": [{"id": "choose_problem", "title": "Chọn vấn đề cần cải thiện", "basis": "Bạn nêu mục tiêu số hóa.", "status": "needs_input"}]}
    value.update(changes)
    return value


class Stub:
    def __init__(self, values):
        self.values, self.calls, self.callback = values, [], None

    async def __call__(self, model, payload, limit):
        self.calls.append((model, copy.deepcopy(payload)))
        if self.callback:
            self.callback()
        item = self.values[min(len(self.calls)-1, len(self.values)-1)]
        if isinstance(item, Exception):
            raise item
        return {"text": json.dumps(item, ensure_ascii=False), "model": model, "request_id": "stub-request",
                "stop_reason": "end_turn", "usage": {"input_tokens": 12, "output_tokens": 20, "secret": "never persist"},
                "headers": {"Authorization": "must not persist"}}


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "live.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("live-owner", "FakePassword012345", "Trà Sen live QA")
    other = accounts.register("other-owner", "FakePassword012345", "Other enterprise")
    return repo, owner, other


def services(workspace, values):
    repo, owner, other = workspace
    stub = Stub(values)
    provider = V04ReviewProvider(repo, request_fn=stub)
    intake = LiveIntakeService(repo, provider=provider)
    return provider, intake, LiveConversationService(intake), stub


async def send(chat, owner, text="Tôi muốn số hóa bán hàng và tồn kho", op="live-send-0001", **kwargs):
    return await chat.send_async(owner["account_id"], owner["enterprise_id"], text, kwargs.pop("attachments", []),
                                 op, paid_consent=kwargs.pop("paid_consent", True), **kwargs)


@pytest.mark.asyncio
async def test_live_send_reads_actual_xlsx_and_vision_one_call_then_free_reads_and_confirm(workspace):
    repo, owner, other = workspace
    image = upload(ASSETS / "tra-sen-bao-bi-mau.png")
    sha = hashlib.sha256((ASSETS / image["filename"]).read_bytes()).hexdigest()
    first = result(image_facts=[{"sha256": sha, "field": "name", "value": "Trà Sen Tây Hồ", "quote": "Trà Sen Tây Hồ", "location": "Tên sản phẩm ở mặt trước"}])
    provider, intake, chat, stub = services(workspace, [first])
    # A network callback can take an independent writer lock: no SQL transaction
    # is held while waiting for Claude.
    def separate_writer():
        with repo.connection(write=True) as db:
            db.execute("CREATE TABLE IF NOT EXISTS test_free_during_network(value INTEGER)")
    stub.callback = separate_writer
    params = dict(attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx"), image])
    conversation = await send(chat, owner, **params)
    assert len(stub.calls) == 1 and stub.calls[0][0] == "claude-opus-5-5"
    assert len(stub.calls[0][1]["input"]["parsed_xlsx_facts"]) == 9
    assert "data_base64" not in json.dumps(stub.calls[0][1])
    item = conversation["intake"]
    assert len(item["candidates"]) == 9
    assert item["intent"]["interpretation_mode"] == "claude_validated_dialogue"
    assert conversation["messages"][-1]["text"] == first["assistant_text"]
    assert conversation["model_calls"] == conversation["cost"]["paid_calls"] == 1
    assert item["origins"]["business_plan"] == "claude"
    name = next(c for c in item["candidates"] if c["field"] == "name")
    assert {s["kind"] for s in name["sources"]} == {"spreadsheet", "claude_vision"}
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    assert (await send(chat, owner, **params))["id"] == conversation["id"]
    chat.get(owner["account_id"], owner["enterprise_id"], conversation["id"])
    chat.list(owner["account_id"], owner["enterprise_id"])
    saved = confirm(intake, owner, item)
    assert len(stub.calls) == 1 and saved["status"] == "confirmed"
    assert saved["business_plan"] == item["business_plan"]
    assert saved["origins"]["next_steps"] == "server_confirmation_state"
    with pytest.raises(CoreError):
        chat.get(other["account_id"], other["enterprise_id"], conversation["id"])
    ledger = provider.summary()
    assert ledger["paid_calls"] == 1 and ledger["remaining_attempts"] == 3
    assert ledger["attempts"][0]["usage"] == {"input_tokens": 12, "output_tokens": 20}


@pytest.mark.asyncio
async def test_pending_goal_change_keeps_candidates_draft_and_actual_claude_answers(workspace):
    repo, owner, _ = workspace
    initial = "Tôi muốn số hóa bán hàng và tồn kho"
    goal = "Không cải thiện bao bì, chỉ ưu tiên giảm sai lệch tồn kho"
    counts = "Tồn trên sổ 120 hộp, kiểm đếm 110 hộp cuối ngày hôm qua"
    first = result(initial)
    second = result(goal, focus="inventory_accuracy", assistant_text="Mình chuyển sang ưu tiên sai lệch tồn kho. Tồn trên sổ và thực tế đang là bao nhiêu?")
    third = result(primary_quote=None, focus="inventory_accuracy", working_answers=[
        {"key": "book_quantity", "value": "120", "quote": "Tồn trên sổ 120 hộp", "message_index": 4},
        {"key": "physical_quantity", "value": "110", "quote": "kiểm đếm 110 hộp", "message_index": 4},
        {"key": "count_date_phrase", "value": "hôm qua", "quote": "hôm qua", "message_index": 4}],
        assistant_text="Thực tế ít hơn sổ 10 hộp. Bạn xác nhận ngày kiểm kê và mã sản phẩm nhé?", next_steps=["Xác nhận ngày và mã sản phẩm."])
    provider, intake, chat, stub = services(workspace, [first, second, third])
    initial = await send(chat, owner, initial, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")])
    item = initial["intake"]
    employee = next(c["id"] for c in item["candidates"] if c["field"] == "employee_count")
    draft = {"selected": {c["id"]: c["id"] != employee for c in item["candidates"]}, "edits": {}, "choices": {}}
    chat.save_draft(owner["account_id"], owner["enterprise_id"], initial["id"], item["id"], draft, "save-live-draft")
    changed = await send(chat, owner, goal, op="live-change-goal", conversation_id=initial["id"], draft={"intake_id": item["id"], **draft})
    assert changed["intake"]["id"] == item["id"] and changed["intake"]["candidates"] == item["candidates"]
    saved_draft = changed["drafts"][item["id"]]
    assert {key: saved_draft[key] for key in ("selected", "edits", "choices")} == draft
    assert saved_draft["base_review_revision"] == changed["intake"]["review"]["revision"]
    assert saved_draft["ui_revision"] == 2
    # UI concurrency metadata belongs to the application, not Claude's input.
    assert stub.calls[-1][1]["input"]["draft"] == {"intake_id": item["id"], **draft}
    assert "base_review_revision" not in json.dumps(stub.calls[-1][1]["input"])
    assert "ui_revision" not in json.dumps(stub.calls[-1][1]["input"])
    counted = await send(chat, owner, counts, op="live-count-reply", conversation_id=initial["id"])
    answers = counted["intake"]["intent"]["working_answers"]
    assert answers == {"book_quantity": 120., "physical_quantity": 110., "count_date_phrase": "hôm qua"}
    assert counted["messages"][-1]["text"] == third["assistant_text"]
    assert len(counted["messages"]) == 6 and counted["model_calls"] == 3
    assert all(c[0] == "claude-sonnet-5-5" for c in stub.calls)
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []


@pytest.mark.asyncio
async def test_no_consent_unauthorized_and_direct_prepare_do_not_dispatch(workspace):
    repo, owner, other = workspace
    provider, intake, chat, stub = services(workspace, [result()])
    with pytest.raises(CoreError, match="đồng ý"):
        await send(chat, owner, paid_consent=False)
    with pytest.raises(CoreError):
        await chat.send_async(other["account_id"], owner["enterprise_id"], "test", [], "unauthorized-send", paid_consent=True)
    with pytest.raises(CoreError, match="nút gửi"):
        intake.prepare(owner["account_id"], owner["enterprise_id"], "test", [], "bypass-prepare-live")
    assert stub.calls == [] and provider.summary()["paid_calls"] == 0


@pytest.mark.asyncio
@pytest.mark.parametrize("invalid", ["ungrounded", "false_save", "invented_date"])
async def test_invalid_claude_output_stops_without_fallback_or_paid_replay(workspace, invalid):
    repo, owner, _ = workspace
    out = result()
    if invalid == "ungrounded":
        out["primary_quote"] = "Never said this"
    elif invalid == "false_save":
        out["assistant_text"] = "Mình đã lưu hồ sơ của bạn"
    else:
        out.update(focus="inventory_accuracy", working_answers=[{"key": "count_date", "value": "2026-10-18", "quote": "hôm qua", "message_index": 0}])
    provider, intake, chat, stub = services(workspace, [out])
    question = "Tôi muốn số hóa bán hàng và tồn kho hôm qua" if invalid == "invented_date" else "Tôi muốn số hóa bán hàng và tồn kho"
    if invalid == "invented_date":
        out["primary_quote"] = question
    for _ in range(2):
        with pytest.raises(CoreError):
            await send(chat, owner, question)
    assert len(stub.calls) == 1 and chat.list(owner["account_id"], owner["enterprise_id"]) == []
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    assert provider.summary()["paid_calls"] == 1


@pytest.mark.asyncio
async def test_provider_failure_persists_budget_no_retry_even_after_restart(workspace):
    repo, owner, _ = workspace
    provider, intake, chat, stub = services(workspace, [TimeoutError("never show secret")])
    for _ in range(2):
        with pytest.raises(CoreError) as error:
            await send(chat, owner)
        assert "secret" not in str(error.value)
    assert len(stub.calls) == 1
    provider2 = V04ReviewProvider(repo, request_fn=stub)
    chat2 = LiveConversationService(LiveIntakeService(repo, provider=provider2))
    with pytest.raises(CoreError):
        await send(chat2, owner)
    for index in range(1, 4):
        with pytest.raises(CoreError):
            await send(chat2, owner, op=f"live-failure-{index}")
    with pytest.raises(CoreError) as exhausted:
        await send(chat2, owner, op="live-over-budget")
    assert exhausted.value.code == "LIVE_BUDGET_EXHAUSTED"
    assert len(stub.calls) == 4 and provider2.summary()["remaining_attempts"] == 0


@pytest.mark.asyncio
async def test_atomic_conversation_failure_can_commit_cached_response_without_second_call(workspace, monkeypatch):
    repo, owner, _ = workspace
    provider, intake, chat, stub = services(workspace, [result()])
    original = repo._save_operation
    def fail(db, account, enterprise, kind, *rest):
        if kind == "v04_conversation_send":
            raise RuntimeError("rollback test")
        return original(db, account, enterprise, kind, *rest)
    monkeypatch.setattr(repo, "_save_operation", fail)
    with pytest.raises(RuntimeError):
        await send(chat, owner)
    assert intake.list(owner["account_id"], owner["enterprise_id"]) == []
    assert chat.list(owner["account_id"], owner["enterprise_id"]) == []
    monkeypatch.setattr(repo, "_save_operation", original)
    completed = await send(chat, owner)
    assert completed["model_calls"] == 1 and len(stub.calls) == 1


@pytest.mark.asyncio
async def test_live_mcp_registry_blocks_other_paid_and_direct_intake_paths(workspace):
    repo, owner, _ = workspace
    provider, intake, chat, stub = services(workspace, [result()])
    server = create_mcp(repo, MissionService(repo), intake=intake, tool_allowlist=LIVE_TOOLS)
    tools = {t.name for t in await server.list_tools()}
    assert tools == LIVE_TOOLS
    assert not tools & {"prepare_mission", "start_mission", "prepare_intake", "clarify_intake", "update_enterprise_facts"}


def test_http_to_mcp_live_adapter_single_dispatch_replay_and_paid_gate(tmp_path):
    from nmate.v04.live_local import make_live_app
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    stub = Stub([result()])
    app = make_live_app(tmp_path / "http.sqlite3", api_key="fake-not-a-provider-key",
        simple_model="claude-sonnet-5-5", complex_model="claude-opus-5-5", port=port,
        request_fn=stub, cookie_namespace="v04_http_fake_live")
    instance = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error", access_log=False))
    thread = threading.Thread(target=instance.run, daemon=True)
    thread.start()
    deadline = time.monotonic()+15
    while not instance.started:
        assert thread.is_alive() and time.monotonic() < deadline
        time.sleep(.02)
    try:
        url = f"http://127.0.0.1:{port}"
        with httpx.Client(base_url=url) as web:
            pre = web.get("/api/v03/session").json()
            response = web.post("/api/v03/register", headers={"Origin": url, "X-CSRF-Token": pre["csrf_token"]},
                json={"username": "http-live-owner", "password": "FakePassword012345", "enterprise_name": "Trà Sen HTTP"})
            assert response.status_code == 200
            session = response.json()
            assert "v04_http_fake_live_session=" in response.headers["set-cookie"]
            headers = {"Origin": url, "X-CSRF-Token": session["csrf_token"]}
            arguments = {"enterprise_id": session["enterprise"]["id"], "text": "Tôi muốn số hóa bán hàng và tồn kho",
                         "attachments": [], "operation_id": "http-live-message"}
            def call(name, args):
                return web.post("/api/v03/mcp/call", headers=headers, json={"name": name, "arguments": args})
            denied = call("send_message", arguments).json()
            assert denied["ok"] is False and denied["error"]["code"] == "PAID_CONSENT_REQUIRED"
            assert stub.calls == []
            arguments["paid_consent"] = True
            first = call("send_message", arguments).json()
            assert first["ok"] is True, first
            assert first["data"]["messages"][-1]["text"] == result()["assistant_text"]
            repeated = call("send_message", arguments).json()
            assert repeated["data"]["id"] == first["data"]["id"]
            read = call("get_conversation", {"enterprise_id": arguments["enterprise_id"], "conversation_id": first["data"]["id"]}).json()
            assert read["ok"] and read["data"]["model_calls"] == 1 and len(stub.calls) == 1
            blocked = call("prepare_mission", {"enterprise_id": arguments["enterprise_id"], "user_text": "test", "operation_id": "blocked-v03-start"})
            assert blocked.status_code == 400 and len(stub.calls) == 1
            runtime = web.get("/api/v04/qa-status").json()
            assert runtime["mode"] == "live_claude_review_v04" and runtime["remaining_attempts"] == 3
    finally:
        instance.should_exit = True
        thread.join(10)
        assert not thread.is_alive()


def conflicting_vision_result():
    image = upload(ASSETS / "tra-sen-bao-bi-mau.png")
    sha = hashlib.sha256((ASSETS / image["filename"]).read_bytes()).hexdigest()
    output = result(focus="inventory_accuracy", image_facts=[{
        "sha256": sha, "field": "net_quantity", "value": "120 g", "quote": "Lượng tịnh: 120 g",
        "location": "Dòng lượng tịnh trên nhãn"}],
        assistant_text="Hai nguồn khác nhau: ảnh 120 g, Excel 100 g. Bạn chọn giá trị cho hồ sơ nhé?",
        pending_question="Bạn chọn 100 g hay 120 g?")
    return image, sha, output


@pytest.mark.asyncio
async def test_saved_draft_choice_and_edits_reach_actual_request_without_becoming_ssot(workspace):
    repo, owner, _ = workspace
    image, sha, first = conflicting_vision_result()
    provider, intake, chat, stub = services(workspace, [first, result(primary_quote=None, focus="inventory_accuracy")])
    conversation = await send(chat, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx"), image])
    item = conversation["intake"]
    quantity = next(c for c in item["candidates"] if c["field"] == "net_quantity" and c["value"] == "100 g")
    ignored = next(c for c in item["candidates"] if c["field"] == "net_quantity" and c["value"] == "120 g")
    name = next(c for c in item["candidates"] if c["field"] == "name")
    draft = {"selected": {ignored["id"]: False}, "edits": {name["id"]: "Trà Sen Tây Hồ 2026"},
             "choices": {quantity["id"]: "incoming"}}
    chat.save_draft(owner["account_id"], owner["enterprise_id"], conversation["id"], item["id"], draft, "save-effective-draft")
    # Simulate reopening history: no draft is sent with the next user message.
    chat = LiveConversationService(LiveIntakeService(repo, provider=provider))
    reopened = chat.get(owner["account_id"], owner["enterprise_id"], conversation["id"])
    assert reopened["drafts"][item["id"]]["ui_revision"] == 1
    assert reopened["drafts"][item["id"]]["base_review_revision"] == item["review"]["revision"]
    await send(chat, owner, "Tiếp tục kiểm kê theo hộp", op="use-saved-draft", conversation_id=reopened["id"])
    actual = stub.calls[-1][1]["input"]
    assert actual["draft"] == {"intake_id": item["id"], **draft}
    assert "base_review_revision" not in json.dumps(actual)
    assert "ui_revision" not in json.dumps(actual)
    effective = actual["effective_context"]
    quantity_field = next(f for f in effective["active_editable_draft"] if f["field"] == "net_quantity")
    assert quantity_field["state"] == "chosen_not_saved" and quantity_field["effective_value"] == "100 g"
    assert quantity_field["is_committed"] is False
    assert next(f for f in effective["active_editable_draft"] if f["field"] == "name")["effective_value"] == "Trà Sen Tây Hồ 2026"
    assert not any(c["field"] == "net_quantity" for c in actual["pending_candidates"])
    archived = next(c for c in effective["archived_observations"] if c["candidate_id"] == ignored["id"])
    assert archived["observed_value"] == "120 g" and archived["sources"][0]["sha256"] == sha
    assert archived["status"] == "excluded_in_editable_draft"
    assert effective["owner_decisions"] == [] and effective["confirmed_ssot"]["fact_refs"] == []
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
    assert len(stub.calls) == 2


@pytest.mark.asyncio
async def test_confirmed_decision_survives_new_intake_history_and_restart_with_source_audit(workspace):
    repo, owner, _ = workspace
    image, sha, first = conflicting_vision_result()
    continuation = result(primary_quote=None, focus="inventory_accuracy", assistant_text="Bạn cho mình ngày kiểm kê và mã sản phẩm để đối chiếu tồn kho theo hộp nhé?",
                          pending_question="Ngày kiểm kê và mã sản phẩm là gì?", next_steps=["Đối chiếu phiếu nhập và xuất theo hộp."])
    provider, intake, chat, stub = services(workspace, [first, continuation, continuation])
    conversation = await send(chat, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx"), image])
    item = conversation["intake"]
    selected = [c["id"] for c in item["candidates"] if not (c["field"] == "net_quantity" and c["value"] == "120 g")]
    choices = {c["id"]: "incoming" for c in item["candidates"] if c["id"] in selected and c["status"] == "conflict"}
    before = copy.deepcopy(item["candidates"])
    confirm(intake, owner, item, selected=selected, conflict_choices=choices)
    assert len(stub.calls) == 1
    current = repo.get_context(owner["account_id"], owner["enterprise_id"])
    product = next(e for e in current["entities"] if e["entity_type"] == "product")
    assert product["values"]["net_quantity"] == "100 g"
    continued = await send(chat, owner, "Tồn trên sổ 120 hộp, kiểm đếm 110 hộp", op="after-confirmed-choice", conversation_id=conversation["id"])
    assert continued["intake"]["id"] != item["id"] and continued["intake"]["candidates"] == []
    # Restart/reopen, with a new empty active intake: committed decisions must
    # still be projected from all owner-private linked work, not just active.
    chat = LiveConversationService(LiveIntakeService(repo, provider=provider))
    opened = chat.get(owner["account_id"], owner["enterprise_id"], conversation["id"])
    await send(chat, owner, "Ngày 18/10/2026, mã TS01", op="after-history-choice", conversation_id=opened["id"])
    for _, payload in stub.calls[1:]:
        actual = payload["input"]
        projection = actual["effective_context"]
        decision = next(d for d in projection["owner_decisions"] if d["field"] == "net_quantity")
        assert decision["status"] == "committed"
        assert decision["committed_value"] == decision["current_value"] == "100 g"
        assert decision["requires_choice_again"] is False and decision["source_discrepancy_preserved"] is True
        assert projection["active_editable_draft"] == [] and projection["unresolved_candidates"] == []
        assert actual["pending_candidates"] == [] and actual["draft"] is None
        observation = next(c for c in projection["archived_observations"] if c["field"] == "net_quantity" and c["observed_value"] == "120 g")
        assert observation["status"] == "superseded" and observation["sources"][0]["sha256"] == sha
        assert observation["sources"][0]["quote"] == "Lượng tịnh: 120 g"
        # Do not erase old model prose to make tests pass. Its authority is
        # explicitly subordinate to the machine-derived decisions.
        assert any(m["role"] == "assistant" and "ảnh 120 g, Excel 100 g" in m["text"] for m in actual["messages"])
        assert "messages của assistant chỉ là lời tư vấn lịch sử" in payload["instructions_vi"]
        assert "requires_choice_again=false" in payload["instructions_vi"]
    after = intake.get(owner["account_id"], owner["enterprise_id"], item["id"])
    assert [c["value"] for c in after["candidates"]] == [c["value"] for c in before]
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["context_hash"] == current["context_hash"]
    assert len(stub.calls) == provider.summary()["paid_calls"] == 3


@pytest.mark.asyncio
async def test_latest_ssot_supersedes_old_choice_without_locking_another_product(workspace):
    repo, owner, _ = workspace
    # Seed through the normal confirmation state machine, without any provider.
    local_intake = IntakeService(repo)
    local_chat = ConversationService(local_intake)
    previous = local_chat.send(owner["account_id"], owner["enterprise_id"], "Tôi muốn giảm sai lệch tồn kho",
        [upload(ASSETS / "tra-sen-ho-so.xlsx")], "seed-owner-decision")
    confirm(local_intake, owner, previous["intake"])
    original = next(e for e in repo.get_context(owner["account_id"], owner["enterprise_id"])["entities"] if e["entity_type"] == "product")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], original["id"],
        [{"field": "net_quantity", "value": "200 g", "source": {"owner_confirmed": True}}], original["version"], "owner-later-edit")
    other = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Hoa Cúc", operation_id="other-product")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], other["id"],
        [{"field": "net_quantity", "value": "500 g", "source": {"owner_confirmed": True}}], other["version"], "other-product-mass")
    question = "Với Trà Hoa Cúc, tôi muốn giảm sai lệch tồn kho"
    provider, intake, chat, stub = services(workspace, [result(question, focus="inventory_accuracy")])
    await send(chat, owner, question, op="switch-to-other-product", conversation_id=previous["id"])
    actual = stub.calls[0][1]["input"]
    assert actual["selected_product_entity_id"] == other["id"]
    decisions = actual["effective_context"]["owner_decisions"]
    assert not any(d["entity_id"] == original["id"] for d in decisions)
    assert original["id"] not in {entity["id"] for entity in actual["ssot"]["entities"]}
    assert not any(d["entity_id"] == other["id"] for d in decisions)
    assert next(e for e in actual["effective_context"]["confirmed_ssot"]["entities"] if e["id"] == other["id"])["values"]["net_quantity"] == "500 g"
    assert "working_answers" not in (actual["previous_intent"] or {})
    assert len(stub.calls) == 1


@pytest.mark.asyncio
async def test_invalid_draft_edit_is_not_promoted_to_effective_value(workspace):
    repo, owner, _ = workspace
    provider, intake, chat, stub = services(workspace, [result(), result(primary_quote=None)])
    conversation = await send(chat, owner, attachments=[upload(ASSETS / "tra-sen-ho-so.xlsx")])
    item = conversation["intake"]
    quantity = next(c for c in item["candidates"] if c["field"] == "net_quantity")
    draft = {"selected": {}, "edits": {quantity["id"]: "100 stones"}, "choices": {}}
    chat.save_draft(owner["account_id"], owner["enterprise_id"], conversation["id"], item["id"], draft, "invalid-unit-draft")
    await send(chat, owner, "Tiếp tục giúp tôi", op="inspect-invalid-draft", conversation_id=conversation["id"])
    actual = stub.calls[-1][1]["input"]
    projection = next(f for f in actual["effective_context"]["active_editable_draft"] if f["field"] == "net_quantity")
    assert projection["state"] == "invalid_edit" and projection["effective_value"] is None
    assert "đơn vị" in projection["validation_error"]
    assert any(c["candidate_id"] == quantity["id"] for c in actual["pending_candidates"])
    assert repo.get_context(owner["account_id"], owner["enterprise_id"])["fact_refs"] == []
