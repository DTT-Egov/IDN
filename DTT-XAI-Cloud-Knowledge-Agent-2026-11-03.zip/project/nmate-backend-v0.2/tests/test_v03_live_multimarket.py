"""Contract tests only: injected outputs, no provider SDK, network or paid calls."""
import copy

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_review import LiveReviewMissionService, research_field_registry, validate_intake, validate_research


class GroundedModel:
    def __init__(self):
        self.calls = []

    async def __call__(self, kind, payload, **scope):
        self.calls.append((kind, payload, scope))
        inputs = payload["input"]
        market = inputs["resolved_market"]
        if kind == "intake":
            question = inputs["question"]
            data = {"scope": "us_food" if market and market["code"] == "US" else "export_food" if market else "unsupported",
                    "product_name": "Trà Sen Tây Hồ" if "Trà Sen Tây Hồ" in question else None,
                    "product_quote": "Trà Sen Tây Hồ" if "Trà Sen Tây Hồ" in question else None,
                    "outcomes": [{"id": "registration", "question_quote": "điều kiện nhập khẩu"},
                                 {"id": "label", "question_quote": "nhãn"}], "ambiguities": []}
        else:
            records = inputs["reference_records"]
            answers = []
            for outcome in inputs["outcomes"]:
                oid = outcome["id"]
                topic = {"registration": "facility_registration", "label": "food_label"}[oid]
                candidates = [record for record in records if topic in record["topics"]]
                # Exercise native German/Japanese excerpts rather than pretending
                # all sources are English or translating the evidence itself.
                record = next((record for record in candidates if record["original_language"] != "en"), candidates[0])
                answers.append({"outcome_id": oid, "status": "artifact_ready" if oid == "label" else "answered_general",
                                "text": "Theo trích đoạn đã lưu, cần đối chiếu phạm vi và dữ kiện trước khi kết luận riêng.",
                                "details_vi": "Nội dung tham khảo chưa được chuyên gia duyệt; bản nguồn không được cập nhật Internet trong lượt này.",
                                "citations": [{"source_id": record["id"], "quote_original": record["excerpt"]}],
                                "missing_fields": []})
            data = {"answers": answers, "actions": []}
        return {"data": data, "attempt_id": f"contract-{len(self.calls)}", "model": "injected-contract-test",
                "usage": {"input_tokens": 1, "output_tokens": 1}, "request_id": f"contract-{len(self.calls)}"}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "multimarket.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("owner", "TestPassword12345", "Doanh nghiệp Sen")
    model = GroundedModel()
    return repo, owner, model, LiveReviewMissionService(repo, model_call=model)


def owner_args(owner):
    return owner["account_id"], owner["enterprise_id"]


async def complete(service, owner, market, *, product=None, continuation=None):
    destination = {"US": "Mỹ", "DE": "Đức", "JP": "Nhật Bản"}[market]
    question = f"Tôi có Trà Sen Tây Hồ xuất sang {destination}, cần điều kiện nhập khẩu và nhãn."
    mission = await service.prepare_async(*owner_args(owner), question, f"prepare-{market}", product,
                                          continuation_mission_id=continuation, market_code=market)
    service.start(*owner_args(owner), mission["id"], f"start-{market}")
    assert await service.execute_next()
    return service.get(*owner_args(owner), mission["id"])


@pytest.mark.asyncio
@pytest.mark.parametrize("market,scope,language", [("US", "us_food", "en"), ("DE", "export_food", "de"), ("JP", "export_food", "ja")])
async def test_actual_adapter_supports_all_markets_and_native_citations(setup, market, scope, language):
    _, owner, model, service = setup
    mission = await complete(service, owner, market)
    assert mission["status"] == "completed_partial"
    assert mission["mode"] == "live_claude_review"
    assert mission["intent"]["scope"] == scope
    assert mission["market"]["code"] == market
    assert len(model.calls) == 2
    assert mission["cost"]["provider_attempts"] == 2
    assert all(call[1]["input"]["resolved_market"]["code"] == market for call in model.calls)
    research_payload = model.calls[1][1]
    missing_enum = research_payload["response_schema"]["$defs"]["ResearchAnswer"]["properties"]["missing_fields"]["items"]["enum"]
    assert missing_enum == research_payload["input"]["registered_missing_fields"]
    assert set(missing_enum) <= research_field_registry(market)
    assert "target_market" not in missing_enum
    assert ("fda_registration_status" in missing_enum) is (market == "US")
    assert mission["label"]["label_language"] == language
    assert mission["research_provenance"]["network_refresh"] is False
    assert mission["research_provenance"]["source_accessed_at"]
    assert mission["knowledge"]["network_calls"] == 0
    citations = [citation for answer in mission["answers"] for citation in answer["citations"]]
    assert all(citation["market_code"] == market for citation in citations)
    assert all(citation["quote_original"] for citation in citations)
    if market != "US":
        native = [citation for citation in citations if citation["original_language"] == language]
        assert native and all("quote_en" not in citation for citation in native)
        assert all("FDA" not in answer["title"] for answer in mission["answers"])
    else:
        assert all(citation["quote_en"] == citation["quote_original"] for citation in citations)


@pytest.mark.asyncio
@pytest.mark.parametrize("market", ["US", "DE", "JP"])
async def test_research_schema_locks_missing_fields_to_unfilled_market_registry(setup, market):
    _, owner, model, service = setup
    await complete(service, owner, market)
    payload = model.calls[-1][1]
    schema = payload["response_schema"]
    fields = schema["$defs"]["ResearchAnswer"]["properties"]["missing_fields"]["items"]["enum"]
    assert fields == payload["input"]["registered_missing_fields"]
    assert "name" not in fields  # Already known in SSOT, never ask it again.
    assert "nutrition_information" in fields
    if market == "US":
        assert not {"date_marking", "storage_instructions", "ingredients_declaration"}.intersection(fields)
    else:
        assert {"date_marking", "storage_instructions", "ingredients_declaration"} <= set(fields)
    assert set(schema["$defs"]["ResearchAnswer"]["properties"]["outcome_id"]["enum"]) == {"registration", "label"}
    assert schema["properties"]["answers"]["minItems"] == schema["properties"]["answers"]["maxItems"] == 2


@pytest.mark.asyncio
async def test_same_ssot_product_separate_market_profiles_drafts_and_sources(setup):
    _, owner, model, service = setup
    us = await complete(service, owner, "US")
    service.update_label_progress(*owner_args(owner), us["id"], us["label"]["id"],
                                  {"net_quantity": "100 g", "statement_of_identity": "Lotus tea"},
                                  ["net_quantity", "statement_of_identity"], us["label"]["version"],
                                  us["product"]["version"], "save-us",
                                  expected_market_profile_version=us["market_profile"]["version"])
    de = await complete(service, owner, "DE", product=us["product"]["entity_id"], continuation=us["id"])
    jp = await complete(service, owner, "JP", product=us["product"]["entity_id"], continuation=de["id"])
    assert len({mission["product"]["entity_id"] for mission in (us, de, jp)}) == 1
    assert len({mission["market_profile"]["entity_id"] for mission in (us, de, jp)}) == 3
    for mission in (de, jp):
        fields = {field["id"]: field for field in mission["label"]["fields"]}
        assert fields["net_quantity"]["value"] == "100 g"
        assert fields["statement_of_identity"]["value"] is None
        assert mission["label"]["parent_artifact_ref"] is None
        assert mission["context"]["reused_shared_fact_count"] >= 2
        assert "statement_of_identity" not in mission["context"]["market_values"]
        assert all(record["market_code"] == mission["market"]["code"] for record in mission["knowledge"]["records"])
    later_intakes = [payload for kind, payload, _ in model.calls if kind == "intake"][1:]
    assert all(payload["input"]["previous_mission_context"] is None for payload in later_intakes)


@pytest.mark.asyncio
async def test_cannot_substitute_foreign_reference_or_request_known_field(setup):
    _, owner, model, service = setup
    mission = await complete(service, owner, "JP")
    response = copy.deepcopy(next(call for call in model.calls if call[0] == "research")[1])
    envelope = await model("research", response)
    valid = copy.deepcopy(envelope)
    validate_research(valid, service._internal(mission["id"]))
    envelope["data"]["answers"][0]["citations"][0]["source_id"] = "FDA_REGISTRATION_SCOPE_VI_20261018_DRAFT"
    with pytest.raises(CoreError, match="gắn nhầm nguồn"):
        validate_research(envelope, service._internal(mission["id"]))
    valid["data"]["answers"][0]["missing_fields"] = ["name"]
    with pytest.raises(CoreError, match="SSOT"):
        validate_research(valid, service._internal(mission["id"]))


def test_intake_market_scope_is_server_bound_not_model_decided():
    data = {"scope": "us_food", "product_name": None, "product_quote": None,
            "outcomes": [{"id": "label", "question_quote": "nhãn"}], "ambiguities": []}
    with pytest.raises(CoreError):
        validate_intake({"data": data}, "Cần nhãn cho Nhật Bản.")
    data["scope"] = "export_food"
    assert validate_intake({"data": data}, "Cần nhãn.", market_code="DE").scope == "export_food"
    with pytest.raises(CoreError):
        validate_intake({"data": data}, "Cần nhãn cho Canada.")


@pytest.mark.asyncio
async def test_reload_or_restart_never_reexecutes_paid_market_stages(setup):
    repo, owner, model, service = setup
    mission = await complete(service, owner, "DE")
    question = mission["question"]
    same = await service.prepare_async(*owner_args(owner), question, "prepare-DE", market_code="DE")
    assert same["id"] == mission["id"]
    restarted = LiveReviewMissionService(repo, model_call=model)
    assert restarted.recover_interrupted() == 0
    assert not await restarted.execute_next()
    restarted.start(*owner_args(owner), mission["id"], "reload-start")
    assert not await restarted.execute_next()
    assert len(model.calls) == 2


@pytest.mark.asyncio
async def test_authorized_same_market_followup_receives_bounded_context_and_label_only_when_relevant(setup):
    _, owner, model, service = setup
    mission = await complete(service, owner, "US")
    original_call = service.model_call

    async def followup(kind, payload, **scope):
        envelope = await original_call(kind, payload, **scope)
        envelope["data"]["outcomes"] = [{"id": "label" if "nhãn" in payload["input"]["question"] else "registration",
                                          "question_quote": payload["input"]["question"]}]
        return envelope

    service.model_call = followup
    for op, question, expect_label in (("followup-facility", "Còn ngoại lệ của cơ sở trên thì sao?", False),
                                       ("followup-label", "Tôi muốn sửa tiếp bản nhãn đã lưu.", True)):
        prepared = await service.prepare_async(*owner_args(owner), question, op,
                                                mission["product"]["entity_id"], continuation_mission_id=mission["id"], market_code="US")
        assert prepared["intent"]["outcomes"][0]["question_part"] == question
        payload = model.calls[-1][1]["input"]
        context = payload["previous_mission_context"]
        assert context["question"] == mission["question"]
        assert context["market"]["code"] == "US"
        assert len(context["answers"]) == 2
        assert context["data_classification"] == "untrusted_private_conversation_context_not_source_evidence"
        assert bool(context["label_work_state"]) is expect_label
        assert payload["selected_product"]["id"] == mission["product"]["entity_id"]
        assert len(context["question"]) <= 2000 and all(len(answer["text"]) <= 600 for answer in context["answers"])


@pytest.mark.asyncio
async def test_followup_cross_owner_or_different_product_denied_before_model(setup):
    repo, owner, model, service = setup
    mission = await complete(service, owner, "US")
    other = LocalAccounts(repo).register("another-owner", "TestPassword12345", "Doanh nghiệp khác")
    count = len(model.calls)
    with pytest.raises(CoreError):
        await service.prepare_async(*owner_args(other), "Còn nhãn đó thì sao?", "private-followup",
                                    continuation_mission_id=mission["id"], market_code="US")
    other_product = repo.create_entity(*owner_args(owner), "product", "Bột Sen")
    with pytest.raises(CoreError, match="sản phẩm khác"):
        await service.prepare_async(*owner_args(owner), "Còn nhãn đó thì sao?", "wrong-product-followup",
                                    other_product["id"], continuation_mission_id=mission["id"], market_code="US")
    assert len(model.calls) == count


@pytest.mark.asyncio
@pytest.mark.parametrize("market,field", [("US", "target_market"), ("DE", "target_market"), ("JP", "target_market"),
                                          ("DE", "fda_registration_status"), ("JP", "fda_registration_status")])
async def test_strict_validator_rejects_already_resolved_market_and_foreign_fda_field(setup, market, field):
    _, owner, model, service = setup
    mission = await complete(service, owner, market)
    original_payload = next(payload for kind, payload, _ in model.calls if kind == "research")
    envelope = await model("research", original_payload)
    envelope["data"]["answers"][0]["missing_fields"] = [field]
    with pytest.raises(CoreError, match="ngoài hợp đồng"):
        validate_research(envelope, service._internal(mission["id"]))
