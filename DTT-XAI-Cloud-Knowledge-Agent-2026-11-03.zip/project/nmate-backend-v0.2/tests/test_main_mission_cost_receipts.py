"""Receipt projections use exact scoped identities; estimates never become actual."""
from __future__ import annotations

import json

from nmate.core_v1.gateway import SCHEMA
from nmate.v03.core import json_text
from test_main_context_usage import setup, plan, get
from test_review_commands_v2 import data_snapshot


def ledger(repo, owner, *, receipt="gateway-a", operation="research-a", kind="research", actual=103928):
    a, e = owner["account_id"], owner["enterprise_id"]
    with repo.connection(write=True) as db:
        db.executescript(SCHEMA)
        db.execute("INSERT INTO core_budget_grants(id,enterprise_id,account_id,approval_id,max_calls,cap_microusd,purposes_json,roles_json,expires_at,created_at) VALUES(?,?,?,?,1,1000000,'[\"legacy_research\"]','[\"complex\"]','2027-01-01','2026-10-22')", ("grant-"+receipt, e, a, "approval-"+receipt))
        db.execute("INSERT INTO core_model_operations(enterprise_id,operation_id,actor_id,request_hash,purpose,state,created_at) VALUES(?,?,?,'hash',?,'complete','2026-10-22')", (e, operation, a, "legacy_"+kind))
        db.execute("INSERT INTO core_model_attempts(id,enterprise_id,operation_id,task_id,step_key,actor_id,grant_id,profile_version,model,price_version,request_hash,input_upper_tokens,max_output_tokens,held_microusd,actual_microusd,state,usage_json,created_at,dispatched_at,finished_at) VALUES(?,?,?,?,'synthesis',?,?,'complex/1','claude-opus-5-5','price-recorded','hash',12000,4096,?,?,'response_received',?,'2026-10-22T00:21:45Z','2026-10-22T00:21:45Z','2026-10-22T00:22:21Z')",
                   (receipt,e,operation,"legacy_"+kind,a,"grant-"+receipt,actual or 200000,actual,json_text({"input_tokens":10772,"output_tokens":3042})))


def native(repo, owner, mission, *, attempt="native-a", receipt="gateway-a", operation="research-a", kind="research"):
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,mission_id,model,state,usage_json,response_json,created_at,finished_at) VALUES(?,?,?,?,?,'hash',?,'claude-opus-5-5','succeeded',?,?,'2026-10-22T00:21:45Z','2026-10-22T00:22:21Z')",
                   (attempt,owner["account_id"],owner["enterprise_id"],operation,kind,mission["id"],json_text({"input_tokens":1,"output_tokens":1}),json_text({"gateway_attempt_id":receipt})))


def test_exact_scoped_receipt_carries_recorded_cost_price_usage_and_never_an_invoice(setup):
    repo, owner = setup[:2]
    value = plan(setup)
    ledger(repo, owner)
    native(repo, owner, value)
    before = data_snapshot(repo)
    cost = get(setup,value)["cost"]
    call = cost["calls"][0]
    assert call["kind"] == "research" and call["attempt_id"] == "native-a"
    assert call["gateway_attempt_id"] == "gateway-a" and call["actual_microusd"] == 103928
    assert call["price_version"] == "price-recorded"
    assert call["usage"] == {"input_tokens":10772,"output_tokens":3042}
    assert call["dispatched_at"] and call["finished_at"] and call["is_invoice"] is False
    assert cost["cost_scope"] == "mission_prepare_and_research" and cost["is_invoice"] is False
    assert data_snapshot(repo) == before


def test_foreign_owner_or_wrong_operation_reference_cannot_supply_cost_to_current_mission(setup):
    repo, owner, other = setup[:3]
    value = plan(setup)
    ledger(repo, other, receipt="foreign",operation="foreign-op")
    native(repo, owner, value,receipt="foreign")
    ledger(repo, owner,receipt="same-owner-wrong-operation",operation="other-op")
    native(repo,owner,value,attempt="native-b",receipt="same-owner-wrong-operation",operation="research-b")
    before = data_snapshot(repo)
    calls = get(setup,value)["cost"]["calls"]
    assert len(calls) == 2
    assert all(call["gateway_attempt_id"] is None and call["actual_microusd"] is None and call["price_version"] is None for call in calls)
    assert all(call["estimated_usd"] > 0 for call in calls)
    assert data_snapshot(repo) == before


def test_missing_actual_usage_receipt_stays_unknown_and_unrelated_mission_cost_is_excluded(setup):
    repo, owner = setup[:2]
    value = plan(setup)
    other_value = plan(setup,"other")
    ledger(repo, owner,actual=None)
    native(repo, owner, value)
    ledger(repo,owner,receipt="unrelated",operation="unrelated-op",actual=999999)
    native(repo,owner,other_value,attempt="unrelated-native",receipt="unrelated",operation="unrelated-op")
    before = data_snapshot(repo)
    cost = get(setup,value)["cost"]
    assert len(cost["calls"]) == 1 and cost["calls"][0]["actual_microusd"] is None
    assert cost["calls"][0]["gateway_attempt_id"] == "gateway-a"
    assert data_snapshot(repo) == before
