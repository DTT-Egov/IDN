"""Save-claim polarity and authoritative history; no provider/network calls."""
from copy import deepcopy
import json
from pathlib import Path

import pytest

from nmate.v03.core import CoreError
from nmate.v04.live_review import validate_output


QUESTION = "Tôi muốn số hóa bán hàng và tồn kho"


def request(confirmed=False):
    context = {"entities": [], "fact_refs": []}
    if confirmed:
        context = {"entities": [{"id": "owned-product", "values": {"net_quantity": "100 g"},
                    "facts": [{"field": "net_quantity", "value": "100 g", "value_state": "known", "freshness_state": "self_declared",
                               "assertion_id": "owner-confirmed", "version": 2}]}],
                   "fact_refs": [{"entity_id": "owned-product", "field": "net_quantity", "assertion_id": "owner-confirmed", "version": 2}]}
    return {"messages": [{"role": "user", "text": QUESTION}], "files": [],
            "effective_context": {"confirmed_ssot": context}, "ssot": deepcopy(context)}


def output(text):
    return {"data": {"primary": "digitize_operations", "primary_quote": QUESTION, "focus": None,
                     "market_codes": [], "market_clarification_needed": False, "working_answers": [],
                     "image_facts": [], "unread_image_sha256": [], "assistant_text": text,
                     "next_steps": [], "pending_question": None, "actions": []}}


@pytest.mark.parametrize("text", [
    "Các số này chỉ là dữ kiện làm việc trong chat, không phải hồ sơ đã lưu.",
    "Mình chưa ghi nhớ dữ kiện này.", "Mình chưa lưu hồ sơ.",
    "Điều này không có nghĩa là mình đã lưu vào hồ sơ.",
    "Đây chưa phải dữ kiện đã lưu.",
])
@pytest.mark.parametrize("confirmed", [False, True])
def test_explicit_negation_never_claims_a_write(text, confirmed):
    assert validate_output(output(text), request(confirmed))[0].assistant_text == text


@pytest.mark.parametrize("text", [
    "Mình đã lưu hồ sơ của bạn.", "Tôi đã ghi nhớ dữ kiện.",
    "Hệ thống đã cập nhật hồ sơ.", "Đã lưu hồ sơ.",
    "Hồ sơ đã được lưu thành công.", "Mình vừa lưu dữ kiện.",
    "Mình không chỉ đã lưu mà còn cập nhật hồ sơ.",
    "Đây không phải hồ sơ đã lưu; mình đã lưu dữ kiện mới.",
    "Mình chưa lưu, đã lưu hồ sơ thành công.",
])
@pytest.mark.parametrize("confirmed", [False, True])
def test_actual_write_assertions_remain_rejected_even_with_existing_facts(text, confirmed):
    with pytest.raises(CoreError) as error:
        validate_output(output(text), request(confirmed))
    assert error.value.code == "LIVE_SAVE_CLAIM_INVALID"


@pytest.mark.parametrize("text", [
    "Hồ sơ đã lưu trước đó đang dùng 100 g.",
    "Dữ kiện đã lưu trong hồ sơ: lượng tịnh 100 g.",
    "Lần trước chủ tài khoản đã lưu lựa chọn 100 g.",
])
def test_historical_reference_requires_real_server_confirmed_facts(text):
    assert validate_output(output(text), request(True))
    with pytest.raises(CoreError) as error:
        validate_output(output(text), request(False))
    assert error.value.code == "LIVE_SAVE_CLAIM_INVALID"


@pytest.mark.parametrize("mutation", ["draft_only", "stale", "missing_ref", "wrong_version", "unknown"])
def test_draft_stale_unknown_or_unbound_fact_cannot_authorize_saved_history(mutation):
    current = request(True)
    context = current["effective_context"]["confirmed_ssot"]
    if mutation == "draft_only":
        current["effective_context"]["active_editable_draft"] = context["entities"]
        context["entities"] = []
    elif mutation == "missing_ref":
        context["fact_refs"] = []
    elif mutation == "wrong_version":
        context["fact_refs"][0]["version"] = 1
    elif mutation == "stale":
        context["entities"][0]["facts"][0]["freshness_state"] = "expired"
    else:
        context["entities"][0]["facts"][0]["value_state"] = "unknown"
    with pytest.raises(CoreError):
        validate_output(output("Hồ sơ đã lưu trước đó đang dùng 100 g."), current)


def test_exact_real_sonnet_call2_remains_unchanged_and_valid_without_provider_replay():
    path = Path(__file__).parents[2] / "MVP/v0.4-reviewfix-2026-10-19/raw-model-outputs.json"
    raw = json.loads(path.read_text(encoding="utf-8"))
    actual = next(item["data"] for item in raw if item["attempt_id"] == "claude_aff0ea6f78e14a8597702ca47436fb53")
    before = deepcopy(actual)
    current = request(True)
    current["messages"] = [{"role": "user", "text": raw[0]["data"]["primary_quote"]},
                           {"role": "assistant", "text": raw[0]["data"]["assistant_text"]},
                           {"role": "user", "text": actual["primary_quote"]}]
    result, answers = validate_output({"data": actual}, current)
    assert actual == before and result.model_dump() == before
    assert answers == {"book_quantity": 120.0, "physical_quantity": 110.0, "quantity_unit": "hộp",
                       "count_date": "2026-10-19", "product_code": "TS01"}
