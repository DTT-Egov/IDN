"""Chosen main account may record scoped decisions, never dispatch on approval."""

import hashlib
import json
import pytest
from test_knowledge_m6_worker import batch
from test_knowledge_m1 import kb
from test_knowledge_m6_independent_branch import failed_o1
from nmate.v03.core import CoreError
from nmate.knowledge_v1 import worker_m6


@pytest.fixture
def approval(batch, kb, tmp_path):
    from nmate.knowledge_v1.cost_authority import ApproverAssignment
    from nmate.knowledge_v1.cost_approval import CostApprovalService

    main = kb[0]
    folder, prepared, grant, _, _ = batch
    with main.connection() as db:
        user = dict(
            db.execute(
                "SELECT id,username FROM v03_accounts WHERE id=?", (prepared["account_id"],)
            ).fetchone()
        )
    record = dict(
        schema_version="cost-approver-assignment/1",
        assignment_id="TEST-COST-ASSIGNMENT",
        main_database=str(tmp_path / "knowledge-test.sqlite"),
        public_batch_directory=str(folder),
        subject=dict(account_id=user["id"], username=user["username"]),
        scope_id="public_domain:hanoi_policy:HN-DIGITAL-CONSULTING-2026",
        capability="continue_independent_O2",
        active=True,
        approved_by="project_owner",
        approval_reference="TEST-only-direct-human-account-choice",
    )
    path = tmp_path / "TEST-assignment.json"
    path.write_bytes(json.dumps(record).encode())
    pin = hashlib.sha256(path.read_bytes()).hexdigest()
    assignment = ApproverAssignment.load(path, pin)
    return CostApprovalService(main, assignment), user["id"], path, record


@pytest.mark.asyncio
async def test_main_approver_decision_is_scoped_v2_and_zero_provider_or_budget_change(approval, batch):
    service, actor, _, _ = approval
    await failed_o1(batch)
    calls = batch[4]
    before = worker_m6.snapshot(batch[0])
    decision = service.preview(actor, "TEST-main-approve")
    assert decision["schema_version"] == "knowledge-independent-continuation/2"
    assert decision["approver"]["account_id"] == actor
    receipt = service.approve(actor, decision)
    assert receipt["decision"]["approved_by"] == actor
    assert len(calls) == 5 and worker_m6.snapshot(batch[0])["next_slot"] == "O2"
    assert worker_m6.snapshot(batch[0])["known_estimated_microusd"] == before["known_estimated_microusd"]
    assert service.approve(actor, decision) == receipt


@pytest.mark.asyncio
async def test_legal_reviewer_or_owner_is_not_cost_approver_and_assignment_revoke_keeps_old_read(
    approval, batch, kb
):
    service, actor, path, _ = approval
    await failed_o1(batch)
    with pytest.raises(CoreError):
        service.preview(kb[2], "TEST-other-not-allowed")
    decision = service.preview(actor, "TEST-main-receipt")
    saved = service.approve(actor, decision)
    path.rename(path.with_suffix(".disabled"))
    assert service.approve(actor, decision) == saved
    with pytest.raises(CoreError):
        service.preview(actor, "TEST-new-decision-no-right")
    assert len(batch[4]) == 5


def test_main_composition_exposes_adapter_without_catchall_or_provider(approval, batch):
    import httpx
    import asyncio
    from nmate.main.app import make_main_app

    service, actor, _, _ = approval

    def forbidden(*args, **kwargs):
        raise AssertionError("No real provider in composition test")

    app = make_main_app(
        service.repo.db_path,
        request_fn=forbidden,
        gateway_request_fn=forbidden,
        refresh_sources=False,
        gateway_enabled=False,
        cost_approval_binding=service.assignment,
    )
    assert app.state.cost_approval is not None
    session = app.state.accounts.create_session(actor)

    async def verify():
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app), base_url="http://testserver"
        ) as client:
            response = await client.get("/api/main/policy-cost/status")
            assert response.status_code == 401
            client.cookies.set("nmate_v04a_session", session["token"])
            response = await client.get("/api/main/policy-cost/status")
            assert response.status_code == 200 and response.json()["data"]["account_id"] == actor

    asyncio.run(verify())
    assert batch[4] == []
