"""Injected authority HTTP responses; no network, credentials or Claude calls."""
import asyncio
from time import monotonic
from html import escape

import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from nmate.v03.source_refresh import AuthoritySourceRefresher, authority_host


async def public_dns(_host):
    return None


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "sources.sqlite3")
    owner = LocalAccounts(repo).register("owner", "TestPassword12345", "Doanh nghiệp Sen")
    catalog = DomainCatalog(repo)
    with repo.connection() as db:
        sources = {row["id"]: dict(row) for row in db.execute("SELECT * FROM v03_domain_sources")}
    calls = []

    async def get(url):
        calls.append(url)
        # Several bounded source IDs point to one authority page. That real
        # page includes all of their passages, not just the last packed slice.
        with repo.connection() as db:
            text = "\n".join(row[0] for row in db.execute("SELECT text FROM v03_domain_sources WHERE url=?", (url,)))
        text += "\nOfficial source reference content for contract tests."
        return 200, {"content-type": "text/html; charset=utf-8"}, (f'<html><meta charset="utf-8"><main><pre>{escape(text)}</pre></main></html>').encode()

    refresh = AuthoritySourceRefresher(repo, catalog, request_fn=get, dns_guard=public_dns)
    return repo, owner, catalog, sources, calls, refresh


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


@pytest.mark.asyncio
@pytest.mark.parametrize("market", ["US", "DE", "JP"])
async def test_check_all_markets_preserves_snapshot_and_records_real_network_observation(setup, market):
    repo, owner, catalog, sources, calls, refresh = setup
    result = await refresh.refresh(*args(owner), market, ["facility_registration", "food_label"])
    assert result["network_refresh"] is True
    assert result["network_source_checks"] >= len(calls) > 0
    assert result["source_urls_checked"] == len(calls)
    assert result["http_requests"] == len(calls)
    assert all(item["state"] == "exact_excerpts_present" for item in result["sources"])
    assert len(calls) == len(set(calls))
    for item in result["sources"]:
        original = next(source for source in sources.values() if source["id"] == item["source_id"])
        current = catalog.get_source(item["source_id"])
        assert current["accessed_at"] == original["accessed_at"]
        assert current["content_sha256"] == original["content_sha256"]
        assert current["freshness_state"] == "recorded_snapshot"
        assert item["checked_at"] != current["accessed_at"]
        assert item["body_sha256"] and item["text_sha256"]
    checks = refresh.latest_checks([item["source_id"] for item in result["sources"]])
    assert len(checks) == result["network_source_checks"]
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_authority_network_checks WHERE text IS NOT NULL").fetchone()[0] == result["network_source_checks"]


@pytest.mark.asyncio
async def test_missing_exact_excerpt_invalidates_reuse_and_existing_mission_without_rewriting_quote(setup):
    repo, owner, catalog, _, calls, refresh = setup
    missions = MissionService(repo)
    mission = missions.prepare(*args(owner), "Tôi có Trà Sen Tây Hồ gửi Mỹ, cần đăng ký cơ sở và nhãn.", "prepare")
    before = catalog.get_source("fda_registration")
    original_get = refresh.request_fn

    async def changed(url):
        if url == before["url"]:
            calls.append(url)
            return 200, {"content-type": "text/plain"}, b"This official page now contains different content. No previously cited clause is present."
        return await original_get(url)

    refresh.request_fn = changed
    result = await refresh.refresh(*args(owner), "US", ["facility_registration", "food_label"])
    observed = next(item for item in result["sources"] if item["source_id"] == "fda_registration")
    assert observed["state"] == "excerpt_changed" and observed["missing_reference_ids"]
    after = catalog.get_source("fda_registration")
    assert after["text"] == before["text"] and after["content_sha256"] == before["content_sha256"]
    assert after["freshness_state"] == "needs_revalidation" and after["version"] == before["version"] + 1
    assert missions.get(*args(owner), mission["id"])["status"] == "needs_revalidation"
    knowledge = catalog.lookup_domain(["facility_registration"], *args(owner), market_code="US")
    assert all(not record["reusable"] for record in knowledge["records"] if record["source_id"] == "fda_registration")


@pytest.mark.asyncio
@pytest.mark.parametrize("response,error", [
    ((403, {"content-type": "text/html"}, b"Forbidden"), "authority_http_403"),
    ((200, {"content-type": "application/pdf"}, b"%PDF-1.7"), "authority_unsupported_content"),
    ((200, {"content-type": "text/html"}, b"<html>Challenge</html>"), "authority_empty_content"),
    ((200, {"content-type": "text/html"}, b"<html><title>Access Denied</title><main>Please verify you are human before accessing this protected official website.</main></html>"), "authority_access_challenge"),
    ((302, {"location": "http://127.0.0.1/private"}, b""), "authority_unsafe_url"),
])
async def test_failure_is_named_once_never_retried_or_claimed_as_fresh(setup, response, error):
    _, owner, catalog, _, calls, refresh = setup

    async def failed(url):
        calls.append(url)
        return response

    refresh.request_fn = failed
    result = await refresh.refresh(*args(owner), "JP", ["facility_registration"])
    assert len(calls) == len(set(calls))
    assert all(item["state"] == "unavailable" and item["error_code"] == error for item in result["sources"])
    assert all(catalog.get_source(item["source_id"])["accessed_at"] != item["checked_at"] for item in result["sources"])


@pytest.mark.asyncio
async def test_non_public_dns_blocks_all_requests_before_any_http(setup):
    _, owner, _, _, calls, refresh = setup

    async def private_dns(_host):
        raise CoreError("authority_private_address", "Non-public address")

    refresh.dns_guard = private_dns
    result = await refresh.refresh(*args(owner), "DE", ["food_label"])
    assert calls == []
    assert all(item["error_code"] == "authority_private_address" for item in result["sources"])


@pytest.mark.asyncio
async def test_wrong_owner_denied_before_network(setup):
    _, owner, _, _, calls, refresh = setup
    with pytest.raises(CoreError):
        await refresh.refresh("not-owner", owner["enterprise_id"], "US", ["food_label"])
    assert calls == []


@pytest.mark.parametrize("url", ["http://www.fda.gov/food", "https://www.fda.gov:444/food", "https://www.fda.gov.evil.test/food",
                                "https://x:www.fda.gov@127.0.0.1/food", "https://www.fda.gov/food#fragment"])
def test_authority_url_allowlist_is_exact(url):
    with pytest.raises(CoreError):
        authority_host(url)


@pytest.mark.asyncio
async def test_complete_batch_deadline_cancels_slow_fetches_without_any_retry(setup):
    _, owner, _, _, calls, refresh = setup
    refresh.total_timeout_seconds = 0.03

    async def slow(url):
        calls.append(url)
        await asyncio.sleep(1)
        raise AssertionError("The deadline must cancel this request")

    refresh.request_fn = slow
    started = monotonic()
    result = await refresh.refresh(*args(owner), "US", ["facility_registration", "food_label"])
    assert monotonic() - started < 0.5
    assert len(calls) <= 3 and len(calls) == len(set(calls))
    assert result["http_requests"] == len(calls)
    assert all(item["state"] == "unavailable" and item["error_code"] == "authority_batch_timeout" for item in result["sources"])
