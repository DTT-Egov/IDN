"""Owner-selected identity supports shorthand without switching product dossiers."""
import pytest

from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from nmate.v03.models import Intent, Outcome


@pytest.mark.parametrize("reference,competing,expected", [
    ("Trà Sen", False, "planned"),
    ("Trà Sen Tây Hồ", False, "planned"),
    ("Trà Se", False, "waiting_input"),
    ("Bột Sen", False, "waiting_input"),
    ("Trà Sen", True, "waiting_input"),
])
def test_selected_product_shorthand_is_bounded_and_never_rewrites_ssot(tmp_path, reference, competing, expected):
    repo = CoreRepository(tmp_path / "reference.sqlite3")
    owner = LocalAccounts(repo).register("reference-owner", "TestPassword12345", "Trà Sen")
    scope = owner["account_id"], owner["enterprise_id"]
    selected = repo.create_entity(*scope, "product", "Trà Sen Tây Hồ 2026")
    repo.propose_or_apply_facts(*scope, selected["id"], [{"field": "name", "value": selected["name"]}], 0, "name")
    if competing:
        repo.create_entity(*scope, "product", reference)
    service = MissionService(repo)
    service._interpret_request = lambda text: (Intent(scope="us_food", market_code="US",
        outcomes=[Outcome(id="label", title="Nhãn", question_part="nhãn")]), reference)
    result = service.prepare(*scope, f"Dùng hồ sơ {reference} đã xác nhận để chuẩn bị nhãn cho Mỹ.", "prepare", selected["id"], market_code="US")
    assert result["status"] == expected
    assert result["product"]["entity_id"] == selected["id"]
    assert repo.get_entity(*scope, selected["id"])["name"] == "Trà Sen Tây Hồ 2026"
    assert len(repo.list_entities(*scope, "product")) == (2 if competing else 1)
