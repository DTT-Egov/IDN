"""Independent browser cookie jars, real persistence/auth, no network/model calls."""
import json

from fastapi.testclient import TestClient

from nmate.app import create_app
from nmate.auth import LOCAL_PRINCIPAL
from nmate.config import Settings
from nmate.models import Principal
from test_translations_http import saved_artifact


def app_for(path, factory=None):
    return create_app(Settings(_env_file=None, data_dir=path, mode="llm", model_provider="anthropic",
        model_name="claude-sonnet-5-5", ANTHROPIC_API_KEY="TEST-NOT-A-REAL-KEY", OPENAI_API_KEY=None),
        conversation_model_factory=factory)


def session(client):
    response = client.get("/api/session")
    assert response.status_code == 200
    return response.json(), {"X-CSRF-Token": response.json()["csrf_token"]}


def test_independent_browser_profiles_cannot_read_write_followup_or_translate_foreign_records(tmp_path, monkeypatch):
    calls = []
    def factory(*args):
        calls.append(True)
        raise AssertionError("Model must not initialize for unauthorized follow-up")
    app = app_for(tmp_path, factory)
    # saved_artifact owns the synthetic run's claim/finish transaction. Keep the
    # HTTP/MCP/auth lifespan, but do not race that fixture with a research worker.
    # Worker scheduling is not part of these cross-profile authorization checks.
    async def no_background_research():
        return None
    monkeypatch.setattr(app.state.service, "start_worker", no_background_research)
    with TestClient(app, base_url="http://127.0.0.1:8022") as a:
        assert app.state.service.worker_task is None
        b = TestClient(app, base_url="http://127.0.0.1:8022")  # Separate cookie jar, same running ASGI service.
        sa, ha = session(a)
        sb, hb = session(b)
        assert sa["browser_user_id"] != sb["browser_user_id"]
        assert sa["browser_user_id"] == sa["workspace_id"] and sa["identity_mode"] == "browser_profile_local"
        assert a.cookies.get("nmate_device") not in json.dumps(sa)
        pa = app.state.auth.device_principal(a.cookies.get("nmate_device"))
        pb = app.state.auth.device_principal(b.cookies.get("nmate_device"))
        assert pa.tenant_id != pb.tenant_id and pa.subject != pb.subject
        conv = a.post("/api/conversations", headers=ha, json={"consent_model": True, "consent_storage": True}).json()
        artifact = saved_artifact(app.state.store, pa)
        case_id, run_id, aid = artifact["case_id"], artifact["run_id"], artifact["artifact_id"]
        assert len(a.get("/api/conversations").json()) == 1
        assert len(a.get("/api/cases").json()) == 1 and len(a.get("/api/runs").json()) == 1
        for collection in ("conversations", "cases", "runs"):
            assert b.get("/api/" + collection).json() == []
        for path in (f"/api/conversations/{conv['conversation_id']}", f"/api/cases/{case_id}", f"/api/artifacts/{aid}/translations"):
            assert b.get(path).status_code == 404
        url = f"/api/conversations/{conv['conversation_id']}"
        payload = {"expected_version": 1, "idempotency_key": "TEST-FOREIGN-FOLLOWUP", "message": "Đọc bản đã lưu", "artifact_id": aid}
        assert b.post(url + "/messages", headers=hb, json=payload).status_code == 404
        assert b.post(url + "/facts", headers=hb, json={"expected_version": 1, "idempotency_key": "TEST-FOREIGN-EDIT", "changes": [{"field": "product.packaging", "value": "100 g"}]}).status_code == 404
        assert b.post(url + "/confirm", headers=hb, json={"expected_version": 1, "idempotency_key": "TEST-FOREIGN-CONFIRM"}).status_code == 404
        assert b.post(url + "/link", headers=hb, json={"expected_version": 1, "case_id": case_id, "case_version": 1, "artifact_id": aid}).status_code == 404
        assert b.put(f"/api/cases/{case_id}", headers=hb, json={"expected_case_version": 1, "product": {"sku": "TEST", "name": "TEST"}}).status_code == 404
        # Browser MCP credentials are server-side and bound to exactly this identity.
        token = app.state.auth.create_session(pb)["mcp_token"]
        assert app.state.auth.verify_bearer(token) == pb
        assert app.state.auth.verify_bearer(app.state.auth.developer_token) == LOCAL_PRINCIPAL != pa
        for operation, value in ((app.state.store.get_case, case_id), (app.state.store.get_run, run_id), (app.state.store.get_artifact, aid)):
            try:
                operation(app.state.auth.verify_bearer(token), value)
                raise AssertionError("Foreign MCP principal unexpectedly read object")
            except Exception as error:
                assert getattr(error, "code", None) == "NOT_FOUND"
        assert not calls
        b.close()


def test_device_identity_survives_restart_but_session_alone_and_forged_identity_do_not_grant_access(tmp_path):
    app = app_for(tmp_path)
    a = TestClient(app, base_url="http://127.0.0.1:8022")
    state, headers = session(a)
    conv = a.post("/api/conversations", headers=headers, json={"consent_model": True, "consent_storage": True}).json()
    old_cookies = dict(a.cookies)
    restarted = app_for(tmp_path)
    restored = TestClient(restarted, base_url="http://127.0.0.1:8022", cookies=old_cookies)
    new_state, _ = session(restored)
    assert new_state["browser_user_id"] == state["browser_user_id"]
    assert restored.get(f"/api/conversations/{conv['conversation_id']}").status_code == 200
    stolen_session_only = TestClient(restarted, base_url="http://127.0.0.1:8022", cookies={"nmate_session": old_cookies["nmate_session"]})
    assert stolen_session_only.get(f"/api/conversations/{conv['conversation_id']}").status_code == 401
    other_state, other_headers = session(stolen_session_only)
    assert other_state["browser_user_id"] != state["browser_user_id"]
    assert stolen_session_only.get("/api/conversations").json() == []
    assert stolen_session_only.post("/api/conversations", headers=other_headers, json={"consent_model": True, "consent_storage": True, "browser_user_id": state["browser_user_id"]}).status_code == 422
    forged = TestClient(restarted, base_url="http://127.0.0.1:8022", cookies={"nmate_device": old_cookies["nmate_device"][:-1] + ("0" if old_cookies["nmate_device"][-1] != "0" else "1")})
    forged_state, _ = session(forged)
    assert forged_state["browser_user_id"] != state["browser_user_id"]
    assert forged.get("/api/conversations").json() == []
    for client in (a, restored, stolen_session_only, forged):
        client.close()


def test_legacy_shared_records_are_quarantined_from_browser_and_default_console(tmp_path):
    app = app_for(tmp_path)
    old = Principal("local-developer", "local-user")
    legacy = app.state.conversations.store.create(old, {"consent_model": True, "consent_storage": True})
    before = app.state.conversations.store.get(old, legacy["conversation_id"])
    with TestClient(app, base_url="http://127.0.0.1:8022") as client:
        state, _ = session(client)
        assert state["legacy_workspace_quarantined"] is True
        assert client.get("/api/conversations").json() == []
        assert client.get(f"/api/conversations/{legacy['conversation_id']}").status_code == 404
        console = app.state.auth.verify_bearer(app.state.auth.developer_token)
        assert console.tenant_id != old.tenant_id
    assert app.state.conversations.store.get(old, legacy["conversation_id"]) == before


def test_favicon_public_and_identity_cookie_security_attributes(tmp_path):
    with TestClient(app_for(tmp_path), base_url="http://127.0.0.1:8022") as client:
        assert client.get("/favicon.ico").status_code == 204
        response = client.get("/api/session")
        cookies = response.headers.get_list("set-cookie")
        assert len(cookies) == 2
        assert all("HttpOnly" in value and "SameSite=strict" in value for value in cookies)
