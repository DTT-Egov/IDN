"""Full HTTP/MCP replay of a saved Claude response, with no provider transport.

The new local ledger belongs to pytest's temporary database, not MAIN. These
checks prove integration of a recording, not a fresh model evaluation.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path

import httpx

from test_core_policy_http import running, register, good
from test_v04_text_observations import TEXT


def test_recorded_tea_chat_confirmation_policy_guide_history_and_reload(tmp_path):
    recording = json.loads((Path(__file__).parent / "fixtures/recorded_tea_sonnet_20261019.json").read_text(encoding="utf8"))
    text = recording["response_text"]
    assert hashlib.sha256(text.encode()).hexdigest() == recording["source_raw_sha256"]
    replay_calls = []

    async def replay(model, body, limit):
        assert body["input"]["capability"] == "legacy_intake"
        replay_calls.append(model)
        return {"text": text, "request_id": "offline-recording-replay-not-provider",
                "usage": {"input_tokens": 100, "output_tokens": 100}}

    async def forbidden(*args):
        raise AssertionError("No native model/SDK path is allowed in recorded replay")

    with running(tmp_path, gateway_request_fn=replay, gateway_enabled=True, request_fn=forbidden) as (app, url):
        expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        app.state.gateway.budget_pool.authorize("TEST-ONLY-OFFLINE-TEA-RECORDING", "standard", 1, 1,
                                               ["legacy_intake"], expiry)
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "recorded-tea-owner")
            product = good(web, url, session, "core_create_entity", entity_type="product", name="Trà Sen Tây Hồ",
                           operation_id="replay-create-product")
            proposal = good(web, url, session, "core_propose_facts", entity_id=product["id"], expected_version=0,
                            facts=[{"field": "name", "value": "Trà Sen Tây Hồ"}], operation_id="replay-name")
            good(web, url, session, "core_confirm_facts", proposal_id=proposal["proposal_id"], expected_version=0,
                 proposal_hash=proposal["proposal_hash"], operation_id="replay-confirm-name")
            chat = good(web, url, session, "send_message", text=TEXT, attachments=[], product_entity_id=product["id"],
                        task_hint="profile_intake", paid_consent=True, operation_id="replay-send")
            intake = chat["intake"]
            selected = [c["id"] for c in intake["candidates"] if c["status"] == "candidate"]
            assert len(selected) == 3
            assert {c["source"]["kind"] for c in intake["candidates"]} == {"server_text_extract"}
            assert intake["status"] == "awaiting_confirmation"
            confirmed = good(web, url, session, "confirm_intake", intake_id=intake["id"], selected_fact_ids=selected,
                             expected_entity_versions=intake["expected_entity_versions"], operation_id="replay-confirm-three",
                             expected_review_revision=intake["review"]["revision"],
                             expected_proposal_hashes={key: intake["review"]["proposal_hashes"][key] for key in selected})
            assert confirmed["status"] == "confirmed"
            reread = good(web, url, session, "get_conversation", conversation_id=chat["id"])
            assert reread["intake"]["status"] == "confirmed" and len(replay_calls) == 1
            entities = good(web, url, session, "core_list_entities")["entities"]
            tea = next(e for e in entities if e["id"] == product["id"])
            assert tea["values"]["name"] == "Trà Sen Tây Hồ" and tea["values"]["net_quantity"] == "100 g"
            assert "legal_form" not in tea["field_scope"]["allowed_fields"]
            case = good(web, url, session, "policy_prepare", conversation_id=chat["id"], product_entity_id=product["id"],
                        question="Tôi muốn số hóa quản lý kho Trà Sen. Có chương trình nào, cần chuẩn bị gì và còn nhận hồ sơ không?",
                        operation_id="replay-free-policy")["policy_case"]
            assert case["source_update"]["provider_used"] is False
            assert case["business_next_action"]["automatic_contact"] is False
            assert case["business_next_action"]["automatic_submission"] is False
            assert case["source_update"]["application_status"] == "unknown"
            assert case["source_update"]["eligibility_state"] == "awaiting_rule_review"
            history = good(web, url, session, "list_conversations")
            row = next(item for item in history if item["id"] == chat["id"])
            assert row["display_title"] == "Trà Sen Tây Hồ · số hóa kho"
            assert row["task_labels"] == ["Hồ sơ", "Chính sách Hà Nội", "Bán hàng / tồn kho"]
            assert set(row["history_task_kinds"]) == {"profile_intake", "hanoi_policy", "sales_inventory"}
            assert "dữ kiện" not in row["history_state_vi"]
            again = good(web, url, session, "get_conversation", conversation_id=chat["id"])
            assert again["policy_cases"][0]["id"] == case["id"]
            assert len(replay_calls) == 1
            with app.state.repo.connection() as db:
                attempts = db.execute("SELECT raw_sha256 FROM core_model_attempts").fetchall()
                assert len(attempts) == 1 and attempts[0][0] == recording["source_raw_sha256"]
