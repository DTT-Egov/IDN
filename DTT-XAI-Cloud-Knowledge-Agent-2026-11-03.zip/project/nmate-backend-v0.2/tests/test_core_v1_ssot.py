"""Cross-tenant, collaboration and canonical-fact invariants for the shared core."""
from concurrent.futures import ThreadPoolExecutor
import sqlite3

import pytest

from nmate.core_v1.ssot import CoreSSOTService
import nmate.core_v1.ssot as ssot_module
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "core.sqlite")
    accounts = LocalAccounts(repo)
    owner = accounts.register("owner", "owner-password", "Trà Sen Hà Nội")
    staff = accounts.register("staff", "staff-password", "Nhân viên riêng")
    outsider = accounts.register("other", "other-password", "Doanh nghiệp khác")
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Trà Sen ĐỒNG THÁP")
    service = CoreSSOTService(repo)
    return repo, service, owner, staff, outsider, entity


def share(setup, fields=None, capabilities=None):
    _, service, owner, staff, _, entity = setup
    service.add_member(owner["account_id"], owner["enterprise_id"], staff["username"])
    return service.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"],
                                  capabilities or ["read", "propose_fact"], fields or ["*"])


def seed(setup, facts=None):
    repo, _, owner, _, _, entity = setup
    return repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
           facts or [{"field": "name", "value": "Trà Sen ĐỒNG THÁP"}, {"field": "net_quantity", "value": "100 g"}], 0, "seed")


def company_scope(setup):
    """Finance fixtures belong to a company, never a product after scope v1."""
    repo, service, owner, staff, outsider, _ = setup
    entity = repo.create_entity(owner["account_id"], owner["enterprise_id"], "enterprise", "Công ty Trà Sen")
    return repo, service, owner, staff, outsider, entity


def propose(setup, actor=None, facts=None, version=0, op="propose"):
    _, service, owner, staff, _, entity = setup
    return service.propose_facts((actor or staff)["account_id"], owner["enterprise_id"], entity["id"],
           facts or [{"field": "net_quantity", "value": "100 g"}], version, op)


def confirm(setup, proposal, actor=None, operation="confirm", **extra):
    _, service, owner, _, _, _ = setup
    return service.confirm_facts((actor or owner)["account_id"], owner["enterprise_id"], proposal["proposal_id"],
           proposal["expected_version"], operation, proposal_hash=proposal["proposal_hash"], **extra)


def test_membership_never_shares_legacy_or_private_resources(setup):
    repo, service, owner, staff, _, entity = setup
    seed(setup)
    service.add_member(owner["account_id"], owner["enterprise_id"], staff["username"])
    assert service.list_entities(staff["account_id"], owner["enterprise_id"]) == []
    with pytest.raises(CoreError):
        service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]])
    # Legacy owner-only APIs do not get implicitly widened by the additive service.
    with pytest.raises(CoreError):
        repo.get_context(staff["account_id"], owner["enterprise_id"])
    assert service.list_entities(owner["account_id"], owner["enterprise_id"])[0]["name"] == "Trà Sen ĐỒNG THÁP"


def test_staff_proposes_owner_confirms_same_canonical_facts(setup):
    repo, service, owner, staff, _, entity = setup
    share(setup)
    proposal = propose(setup, facts=[{"field": "name", "value": "Trà Sen HỒ TÂY"}, {"field": "net_quantity", "value": "100 g"}])
    assert repo.get_entity(owner["account_id"], owner["enterprise_id"], entity["id"])["facts"] == []
    assert proposal["status"] == "awaiting_owner"
    with pytest.raises(CoreError) as denied:
        confirm(setup, proposal, actor=staff)
    assert denied.value.code == "forbidden"
    saved = confirm(setup, proposal)
    assert saved["status"] == "confirmed"
    canonical = repo.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]])
    assert canonical["entities"][0]["values"]["name"] == "Trà Sen HỒ TÂY"
    assert len(repo.get_fact_history(owner["account_id"], owner["enterprise_id"], entity["id"])) == 2
    assert confirm(setup, proposal) == saved
    with pytest.raises(CoreError) as resolved:
        confirm(setup, proposal, operation="other-confirm")
    assert resolved.value.code == "proposal_resolved"
    # Staff's read permission does not become owner or routine write permission.
    assert service.membership(staff["account_id"], owner["enterprise_id"])["role"] == "staff"


def test_field_scopes_and_finance_require_independent_grant(setup):
    setup = company_scope(setup)
    _, service, owner, staff, _, entity = setup
    seed(setup, [{"field": "name", "value": "Công ty Trà Sen"}, {"field": "inventory_management", "value": "Excel"},
                 {"field": "revenue", "value": "1000000000", "source": {"kind": "spreadsheet", "filename": "secret.xlsx", "locator": "Sheet1!A1"}}])
    share(setup, ["inventory_management", "revenue"])
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]])
    assert context["entities"][0]["name"] == "Hồ sơ được chia sẻ"
    assert context["entities"][0]["values"] == {"inventory_management": "Excel"}
    with pytest.raises(CoreError):
        service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"])
    service.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read_finance"], ["revenue"])
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"])
    assert context["entities"][0]["values"] == {"revenue": "1000000000"}
    assert context["entities"][0]["facts"][0]["source"] == {"kind": "restricted_source", "details_restricted": True}
    assert "secret.xlsx" not in str(context)
    assert not service.can_read(staff["account_id"], owner["enterprise_id"], "private-conversation-id")


def test_no_cross_enterprise_or_staff_share_or_routine_grant(setup):
    _, service, owner, staff, outsider, entity = setup
    share(setup)
    with pytest.raises(CoreError):
        service.grant_resource(staff["account_id"], owner["enterprise_id"], entity["id"], owner["account_id"])
    with pytest.raises(CoreError):
        service.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], outsider["account_id"])
    with pytest.raises(CoreError):
        service.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["resolve_routine_fact"])
    with pytest.raises(CoreError):
        service.get_context(outsider["account_id"], outsider["enterprise_id"], [entity["id"]])
    with pytest.raises(CoreError):
        service.add_member(owner["account_id"], owner["enterprise_id"], "other", "owner")


def test_snapshot_is_immutable_minimal_and_current_acl_checked(setup):
    repo, service, owner, staff, _, entity = setup
    seed(setup)
    share(setup, ["net_quantity"])
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity"])
    assert len(context["fact_refs"]) == 1
    assert service.get_snapshot(staff["account_id"], owner["enterprise_id"], context["context_snapshot_id"]) == context
    with repo.connection(write=True) as db:
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE core_v1_context_snapshots SET payload_json='{}'")
    service.revoke_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"])
    with pytest.raises(CoreError):
        service.get_snapshot(staff["account_id"], owner["enterprise_id"], context["context_snapshot_id"])
    with pytest.raises(CoreError):
        propose(setup, version=1)


def test_revoked_membership_remains_revoked_after_rejoin(setup):
    _, service, owner, staff, _, entity = setup
    share(setup)
    service.remove_member(owner["account_id"], owner["enterprise_id"], staff["account_id"])
    with pytest.raises(CoreError):
        service.list_entities(staff["account_id"], owner["enterprise_id"])
    service.add_member(owner["account_id"], owner["enterprise_id"], staff["username"])
    assert service.list_entities(staff["account_id"], owner["enterprise_id"]) == []
    assert not service.can_read(staff["account_id"], owner["enterprise_id"], entity["id"])


def test_fact_cas_conflict_and_unrelated_change_can_continue(setup):
    repo, service, owner, _, _, entity = setup
    share(setup)
    proposal = propose(setup)
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "ingredients", "value": "Trà, Sen"}], 0, "unrelated")
    with pytest.raises(CoreError) as conflict:
        confirm(setup, proposal)
    assert conflict.value.code == "version_conflict"
    saved = confirm(setup, proposal, expected_field_versions=proposal["expected_field_versions"])
    assert saved["version"] == 2
    next_proposal = propose(setup, version=2, op="next", facts=[{"field": "net_quantity", "value": "200 g"}])
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "net_quantity", "value": "300 g"}], 2, "relevant")
    with pytest.raises(CoreError) as conflict:
        confirm(setup, next_proposal, operation="next-confirm", expected_field_versions=next_proposal["expected_field_versions"])
    assert conflict.value.code == "fact_version_conflict"


def test_two_owner_confirms_only_one_decision_and_current_write(setup):
    repo, _, owner, _, _, entity = setup
    share(setup)
    proposal = propose(setup)

    def save(operation):
        try:
            return confirm(setup, proposal, operation=operation)
        except CoreError as exc:
            return exc.code
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(save, ["one", "two"]))
    assert sum(isinstance(r, dict) for r in results) == 1
    assert "proposal_resolved" in results
    assert len(repo.get_fact_history(owner["account_id"], owner["enterprise_id"], entity["id"])) == 1


def test_proposal_and_operation_immutable_with_exact_payload(setup):
    repo, service, owner, staff, _, entity = setup
    share(setup)
    proposal = propose(setup)
    assert propose(setup) == proposal
    with pytest.raises(CoreError) as conflict:
        propose(setup, facts=[{"field": "net_quantity", "value": "200 g"}])
    assert conflict.value.code == "idempotency_conflict"
    with pytest.raises(CoreError) as conflict:
        service.confirm_facts(owner["account_id"], owner["enterprise_id"], proposal["proposal_id"], 0, "bad", proposal_hash="spoof")
    assert conflict.value.code == "proposal_conflict"
    with repo.connection(write=True) as db:
        with pytest.raises(sqlite3.IntegrityError):
            db.execute("UPDATE core_v1_proposals SET facts_json='[]'")
    assert service.list_proposals(staff["account_id"], owner["enterprise_id"], entity["id"])[0]["status"] == "awaiting_owner"


def test_known_at_temporal_unknown_and_historical_snapshot(setup):
    repo, service, owner, _, _, entity = setup
    seeded = seed(setup, [{"field": "net_quantity", "value": "100 g"},
                         {"field": "certificate", "value": "ISO", "valid_from": "2020-01-01", "valid_to": "2022-01-01"}])
    known_at = repo.get_fact_history(owner["account_id"], owner["enterprise_id"], entity["id"])[-1]["recorded_at"]
    past = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity", "certificate"], target_date="2021-01-01")
    assert past["entities"][0]["values"] == {"certificate": "ISO"}
    assert past["entities"][0]["facts"][0]["freshness_state"] == "unknown_for_target_date"
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"], [{"field": "net_quantity", "value": "200 g"}], seeded["version"], "new")
    historic = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity"], known_at=known_at)
    assert historic["entities"][0]["values"] == {"net_quantity": "100 g"}
    assert historic["fact_refs"][0]["version"] == 1
    current = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity"])
    assert current["entities"][0]["values"] == {"net_quantity": "200 g"}
    assert current["context_hash"] != historic["context_hash"]


def test_explicit_scope_required_and_unknown_null_does_not_clear(setup):
    repo, service, owner, _, _, entity = setup
    seed(setup)
    with pytest.raises(CoreError):
        service.get_context(owner["account_id"], owner["enterprise_id"], None)
    with pytest.raises(CoreError):
        propose(setup, actor=owner, facts=[{"field": "net_quantity", "value": None}], version=1)
    assert repo.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]])["entities"][0]["values"]["net_quantity"] == "100 g"


def test_migration_does_not_change_legacy_facts_grants_or_names(setup):
    repo, _, owner, _, _, entity = setup
    before = seed(setup)
    CoreSSOTService(repo)
    CoreSSOTService(repo)
    after = repo.get_entity(owner["account_id"], owner["enterprise_id"], entity["id"])
    assert before["facts"] == after["facts"]
    assert after["name"] == "Trà Sen ĐỒNG THÁP"
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_v1_grants").fetchone()[0] == 0
        assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def test_wildcard_does_not_open_unclassified_or_financial_fields(setup):
    setup = company_scope(setup)
    _, service, owner, staff, _, entity = setup
    seed(setup, [{"field": "inventory_management", "value": "Excel"}, {"field": "secret_formula", "value": "PRIVATE"},
                 {"field": "annual_sales", "value": "1000000000"}])
    share(setup)
    context = service.get_context(staff["account_id"], owner["enterprise_id"], [entity["id"]])
    assert context["entities"][0]["values"] == {"inventory_management": "Excel"}
    service.grant_resource(owner["account_id"], owner["enterprise_id"], entity["id"], staff["account_id"], ["read"], ["secret_formula"])
    assert service.can_read(staff["account_id"], owner["enterprise_id"], entity["id"], "secret_formula")
    assert not service.can_read(staff["account_id"], owner["enterprise_id"], entity["id"], "annual_sales")


def test_design_state_aliases_preserve_explicit_absence_and_zero(setup):
    setup = company_scope(setup)
    _, service, owner, _, _, entity = setup
    share(setup)
    proposal = propose(setup, facts=[{"field": "certifications", "value": None, "value_state": "explicit_absent"},
                                    {"field": "employee_count", "value": 0}], actor=owner)
    confirm(setup, proposal)
    context = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]])
    by_key = {fact["field"]: fact for fact in context["entities"][0]["facts"]}
    assert by_key["certifications"]["value_state"] == "known_absent"
    assert context["entities"][0]["values"] == {"employee_count": 0}


def test_single_temporal_bound_does_not_imply_infinite_past(setup):
    _, service, owner, _, _, entity = setup
    seed(setup, [{"field": "certifications", "value": ["ISO"], "valid_to": "2100-01-01"}])
    context = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["certifications"], "2000-01-01")
    assert context["entities"][0]["values"] == {}
    assert context["entities"][0]["facts"][0]["temporal_basis"] == "current_only"


def test_vietnam_business_day_after_midnight_does_not_turn_current_fact_unknown(setup, monkeypatch):
    repo, service, owner, _, _, entity = setup
    seed(setup, [{"field": "net_quantity", "value": "100 g"}])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_fact_resolutions SET recorded_at='2026-10-18T17:30:00+00:00'")
    monkeypatch.setattr(ssot_module, "now_iso", lambda: "2026-10-18T18:00:00+00:00")
    # 01:00 on 19/10 in Hanoi, while UTC is still 18/10.
    current = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity"], "2026-10-19")
    assert current["entities"][0]["values"] == {"net_quantity": "100 g"}
    prior = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["net_quantity"], "2026-10-18")
    assert prior["entities"][0]["values"] == {}


def test_future_interval_does_not_replace_current_and_corrections_keep_old_parts(setup):
    setup = company_scope(setup)
    repo, service, owner, _, _, entity = setup
    seed(setup, [{"field": "inventory_management", "value": "Excel"},
                 {"field": "revenue", "value": "100", "valid_from": "2020-01-01", "valid_to": "2023-01-01"}])
    original_known_at = repo.get_fact_history(owner["account_id"], owner["enterprise_id"], entity["id"])[-1]["recorded_at"]
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], entity["id"],
        [{"field": "inventory_management", "value": "ERP", "valid_from": "2100-01-01", "valid_to": "2101-01-01"},
         {"field": "revenue", "value": "150", "valid_from": "2021-01-01", "valid_to": "2022-01-01"}], 1, "interval")
    present = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["inventory_management"])
    assert present["entities"][0]["values"] == {"inventory_management": "Excel"}
    before = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"], "2020-06-01")
    corrected = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"], "2021-06-01")
    after = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"], "2022-06-01")
    assert before["entities"][0]["values"] == after["entities"][0]["values"] == {"revenue": "100"}
    assert corrected["entities"][0]["values"] == {"revenue": "150"}
    originally_known = service.get_context(owner["account_id"], owner["enterprise_id"], [entity["id"]], ["revenue"], "2021-06-01", original_known_at)
    assert originally_known["entities"][0]["values"] == {"revenue": "100"}
