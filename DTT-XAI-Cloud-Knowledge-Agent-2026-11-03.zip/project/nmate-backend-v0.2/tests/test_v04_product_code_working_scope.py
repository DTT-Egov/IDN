"""Product references are not stock quantities; quotes stay exact and private."""
import copy

import pytest

from nmate.v03.core import CoreError
from nmate.v04.live_review import validate_output
from test_v04_live_review import result


TEXT = "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSB01."


def answer(**changes):
    return {"key": "product_code", "value": "TSB01", "quote": "mã TSB01", "message_index": 0, **changes}


def request(text=TEXT):
    return {"messages": [{"role": "user", "text": text}], "files": [], "ssot": {}}


@pytest.mark.parametrize("primary", ["understand_business", "improve_packaging", "export_readiness", "digitize_operations", "needs_clarification"])
def test_exact_product_reference_is_valid_for_each_relevant_intent(primary):
    output = result(TEXT, primary=primary, working_answers=[answer()])
    original = copy.deepcopy(output)
    parsed, working = validate_output({"data": output}, request())
    assert parsed.primary == primary and parsed.focus is None
    assert working == {"product_code": "TSB01"}
    assert output == original  # no model quote or answer rewriting


@pytest.mark.parametrize("value,quote", [("tsb01", "mã TSB01"), ("TSB0", "mã TSB01"), ("TSB01", "mã TSB010"), ("TSB01", "mã XTSB01")])
def test_product_reference_must_keep_exact_case_and_whole_token(value, quote):
    with pytest.raises(CoreError) as error:
        validate_output({"data": result(TEXT, primary="understand_business", working_answers=[answer(value=value, quote=quote)])}, request(TEXT+" "+quote))
    assert error.value.code == "LIVE_ANSWER_UNGROUNDED"


@pytest.mark.parametrize("quote", ["mã TSB01.","mã TSB01. Chị muốn đối chiếu.","mã TSB01, hộp 100 g","(TSB01)"])
def test_sentence_punctuation_does_not_become_part_of_the_product_code(quote):
    text=TEXT+" "+quote
    _,working=validate_output({"data":result(text,primary="understand_business",working_answers=[answer(quote=quote)])},request(text))
    assert working=={"product_code":"TSB01"}


@pytest.mark.parametrize("quote", ["mã TSB01-A", "mã TSB01.1", "mã X.TSB01", "mã TSB01_2", "mã X-TSB01"])
def test_code_suffix_or_prefix_is_not_accepted_as_sentence_punctuation(quote):
    text=TEXT+" "+quote
    with pytest.raises(CoreError) as error:
        validate_output({"data":result(text,primary="understand_business",working_answers=[answer(quote=quote)])},request(text))
    assert error.value.code=="LIVE_ANSWER_UNGROUNDED"


@pytest.mark.parametrize("key,value,quote", [
    ("book_quantity", "120", "tồn trên sổ 120"),
    ("physical_quantity", "110", "đếm thực tế 110"),
    ("quantity_unit", "hộp", "120 hộp"),
    ("count_date", "2026-10-18", "18/10/2026"),
    ("count_date_phrase", "hôm qua", "hôm qua"),
])
def test_inventory_only_values_still_require_inventory_focus(key, value, quote):
    text=TEXT+" "+quote
    with pytest.raises(CoreError) as error:
        validate_output({"data": result(text, primary="understand_business", working_answers=[answer(key=key,value=value,quote=quote)])}, request(text))
    assert error.value.code == "LIVE_ANSWER_INVALID"


def test_product_reference_cannot_be_grounded_in_assistant_history():
    value=request()
    value["messages"].append({"role":"assistant","text":"mã TSB01"})
    with pytest.raises(CoreError) as error:
        validate_output({"data":result(TEXT, primary="understand_business",working_answers=[answer(message_index=1)])},value)
    assert error.value.code == "LIVE_ANSWER_UNGROUNDED"


def test_inventory_keeps_its_exact_code_and_valid_quantity_semantics():
    text="Chị báo tồn trên sổ 120 hộp, thực tế 110 hộp, mã TSB01."
    parsed,working=validate_output({"data":result(text,focus="inventory_accuracy",working_answers=[
        answer(),answer(key="book_quantity",value="120",quote="tồn trên sổ 120 hộp"),
        answer(key="physical_quantity",value="110",quote="thực tế 110 hộp")])}, request(text))
    assert parsed.focus=="inventory_accuracy"
    assert working=={"product_code":"TSB01","book_quantity":120.0,"physical_quantity":110.0}


def test_inventory_reload_followup_reuses_grounded_counts_and_date_with_a_final_code_period():
    first="Chị báo tồn trên sổ 120 hộp, đếm thực tế 110 hộp."
    dated="Ngày 18/10/2026, mã TS01."
    latest="Chị muốn đối chiếu phiếu nhập và xuất, chưa xác nhận thay đổi hồ sơ sản phẩm."
    inputs={"messages":[{"role":"user","text":first},{"role":"assistant","text":"Chị bổ sung ngày và mã nhé."},
                        {"role":"user","text":dated},{"role":"user","text":latest}],"files":[],"ssot":{}}
    output=result(latest,focus="inventory_accuracy",working_answers=[
        answer(key="book_quantity",value="120",quote="tồn trên sổ 120 hộp"),
        answer(key="physical_quantity",value="110",quote="đếm thực tế 110 hộp"),
        answer(key="quantity_unit",value="hộp",quote="tồn trên sổ 120 hộp"),
        answer(key="count_date",value="2026-10-18",quote=dated,message_index=2),
        answer(value="TS01",quote=dated,message_index=2)])
    _,working=validate_output({"data":output},inputs)
    assert working=={"book_quantity":120.0,"physical_quantity":110.0,"quantity_unit":"hộp","count_date":"2026-10-18","product_code":"TS01"}
