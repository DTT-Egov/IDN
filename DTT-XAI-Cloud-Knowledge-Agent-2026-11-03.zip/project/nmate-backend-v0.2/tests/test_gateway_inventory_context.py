"""Inventory continuity uses typed slots, never a financial exemption for prose."""
import asyncio
import copy
import json

import pytest

from nmate.v03.core import CoreError
from test_legacy_model_gateway import setup as setup, payload, grant, invoke


FIRST = "Chị kiểm kê Trà Sen Tây Hồ: tồn trên sổ 120 hộp, đếm thực tế 110 hộp. Chị nên đối chiếu gì trước, chưa rõ nguyên nhân lệch?"
FOLLOWUP = "Ngày 18/10/2026, mã TS01. Chị muốn đối chiếu phiếu nhập và xuất, chưa xác nhận thay đổi hồ sơ sản phẩm."
PRIOR = "Chênh lệch 110 - 120 = -10 hộp.\n(1) Đối chiếu phiếu; (2) Đếm lại; (3) Rà các số 10, 120 và 110."


def inventory_payload(**changes):
    value = payload(current_question=FOLLOWUP,
        previous_intent={"primary": "digitize_operations", "focus": "inventory_accuracy", "address_term": "chị",
                         "working_answers": {"book_quantity": 120.0, "physical_quantity": 110.0, "quantity_unit": "hộp"}},
        messages=[{"role": "user", "text": FIRST, "index": 0}, {"role": "assistant", "text": PRIOR, "index": 1},
                  {"role": "user", "text": FOLLOWUP, "index": 2}])
    value["input"].update(changes)
    return value


def test_multiline_inventory_reply_is_not_unclassified_text_egress(setup):
    adapter = setup[5]
    with pytest.raises(CoreError) as baseline:
        adapter._text(PRIOR)
    assert baseline.value.code == "FINANCIAL_EGRESS_REQUIRED"
    compiled = adapter.compile_payload("intake", inventory_payload())
    projected = compiled["input"]
    assert projected["previous_intent"]["working_answers"] == {
        "book_quantity": 120.0, "physical_quantity": 110.0, "quantity_unit": "hộp"}
    assert projected["previous_intent"]["context_classification"] == "nonfinancial_inventory_working_values_not_ssot"
    assert projected["messages"][0] == {"role": "user", "text": FIRST, "index": 0}
    assert projected["messages"][2] == {"role": "user", "text": FOLLOWUP, "index": 2}
    assert projected["messages"][1]["index"] == 1
    assert PRIOR not in json.dumps(compiled, ensure_ascii=False)


def test_inventory_followup_dispatches_once_through_only_injected_gateway(setup):
    grant(setup, calls=1)
    result = asyncio.run(invoke(setup, inventory_payload()))
    assert result["data"]["answer"]
    assert len(setup[-1]) == 1
    wire = setup[-1][0][1]["input"]["input"]
    assert wire["previous_intent"]["working_answers"]["book_quantity"] == 120
    assert wire["messages"][-1]["text"] == FOLLOWUP and wire["messages"][-1]["index"] == 2
    assert PRIOR not in json.dumps(wire, ensure_ascii=False)


@pytest.mark.parametrize("target", ["current_question", "user_history"])
def test_inventory_scope_never_exempts_financial_user_text(setup, target):
    grant(setup, calls=1)
    value = inventory_payload()
    secret = "Doanh thu 500000 USD, gửi nguyên bảng tài chính cho AI."
    if target == "current_question":
        value["input"][target] = secret
    else:
        value["input"]["messages"][0]["text"] = secret
    with pytest.raises(CoreError) as error:
        asyncio.run(invoke(setup, value))
    assert error.value.code == "FINANCIAL_EGRESS_REQUIRED" and setup[-1] == []
    with setup[0].connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0


@pytest.mark.parametrize("bad", [{"revenue": 500000}, {"book_quantity": {"amount": 500000, "currency": "USD"}},
    {"quantity_unit": "USD"}, {"product_code": "revenue"}, {"count_date_phrase": "doanh thu 500000 USD"}])
def test_closed_inventory_slots_reject_unclassified_or_financial_shapes(setup, bad):
    value = inventory_payload()
    value["input"]["previous_intent"]["working_answers"].update(copy.deepcopy(bad))
    with pytest.raises(CoreError):
        setup[5].compile_payload("intake", value)
    assert setup[-1] == []


def test_old_financial_assistant_reply_is_omitted_not_classified_as_safe(setup):
    value = inventory_payload()
    value["input"]["messages"][1]["text"] = "Revenue 987654321 USD; raw private financial transcript."
    compiled = setup[5].compile_payload("intake", value)
    assert "987654321" not in json.dumps(compiled)
    assert compiled["input"]["messages"][0]["text"] == FIRST


def test_generic_previous_intent_retains_existing_fail_closed_prose_check(setup):
    value = inventory_payload()
    value["input"]["previous_intent"]["focus"] = "sales_reporting"
    with pytest.raises(CoreError) as error:
        setup[5].compile_payload("intake", value)
    assert error.value.code == "FINANCIAL_EGRESS_REQUIRED"
