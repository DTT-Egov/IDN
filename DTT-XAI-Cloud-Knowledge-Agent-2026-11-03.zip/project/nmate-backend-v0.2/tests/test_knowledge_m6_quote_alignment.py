"""DF-060: only unique ASCII-whitespace alignment, never semantic repair."""
import json,sqlite3
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe,extracted
from test_knowledge_m3_domain_gateway import domain,invoke
from nmate.knowledge_v1 import ai_proposals as module
from nmate.knowledge_v1.governance import WikiGovernance
from nmate.v03.core import CoreError
from test_knowledge_m3_admission import saved

@pytest.mark.asyncio
async def test_paid_response_recovered_without_model_or_raw_mutation(domain):
    gw,_,actor,_,_,_,ref,calls=domain
    quote=ref['quote'].replace(' ','\n',1)
    data=dict(title='TEST ONLY',claims=[dict(kind='source_excerpt',text='TEST interpretation',
        evidence=[dict(evidence_id='1',quote=quote)])],gaps=['TEST incomplete source'],questions_for_expert=[])
    async def request(model,body,limit):
        calls.append(model)
        return dict(text=json.dumps(data),model=model,stop_reason='end_turn',usage={'input_tokens':100,'output_tokens':80})
    gw.request_fn=request
    result=await invoke(domain,output_schema=module.PROPOSAL_SCHEMA)
    with gw.repo.connection() as db:raw=dict(db.execute('SELECT * FROM core_domain_model_attempts WHERE id=?',(result['attempt_id'],)).fetchone())
    service=WikiGovernance(gw.repo)
    proposal=module.record_proposal(service,gw,actor,result['attempt_id'])
    stored=module.read_proposal(service,gw,actor,proposal['proposal_id'])['payload']
    assert stored['model_output']==data and stored['admission']['version']=='proposal-admission/3'
    proof=stored['admission']['claims'][0]['evidence_alignment'][0]
    assert proof['mode']=='ascii-whitespace-span/1' and proof['model_quote']==quote
    assert proof['canonical_quote']==ref['quote']
    assert stored['candidate']['claims'][0]['kind']=='interpretation'
    assert stored['admission']['claims'][0]['semantic_verified'] is False
    with gw.repo.connection() as db:
        assert dict(db.execute('SELECT * FROM core_domain_model_attempts WHERE id=?',(result['attempt_id'],)).fetchone())==raw
        before=list(db.iterdump())
    gw.request_fn=lambda *a:pytest.fail('No SDK on replay')
    assert module.record_proposal(service,gw,actor,result['attempt_id'])['cached']
    with gw.repo.connection() as db:assert list(db.iterdump())==before
    assert len(calls)==1

@pytest.mark.parametrize('source,quote',[
    ('Alpha beta.','Alpha\nbeta.'),('Alpha\r\nbeta.','Alpha beta.'),
    ('Alpha\t \r\nbeta.','Alpha\t\tbeta.'),('Từ 30/03/2026 đến khi đủ\nchỉ tiêu.','Từ 30/03/2026 đến\nkhi đủ\nchỉ tiêu.'),
])
def test_unique_whitespace_mapping_is_original_contiguous_span(pipe,source,quote):
    _,service,actor,_=pipe
    ex=extracted(pipe,raw=source.encode());chunk=ex['chunks'][0]['id']
    ref=service.pipeline_evidence(actor,chunk,source)
    body={'input':{'source_excerpts':[{'evidence_id':'1','ref':ref}]}}
    data=dict(title='TEST',claims=[dict(kind='interpretation',text='TEST',evidence=[dict(evidence_id='1',quote=quote)])],gaps=[],questions_for_expert=[])
    payload,admission=module.candidate_payload_v3(service,actor,data,body)
    evidence=payload['claims'][0]['evidence'][0]
    assert evidence['quote']==source and evidence['quote_start']==ref['quote_start']
    assert admission['claims'][0]['evidence_alignment'][0]['relative_end']==len(source)
    with pytest.raises(CoreError):module.candidate_payload(service,actor,data,body)

@pytest.mark.parametrize('source,quote',[
    ('Alpha beta. Alpha\nbeta.','Alpha\t\nbeta.'), # normalized ambiguity
    ('a a a','a\na'), # overlapping normalized matches
    ('Alpha beta.','alphA\nbeta.'),('100 triệu','1000\ntriệu'),
    ('Không đủ điều kiện','Không\nđiều kiện'),('Không đủ điều kiện','Có\nđủ điều kiện'),('Alpha beta.','Alpha\nbeta!'),
    ('Alpha-beta','Alpha\nbeta'),('Alpha beta','Alphabeta'),
    ('Alpha\u00a0beta','Alpha\nbeta'),('Alpha beta','Alpha\u00a0beta'),
    ('a b',' \r\n\t'),('Alpha beta',' Alpha\nbeta'),
])
def test_no_fuzzy_case_digit_word_punctuation_unicode_trim_or_ambiguity(pipe,source,quote):
    _,service,actor,_=pipe
    ex=extracted(pipe,raw=source.encode());ref=service.pipeline_evidence(actor,ex['chunks'][0]['id'],source)
    body={'input':{'source_excerpts':[{'evidence_id':'1','ref':ref}]}}
    data=dict(title='TEST',claims=[dict(kind='interpretation',text='TEST',evidence=[dict(evidence_id='1',quote=quote)])],gaps=[],questions_for_expert=[])
    with pytest.raises(CoreError):module.candidate_payload_v3(service,actor,data,body)

@pytest.mark.asyncio
async def test_new_v3_space_run_is_proven_but_historical_v2_remains_strict(domain):
    gw,_,actor,*_=domain;service=WikiGovernance(gw.repo)
    result,data=await saved(domain,quote='Training  for enterprises.')
    _,_,body,_=module.receipt_data(service,gw,actor,result['attempt_id'])
    with pytest.raises(CoreError):module.candidate_payload(service,actor,data,body)
    pid=module.record_proposal(service,gw,actor,result['attempt_id'])['proposal_id']
    value=module.read_proposal(service,gw,actor,pid)['payload']
    assert value['admission']['claims'][0]['evidence_alignment'][0]['canonical_quote']=='Training for enterprises.'
    assert value['model_output']['claims'][0]['evidence'][0]['quote']=='Training  for enterprises.'

@pytest.mark.asyncio
async def test_exact_v2_receipt_replay_does_not_run_v3_or_rewrite_history(domain,monkeypatch):
    from nmate.core_v1.runtime_schema import canonical,digest
    from nmate.v03.core import now_iso
    gw,_,actor,*_=domain;service=WikiGovernance(gw.repo)
    result,data=await saved(domain)
    _,dep,body,inv=module.receipt_data(service,gw,actor,result['attempt_id'])
    payload,admission=module.candidate_payload(service,actor,data,body)
    value=dict(model_output=data,candidate=payload,admission=admission,generated_by=result['attempt_id'],invoked_by=inv,
        assignee_id=actor,reviewed_by=None,published_by=None)
    with gw.repo.connection(write=True) as db:
        db.execute('INSERT INTO pol_wiki_ai_proposals VALUES(?,?,?,?,?,?,?,?)',
            ('v2-receipt',result['attempt_id'],dep['policy_id'],actor,canonical(inv),canonical(value),digest(value),now_iso()))
        before=list(db.iterdump())
    def forbidden(*a,**kw):pytest.fail('Old receipt must not use a newer admission')
    monkeypatch.setattr(module,'candidate_payload_v3',forbidden)
    assert module.record_proposal(service,gw,actor,result['attempt_id'])['cached']
    assert module.read_proposal(service,gw,actor,'v2-receipt')['payload']==value
    with gw.repo.connection() as db:assert list(db.iterdump())==before

@pytest.mark.asyncio
@pytest.mark.parametrize('fault',['offset','canonical_quote','semantic_true','semantic_zero','mode','source_ref_hash','candidate','drop_admission','retag_v2','reviewed_by','published_by'])
async def test_v3_reader_checks_original_input_even_after_projection_rehash(domain,fault):
    from nmate.core_v1.runtime_schema import canonical,digest
    gw,_,actor,*_=domain;service=WikiGovernance(gw.repo)
    result,_=await saved(domain,quote='Training\nfor enterprises.')
    pid=module.record_proposal(service,gw,actor,result['attempt_id'])['proposal_id']
    value=module.read_proposal(service,gw,actor,pid)['payload']
    _,dep,body,inv=module.receipt_data(service,gw,actor,result['attempt_id'])
    with gw.repo.connection() as db:forged=dict(db.execute('SELECT * FROM pol_wiki_ai_proposals WHERE id=?',(pid,)).fetchone())
    proof=value['admission']['claims'][0]['evidence_alignment'][0]
    if fault=='offset':proof['relative_start']+=1
    elif fault=='canonical_quote':proof['canonical_quote']+=' '
    elif fault=='semantic_true':value['admission']['claims'][0]['semantic_verified']=True
    elif fault=='semantic_zero':value['admission']['claims'][0]['semantic_verified']=0
    elif fault=='mode':proof['mode']='unknown'
    elif fault=='source_ref_hash':proof['source_ref_hash']='wrong'
    elif fault=='candidate':value['candidate']['body']='rehashed drift'
    elif fault=='drop_admission':del value['admission']
    elif fault in {'reviewed_by','published_by'}:value[fault]=actor
    else:value['admission']['version']='proposal-admission/2'
    with gw.repo.connection(write=True) as db:
        with pytest.raises(sqlite3.IntegrityError):
            db.execute('UPDATE pol_wiki_ai_proposals SET payload_json=?,content_hash=? WHERE id=?',(canonical(value),digest(value),pid))
    # Storage guard is one defense. Exercise the reader separately with a
    # counterfeit imported row, without dropping schema guards or mutating DB.
    forged.update(payload_json=canonical(value),content_hash=digest(value))
    with pytest.raises(CoreError):module._verified_stored(service,forged,actor,result,dep,body,inv)
    assert module.read_proposal(service,gw,actor,pid)['payload']['model_output']==result['data']

@pytest.mark.asyncio
async def test_v3_read_and_free_admission_need_current_read_not_export(domain):
    gw,source,actor,_,_,_,ref,calls=domain;service=WikiGovernance(gw.repo)
    result,_=await saved(domain,quote='Training\nfor enterprises.')
    source.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=True,allow_export=False,
        reason='TEST export revoked',operation_id='revoke-export-v3')
    pid=module.record_proposal(service,gw,actor,result['attempt_id'])['proposal_id']
    assert module.read_proposal(service,gw,actor,pid)['payload']['admission']['version']=='proposal-admission/3'
    source.set_source_rights(actor,'KB-TEST-A',expected_version=2,allow_read=False,allow_export=False,
        reason='TEST read revoked',operation_id='revoke-read-v3')
    with pytest.raises(CoreError):module.read_proposal(service,gw,actor,pid)
    with pytest.raises(CoreError):module.record_proposal(service,gw,actor,result['attempt_id'])
    assert len(calls)==1
