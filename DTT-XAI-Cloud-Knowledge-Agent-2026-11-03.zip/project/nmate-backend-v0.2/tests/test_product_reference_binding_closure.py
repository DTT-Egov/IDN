"""DF-008: read-only references use exact owned identities, not name proposals."""
import copy
import unicodedata

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.intake import IntakeService
from nmate.v04.product_binding import product_scope
from nmate.v04.conversations import ConversationService
from test_review_commands_v2 import data_snapshot


@pytest.fixture
def local_workspace(tmp_path):
    repo = CoreRepository(tmp_path / "reference-binding.sqlite3")
    owner = LocalAccounts(repo).register("reference-owner", "Local-only-password-123", "Cơ sở kiểm thử")
    return repo, IntakeService(repo), owner["account_id"], owner["enterprise_id"]


@pytest.mark.parametrize("name", ["Trà Sen", "TRÀ SEN", unicodedata.normalize("NFD", "Trà Sen")])
def test_exact_owned_reference_uses_context_without_name_assertion(local_workspace, name):
    repo, intake, account, enterprise = local_workspace
    product = repo.create_entity(account, enterprise, "product", "Trà Sen")
    snapshot = data_snapshot(repo)
    item = intake.prepare(account, enterprise,
        f"Chị có nên nhập thêm hàng {name} khi tồn kho còn 120 hộp?", [], "exact-reference")
    assert item["product"]["id"] == product["id"]
    assert item["candidates"] == []
    assert item["reused_context"]["entity_ids"] == [product["id"]]
    assert intake.get(account, enterprise, item["id"])["candidates"] == []
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == snapshot[table]


@pytest.mark.parametrize("saved, mentioned", [
    ("Trà Sen Tây Hồ", "Trà Sen"), ("Trà Sen", "Trà Sen Cao Cấp"),
    ("Trà Sen", "Trà Sén"), ("Trà Sen", "Tra Sen"), ("Tra Sen", "Trà Sen"),
])
def test_unknown_or_different_reference_never_borrows_saved_product(local_workspace, saved, mentioned):
    repo, intake, account, enterprise = local_workspace
    product = repo.create_entity(account, enterprise, "product", saved)
    before = data_snapshot(repo)
    item = intake.prepare(account, enterprise,
        f"Chị có nên nhập thêm hàng {mentioned} khi tồn kho còn 120 hộp?", [], "unknown-reference", product["id"])
    assert item["product"] is None
    assert item["product_binding"]["state"] == "unbound_reference"
    assert item["product_binding"]["referenced_name"] == mentioned
    assert item["candidates"] == [] and not item["reused_context"]["entity_ids"]
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == before[table]


def test_reference_cannot_inherit_a_previous_confirmed_product(local_workspace):
    repo, intake, account, enterprise = local_workspace
    product = repo.create_entity(account, enterprise, "product", "Trà Sen Tây Hồ")
    previous = {"product": copy.deepcopy(product), "product_binding": {"state": "selected_confirmed"}}
    before = data_snapshot(repo)
    with repo.connection() as db:
        selected, binding = product_scope(intake, account, enterprise,
            "Chị có nên nhập thêm hàng Bột Sen khi tồn kho còn 120 hộp?", db, previous=previous)
    assert selected is None and binding["state"] == "unbound_reference"
    assert data_snapshot(repo) == before


def test_unknown_reference_starts_separate_work_unit_without_clobbering_old_draft(local_workspace):
    repo, intake, account, enterprise = local_workspace
    chats = ConversationService(intake)
    first = chats.send(account, enterprise, "Chị có Trà Sen Tây Hồ, hộp 100 g", [], "first-tea-reference")
    old = copy.deepcopy(first["intake"])
    before = data_snapshot(repo)
    second = chats.send(account, enterprise,
        "Chị có nên nhập thêm hàng Bột Sen khi tồn kho còn 120 hộp?", [], "unknown-next-reference", first["id"])
    current = second["intake"]
    assert current["id"] != old["id"] and current["product"] is None
    assert current["product_binding"]["state"] == "unbound_reference"
    assert current["candidates"] == [] and not current["reused_context"]["entity_ids"]
    assert intake.get(account, enterprise, old["id"])["candidates"] == old["candidates"]
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == before[table]


@pytest.mark.parametrize("saved, mentioned", [("Trà Sen", "Tra Sen"), ("Tra Sen", "Trà Sen"),
    ("Tra Sen", "Tra Sen Cao Cap")])
def test_raw_owned_reference_never_strips_accents_or_matches_shorter_prefix(local_workspace, saved, mentioned):
    repo, intake, account, enterprise = local_workspace
    repo.create_entity(account, enterprise, "product", saved)
    with repo.connection() as db:
        assert intake.resolve_product_reference(account, enterprise,
            f"Chị kiểm kê {mentioned}, tồn kho còn 120 hộp", db) is None


def test_desired_packaging_change_never_becomes_an_observed_current_value():
    from nmate.v04.extraction import extract_product_text
    for text in ("Chị muốn cải thiện bao bì chống ẩm.", "Chị cần thiết kế bao bì túi zip.",
                 "Hãy đổi bao bì thành hộp giấy.", "Chị hỏi về bao bì túi zip.",
                 "Bao bì túi zip có phù hợp để giữ hương trà không?",
                 "Chị có nên dùng túi zip làm bao bì?", "Kiểm tra bao bì túi zip.",
                 "Góp ý bao bì túi zip.", "Đánh giá bao bì túi zip.", "Xem bao bì túi zip có phù hợp không.",
                 "Bao bì nên dùng loại nào.", "Chị muốn cải thiện bảo quản bao bì chống ẩm.",
                 "Chị muốn đổi sang bao bì hộp giấy.",
                 "Chị muốn cải thiện khả năng bảo quản của bao bì chống ẩm."):
        assert extract_product_text(text) == []
    declared = extract_product_text("Chị muốn đi Mỹ, bao bì túi zip.")
    assert {fact["field"]: fact["value"] for fact in declared} == {"packaging": "túi zip"}
    assert {fact["field"]: fact["value"] for fact in extract_product_text(
        "Bao bì túi zip; chị muốn cải thiện bảo quản bao bì.")} == {"packaging": "túi zip"}


@pytest.mark.parametrize("tail", ["tồn kho còn 120 kg", "bán 30 kg mỗi tuần", "lô hàng 500 kg",
    "kho còn 120 kg", "nhập 50 kg mỗi tháng"])
def test_operational_mass_is_not_net_content(tail):
    from nmate.v04.extraction import extract_product_text
    facts = extract_product_text("Chị có Trà Sen 100 g, " + tail + ".")
    assert {fact["field"]: fact["value"] for fact in facts} == {"name": "Trà Sen", "net_quantity": "100 g"}


def test_multiple_product_reference_never_binds_only_the_one_saved_product(local_workspace):
    repo, intake, account, enterprise = local_workspace
    product = repo.create_entity(account, enterprise, "product", "Trà Sen")
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        intake.prepare(account, enterprise, "Chị kiểm kê Trà Sen và Bột Sen, tồn kho còn 120 hộp", [],
                       "multiple-product-reference", product["id"])
    assert error.value.code == "multiple_products_not_supported"
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("text, expected", [
    ("Chị muốn cập nhật hồ sơ: bao bì túi zip, lượng tịnh 200 g.", {"packaging": "túi zip", "net_quantity": "200 g"}),
    ("Chị cần ghi nhớ bao bì: túi zip.", {"packaging": "túi zip"}),
    ("Xin lưu khối lượng tịnh: 200 g.", {"net_quantity": "200 g"}),
    ("Chị đã kiểm tra bao bì: túi zip.", {"packaging": "túi zip"}),
])
def test_commands_to_propose_literal_values_keep_owner_review_contract(text, expected):
    from nmate.v04.extraction import extract_product_text
    facts = extract_product_text(text)
    assert {fact["field"]: fact["value"] for fact in facts} == expected
    assert all(fact["source"]["review_state"] == "owner_confirmation_required" for fact in facts)


def test_document_instruction_purpose_does_not_override_the_exact_selected_product(local_workspace):
    repo, intake, account, enterprise = local_workspace
    product = repo.create_entity(account, enterprise, "product", "Trà Sen Tây Hồ")
    before = data_snapshot(repo)
    item = intake.prepare(account, enterprise, "Chị đọc tài liệu Trà Sen Tây Hồ để lập nháp hồ sơ.", [],
                          "document-purpose-reference", product["id"])
    assert item["product"]["id"] == product["id"]
    assert item["candidates"] == []
    after = data_snapshot(repo)
    for table in ("v03_entities", "v03_entity_names", "v03_current_facts", "v03_fact_assertions"):
        assert after[table] == before[table]


