"""MVP0.5 user journeys through authenticated HTTP → MCP, with no model/network dispatch."""
from io import BytesIO

import httpx
from pypdf import PdfReader

from test_core_policy_http import running, register, call, good


def test_policy_draft_chat_reload_private_idempotency_and_print(tmp_path):
    calls = []

    async def forbidden(*args):
        calls.append(args)
        raise AssertionError("No paid call is authorized by these tests")

    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as owner, \
             httpx.Client(base_url=url, trust_env=False, timeout=20) as other:
            session = register(owner, url, "mvp05-http-owner")
            outsider = register(other, url, "mvp05-http-other")
            question = "Chị muốn xuất khẩu trà sen và đào tạo nhân viên làm sổ sách; giúp chị chuẩn bị đề nghị tư vấn."
            args = dict(question=question, kind="participation_request", operation_id="draft-http-once")
            created = good(owner, url, session, "policy05_create_draft", **args)
            draft = created["policy_draft"]
            assert draft["kind"] == "request_guidance"
            assert draft["provider_calls"] == 0
            assert draft["conversation_id"]
            repeated = good(owner, url, session, "policy05_create_draft", **args)["policy_draft"]
            assert repeated["id"] == draft["id"]
            chat = good(owner, url, session, "get_conversation", conversation_id=draft["conversation_id"])
            assert [d["id"] for d in chat["policy_drafts"]] == [draft["id"]]
            assert len([m for m in chat["messages"] if m["role"] == "user"]) == 1
            assert chat["messages"][0]["text"] == question
            assert not call(other, url, outsider, "policy05_get_draft", draft_id=draft["id"])["ok"]
            assert not call(other, url, outsider, "policy05_get_draft", enterprise_id=session["enterprise"]["id"],
                            draft_id=draft["id"])["ok"]
            reopened = good(owner, url, session, "policy05_get_draft", draft_id=draft["id"])["policy_draft"]
            assert reopened["body"] == draft["body"]
            pdf_url = f"/api/main/policy05/drafts/{draft['id']}/pdf?e={session['enterprise']['id']}&revision={draft['version']}"
            pdf = owner.get(pdf_url)
            assert pdf.status_code == 200, pdf.text[:500] if pdf.status_code != 200 else ""
            assert pdf.headers["content-type"].startswith("application/pdf")
            text = "\n".join(p.extract_text() for p in PdfReader(BytesIO(pdf.content)).pages)
            assert "BẢN NHÁP" in text and "Chưa gửi" in text
            assert other.get(pdf_url).status_code in {403, 404}
            assert owner.get(pdf_url.replace(f"revision={draft['version']}", "revision=999999")).status_code == 409
            assert not calls


def test_policy05_status_explicitly_reports_unqualified_ihanoi_without_call(tmp_path):
    with running(tmp_path) as (_, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as owner:
            session = register(owner, url, "mvp05-status-owner")
            status = owner.get("/api/main/status").json()
            assert status["features"]["policy05_workbench"] is True
            assert status["integrations"]["ihanoi"]["state"] == "not_configured"
            assert status["integrations"]["ihanoi"]["can_submit"] is False
            draft = good(owner, url, session, "policy05_create_draft", question="Chị muốn kiến nghị có lớp sổ sách buổi tối.",
                         kind="business_petition", operation_id="petition-1")["policy_draft"]
            result = call(owner, url, session, "policy05_submit_draft", draft_id=draft["id"],
                          expected_version=draft["version"], operation_id="do-not-send")
            assert not result["ok"]
            assert result["error"]["code"] == "IHANOI_NOT_CONFIGURED"
            assert good(owner, url, session, "policy05_get_draft", draft_id=draft["id"])["policy_draft"]["version"] == draft["version"]
