"""DF-002/003/046: shared field and receipt contracts, with no provider calls."""
from __future__ import annotations

import copy
import socket

import pytest

from nmate.core_v1.ssot import CoreSSOTService
import nmate.core_v1.ssot as ssot_module
import nmate.v03.core as core_module
from nmate.v03.core import CoreError, CoreRepository, causal_fact_rows
from nmate.v03.domain_validation import FIELD_VALUE_KINDS, FINANCIAL_FIELD_BASES, field_is_financial, field_value_contract, product_identity_key, validate_field_value
from nmate.v03.field_scope import field_is_in_scope, scope_contract
from nmate.v03.identity import LocalAccounts
from nmate.v04.extraction import product_name_key, typed_value
from test_review_commands_v2 import data_snapshot
from test_ssot_field_scope import legacy_fact


@pytest.fixture(autouse=True)
def local_only(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("SSOT invariant checks must not use a provider or network")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "design-ssot.sqlite3")
    owner = LocalAccounts(repo).register("design-owner", "Local-only-test-password", "Trà Sen QA")
    service = CoreSSOTService(repo)
    product = repo.create_entity(*scope(owner), "product", "Trà Sen Tây Hồ")
    company = repo.create_entity(*scope(owner), "enterprise", "Cơ sở Trà Sen")
    return repo, service, owner, product, company


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


@pytest.mark.parametrize("field,value,entity_kind", [
    ("net_quantity.2026", "một trăm gam abc", "product"),
    ("net_weight.override", "100 ml", "product"),
    ("product_code.alternate", "TS 001", "product"),
    ("sku.2026", "A<script>", "product"),
    ("employee_count.2026", -1, "enterprise"),
    ("employees.2026", True, "enterprise"),
    ("annual_employee_count.2026", 1.5, "enterprise"),
    ("EMPLOYEE_COUNT.2026", -1, "enterprise"),
    ("NET_QUANTITY.2026", "100 abc", "product"),
])
def test_qualified_fields_cannot_escape_base_constraints(workspace, field, value, entity_kind):
    repo, service, owner, product, company = workspace
    target = product if entity_kind == "product" else company
    facts = [{"field": "name", "value": target["name"]}, {"field": field, "value": value}]
    before = data_snapshot(repo)
    for invoke in (
        lambda: repo.propose_or_apply_facts(*scope(owner), target["id"], facts, 0, "invalid-direct"),
        lambda: service.propose_facts(*scope(owner), target["id"], facts, 0, "invalid-proposal"),
    ):
        with pytest.raises(CoreError):
            invoke()
        assert data_snapshot(repo) == before


@pytest.mark.parametrize("field,value", [("net_quantity.2026", "100 g"), ("employee_count.2026", 0),
                                         ("employees", 3), ("annual_employee_count", 0)])
def test_qualified_valid_values_keep_original_representation(field, value):
    original = copy.deepcopy(value)
    assert validate_field_value(field, value) is None
    assert value == original


def test_registry_is_shared_immutable_and_qualifiers_do_not_reinterpret_units():
    with pytest.raises(TypeError):
        FIELD_VALUE_KINDS["net_quantity"] = "unvalidated"
    assert field_value_contract("employee_count.2026")["minimum"] == 0
    assert field_value_contract("employee_count.2026")["base_field"] == "employee_count"
    assert field_value_contract("net_weight.2026")["kind"] == "mass"
    assert field_value_contract("private_extension") is None
    assert scope_contract("product")["registry_version"] == "ssot-field-scope/2"
    for name in [" Trà  Sen  ", "TRÀ SEN", "Tra Sen", "Tra\u0300 Sen"]:
        assert product_name_key(name) == product_identity_key(name)
    assert product_name_key("Tra Sen") != product_name_key("Trà Sen")
    for quantity in ["100 μg", "100 µg", "100 fl oz", "0,1 kg", "100g"]:
        value, _kind = typed_value("net_quantity", quantity)
        assert validate_field_value("net_quantity", value) is None


@pytest.mark.parametrize("patch,code", [
    ({"value": None, "value_state": []}, "invalid_state"),
    ({"value": None, "explicit_clear": "true"}, "invalid_fact_action"),
    ({"value": None, "explicit_clear": 1}, "invalid_fact_action"),
    ({"value": [], "value_state": "unknown"}, "invalid_fact"),
    ({"value": False, "value_state": "known_absent"}, "invalid_fact"),
])
def test_fact_transition_input_errors_are_typed(patch, code):
    with pytest.raises(CoreError) as error:
        CoreRepository._normalize_fact({"field": "private_extension", **patch})
    assert error.value.code == code


@pytest.mark.parametrize("value", [False, 0, [], ""])
def test_known_falsy_extensions_are_values_not_null_or_clear(value):
    result = CoreRepository._normalize_fact({"field": "private_extension", "value": value})
    assert result["value"] == value and result["value_state"] == "known" and not result["explicit_clear"]


def test_unknown_noop_is_not_a_clear_or_a_known_absence():
    assert CoreRepository._normalize_fact({"field": "certifications", "value": None}) is None
    absent = CoreRepository._normalize_fact({"field": "certifications", "value": None, "value_state": "known_absent"})
    cleared = CoreRepository._normalize_fact({"field": "certifications", "value": None, "explicit_clear": True})
    assert absent["value_state"] == "known_absent" and not absent["explicit_clear"]
    assert cleared["value_state"] == "unknown" and cleared["explicit_clear"]


@pytest.mark.parametrize("field", ["cost", "costs.2026", "operating_cost.2026", "cash_flow.2026", "finance.revenue", "assets_total",
                                   "Revenue.2026", "CASH_FLOW.2026", "Finance.Revenue", "Assets_Total"])
def test_finance_classifier_and_entity_scope_share_one_registry(field):
    from nmate.core_v1.finance import is_financial_field
    from nmate.core_v1.ssot import FINANCE_FIELDS, _finance
    assert FINANCE_FIELDS is FINANCIAL_FIELD_BASES
    assert field_is_financial(field) and is_financial_field(field) and _finance(field)
    assert not field_is_in_scope("product", field)
    assert field_is_in_scope("enterprise", field) and field_is_in_scope("financial_period", field)


def test_new_finance_aliases_cannot_escape_scope_or_wildcard_acl(workspace):
    repo, service, owner, product, company = workspace
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "cash_flow.2026", "value": -10}], 0, "wrong-scope")
    assert error.value.code == "invalid_field_scope" and data_snapshot(repo) == before
    repo.propose_or_apply_facts(*scope(owner), company["id"], [{"field": "cash_flow.2026", "value": -10}], 0, "finance-owner")
    staff = LocalAccounts(repo).register("design-staff", "Local-only-test-password", "Cá nhân")
    service.add_member(*scope(owner), staff["username"])
    service.grant_resource(*scope(owner), company["id"], staff["account_id"], ["read"], ["*"])
    assert not service.can_read(staff["account_id"], owner["enterprise_id"], company["id"], "cash_flow.2026")
    service.grant_resource(*scope(owner), company["id"], staff["account_id"], ["read_finance"], ["cash_flow.2026"])
    assert service.can_read(staff["account_id"], owner["enterprise_id"], company["id"], "cash_flow.2026")


@pytest.mark.parametrize("bounds", [{"valid_from": "2099-01-01"}, {"valid_to": "2000-01-01"}])
def test_noncurrent_name_does_not_materialize_as_current_identity_label(workspace, bounds):
    repo, _, owner, product, _ = workspace
    repo.propose_or_apply_facts(*scope(owner), product["id"],
        [{"field": "name", "value": "Tên chỉ thuộc thời điểm khác", **bounds}], 0, "name-not-current")
    view = repo.get_entity(*scope(owner), product["id"])
    assert view["name"] == "Trà Sen Tây Hồ"
    context = repo.get_context(*scope(owner), [product["id"]])
    assert context["entities"][0]["name"] == "Trà Sen Tây Hồ"
    assert "name" not in context["entities"][0]["values"]
    history = repo.get_fact_history(*scope(owner), product["id"], "name")
    assert history[0]["value"] == "Tên chỉ thuộc thời điểm khác"


def test_equal_timestamps_use_causal_chain_not_uuid_for_current_context_or_versions(workspace, monkeypatch):
    repo, service, owner, product, _ = workspace
    stamp, real_id = core_module.now_iso(), core_module.new_id
    ids = iter(["resolution_z_first", "resolution_m_second", "resolution_a_third"])
    monkeypatch.setattr(core_module, "now_iso", lambda: stamp)
    monkeypatch.setattr(ssot_module, "now_iso", lambda: stamp)
    monkeypatch.setattr(core_module, "new_id", lambda prefix: next(ids) if prefix == "resolution" else real_id(prefix))
    for version, quantity in enumerate(["100 g", "200 g", "300 g"]):
        repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": quantity}], version, "same-clock-" + str(version))
    before = data_snapshot(repo)
    current = service.get_context(*scope(owner), [product["id"]], save_snapshot=False)
    assert current["entities"][0]["values"]["net_quantity"] == "300 g"
    assert current["entities"][0]["facts"][0]["version"] == 3
    assert repo.get_context(*scope(owner), [product["id"]])["entities"][0]["values"]["net_quantity"] == "300 g"
    versions = repo.entity_versions(*scope(owner), product["id"])
    assert [(event["to_value"], event["version"]) for event in versions["events"]] == [("300 g", 3), ("200 g", 2), ("100 g", 1)]
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("previous", ["missing_assertion", "child"])
def test_broken_or_cyclic_causal_history_is_not_promoted_to_current_context(previous):
    row = {"id": "child", "previous_assertion_id": previous, "recorded_at": "2026-10-22T00:00:00+00:00",
           "enterprise_id": "qa-enterprise", "entity_id": "qa-product", "field": "net_quantity"}
    with pytest.raises(CoreError) as error:
        causal_fact_rows([row])
    assert error.value.code == "fact_history_invalid"


def test_causal_history_cannot_link_different_fields():
    common = {"recorded_at": "2026-10-22T00:00:00+00:00", "enterprise_id": "qa-enterprise", "entity_id": "qa-product"}
    parent = {**common, "id": "parent", "field": "name", "previous_assertion_id": None}
    child = {**common, "id": "child", "field": "net_quantity", "previous_assertion_id": "parent"}
    with pytest.raises(CoreError) as error:
        causal_fact_rows([child, parent])
    assert error.value.code == "fact_history_invalid"


def test_legacy_qualified_bad_quantity_is_auditable_but_never_context(workspace):
    repo, service, owner, product, _ = workspace
    legacy_fact(repo, owner, product["id"], "net_quantity.2026", "100 hộp abc")
    before = data_snapshot(repo)
    assert repo.get_entity(*scope(owner), product["id"])["validation_issues"]
    assert "net_quantity.2026" not in repo.get_context(*scope(owner), [product["id"]])["entities"][0]["values"]
    for snapshot in (False, True):
        context = service.get_context(*scope(owner), [product["id"]], ["net_quantity.2026"], save_snapshot=snapshot)
        assert context["entities"][0]["values"] == {}
        assert context["entities"][0]["facts"][0]["value_state"] == "unknown"
    current = repo.get_context(*scope(owner), [product["id"]])
    validation = repo.validate_context(*scope(owner), current["fact_refs"])
    assert validation["valid"] is True
    assert current["fact_refs"][0]["usage"] == "excluded_invalid"
    old_refs = [{key: value for key, value in ref.items() if key != "usage"} for ref in current["fact_refs"]]
    assert repo.validate_context(*scope(owner), old_refs)["reasons"][0]["reason"] == "invalid_value"
    assert len(repo.get_fact_history(*scope(owner), product["id"], "net_quantity.2026")) == 1
    after = data_snapshot(repo)
    for table in before:
        if table != "core_v1_context_snapshots":
            assert before[table] == after[table]


@pytest.mark.parametrize("value", ["100 g", 0, False, [], {}])
def test_set_and_clear_in_one_command_is_rejected_without_silent_data_loss(workspace, value):
    repo, _, owner, product, _ = workspace
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"],
            [{"field": "private_extension", "value": value, "explicit_clear": True}], 0, "ambiguous-clear")
    assert error.value.code == "conflicting_fact_action"
    assert data_snapshot(repo) == before


def test_archived_entity_cannot_pass_validation_of_old_context_refs(workspace):
    repo, _, owner, product, _ = workspace
    repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "seed")
    context = repo.get_context(*scope(owner), [product["id"]])
    assert repo.validate_context(*scope(owner), context["fact_refs"])["valid"]
    repo.archive_entity(*scope(owner), product["id"], 1, "archive")
    before = data_snapshot(repo)
    result = repo.validate_context(*scope(owner), context["fact_refs"])
    assert not result["valid"] and result["reasons"][0]["reason"] == "entity_archived"
    assert data_snapshot(repo) == before


def test_fact_receipt_can_be_replayed_after_archive_but_not_used_as_new_write(workspace):
    repo, _, owner, product, _ = workspace
    facts = [{"field": "net_quantity", "value": "100 g"}]
    saved = repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "receipt-before-archive")
    repo.archive_entity(*scope(owner), product["id"], 1, "archive-product")
    before = data_snapshot(repo)
    assert repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "receipt-before-archive") == saved
    assert data_snapshot(repo) == before
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 2, "new-write-after-archive")
    assert error.value.code == "entity_archived"
    assert data_snapshot(repo) == before


def retain_read_but_remove_write(repo, service, owner, product):
    # Reproduce a future role transition without adding a new role-management UI.
    # The explicit read grant is already supported; role loss must not rewrite it.
    service.grant_resource(*scope(owner), product["id"], owner["account_id"], ["read"], ["*"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?", scope(owner))


def test_exact_fact_replay_requires_read_not_write_and_rechecks_all_receipt_fields(workspace):
    repo, service, owner, product, _ = workspace
    facts = [{"field": "net_quantity", "value": "100 g"}]
    saved = repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "receipt-readable")
    retain_read_but_remove_write(repo, service, owner, product)
    before = data_snapshot(repo)
    assert repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "receipt-readable") == saved
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 1, "not-a-new-writer")
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_v1_grants SET revoked_at='2026-10-22' WHERE account_id=?", (owner["account_id"],))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "receipt-readable")
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before


def test_proposal_confirmation_receipt_read_survives_write_loss_only(workspace):
    repo, service, owner, product, _ = workspace
    proposal = service.propose_facts(*scope(owner), product["id"], [{"field": "net_quantity", "value": "100 g"}], 0, "propose")
    args = (*scope(owner), proposal["proposal_id"], 0, "confirm")
    saved = service.confirm_facts(*args, proposal_hash=proposal["proposal_hash"])
    retain_read_but_remove_write(repo, service, owner, product)
    before = data_snapshot(repo)
    assert service.confirm_facts(*args, proposal_hash=proposal["proposal_hash"]) == saved
    with pytest.raises(CoreError) as error:
        service.confirm_facts(*scope(owner), proposal["proposal_id"], 1, "new-confirm")
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_v1_grants SET revoked_at='2026-10-22' WHERE account_id=?", (owner["account_id"],))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        service.confirm_facts(*args, proposal_hash=proposal["proposal_hash"])
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before


def test_receipt_replay_cannot_expose_as_of_fields_beyond_current_read_grant(workspace):
    repo, service, owner, product, _ = workspace
    repo.propose_or_apply_facts(*scope(owner), product["id"], [{"field": "ingredients", "value": "Trà, sen"}], 0, "initial")
    facts = [{"field": "net_quantity", "value": "100 g"}]
    saved = repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 1, "narrow-replay")
    assert {fact["field"] for fact in saved["facts"]} == {"net_quantity", "ingredients"}
    service.grant_resource(*scope(owner), product["id"], owner["account_id"], ["read"], ["net_quantity"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id=? AND enterprise_id=?", scope(owner))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 1, "narrow-replay")
    assert error.value.status_code == 403
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("role", ["owner", "staff"])
@pytest.mark.parametrize("capability", ["read", "propose_fact", "read_finance", "send_financial_metrics"])
def test_revoked_legacy_acl_denies_even_owner_or_explicit_additive_grant(workspace, role, capability):
    repo, service, owner, product, _ = workspace
    service.grant_resource(*scope(owner), product["id"], owner["account_id"],
        list({"read", capability}), ["*"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role=? WHERE account_id=? AND enterprise_id=?", (role, *scope(owner)))
        assert service._can(db, *scope(owner), product["id"], capability, "net_quantity")
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (product["id"],))
    before = data_snapshot(repo)
    with repo.connection() as db:
        assert not service._can(db, *scope(owner), product["id"], capability, "net_quantity")
    assert not service.can_read(*scope(owner), product["id"], "net_quantity")
    assert data_snapshot(repo) == before


@pytest.mark.parametrize("route", ["direct", "proposal"])
@pytest.mark.parametrize("role", ["owner", "staff"])
def test_exact_receipt_read_cannot_bypass_revoked_entity_acl(workspace, route, role):
    repo, service, owner, product, _ = workspace
    facts = [{"field": "net_quantity", "value": "100 g"}]
    if route == "direct":
        def replay():
            return repo.propose_or_apply_facts(*scope(owner), product["id"], facts, 0, "old-command")
    else:
        proposal = service.propose_facts(*scope(owner), product["id"], facts, 0, "proposal")
        def replay():
            return service.confirm_facts(*scope(owner), proposal["proposal_id"], 0, "old-command", proposal_hash=proposal["proposal_hash"])
    replay()
    service.grant_resource(*scope(owner), product["id"], owner["account_id"], ["read"], ["*"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET role=? WHERE account_id=? AND enterprise_id=?", (role, *scope(owner)))
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (product["id"],))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as error:
        replay()
    assert error.value.status_code == 403 and data_snapshot(repo) == before
