"""R0/R1: archived governed output inherits current input READ, never new IO.

All rows belong to pytest tmp_path. A synthetic transport establishes one
accepted receipt; no provider SDK, MAIN database or private user input is used.
"""
from __future__ import annotations

import asyncio
import copy
from datetime import datetime, timedelta, timezone
import json

import httpx
import pytest

from nmate.main.recorded_analysis import project_recorded_export_intake
from nmate.policy_v1.refresh_jobs import SourceRefreshJobs
from nmate.v03.core import CoreError, json_text, now_iso
from nmate.v03.live_review import IntakeOutput
from test_core_policy_http import call, register, running
from test_live_intake_clarification_separation import RECORDED_INTAKE


@pytest.fixture
def archive(tmp_path, monkeypatch):
    async def no_source_acquisition(self):
        return False

    monkeypatch.setattr(SourceRefreshJobs, "execute_next", no_source_acquisition)
    calls = []

    async def synthetic(model, body, limit):
        calls.append((model, limit))
        return {"text": json.dumps(RECORDED_INTAKE, ensure_ascii=False), "model": model,
                "usage": {"input_tokens": 10, "output_tokens": 5}, "stop_reason": "end_turn"}

    async def no_native_transport(*args):
        raise AssertionError("Native provider transport is forbidden")

    with running(tmp_path, request_fn=no_native_transport, gateway_request_fn=synthetic,
                 gateway_enabled=True) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=30) as web:
            session = register(web, url, "r0-archival-owner")
            repo, gateway = app.state.repo, app.state.gateway
            account, enterprise = session["account"]["id"], session["enterprise"]["id"]
            resource = repo.create_entity(account, enterprise, "product", "Trà Sen Tây Hồ")
            grant = gateway.authorize_budget(account, enterprise, approval_id="SYNTHETIC-R0-NO-PROVIDER",
                max_calls=1, max_cost_usd=1, purposes=["legacy_intake"], roles=["standard"],
                expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())["id"]
            receipt = asyncio.run(gateway.call_once(account_id=account, enterprise_id=enterprise,
                operation_id="r0-archive-operation", task_id="legacy_intake", role="standard",
                purpose="legacy_intake", context={"question": "Synthetic archival question"},
                output_schema=IntakeOutput.model_json_schema(), budget_grant_id=grant,
                resource_dependencies=[{"resource_id": resource["id"], "fields": ["name"]}]))
            native_id, conversation_id = "r0-archive-native", "r0-archive-chat"
            envelope = {"data": copy.deepcopy(receipt["data"]), "attempt_id": native_id,
                        "gateway_attempt_id": receipt["attempt_id"], "model": receipt["model"]}
            stamp = now_iso()
            chat = {"id": conversation_id, "enterprise_id": enterprise, "owner_id": account,
                    "title": "Synthetic archived export question", "messages": [], "drafts": {},
                    "intake_ids": [], "mission_ids": [], "operation_ids": ["r0-archive-operation"],
                    "latest_operation_id": "r0-archive-operation", "active_intake_id": None,
                    "task_hint": "export_research", "created_at": stamp, "updated_at": stamp}
            with repo.connection(write=True) as db:
                db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)",
                    (conversation_id, enterprise, account, json_text(chat), stamp, stamp))
                db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'failed','live_output_invalid',?)",
                    (account, enterprise, "r0-archive-operation", "synthetic-main-hash", conversation_id, "export_research", stamp))
                db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,model,state,response_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (native_id, account, enterprise, "r0-archive-operation", "intake", "synthetic-native-hash",
                     receipt["model"], "succeeded", json_text(envelope), stamp))
            yield app, web, url, session, resource["id"], receipt, conversation_id, calls


def revoke_input(archive):
    app, _, _, session, resource, receipt, _, calls = archive
    with app.state.repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (resource,))
    with pytest.raises(CoreError) as denied:
        app.state.gateway.read_receipt(session["account"]["id"], session["enterprise"]["id"], receipt["attempt_id"])
    assert denied.value.code == "forbidden" and len(calls) == 1


def project(archive, *, authority=True):
    app, _, _, session, _, _, conversation, _ = archive
    options = {"authorize_envelope": app.state.core_extension.legacy_adapter.authorize_recorded_envelope} if authority else {}
    return project_recorded_export_intake(app.state.repo, session["account"]["id"],
        session["enterprise"]["id"], conversation, **options)


def ledger_snapshot(archive):
    with archive[0].state.repo.connection() as db:
        return {table: [tuple(row) for row in db.execute("SELECT * FROM " + table)] for table in (
            "v03_live_attempts", "main_operations", "v04_conversations", "v03_current_facts",
            "v03_fact_assertions", "core_model_attempts", "core_model_operations",
            "core_model_request_manifests", "core_budget_grants")}


def test_governed_archival_projection_rechecks_original_input_read(archive):
    calls = archive[-1]
    saved = ledger_snapshot(archive)
    before = project(archive)
    assert before["outcomes"] and before["reported_product_name"] == "Trà Sen Tây Hồ"
    assert ledger_snapshot(archive) == saved
    revoke_input(archive)
    revoked = ledger_snapshot(archive)
    with pytest.raises(CoreError) as denied:
        project(archive)
    assert denied.value.code == "forbidden" and len(calls) == 1
    assert ledger_snapshot(archive) == revoked


def test_http_mcp_archival_read_cannot_return_revoked_governed_output(archive):
    _, web, url, session, _, _, conversation, calls = archive
    original = call(web, url, session, "get_conversation", conversation_id=conversation)
    assert original["ok"] and original["data"]["recorded_intake_analysis"]["outcomes"]
    revoke_input(archive)
    saved = ledger_snapshot(archive)
    result = call(web, url, session, "get_conversation", conversation_id=conversation)
    assert result["ok"] is False and result["error"]["code"] == "forbidden"
    assert len(calls) == 1
    assert ledger_snapshot(archive) == saved


def test_governed_archive_without_current_authority_fails_closed(archive):
    with pytest.raises(CoreError) as denied:
        project(archive, authority=False)
    assert denied.value.code == "RECORDED_AUTHORITY_UNAVAILABLE"
    assert len(archive[-1]) == 1


@pytest.mark.parametrize("reference", [None, "", 42, []])
def test_present_but_malformed_gateway_reference_never_becomes_native_archive(archive, reference):
    app = archive[0]
    with app.state.repo.connection(write=True) as db:
        envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id='r0-archive-native'").fetchone()[0])
        envelope["gateway_attempt_id"] = reference
        db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id='r0-archive-native'", (json_text(envelope),))
    saved = ledger_snapshot(archive)
    with pytest.raises(CoreError) as denied:
        project(archive)
    assert denied.value.code == "RECORDED_AUTHORITY_UNAVAILABLE"
    assert ledger_snapshot(archive) == saved and len(archive[-1]) == 1


@pytest.mark.parametrize("drift", ["data", "model", "missing_receipt"])
def test_governed_archive_checks_exact_saved_envelope(archive, drift):
    app = archive[0]
    with app.state.repo.connection(write=True) as db:
        envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id='r0-archive-native'").fetchone()[0])
        if drift == "data":
            envelope["data"]["product_name"] = "Mứt Sen"
        elif drift == "model":
            envelope["model"] = "claude-opus-5-5"
        else:
            envelope["gateway_attempt_id"] = "missing-receipt"
        db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id='r0-archive-native'", (json_text(envelope),))
    with pytest.raises(CoreError) as denied:
        project(archive)
    assert denied.value.code == ("RESOURCE_UNAVAILABLE" if drift == "missing_receipt" else "RECORDED_RECEIPT_MISMATCH")
    assert len(archive[-1]) == 1


def test_native_old_archive_does_not_invent_gateway_lineage(archive):
    app = archive[0]
    with app.state.repo.connection(write=True) as db:
        envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id='r0-archive-native'").fetchone()[0])
        envelope.pop("gateway_attempt_id")
        db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id='r0-archive-native'", (json_text(envelope),))
    # Pre-gateway receipt retains its original private membership-only
    # archival contract; no retrofit of dependencies or dispatch manifest.
    revoke_input(archive)
    value = project(archive, authority=False)
    assert value["reported_product_name"] == "Trà Sen Tây Hồ"
    assert value["verification_state"] == "structure_only_original_question_not_revalidated"
    assert value["new_model_calls"] == value["ssot_writes"] == 0 and len(archive[-1]) == 1


def test_archival_read_remains_available_without_fresh_budget_or_write(archive):
    app, web, url, session, _, receipt, conversation, calls = archive
    gateway = app.state.gateway
    gateway.enabled = False
    with app.state.repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_grants SET state='closed'")
    saved = ledger_snapshot(archive)
    expected = gateway.read_receipt(session["account"]["id"], session["enterprise"]["id"], receipt["attempt_id"])
    first = call(web, url, session, "get_conversation", conversation_id=conversation)
    assert first["ok"] and first["data"]["recorded_intake_analysis"]["reported_product_name"] == expected["data"]["product_name"]
    assert len(calls) == 1
    assert ledger_snapshot(archive) == saved
