"""Loopback-only synthetic workbench for M3 browser QA. No keys/live data."""
from pathlib import Path
import argparse
from fastapi import FastAPI
from nmate.knowledge_v1.workbench import router
from nmate.core_v1.gateway import ModelGateway
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed,attest

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--directory',required=True);parser.add_argument('--port',type=int,default=8026);args=parser.parse_args()
    path=Path(args.directory).resolve();path.mkdir(parents=True,exist_ok=True)
    if (path/'knowledge-test.sqlite').exists(): raise SystemExit('Use a new fixture namespace, never overwrite existing history.')
    k=kb.__wrapped__(path);p=pipe.__wrapped__(k,path);env=governed.__wrapped__(p,path)
    repo,service,author,reviewer,page=env;attest(env)
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_wiki_capabilities VALUES(?,'TEST-POLICY','KB-TEST-A','author','TEST-ONLY',NULL)",(reviewer,))
    gateway=ModelGateway(repo,enabled=False)
    def synthetic_session(request): return reviewer
    app=FastAPI(title='SYNTHETIC ONLY M3 · No AI / No MAIN')
    app.include_router(router(service,gateway,synthetic_session))
    import uvicorn
    uvicorn.run(app,host='127.0.0.1',port=args.port,log_level='warning')
if __name__=='__main__': main()
