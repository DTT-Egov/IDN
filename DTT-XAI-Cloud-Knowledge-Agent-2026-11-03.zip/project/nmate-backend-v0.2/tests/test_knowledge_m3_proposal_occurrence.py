"""M3 adapters must not erase M2's exact occurrence contract (DF-005/033)."""
import pytest
from test_knowledge_m2 import pipe,extracted
from test_knowledge_m1 import kb
from nmate.knowledge_v1.ai_proposals import candidate_payload
from nmate.v03.core import CoreError

@pytest.mark.parametrize('source,quote',[('Alpha Alpha','Alpha'),('aaa','aa')])
def test_model_subquote_without_unique_occurrence_is_not_assigned_first_span(pipe,source,quote):
    _,service,actor,_=pipe
    ex=extracted(pipe,raw=source.encode())
    ref=service.pipeline_evidence(actor,ex['chunks'][0]['id'],source)
    body={'input':{'source_excerpts':[{'evidence_id':'1','ref':ref}]}}
    output=dict(title='TEST ONLY',claims=[dict(kind='source_excerpt',text=quote,evidence=[dict(evidence_id='1',quote=quote)])],gaps=[],questions_for_expert=[])
    with pytest.raises(CoreError,match='vị trí'):
        candidate_payload(service,actor,output,body)
