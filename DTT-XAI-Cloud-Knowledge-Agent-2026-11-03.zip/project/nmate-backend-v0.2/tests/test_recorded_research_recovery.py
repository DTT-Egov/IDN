"""Cache-only maintenance never sends another model request (all models injected)."""
import asyncio
import hashlib
import json

import pytest

from nmate.main.recorded_research import TOPIC_FAILURE, recover_recorded_research
from nmate.v03 import live_review
from nmate.v03.core import CoreError, json_text
from test_unified_main import setup as shared_setup, docs, scope
from test_v03_live_review import TEA


@pytest.fixture(name="setup")
def setup_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


def rows(repo, table, where="", params=()):
    with repo.connection() as db:
        return [dict(row) for row in db.execute(f"SELECT * FROM {table} {where}", params)]


def facts(repo):
    return {table: rows(repo, table) for table in (
        "v03_current_facts", "v03_fact_assertions", "v03_fact_resolutions", "v03_entities")}


async def failed(setup, monkeypatch):
    repo, owner, _, model, provider, service, _, chat = setup
    conv = await docs(setup)
    planned = await chat.send_async(*scope(owner), TEA, [], "recover-research-plan", conv["id"],
                                   conv["intake"]["product"]["id"], paid_consent=True,
                                   task_hint="export_research", market_code="US")
    mission_id = planned["active_mission_id"]
    original = live_review.validate_research

    def false_topic_rejection(*args, **kwargs):
        raise CoreError("live_output_invalid", TOPIC_FAILURE, 502)

    monkeypatch.setattr(live_review, "validate_research", false_topic_rejection)
    service.start(*scope(owner), mission_id, "recover-research-start")
    assert await service.execute_next()
    monkeypatch.setattr(live_review, "validate_research", original)
    result = service.get(*scope(owner), mission_id)
    assert result["status"] == "failed" and result["stale_reason"] == TOPIC_FAILURE
    attempt = rows(repo, "v03_live_attempts", "WHERE mission_id=? AND kind='research'", (mission_id,))[0]
    assert attempt["state"] == "succeeded" and len(model.calls) == 3
    return mission_id, attempt


@pytest.mark.asyncio
async def test_exact_cached_result_publishes_once_and_preserves_failure_raw_ssot_and_cost(setup, monkeypatch):
    repo, owner, _, model, provider, service, _, _ = setup
    mid, attempt = await failed(setup, monkeypatch)
    ledger, ssot = rows(repo, "v03_live_attempts"), facts(repo)
    original_mission = rows(repo, "v03_missions", "WHERE id=?", (mid,))[0]
    original_tasks = rows(repo, "v03_task_attempts", "WHERE mission_id=? ORDER BY task_id,attempt", (mid,))
    original_stages = rows(repo, "v03_live_review_stages", "WHERE mission_id=?", (mid,))
    cost = provider.summary()

    results = await asyncio.gather(*[
        recover_recorded_research(service, *scope(owner), mid, attempt["id"]) for _ in range(3)])
    assert all(result["status"] == "completed_partial" and result["label"] for result in results)
    assert len(model.calls) == 3 and rows(repo, "v03_live_attempts") == ledger
    assert facts(repo) == ssot and provider.summary() == cost
    assert len(rows(repo, "v03_artifact_revisions", "WHERE mission_id=?", (mid,))) == 1
    audit = rows(repo, "main_recorded_research_recoveries")[0]
    assert audit["state"] == "completed"
    assert audit["original_request_hash"] == attempt["request_hash"]
    assert audit["original_response_sha256"] == hashlib.sha256(attempt["response_json"].encode()).hexdigest()
    saved = json.loads(audit["original_rows_json"])
    assert saved == {"mission": original_mission, "tasks": original_tasks, "stages": original_stages}
    assert not provider.recorded_only.get()


@pytest.mark.asyncio
@pytest.mark.parametrize("drift", ["request", "facts", "source", "bad_output", "sole_supplementary", "unknown_sdk", "wrong_attempt", "completed_task", "owner"])
async def test_drift_invalid_and_ambiguous_states_cannot_publish_or_dispatch(setup, monkeypatch, drift):
    repo, owner, other, model, provider, service, _, _ = setup
    mid, attempt = await failed(setup, monkeypatch)
    identity = scope(owner)
    attempt_id = attempt["id"]
    with repo.connection(write=True) as db:
        if drift == "request":
            mission = service._internal(mid)
            mission["question"] += " Câu hỏi đã đổi."
            db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(mission), mid))
        elif drift == "facts":
            ref = service._internal(mid)["context"]["fact_refs"][0]
            db.execute("UPDATE v03_current_facts SET version=version+1 WHERE entity_id=? AND field=?", (ref["entity_id"], ref["field"]))
        elif drift == "source":
            ref = service._internal(mid)["knowledge"]["source_refs"][0]
            db.execute("UPDATE v03_domain_sources SET version=version+1 WHERE id=?", (ref["source_id"],))
        elif drift == "bad_output":
            envelope = json.loads(attempt["response_json"])
            envelope["data"]["answers"][0]["citations"][0]["quote_en"] = "An invented sentence that is absent from the official source."
            db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id=?", (json_text(envelope), attempt_id))
        elif drift == "sole_supplementary":
            envelope = json.loads(attempt["response_json"])
            registration = next(item for item in envelope["data"]["answers"] if item["outcome_id"] == "registration")
            label = next(item for item in envelope["data"]["answers"] if item["outcome_id"] == "label")
            registration["citations"] = label["citations"]
            db.execute("UPDATE v03_live_attempts SET response_json=? WHERE id=?", (json_text(envelope), attempt_id))
        elif drift == "unknown_sdk":
            db.execute("UPDATE v03_live_attempts SET state='outcome_unknown' WHERE id=?", (attempt_id,))
        elif drift == "wrong_attempt":
            attempt_id = "claude_not_the_original"
        elif drift == "completed_task":
            db.execute("UPDATE v03_task_attempts SET state='succeeded',result_json='{}' WHERE mission_id=? AND task_id='registration-research'", (mid,))
        elif drift == "owner":
            identity = scope(other)
    ledger, ssot = rows(repo, "v03_live_attempts"), facts(repo)
    mission_before = rows(repo, "v03_missions", "WHERE id=?", (mid,))
    tasks_before = rows(repo, "v03_task_attempts", "WHERE mission_id=?", (mid,))
    with pytest.raises(CoreError):
        await recover_recorded_research(service, *identity, mid, attempt_id)
    assert len(model.calls) == 3 and rows(repo, "v03_live_attempts") == ledger
    assert facts(repo) == ssot and rows(repo, "v03_missions", "WHERE id=?", (mid,)) == mission_before
    assert rows(repo, "v03_task_attempts", "WHERE mission_id=?", (mid,)) == tasks_before
    assert not rows(repo, "v03_artifact_revisions", "WHERE mission_id=?", (mid,))
    assert not rows(repo, "v03_live_review_outputs", "WHERE mission_id=? AND kind='research'", (mid,))
    assert not provider.recorded_only.get()


@pytest.mark.asyncio
async def test_graph_error_removes_unpublished_output_and_restores_original_rows(setup, monkeypatch):
    repo, owner, _, model, provider, service, _, _ = setup
    mid, attempt = await failed(setup, monkeypatch)
    mission_before = rows(repo, "v03_missions", "WHERE id=?", (mid,))
    tasks_before = rows(repo, "v03_task_attempts", "WHERE mission_id=?", (mid,))
    stages_before = rows(repo, "v03_live_review_stages", "WHERE mission_id=?", (mid,))
    ledger = rows(repo, "v03_live_attempts")

    def fail_publish(*args):
        raise CoreError("unit_graph_failure", "Local graph failure")

    monkeypatch.setattr(service, "publish", fail_publish)
    with pytest.raises(CoreError, match="Local graph failure"):
        await recover_recorded_research(service, *scope(owner), mid, attempt["id"])
    assert rows(repo, "v03_missions", "WHERE id=?", (mid,)) == mission_before
    assert rows(repo, "v03_task_attempts", "WHERE mission_id=?", (mid,)) == tasks_before
    assert rows(repo, "v03_live_review_stages", "WHERE mission_id=?", (mid,)) == stages_before
    assert rows(repo, "v03_live_attempts") == ledger and len(model.calls) == 3
    assert not rows(repo, "v03_live_review_outputs", "WHERE mission_id=? AND kind='research'", (mid,))
    assert not rows(repo, "v03_artifact_revisions", "WHERE mission_id=?", (mid,))
    assert rows(repo, "main_recorded_research_recoveries")[0]["error_code"] == "unit_graph_failure"
    assert not provider.recorded_only.get()


@pytest.mark.asyncio
async def test_context_invalidated_during_graph_keeps_needs_revalidation(setup, monkeypatch):
    repo, owner, _, model, _, service, _, _ = setup
    mid, attempt = await failed(setup, monkeypatch)
    original = service._request_research

    async def invalidate_after_cache(*args):
        await original(*args)
        ref = service._internal(mid)["knowledge"]["source_refs"][0]
        with repo.connection(write=True) as db:
            db.execute("UPDATE v03_domain_sources SET version=version+1 WHERE id=?", (ref["source_id"],))

    monkeypatch.setattr(service, "_request_research", invalidate_after_cache)
    with pytest.raises(CoreError) as error:
        await recover_recorded_research(service, *scope(owner), mid, attempt["id"])
    assert error.value.code == "context_changed"
    assert service.get(*scope(owner), mid)["status"] == "needs_revalidation"
    assert len(model.calls) == 3
    assert not rows(repo, "v03_live_review_outputs", "WHERE mission_id=? AND kind='research'", (mid,))
    assert not rows(repo, "v03_artifact_revisions", "WHERE mission_id=?", (mid,))
