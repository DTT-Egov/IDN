"""Independent acceptance on installed public sources and actual mission GET.

No live provider call, grant, main DB, or source download is used. The boundary
is the owner's market-entry question and the persisted plan returned by services.
"""
from __future__ import annotations

import asyncio
import copy
import hashlib
import socket

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.core_v1.ssot import CoreSSOTService
from nmate.main.app import MainMissions
from nmate.main.provider import MainProvider
from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository, json_text
from nmate.v03.identity import LocalAccounts
from nmate.v03.install_readiness import install_readiness_pack
from nmate.v03.missions import MissionService


V7_QUESTION = ("THỬ NGHIỆM: Chị là chủ cơ sở Trà sen Quảng An ở Tây Hồ. "
    "Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TEST-TRASEN-100-001, muốn bán sang Mỹ. "
    "Chị cần biết có phải đăng ký FDA không, nhãn cần những gì, và ba việc đầu tiên chị nên làm.")


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    # Windows' asyncio loop creates an internal loopback socket pair. Permit
    # that local plumbing while every external connection stays prohibited.
    real_connect, real_connect_ex = socket.socket.connect, socket.socket.connect_ex

    def guarded(method):
        def connect(sock, address):
            if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
                return method(sock, address)
            raise AssertionError("Readiness acceptance must not use external/model transport")
        return connect

    monkeypatch.setattr(socket.socket, "connect", guarded(real_connect))
    monkeypatch.setattr(socket.socket, "connect_ex", guarded(real_connect_ex))


def snapshot(repo):
    with repo.connection() as db:
        names = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {name: hashlib.sha256(repr(sorted(tuple(row) for row in db.execute(f'SELECT * FROM "{name}"'))).encode()).hexdigest() for name in names}


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "independent-readiness.sqlite3")
    owner = LocalAccounts(repo).register("readiness-independent-owner", "Local-fixture-password-2026", "Trà Sen QA")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    product = repo.create_entity(account, enterprise, "product", "Trà sen Tây Hồ ướp bông")
    repo.propose_or_apply_facts(account, enterprise, product["id"], [
        {"field": "name", "value": "Trà sen Tây Hồ ướp bông"},
        {"field": "product_code", "value": "TEST-TRASEN-100-001"},
        {"field": "net_quantity", "value": "100 g"},
        {"field": "packaging", "value": "hộp"},
    ], product["version"], "readiness-four-facts")
    calls = []

    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("No model response may be requested")

    provider = MainProvider(repo, request_fn=forbidden)
    main = MainMissions(repo, model_call=provider)
    return repo, owner, product, main, provider, calls


def prepare(workspace, question=V7_QUESTION, product=None, operation="readiness-prepare"):
    repo, owner, original, _main, _provider, _calls = workspace
    return MissionService(repo).prepare(owner["account_id"], owner["enterprise_id"], question,
        operation, (product or original)["id"], market_code="US")


def get(workspace, mission):
    _repo, owner, _product, main, _provider, _calls = workspace
    return main.get(owner["account_id"], owner["enterprise_id"], mission["id"])


def test_v7_saved_plan_keeps_original_research_while_current_sources_explain_next_work(workspace):
    repo, _owner, _product, _main, _provider, calls = workspace
    mission = prepare(workspace)
    original = copy.deepcopy(mission)
    before_pack = get(workspace, mission)["goal_readiness"]
    pn = next(item for item in before_pack["requirements"] if item["id"] == "prior_notice")
    assert pn["status"] == "needs_source"
    assert {"exceptions", "international_mail_update"} <= set(pn["coverage"]["missing_facets"])
    install_readiness_pack(repo)
    before_get = snapshot(repo)
    result = get(workspace, mission)
    readiness = result["goal_readiness"]
    assert readiness["goal"]["basis_quote"] == V7_QUESTION
    assert result["intent"] == original["intent"]
    assert {item["id"] for item in result["intent"]["outcomes"]} == {"registration", "label"}
    assert result["context"] == original["context"] and result["answers"] == original["answers"]
    assert all(item["status"] == "reference_available" for item in readiness["requirements"])
    assert all(item["applicability"] == "not_assessed" for item in readiness["requirements"])
    assert readiness["does_not_change_saved_claude"] and readiness["does_not_determine_legal_applicability"]
    assert [item["priority"] for item in readiness["first_actions"]] == [1, 2, 3]
    assert all(item["owner_vi"] and item["deliverable_vi"] and item["source_refs"] for item in readiness["first_actions"])
    pn = next(item for item in readiness["requirements"] if item["id"] == "prior_notice")
    assert {item["facet"] for item in pn["summary_items"]} == {"submitter", "timing", "exceptions"}
    timing_vi = next(item["text_vi"] for item in pn["summary_items"] if item["facet"] == "timing")
    for text in (timing_vi, pn["answer_vi"]):
        assert "ít nhất 2 giờ" in text and "4 giờ" in text and "8 giờ" in text
        assert "Không nộp sớm hơn 30 ngày" in text and "15 ngày" in text and "PNSI" in text
        assert "Bưu gửi quốc tế nộp trước khi gửi" in text
    assert {"US_PN_SUBMITTER_20261022_V1", "US_PN_TIMING_20261022_V1", "US_PN_MAIL_UPDATE_20261022_V1"} <= {
        citation["reference_id"] for citation in pn["citations"]}
    assert not any(citation["reference_id"].startswith("FDA_PRIOR_NOTICE_") for citation in pn["citations"])
    assert all(citation["review_state"] == "reference_unreviewed" for item in readiness["requirements"] for citation in item["citations"])
    assert get(workspace, mission)["goal_readiness"] == readiness
    assert snapshot(repo) == before_get and calls == []


def test_changed_new_submitter_source_is_not_replaced_with_superseded_2011_advice(workspace):
    repo, owner, _product, _main, _provider, calls = workspace
    install_readiness_pack(repo)
    mission = prepare(workspace)
    result = get(workspace, mission)
    pn = next(item for item in result["goal_readiness"]["requirements"] if item["id"] == "prior_notice")
    who = next(c for c in pn["citations"] if c["reference_id"] == "US_PN_SUBMITTER_20261022_V1")
    DomainCatalog(repo).observe_source(owner["account_id"], owner["enterprise_id"], who["source_id"], "f" * 64, "changed-current-pn-source")
    before_get = snapshot(repo)
    current = get(workspace, mission)
    current_pn = next(item for item in current["goal_readiness"]["requirements"] if item["id"] == "prior_notice")
    assert current_pn["status"] == "needs_source" and "submitter" in current_pn["coverage"]["missing_facets"]
    assert not any(c["reference_id"] in {who["reference_id"], "FDA_PRIOR_NOTICE_SUBMITTER_VI_20261019_V1"} for c in current_pn["citations"])
    assert current["status"] == "needs_revalidation"
    assert current["context"] == mission["context"] and current["answers"] == mission["answers"]
    assert snapshot(repo) == before_get and calls == []


def test_non_tea_product_does_not_receive_the_tea_only_marking_exception(workspace):
    repo, owner, _product, _main, _provider, calls = workspace
    install_readiness_pack(repo)
    jam = repo.create_entity(owner["account_id"], owner["enterprise_id"], "product", "Mứt Sen sấy")
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], jam["id"],
        [{"field": "name", "value": "Mứt Sen sấy"}], jam["version"], "jam-name")
    mission = prepare(workspace, "Chị muốn bán Mứt Sen sấy sang Mỹ, đăng ký FDA và nhãn cần gì, ba việc đầu tiên chị nên làm?", jam, "jam-readiness")
    before_get = snapshot(repo)
    result = get(workspace, mission)["goal_readiness"]
    origin = next(item for item in result["requirements"] if item["id"] == "origin_marking")
    assert origin["coverage"]["required_facets"] == ["general_marking"]
    assert {c["reference_id"] for c in origin["citations"]} == {"US_ORIGIN_GENERAL_20261022_V1"}
    assert "trà/cà phê" not in origin["answer_vi"]
    assert "ướp trà" not in result["first_actions"][0]["deliverable_vi"]
    assert origin["applicability"] == "not_assessed"
    assert snapshot(repo) == before_get and calls == []


def test_installed_goal_references_compile_through_real_gateway_without_reservation(workspace, monkeypatch, record_property):
    repo, owner, _product, main, provider, calls = workspace
    install_readiness_pack(repo)
    mission = prepare(workspace)
    readiness = get(workspace, mission)["goal_readiness"]
    record_ids = {c["reference_id"] for item in readiness["requirements"] for c in item["citations"]}
    records = DomainCatalog(repo).lookup_domain(
        ["facility_registration", "food_label", "prior_notice", "fsvp_importer", "origin_marking"], market_code="US")["records"]
    actual = [record for record in records if record["id"] in record_ids]
    gateway = ModelGateway(repo, core=CoreSSOTService(repo), enabled=False)
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    before = snapshot(repo)
    value = adapter.compile_payload("research", {
        "instructions_vi": "Chỉ đối chiếu dữ kiện và trích đoạn công khai đã lưu.",
        "response_schema": {"type": "object", "additionalProperties": False, "properties": {"answer": {"type": "string"}}, "required": ["answer"]},
        "input": {"question": V7_QUESTION, "requested_action_count": 3,
            "supporting_requirements": [{"id": item["id"], "status": item["status"], "applicability": item["applicability"]} for item in readiness["requirements"]],
            "supporting_reference_records": actual}})
    assert {record["id"] for record in value["input"]["supporting_reference_records"]} == record_ids
    assert snapshot(repo) == before and calls == []
    # Compile-only with a small schema is insufficient: use the actual research
    # envelope builder, stop at its callback boundary BEFORE the provider, then
    # check the same full wire limit as grant selection. Never grant or reserve.
    class CapturedBeforeProvider(Exception):
        pass

    actual_payloads = []

    async def capture(kind, actual_payload, **_kwargs):
        assert kind == "research"
        actual_payloads.append(copy.deepcopy(actual_payload))
        raise CapturedBeforeProvider

    monkeypatch.setattr(main, "model_call", capture)
    internal = main._internal(mission["id"])
    # This is an offline protocol fixture, not a claim that a live check ran.
    # Runtime checks carry titles, URLs and failure reasons; an empty list can
    # conceal an oversized request that only fails after the owner clicks.
    sources = {record["source_id"]: record for record in actual}
    internal["research_provenance"] = {"network_checks": [
        {"source_id": source_id, "title": record["title"], "url": record["url"],
         "checked_at": "2026-10-22T00:50:00.000000+00:00", "state": "unavailable",
         "error_code": "authority_access_challenge", "missing_reference_ids": []}
        for source_id, record in sources.items()]}
    relevant = [record for record in internal["knowledge"]["records"] if record.get("reusable")]
    with pytest.raises(CapturedBeforeProvider):
        asyncio.run(main._request_research(internal, relevant))
    assert len(actual_payloads) == 1 and calls == []
    actual_payload = actual_payloads[0]
    actual_context = adapter.compile_payload("research", actual_payload)
    input_values = actual_context["input"]
    prompt_records = [*input_values["reference_records"], *input_values["supporting_reference_records"]]
    assert all(record["page_id"] for record in prompt_records)
    prompt_pages = {record["page_id"] for record in prompt_records}
    # A page can publish several excerpts; one canonical publisher per page
    # preserves provenance without repeating presentation metadata each time.
    publisher_pages = {record["page_id"] for record in prompt_records if record.get("publisher")}
    assert publisher_pages == prompt_pages
    check_pages = {check["source_id"] for check in input_values["source_checks"]}
    assert prompt_pages <= check_pages <= set(sources)
    assert all(check["state"] == "unavailable" for check in input_values["source_checks"])
    wire = json_text({"input": actual_context, "response_schema": actual_payload["response_schema"],
        "purpose": "legacy_research", "task_instructions_vi": actual_payload["instructions_vi"]})
    record_property("research_wire_bytes", len(wire.encode("utf-8")))
    record_property("research_wire_cap_bytes", 30000)
    record_property("source_check_count", len(input_values["source_checks"]))
    assert len(wire.encode("utf-8")) <= 30000, {
        "wire_bytes": len(wire.encode("utf-8")),
        "schema_bytes": len(json_text(actual_payload["response_schema"]).encode("utf-8")),
        "instructions_bytes": len(actual_payload["instructions_vi"].encode("utf-8")),
        "context_input_bytes_by_key": {key: len(json_text(value).encode("utf-8")) for key, value in actual_context["input"].items()},
    }
    assert provider._model("research", actual_payload) == "claude-opus-5-5"
    with pytest.raises(CoreError) as error:
        adapter._select_grant(owner["account_id"], owner["enterprise_id"], "legacy_research", "complex",
            actual_context, actual_payload["response_schema"], actual_payload["instructions_vi"])
    assert error.value.code == "BUDGET_NOT_GRANTED"
    assert snapshot(repo) == before and calls == []
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM v03_live_attempts").fetchone()[0] == 0
