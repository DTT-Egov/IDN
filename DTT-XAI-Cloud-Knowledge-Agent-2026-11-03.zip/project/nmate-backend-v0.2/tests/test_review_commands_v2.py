"""Adversarial aggregate checks beyond the independent public-flow acceptance."""
from __future__ import annotations

import copy
import json
import sqlite3
import socket

import pytest

from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso
from nmate.v03.identity import LocalAccounts
from nmate.v04.intake import IntakeService
from test_review_architecture_acceptance import by_field, confirm, pending_fields, prepare, scope
from test_v04_intake import ASSETS, QA, upload


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Local review commands must not dispatch a model or network request")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


def data_snapshot(repo):
    with repo.connection() as db:
        tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        return {table: sorted(json.dumps(dict(row), ensure_ascii=False, sort_keys=True, default=lambda value: value.hex())
                              for row in db.execute('SELECT * FROM "' + table + '"')) for table in tables}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "review-commands-v2.sqlite3")
    owner = LocalAccounts(repo).register("aggregate-owner", "Only-local-review-password", "Trà Sen QA")
    return repo, IntakeService(repo), owner


def test_competing_value_resolves_only_its_group_and_never_resurrects(setup):
    repo, service, owner = setup
    item = service.prepare(*scope(owner), "Cập nhật hồ sơ", [upload(ASSETS / "tra-sen-ho-so.xlsx"), upload(QA / "tra-sen-mau-thuan.xlsx")], "group-source")
    name = next(c for c in item["candidates"] if c["field"] == "name")
    item = service.confirm(*scope(owner), item["id"], [name["id"]], item["expected_entity_versions"], "group-name")
    quantities = [c for c in item["candidates"] if c["field"] == "net_quantity"]
    assert len(quantities) == 2
    winner, loser = quantities
    saved = service.confirm(*scope(owner), item["id"], [winner["id"]], item["expected_entity_versions"], "group-quantity",
        conflict_choices={winner["id"]: "incoming"}, expected_review_revision=item["review"]["revision"],
        expected_proposal_hashes={winner["id"]: item["review"]["proposal_hashes"][winner["id"]]})
    loser_state = next(c for c in saved["candidates"] if c["id"] == loser["id"])
    assert loser_state["decision_state"] == "superseded"
    assert loser["id"] not in saved["review"]["pending_candidate_ids"]
    assert "packaging" in pending_fields(saved)
    before = data_snapshot(repo)
    restarted = IntakeService(CoreRepository(repo.db_path))
    saved = restarted.get(*scope(owner), item["id"])
    with pytest.raises(CoreError, match="đã có quyết định"):
        restarted.confirm(*scope(owner), item["id"], [loser["id"]], saved["expected_entity_versions"], "cannot-revive-loser", conflict_choices={loser["id"]: "incoming"})
    assert data_snapshot(repo) == before


def test_owner_amendment_has_immutable_lineage_and_exact_fact_hash(setup):
    repo, service, owner = setup
    item = prepare(service, owner)
    candidate = by_field(item)["trading_name"]
    saved = confirm(service, owner, item, ["trading_name"], "amendment-evidence", edits={candidate["id"]: "Trà Sen An Nhiên"})
    with repo.connection() as db:
        rows = db.execute("SELECT * FROM core_review_proposals WHERE candidate_id=? ORDER BY proposal_revision", (candidate["id"],)).fetchall()
        assert len(rows) == 2
        assert json.loads(rows[0]["observed_json"])["value"] == "Trà sen Quảng An"
        assert json.loads(rows[1]["observed_json"])["value"] == "Trà sen Quảng An"
        assert json.loads(rows[1]["proposed_json"])["value"] == "Trà Sen An Nhiên"
        assert rows[1]["derived_from"] == rows[0]["proposal_id"]
        assert rows[1]["proposal_hash"] != rows[0]["proposal_hash"]
        fact = db.execute("SELECT source_json FROM v03_fact_assertions WHERE field='trading_name'").fetchone()
        source = json.loads(fact[0])
        assert source["review_proposal_hash"] == rows[1]["proposal_hash"]
        assert saved["latest_confirmation_receipt"]["decisions"][0]["proposal_hash"] == rows[1]["proposal_hash"]
    before = data_snapshot(repo)
    for table in ("proposals", "decisions", "command_receipts", "group_resolutions", "entity_bindings"):
        with pytest.raises(sqlite3.IntegrityError, match="immutable review record"):
            with repo.connection(write=True) as db:
                db.execute(f"DELETE FROM core_review_{table}")
    assert data_snapshot(repo) == before


def test_failure_in_live_projection_hook_rolls_back_fact_and_review(setup):
    repo, _service, owner = setup

    class FailingProjection(IntakeService):
        def _confirmation_projection(self, payload, previous):
            raise RuntimeError("projection fault in same UoW")

    service = FailingProjection(repo)
    item = prepare(service, owner)
    before = data_snapshot(repo)
    with pytest.raises(RuntimeError, match="same UoW"):
        confirm(service, owner, item, ["trading_name", "name", "product_code"], "hook-fault")
    assert data_snapshot(repo) == before


def test_operation_key_is_scoped_by_command_kind_and_receipts_stay_distinct(setup):
    repo, service, owner = setup
    item = prepare(service, owner)
    saved = confirm(service, owner, item, ["name"], "same-operation-different-kind")
    first = copy.deepcopy(saved["latest_confirmation_receipt"])
    cid = by_field(saved)["ingredients"]["id"]
    dismissed = service.dismiss_candidates(*scope(owner), item["id"], [cid], "same-operation-different-kind")
    second = dismissed["latest_confirmation_receipt"]
    assert first["command_id"] != second["command_id"]
    assert service.get_review_receipt(*scope(owner), item["id"], "same-operation-different-kind")["receipt"] == first
    assert service.get_review_receipt(*scope(owner), item["id"], "same-operation-different-kind", "dismiss_candidates")["receipt"] == second
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_memberships SET active=0 WHERE account_id=?", (owner["account_id"],))
    with pytest.raises(CoreError):
        service.get_review_receipt(*scope(owner), item["id"], "same-operation-different-kind")


def test_explicit_legacy_import_requires_exact_fact_and_resolution_evidence(setup):
    repo, service, owner = setup
    prototype = prepare(service, owner)
    entity = repo.create_entity(*scope(owner), "enterprise", "Trà Sen QA")
    stamp = now_iso()
    for suffix, saved_value, observed_value in [("match", "Tên đúng", "Tên đúng"), ("forged", "Giá trị khác", "Tên giả")]:
        intake_id, candidate_id = "legacy-" + suffix, "legacy-candidate-" + suffix
        with repo.connection() as db:
            version = repo._entity(*scope(owner), entity["id"], db)["version"]
        repo.propose_or_apply_facts(*scope(owner), entity["id"], [{"field": "trading_name", "value": saved_value,
            "source": {"intake_id": intake_id, "candidate_id": candidate_id, "owner_confirmed": True}}], version, "legacy-fact-" + suffix)
        payload = copy.deepcopy(prototype)
        payload.update(id=intake_id, status="confirmed", candidates=[{**by_field(prototype)["trading_name"], "id": candidate_id,
            "entity_id": entity["id"], "value": observed_value, "confirmed_value": observed_value, "status": "confirmed"}])
        payload.pop("review", None)
        with repo.connection(write=True) as db:
            db.execute("INSERT INTO v04_intakes VALUES(?,?,?,?,?,?,?)", (intake_id, owner["enterprise_id"], owner["account_id"], "confirmed", json_text(payload), stamp, stamp))
    before = data_snapshot(repo)
    # Constructor and GET do not backfill or repair existing documents.
    restarted = IntakeService(CoreRepository(repo.db_path))
    assert restarted.get(*scope(owner), "legacy-match")["review"]["migration_required"] is True
    assert data_snapshot(repo) == before
    assert restarted.migrate_reviews()["migrated_workspace_count"] == 2
    assert restarted.get(*scope(owner), "legacy-match")["candidates"][0]["decision_state"] == "committed"
    assert restarted.get(*scope(owner), "legacy-forged")["candidates"][0]["decision_state"] == "legacy_archived"
    after = data_snapshot(repo)
    assert restarted.migrate_reviews()["migrated_workspace_count"] == 0
    assert data_snapshot(repo) == after
    for table in before:
        if not table.startswith("core_review_"):
            assert before[table] == after[table]


def test_new_owner_statement_creates_next_generation_without_reopening_kept_value(setup):
    repo, service, owner = setup
    item = prepare(service, owner)
    quantity = by_field(item)["net_quantity"]
    item = confirm(service, owner, item, ["name", "net_quantity"], "initial-amended-quantity", edits={quantity["id"]: "120 g"})
    update = "Cập nhật hồ sơ: khối lượng tịnh: 100 g"
    item = service.clarify(*scope(owner), item["id"], update, "new-observation-before-keep")
    pending = [c for c in item["candidates"] if c["field"] == "net_quantity" and c["decision_state"] == "pending"]
    assert len(pending) == 1
    candidate = pending[0]
    item = service.confirm(*scope(owner), item["id"], [candidate["id"]], item["expected_entity_versions"], "keep-current-120",
        conflict_choices={candidate["id"]: "current"})
    assert candidate["id"] not in item["review"]["pending_candidate_ids"]
    before_count = len(item["candidates"])
    item = service.clarify(*scope(owner), item["id"], update, "same-message-after-keep")
    assert len(item["candidates"]) == before_count
    # Recovery/replay of an existing source is never a new owner command.
    with repo.connection(write=True) as db:
        cached = service._owned(*scope(owner), item["id"], db)
        assert service._append_text_observations(*scope(owner), cached, "Khối lượng tịnh: 100 g theo ảnh cũ", db) == []
    fresh = "Chị đổi khối lượng tịnh: 100 g theo nhãn mới vừa kiểm tra"
    item = service.clarify(*scope(owner), item["id"], fresh, "fresh-owner-declaration")
    remaining = [c for c in item["candidates"] if c["field"] == "net_quantity" and c["decision_state"] == "pending"]
    assert len(remaining) == 1 and remaining[0]["id"] != candidate["id"]
    assert remaining[0]["derived_from_candidate_id"] == candidate["id"]
    assert next(c for c in item["candidates"] if c["id"] == candidate["id"])["decision_state"] == "kept_current"
    with repo.connection() as db:
        proposals = db.execute("SELECT candidate_id,group_id,generation,derived_from FROM core_review_proposals WHERE candidate_id IN (?,?)",
            (candidate["id"], remaining[0]["id"])).fetchall()
        older = next(p for p in proposals if p["candidate_id"] == candidate["id"])
        newer = next(p for p in proposals if p["candidate_id"] == remaining[0]["id"])
        assert older["group_id"] == newer["group_id"]
        assert newer["generation"] == older["generation"] + 1
        assert newer["derived_from"] == candidate["proposal_id"]
    item = service.confirm(*scope(owner), item["id"], [remaining[0]["id"]], item["expected_entity_versions"], "apply-fresh-owner-value",
        conflict_choices={remaining[0]["id"]: "incoming"})
    product = next(e for e in item["saved_context"]["entities"] if e["entity_type"] == "product")
    assert product["values"]["net_quantity"] == "100 g"


def test_replaying_old_command_keeps_receipt_separate_from_latest_state(setup):
    repo, service, owner = setup
    original = prepare(service, owner)
    first = confirm(service, owner, original, ["trading_name"], "replay-history-first")
    old_receipt = copy.deepcopy(first["latest_confirmation_receipt"])
    second = confirm(service, owner, first, ["name", "product_code"], "replay-history-second")
    latest_receipt = copy.deepcopy(second["latest_confirmation_receipt"])
    before = data_snapshot(repo)
    replay = confirm(service, owner, original, ["trading_name"], "replay-history-first")
    assert replay["confirmation_receipt"] == old_receipt
    assert replay["latest_confirmation_receipt"] == latest_receipt
    assert replay["review"]["revision"] == second["review"]["revision"]
    assert pending_fields(replay) == {"net_quantity", "packaging", "ingredients"}
    assert data_snapshot(repo) == before
