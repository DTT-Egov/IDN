"""Registered official policy source hosts can resolve; private/public bypasses cannot."""
import socket

import pytest

from nmate.main.local import network_guard


def test_policy_sources_use_same_official_domains_and_global_ip_guard(monkeypatch):
    looked_up = []

    def lookup(host, *args, **kwargs):
        looked_up.append(host)
        address = "127.0.0.2" if host.startswith("private.") else "8.8.8.8"
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, 443))]

    monkeypatch.setattr(socket, "getaddrinfo", lookup)
    # The guard replaces these methods itself; register restoration with pytest.
    monkeypatch.setattr(socket.socket, "connect", socket.socket.connect)
    monkeypatch.setattr(socket.socket, "connect_ex", socket.socket.connect_ex)
    counts = network_guard()
    socket.getaddrinfo("vanban.chinhphu.vn", 443)
    socket.getaddrinfo("data.hanoi.gov.vn", 443)
    with pytest.raises(OSError):
        socket.getaddrinfo("private.hanoi.gov.vn", 443)
    with pytest.raises(OSError):
        socket.getaddrinfo("hanoi.gov.vn.attacker.test", 443)
    assert looked_up == ["vanban.chinhphu.vn", "data.hanoi.gov.vn", "private.hanoi.gov.vn"]
    assert counts["blocked_network_attempts"] == 2
