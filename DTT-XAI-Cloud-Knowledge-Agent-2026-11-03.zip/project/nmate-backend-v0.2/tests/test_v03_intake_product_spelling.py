"""Cosmetic model spelling cannot discard a paid intake or rewrite user data."""
import copy
import unicodedata

import pytest

from nmate.v03.core import CoreError
from nmate.v03.live_review import validate_intake
from test_v03_live_review import TEA, intake


@pytest.mark.parametrize("model_name", [
    "trà sen tây hồ", "TRÀ SEN TÂY HỒ", "Trà  Sen\tTây Hồ",
    unicodedata.normalize("NFD", "Trà Sen Tây Hồ"),
])
def test_cosmetic_model_name_uses_exact_user_quote_and_leaves_raw_envelope_immutable(model_name):
    data = intake()
    data["product_name"] = model_name
    envelope = {"data": data, "attempt_id": "already-paid-recorded-result"}
    original = copy.deepcopy(envelope)
    parsed = validate_intake(envelope, TEA)
    assert parsed.product_name == parsed.product_quote == "Trà Sen Tây Hồ"
    assert envelope == original and envelope["data"]["product_name"] == model_name


@pytest.mark.parametrize("model_name", ["Trà Sen Tây Hồ Cao Cấp", "Mứt Sen Tây Hồ", "Tra Sen Tay Ho", "Trà Sen"])
def test_identity_normalization_does_not_accept_different_longer_shorter_or_accentless_name(model_name):
    data = intake()
    data["product_name"] = model_name
    with pytest.raises(CoreError):
        validate_intake({"data": data}, TEA)


def test_model_quote_itself_must_still_be_verbatim_even_if_identity_matches():
    data = intake()
    data.update(product_name="trà sen tây hồ", product_quote="trà sen tây hồ")
    with pytest.raises(CoreError):
        validate_intake({"data": data}, TEA)


def test_empty_name_and_empty_quote_are_not_a_product_observation():
    data = intake()
    data.update(product_name="", product_quote="")
    with pytest.raises(CoreError):
        validate_intake({"data": data}, TEA)


def test_lowercase_user_quote_is_kept_when_model_capitalizes_its_derived_name():
    text = "Chị có mứt sen sấy, cần đăng ký cơ sở FDA và nhãn tiếng Anh cho Mỹ."
    data = intake()
    data.update(product_name="Mứt Sen Sấy", product_quote="mứt sen sấy")
    parsed = validate_intake({"data": data}, text)
    assert parsed.product_name == parsed.product_quote == "mứt sen sấy"
