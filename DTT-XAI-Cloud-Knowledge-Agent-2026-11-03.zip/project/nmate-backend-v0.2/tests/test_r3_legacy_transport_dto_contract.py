"""DF-002: closed legacy transport DTOs do not broaden canonical SSOT types."""
import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.v03.core import CoreError
from nmate.v03.domain_validation import validate_field_value


@pytest.mark.parametrize("field,value", [
    ("responsible_business", {"name": "Trà Sen", "address": "Hà Nội", "role": "Nhà sản xuất"}),
    ("nutrition_information", {"energy_kcal": 100, "protein_g": 2.5, "serving_size": "100 g"}),
])
def test_existing_closed_transport_objects_are_not_scalar_ssot_values(field, value):
    GovernedLegacyAdapter._business_value(field, value)
    assert validate_field_value(field, value) is not None


@pytest.mark.parametrize("field,value", [
    ("name", {"amount": 123, "currency": "USD"}),
    ("packaging", {"name": "Trà Sen"}),
    ("responsible_business", {"name": {"amount": 123}}),
    ("responsible_business", {"name": "Trà Sen", "balance": 123}),
    ("responsible_business", {"name": "Trà Sen", "address": ["Hà Nội"]}),
    ("nutrition_information", {"amount": 123, "currency": "USD"}),
    ("nutrition_information", {"energy_kcal": {"amount": 123}}),
    ("nutrition_information", {"energy_kcal": True}),
    ("nutrition_information", {"energy_kcal": float("inf")}),
    ("nutrition_information", {"energy_kcal": -1}),
    ("nutrition_information", {"energy_kcal": 1000001}),
    ("nutrition_information", {"serving_size": "x" * 101}),
    ("ingredients", [{"amount": 123, "currency": "USD"}]),
])
def test_adapter_closed_shapes_do_not_accept_money_nested_or_arbitrary_objects(field, value):
    with pytest.raises(CoreError) as error:
        GovernedLegacyAdapter._business_value(field, value)
    assert error.value.code == "BUSINESS_VALUE_TYPE_UNSUPPORTED"


@pytest.mark.parametrize("field,value", [("net_quantity", "one hundred abc"), ("name.alternate", "x" * 251),
                                        ("product_code", "not a code / 123")])
def test_shape_valid_scalar_still_uses_shared_registry_validation(field, value):
    with pytest.raises(CoreError):
        GovernedLegacyAdapter._business_value(field, value)
