"""Real existing sessions, CSRF and actual MCP; no paid/network dispatch."""
from datetime import date
import pytest
from fastapi import FastAPI
from httpx import ASGITransport,AsyncClient
from nmate.v03.identity import LocalAccounts
from nmate.knowledge_v1.host import attach_workbench
from nmate.core_v1.gateway import ModelGateway
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_governance import governed
from test_knowledge_m4_serving import serving,release

@pytest.mark.asyncio
async def test_host_session_csrf_scoped_expert_and_revocation(serving):
    repo,_,s,author,expert,page,customer,_=serving
    app=FastAPI();app.state.accounts=LocalAccounts(repo)
    attach_workbench(app,s,ModelGateway(repo,enabled=False),cookie_namespace='m4')
    session=app.state.accounts.create_session(expert)
    request=dict(tool='knowledge_wiki_workbench',arguments={'page_id':page['page_id']})
    async with AsyncClient(transport=ASGITransport(app=app),base_url='http://test') as c:
        assert (await c.get('/knowledge/session')).status_code==401
        c.cookies.set('m4_session',session['token']);c.cookies.set('m4_csrf',session['csrf_token'])
        identity=(await c.get('/knowledge/session')).json()
        assert identity['account_id']==expert and identity['csrf_token']==session['csrf_token']
        assert (await c.post('/knowledge/rpc',json=request)).status_code==403
        response=await c.post('/knowledge/rpc',json=request,headers={'X-CSRF-Token':session['csrf_token'],'Origin':'http://test'})
        assert response.status_code==200 and response.json()['data']['candidate']['page_id']==page['page_id']
        assert response.json()['_scope_actor_id']==expert and response.headers['cache-control']=='no-store'
        # An ordinary owner cannot borrow expert authority via body/cookie names.
        ordinary=app.state.accounts.create_session(customer['account_id']);c.cookies.set('m4_session',ordinary['token'])
        assert (await c.get('/knowledge/session')).status_code==403
        assert (await c.post('/knowledge/rpc',json=request,headers={'X-CSRF-Token':ordinary['csrf_token']})).status_code==403
        c.cookies.set('m4_session',session['token'])
        app.state.accounts.logout(session['token'])
        assert (await c.get('/knowledge/session')).status_code==401

@pytest.mark.asyncio
async def test_actual_mcp_serving_read_has_no_private_scope_or_provider(serving):
    from mcp import Client
    from nmate.v03.mcp import create_mcp,account_context
    from nmate.knowledge_v1.mcp_m4 import register_tools,NAMES
    repo,_,s,_,_,page,customer,_=serving;release(serving)
    server=create_mcp(repo,None,extra_register=lambda server,call:register_tools(server,s,call),tool_allowlist=NAMES)
    token=account_context.set(customer['account_id'])
    with repo.connection() as db:before=list(db.iterdump())
    try:
        async with Client(server,mode='2026-07-28',cache=None) as client:
            definitions=await client.list_tools();assert {t.name for t in definitions.tools}==NAMES
            result=await client.call_tool('knowledge_public_lookup',{'goals':['workforce_training','market_development'],'target_date':date.today().isoformat()})
            value=result.structured_content
            assert value['ok'] and value['data'][0]['wiki_revision_refs'][0]['revision_id']==page['revision_id']
            assert value['data'][1]['wiki_revision_refs']==[] and customer['enterprise_id'] not in str(value)
    finally:account_context.reset(token)
    with repo.connection() as db:assert list(db.iterdump())==before

@pytest.mark.asyncio
async def test_full_main_host_composition_and_original_mcp_boundary(tmp_path):
    from serve_knowledge_m4_fixture import build
    app=build(tmp_path/'composed-main',port=8039)
    with app.state.repo.connection() as db:
        author=db.execute("SELECT id FROM v03_accounts WHERE username='kb_author'").fetchone()[0]
        page=db.execute('SELECT page_id FROM kp_page_contracts LIMIT 1').fetchone()[0]
    session=app.state.accounts.create_session(author)
    async with AsyncClient(transport=ASGITransport(app=app),base_url='http://127.0.0.1:8039') as client:
        assert (await client.get('/knowledge/')).status_code==200
        denied=await client.get('/knowledge/session')
        assert denied.status_code==401 and denied.json()['error']['code']=='unauthenticated'
        client.cookies.set('nmate_m4_qa_session',session['token']);client.cookies.set('nmate_m4_qa_csrf',session['csrf_token'])
        identity=await client.get('/knowledge/session')
        assert identity.status_code==200 and identity.json()['account_id']==author
        request=dict(tool='knowledge_wiki_workbench',arguments={'page_id':page})
        assert (await client.post('/knowledge/rpc',json=request)).status_code==403
        result=await client.post('/knowledge/rpc',json=request,headers={'X-CSRF-Token':session['csrf_token'],'Origin':'http://127.0.0.1:8039'})
        assert result.status_code==200 and result.json()['data']['candidate']['page_id']==page
        # Session cookies never become raw MCP bearer credentials.
        assert (await client.post('/mcp',json={})).status_code==401
        status=await client.get('/api/main/status')
        assert status.status_code==200 and status.json()['provider_attempts']==0
        app.state.accounts.logout(session['token'])
        assert (await client.get('/knowledge/session')).status_code==401
