"""M4 public serving uses actual release/source gates, no expert impersonation.

Synthetic legal assertions only. DF-024/027/029/033/046/049/056/059.
"""
from datetime import date,datetime,timedelta,timezone
import pytest
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe,acquire
from test_knowledge_m3_governance import governed,attest,review
from nmate.v03.identity import LocalAccounts
from nmate.v03.core import CoreError
from nmate.knowledge_v1.operator_m4 import install_m4_on_clone
from nmate.knowledge_v1.serving import PublishedKnowledge

@pytest.fixture
def serving(governed,tmp_path):
    repo,g,author,expert,page=governed
    install_m4_on_clone(repo.db_path,backup_path=tmp_path/'before-m4.sqlite')
    customer=LocalAccounts(repo).register('TEST-customer','Synthetic-password-789','THỬ NGHIỆM Trà Sen')
    s=PublishedKnowledge(repo)
    payload=dict(goal_types=['workforce_training'],jurisdiction='VN-HN',usable_for=['explain_public_policy'],
                 valid_from='2026-01-01',valid_until=None)
    return repo,g,s,author,expert,page,customer,payload

def release(serving):
    _,g,s,author,expert,page,_,payload=serving
    from nmate.policy_v1.catalog import KnowledgeCatalog
    KnowledgeCatalog(g.repo).record_source_check(author,'KB-TEST-A',result='verified_current',
      current_until=(datetime.now(timezone.utc)+timedelta(hours=8)).isoformat(),rationale='SYNTHETIC post-migration source control check')
    s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-test')
    attest((g.repo,g,author,expert,page));r=review((g.repo,g,author,expert,page))
    return g.publish_wiki(expert,page['page_id'],revision_id=page['revision_id'],review_event_id=r['review_event_id'],
      expected_manifest_hash=r['review_manifest_hash'],rationale='SYNTHETIC ONLY',operation_id='release-m4-test')

def lookup(serving,goal='workforce_training',**extra):
    _,_,s,_,_,_,customer,_=serving
    return s.lookup(customer['account_id'],goals=[goal],target_date=date.today().isoformat(),**extra)

def test_customer_gets_only_released_matching_goal_never_draft_or_expert_identity(serving):
    repo,g,s,author,expert,page,customer,payload=serving
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    with pytest.raises(CoreError):g.get_candidate(customer['account_id'],page['page_id'])
    release(serving)
    bundle=lookup(serving)[0]
    assert bundle['schema_version']=='policy-evidence-bundle/2'
    assert bundle['decision']=='public_explanation_available' and bundle['assessment_eligible'] is False
    assert bundle['wiki_revision_refs'][0]['revision_id']==page['revision_id']
    assert lookup(serving,'market_development')[0]['wiki_revision_refs']==[]
    assert 'created_by' not in str(bundle) and 'password' not in str(bundle)
    with repo.connection() as db:
        assert not db.execute('SELECT 1 FROM pol_wiki_capabilities WHERE account_id=?',(customer['account_id'],)).fetchone()

def test_mapping_after_review_invalidates_prior_approval(serving):
    _,g,s,author,expert,page,_,payload=serving
    attest((g.repo,g,author,expert,page));r=review((g.repo,g,author,expert,page))
    s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='late-binding')
    with pytest.raises(CoreError):g.publish_wiki(expert,page['page_id'],revision_id=page['revision_id'],
      review_event_id=r['review_event_id'],expected_manifest_hash=r['review_manifest_hash'],rationale='old review',operation_id='wrong-release')

def test_read_history_survives_withdraw_but_new_use_does_not(serving):
    _,g,s,_,expert,page,customer,_=serving
    r=release(serving);ref=lookup(serving)[0]['wiki_revision_refs'][0]
    g.withdraw_wiki(expert,page['page_id'],expected_release_id=r['release_event_id'],rationale='TEST withdraw',operation_id='withdraw-m4')
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    assert s.read_reference(customer['account_id'],ref,mode='history')['body']==page['body']
    with pytest.raises(CoreError):s.read_reference(customer['account_id'],ref,mode='current')

def test_export_revoke_keeps_read_but_read_revoke_blocks_even_owner(serving):
    _,g,s,author,_,page,customer,_=serving
    release(serving);ref=lookup(serving)[0]['wiki_revision_refs'][0]
    g.set_source_rights(author,'KB-TEST-A',expected_version=1,allow_read=True,allow_export=False,reason='TEST export stop',operation_id='export-stop-m4')
    assert s.read_reference(customer['account_id'],ref,mode='history')['body']==page['body']
    with pytest.raises(CoreError):s.read_reference(customer['account_id'],ref,mode='current',export=True)
    g.set_source_rights(author,'KB-TEST-A',expected_version=2,allow_read=False,allow_export=False,reason='TEST read stop',operation_id='read-stop-m4')
    with pytest.raises(CoreError):s.read_reference(author,ref,mode='history')
    assert lookup(serving)[0]['wiki_revision_refs']==[]

def test_changed_source_does_not_serve_stale_release_and_history_does_not_rewrite(serving):
    _,g,s,author,expert,page,customer,_=serving
    release(serving);ref=lookup(serving)[0]['wiki_revision_refs'][0]
    acquire((g.repo,g,author,expert),raw=b'TEST changed source with exception',version=3,operation='changed-m4')
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    assert s.read_reference(customer['account_id'],ref,mode='history')['body']==page['body']

def test_new_draft_does_not_leak_while_published_revision_history_remains(serving):
    _,g,s,author,_,page,customer,_=serving
    release(serving);ref=lookup(serving)[0]['wiki_revision_refs'][0]
    g.edit_candidate(author,page['page_id'],expected_version=1,expected_revision_id=page['revision_id'],title='PRIVATE DRAFT TITLE',
      body=page['body'],claims=page['claims'],aliases=[],links=[],operation_id='edit-private-m4')
    bundles=lookup(serving)
    assert bundles[0]['wiki_revision_refs']==[] and 'PRIVATE' not in str(bundles)
    with pytest.raises(CoreError):g.get_candidate(customer['account_id'],page['page_id'])
    assert s.read_reference(customer['account_id'],ref,mode='history')['title']=='TEST ONLY'

def test_multi_goal_keeps_answered_and_gap_separate_without_private_context(serving):
    repo,_,s,_,_,_,customer,_=serving
    release(serving)
    with repo.connection() as db:before=list(db.iterdump())
    bundles=s.lookup(customer['account_id'],goals=['market_development','workforce_training'],target_date=date.today().isoformat())
    assert [b['outcome_id'] for b in bundles]==['market_development','workforce_training']
    assert [b['decision'] for b in bundles]==['source_incomplete','public_explanation_available']
    assert all('context_manifest_ref' not in b and customer['enterprise_id'] not in str(b) for b in bundles)
    with repo.connection() as db:assert list(db.iterdump())==before

@pytest.mark.parametrize('change',['upstream_snapshot','upstream_unavailable'])
def test_legacy_source_change_invalidates_public_serving_without_rewriting_history(serving,change):
    from nmate.policy_v1.catalog import KnowledgeCatalog
    _,g,s,author,_,page,user,_=serving;release(serving)
    ref=lookup(serving)[0]['wiki_revision_refs'][0];catalog=KnowledgeCatalog(g.repo)
    if change=='upstream_snapshot':
        text='THỬ NGHIỆM: nguồn gốc đã có ngoại lệ mới.'
        catalog.add_snapshot(author,'KB-TEST-A',text.encode(),text)
    else:catalog.record_source_check(author,'KB-TEST-A',result='unavailable',rationale='THỬ NGHIỆM: lỗi mạng, không sửa bản lưu')
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    assert s.read_reference(user['account_id'],ref,mode='history')['body']==page['body']

@pytest.mark.parametrize('change',[{'goal_types':['FDA']},{'usable_for':['eligibility_conclusion']},{'jurisdiction':'US'},
                                 {'valid_from':'not-date'},{'valid_until':'2025-01-01'}])
def test_binding_rejects_unsupported_scope_not_just_prompt(serving,change):
    _,_,s,author,_,page,_,payload=serving
    with pytest.raises(CoreError):s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload|change,operation_id='bad-mapping')

def test_binding_exact_replay_after_writer_revoke_but_no_new_write(serving):
    repo,g,s,author,_,page,_,payload=serving
    first=s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-replay')
    with repo.connection(write=True) as db:db.execute("UPDATE pol_knowledge_roles SET revoked_at='TEST revoked' WHERE account_id=?",(author,))
    assert s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-replay')==first
    with pytest.raises(CoreError):s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='different-new-write')

def test_binding_atomic_and_immutable_never_cross_page_or_stale_revision(serving):
    repo,g,s,author,_,page,_,payload=serving
    another=g.create_candidate(author,policy_id=page['policy_id'],title='TEST second',body=page['body'],claims=page['claims'],aliases=[],links=[],operation_id='second-wiki')
    with pytest.raises(CoreError):s.bind_applicability(author,page['page_id'],revision_id=another['revision_id'],payload=payload,operation_id='wrong-page')
    with repo.connection() as db:before=list(db.iterdump())
    def crash(point):
        if point=='before_receipt':raise RuntimeError('TEST crash')
    s.fault_hook=crash
    with pytest.raises(RuntimeError):s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='crash-scope')
    with repo.connection() as db:assert list(db.iterdump())==before
    s.fault_hook=None
    s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-once')
    with pytest.raises(CoreError):s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='bind-twice')
    g.edit_candidate(author,page['page_id'],expected_version=1,expected_revision_id=page['revision_id'],title='TEST new revision',body=page['body'],claims=page['claims'],aliases=[],links=[],operation_id='new-head-for-scope')
    with pytest.raises(CoreError):s.bind_applicability(author,page['page_id'],revision_id=page['revision_id'],payload=payload,operation_id='old-head-scope')

@pytest.mark.parametrize('key,value',[('body_hash','0'*64),('review_event_id','foreign-review'),('goal','market_development'),('target_date','2025-01-01')])
def test_typed_reference_cannot_mix_released_proof_or_scope(serving,key,value):
    _,_,s,_,_,_,user,_=serving;release(serving)
    ref=lookup(serving)[0]['wiki_revision_refs'][0]
    with pytest.raises(CoreError):s.read_reference(user['account_id'],ref|{key:value},mode='history')

def test_history_citation_keeps_recorded_language_and_url_identity_cannot_change_silently(serving):
    _,g,s,author,_,_,user,_=serving;release(serving)
    ref=lookup(serving)[0]['wiki_revision_refs'][0];old=s.read_reference(user['account_id'],ref)
    m=g.source_manifest(author,'KB-TEST-A')['manifest']
    # The original URL-change precondition was invalid: M2 already refuses a
    # silent identity change. Keep that negative proof; exercise the actual
    # permitted metadata path (language), rather than bypassing its guard.
    with pytest.raises(CoreError):g.configure_source(author,'KB-TEST-A',expected_version=3,
        manifest=m|{'url':'https://hanoi.gov.vn/test-only/new-address'},operation_id='refuse-silent-url')
    g.configure_source(author,'KB-TEST-A',expected_version=3,manifest=m|{'language':'en'},operation_id='change-manifest-language')
    assert lookup(serving)[0]['wiki_revision_refs']==[]
    assert s.read_reference(user['account_id'],ref)['citations']==old['citations']

def test_successful_operational_check_does_not_forge_new_legal_revision(serving):
    from nmate.policy_v1.catalog import KnowledgeCatalog
    repo,g,s,author,_,page,_,_=serving;release(serving)
    before=lookup(serving)[0]['wiki_revision_refs']
    KnowledgeCatalog(repo).record_source_check(author,'KB-TEST-A',result='verified_current',
        current_until=(datetime.now(timezone.utc)+timedelta(hours=8)).isoformat(),rationale='TEST successful check, same content')
    assert lookup(serving)[0]['wiki_revision_refs']==before
