"""DF-029: old opaque selected-product lineage cannot bypass archive READ."""
import asyncio
from copy import deepcopy
import json

import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.main.app import MainMissions
from nmate.main.conversations import MainIntakeService, MainConversationService
from nmate.main.provider import MainProvider
from nmate.main.recorded_analysis import project_recorded_export_intake
from nmate.v03.core import CoreError, json_text, now_iso
from test_r3_export_intake_cache_contracts import gateway_workspace, payload, registration_only
from test_review_commands_v2 import data_snapshot


@pytest.fixture
def archived(tmp_path, monkeypatch, request):
    repo, core, _finance, gateway, _grant, resource, calls, _manifests = gateway_workspace.__wrapped__(tmp_path)
    mode = getattr(request, "param", "opaque_shared")
    if mode == "opaque_owned":
        resource = repo.create_entity("owner", "enterprise", "product", "Trà Sen")["id"]
    if mode == "opaque_document_staff":
        resource = "whole-private-document"
        with repo.connection(write=True) as db:
            db.execute("INSERT INTO core_v1_resources VALUES(?,?,'document',?,1,?)",
                       ("enterprise", resource, "owner", now_iso()))
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native transport"))
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    provider.governed_adapter = adapter
    missions = MainMissions(repo, model_call=provider)
    MainConversationService(MainIntakeService(repo, provider=provider, missions=missions))
    body = payload(["registration"], resource)
    output = {**registration_only(), "product_name": "Trà Sen", "product_quote": "Trà Sen"}

    async def transport(model, actual_body, limit):
        calls.append((model, deepcopy(actual_body), limit))
        return {"text": json_text(output), "model": model, "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    gateway.request_fn = transport
    # Create with the actual old dependency projector, never rewriting an
    # accepted receipt or its signed manifest to manufacture the old defect.
    with monkeypatch.context() as old:
        if mode != "sealed_shared":
            old.setattr(adapter, "_resource_dependencies", lambda _context: [{"resource_id": resource, "fields": []}])
        asyncio.run(provider("intake", body, operation_id="archive-old-selected", account_id="owner", enterprise_id="enterprise"))
    stamp, chat = now_iso(), "opaque-selected-product-archive"
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v04_conversations VALUES(?,?,?,?,?,?)", (chat, "enterprise", "owner", json_text({"id": chat}), stamp, stamp))
        db.execute("INSERT INTO main_operations VALUES(?,?,?,?,?,?,'failed','live_output_invalid',?)",
                   ("owner", "enterprise", "archive-old-selected", "old-main-hash", chat, "export_research", stamp))
        if mode == "opaque_document_staff":
            db.execute("UPDATE v03_memberships SET role='staff' WHERE account_id='owner' AND enterprise_id='enterprise'")
    return repo, core, adapter, resource, calls, chat


def test_archive_with_opaque_product_name_lineage_checks_current_name_read(archived):
    repo, core, adapter, resource, calls, chat = archived

    def project():
        return project_recorded_export_intake(repo, "owner", "enterprise", chat,
                                              authorize_envelope=adapter.authorize_recorded_envelope)
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as unresolved:
        project()
    assert unresolved.value.code == "RECORDED_FIELD_LINEAGE_INCOMPLETE"
    assert data_snapshot(repo) == before
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as denied:
        project()
    assert denied.value.code == "RECORDED_FIELD_LINEAGE_INCOMPLETE"
    assert data_snapshot(repo) == before and len(calls) == 1


@pytest.mark.parametrize("archived", ["opaque_owned"], indirect=True)
def test_intrinsic_owner_can_read_opaque_archive_but_global_revoke_still_denies(archived):
    repo, _core, adapter, resource, calls, chat = archived

    def project():
        return project_recorded_export_intake(repo, "owner", "enterprise", chat,
                                              authorize_envelope=adapter.authorize_recorded_envelope)
    before = data_snapshot(repo)
    assert project()["reported_product_name"] == "Trà Sen"
    assert data_snapshot(repo) == before
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (resource,))
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as denied:
        project()
    assert denied.value.code == "forbidden"
    assert data_snapshot(repo) == before and len(calls) == 1


@pytest.mark.parametrize("archived", ["sealed_shared"], indirect=True)
def test_new_complete_field_lineage_keeps_legal_shared_archive_read(archived):
    repo, core, adapter, resource, calls, chat = archived

    def project():
        return project_recorded_export_intake(repo, "owner", "enterprise", chat,
                                              authorize_envelope=adapter.authorize_recorded_envelope)
    before = data_snapshot(repo)
    assert project()["reported_product_name"] == "Trà Sen"
    assert data_snapshot(repo) == before
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as denied:
        project()
    assert denied.value.code == "forbidden"
    assert data_snapshot(repo) == before and len(calls) == 1


@pytest.mark.parametrize("archived", ["opaque_document_staff"], indirect=True)
def test_whole_resource_document_creator_receipt_read_does_not_require_owner_role(archived):
    repo, _core, adapter, _resource, calls, _chat = archived
    before = data_snapshot(repo)
    with repo.connection() as db:
        envelope = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id='archive-old-selected'").fetchone()[0])
    # The archive application is owner-only. This countercase exercises the
    # existing broader whole-document receipt contract at its real adapter.
    assert adapter.authorize_recorded_envelope("owner", "enterprise", envelope,
                                               require_complete_lineage=True) == envelope
    assert data_snapshot(repo) == before and len(calls) == 1


@pytest.mark.parametrize("archived", ["opaque_owned"], indirect=True)
def test_archive_lifecycle_keeps_intrinsic_read_without_adding_ai_authority(archived):
    repo, _core, adapter, resource, calls, chat = archived
    entity = repo.get_entity("owner", "enterprise", resource)
    repo.archive_entity("owner", "enterprise", resource, entity["version"], "archive-product-no-revoke")
    before = data_snapshot(repo)
    view = project_recorded_export_intake(repo, "owner", "enterprise", chat,
                                         authorize_envelope=adapter.authorize_recorded_envelope)
    assert view["reported_product_name"] == "Trà Sen" and not view["can_start_research"]
    assert data_snapshot(repo) == before and len(calls) == 1


@pytest.mark.parametrize("archived", ["opaque_owned"], indirect=True)
def test_explicit_read_revoke_does_not_get_opaque_owner_shortcut(archived):
    repo, core, adapter, resource, calls, chat = archived
    core.grant_resource("owner", "enterprise", resource, "owner", ["read"], ["name"])
    core.revoke_resource("owner", "enterprise", resource, "owner", ["read"], ["name"])
    before = data_snapshot(repo)
    with pytest.raises(CoreError) as denied:
        project_recorded_export_intake(repo, "owner", "enterprise", chat,
                                       authorize_envelope=adapter.authorize_recorded_envelope)
    assert denied.value.code == "RECORDED_FIELD_LINEAGE_INCOMPLETE"
    assert data_snapshot(repo) == before and len(calls) == 1
