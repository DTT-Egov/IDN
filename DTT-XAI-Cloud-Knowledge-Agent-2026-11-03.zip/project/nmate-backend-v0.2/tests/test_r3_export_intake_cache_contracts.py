"""DF-034: export intake's dynamic schema/input must replay whole old contracts."""
import asyncio
from copy import deepcopy
import json
from pathlib import Path

import pytest

from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.main.provider import MainProvider
from nmate.main.app import MainMissions
from nmate.v03.core import CoreError, json_text
from nmate.v03.export_intake_contracts import (build_export_intake_payload, historic_export_intake_payloads,
                                               _build_payload, static_contract)
from nmate.v03.live_review import IntakeOutput, selected_product_projection
from nmate.v03.markets import get_market
from test_design_gateway_invariants import workspace as private_workspace
from test_review_commands_v2 import data_snapshot
from test_unified_main import setup as private_main_workspace, scope
from test_v03_live_review import research


FROZEN = json.loads((Path(__file__).parent / "fixtures/export_intake_contract_before_comma_20261022.json").read_text(encoding="utf-8"))
QUESTION = "Chị muốn xuất khẩu sang Mỹ, cần đăng ký FDA, thông báo trước lô hàng, nhãn và ba việc đầu tiên."


def payload(outcomes, resource=None):
    schema = deepcopy(FROZEN["base_schema"])
    schema["$defs"]["IntakeOutcome"]["properties"]["id"]["enum"] = list(outcomes)
    schema["properties"]["outcomes"].update(minItems=len(outcomes), maxItems=len(outcomes))
    return {"instructions_vi": FROZEN["instructions_vi"], "response_schema": schema,
            "input": {"question": QUESTION,
                      "selected_product": {"entity_id": resource, "values": {"name": "Trà Sen"}} if resource else None,
                      "allowed_outcomes": list(outcomes), "outcome_semantics_vi": FROZEN["outcome_semantics_vi"],
                      "previous_mission_context": None, "resolved_market": get_market("US")}}


@pytest.fixture
def gateway_workspace(tmp_path):
    case = private_workspace.__wrapped__(tmp_path)

    async def recorded_transport(model, body, limit):
        case[6].append((model, deepcopy(body), limit))
        return {"text": json_text(registration_only()), "model": model, "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    case[3].request_fn = recorded_transport
    return case


@pytest.fixture
def main_workspace(tmp_path):
    return private_main_workspace.__wrapped__(tmp_path)


def registration_only():
    return {"scope": "us_food", "outcomes": [{"id": "registration", "question_quote": "đăng ký FDA"}],
            "product_name": None, "product_quote": None, "ambiguities": []}


@pytest.mark.parametrize("version", [1, 2])
def test_dynamic_old_export_intake_is_read_without_another_model_or_database_write(gateway_workspace, version):
    repo, _core, _finance, gateway, _grant, resource, calls, _manifests = gateway_workspace
    old = _build_payload(QUESTION, {"entity_id": resource, "values": {"name": "Trà Sen"}}, None, get_market("US"), version=version)
    current = payload(["label", "registration", "prior_notice"], resource)
    output = registration_only()

    async def injected(model, body, limit):
        calls.append((model, deepcopy(body), limit))
        return {"text": json_text(output), "model": model, "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    gateway.request_fn = injected
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native transport"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    kwargs = {"operation_id": "dynamic-export-intake", "account_id": "owner", "enterprise_id": "enterprise"}
    expected = asyncio.run(provider("intake", old, **kwargs))
    before = data_snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        assert asyncio.run(provider("intake", current, **kwargs)) == expected
        assert len(calls) == 1 and data_snapshot(repo) == before
    finally:
        provider.recorded_only.reset(token)


def test_new_builder_keeps_all_three_and_static_shape_matches_strict_validator():
    assert static_contract()["base_schema"] == IntakeOutput.model_json_schema()
    current = build_export_intake_payload(QUESTION, None, None, get_market("US"))
    assert current == payload(["label", "registration", "prior_notice"])
    variants = historic_export_intake_payloads(current)
    assert variants[0] == current and payload(["registration"]) in variants[1:]
    # The public new-dispatch builder cannot select a weaker historical schema.
    with pytest.raises(TypeError):
        build_export_intake_payload(QUESTION, None, None, get_market("US"), version=2)


@pytest.mark.parametrize("question,prior_v1,prior_v2,current", [
    (QUESTION, ["label", "registration", "prior_notice", "clarification"], ["registration"], ["label", "registration", "prior_notice"]),
    ("Tôi chỉ hỏi nhãn", ["label", "clarification"], ["label", "clarification"], ["label"]),
    ("Chị không hỏi đăng ký FDA, nhãn, thông báo trước.", ["label", "prior_notice", "clarification"],
     ["label", "prior_notice", "clarification"], ["clarification"]),
])
def test_versioned_parsers_freeze_old_allowed_and_explicit_together(question, prior_v1, prior_v2, current):
    assert [_build_payload(question, None, None, get_market("US"), version=version)["input"]["allowed_outcomes"]
            for version in (1, 2, 3)] == [prior_v1, prior_v2, current]


def test_actual_mobile_quote_dispatch_contract_requests_all_three():
    question = ("Chị có Trà sen Tây Hồ (THỬ NGHIỆM), khối lượng tịnh 100 g, mã TS-QA-R23, bao bì hộp giấy. "
                "Chị muốn xuất khẩu sang Mỹ, cần đăng ký FDA, thông báo trước lô hàng, nhãn và ba việc đầu tiên.")
    body = build_export_intake_payload(question, None, None, get_market("US"))
    assert body["input"]["allowed_outcomes"] == ["label", "registration", "prior_notice"]
    assert body["response_schema"]["properties"]["outcomes"]["minItems"] == 3
    assert body["response_schema"]["properties"]["outcomes"]["maxItems"] == 3
    assert body["response_schema"]["$defs"]["IntakeOutcome"]["properties"]["id"]["enum"] == ["label", "registration", "prior_notice"]


@pytest.mark.parametrize("mutate", [
    lambda value: value["response_schema"]["properties"]["outcomes"].update(minItems=1),
    lambda value: value["response_schema"]["$defs"]["IntakeOutcome"]["properties"]["id"].update(enum=["registration"]),
    lambda value: value["input"].update(allowed_outcomes=["registration"]),
    lambda value: value.update(instructions_vi=value["instructions_vi"] + " Changed prompt"),
    lambda value: value["input"].update(outcome_semantics_vi="Changed semantics"),
    lambda value: value["input"].update(extra_key="not registered"),
    lambda value: value.update(extra_key="not registered"),
])
def test_unknown_whole_contract_is_never_reinterpreted_as_historical(mutate):
    current = build_export_intake_payload(QUESTION, None, None, get_market("US"))
    mutate(current)
    assert historic_export_intake_payloads(current) == [current]


@pytest.mark.parametrize("change", ["question", "product_id", "product_value", "previous_context", "market"])
def test_historic_hash_does_not_erase_changed_private_input(gateway_workspace, change):
    repo, _core, _finance, gateway, _grant, resource, calls, _manifests = gateway_workspace
    old = _build_payload(QUESTION, {"entity_id": resource, "values": {"name": "Trà Sen"}}, None, get_market("US"), version=2)
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native transport"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    kwargs = {"operation_id": "changed-" + change, "account_id": "owner", "enterprise_id": "enterprise"}
    asyncio.run(provider("intake", old, **kwargs))
    inputs = deepcopy(old["input"])
    if change == "question":
        inputs["question"] += " Riêng đợt hai."
    elif change == "product_id":
        inputs["selected_product"]["entity_id"] = "other-resource"
    elif change == "product_value":
        inputs["selected_product"]["values"]["name"] = "Mứt Sen"
    elif change == "previous_context":
        inputs["previous_mission_context"] = {"outcomes": [{"id": "registration"}], "prior_decision": "new"}
    else:
        inputs["resolved_market"] = get_market("JP")
    current = build_export_intake_payload(inputs["question"], inputs["selected_product"],
                                         inputs["previous_mission_context"], inputs["resolved_market"])
    before = data_snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        with pytest.raises(CoreError) as error:
            asyncio.run(provider("intake", current, **kwargs))
        assert error.value.code == "RECORDED_CONTEXT_CHANGED"
        assert len(calls) == 1 and data_snapshot(repo) == before
    finally:
        provider.recorded_only.reset(token)


def test_exact_old_cache_still_checks_current_resource_read(gateway_workspace, monkeypatch):
    repo, core, _finance, gateway, _grant, resource, calls, _manifests = gateway_workspace
    old = payload(["registration"], resource)
    current = build_export_intake_payload(QUESTION, old["input"]["selected_product"], None, get_market("US"))
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native transport"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    kwargs = {"operation_id": "revoke-old-cache", "account_id": "owner", "enterprise_id": "enterprise"}
    # Produce a genuine prior-version immutable manifest, without editing it
    # after the fact. The old projector omitted selected-product fields.
    with monkeypatch.context() as previous_version:
        previous_version.setattr(provider.governed_adapter, "_resource_dependencies",
                                 lambda _context: [{"resource_id": resource, "fields": []}])
        asyncio.run(provider("intake", old, **kwargs))
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
    before = data_snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        with pytest.raises(CoreError):
            asyncio.run(provider("intake", current, **kwargs))
        assert len(calls) == 1 and data_snapshot(repo) == before
    finally:
        provider.recorded_only.reset(token)


def test_new_selected_product_manifest_seals_exact_field_names():
    context = {"input": {"selected_product": {"entity_id": "product", "name": "Trà Sen",
                                             "values": {"Name.alternate": "Raw alias", "net_quantity": "100 g"},
                                             "facts": [{"field": "Packaging.Note", "value": "hộp"}]}}}
    assert GovernedLegacyAdapter._resource_dependencies(context) == [
        {"resource_id": "product", "fields": ["Name.alternate", "Packaging.Note", "name", "net_quantity"]}]


def test_revoked_unrelated_field_does_not_expand_receipt_read_scope(gateway_workspace):
    repo, core, _finance, gateway, _grant, resource, calls, _manifests = gateway_workspace
    selected = {"entity_id": resource, "values": {"net_quantity": "100 g"}}
    old = _build_payload(QUESTION, selected, None, get_market("US"), version=2)
    current = build_export_intake_payload(QUESTION, selected, None, get_market("US"))
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("No native transport"))
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    kwargs = {"operation_id": "quantity-only-read", "account_id": "owner", "enterprise_id": "enterprise"}
    expected = asyncio.run(provider("intake", old, **kwargs))
    with repo.connection() as db:
        dependencies = json.loads(db.execute("SELECT dependencies_json FROM core_model_attempts").fetchone()[0])
    assert dependencies["resource_dependencies"] == [{"resource_id": resource, "fields": ["net_quantity"]}]
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
    before = data_snapshot(repo)
    token = provider.recorded_only.set(True)
    try:
        assert asyncio.run(provider("intake", current, **kwargs)) == expected
        assert len(calls) == 1 and data_snapshot(repo) == before
    finally:
        provider.recorded_only.reset(token)


@pytest.mark.asyncio
async def test_full_prepare_uses_old_intake_receipt_and_keeps_missing_topics_visible(main_workspace):
    repo, owner, _other, model, provider, missions, _intake, _chat = main_workspace
    product = repo.create_entity(*scope(owner), "product", "Trà Sen")
    selected = selected_product_projection(repo.get_entity(*scope(owner), product["id"]))
    old = _build_payload(QUESTION, selected, None, get_market("US"), version=2)

    async def original_model(model_name, body, limit):
        model.calls.append((model_name, deepcopy(body)))
        return {"text": json_text(registration_only()), "model": model_name, "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    provider._request_override = original_model
    kwargs = {"operation_id": "old-prepare-receipt", "account_id": owner["account_id"], "enterprise_id": owner["enterprise_id"]}
    envelope = await provider("intake", old, **kwargs)
    ledger_before = data_snapshot(repo)["v03_live_attempts"]
    token = provider.recorded_only.set(True)
    try:
        view = await missions.prepare_async(*scope(owner), QUESTION, kwargs["operation_id"], product["id"], market_code="US")
        assert {outcome["id"] for outcome in view["intent"]["outcomes"]} == {"label", "registration", "prior_notice"}
        assert not view["answers"] and len(model.calls) == 1
        assert data_snapshot(repo)["v03_live_attempts"] == ledger_before
        with repo.connection() as db:
            raw = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id=?", (envelope["attempt_id"],)).fetchone()[0])
            interpreted = json.loads(db.execute("SELECT output_json FROM v03_live_review_outputs WHERE mission_id=? AND kind='intake'", (view["id"],)).fetchone()[0])
        assert raw == envelope and interpreted == registration_only()
        before_read = data_snapshot(repo)
        assert missions.get(*scope(owner), view["id"])["id"] == view["id"]
        assert (await missions.prepare_async(*scope(owner), QUESTION, kwargs["operation_id"], product["id"], market_code="US"))["id"] == view["id"]
        assert data_snapshot(repo) == before_read and len(model.calls) == 1
    finally:
        provider.recorded_only.reset(token)

    # An old valid registration answer cannot turn missing label/prior_notice
    # into answers. The actual main READ route publishes only checked parts.
    stored = missions._internal(view["id"])
    registration = next(outcome for outcome in stored["intent"]["outcomes"] if outcome["id"] == "registration")
    old_research = {"data": research({"input": {"reference_records": stored["knowledge"]["records"], "outcomes": [registration]}})}
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_missions SET status='failed' WHERE id=?", (view["id"],))
        db.execute("INSERT INTO v03_live_attempts(id,account_id,enterprise_id,operation_id,kind,request_hash,mission_id,model,state,response_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                   ("synthetic-old-research", owner["account_id"], owner["enterprise_id"], "old-research-receipt", "research", "old-intact-hash", view["id"], "claude-sonnet-5-5", "succeeded", json_text(old_research), stored["created_at"]))
    before_read = data_snapshot(repo)
    restarted = MainMissions(repo, model_call=provider)
    partial = restarted.get(*scope(owner), view["id"])["strict_partial"]
    assert [answer["outcome_id"] for answer in partial["validated_answers"]] == ["registration"]
    assert {item["outcome_id"] for item in partial["blocked_outcomes"]} == {"label", "prior_notice"}
    assert not partial["complete_report"] and partial["model_calls"] == partial["ssot_writes"] == 0
    assert data_snapshot(repo) == before_read and len(model.calls) == 1
