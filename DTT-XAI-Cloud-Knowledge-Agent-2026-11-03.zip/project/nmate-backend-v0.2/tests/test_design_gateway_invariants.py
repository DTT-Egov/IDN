"""DF-029/030/031/034/044 architecture contracts; injected transport only."""
import asyncio
import copy
import hashlib
import json
import sqlite3
from datetime import datetime, timedelta, timezone

import pytest

import nmate.core_v1.model_contract as contracts
from nmate.core_v1.finance import FinanceService, is_financial_field
from nmate.core_v1.gateway import ModelGateway, digest
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.core_v1.ssot import CoreSSOTService
from nmate.main.provider import MainProvider, canonical_main_request, historic_main_request_hashes
from nmate.v03.core import CoreError, CoreRepository, json_text, now_iso


OUTPUT = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


@pytest.fixture
def workspace(tmp_path):
    repo = CoreRepository(tmp_path / "design-gateway.sqlite3")
    with repo.connection(write=True) as db:
        for account in ("owner", "colleague", "outsider"):
            db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES(?,?,?,?)",
                       (account, account, "no-login-no-network", now_iso()))
        for enterprise in ("enterprise", "other-enterprise"):
            db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES(?,?,?)", (enterprise, enterprise, now_iso()))
        db.executemany("INSERT INTO v03_memberships VALUES(?,'enterprise','owner',1)", [("owner",), ("colleague",)])
        db.execute("INSERT INTO v03_memberships VALUES('outsider','other-enterprise','owner',1)")
    core = CoreSSOTService(repo)
    finance = FinanceService(repo, core)
    resource = repo.create_entity("colleague", "enterprise", "enterprise", "Hồ sơ riêng")
    core.grant_resource("colleague", "enterprise", resource["id"], "owner", ["read"], ["name", "net_quantity"])
    calls, manifests_at_transport = [], []

    async def transport(model, body, limit):
        calls.append(copy.deepcopy((model, body, limit)))
        with repo.connection() as db:
            row = db.execute("SELECT m.* FROM core_model_request_manifests m JOIN core_model_attempts a ON a.id=m.attempt_id "
                             "WHERE a.state='dispatch_committed' ORDER BY a.created_at DESC LIMIT 1").fetchone()
            manifests_at_transport.append(dict(row) if row else None)
        return {"text": '{"answer":"Kết quả đã kiểm chứng trong test."}', "model": model,
                "usage": {"input_tokens": 10, "output_tokens": 5}, "stop_reason": "end_turn"}

    gateway = ModelGateway(repo, core=core, finance=finance, request_fn=transport, enabled=True)
    grant = gateway.authorize_budget("owner", "enterprise", approval_id="TEST-NO-PROVIDER-NETWORK",
        max_calls=10, max_cost_usd=10, purposes=["policy_synthesis", "legacy_intake", "legacy_research"],
        roles=["standard", "complex"], expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())["id"]
    return repo, core, finance, gateway, grant, resource["id"], calls, manifests_at_transport


def invoke(workspace, **overrides):
    gateway, grant = workspace[3:5]
    args = {"account_id": "owner", "enterprise_id": "enterprise", "operation_id": "same-operation",
            "task_id": "summary", "purpose": "policy_synthesis", "role": "standard",
            "context": {"question": "Câu gốc chỉ được giữ ở hồ sơ riêng 748203"},
            "output_schema": OUTPUT, "budget_grant_id": grant}
    args.update(overrides)
    return asyncio.run(gateway.call_once(**args))


def attempt_counts(repo):
    with repo.connection() as db:
        return tuple(db.execute("SELECT (SELECT COUNT(*) FROM core_model_attempts),"
                                "(SELECT COUNT(*) FROM core_model_request_manifests)").fetchone())


def test_finance_reference_without_verifier_fails_before_reservation(workspace):
    # Regression: the old compile guard treated any nonempty IDs as authority
    # while verify_dispatch was skipped when the finance service was absent.
    workspace[3].finance = None
    with pytest.raises(CoreError) as blocked:
        invoke(workspace, context={"revenue": 100}, financial_egress_grant_ids=["invented-reference"])
    assert blocked.value.code == "DATA_EGRESS_AUTHORITY_UNAVAILABLE"
    assert attempt_counts(workspace[0]) == (0, 0) and workspace[6] == []


def test_private_ssot_dependencies_without_resource_authority_fail_before_reservation(workspace):
    workspace[3].core = None
    with pytest.raises(CoreError) as blocked:
        invoke(workspace, resource_dependencies=[{"resource_id": workspace[5], "fields": ["name"]}])
    assert blocked.value.code == "RESOURCE_AUTHORITY_UNAVAILABLE"
    assert attempt_counts(workspace[0]) == (0, 0) and workspace[6] == []


@pytest.mark.parametrize("context", [{"metric_code": "revenue", "value_decimal": "100"},
                                    {"facts": [{"field": "cash_flow.2026", "value": "100"}]}])
def test_unsealed_annotated_metrics_cannot_bypass_missing_verifier(workspace, context):
    workspace[3].finance = None
    with pytest.raises(CoreError) as blocked:
        invoke(workspace, context=context)
    assert blocked.value.code == "financial_unsealed_payload"
    assert attempt_counts(workspace[0]) == (0, 0) and not workspace[6]


@pytest.mark.parametrize("field", ["revenue.2026", "annual_revenue.2025", "finance.revenue", "financial.profit",
                                  "cash_flow.2026", "operating_cost.2026", "revenue_projection", "Revenue.2026",
                                  "EMPLOYEE_COUNT.2026", "FINANCE.Revenue"])
def test_qualified_financial_keys_use_one_boundary(workspace, field):
    assert is_financial_field(field)
    with pytest.raises(CoreError):
        invoke(workspace, context={"nested": {field: 100}})
    assert attempt_counts(workspace[0]) == (0, 0) and not workspace[6]


@pytest.mark.parametrize("key", ["data_base64", "original_document", "file_path"])
def test_raw_equivalent_aliases_never_reserve(workspace, key):
    with pytest.raises(CoreError):
        invoke(workspace, context={"nested": {key: "original-private-document"}})
    assert attempt_counts(workspace[0]) == (0, 0)


@pytest.mark.parametrize("grant_ids", ["not-a-list", ["repeat", "repeat"], [None], [42], [""]])
def test_egress_ids_are_typed_references_not_capabilities(workspace, grant_ids):
    with pytest.raises(CoreError) as blocked:
        invoke(workspace, financial_egress_grant_ids=grant_ids)
    assert blocked.value.code == "INVALID_MODEL_REQUEST" and not workspace[6]


def test_manifest_is_durable_before_transport_minimized_and_immutable(workspace):
    repo, _, _, gateway, _, _, calls, at_transport = workspace
    result = invoke(workspace)
    assert len(calls) == 1 and len(at_transport) == 1
    saved = at_transport[0]
    assert saved and saved["attempt_id"] == result["attempt_id"]
    manifest = json.loads(saved["manifest_json"])
    assert "748203" not in saved["manifest_json"] and "Câu gốc" not in saved["manifest_json"]
    assert manifest["contract_version"] == contracts.REQUEST_CONTRACT_VERSION
    assert manifest["model"] == result["model"] and saved["manifest_hash"] == digest(manifest)
    with repo.connection() as db:
        attempt = db.execute("SELECT * FROM core_model_attempts WHERE id=?", (result["attempt_id"],)).fetchone()
        assert attempt["request_hash"] == manifest["request_hash"]
    for statement in ("UPDATE core_model_request_manifests SET manifest_hash='changed'",
                      "DELETE FROM core_model_request_manifests"):
        with pytest.raises(sqlite3.IntegrityError, match="immutable"):
            with repo.connection(write=True) as db:
                db.execute(statement)
    # No new manifest, grant or provider invocation is created by receipt reads.
    before = attempt_counts(repo)
    gateway.enabled = False
    assert gateway.read_receipt("owner", "enterprise", result["attempt_id"])["data"] == result["data"]
    assert attempt_counts(repo) == before and len(calls) == 1


def test_canonical_builder_preserves_original_compatibility_hash():
    body = {"input": {"question": "Nguyên văn"}, "response_schema": OUTPUT, "purpose": "legacy_intake",
            "task_instructions_vi": "Chỉ dẫn gốc"}
    dependencies = {"resource_id": None, "financial_egress_grant_ids": []}
    contract = contracts.canonical_request(payload=body["input"], output_schema=OUTPUT, purpose="legacy_intake",
        role="standard", profile_version="standard/1", model="claude-sonnet-5-5", max_output_tokens=4096,
        dependencies=dependencies, instructions=body["task_instructions_vi"])
    expected = digest({**body, "role": "standard", "profile": "standard/1", "max_output_tokens": 4096,
                       "dependencies": dependencies})
    assert contract["request_hash"] == expected and contract["body"] == body


def test_contract_drift_prevents_reinvocation_but_never_hides_lawful_history(workspace, monkeypatch):
    original = invoke(workspace)
    monkeypatch.setattr(contracts, "TRANSPORT_CONTRACT_VERSION", "different-contract/2")
    with pytest.raises(CoreError) as blocked:
        invoke(workspace)
    assert blocked.value.code == "RECORDED_CONTRACT_CHANGED"
    assert workspace[3].read_receipt("owner", "enterprise", original["attempt_id"])["data"] == original["data"]
    assert len(workspace[6]) == 1 and attempt_counts(workspace[0]) == (1, 1)


@pytest.mark.parametrize("column,value", [("dependencies_json", "{}"), ("request_hash", "0" * 64),
                                         ("profile_version", "complex/1"), ("model", "claude-opus-5-5"),
                                         ("max_output_tokens", 2048), ("step_key", "different-step")])
def test_attempt_identity_or_lineage_drift_cannot_bypass_immutable_manifest(workspace, column, value):
    receipt = invoke(workspace)
    with workspace[0].connection(write=True) as db:
        # Simulate a future buggy writer; the original immutable manifest must
        # detect drift even though state columns on attempts remain mutable.
        db.execute(f"UPDATE core_model_attempts SET {column}=? WHERE id=?", (value, receipt["attempt_id"]))
    with pytest.raises(CoreError) as blocked:
        workspace[3].read_receipt("owner", "enterprise", receipt["attempt_id"])
    assert blocked.value.code == "RECORDED_MANIFEST_MISMATCH" and len(workspace[6]) == 1


def test_failed_network_retains_manifest_and_never_retries(workspace):
    async def timeout(*args):
        workspace[6].append("transport-boundary-crossed")
        raise TimeoutError("No real network in this test")
    workspace[3].request_fn = timeout
    for _ in range(2):
        with pytest.raises(CoreError):
            invoke(workspace)
    assert len(workspace[6]) == 1 and attempt_counts(workspace[0]) == (1, 1)
    workspace[3].recover_interrupted()
    assert attempt_counts(workspace[0]) == (1, 1)


@pytest.mark.parametrize("actor,enterprise", [("colleague", "enterprise"), ("outsider", "other-enterprise")])
def test_receipt_read_checks_principal_not_only_membership(workspace, actor, enterprise):
    receipt = invoke(workspace)
    with pytest.raises(CoreError):
        workspace[3].read_receipt(actor, enterprise, receipt["attempt_id"])
    assert len(workspace[6]) == 1


def test_field_revocation_blocks_derivative_receipt_even_if_resource_still_readable(workspace):
    repo, core, _, gateway, _, resource, calls, _ = workspace
    refs = [{"resource_id": resource, "fields": ["name", "net_quantity"]}]
    receipt = invoke(workspace, resource_dependencies=refs)
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["net_quantity"])
    assert core.can_read("owner", "enterprise", resource, "name")
    with pytest.raises(CoreError):
        gateway.read_receipt("owner", "enterprise", receipt["attempt_id"])
    with pytest.raises(CoreError):
        invoke(workspace, resource_dependencies=refs)
    assert len(calls) == 1 and attempt_counts(repo) == (1, 1)


def test_dependency_acl_rechecked_in_same_final_transaction(workspace, monkeypatch):
    repo, core, _, gateway, _, resource, calls, _ = workspace
    check = gateway._require_dependencies
    checks = []

    def revoke_between_fences(db, account, enterprise, dependencies):
        check(db, account, enterprise, dependencies)
        checks.append(1)
        if len(checks) == 1:
            db.execute("UPDATE core_v1_grants SET revoked_at=? WHERE resource_id=? AND account_id='owner' AND field_key='net_quantity'",
                       (now_iso(), resource))
    monkeypatch.setattr(gateway, "_require_dependencies", revoke_between_fences)
    with pytest.raises(CoreError):
        invoke(workspace, resource_dependencies=[{"resource_id": resource, "fields": ["net_quantity"]}])
    assert calls == []
    with repo.connection() as db:
        row = db.execute("SELECT state,dispatched_at,held_microusd FROM core_model_attempts").fetchone()
        assert tuple(row) == ("cancelled_before_dispatch", None, 0)
    assert attempt_counts(repo) == (1, 1)


def test_legacy_cache_and_recorded_only_share_gateway_lineage_authority(workspace):
    repo, core, _, gateway, _, resource, calls, _ = workspace
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("Native transport is forbidden"))
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    provider.governed_adapter = adapter
    original = {"instructions_vi": "Chỉ trả JSON.", "response_schema": OUTPUT,
                "input": {"current_question": "Chị cần đối chiếu hồ sơ.",
                          "ssot": {"entities": [{"id": resource, "values": {"name": "Hồ sơ riêng"}}]}}}
    kwargs = {"operation_id": "legacy-lineage", "account_id": "owner", "enterprise_id": "enterprise"}
    first = asyncio.run(provider("intake", original, **kwargs))
    assert len(calls) == 1
    core.revoke_resource("colleague", "enterprise", resource, "owner", ["read"], ["name"])
    for recorded in (False, True):
        token = provider.recorded_only.set(recorded)
        try:
            with pytest.raises(CoreError):
                asyncio.run(provider("intake", original, **kwargs))
        finally:
            provider.recorded_only.reset(token)
    assert len(calls) == 1
    with repo.connection() as db:
        raw = json.loads(db.execute("SELECT response_json FROM v03_live_attempts WHERE id=?", (first["attempt_id"],)).fetchone()[0])
        assert raw == first  # Denial must never rewrite the paid receipt.


def test_unknown_legacy_ssot_entity_cannot_be_used_as_model_context(workspace):
    repo, _, _, gateway, _, _, calls, _ = workspace
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("Native transport is forbidden"))
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    payload = {"instructions_vi": "Chỉ trả JSON.", "response_schema": OUTPUT,
               "input": {"current_question": "Chị cần xem hồ sơ.",
                         "ssot": {"entities": [{"id": "invented-no-authority", "values": {"name": "Trà Sen"}}]}}}
    with pytest.raises(CoreError):
        asyncio.run(adapter("intake", payload, operation_id="forged-lineage", account_id="owner", enterprise_id="enterprise"))
    assert calls == [] and attempt_counts(repo) == (0, 0)


@pytest.mark.parametrize("field,value", [("net_quantity", "một trăm gam abc"), ("net_weight", "-100 g"),
                                        ("product_code", "TS01<script>")])
def test_legacy_business_scalar_uses_shared_domain_value_contract_before_reservation(workspace, field, value):
    repo, _, _, gateway, _, _, calls, _ = workspace
    provider = MainProvider(repo, request_fn=lambda *args: pytest.fail("Native transport is forbidden"))
    adapter = GovernedLegacyAdapter(repo, gateway, provider)
    payload = {"instructions_vi": "Chỉ trả JSON.", "response_schema": OUTPUT,
               "input": {"current_question": "Chị cần xem hồ sơ.", "ssot": {"values": {field: value}}}}
    with pytest.raises(CoreError):
        asyncio.run(adapter("intake", payload, operation_id="invalid-legacy-value", account_id="owner", enterprise_id="enterprise"))
    assert calls == [] and attempt_counts(repo) == (0, 0)


@pytest.mark.parametrize("version", [1, 2, 3])
@pytest.mark.parametrize("address", [None, "chị", "bác"])
def test_main_contract_registry_uses_complete_hash_for_all_historic_variants(version, address):
    original = {"input": {"current_question": "Giữ nguyên câu hỏi", "ssot": {"net_quantity": "100 g"}},
                "instructions_vi": "Chỉ trả JSON.", "response_schema": OUTPUT}
    payload = canonical_main_request("intake", original, "profile_intake", contract_version=version, address=address)
    request_hash = hashlib.sha256(json_text(payload).encode()).hexdigest()
    assert request_hash in historic_main_request_hashes("intake", original, "profile_intake")
    changed = copy.deepcopy(original)
    changed["input"]["ssot"]["net_quantity"] = "200 g"
    assert request_hash not in historic_main_request_hashes("intake", changed, "profile_intake")
    assert original["instructions_vi"] == "Chỉ trả JSON."


@pytest.mark.asyncio
@pytest.mark.parametrize("interrupt", [False, True])
async def test_original_question_and_pending_operation_commit_before_any_main_transport(tmp_path, interrupt):
    from test_unified_main import setup as main_setup, scope
    repo, owner, _, model, provider, _, _, chat = main_setup.__wrapped__(tmp_path)
    original = provider._request_override
    question, operation = "Tôi muốn số hóa bán hàng và tồn kho", "durable-before-transport"
    observed = []

    async def inspect_before_transport(model_name, payload, limit):
        with repo.connection() as db:
            row = db.execute("SELECT * FROM main_operations WHERE account_id=? AND enterprise_id=? AND operation_id=?",
                             (*scope(owner), operation)).fetchone()
            assert row and row["state"] == "preparing"
            saved = json.loads(db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (row["conversation_id"],)).fetchone()[0])
            submitted = [message for message in saved["messages"] if message.get("role") == "user"
                         and message.get("operation_id") == operation]
            assert len(submitted) == 1 and submitted[0]["text"] == question
            assert saved["pending_operation_id"] == operation
            observed.append(True)
        if interrupt:
            raise TimeoutError("Injected crash, no external network")
        return await original(model_name, payload, limit)

    provider._request_override = inspect_before_transport
    if interrupt:
        with pytest.raises(CoreError):
            await chat.send_async(*scope(owner), question, [], operation, paid_consent=True, task_hint="sales_inventory")
    else:
        result = await chat.send_async(*scope(owner), question, [], operation, paid_consent=True, task_hint="sales_inventory")
        assert result["status"] != "preparing"
    assert observed == [True]
    with repo.connection() as db:
        row = db.execute("SELECT conversation_id FROM main_operations WHERE operation_id=?", (operation,)).fetchone()
        saved = json.loads(db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (row[0],)).fetchone()[0])
        assert sum(message.get("text") == question and message.get("role") == "user" for message in saved["messages"]) == 1
    # Reading state after interruption never dispatches another request.
    calls = len(model.calls)
    chat.get(*scope(owner), row[0])
    chat.list(*scope(owner))
    assert len(model.calls) == calls
