"""Saved public output is an assertion, never a legal approval. No paid SDK."""
import json
import pytest
from test_knowledge_m3_domain_gateway import domain, invoke
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb
from nmate.knowledge_v1.governance import WikiGovernance
from nmate.knowledge_v1.ai_proposals import PROPOSAL_SCHEMA,record_proposal,read_proposal
from nmate.v03.core import CoreError

async def saved(domain,kind='source_excerpt',text='A paraphrase requiring human review.',quote=None,evidence_id='1'):
    gw,_,_,_,_,_,ref,calls=domain
    data=dict(title='TEST ONLY',claims=[dict(kind=kind,text=text,evidence=[dict(evidence_id=evidence_id,quote=quote or ref['quote'])])],gaps=['TEST incomplete'],questions_for_expert=[])
    async def request(model,body,limit):
        calls.append(model)
        return dict(text=json.dumps(data),model=model,stop_reason='end_turn',usage={'input_tokens':100,'output_tokens':80})
    gw.request_fn=request
    result=await invoke(domain,output_schema=PROPOSAL_SCHEMA)
    return result,data

@pytest.mark.asyncio
@pytest.mark.parametrize('kind,literal,effective',[
    ('source_excerpt',False,'interpretation'),('source_excerpt',True,'source_excerpt'),('interpretation',True,'interpretation')])
async def test_admission_only_downgrades_and_preserves_original(domain,kind,literal,effective):
    gw,_,actor,_,_,_,ref,calls=domain;service=WikiGovernance(gw.repo)
    result,data=await saved(domain,kind,ref['quote'] if literal else 'A paraphrase requiring human review.')
    proposal=record_proposal(service,gw,actor,result['attempt_id'])
    row=read_proposal(service,gw,actor,proposal['proposal_id']);p=row['payload']
    assert p['model_output']==data
    assert p['candidate']['claims'][0]['kind']==effective
    assert p['admission']['version']=='proposal-admission/3'
    claim=p['admission']['claims'][0]
    assert claim['model_kind']==kind and claim['effective_kind']==effective
    assert claim['semantic_verified'] is False
    assert bool(claim['warnings'])==(effective=='interpretation')
    assert p['admission']['requires_expert_review'] is True
    assert p['reviewed_by'] is None and p['published_by'] is None
    assert record_proposal(service,gw,actor,result['attempt_id'])['cached'] is True
    assert len(calls)==1

@pytest.mark.asyncio
async def test_v1_receipt_replay_before_current_admission_recipe(domain,monkeypatch):
    from nmate.core_v1.runtime_schema import canonical,digest
    from nmate.knowledge_v1 import ai_proposals as module
    from nmate.v03.core import now_iso
    gw,_,actor,_,_,_,ref,_=domain;service=WikiGovernance(gw.repo)
    result,data=await saved(domain,text=ref['quote'])
    _,dep,body,inv=module.receipt_data(service,gw,actor,result['attempt_id'])
    candidate,_=module.candidate_payload(service,actor,data,body)
    original=dict(model_output=data,candidate=candidate,generated_by=result['attempt_id'],invoked_by=inv,
                  assignee_id=actor,reviewed_by=None,published_by=None)
    with gw.repo.connection(write=True) as db:
        db.execute('INSERT INTO pol_wiki_ai_proposals VALUES(?,?,?,?,?,?,?,?)',
          ('v1-proposal',result['attempt_id'],dep['policy_id'],actor,canonical(inv),canonical(original),digest(original),now_iso()))
        before=list(db.iterdump())
    def forbidden(*args,**kw):raise AssertionError('must not rederive committed v1')
    monkeypatch.setattr(module,'candidate_payload',forbidden)
    assert record_proposal(service,gw,actor,result['attempt_id'])['cached'] is True
    assert read_proposal(service,gw,actor,'v1-proposal')['payload']==original
    with gw.repo.connection() as db:assert list(db.iterdump())==before

@pytest.mark.asyncio
async def test_revoke_read_blocks_free_admission_but_not_stop(domain):
    from nmate.knowledge_v1.public_batch import pause_after_failure
    gw,source,actor,_,_,grant,_,calls=domain;service=WikiGovernance(gw.repo)
    result,_=await saved(domain)
    source.set_source_rights(actor,'KB-TEST-A',expected_version=1,allow_read=False,allow_export=False,
                             reason='TEST revoke',operation_id='revoke-admission')
    pause_after_failure(gw.repo,grant,result['attempt_id'],operator='TEST operator',reason='TEST stop despite revoke')
    with pytest.raises(CoreError):record_proposal(service,gw,actor,result['attempt_id'])
    assert len(calls)==1

@pytest.mark.asyncio
@pytest.mark.parametrize('state',['needs_reconciliation','revoked'])
async def test_stop_never_weakens_existing_nonactive_state(domain,state):
    from nmate.knowledge_v1.public_batch import pause_after_failure
    gw,_,actor,_,_,grant,_,_=domain
    result,_=await saved(domain)
    with gw.repo.connection(write=True) as db:db.execute('UPDATE core_domain_budget_grants SET state=? WHERE id=?',(state,grant))
    pause_after_failure(gw.repo,grant,result['attempt_id'],operator='TEST operator',reason='TEST stop')
    with gw.repo.connection() as db:assert db.execute('SELECT state FROM core_domain_budget_grants WHERE id=?',(grant,)).fetchone()[0]==state

@pytest.mark.asyncio
@pytest.mark.parametrize('quote,evidence_id',[('fabricated','1'),('training for enterprises.','1'),('Training for enterprises.','999')])
async def test_bad_evidence_cannot_be_rescued_by_downgrade(domain,quote,evidence_id):
    gw,_,actor,*_=domain;service=WikiGovernance(gw.repo)
    result,_=await saved(domain,quote=quote,evidence_id=evidence_id)
    with pytest.raises(CoreError):record_proposal(service,gw,actor,result['attempt_id'])
    with gw.repo.connection() as db: assert db.execute('SELECT count(*) FROM pol_wiki_ai_proposals').fetchone()[0]==0
    assert len(domain[-1])==1

@pytest.mark.asyncio
async def test_pause_survives_free_admission_and_blocks_new_slot(domain):
    from nmate.knowledge_v1.public_batch import pause_after_failure
    gw,_,actor,_,_,grant,_,calls=domain;service=WikiGovernance(gw.repo)
    result,_=await saved(domain)
    first=pause_after_failure(gw.repo,grant,result['attempt_id'],operator='TEST operator',reason='TEST admission failure')
    assert pause_after_failure(gw.repo,grant,result['attempt_id'],operator='TEST operator',reason='TEST admission failure')==first
    proposal=record_proposal(service,gw,actor,result['attempt_id'])
    assert read_proposal(service,gw,actor,proposal['proposal_id'])['payload']['candidate']['claims'][0]['kind']=='interpretation'
    with pytest.raises(CoreError):await invoke(domain,task_id='S2',operation_id='no-auto-continue')
    with gw.repo.connection() as db:
        assert db.execute('SELECT state FROM core_domain_budget_grants WHERE id=?',(grant,)).fetchone()[0]=='paused_admission_review'
        assert db.execute("SELECT count(*) FROM core_domain_model_events WHERE kind='batch_paused_admission'").fetchone()[0]==1
        assert db.execute('SELECT count(*) FROM pol_wiki_reviews').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM pol_wiki_releases').fetchone()[0]==0
    assert len(calls)==1
