"""Known unsupported questions stop before any paid/model reservation."""
import pytest
from datetime import datetime, timedelta, timezone
import json

from nmate.v03.core import CoreError
from nmate.core_v1.gateway import ModelGateway
from nmate.core_v1.legacy_gateway import GovernedLegacyAdapter
from nmate.core_v1.ssot import CoreSSOTService
from test_unified_main import setup as setup, scope
from test_v04_intake import confirm
from test_v04_live_review import result


@pytest.mark.asyncio
@pytest.mark.parametrize("task", ["profile_intake", "sales_inventory", "export_research"])
async def test_paid_loan_question_refuses_before_chat_model_or_d06_hold(setup, task):
    repo, owner, _other, model, provider, _missions, _intake, chats = setup
    model.fail = True
    gateway = ModelGateway(repo, request_fn=model, enabled=True)
    gateway.authorize_budget(*scope(owner), approval_id="LOCAL-TEST-NO-PAID-IO", max_calls=2, max_cost_usd=1,
        purposes=["legacy_intake", "legacy_research"], roles=["standard", "complex"],
        expires_at=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    before = repo.get_context(*scope(owner))
    with pytest.raises(CoreError) as error:
        await chats.send_async(*scope(owner), "Chị muốn vay vốn để mở rộng cơ sở", [], "unsupported-loan-01",
            task_hint=task, paid_consent=True, market_code="US" if task == "export_research" else None)
    assert error.value.code == "UNSUPPORTED_TASK"
    assert "chưa hỗ trợ" in str(error.value)
    assert "chị" in str(error.value).lower()
    assert "chuẩn bị xuất khẩu?" not in str(error.value)
    assert model.calls == []
    assert provider.summary()["paid_calls"] == 0
    assert repo.get_context(*scope(owner))["fact_refs"] == before["fact_refs"]
    with repo.connection() as db:
        for table in ("v03_live_attempts", "core_model_attempts", "main_operations", "v04_conversations"):
            assert db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 1
    gate = gateway.status(*scope(owner))
    assert gate["held_usd"] == 0 and gate["grants"][0]["remaining_calls"] == 2


@pytest.mark.asyncio
async def test_unsupported_preflight_preserves_existing_chat_and_draft(setup):
    repo, owner, _other, model, _provider, _missions, _intake, chats = setup
    initial = chats.prepare_chat_draft(*scope(owner), "Chị có sản phẩm Trà Sen Tây Hồ, hộp 100 g", "free-original-tea")
    with repo.connection() as db:
        before = db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (initial["id"],)).fetchone()[0]
    with pytest.raises(CoreError) as error:
        await chats.send_async(*scope(owner), "Cần vay ngân hàng thì sao?", [], "unsupported-loan-next", initial["id"], paid_consent=True)
    assert error.value.code == "UNSUPPORTED_TASK" and model.calls == []
    assert "chị" in str(error.value).lower()
    with repo.connection() as db:
        assert db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (initial["id"],)).fetchone()[0] == before
        assert db.execute("SELECT COUNT(*) FROM main_operations").fetchone()[0] == 0


@pytest.mark.asyncio
async def test_governed_allowed_chat_keeps_minimal_product_context_and_cas(setup):
    repo, owner, _other, ungoverned, provider, _missions, intake, chats = setup
    ungoverned.fail = True
    pending = chats.prepare_chat_draft(*scope(owner), "Chị có sản phẩm Trà Sen Tây Hồ, hộp 100 g", "free-tea-for-governed")
    tea = confirm(intake, owner, pending["intake"])["product"]["id"]
    other = repo.create_entity(*scope(owner), "product", "Mứt Sen")
    repo.propose_or_apply_facts(*scope(owner), other["id"], [{"field": "name", "value": "Mứt Sen"}], 0, "other-product-name")
    question = "Chị muốn giảm sai lệch tồn kho Trà Sen Tây Hồ"
    calls = []

    async def transport(model, body, limit):
        calls.append(body)
        return {"text": json.dumps(result(question, focus="inventory_accuracy"), ensure_ascii=False),
                "model": model, "request_id": "local-governed-no-paid-io", "stop_reason": "end_turn",
                "usage": {"input_tokens": 10, "output_tokens": 10}}

    # Match production: a paid request using private SSOT has an ACL authority.
    # Missing-authority refusal is independently covered by the design tests.
    gateway = ModelGateway(repo, core=CoreSSOTService(repo), request_fn=transport, enabled=True)
    gateway.authorize_budget(*scope(owner), approval_id="LOCAL-GOVERNED-ALLOW-NO-PAID-IO", max_calls=1, max_cost_usd=1,
        purposes=["legacy_intake"], roles=["standard"],
        expires_at=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())
    provider.governed_adapter = GovernedLegacyAdapter(repo, gateway, provider)
    sent = await chats.send_async(*scope(owner), question, [], "governed-allowed-chat", pending["id"], tea,
                                  paid_consent=True, task_hint="sales_inventory")
    assert len(calls) == 1 and ungoverned.calls == []
    model_input = calls[0]["input"]["input"]
    assert "product_binding" not in model_input
    assert tea in {entity["id"] for entity in model_input["ssot"]["entities"]}
    assert other["id"] not in {entity["id"] for entity in model_input["ssot"]["entities"]}
    assert sent["intake"]["product"]["id"] == tea
    assert chats.get(*scope(owner), sent["id"])["latest_operation_id"] == "governed-allowed-chat"
