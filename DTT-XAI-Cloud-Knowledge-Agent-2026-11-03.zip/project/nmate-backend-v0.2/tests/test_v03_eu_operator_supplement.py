"""Pin one supporting EU role clause; no SDK, network or repository writes."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from nmate.main.partial import project_partial_research
from nmate.v03.core import CoreError, json_text
from nmate.v03.evidence import (EU_OPERATOR_REFERENCE, SUPPLEMENTARY_POLICY,
                               validate_answer_citations, validate_citation)
from nmate.v03.live_review import validate_research


FIXTURE = Path(__file__).parent / "fixtures/unified_de_operator_failed_20261019.json"
FIXTURE_SHA256 = "e59b9a582e3aa974b0e38606bac4beb5411ce5526e3419f1be33c3c7e4008f8a"
RAW_DATA_SHA256 = "71d967a10cd8c458665c6f07d0946db9a51d737d1f7fecb726315781a93777c7"


@pytest.fixture
def recorded():
    value = json.loads(FIXTURE.read_text(encoding="utf-8"))
    return value["mission"], value["provider_envelope"]


def bind(mission, answer):
    outcome = next(item for item in mission["intent"]["outcomes"] if item["id"] == answer["outcome_id"])
    return validate_answer_citations(answer["citations"], records=mission["knowledge"]["records"],
        outcome_id=answer["outcome_id"], expected_market_code=mission["market"]["code"],
        outcome_question_part=outcome.get("question_part"), question=mission["question"])


def test_actual_de6_validates_whole_original_output_with_one_supplement_and_no_repair(recorded):
    mission, envelope = recorded
    before = deepcopy((mission, envelope))
    value = validate_research(envelope, mission)
    # Schema extensions may have optional defaults; the original supplied
    # fields must remain exactly unchanged, including every cited condition.
    assert value.model_dump(exclude_unset=True) == envelope["data"]
    assert (mission, envelope) == before
    bound = bind(mission, envelope["data"]["answers"][0])
    assert len(bound) == 5
    assert len([c for c in bound if c.get("evidence_role") == "supplementary"]) == 1
    support = next(c for c in bound if c.get("evidence_role") == "supplementary")
    assert support["reference_id"] == EU_OPERATOR_REFERENCE
    assert support["citation_policy"] == SUPPLEMENTARY_POLICY
    assert support["supplementary_scope"] == "eu_food_information_responsible_operator"
    label = bind(mission, envelope["data"]["answers"][1])
    assert len(label) == 6 and all(c.get("evidence_role") != "supplementary" for c in label)


def test_real_fixture_raw_hash_is_fixed_and_matches_recorded_data():
    value = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == FIXTURE_SHA256
    assert value["provenance"]["provider_attempt_id"] == "claude_c8b2318ece1046ab90e1e24aa2c8d1cb"
    assert hashlib.sha256(json_text(value["provider_envelope"]["data"]).encode()).hexdigest() == value["provenance"]["raw_data_sha256"] == RAW_DATA_SHA256
    assert value["provenance"]["no_provider_replay"] is True


def test_failed_report_projection_uses_same_contract_preserves_failed_status_and_raw(recorded):
    mission, envelope = recorded
    before = deepcopy((mission, envelope))
    view = project_partial_research(mission, envelope)
    assert (mission, envelope) == before
    assert view["mission_status"] == "failed" and not view["complete_report"]
    assert view["model_calls"] == view["ssot_writes"] == 0
    assert [a["outcome_id"] for a in view["validated_answers"]] == ["registration", "label"]
    assert view["blocked_outcomes"] == [] and view["actions"] == view["artifacts"] == []
    assert view["audit"]["raw_output"] == envelope["data"]


@pytest.mark.parametrize("status", ["needs_input", "answered_general", "blocked_source"])
def test_supplement_alone_never_establishes_registration_primary_coverage(recorded, status):
    mission, envelope = recorded
    answer = envelope["data"]["answers"][0]
    answer["status"] = status
    answer["citations"] = [c for c in answer["citations"] if c["source_id"] == EU_OPERATOR_REFERENCE]
    with pytest.raises(CoreError) as error:
        validate_research(envelope, mission)
    assert error.value.code == "evidence_primary_required"


@pytest.mark.parametrize("mutation", ["no_role", "different_outcome_part", "unbound_part", "negated_role", "focused_elsewhere"])
def test_role_must_be_explicitly_requested_in_bound_registration_question_part(recorded, mutation):
    mission, envelope = recorded
    registration = mission["intent"]["outcomes"][0]
    if mutation == "no_role":
        mission["question"] = "Hãy rà yêu cầu nhập khẩu thực phẩm."
        registration["question_part"] = mission["question"]
    elif mutation == "different_outcome_part":
        registration["question_part"] = "yêu cầu nhập khẩu thực phẩm"
    elif mutation == "unbound_part":
        registration["question_part"] = "Hỏi vai trò nhà nhập khẩu chưa từng có trong câu hỏi"
    elif mutation == "negated_role":
        mission["question"] = "Tôi không hỏi vai trò đơn vị chịu trách nhiệm; hãy rà yêu cầu nhập khẩu."
        registration["question_part"] = mission["question"]
    else:
        mission["question"] = "Vai trò đơn vị chịu trách nhiệm đã rõ; tôi chỉ hỏi yêu cầu nhập khẩu."
        registration["question_part"] = mission["question"]
    with pytest.raises(CoreError):
        validate_research(envelope, mission)


@pytest.mark.parametrize("mutation", ["short_quote", "other_id", "other_source", "new_source_version", "other_label_record", "wrong_hash", "modified_excerpt", "stale", "wrong_market", "us_mission", "coverage_gap"])
def test_id_hash_full_condition_source_market_freshness_and_coverage_stay_strict(recorded, mutation):
    mission, envelope = recorded
    answer = envelope["data"]["answers"][0]
    citation = next(c for c in answer["citations"] if c["source_id"] == EU_OPERATOR_REFERENCE)
    record = next(r for r in mission["knowledge"]["records"] if r["id"] == EU_OPERATOR_REFERENCE)
    if mutation == "short_quote":
        citation["quote_original"] = "if that operator is not established in the Union, the importer into the Union market."
    elif mutation == "other_id":
        record["id"] = citation["source_id"] = "EU_UNREVIEWED_COPY"
    elif mutation == "other_source":
        record["source_id"] = "another-page"
    elif mutation == "new_source_version":
        record["source_version"] = 2
    elif mutation == "other_label_record":
        other = next(r for r in mission["knowledge"]["records"] if r["id"].startswith("EU_LABEL_MANDATORY_CORE"))
        citation.update(source_id=other["id"], quote_original=other["excerpt"])
    elif mutation == "wrong_hash":
        record["excerpt_sha256"] = "0" * 64
    elif mutation == "modified_excerpt":
        record["excerpt"] += " This additional rule is not part of Article 8."
        record["excerpt_sha256"] = hashlib.sha256(record["excerpt"].encode()).hexdigest()
        citation["quote_original"] = record["excerpt"]
    elif mutation == "stale":
        record.update(reusable=False, freshness_state="needs_revalidation")
    elif mutation == "wrong_market":
        record["scope"]["jurisdiction"] = "US"
    elif mutation == "us_mission":
        mission["market"]["code"] = "US"
    else:
        mission["knowledge"]["coverage"].update(supported=["food_label"], missing=["facility_registration"])
    with pytest.raises(CoreError):
        validate_research(envelope, mission)


def test_default_standalone_citation_guard_does_not_grant_cross_topic_access(recorded):
    mission, envelope = recorded
    citation = next(c for c in envelope["data"]["answers"][0]["citations"] if c["source_id"] == EU_OPERATOR_REFERENCE)
    with pytest.raises(CoreError):
        validate_citation(citation["source_id"], records=mission["knowledge"]["records"],
            outcome_id="registration", quote_original=citation["quote_original"], expected_market_code="DE")
