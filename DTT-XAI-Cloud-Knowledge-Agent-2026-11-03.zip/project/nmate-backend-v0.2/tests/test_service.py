"""Independent SQLite service-boundary tests for the local developer preview.

These exercise the actual Store transaction/lease implementation, not a mock
database. They do not assert production identity/RLS or legal source approval.
ResearchService orchestration uses controlled async graphs to exercise real
durable state changes. The graph/source suite separately tests LangGraph/fetch.
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from types import SimpleNamespace

import pytest

from nmate.models import AppError, CaseCreate, Principal
from nmate.config import Settings
from nmate.models import StartInput
from nmate.service import ResearchService
from nmate.store import Store, digest


@pytest.fixture
def principal():
    return Principal("tenant-a", "business-a", "business")


@pytest.fixture
def foreign():
    return Principal("tenant-b", "business-b", "business")


@pytest.fixture
def store(tmp_path):
    return Store(tmp_path / "business.sqlite3")


def case_data(**changes):
    data = CaseCreate.model_validate({
        "product": {"sku": "DRY-001", "name": "Miến dong khô mẫu"},
        "consent_research": True,
        "consent_model": False,
    }).model_dump(mode="json")
    for key, value in changes.items():
        if key in ("product", "shipment"):
            data[key].update(value)
        else:
            data[key] = value
    # Use the validated public model to supply all scope/default fields.
    return CaseCreate.model_validate(data).model_dump(mode="json")


def arguments(case, key="request-key-0001", question="Cần chuẩn bị gì cho lô thử?"):
    return {
        "case_id": case["case_id"],
        "expected_case_version": case["version"],
        "idempotency_key": key,
        "question": question,
    }


def start(store, principal, case, key="request-key-0001", *, mode="evidence_only", **limits):
    return store.start(
        principal, arguments(case, key), mode=mode,
        max_active=limits.get("max_active", 5), max_daily=limits.get("max_daily", 30),
    )


def assert_code(code, operation, *args, **kwargs):
    with pytest.raises(AppError) as caught:
        operation(*args, **kwargs)
    assert caught.value.code == code
    return caught.value


def count(store, table, where="", params=()):
    assert table in {"cases", "runs", "artifacts", "audit"}
    with store.connection() as db:
        return db.execute(f"SELECT COUNT(*) FROM {table} {where}", params).fetchone()[0]


def claimed(store, principal, case, owner="worker-a", key="request-key-0001", **kwargs):
    run = start(store, principal, case, key, **kwargs)
    lease = store.claim(owner)
    assert lease["run_id"] == run["run_id"]
    return run


def test_case_defaults_and_durability(store, principal):
    case = store.create_case(principal, case_data())
    reopened = Store(store.path)
    assert reopened.get_case(principal, case["case_id"]) == case
    assert case["version"] == 1
    assert case["shipment"]["target_market"] == "US"
    assert case["product"]["origin_country"] == "VN"
    assert count(store, "audit", "WHERE action='case.create'") == 1


@pytest.mark.parametrize("operation", ["create", "replace"])
def test_research_role_cannot_confirm_or_replace_profile(store, principal, operation):
    case = store.create_case(principal, case_data())
    agent = Principal(principal.tenant_id, "agent", "research")
    if operation == "create":
        assert_code("FORBIDDEN", store.create_case, agent, case_data())
    else:
        assert_code("FORBIDDEN", store.replace_case, agent, case["case_id"], 1, case_data())
    assert count(store, "cases") == 1
    assert store.get_case(principal, case["case_id"])["version"] == 1


@pytest.mark.parametrize("operation", ["get", "replace", "start"])
def test_foreign_tenant_cannot_address_a_case(store, principal, foreign, operation):
    case = store.create_case(principal, case_data())
    if operation == "get":
        error = assert_code("NOT_FOUND", store.get_case, foreign, case["case_id"])
    elif operation == "replace":
        error = assert_code("NOT_FOUND", store.replace_case, foreign, case["case_id"], 1, case_data())
    else:
        error = assert_code("NOT_FOUND", start, store, foreign, case)
    assert error.status == 404
    assert count(store, "runs") == 0
    assert store.get_case(principal, case["case_id"]) == case


def test_case_update_requires_current_version_and_keeps_created_at(store, principal):
    case = store.create_case(principal, case_data())
    updated = store.replace_case(
        principal, case["case_id"], 1, case_data(product={"packaging": "250 g/gói"}),
    )
    assert updated["version"] == 2
    assert updated["created_at"] == case["created_at"]
    assert_code("VERSION_CONFLICT", store.replace_case, principal, case["case_id"], 1, case_data())
    assert store.get_case(principal, case["case_id"]) == updated
    assert count(store, "audit", "WHERE action='case.replace'") == 1


def test_start_preserves_input_snapshot_and_question(store, principal):
    case = store.create_case(principal, case_data())
    args = arguments(case, question="Rà giúp phần importer còn thiếu")
    run = store.start(principal, args, mode="evidence_only", max_active=5, max_daily=30)
    store.replace_case(principal, case["case_id"], 1, case_data(product={"name": "Tên đã đổi"}))
    durable = Store(store.path).get_run(principal, run["run_id"])
    assert durable["snapshot"] == case
    assert durable["question"] == args["question"]
    assert durable["profile_version"] == 1
    assert durable["status"] == "queued"


def test_identical_start_is_one_durable_run_and_one_start_audit(store, principal):
    case = store.create_case(principal, case_data())
    first = start(store, principal, case)
    second = start(Store(store.path), principal, case)
    assert second == first
    assert count(store, "runs") == 1
    assert count(store, "audit", "WHERE action='research.start'") == 1


def test_same_idempotency_key_with_changed_question_is_rejected(store, principal):
    case = store.create_case(principal, case_data())
    start(store, principal, case)
    args = arguments(case, question="Một câu hỏi khác")
    assert_code(
        "IDEMPOTENCY_CONFLICT", store.start, principal, args,
        mode="evidence_only", max_active=5, max_daily=30,
    )
    assert count(store, "runs") == 1


def test_same_idempotency_key_with_changed_model_mode_is_rejected(store, principal):
    case = store.create_case(principal, case_data(consent_model=True))
    start(store, principal, case)
    assert_code("IDEMPOTENCY_CONFLICT", start, store, principal, case, mode="llm")


def test_concurrent_identical_start_commits_once(store, principal):
    case = store.create_case(principal, case_data())
    with ThreadPoolExecutor(max_workers=8) as pool:
        runs = list(pool.map(lambda _: start(Store(store.path), principal, case), range(8)))
    assert len({run["run_id"] for run in runs}) == 1
    assert count(store, "runs") == 1
    assert count(store, "audit", "WHERE action='research.start'") == 1


def test_idempotency_key_is_not_global_between_cases_or_tenants(store, principal, foreign):
    a = store.create_case(principal, case_data())
    b = store.create_case(principal, case_data(product={"sku": "DRY-002"}))
    c = store.create_case(foreign, case_data())
    runs = [start(store, p, case) for p, case in [(principal, a), (principal, b), (foreign, c)]]
    assert len({run["run_id"] for run in runs}) == 3


def test_new_start_cannot_use_a_stale_case_version(store, principal):
    case = store.create_case(principal, case_data())
    store.replace_case(principal, case["case_id"], 1, case_data())
    assert_code("VERSION_CONFLICT", start, store, principal, case)
    assert count(store, "runs") == 0


@pytest.mark.parametrize("change,code", [
    ({"product": {"family": "wood"}}, "OUT_OF_SCOPE"),
    ({"product": {"origin_country": "TH"}}, "OUT_OF_SCOPE"),
    ({"shipment": {"target_market": "EU"}}, "OUT_OF_SCOPE"),
    ({"shipment": {"route": "marketplace"}}, "OUT_OF_SCOPE"),
    ({"consent_research": False}, "CONSENT_REQUIRED"),
])
def test_scope_and_consent_block_before_enqueue(store, principal, change, code):
    case = store.create_case(principal, case_data(**change))
    assert_code(code, start, store, principal, case)
    assert count(store, "runs") == 0


def test_llm_mode_requires_separate_model_consent(store, principal):
    case = store.create_case(principal, case_data())
    assert_code("MODEL_CONSENT_REQUIRED", start, store, principal, case, mode="llm")
    assert count(store, "runs") == 0
    assert start(store, principal, case)["mode"] == "evidence_only"


def test_machine_active_limit_is_enforced_transactionally(store, principal):
    case = store.create_case(principal, case_data())
    start(store, principal, case, "active-first-key", max_active=1)
    other_case = store.create_case(principal, case_data())
    error = assert_code("RUN_LIMIT", start, store, principal, other_case, "active-second-key", max_active=1)
    assert error.status == 429
    assert count(store, "runs") == 1


def test_daily_limit_includes_cancelled_runs(store, principal):
    case = store.create_case(principal, case_data())
    first = start(store, principal, case, "daily-first-key", max_daily=1)
    store.cancel(principal, first["run_id"])
    assert_code("RUN_LIMIT", start, store, principal, case, "daily-second-key", max_daily=1)


def test_concurrent_claim_has_one_owner_and_no_tenant_leak_in_client_dto(store, principal):
    case = store.create_case(principal, case_data())
    run = start(store, principal, case)
    with ThreadPoolExecutor(max_workers=4) as pool:
        leases = list(pool.map(lambda i: Store(store.path).claim(f"worker-{i}"), range(4)))
    active = [lease for lease in leases if lease is not None]
    assert len(active) == 1
    assert active[0]["tenant_id"] == principal.tenant_id
    assert "tenant_id" not in store.get_run(principal, run["run_id"])


@pytest.mark.parametrize("operation", ["read", "cancel", "artifact"])
def test_foreign_tenant_cannot_read_or_cancel_result(store, principal, foreign, operation):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.finish(run["run_id"], "worker-a", report={"summary": "Bản chuẩn bị có phần chưa rõ"})
    done = store.get_run(principal, run["run_id"])
    if operation == "read":
        assert_code("NOT_FOUND", store.get_run, foreign, run["run_id"])
    elif operation == "cancel":
        assert_code("NOT_FOUND", store.cancel, foreign, run["run_id"])
    else:
        assert_code("NOT_FOUND", store.get_artifact, foreign, done["artifact_id"])
    assert store.get_run(principal, run["run_id"]) == done


def test_cancel_queued_run_prevents_worker_claim_and_is_idempotent(store, principal):
    case = store.create_case(principal, case_data())
    run = start(store, principal, case)
    first = store.cancel(principal, run["run_id"])
    assert first["status"] == "cancelled"
    assert first["cancel_requested"] is True
    assert store.cancel(principal, run["run_id"]) == first
    assert store.claim("worker-a") is None
    assert count(store, "audit", "WHERE action='research.cancel_requested'") == 1


def test_cancel_running_run_blocks_guard_and_publication(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.cancel(principal, run["run_id"])
    assert_code("RUN_CANCELLED", store.guard, run["run_id"], "worker-a")
    store.finish(run["run_id"], "worker-a", report={"summary": "Không được xuất bản"})
    assert store.get_run(principal, run["run_id"])["status"] == "cancelled"
    assert count(store, "artifacts") == 0


@pytest.mark.parametrize("change,mode", [
    ({"consent_research": False}, "evidence_only"),
    ({"consent_model": False}, "llm"),
    ({"product": {"name": "Dữ kiện mới"}}, "evidence_only"),
])
def test_finish_rechecks_current_consent_and_version_in_transaction(store, principal, change, mode):
    case = store.create_case(principal, case_data(consent_model=True))
    run = claimed(store, principal, case, mode=mode)
    replacement = case_data(consent_model=True)
    for key, value in change.items():
        if isinstance(value, dict):
            replacement[key].update(value)
        else:
            replacement[key] = value
    store.replace_case(principal, case["case_id"], 1, replacement)
    with pytest.raises(AppError):
        store.guard(run["run_id"], "worker-a")
    store.finish(run["run_id"], "worker-a", report={"summary": "Kết quả từ snapshot cũ"})
    result = store.get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"]["code"] == "PROFILE_OR_CONSENT_CHANGED"
    assert count(store, "artifacts") == 0


def test_successful_artifact_is_durable_draft_with_verifiable_content_hash(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    report = {"summary": "Cần xác định importer", "unknowns": ["IOR", "FSVP importer"], "sources": []}
    store.finish(run["run_id"], "worker-a", report=report)
    reopened = Store(store.path)
    result = reopened.get_run(principal, run["run_id"])
    artifact = reopened.get_artifact(principal, result["artifact_id"])
    assert result["status"] == "succeeded"
    assert artifact["report"] == report
    assert artifact["review_status"] == "draft"
    assert artifact["profile_version"] == 1
    assert artifact["stale"] is False
    hashed = deepcopy(artifact)
    expected = hashed.pop("content_sha256")
    hashed.pop("stale")
    assert digest(hashed) == expected


def test_publication_replay_and_cancel_cannot_change_a_succeeded_run(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.finish(run["run_id"], "worker-a", report={"summary": "Bản đầu"})
    initial = store.get_run(principal, run["run_id"])
    store.finish(run["run_id"], "worker-a", report={"summary": "Không được ghi đè"})
    assert store.cancel(principal, run["run_id"]) == initial
    assert count(store, "artifacts") == 1
    assert count(store, "audit", "WHERE action='research.succeeded'") == 1


def test_concurrent_publication_commits_one_artifact_and_terminal_audit(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(
            lambda _: Store(store.path).finish(
                run["run_id"], "worker-a", report={"summary": "Cùng kết quả được giao lại"},
            ),
            range(4),
        ))
    assert store.get_run(principal, run["run_id"])["status"] == "succeeded"
    assert count(store, "artifacts") == 1
    assert count(store, "audit", "WHERE action='research.succeeded'") == 1


def test_only_current_lease_owner_can_finish(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.finish(run["run_id"], "wrong-worker", report={"summary": "Trái lease"})
    assert store.get_run(principal, run["run_id"])["status"] == "running"
    assert count(store, "artifacts") == 0


def test_worker_release_terminally_interrupts_without_paid_resume(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.progress(run["run_id"], "worker-a", stage="retrieving")
    store.release("worker-a")
    reopened = Store(store.path)
    assert reopened.claim("worker-b") is None
    terminal = reopened.get_run(principal, run["run_id"])
    assert terminal["status"] == "failed" and terminal["stage"] == "interrupted"
    assert terminal["error"]["code"] == "RUN_INTERRUPTED" and terminal["snapshot"] == case
    assert_code("LEASE_LOST", store.guard, run["run_id"], "worker-a")
    store.progress(run["run_id"], "worker-a", stage="stale-write")
    store.finish(run["run_id"], "worker-a", report={"summary": "Stale worker"})
    assert reopened.get_run(principal, run["run_id"])["stage"] == "interrupted"
    reopened.finish(run["run_id"], "worker-b", report={"summary": "Worker mới"})
    assert reopened.get_run(principal, run["run_id"])["status"] == "failed"
    assert count(store, "runs") == 1
    assert count(store, "artifacts") == 0


def test_expired_lease_cannot_publish_even_before_another_worker_claims(store, principal, monkeypatch):
    clock = [1000.0]
    monkeypatch.setattr("nmate.store.time.time", lambda: clock[0])
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    clock[0] += 11
    assert_code("LEASE_LOST", store.guard, run["run_id"], "worker-a")
    store.finish(run["run_id"], "worker-a", report={"summary": "Lease hết hạn"})
    assert count(store, "artifacts") == 0
    assert store.claim("worker-b") is None
    assert store.get_run(principal, run["run_id"])["error"]["code"] == "LEASE_EXPIRED"


def test_heartbeat_cannot_resurrect_an_expired_lease(store, principal, monkeypatch):
    clock = [1000.0]
    monkeypatch.setattr("nmate.store.time.time", lambda: clock[0])
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    clock[0] += 11
    store.progress(run["run_id"], "worker-a", stage="late-heartbeat")
    assert_code("LEASE_LOST", store.guard, run["run_id"], "worker-a")
    assert store.claim("worker-b") is None
    assert store.get_run(principal, run["run_id"])["status"] == "failed"


def test_source_or_provider_failure_is_durable_failed_run_without_artifact(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    failure = {"code": "SOURCE_UNAVAILABLE", "message": "Nguồn trả HTTP403; chưa đủ căn cứ."}
    store.finish(run["run_id"], "worker-a", error=failure)
    result = Store(store.path).get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"] == failure
    assert result["artifact_id"] is None
    assert count(store, "artifacts") == 0


def test_artifact_marks_profile_change_without_rewriting_historical_report(store, principal):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    store.finish(run["run_id"], "worker-a", report={"summary": "Bản lịch sử"})
    result = store.get_run(principal, run["run_id"])
    original = store.get_artifact(principal, result["artifact_id"])
    store.replace_case(principal, case["case_id"], 1, case_data(product={"name": "Tên mới"}))
    historical = store.get_artifact(principal, result["artifact_id"])
    assert historical["stale"] is True
    assert historical["report"] == original["report"]
    assert historical["content_sha256"] == original["content_sha256"]


def test_audit_failure_rolls_back_case_write(store, principal, monkeypatch):
    def fail_audit(*_):
        raise RuntimeError("Injected audit write failure")
    monkeypatch.setattr(store, "_audit", fail_audit)
    with pytest.raises(RuntimeError, match="Injected audit"):
        store.create_case(principal, case_data())
    assert count(store, "cases") == 0
    assert count(store, "audit") == 0


def test_audit_failure_rolls_back_artifact_and_terminal_transition(store, principal, monkeypatch):
    case = store.create_case(principal, case_data())
    run = claimed(store, principal, case)
    def fail_audit(*_):
        raise RuntimeError("Injected completion audit failure")
    monkeypatch.setattr(store, "_audit", fail_audit)
    with pytest.raises(RuntimeError, match="Injected completion"):
        store.finish(run["run_id"], "worker-a", report={"summary": "Không được commit một nửa"})
    assert count(store, "artifacts") == 0
    assert store.get_run(principal, run["run_id"])["status"] == "running"


def test_audit_failure_rolls_back_cancel_request(store, principal, monkeypatch):
    case = store.create_case(principal, case_data())
    run = start(store, principal, case)
    def fail_audit(*_):
        raise RuntimeError("Injected cancellation audit failure")
    monkeypatch.setattr(store, "_audit", fail_audit)
    with pytest.raises(RuntimeError, match="Injected cancellation"):
        store.cancel(principal, run["run_id"])
    durable = store.get_run(principal, run["run_id"])
    assert durable["status"] == "queued"
    assert durable["cancel_requested"] is False
    assert store.claim("worker-a")["run_id"] == run["run_id"]


class ControlledGraph:
    """Controlled orchestration collaborator; no claim of real LLM/network execution."""

    def __init__(self, *, values=None, next_nodes=None, failure=None):
        self.values = values or {}
        self.next_nodes = next_nodes if next_nodes is not None else ("research",)
        self.failure = failure
        self.started = asyncio.Event()
        self.proceed = asyncio.Event()
        self.stream_calls = 0
        self.initial = "not_called"
        self.factory_kwargs = None

    def factory(self, _checkpointer, **kwargs):
        self.factory_kwargs = kwargs
        return self

    async def aget_state(self, _config):
        return SimpleNamespace(values=self.values, next=self.next_nodes)

    async def astream(self, initial, _config, *, stream_mode):
        assert stream_mode == "updates"
        self.stream_calls += 1
        self.initial = initial
        self.started.set()
        await self.proceed.wait()
        if self.failure:
            raise self.failure
        self.values = {"report": {"summary": "Bản chuẩn bị; cần người rà", "sources": []}}
        self.next_nodes = ()
        yield {"research": {"status": "complete"}}


def settings_for(tmp_path, **overrides):
    return Settings(
        _env_file=None, data_dir=tmp_path, mode=overrides.pop("mode", "evidence_only"),
        model_provider=overrides.pop("model_provider", "openai"),
        model_name=overrides.pop("model_name", None),
        OPENAI_API_KEY=overrides.pop("OPENAI_API_KEY", None),
        ANTHROPIC_API_KEY=overrides.pop("ANTHROPIC_API_KEY", None), **overrides,
    )


def service_for(store, tmp_path, graph=None, **settings):
    graph = graph or ControlledGraph()
    service = ResearchService(store, settings_for(tmp_path, **settings), None, graph_factory=graph.factory)
    return service, graph


def test_service_public_run_dto_omits_case_snapshot_and_tenant(store, principal, tmp_path):
    service, _ = service_for(store, tmp_path)
    case = store.create_case(principal, case_data())
    result = service.start(principal, StartInput.model_validate(arguments(case)))
    assert "snapshot" not in result
    assert "tenant_id" not in result
    assert result["run_id"] == service.get_run(principal, result["run_id"])["run_id"]
    assert "snapshot" not in service.cancel(principal, result["run_id"])


def test_service_llm_mode_missing_server_config_fails_before_enqueue(store, principal, tmp_path):
    service, _ = service_for(store, tmp_path, mode="llm")
    case = store.create_case(principal, case_data(consent_model=True))
    error = assert_code("MODEL_NOT_CONFIGURED", service.start, principal, StartInput.model_validate(arguments(case)))
    assert error.status == 503
    assert count(store, "runs") == 0


@pytest.mark.asyncio
async def test_service_pins_claude_provider_model_and_key_selection_after_config_switch(
    store, principal, tmp_path,
):
    claude_key = "TEST_ONLY_CLAUDE_PRIVATE_KEY"
    openai_key = "TEST_ONLY_OPENAI_PRIVATE_KEY"
    service, graph = service_for(
        store, tmp_path, mode="llm", model_provider="anthropic", model_name="claude-sonnet-5-5",
        ANTHROPIC_API_KEY=claude_key, OPENAI_API_KEY=openai_key,
    )
    case = store.create_case(principal, case_data(consent_model=True))
    args = StartInput.model_validate(arguments(case))
    run = service.start(principal, args)
    service.settings.model_provider = "openai"
    service.settings.model_name = "unit-reconfigured-model"
    assert_code("IDEMPOTENCY_CONFLICT", service.start, principal, args)
    graph.proceed.set()
    await service.execute_claimed(store.claim(service.owner))
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "succeeded"
    assert result["model_provider"] == graph.factory_kwargs["model_provider"] == "anthropic"
    assert result["model_name"] == graph.factory_kwargs["model_name"] == "claude-sonnet-5-5"
    assert graph.factory_kwargs["api_key"] == claude_key
    artifact = store.get_artifact(principal, result["artifact_id"])
    assert claude_key not in repr(result) + repr(artifact)
    assert openai_key not in repr(result) + repr(artifact)
    with store.connection() as db:
        persisted = repr([tuple(row) for row in db.execute("SELECT * FROM runs").fetchall()])
    assert claude_key not in persisted
    assert openai_key not in persisted


@pytest.mark.asyncio
async def test_service_missing_pinned_claude_key_cannot_fall_back_to_retained_openai_key(
    store, principal, tmp_path,
):
    service, graph = service_for(
        store, tmp_path, mode="llm", model_provider="anthropic", model_name="claude-sonnet-5-5",
        ANTHROPIC_API_KEY="TEST_ONLY_CLAUDE_KEY", OPENAI_API_KEY="TEST_ONLY_RETAINED_OPENAI_KEY",
    )
    case = store.create_case(principal, case_data(consent_model=True))
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    service.settings.anthropic_api_key = None
    service.settings.model_provider = "openai"
    service.settings.model_name = "unit-other-provider"
    graph.proceed.set()
    await service.execute_claimed(store.claim(service.owner))
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"]["code"] == "MODEL_CREDENTIAL_UNAVAILABLE"
    assert graph.factory_kwargs is None
    assert count(store, "artifacts") == 0


@pytest.mark.asyncio
async def test_service_pipeline_publishes_durable_draft_from_authorized_snapshot(store, principal, tmp_path):
    service, graph = service_for(store, tmp_path)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    lease = store.claim(service.owner)
    graph.proceed.set()
    await service.execute_claimed(lease)
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "succeeded"
    assert graph.initial == {"case": case, "question": arguments(case)["question"]}
    assert graph.factory_kwargs["mode"] == "evidence_only"
    assert callable(graph.factory_kwargs["guard"])
    artifact = Store(store.path).get_artifact(principal, result["artifact_id"])
    assert artifact["review_status"] == "draft"
    assert artifact["report"]["summary"] == "Bản chuẩn bị; cần người rà"


@pytest.mark.asyncio
async def test_service_cancel_during_pipeline_does_not_publish(store, principal, tmp_path):
    service, graph = service_for(store, tmp_path)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    execution = asyncio.create_task(service.execute_claimed(store.claim(service.owner)))
    await asyncio.wait_for(graph.started.wait(), timeout=2)
    service.cancel(principal, run["run_id"])
    graph.proceed.set()
    await asyncio.wait_for(execution, timeout=2)
    assert service.get_run(principal, run["run_id"])["status"] == "cancelled"
    assert count(store, "artifacts") == 0


@pytest.mark.asyncio
async def test_service_consent_revoked_while_graph_waits_is_rechecked_before_publish(
    store, principal, tmp_path,
):
    service, graph = service_for(store, tmp_path)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    execution = asyncio.create_task(service.execute_claimed(store.claim(service.owner)))
    await asyncio.wait_for(graph.started.wait(), timeout=2)
    store.replace_case(principal, case["case_id"], 1, case_data(consent_research=False))
    graph.proceed.set()
    await asyncio.wait_for(execution, timeout=2)
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"]["code"] == "PROFILE_OR_CONSENT_CHANGED"
    assert count(store, "artifacts") == 0


@pytest.mark.asyncio
async def test_service_does_not_expose_provider_exception_secret(store, principal, tmp_path, caplog):
    fake_secret = "TEST_ONLY_SDK_SECRET_DO_NOT_EXPOSE"
    graph = ControlledGraph(failure=RuntimeError(fake_secret))
    graph.proceed.set()
    service, _ = service_for(store, tmp_path, graph)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    await service.execute_claimed(store.claim(service.owner))
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"]["code"] == "RESEARCH_FAILED"
    assert fake_secret not in str(result)
    assert fake_secret not in caplog.text
    assert count(store, "artifacts") == 0


@pytest.mark.asyncio
async def test_service_wall_timeout_is_bounded_and_leaves_no_artifact(store, principal, tmp_path):
    service, graph = service_for(store, tmp_path, run_timeout_seconds=1)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    await asyncio.wait_for(service.execute_claimed(store.claim(service.owner)), timeout=4)
    assert graph.started.is_set()
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "failed"
    assert result["error"]["code"] == "RUN_TIMEOUT"
    assert count(store, "artifacts") == 0


@pytest.mark.asyncio
async def test_service_completed_checkpoint_is_published_without_rerunning_graph(store, principal, tmp_path):
    graph = ControlledGraph(values={"report": {"summary": "Checkpoint hoàn thành"}}, next_nodes=())
    service, _ = service_for(store, tmp_path, graph)
    case = store.create_case(principal, case_data())
    run = service.start(principal, StartInput.model_validate(arguments(case)))
    await service.execute_claimed(store.claim(service.owner))
    assert graph.stream_calls == 0
    result = service.get_run(principal, run["run_id"])
    assert result["status"] == "succeeded"
    assert store.get_artifact(principal, result["artifact_id"])["report"] == graph.values["report"]


@pytest.mark.asyncio
async def test_service_shutdown_marks_interrupted_and_new_worker_does_not_resume(store, principal, tmp_path):
    first, graph = service_for(store, tmp_path)
    case = store.create_case(principal, case_data())
    run = first.start(principal, StartInput.model_validate(arguments(case)))
    await first.start_worker()
    await asyncio.wait_for(graph.started.wait(), timeout=2)
    await first.stop_worker()
    terminal = store.get_run(principal, run["run_id"])
    assert terminal["status"] == "failed" and terminal["stage"] == "interrupted"
    assert terminal["error"]["code"] == "RUN_INTERRUPTED"
    assert count(store, "artifacts") == 0
    second, second_graph = service_for(Store(store.path), tmp_path)
    try:
        await second.start_worker()
        await asyncio.sleep(0.05)
        assert not second_graph.started.is_set()
        assert count(store, "runs") == 1 and count(store, "artifacts") == 0
    finally:
        await second.stop_worker()
