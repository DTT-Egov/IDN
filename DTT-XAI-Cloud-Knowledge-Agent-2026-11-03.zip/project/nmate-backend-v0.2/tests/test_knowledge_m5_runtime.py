"""Pinned release contract, actual CLI readiness; no key/network/provider."""
from contextlib import closing
import json,sqlite3,sys
import pytest
from nmate.knowledge_v1.operator import install_on_clone
from nmate.knowledge_v1.operator_m2 import install_m2_on_clone
from nmate.knowledge_v1.operator_m3 import install_m3_on_clone
from nmate.knowledge_v1.operator_m4 import install_m4_on_clone,target_m4_contract
from nmate.main.app import make_main_app
from test_main_runtime_lock import configured_settings

@pytest.mark.parametrize('correct',[True,False])
def test_cli_verifies_explicit_release_contract_before_opening_managed_runtime(tmp_path,monkeypatch,correct):
    from nmate.main import local
    from nmate import config
    from nmate.core_v1.runtime_schema import CONTRACT_PATH
    import uvicorn
    database=tmp_path/'enterprise.sqlite3'
    def forbidden(*a,**kw):pytest.fail('No provider')
    make_main_app(database,request_fn=forbidden,gateway_request_fn=forbidden,refresh_sources=True)
    install_on_clone(database,backup_path=tmp_path/'m1.sqlite');install_m2_on_clone(database,backup_path=tmp_path/'m2.sqlite')
    install_m3_on_clone(database,backup_path=tmp_path/'m3.sqlite');install_m4_on_clone(database,backup_path=tmp_path/'m4.sqlite')
    contract=tmp_path/'contract.json';contract.write_bytes(json.dumps(target_m4_contract()).encode())
    monkeypatch.setattr(config,'Settings',lambda **kw:configured_settings())
    monkeypatch.setattr(sys,'argv',['test-runtime','--data-dir',str(tmp_path),'--port','8044','--schema-contract',str(contract if correct else CONTRACT_PATH)])
    calls=[]
    monkeypatch.setattr(local,'network_guard',lambda: calls.append('network-guard') or {})
    def serve(app,**kwargs):
        calls.append('serve')
        assert app.state.schema_readiness['contract_version']=='nmate-main-20261027-knowledge-m4'
        assert app.state.policy.knowledge is not None
    monkeypatch.setattr(uvicorn,'run',serve)
    with closing(sqlite3.connect(database)) as db:before=list(db.iterdump())
    if correct:local.main();assert calls==['network-guard','serve']
    else:
        with pytest.raises(SystemExit,match='schema'):local.main()
        assert calls==[]
    with closing(sqlite3.connect(database)) as db:assert list(db.iterdump())==before
