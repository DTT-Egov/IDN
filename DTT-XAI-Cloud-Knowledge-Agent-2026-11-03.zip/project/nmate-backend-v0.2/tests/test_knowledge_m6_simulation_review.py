import json
from datetime import datetime, timedelta, timezone
import pytest
from test_knowledge_m3_domain_gateway import domain
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb
from test_knowledge_m6_next_contracts import artifact
from nmate.knowledge_v1.demo_artifacts import schema
from nmate.knowledge_v1.ai_proposals import record_proposal, read_proposal
from nmate.knowledge_v1.simulation_review import SimulationReview
from nmate.v03.core import CoreError


async def typed_drafts(domain):
    g, source, actor, other, scope, _, ref, calls = domain
    invocation = dict(
        mode="operator_approved_batch",
        initiated_by="project_owner_operator",
        on_behalf_of_account_id=actor,
        approval_receipt_id="TEST-NEW-PROFILE",
        execution_profile_policy=dict(
            version="policy-execution/1", tiers=["high"], artifact_contract="policy-demo/1"
        ),
    )
    grant = g.authorize_domain_budget(
        actor,
        scope,
        approval_id="TEST-NEW-PROFILE",
        max_calls=2,
        max_cost_usd=".5",
        per_role={"standard": dict(max_calls=2, max_cost_usd=".25")},
        source_ids=["KB-TEST-A"],
        source_refs=[ref],
        expires_at=(datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
        invocation=invocation,
    )

    async def request(model, body, limit):
        calls.append((model, body, limit))
        kind = body["response_schema"]["properties"]["kind"]["const"]
        return dict(
            text=json.dumps(artifact(kind), ensure_ascii=False),
            model=model,
            stop_reason="end_turn",
            usage=dict(input_tokens=100, output_tokens=100),
        )

    g.request_fn = request
    ids = []
    for slot, kind in [("S3", "overview_faq"), ("S4", "checklist")]:
        result = await g.call_domain_once(
            source_reader=source,
            account_id=actor,
            scope=scope,
            operation_id="TEST-profile-" + slot,
            task_id=slot,
            role="standard",
            purpose="policy_knowledge_build",
            source_refs=[ref],
            output_schema=schema(kind),
            budget_grant_id=grant["id"],
            recipe="policy-knowledge-draft/2",
            execution_tier="high",
        )
        ids.append(record_proposal(source, g, actor, result["attempt_id"])["proposal_id"])
    return ids, SimulationReview(
        source, g, sandbox_id="TEST-review", assignments={(other, actor, scope.policy_id): True}
    )


def review(bundle):
    return dict(
        schema_version="simulated-policy-review/1",
        mode="simulation",
        reviewer_type="ai_agent",
        target_hash=bundle["target_hash"],
        verdict="approved",
        items=[
            dict(
                target_id=n["target_id"],
                verdict="gap_acknowledged",
                evidence_ids=[],
                rationale="Đã ghi rõ thiếu nguồn; không tuyên bố điều kiện bắt buộc.",
                correction="",
            )
            for n in bundle["targets"]
        ],
        unassessed=[],
    )


@pytest.mark.asyncio
async def test_profiles_typed_admission_simulated_review_and_release_use_same_sql_receipts(domain, tmp_path):
    ids, sim = await typed_drafts(domain)
    g, source, actor, other, scope, _, ref, calls = domain
    bundle = sim.bundle(other, ids)
    assert bundle["goal_structure_complete"] and len(calls) == 2
    result = review(bundle)
    saved = sim.submit(other, ids, result, "TEST-review-1")
    assert saved["state"] == "simulation_approved" and saved["production_eligible"] is False
    assert sim.submit(other, ids, result, "TEST-review-1") == saved
    assert sim.status(other, "TEST-review-1") == saved
    released = sim.release(other, "TEST-review-1", "TEST-release-1")
    assert released["state"] == "simulation_released" and released["production_eligible"] is False
    sim.export(other, ids, tmp_path / "handoff")
    assert (tmp_path / "handoff" / "START_HERE.md").exists()
    with g.repo.connection() as db:
        assert db.execute("SELECT count(*) FROM pol_wiki_reviews").fetchone()[0] == 0
        assert db.execute("SELECT count(*) FROM pol_wiki_releases").fetchone()[0] == 0
        assert db.execute("SELECT count(*) FROM kp_wiki_pages").fetchone()[0] == 0
        assert (
            db.execute(
                "SELECT count(*) FROM kp_knowledge_operations WHERE kind LIKE ?", ("simulation_%",)
            ).fetchone()[0]
            == 2
        )
        manifest = json.loads(
            db.execute("SELECT manifest_json FROM core_domain_model_request_manifests LIMIT 1").fetchone()[0]
        )
        assert manifest["contract_version"] == "model-gateway-request/2"
        assert manifest["execution_profile"]["tier"] == "high"
    for pid in ids:
        assert (
            read_proposal(source, g, actor, pid)["payload"]["admission"]["version"] == "proposal-admission/4"
        )
    assert len(calls) == 2


@pytest.mark.asyncio
async def test_simulation_replay_obeys_read_but_does_not_require_current_write(domain):
    ids, sim = await typed_drafts(domain)
    g, source, actor, other, scope, _, ref, calls = domain
    result = review(sim.bundle(other, ids))
    saved = sim.submit(other, ids, result, "TEST-review-2")
    sim.assignments[(other, actor, scope.policy_id)] = False
    assert sim.submit(other, ids, result, "TEST-review-2") == saved
    with pytest.raises(CoreError):
        sim.submit(other, ids, result, "TEST-review-new")
    source.set_source_rights(
        actor,
        "KB-TEST-A",
        expected_version=1,
        allow_read=False,
        allow_export=False,
        reason="TEST revoke",
        operation_id="TEST-sim-read-revoke",
    )
    with pytest.raises(CoreError):
        sim.status(other, "TEST-review-2")
    assert len(calls) == 2


@pytest.mark.asyncio
async def test_review_file_cannot_grant_actor_scope_or_skip_targets(domain):
    ids, sim = await typed_drafts(domain)
    _, _, actor, other, _, _, _, _ = domain
    with pytest.raises(CoreError):
        sim.bundle(actor, ids)
    result = review(sim.bundle(other, ids))
    with pytest.raises(CoreError):
        sim.submit(other, ids, result | {"mode": "production"}, "TEST-fail-mode")
    with pytest.raises(CoreError):
        sim.submit(other, ids, result | {"items": []}, "TEST-fail-coverage")
    with pytest.raises(CoreError):
        sim.submit(other, ids, result | {"target_hash": "0" * 64}, "TEST-fail-hash")


@pytest.mark.asyncio
async def test_authenticated_mcp_review_handoff_has_no_paid_or_production_tools(domain):
    from mcp import Client
    from nmate.v03.mcp import create_mcp, account_context
    from nmate.knowledge_v1.mcp_simulation import NAMES, register_tools

    ids, sim = await typed_drafts(domain)
    g, _, _, other, _, _, _, calls = domain
    server = create_mcp(
        g.repo,
        None,
        extra_register=lambda server, call: register_tools(server, sim, call),
        tool_allowlist=NAMES,
    )
    token = account_context.set(other)
    try:
        async with Client(server, mode="2026-07-28", cache=None) as client:
            definitions = await client.list_tools()
            assert {t.name for t in definitions.tools} == NAMES
            result = await client.call_tool("knowledge_simulation_bundle", {"proposal_ids": ids})
            assert not result.is_error
            value = result.structured_content
            assert value["ok"] and value["data"]["bundle"]["production_eligible"] is False
            assert "START_HERE.md" in value["data"]["files"]
    finally:
        account_context.reset(token)
    assert len(calls) == 2


@pytest.mark.asyncio
async def test_whole_demo_package_can_be_produced_in_one_call(domain):
    g, source, actor, _, scope, _, ref, calls = domain
    ids, sim = await typed_drafts(domain)
    # A distinct approved fixture grant; never reuses a consumed slot or budget.
    grant = g.authorize_domain_budget(
        actor,
        scope,
        approval_id="TEST-PACKAGE",
        max_calls=1,
        max_cost_usd=".25",
        per_role={"standard": dict(max_calls=1, max_cost_usd=".25")},
        source_ids=["KB-TEST-A"],
        source_refs=[ref],
        expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        invocation=dict(
            mode="operator_approved_batch",
            initiated_by="project_owner_operator",
            on_behalf_of_account_id=actor,
            approval_receipt_id="TEST-PACKAGE",
            execution_profile_policy=dict(
                version="policy-execution/1", tiers=["high"], artifact_contract="policy-demo/1"
            ),
        ),
    )
    data = artifact() | dict(kind="demo_package", actions=artifact("checklist")["actions"])

    async def request(model, body, limit):
        calls.append("package")
        return dict(
            model=model,
            stop_reason="end_turn",
            text=json.dumps(data),
            usage=dict(input_tokens=100, output_tokens=100),
        )

    g.request_fn = request
    result = await g.call_domain_once(
        source_reader=source,
        account_id=actor,
        scope=scope,
        operation_id="TEST-package-one",
        task_id="S3",
        role="standard",
        purpose="policy_knowledge_build",
        source_refs=[ref],
        output_schema=schema("demo_package"),
        budget_grant_id=grant["id"],
        recipe="policy-knowledge-package/1",
        execution_tier="high",
    )
    pid = record_proposal(source, g, actor, result["attempt_id"])["proposal_id"]
    assert sim.bundle(domain[3], [pid])["goal_structure_complete"]
    assert len(calls) == 3
