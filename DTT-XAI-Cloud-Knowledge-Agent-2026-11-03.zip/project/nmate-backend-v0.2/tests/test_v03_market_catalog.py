"""Market, source-scope and citation guards: all local, no provider/network calls."""
from copy import deepcopy
import hashlib
import json

import pytest

from nmate.v03 import CoreError, CoreRepository, DomainCatalog, LocalAccounts
from nmate.v03.evidence import bind_answer_citations, validate_citation
from nmate.v03.markets import detect_markets, get_market, market_title


@pytest.fixture
def catalog(tmp_path):
    return DomainCatalog(CoreRepository(tmp_path / "market-catalog.sqlite"))


@pytest.mark.parametrize("text,codes", [
    ("Trà Sen gửi New York, cần nhãn tiếng Anh", ["US"]),
    ("Trà Sen đi Đức (EU), hãy giúp tôi", ["DE"]),
    ("Trà Sen đi Nhật Bản", ["JP"]),
    ("Trà Sen đi EU", ["EU"]),
    ("Tôi ở Việt Nam để chuẩn bị nhãn tiếng Anh", []),
    ("Tôi cần ý kiến và nhãn để bán", []),
    ("Trà Sen đi Brazil", ["OTHER"]),
    ("Trà Sen đi Mỹ và Nhật", ["US", "JP"]),
    ("Trà Sen đi EU và Canada", ["EU", "OTHER"]),
])
def test_destination_detection_never_infers_market_from_vietnamese_fillers(text, codes):
    assert detect_markets(text) == codes


def test_registry_returns_copy_and_titles_cannot_carry_fda_to_other_markets():
    market = get_market("Đức")
    market["jurisdictions"].append("US")
    assert get_market("DE")["jurisdictions"] == ["EU", "DE"]
    assert get_market("JP")["label_language"] == "ja"
    assert "FDA" in market_title("registration", "US")
    assert "FDA" not in market_title("registration", "DE")
    assert "FDA" not in market_title("registration", "JP")
    assert market_title("certification", "JP") == "Đối chiếu chứng nhận cần thiết"
    for value in ("EU", "FR", "Brazil", None, ""):
        with pytest.raises(CoreError) as error:
            get_market(value)
        assert error.value.code == "unsupported_market"


@pytest.mark.parametrize("market,jurisdictions,count", [("US", {"US"}, 8), ("DE", {"DE", "EU"}, 8), ("JP", {"JP"}, 4)])
def test_scope_is_filtered_before_topic_coverage_dependencies_and_reuse_metrics(catalog, market, jurisdictions, count):
    result = catalog.lookup_domain(["registration", "label"], market_code=market, as_of_date="2026-10-18")
    assert len(result["records"]) == count
    assert result["coverage"]["missing"] == []
    assert result["metrics"]["reuse_hits"] == count
    assert result["market_code"] == market
    assert result["model_calls"] == result["network_calls"] == 0
    source_ids = {record["source_id"] for record in result["records"]}
    assert {ref["source_id"] for ref in result["source_refs"]} == source_ids
    for record in result["records"]:
        assert record["scope"]["jurisdiction"] in jurisdictions
        assert record["market_code"] == market
        assert record["excerpt_original"] == record["excerpt"]
        assert record["review_state"] == record["translation_state"] == "reference_unreviewed"
        assert record["authority_state"] == "reference_only"
        assert record["reusable"]
        source = catalog.get_source(record["source_id"])
        assert hashlib.sha256(source["text"].encode()).hexdigest() == record["content_sha256"]
        assert hashlib.sha256(record["excerpt"].encode()).hexdigest() == record["excerpt_sha256"]


@pytest.mark.parametrize("market", ["DE", "JP"])
def test_unsupported_outcomes_never_fall_back_to_us_sources(catalog, market):
    result = catalog.lookup_domain(["prior_notice", "certifications"], market_code=market)
    assert result["records"] == result["source_refs"] == []
    assert result["coverage"]["state"] == "no_support_found"
    assert result["coverage"]["missing"] == ["prior_notice", "certifications"]
    fda_only = catalog.lookup_domain(["fda_registration"], market_code=market)
    assert fda_only["records"] == []
    assert fda_only["coverage"]["missing"] == ["fda_registration"]


def test_catalog_rejects_explicit_unsupported_market_and_invalid_date(catalog):
    with pytest.raises(CoreError) as error:
        catalog.lookup_domain(["food_label"], market_code="FR")
    assert error.value.code == "unsupported_market"
    with pytest.raises(CoreError) as error:
        catalog.lookup_domain(["food_label"], market_code="DE", as_of_date="not-a-date")
    assert error.value.code == "invalid_as_of_date"


def test_reopening_existing_catalog_adds_packs_without_blessing_invalidated_sources(catalog):
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation',version=2 WHERE id='fda_registration'")
    reopened = DomainCatalog(catalog.repo)
    assert not next(record for record in reopened.lookup_domain(["food_label"])["records"]
                    if record["source_id"] == "fda_registration")["reusable"]
    assert all(record["reusable"] for record in reopened.lookup_domain(["food_label"], market_code="DE")["records"])
    with catalog.repo.connection() as db:
        assert db.execute("SELECT count(*) FROM v03_domain_references").fetchone()[0] == 36


@pytest.mark.parametrize("state", ["revoked", "withdrawn", "unknown_state", "needs_revalidation"])
def test_source_withdrawal_or_unknown_freshness_blocks_only_its_market(catalog, state):
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state=? WHERE id='jp_caa_label_language'", (state,))
    japanese = catalog.lookup_domain(["food_label"], market_code="JP")
    assert "food_label" in japanese["coverage"]["missing"]
    assert not next(record for record in japanese["records"] if record["source_id"] == "jp_caa_label_language")["reusable"]
    assert catalog.lookup_domain(["food_label"], market_code="US")["coverage"]["missing"] == []
    assert catalog.lookup_domain(["food_label"], market_code="DE")["coverage"]["missing"] == []


def test_review_overdue_is_not_mistaken_for_legal_expiry_or_current_verification(catalog):
    result = catalog.lookup_domain(["food_label"], market_code="DE", as_of_date="2026-11-19")
    assert result["coverage"]["missing"] == ["food_label"]
    assert all(not record["reusable"] and record["applicability_state"] == "review_overdue" for record in result["records"])
    assert all(record["valid_until"] is None for record in result["records"])


def test_foreign_record_is_rejected_even_if_id_quote_hash_topic_and_reuse_are_valid(catalog):
    us = catalog.lookup_domain(["food_label"], market_code="US")["records"]
    answer = {"outcome_id": "label", "status": "artifact_ready", "source_ids": [us[0]["id"]]}
    with pytest.raises(CoreError) as error:
        bind_answer_citations([answer], us, expected_market_code="DE")
    assert error.value.code == "evidence_market_mismatch"


def test_japanese_original_uses_language_neutral_quote_without_english_alias(catalog):
    records = catalog.lookup_domain(["facility_registration"], market_code="JP")["records"]
    japanese = next(record for record in records if record["original_language"] == "ja")
    quote = japanese["excerpt"]
    citation = validate_citation(japanese["id"], records=records, outcome_id="registration",
                                 quote_original=quote, expected_market_code="JP")
    assert citation["quote_original"] == quote and citation["original_language"] == "ja"
    assert "quote_en" not in citation
    with pytest.raises(CoreError):
        validate_citation(japanese["id"], records=records, outcome_id="registration",
                          quote_original=japanese["excerpt_vi"], expected_market_code="JP")


@pytest.mark.parametrize("mutation", ["future", "expired", "withdrawn", "hash", "quote", "missing_scope"])
def test_temporal_and_original_text_guards_are_not_relaxed_for_new_markets(catalog, mutation):
    item = deepcopy(catalog.lookup_domain(["food_label"], market_code="DE")["records"][0])
    quote = item["excerpt"]
    if mutation == "future":
        item["valid_from"] = "2026-10-20"
    elif mutation == "expired":
        item["valid_until"] = "2026-10-17"
    elif mutation == "withdrawn":
        item["review_state"] = "withdrawn"
    elif mutation == "hash":
        item["excerpt_sha256"] = "0" * 64
    elif mutation == "quote":
        quote = item["excerpt_vi"]
    elif mutation == "missing_scope":
        del item["scope"]
    with pytest.raises(CoreError):
        validate_citation(item["id"], records=[item], outcome_id="label", quote_original=quote,
                          expected_market_code="DE", as_of_date="2026-10-18")


def test_revoked_reference_cannot_regain_reuse_by_reopening_pack(catalog):
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_references SET review_state='revoked' WHERE id='DE_LABEL_LANGUAGE_VI_20261018_DRAFT'")
    reopened = DomainCatalog(catalog.repo)
    record = next(record for record in reopened.lookup_domain(["food_label"], market_code="DE")["records"]
                  if record["id"] == "DE_LABEL_LANGUAGE_VI_20261018_DRAFT")
    assert not record["reusable"] and record["review_state"] == "revoked"
    with pytest.raises(CoreError):
        validate_citation(record["id"], records=[record], outcome_id="label", quote_original=record["excerpt"], expected_market_code="DE")


def test_later_market_row_cannot_turn_us_reference_into_japanese_coverage(catalog):
    with catalog.repo.connection(write=True) as db:
        row = db.execute("SELECT record_json FROM v03_domain_references WHERE id='FDA_LABEL_CORE_VI_20261018_DRAFT'").fetchone()
        record = json.loads(row[0])
        record["market_code"] = "JP"  # Display metadata is not the authoritative scope.
        db.execute("UPDATE v03_domain_references SET record_json=? WHERE id=?", (json.dumps(record), record["id"]))
    result = catalog.lookup_domain(["food_label"], market_code="JP")
    assert all(record["id"] != "FDA_LABEL_CORE_VI_20261018_DRAFT" for record in result["records"])


def test_observing_old_or_new_hash_never_hides_source_revocation(catalog):
    owner = LocalAccounts(catalog.repo).register("source-owner", "correct-password", "Sen")
    source = catalog.get_source("jp_caa_label_language")
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='revoked' WHERE id=?", (source["id"],))
    for operation_id, observed_hash in (("same", source["content_sha256"]), ("different", "0" * 64)):
        result = catalog.observe_source(owner["account_id"], owner["enterprise_id"], source["id"], observed_hash, operation_id)
        assert result["freshness_state"] == "revoked"
        assert catalog.get_source(source["id"])["freshness_state"] == "revoked"
    assert all(not record["reusable"] for record in catalog.lookup_domain(["food_label"], market_code="JP")["records"]
               if record["source_id"] == source["id"])


def test_known_unusable_record_remains_coverage_gap_without_becoming_new_plan_dependency(catalog):
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET freshness_state='needs_revalidation',version=2,invalidated_at='2026-10-18T12:00:00+00:00' WHERE id='jp_mhlw_notification_20261019_v1'")
    result = catalog.lookup_domain(["facility_registration", "food_label"], market_code="JP")
    bad = next(record for record in result["records"] if record["source_id"] == "jp_mhlw_notification_20261019_v1")
    assert bad["reusable"] is False
    assert "facility_registration" in result["coverage"]["missing"]
    assert {ref["source_id"] for ref in result["source_refs"]} == {record["source_id"] for record in result["records"] if record["reusable"] is True}
    assert all(ref["source_id"] != "jp_mhlw_notification_20261019_v1" for ref in result["source_refs"])


def test_another_usable_record_from_same_source_still_binds_source_dependency(catalog):
    with catalog.repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_references SET review_state='revoked' WHERE id='FDA_LABEL_ENGLISH_VI_20261018_DRAFT'")
    result = catalog.lookup_domain(["facility_registration", "food_label"], market_code="US")
    assert any(record["source_id"] == "fda_registration" and record["reusable"] is True for record in result["records"])
    assert any(record["source_id"] == "fda_registration" and record["reusable"] is False for record in result["records"])
    assert any(ref["source_id"] == "fda_registration" for ref in result["source_refs"])
