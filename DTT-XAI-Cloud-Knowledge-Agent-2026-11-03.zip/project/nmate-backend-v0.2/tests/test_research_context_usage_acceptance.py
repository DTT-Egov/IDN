"""Independent query-contract acceptance for research snapshot vs current SSOT.

No provider result is simulated: no model may be called at all. A local bounded
mission is prepared through its normal service, then read through the main app's
actual mission projection.
"""
from __future__ import annotations

import copy
import socket

import pytest

from nmate.main.app import MainMissions
from nmate.main.provider import MainProvider
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from test_review_architecture_acceptance import data_snapshot


@pytest.fixture(autouse=True)
def no_external_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Research metadata reads cannot use network or a model")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


@pytest.fixture
def plan(tmp_path):
    repo = CoreRepository(tmp_path / "research-usage.sqlite3")
    owner = LocalAccounts(repo).register("usage-owner", "Local-only-usage-password", "Trà Sen QA")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    product = repo.create_entity(account, enterprise, "product", "Trà Sen QA")
    saved = repo.propose_or_apply_facts(account, enterprise, product["id"], [
        {"field": "name", "value": "Trà Sen QA"},
        {"field": "net_quantity", "value": "100 g"},
        {"field": "packaging", "value": "hộp"},
        {"field": "product_code", "value": "TSQA01"},
    ], product["version"], "usage-initial-four-facts")
    bounded = MissionService(repo)
    mission = bounded.prepare(account, enterprise,
        "Trà Sen QA xuất khẩu sang Mỹ có phải đăng ký cơ sở FDA không và nhãn thực phẩm cần gì?",
        "usage-local-plan", product["id"], market_code="US")
    calls = []

    async def no_model(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("No model request is authorized for metadata queries")

    provider = MainProvider(repo, request_fn=no_model)
    main = MainMissions(repo, model_call=provider)
    return repo, owner, product, saved, mission, main, calls


def read(plan):
    _repo, owner, _product, _saved, mission, main, _calls = plan
    return main.get(owner["account_id"], owner["enterprise_id"], mission["id"])


def test_current_four_and_plan_three_are_explained_without_changing_either(plan):
    repo, _owner, _product, _saved, original, _main, calls = plan
    historical = copy.deepcopy(original["context"])
    before = data_snapshot(repo)
    view = read(plan)
    usage = view["context_usage"]
    assert usage["schema_version"] == "mission-context-usage/1"
    assert usage["current_product_confirmed_fact_count"] == 4
    assert usage["plan_product_fact_count"] == 3
    assert usage["plan_shared_fact_count"] == 3
    assert usage["omitted_current_field_keys"] == ["product_code"]
    assert usage["snapshot_context_revision"] == usage["current_context_revision"]
    assert usage["snapshot_product_version"] == usage["current_product_version"]
    assert usage["context_revision_changed"] is False
    assert view["context"] == historical
    assert view["status"] == "planned"
    assert read(plan)["context_usage"] == usage
    assert data_snapshot(repo) == before
    assert calls == []


def test_later_ssot_change_updates_current_usage_and_preserves_historical_plan(plan):
    repo, owner, product, saved, original, _main, calls = plan
    historical = copy.deepcopy(original["context"])
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"],
        [{"field": "net_quantity", "value": "200 g"}], saved["version"], "usage-later-correction")
    before = data_snapshot(repo)
    view = read(plan)
    usage = view["context_usage"]
    assert usage["current_product_confirmed_fact_count"] == 4
    assert usage["plan_product_fact_count"] == 3
    assert usage["context_revision_changed"] is True
    assert usage["current_context_revision"] > usage["snapshot_context_revision"]
    assert usage["current_product_version"] > usage["snapshot_product_version"]
    assert view["context"] == historical
    assert view["status"] == "needs_revalidation"
    assert data_snapshot(repo) == before
    assert calls == []


def test_research_role_comes_from_main_provider_without_dispatch(plan):
    repo, _owner, _product, _saved, original, _main, calls = plan
    assert len(original["intent"]["outcomes"]) == 2
    before = data_snapshot(repo)
    requirement = read(plan)["research_model_requirement"]
    assert requirement == {"purpose": "legacy_research", "role": "complex", "model": "claude-opus-5-5"}
    assert data_snapshot(repo) == before
    assert calls == []
