"""Legacy MCP facility edits have a separate canonical entity and CAS lineage."""
import pytest

from nmate.v03.core import CoreError
from test_ssot_field_scope import legacy_fact
from test_v03_continuity import setup as setup, complete, save, args, values, THREE


FACILITY = [{"field": "facility_activity", "value": "Đóng gói trà"},
            {"field": "facility_type", "value": "Cơ sở sản xuất tại Việt Nam"}]


def test_owner_facility_confirmation_has_real_entity_refs_and_keeps_product_history_clean(setup):
    repo, owner, _, service = setup
    original = save(service, owner, complete(service, owner))
    product_id = original["product"]["entity_id"]
    before_version = original["product"]["version"]
    history_before = repo.get_fact_history(*args(owner), product_id)
    assert repo.list_entities(*args(owner), "facility") == []
    assert service.get(*args(owner), original["id"])["current_context"]["facility_binding"]["entity_id"] is None
    assert repo.list_entities(*args(owner), "facility") == []  # no entity on GET

    changed = service.update_facts(*args(owner), original["id"], FACILITY, before_version, "confirm-facility")
    assert changed["status"] == "needs_revalidation"
    facility = repo.list_entities(*args(owner), "facility")[0]
    assert facility["parent_entity_id"] == product_id
    assert {fact["field"] for fact in facility["facts"]} == {"facility_activity", "facility_type"}
    assert repo.get_fact_history(*args(owner), product_id) == history_before
    product = repo.get_entity(*args(owner), product_id)
    assert not any(fact["field"].startswith("facility_") for fact in product["facts"])
    assert product["version"] > before_version  # aggregate CAS, no fabricated fact
    assert changed["current_context"]["facility_binding"] == {"product_entity_id": product_id, "entity_id": facility["id"]}
    refs = [ref for ref in changed["current_context"]["fact_refs"] if ref["field"].startswith("facility_")]
    assert len(refs) == 4 and all(ref["entity_id"] == facility["id"] for ref in refs)
    assert all(ref["assertion_id"] for ref in refs if ref["field"] in {"facility_activity", "facility_type"})
    assert {key: values(changed)[key] for key in THREE} == THREE
    assert not changed["label"]["conflicts"]

    repeated = service.update_facts(*args(owner), original["id"], FACILITY, before_version, "confirm-facility")
    assert repeated["product"]["version"] == changed["product"]["version"]
    assert len(repo.list_entities(*args(owner), "facility")) == 1
    with pytest.raises(CoreError) as stale:
        service.update_facts(*args(owner), original["id"], FACILITY, before_version, "different-operation")
    assert stale.value.code == "version_conflict"
    assert repo.get_fact_history(*args(owner), product_id) == history_before
    continued = complete(service, owner, "facility-continued", "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", parent=original["id"])
    assert {key: values(continued)[key] for key in THREE} == THREE
    assert continued["label"]["parent_artifact_ref"]["artifact_id"] == original["label"]["id"]
    assert continued["label"]["parent_artifact_ref"]["version"] == original["label"]["version"]


def test_direct_facility_fact_edit_advances_legacy_product_cas_without_product_assertions(setup):
    repo, owner, _, service = setup
    original = complete(service, owner)
    changed = service.update_facts(*args(owner), original["id"], FACILITY, original["product"]["version"], "first-facility")
    product_id = original["product"]["entity_id"]
    facility = repo.list_entities(*args(owner), "facility")[0]
    product_history = repo.get_fact_history(*args(owner), product_id)
    repo.propose_or_apply_facts(*args(owner), facility["id"], [{"field": "facility_address", "value": "Hà Nội"}],
                                facility["version"], "direct-facility-address")
    with pytest.raises(CoreError) as stale:
        service.update_facts(*args(owner), original["id"], FACILITY, changed["product"]["version"], "old-dossier-edit")
    assert stale.value.code == "version_conflict"
    assert repo.get_fact_history(*args(owner), product_id) == product_history


def test_prepare_never_moves_or_creates_facility_from_legacy_wrong_scope_facts(setup):
    repo, owner, _, service = setup
    original = complete(service, owner)
    product_id = original["product"]["entity_id"]
    legacy_fact(repo, owner, product_id, "facility_activity", "OLD WRONG-SCOPE ACTIVITY")
    legacy_fact(repo, owner, product_id, "facility_address", "OLD WRONG-SCOPE ADDRESS")
    history_before = repo.get_fact_history(*args(owner), product_id)
    fresh = service.prepare(*args(owner), "Trà Sen Tây Hồ gửi Mỹ cần đăng ký cơ sở FDA không?", "read-legacy-facility", product_id)
    assert fresh["context"]["facility_values"] == {}
    assert repo.list_entities(*args(owner), "facility") == []
    assert "OLD WRONG-SCOPE" not in str(fresh["context"])
    assert repo.get_fact_history(*args(owner), product_id) == history_before
    changed = service.update_facts(*args(owner), fresh["id"], FACILITY, fresh["product"]["version"], "owner-new-facility")
    assert changed["current_context"]["facility_values"]["facility_activity"] == "Đóng gói trà"
    assert "facility_address" not in changed["current_context"]["facility_values"]
    assert repo.get_fact_history(*args(owner), product_id) == history_before


def test_multiple_explicit_facilities_are_not_merged_or_silently_selected(setup):
    repo, owner, _, service = setup
    original = complete(service, owner)
    product_id = original["product"]["entity_id"]
    first = repo.create_entity(*args(owner), "facility", "Cơ sở A", parent_entity_id=product_id)
    second = repo.create_entity(*args(owner), "facility", "Cơ sở B", parent_entity_id=product_id)
    with pytest.raises(CoreError) as ambiguous:
        service.get(*args(owner), original["id"])
    assert ambiguous.value.code == "facility_selection_required"
    assert {entity["id"] for entity in repo.list_entities(*args(owner), "facility")} == {first["id"], second["id"]}
    assert all(entity["facts"] == [] for entity in repo.list_entities(*args(owner), "facility"))


def test_mixed_write_rolls_back_product_and_new_facility_on_duplicate_facility_field(setup):
    repo, owner, _, service = setup
    original = complete(service, owner)
    product_id = original["product"]["entity_id"]
    history_before = repo.get_fact_history(*args(owner), product_id)
    with pytest.raises(CoreError) as conflict:
        service.update_facts(*args(owner), original["id"], [{"field": "ingredients", "value": "Trà xanh"},
            *FACILITY, {"field": "facility_type", "value": "Different"}], original["product"]["version"], "bad-mixed-save")
    assert conflict.value.code == "duplicate_field"
    assert repo.list_entities(*args(owner), "facility") == []
    assert repo.get_fact_history(*args(owner), product_id) == history_before
    assert repo.get_entity(*args(owner), product_id)["version"] == original["product"]["version"]


def test_facility_context_uses_only_explicit_product_binding_and_remains_private(setup):
    repo, owner, other, service = setup
    original = complete(service, owner)
    unrelated = repo.create_entity(*args(owner), "product", "Sản phẩm khác")
    unrelated_facility = repo.create_entity(*args(owner), "facility", "Cơ sở sản phẩm khác", parent_entity_id=unrelated["id"])
    repo.propose_or_apply_facts(*args(owner), unrelated_facility["id"], FACILITY, 0, "unrelated-facts")
    current = service.get(*args(owner), original["id"])["current_context"]
    assert current["facility_values"] == {} and current["facility_binding"]["entity_id"] is None
    with pytest.raises(CoreError):
        service._context(*args(other), original["product"]["entity_id"])
