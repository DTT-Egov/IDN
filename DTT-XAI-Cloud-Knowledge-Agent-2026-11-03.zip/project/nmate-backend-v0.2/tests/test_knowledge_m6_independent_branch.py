import json
import pytest
from test_knowledge_m6_worker import batch
from test_knowledge_m1 import kb
from nmate.knowledge_v1 import worker_m6
from nmate.knowledge_v1.public_batch import existing_repository
from nmate.v03.core import CoreError


async def failed_o1(batch):
    folder, prepared, grant, request, calls = batch

    async def provider(model, body, limit):
        if len(calls) == 4:
            calls.append("O1")
            return dict(
                text='{"bad":',
                model=model,
                stop_reason="max_tokens",
                usage=dict(input_tokens=100, output_tokens=limit),
            )
        return await request(model, body, limit)

    await worker_m6.run_once(folder, request_fn=provider, max_new_calls=6)
    return worker_m6.snapshot(folder)


@pytest.mark.asyncio
async def test_independent_o2_keeps_o1_failed_and_never_refunds_or_retries(batch):
    from nmate.knowledge_v1.independent_branch import preview, continue_independent

    folder, prepared, grant, request, calls = batch
    before = await failed_o1(batch)
    assert before["blocked_slots"] == ["O1"] and len(calls) == 5
    decision = preview(folder, "TEST-explicit-O2")
    receipt = continue_independent(folder, decision)
    assert continue_independent(folder, decision) == receipt
    assert worker_m6.snapshot(folder)["next_slot"] == "O2"
    await worker_m6.run_once(folder, request_fn=request, max_new_calls=6)
    status = worker_m6.snapshot(folder)
    assert status["blocked_slots"] == ["O1"] and status["batch_completion"] == "partially_complete"
    assert status["completed_slots"] == ["S1", "S2", "S3", "S4", "O2"] and len(calls) == 6
    assert status["known_estimated_microusd"] > before["known_estimated_microusd"]
    assert continue_independent(folder, decision) == receipt
    await worker_m6.run_once(folder, request_fn=request)
    assert len(calls) == 6


@pytest.mark.asyncio
async def test_continuation_requires_exact_decision_and_usage_known(batch):
    from nmate.knowledge_v1.independent_branch import preview, continue_independent

    folder, prepared, _, _, calls = batch
    await failed_o1(batch)
    decision = preview(folder, "TEST-cas")
    for change in (
        {"target_slot": "O1"},
        {"no_retry": 1},
        {"expected_lifecycle_ref": {}},
        {"corpus_hash": "0" * 64},
    ):
        with pytest.raises(CoreError):
            continue_independent(folder, decision | change)
    repo = existing_repository(prepared)
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_domain_model_attempts SET actual_microusd=NULL WHERE task_id='S1'")
    with pytest.raises(CoreError):
        continue_independent(folder, decision)
    assert len(calls) == 5
