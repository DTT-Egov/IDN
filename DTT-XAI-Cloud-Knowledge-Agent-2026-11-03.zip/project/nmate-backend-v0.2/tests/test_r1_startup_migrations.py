"""DF-041 schema lifecycle failure/resume/restore, disposable DBs only."""
from contextlib import closing
from pathlib import Path
import json
import sqlite3
import subprocess
import sys

import pytest

from nmate.core_v1.runtime_schema import verify_runtime_database
from nmate.core_v1.schema_lifecycle import (
    LEDGER, SchemaLifecycleError, apply_plan, backup_database, create_plan,
    initialize_new_database, main, restore_database,
)
from nmate.main.runtime_lock import EnterpriseRuntimeLock, RuntimeAlreadyRunning


@pytest.fixture
def simple(tmp_path):
    path = tmp_path / "fixture.sqlite3"
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE business(id TEXT PRIMARY KEY, value TEXT NOT NULL)")
        db.execute("INSERT INTO business VALUES('original','never-change')")
    dependency = tmp_path / "dependency.txt"
    dependency.write_text("known-source-v1\n", encoding="utf8")
    plan = create_plan(path, version="fixture-1", statements=["CREATE TABLE new_schema(id TEXT PRIMARY KEY)"],
                       source_root=tmp_path, dependency_files=["dependency.txt"])
    return path, plan


def snapshot(path):
    with sqlite3.connect(path) as db:
        return list(db.iterdump())


def test_dry_run_does_not_change_original_and_source_is_checksummed(simple, tmp_path):
    path, plan = simple
    assert plan["dry_run"] == {"passed": True, "original_writes": 0, "provider_calls": 0}
    assert plan["before_schema_sha256"] != plan["after_schema_sha256"]
    assert plan["source"]["files"]["dependency.txt"]
    assert LEDGER not in "\n".join(snapshot(path))
    before = snapshot(path)
    (tmp_path / "dependency.txt").write_text("changed-helper-v2\n", encoding="utf8")
    with pytest.raises(SchemaLifecycleError, match="dependency"):
        apply_plan(path, plan, source_root=tmp_path)
    assert snapshot(path) == before


def test_apply_repeat_and_lost_external_receipt_return_same_commit(simple, tmp_path):
    path, plan = simple
    class LostResponse(Exception):
        pass
    def lost():
        raise LostResponse()
    with pytest.raises(LostResponse):
        apply_plan(path, plan, source_root=tmp_path, after_commit=lost)
    after = snapshot(path)
    receipt = apply_plan(path, plan, source_root=tmp_path)
    assert receipt["plan_sha256"] == plan["plan_sha256"]
    assert receipt["business_data_writes"] == receipt["provider_calls"] == 0
    assert apply_plan(path, plan, source_root=tmp_path) == receipt
    assert snapshot(path) == after
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT * FROM business").fetchall() == [("original", "never-change")]
        assert db.execute(f"SELECT COUNT(*) FROM {LEDGER}").fetchone()[0] == 1


def test_interruption_rolls_back_ddl_and_receipt_then_resume_applies_once(simple, tmp_path):
    path, plan = simple
    before = snapshot(path)
    def interrupted(index):
        assert index == 0
        raise KeyboardInterrupt("private injected interruption")
    with pytest.raises(KeyboardInterrupt):
        apply_plan(path, plan, source_root=tmp_path, after_statement=interrupted)
    assert snapshot(path) == before
    assert apply_plan(path, plan, source_root=tmp_path)["version"] == "fixture-1"


def test_abrupt_process_exit_rolls_back_then_resume_uses_one_receipt(simple, tmp_path):
    path, plan = simple
    before = snapshot(path)
    plan_file = tmp_path / "plan.json"
    plan_file.write_text(json.dumps(plan), encoding="utf8")
    child = """
import json,os,sys
from pathlib import Path
from nmate.core_v1.schema_lifecycle import apply_plan
plan=json.loads(Path(sys.argv[2]).read_text(encoding='utf8'))
apply_plan(sys.argv[1],plan,source_root=sys.argv[3],after_statement=lambda index:os._exit(37))
"""
    result = subprocess.run([sys.executable, "-c", child, str(path), str(plan_file), str(tmp_path)],
                            capture_output=True, timeout=20,
                            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    assert result.returncode == 37
    assert snapshot(path) == before
    receipt = apply_plan(path, plan, source_root=tmp_path)
    assert apply_plan(path, plan, source_root=tmp_path) == receipt
    with closing(sqlite3.connect(path)) as db:
        assert db.execute(f"SELECT COUNT(*) FROM {LEDGER}").fetchone()[0] == 1


@pytest.mark.parametrize("sql", [
    "DELETE FROM business", "UPDATE business SET value='bad'", "DROP TABLE business",
    "ALTER TABLE business RENAME TO renamed", "CREATE TRIGGER t AFTER INSERT ON business BEGIN DELETE FROM business; END",
    "CREATE VIEW leaked AS SELECT * FROM business", "ATTACH DATABASE ':memory:' AS other",
    "CREATE TABLE leaked AS SELECT * FROM business",
    "CREATE TABLE leaked AS /* disguised copy */ SELECT * FROM business",
    "CREATE TABLE leaked AS WITH source AS (SELECT * FROM business) SELECT * FROM source",
    "CREATE TABLE core_schema_migration_receipts(fake TEXT)",
    "CREATE TABLE second(id TEXT); DELETE FROM business",
])
def test_schema_only_runner_refuses_business_dml_or_multiple_sql(simple, tmp_path, sql):
    path, _plan = simple
    before = snapshot(path)
    with pytest.raises((SchemaLifecycleError, sqlite3.DatabaseError)):
        create_plan(path, version="unsafe", statements=[sql], source_root=tmp_path,
                    dependency_files=["dependency.txt"])
    assert snapshot(path) == before


def test_plan_tamper_and_drift_refuse_before_ledger_created(simple, tmp_path):
    path, plan = simple
    before = snapshot(path)
    altered = {**plan, "statements": ["CREATE TABLE tampered(id TEXT)"]}
    with pytest.raises(SchemaLifecycleError, match="checksum"):
        apply_plan(path, altered, source_root=tmp_path)
    assert snapshot(path) == before
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE external_drift(id TEXT)")
    drifted = snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="Precondition"):
        apply_plan(path, plan, source_root=tmp_path)
    assert snapshot(path) == drifted


def test_same_version_different_checksum_refuses(simple, tmp_path):
    path, plan = simple
    apply_plan(path, plan, source_root=tmp_path)
    changed = create_plan(path, version="fixture-1", statements=["CREATE TABLE another(id TEXT)"],
                          source_root=tmp_path, dependency_files=["dependency.txt"])
    before = snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="Version đã dùng"):
        apply_plan(path, changed, source_root=tmp_path)
    assert snapshot(path) == before


def test_restore_drill_requires_hash_and_ownership_and_keeps_rows(simple, tmp_path):
    path, plan = simple
    original = snapshot(path)
    backup = tmp_path / "backup.sqlite3"
    with EnterpriseRuntimeLock(path):
        proof = backup_database(path, backup)
    apply_plan(path, plan, source_root=tmp_path)
    upgraded = snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="Checksum"):
        restore_database(path, backup, expected_backup_sha256="wrong")
    assert snapshot(path) == upgraded
    with EnterpriseRuntimeLock(path):
        with pytest.raises(RuntimeAlreadyRunning):
            restore_database(path, backup, expected_backup_sha256=proof["sha256"])
    assert snapshot(path) == upgraded
    receipt = restore_database(path, backup, expected_backup_sha256=proof["sha256"])
    assert receipt["provider_calls"] == 0
    assert snapshot(path) == original


@pytest.mark.parametrize("suffix", ["-journal", "-wal", "-shm", ""])
def test_backup_refuses_database_and_all_sqlite_sidecar_paths(simple, suffix):
    path, _plan = simple
    before = snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="sidecar"):
        backup_database(path, str(path) + suffix)
    assert snapshot(path) == before


def test_backup_never_overwrites_existing_target_and_keeps_verified_new_snapshot(simple, tmp_path):
    path, _plan = simple
    target = tmp_path / "existing-backup.sqlite3"
    target.write_bytes(b"untouched-existing-file")
    with pytest.raises(SchemaLifecycleError, match="đường dẫn mới"):
        backup_database(path, target)
    assert target.read_bytes() == b"untouched-existing-file"
    new = tmp_path / "new-backup.sqlite3"
    proof = backup_database(path, new)
    assert proof["sha256"]
    assert snapshot(path) == snapshot(new)
    assert not list(tmp_path.glob("*.backup-*.sqlite3"))


def test_consistent_backup_of_wal_database_is_published_offline_and_restorable(simple, tmp_path):
    path, _plan = simple
    backup = tmp_path / "wal-source-backup.sqlite3"
    with closing(sqlite3.connect(path)) as writer:
        writer.execute("PRAGMA journal_mode=WAL")
        writer.execute("UPDATE business SET value='committed-in-wal'")
        writer.commit()
        with EnterpriseRuntimeLock(path):
            proof = backup_database(path, backup)
        with closing(sqlite3.connect(backup)) as saved:
            assert saved.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
            assert saved.execute("SELECT value FROM business").fetchone()[0] == "committed-in-wal"
    restore_database(path, backup, expected_backup_sha256=proof["sha256"])
    with closing(sqlite3.connect(path)) as current:
        assert current.execute("SELECT value FROM business").fetchone()[0] == "committed-in-wal"


def test_apply_refuses_live_runtime_lock_before_ddl(simple, tmp_path):
    path, plan = simple
    before = snapshot(path)
    with EnterpriseRuntimeLock(path):
        with pytest.raises(RuntimeAlreadyRunning):
            apply_plan(path, plan, source_root=tmp_path)
    assert snapshot(path) == before


@pytest.mark.parametrize("statements", [
    ["CREATE INDEX business_value ON business(value)"],
    ["ALTER TABLE business ADD COLUMN optional_note TEXT"],
])
def test_positive_additive_index_and_column_keep_business_values(simple, tmp_path, statements):
    path, _plan = simple
    plan = create_plan(path, version="positive", statements=statements, source_root=tmp_path,
                       dependency_files=["dependency.txt"])
    apply_plan(path, plan, source_root=tmp_path)
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT id,value FROM business").fetchall() == [("original", "never-change")]


def test_dependency_paths_cannot_escape_source_root(simple, tmp_path):
    path, _plan = simple
    with pytest.raises(SchemaLifecycleError, match="source root"):
        create_plan(path, version="escape", statements=["CREATE TABLE ok(id TEXT)"], source_root=tmp_path,
                    dependency_files=["../outside.txt"])


@pytest.mark.parametrize("dependencies", [None, "dependency.txt", [None], [{"file": "dependency.txt"}], []])
def test_malformed_dependency_manifest_fails_before_creating_writes(simple, tmp_path, dependencies):
    path, _plan = simple
    before = snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="dependency"):
        create_plan(path, version="bad-dependencies", statements=["CREATE TABLE ok(id TEXT)"],
                    source_root=tmp_path, dependency_files=dependencies)
    assert snapshot(path) == before


def test_symlink_dependency_is_not_attested_as_regular_source(simple, tmp_path, monkeypatch):
    path, _plan = simple
    # Inject filesystem metadata to exercise the platform-independent rejection
    # path without requiring Windows symlink-administration privileges.
    original = Path.is_symlink
    monkeypatch.setattr(Path, "is_symlink", lambda item: item.name == "dependency.txt" or original(item))
    with pytest.raises(SchemaLifecycleError, match="dependency"):
        create_plan(path, version="link", statements=["CREATE TABLE ok(id TEXT)"], source_root=tmp_path,
                    dependency_files=["dependency.txt"])


def test_restore_refuses_wal_backup_bytes_not_attested_by_main_file_hash(simple, tmp_path):
    path, _plan = simple
    saved = tmp_path / "backup.sqlite3"
    with EnterpriseRuntimeLock(path):
        proof = backup_database(path, saved)
    before = snapshot(path)
    with closing(sqlite3.connect(saved)) as writer:
        writer.execute("PRAGMA journal_mode=WAL")
        writer.execute("UPDATE business SET value='only-in-wal'")
        writer.commit()
        with pytest.raises(SchemaLifecycleError, match="WAL"):
            restore_database(path, saved, expected_backup_sha256=proof["sha256"])
        assert snapshot(path) == before


def test_explicit_init_creates_ready_db_without_account_budget_or_provider(tmp_path):
    target = tmp_path / "explicit" / "enterprise.sqlite3"
    receipt = initialize_new_database(target)
    assert receipt["business_accounts_created"] == receipt["budget_grants_created"] == receipt["provider_calls"] == 0
    assert verify_runtime_database(target)["ready"]
    with sqlite3.connect(target) as db:
        assert db.execute("SELECT COUNT(*) FROM v03_accounts").fetchone()[0] == 0
        assert db.execute("SELECT COUNT(*) FROM core_budget_grants").fetchone()[0] == 0
    before = snapshot(target)
    with pytest.raises(SchemaLifecycleError, match="DB mới"):
        initialize_new_database(target)
    assert snapshot(target) == before


def test_init_cli_and_verify_do_not_require_credentials_or_environment(tmp_path, monkeypatch, capsys):
    for key in list(__import__("os").environ):
        if "API_KEY" in key or key.startswith("NMATE_"):
            monkeypatch.delenv(key)
    target = tmp_path / "cli.sqlite3"
    assert main(["verify", "--database", str(target)]) == 2
    assert not target.exists()
    assert main(["init", "--database", str(target)]) == 0
    output = capsys.readouterr()
    assert json.loads(output.out)["result"]["provider_calls"] == 0
    assert main(["verify", "--database", str(target)]) == 0
    assert json.loads(capsys.readouterr().out)["result"]["ready"] is True
    assert not any(file.name.endswith(".env") for file in tmp_path.iterdir())


def test_init_failure_leaves_no_database_to_mistake_for_ready(tmp_path, monkeypatch):
    from nmate.main import app
    target = tmp_path / "failed.sqlite3"
    def broken(path, **kwargs):
        with closing(sqlite3.connect(path)) as db:
            db.execute("CREATE TABLE half_initialized(id TEXT)")
        raise RuntimeError("controlled initialization failure")
    monkeypatch.setattr(app, "make_main_app", broken)
    with pytest.raises(RuntimeError, match="controlled"):
        initialize_new_database(target)
    assert not target.exists()
    assert not list(tmp_path.glob("*.init-*.sqlite3"))
