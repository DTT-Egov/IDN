"""Private SSOT, reusable references and paid-free end-to-end mission behavior."""
import asyncio

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService, interpret
from nmate.v03.markets import detect_markets


TEA = "Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh."


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "v03.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("tea-owner", "TestPassword12345", "Doanh nghiệp Sen")
    other = accounts.register("other-owner", "TestPassword12345", "Doanh nghiệp khác")
    service = MissionService(repo)
    return repo, accounts, owner, other, service


def args(owner):
    return owner["account_id"], owner["enterprise_id"]


def complete(service, owner, text=TEA, key="first", product=None):
    # A selected product alone does not imply a destination. These legacy tests
    # explicitly select US; continuation-specific tests exercise inheritance.
    mission = service.prepare(*args(owner), text, f"prepare-{key}", product,
                              market_code="US" if product and not detect_markets(text) else None)
    service.start(*args(owner), mission["id"], f"start-{key}")
    assert asyncio.run(service.execute_next()) is True
    return service.get(*args(owner), mission["id"])


def test_tea_has_two_direct_answers_real_empty_label_and_actual_dag(setup):
    _, _, owner, _, service = setup
    mission = complete(service, owner)
    assert [a["outcome_id"] for a in mission["answers"]] == ["registration", "label"]
    assert "trừ ngoại lệ" in mission["answers"][0]["text"]
    assert "Chưa thể kết luận" in mission["answers"][0]["text"]
    assert len(mission["actions"]) == 2
    assert {t["id"]: t["depends_on"] for t in mission["plan"]["tasks"]}["label-workbook"] == ["label-research"]
    assert all(t["status"] == "succeeded" for t in mission["plan"]["tasks"])
    label = mission["label"]
    assert label["product_reference"] == "Trà Sen Tây Hồ"
    assert {f["label_en"] for f in label["fields"]} >= {"Ingredients", "Net quantity"}
    assert all(f["value"] is None for f in label["fields"])
    assert label["review_status"] == "draft_unreviewed"
    assert mission["cost"] == {"paid_calls": 0, "provider_attempts": 0}
    assert all(s["review_state"] == "reference_unreviewed" for s in mission["sources"])


def test_intents_do_not_force_triplet_or_confuse_certification_with_label(setup):
    _, _, owner, _, service = setup
    registration = service.prepare(*args(owner), "Tôi có Trà Sen Tây Hồ gửi New York cần đăng ký cơ sở FDA?", "reg")
    label = service.prepare(*args(owner), "Tôi có Trà Sen Tây Hồ gửi New York cần nhãn tiếng Anh.", "label")
    certification = interpret("Tôi có Bột Sen gửi New York. Sản phẩm cần chứng nhận gì?")
    assert [o["id"] for o in registration["intent"]["outcomes"]] == ["registration"]
    assert [o["id"] for o in label["intent"]["outcomes"]] == ["label"]
    assert [o.id for o in certification.outcomes] == ["certification"]
    assert len(registration["plan"]["tasks"]) == 1
    assert len(label["plan"]["tasks"]) == 2


def test_prepare_start_and_label_save_idempotency_and_label_cas(setup):
    repo, _, owner, _, service = setup
    first = complete(service, owner)
    same = service.prepare(*args(owner), TEA, "prepare-first")
    assert same["id"] == first["id"]
    assert service.start(*args(owner), first["id"], "new-start-key")["id"] == first["id"]
    assert asyncio.run(service.execute_next()) is False
    saved = service.update_label(*args(owner), first["id"], first["label"]["id"], {"statement_of_identity": "Lotus-scented tea", "net_quantity": "100 g"}, 1, "save-1")
    assert saved["label"]["version"] == 2
    assert saved["label"]["id"] == first["label"]["id"]
    assert next(f["value"] for f in saved["label"]["fields"] if f["id"] == "net_quantity") == "100 g"
    assert service.update_label(*args(owner), first["id"], first["label"]["id"], {"statement_of_identity": "Lotus-scented tea", "net_quantity": "100 g"}, 1, "save-1")["label"]["version"] == 2
    with pytest.raises(CoreError, match="Khung nhãn đã đổi"):
        service.update_label(*args(owner), first["id"], first["label"]["id"], {"net_quantity": "50 g"}, 1, "save-conflict")
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 2
    restored = MissionService(CoreRepository(repo.db_path)).get(*args(owner), first["id"])
    assert restored["label"]["version"] == 2


def test_ssot_new_facts_invalidate_old_result_and_personalize_next_plan(setup):
    repo, _, owner, _, service = setup
    first = complete(service, owner)
    changed = service.update_facts(*args(owner), first["id"], [
        {"field": "ingredients", "value": ["Green tea", "Lotus scent"], "source": {"kind": "user_entry", "quote": "Công thức giả lập"}},
        {"field": "net_quantity", "value": "100 g"},
    ], first["product"]["version"], "facts-1")
    assert changed["status"] == "needs_revalidation"
    assert changed["label"]["version"] == 1
    second = complete(service, owner, "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", "second", first["product"]["entity_id"])
    assert second["status"] == "completed_partial"
    fields = {f["id"]: f for f in second["label"]["fields"]}
    assert fields["ingredients"]["value"] == "Green tea, Lotus scent"
    assert fields["ingredients"]["state"] == "self_declared"
    assert fields["net_quantity"]["value"] == "100 g"
    assert second["product"]["name"] == "Trà Sen Tây Hồ"
    assert len(repo.list_entities(*args(owner), "product")) == 1
    assert all(f["verification_state"] == "self_declared" for f in second["context"]["entities"][0]["facts"])


def test_two_profiles_same_account_reuse_and_different_account_private(setup):
    _, accounts, owner, other, service = setup
    first = complete(service, owner)
    same_account = accounts.login("tea-owner", "TestPassword12345")
    assert service.get(*args(same_account), first["id"])["id"] == first["id"]
    assert service.list(*args(other)) == []
    with pytest.raises(CoreError):
        service.get(*args(other), first["id"])
    with pytest.raises(CoreError):
        service.get(other["account_id"], owner["enterprise_id"], first["id"])
    second = complete(service, other, key="other")
    assert {s["id"] for s in first["sources"]} == {s["id"] for s in second["sources"]}
    assert first["product"]["entity_id"] != second["product"]["entity_id"]


def test_source_change_invalidates_all_enterprises_without_replacing_snapshot(setup):
    _, _, owner, other, service = setup
    first, second = complete(service, owner), complete(service, other, key="other")
    source = first["knowledge"]["source_refs"][0]
    service.catalog.observe_source(*args(owner), source["source_id"], "a" * 64, "observed-change")
    assert service.get(*args(owner), first["id"])["status"] == "needs_revalidation"
    assert service.get(*args(other), second["id"])["status"] == "needs_revalidation"
    new = service.prepare(*args(owner), TEA, "new-source")
    # A new plan can use the remaining valid sources. The changed snapshot is
    # still visible and explicitly forbidden; it cannot bind or support work.
    unusable = [r for r in new["knowledge"]["records"] if r["source_id"] == source["source_id"]]
    assert unusable and all(r["reusable"] is False for r in unusable)
    assert source["source_id"] not in {r["source_id"] for r in new["knowledge"]["source_refs"]}
    assert new["knowledge"]["coverage"]["missing"]
    assert new["status"] == "planned"
    service.start(*args(owner), new["id"], "new-source-start")
    assert asyncio.run(service.execute_next()) is True
    result = service.get(*args(owner), new["id"])
    assert result["status"] == "completed_partial"
    assert all(source["source_id"] not in a["source_ids"] for a in result["answers"])
    assert service.get(*args(owner), first["id"])["status"] == "needs_revalidation"
    assert service.get(*args(other), second["id"])["status"] == "needs_revalidation"


def test_recovery_is_explicit_and_never_replays_running_work(setup):
    repo, _, owner, _, service = setup
    mission = service.prepare(*args(owner), TEA, "recover")
    service.start(*args(owner), mission["id"], "recover-start")
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_missions SET status='running' WHERE id=?", (mission["id"],))
        db.execute("UPDATE v03_task_attempts SET state='running' WHERE mission_id=?", (mission["id"],))
    assert service.recover_interrupted() == 1
    recovered = service.get(*args(owner), mission["id"])
    assert recovered["status"] == "failed"
    assert "không tự chạy lại" in recovered["stale_reason"]
    assert all(t["status"] == "failed" for t in recovered["plan"]["tasks"])
    assert asyncio.run(service.execute_next()) is False


@pytest.mark.asyncio
async def test_correction_during_running_blocks_publish_and_keeps_old_snapshot(setup):
    repo, _, owner, _, _ = setup
    service = MissionService(repo, task_delay=0.04)
    mission = service.prepare(*args(owner), TEA, "race")
    service.start(*args(owner), mission["id"], "race-start")
    running = asyncio.create_task(service.execute_next())
    await asyncio.sleep(0.015)
    service.update_facts(*args(owner), mission["id"], [{"field": "net_quantity", "value": "80 g"}], mission["product"]["version"], "race-fact")
    await running
    changed = service.get(*args(owner), mission["id"])
    assert changed["status"] == "needs_revalidation"
    assert changed["artifacts"] == []
    assert changed["context"]["entities"][0]["values"].get("net_quantity") is None


def test_new_supported_market_plans_but_unknown_market_and_intent_do_not_start(setup):
    _, _, owner, _, service = setup
    first = complete(service, owner)
    other_market = service.prepare(*args(owner), "Chuẩn bị nhãn sang Nhật", "japan", first["product"]["entity_id"])
    assert other_market["status"] == "planned" and other_market["market"]["code"] == "JP"
    unsupported = service.prepare(*args(owner), "Chuẩn bị nhãn sang Canada", "canada", first["product"]["entity_id"])
    assert unsupported["status"] == "waiting_input" and not unsupported["sources"]
    with pytest.raises(CoreError):
        service.start(*args(owner), unsupported["id"], "canada-start")
    mismatch = service.prepare(*args(owner), "Tôi có Bột Sen gửi New York cần nhãn", "different-name", first["product"]["entity_id"])
    assert mismatch["status"] == "waiting_input"
    mixed = interpret("Tôi có Trà Sen gửi sang EU, cần chuẩn bị nhãn tiếng Anh; chưa hỏi về FDA.")
    assert mixed.scope == "unsupported"
    assert [o.id for o in interpret("Tôi cần chứng nhận Bột Sen đi Mỹ").outcomes] == ["certification"]


def test_revoked_input_acl_blocks_materialized_get_list_and_label_write(setup):
    repo, _, owner, _, service = setup
    mission = complete(service, owner)
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (mission["product"]["entity_id"],))
    with pytest.raises(CoreError):
        service.get(*args(owner), mission["id"])
    assert service.list(*args(owner)) == []
    with pytest.raises(CoreError):
        service.update_label(*args(owner), mission["id"], mission["label"]["id"], {"net_quantity": "100 g"}, 1, "revoked-save")
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_artifact_revisions").fetchone()[0] == 1


def test_saved_label_keeps_lineage_and_unrelated_fields_after_new_formula_declaration(setup):
    _, _, owner, _, service = setup
    first = complete(service, owner)
    assert first["reused_fact_count"] == 0
    saved = service.update_label(*args(owner), first["id"], first["label"]["id"], {"statement_of_identity": "Lotus-scented tea", "net_quantity": "100 g"}, 1, "save-draft")
    second = complete(service, owner, "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", "draft-reuse", first["product"]["entity_id"])
    assert second["reused_fact_count"] == 1  # Product name; no scalar market fact.
    assert next(f["value"] for f in second["label"]["fields"] if f["id"] == "statement_of_identity") == "Lotus-scented tea"
    assert second["label"]["parent_artifact_ref"]["artifact_id"] == saved["label"]["id"]
    assert second["label"]["parent_artifact_ref"]["version"] == 2
    service.update_facts(*args(owner), second["id"], [{"field": "ingredients", "value": ["Green tea"]}], second["product"]["version"], "change-formula")
    third = complete(service, owner, "Chuẩn bị nhãn tiếng Anh cho hồ sơ này.", "draft-changed", first["product"]["entity_id"])
    assert third["label"]["parent_artifact_ref"] is not None
    assert next(f["value"] for f in third["label"]["fields"] if f["id"] == "statement_of_identity") == "Lotus-scented tea"
    assert next(f["value"] for f in third["label"]["fields"] if f["id"] == "ingredients") == "Green tea"


def test_known_facility_facts_are_acknowledged_and_not_requested_again(setup):
    _, _, owner, _, service = setup
    first = complete(service, owner)
    service.update_facts(*args(owner), first["id"], [{"field": "facility_activity", "value": "Đóng gói trà"}, {"field": "facility_type", "value": "Cơ sở sản xuất tại Việt Nam"}], first["product"]["version"], "known-facility")
    second = complete(service, owner, TEA, "known-facility-plan", first["product"]["entity_id"])
    answer = next(a for a in second["answers"] if a["outcome_id"] == "registration")
    assert answer["missing_fields"] == []
    assert "Đóng gói trà" in answer["text"]
    assert "vì thiếu" not in answer["text"]
    assert any(a["title"] == "Rà ngoại lệ theo cơ sở đã khai báo" for a in second["actions"])
