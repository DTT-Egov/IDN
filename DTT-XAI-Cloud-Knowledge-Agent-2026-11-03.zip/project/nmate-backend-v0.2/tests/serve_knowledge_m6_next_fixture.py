"""Loopback testing UI; fresh synthetic DB and fake provider ONLY.

No .env, source production databases, approval registry, or real SDK. Test
accounts authenticate through the same LocalAccounts sessions/CSRF as main.
"""

import argparse
import asyncio
import json
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from nmate.v03.identity import LocalAccounts
from nmate.v03.core import CoreError
from nmate.knowledge_v1.workbench import router
from test_knowledge_m1 import kb
from test_knowledge_m2 import pipe
from test_knowledge_m3_domain_gateway import domain
from test_knowledge_m6_simulation_review import typed_drafts


def main():
    parser = argparse.ArgumentParser(description="Chỉ thử giao thức review mô phỏng, không gọi AI")
    parser.add_argument("--directory", required=True, type=Path)
    parser.add_argument("--port", type=int, default=8032)
    args = parser.parse_args()
    directory = args.directory.resolve()
    if directory.exists():
        raise SystemExit("Cần thư mục testing mới; không ghi đè lịch sử.")
    directory.mkdir(parents=True)
    base = kb.__wrapped__(directory)
    pipeline = pipe.__wrapped__(base, directory)
    fixture = domain.__wrapped__(pipeline, directory)
    ids, simulation = asyncio.run(typed_drafts(fixture))
    gateway = fixture[0]
    accounts = LocalAccounts(gateway.repo)

    # Provider seam becomes unavailable after fixture preparation. Even direct
    # gateway calls cannot reach the real transport in this testing host.
    async def forbidden_provider(*args, **kwargs):
        raise AssertionError("No provider after fixture setup")

    gateway.enabled = False
    gateway.request_fn = forbidden_provider
    simulation.export(fixture[3], ids, directory / "agent-handoff")
    metadata = dict(
        mode="synthetic_testing_only",
        proposal_ids=ids,
        reviewer_id=fixture[3],
        paid_calls=0,
        ui_url=f"http://127.0.0.1:{args.port}/knowledge/simulation?proposals=" + ",".join(ids),
    )
    (directory / "fixture.json").write_bytes(
        json.dumps(metadata, ensure_ascii=False, indent=2).encode("utf-8")
    )
    app = FastAPI(title="nMate · sandbox review · no paid AI")

    def session(request):
        token = request.cookies.get("test_sim_session", "")
        value = (
            accounts.validate_csrf(token, request.headers.get("X-CSRF-Token"))
            if request.method == "POST"
            else accounts.get_session(token)
        )
        return dict(account_id=value["account_id"], csrf_token=request.cookies.get("test_sim_csrf"))

    app.include_router(router(simulation.service, gateway, session, simulation=simulation))

    @app.get("/")
    async def index():
        return HTMLResponse(
            '<!doctype html><html lang="vi"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Đăng nhập testing</title><main style="max-width:400px;margin:24px auto;padding:16px;font:16px system-ui"><h1>Review mô phỏng</h1><p>Dữ liệu thử, không phải chính sách thật. Không có gọi AI ở máy chủ này.</p><form action="/test/login" method="post"><label>Tài khoản <input name="username" value="kb_other" style="min-height:44px;width:100%"></label><label>Mật khẩu thử <input name="password" type="password" style="min-height:44px;width:100%"></label><button style="min-height:44px;margin-top:16px">Đăng nhập testing</button></form></main></html>'
        )

    @app.post("/test/login")
    async def login(request: Request):
        from urllib.parse import parse_qs

        data = parse_qs((await request.body()).decode())
        try:
            account = accounts.login(data.get("username", [""])[0], data.get("password", [""])[0])
            credentials = accounts.create_session(account["account_id"])
        except CoreError as exc:
            return JSONResponse(
                dict(ok=False, error=dict(code=exc.code, message=str(exc))), status_code=exc.status_code
            )
        response = RedirectResponse("/knowledge/simulation?proposals=" + ",".join(ids), status_code=303)
        response.set_cookie("test_sim_session", credentials["token"], httponly=True, samesite="strict")
        response.set_cookie("test_sim_csrf", credentials["csrf_token"], samesite="strict")
        return response

    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
