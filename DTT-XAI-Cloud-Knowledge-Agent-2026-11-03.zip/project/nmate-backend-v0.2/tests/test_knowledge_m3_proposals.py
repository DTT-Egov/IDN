"""Draft provenance and atomic expert application; SDK stub only."""
import json
import pytest
from test_knowledge_m3_domain_gateway import domain,invoke
from test_knowledge_m2 import pipe
from test_knowledge_m1 import kb
from nmate.knowledge_v1.operator_m3 import install_m3_on_clone
from nmate.knowledge_v1.governance import WikiGovernance
from nmate.knowledge_v1.ai_proposals import PROPOSAL_SCHEMA,record_proposal,read_proposal
from nmate.v03.core import CoreError

@pytest.mark.asyncio
async def test_model_proposal_is_not_expert_decision_and_apply_is_atomic(domain,tmp_path):
    gw,s,a,other,scope,grant,ref,calls=domain
    g=WikiGovernance(gw.repo)
    data=dict(title='TEST ONLY',claims=[dict(kind='source_excerpt',text=ref['quote'],evidence=[dict(evidence_id='1',quote=ref['quote'])])],gaps=['TEST missing annex'],questions_for_expert=['TEST verify currency'])
    async def request(model,body,limit):
        calls.append(model);return dict(text=json.dumps(data),model=model,stop_reason='end_turn',usage={'input_tokens':100,'output_tokens':80})
    gw.request_fn=request
    result=await invoke(domain,output_schema=PROPOSAL_SCHEMA)
    proposal=record_proposal(g,gw,a,result['attempt_id']);read=read_proposal(g,gw,a,proposal['proposal_id'])
    assert read['payload']['reviewed_by'] is None and read['payload']['published_by'] is None
    with gw.repo.connection() as db:
        assert db.execute('SELECT count(*) FROM kp_wiki_pages').fetchone()[0]==0
        assert db.execute('SELECT count(*) FROM pol_wiki_reviews').fetchone()[0]==0
        before=list(db.iterdump())
    def crash(point):
        if point=='after_proposal_apply_before_receipt': raise RuntimeError('TEST crash')
    g.fault_hook=crash
    with pytest.raises(RuntimeError): g.apply_proposal(gw,a,proposal['proposal_id'],operation_id='apply-proposal-test')
    with gw.repo.connection() as db: assert list(db.iterdump())==before
    g.fault_hook=None
    applied=g.apply_proposal(gw,a,proposal['proposal_id'],operation_id='apply-proposal-test')
    assert applied['assessment_eligible'] is False
    assert g.apply_proposal(gw,a,proposal['proposal_id'],operation_id='apply-proposal-test')==applied
    assert len(calls)==1
    with pytest.raises(CoreError): read_proposal(g,gw,other,proposal['proposal_id'])

@pytest.mark.asyncio
@pytest.mark.parametrize('bad',['surrogate','huge_usage'])
async def test_malformed_post_dispatch_response_is_persisted_not_retried(domain,bad):
    gw,*_=domain
    async def request(model,body,limit):
        domain[-1].append(model)
        return dict(text='\ud800' if bad=='surrogate' else '{"draft":"TEST"}',model=model,stop_reason='end_turn',
                    usage={'input_tokens':10**100 if bad=='huge_usage' else 100,'output_tokens':10})
    gw.request_fn=request
    with pytest.raises(CoreError): await invoke(domain)
    with gw.repo.connection() as db:
        row=db.execute('SELECT * FROM core_domain_model_attempts').fetchone()
        assert row['state']=='response_received' and row['validation_state']=='rejected'
    with pytest.raises(CoreError): await invoke(domain,operation_id='no-paid-retry')
    assert len(domain[-1])==1
