from nmate.main.history import history_metadata


def policy_chat(**extra):
    return {"title": "Tôi có sản phẩm Trà Sen Tây Hồ, hộp 100 g, thành phần trà xanh và hoa sen...",
            "status": "completed_partial", "intake_ids": ["intake"],
            "intake": {"product": {"name": "Trà Sen Tây Hồ"}},
            "active_policy_case_id": "policy", "policy_cases": [{"id": "policy",
                "intent": {"goal": "digital_inventory"}, "outcomes": [
                    {"type": "eligibility", "status": "awaiting_rule_review"},
                    {"type": "application_window", "status": "needs_source"}],
                "ssot_questions": []}], **extra}


def test_policy_gaps_are_not_reported_as_missing_enterprise_facts():
    chat = policy_chat()
    result = history_metadata(chat)
    assert result["display_title"] == "Trà Sen Tây Hồ · số hóa kho"
    assert result["task_labels"] == ["Hồ sơ", "Chính sách Hà Nội"]
    assert result["history_details_vi"] == ["Quy tắc tư vấn chưa được duyệt", "Còn phần thiếu căn cứ hiện hành"]
    assert "dữ kiện" not in result["history_state_vi"]
    assert chat["title"].startswith("Tôi có sản phẩm")


def test_historical_policy_and_failed_operation_have_distinct_states():
    chat = policy_chat()
    chat["policy_cases"][0]["is_historical"] = True
    assert history_metadata(chat)["history_state_vi"] == "Bản lưu · cần đối chiếu lại"
    chat["operation_error"] = {"message": "Kết quả chưa xác định"}
    assert history_metadata(chat)["history_state_vi"] == "Lượt trước chưa hoàn tất"


def test_title_does_not_guess_product_from_multiple_context_entities():
    chat = policy_chat(intake=None, intake_ids=[])
    chat["policy_cases"][0]["context"] = {"entities": [
        {"entity_type": "product", "name": "Trà Sen"}, {"entity_type": "product", "name": "Mứt Sen"}]}
    assert history_metadata(chat)["display_title"] == "Số hóa kho"
    assert history_metadata(chat)["task_labels"] == ["Chính sách Hà Nội"]


def test_plain_confirmation_state_has_no_policy_gap():
    result = history_metadata({"status": "confirmed", "intake_ids": ["intake"],
                               "intake": {"product": {"name": "Trà Sen Tây Hồ"}}})
    assert result["history_state_vi"] == "Đã lưu hồ sơ"
    assert result["history_details_vi"] == []


def test_empty_plan_history_uses_recorded_basis_not_later_profile():
    chat = {"status": "ready", "intake_ids": ["before-profile"],
            "intake": {"reused_context": {"fact_count": 0}},
            "context": {"fact_refs": [{"field": "name"}] * 8}}
    before = history_metadata(chat)
    assert before["history_reused_fact_count"] == 0
    assert before["history_state_vi"] == "Đã lưu trao đổi · chưa dùng hồ sơ"
    chat["context"]["fact_refs"].append({"field": "packaging"})
    assert history_metadata(chat) == before


def test_history_claims_reuse_only_from_the_recorded_plan():
    result = history_metadata({"status": "ready", "intake": {"reused_context": {"fact_count": 3}}})
    assert result["history_state_vi"] == "Đã dùng hồ sơ để lập kế hoạch"
    assert result["history_reused_fact_count"] == 3
    unknown = history_metadata({"status": "ready", "intake": {},
                                "context": {"fact_refs": [{"field": "name"}]}})
    assert unknown["history_state_vi"] == "Trao đổi đã lưu"
    assert unknown["history_reused_fact_count"] is None


def test_export_history_uses_the_selected_mission_snapshot():
    view = {"status": "planned", "active_mission_id": "fresh", "mission_ids": ["old", "fresh"],
            "missions": [{"id": "old", "context": {"fact_refs": [{"field": "name"}]}},
                         {"id": "fresh", "context": {"fact_refs": []}}]}
    result = history_metadata(view)
    assert result["history_state_vi"] == "Có kế hoạch · chưa dùng hồ sơ"
    assert result["history_reused_fact_count"] == 0


def test_unsupported_request_is_not_described_as_waiting_for_four_tasks():
    result = history_metadata({"status": "needs_clarification", "intake": {
        "intent": {"unsupported_request": "financing"}, "reused_context": {"fact_count": 0}}})
    assert result["history_state_vi"] == "Nhu cầu ngoài phạm vi bản này"
