"""DF-041/042: a committed operator migration must remain runtime-readable.

The disposable old-state fixture is checked against the preserved old public
contract before any migration. No MAIN path, old receipt or source is changed.
"""
from pathlib import Path
import json
import sqlite3

import pytest

from nmate.core_v1.runtime_schema import (
    RuntimeSchemaError, managed_runtime, read_runtime_contract, verify_runtime_database,
)
from nmate.core_v1.schema_lifecycle import LEDGER, LEDGER_SQL, apply_plan, create_plan
from nmate.main.app import make_main_app
from nmate.policy_v05.workbench import SCHEMA


DATA = Path(__file__).resolve().parents[1] / 'src/nmate/core_v1/data'
OLD_CONTRACT = DATA / 'runtime_schema_20261022.json'
SOURCE = Path(__file__).resolve().parents[1] / 'src'


def denied(*_args, **_kwargs):
    raise AssertionError('Migration/runtime tests never call a provider')


def snapshot(path):
    with sqlite3.connect(path) as db:
        return list(db.iterdump())


def business_rows(path):
    with sqlite3.connect(path) as db:
        names = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
                 if not row[0].startswith('pol05_') and row[0] != LEDGER]
        return {name: sorted(db.execute('SELECT * FROM "' + name.replace('"', '""') + '"').fetchall(), key=repr) for name in names}


def ddl():
    result, pending = [], ''
    for line in SCHEMA.splitlines(keepends=True):
        pending += line
        if sqlite3.complete_statement(pending):
            result.append(pending.strip())
            pending = ''
    assert not pending.strip() and len(result) == 8
    return result


@pytest.fixture
def old_database(tmp_path):
    path = tmp_path / 'old-contract.sqlite3'
    app = make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    owner = app.state.accounts.register('migration-chain-owner', 'Synthetic-Migration-Only-123', 'Cơ sở Trà Sen giữ nguyên')
    product = app.state.repo.create_entity(owner['account_id'], owner['enterprise_id'], 'product', 'Trà Sen thử')
    app.state.repo.propose_or_apply_facts(owner['account_id'], owner['enterprise_id'], product['id'],
        [{'field': 'name', 'value': 'Trà Sen thử'}, {'field': 'net_quantity', 'value': '100 g'}], 0, 'original-owner-confirmation')
    # Build the precise preceding schema in a fresh synthetic fixture, not by
    # deleting or rewriting any pre-existing user row. These new tables are empty.
    with sqlite3.connect(path) as db:
        for table in ('pol05_approvals', 'pol05_revisions', 'pol05_drafts', 'core_v1_enterprise_profiles'):
            assert db.execute('SELECT count(*) FROM ' + table).fetchone()[0] == 0
            db.execute('DROP TABLE ' + table)
    previous = verify_runtime_database(path, contract_path=OLD_CONTRACT)
    assert previous['ready'] and previous['contract_version'] == 'nmate-main-20261022-r1'
    # The current managed factory also requires the V17 binding table. Upgrade
    # the exact old baseline through both additive schemas before that factory.
    from nmate.core_v1.enterprise_profile import SCHEMA as PROFILE_SCHEMA
    plan = create_plan(path, version='synthetic-policy05-chain-1', statements=ddl()+[PROFILE_SCHEMA.strip()], source_root=SOURCE,
                       dependency_files=['nmate/policy_v05/workbench.py', 'nmate/core_v1/enterprise_profile.py'])
    return path, plan


def test_old_contract_apply_policy_ddl_new_readiness_managed_factory_and_exact_receipt_replay(old_database):
    path, plan = old_database
    before = business_rows(path)
    with pytest.raises(RuntimeSchemaError):
        verify_runtime_database(path)
    receipt = apply_plan(path, plan, source_root=SOURCE)
    committed = snapshot(path)
    after = business_rows(path)
    assert after.pop('core_v1_enterprise_profiles') == []
    assert after == before
    result = verify_runtime_database(path)
    assert result['ready'] and result['contract_version'] == 'nmate-main-20261026-v17'
    assert result['writes'] == result['provider_calls'] == 0
    assert snapshot(path) == committed
    with managed_runtime():
        app = make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    assert app.state.repo.managed_runtime
    after = business_rows(path)
    assert after.pop('core_v1_enterprise_profiles') == []
    assert snapshot(path) == committed and after == before
    assert apply_plan(path, plan, source_root=SOURCE) == receipt
    assert snapshot(path) == committed
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT COUNT(*) FROM ' + LEDGER).fetchone()[0] == 1


def test_ledger_is_exact_optional_public_schema_without_new_required_seed(tmp_path):
    contract = read_runtime_contract()
    optional = [item for item in contract['optional_objects'] if item['name'] == LEDGER]
    assert len(optional) == 1
    with sqlite3.connect(':memory:') as db:
        db.execute(LEDGER_SQL)
        sql = db.execute('SELECT sql FROM sqlite_master WHERE name=?', (LEDGER,)).fetchone()[0]
    assert optional[0] == {'type': 'table', 'name': LEDGER, 'table': LEDGER, 'sql': sql}
    assert not any(item['table'] == LEDGER for item in contract['required_seeds'])
    path = tmp_path / 'fresh-no-ledger.sqlite3'
    make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    before = snapshot(path)
    assert verify_runtime_database(path)['ready']
    with managed_runtime():
        make_main_app(path, request_fn=denied, gateway_request_fn=denied)
    assert snapshot(path) == before
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (LEDGER,)).fetchone() is None


@pytest.mark.parametrize('tamper', [
    'ALTER TABLE core_schema_migration_receipts ADD COLUMN unexpected TEXT',
    'ALTER TABLE core_schema_migration_receipts RENAME COLUMN receipt_json TO wrong_receipt',
    'CREATE INDEX unregistered_ledger_index ON core_schema_migration_receipts(version)',
    'CREATE TABLE core_schema_migration_receipts_backup(fake TEXT)',
])
def test_optional_ledger_never_whitelists_tampered_or_unknown_objects(old_database, tamper):
    path, plan = old_database
    apply_plan(path, plan, source_root=SOURCE)
    with sqlite3.connect(path) as db:
        db.execute(tamper)
    before = snapshot(path)
    with pytest.raises(RuntimeSchemaError, match='schema'):
        verify_runtime_database(path)
    assert snapshot(path) == before


def test_previous_public_contracts_are_preserved_and_new_contract_only_adds_exact_ledger():
    prior = json.loads((DATA / 'runtime_schema_20261024_v05.json').read_text(encoding='utf8'))
    current = read_runtime_contract(DATA / 'runtime_schema_20261024_v05_1.json')
    assert prior['version'] == 'nmate-main-20261024-v05'
    assert current['version'] == 'nmate-main-20261024-v05.1'
    assert prior['required_objects'] == current['required_objects']
    assert prior['required_seeds'] == current['required_seeds']
    assert prior['optional_objects'] == [item for item in current['optional_objects'] if item['name'] != LEDGER]
