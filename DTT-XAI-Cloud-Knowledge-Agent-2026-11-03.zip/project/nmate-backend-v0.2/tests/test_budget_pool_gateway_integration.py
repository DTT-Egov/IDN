"""Independent reservation audit through the real Gateway, injected IO only."""
import asyncio
from datetime import datetime, timedelta, timezone
import json

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


SCHEMA = {"type": "object", "additionalProperties": False, "required": ["answer"],
          "properties": {"answer": {"type": "string"}}}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "independent-pooled-gateway.sqlite")
    accounts = LocalAccounts(repo)
    first = accounts.register("independent-first", "Password12345", "A")
    second = accounts.register("independent-second", "Password12345", "B")
    calls = []

    async def transport(model, body, limit):
        calls.append((model, body))
        return {"text": '{"answer":"Đã ghi nhận"}', "model": model,
                "usage": {"input_tokens": 20, "output_tokens": 10}, "stop_reason": "end_turn"}

    gateway = ModelGateway(repo, enabled=True, request_fn=transport)
    return repo, first, second, gateway, calls


def authorize(setup, role="standard", calls=1, cap=1, purposes=None):
    return setup[3].budget_pool.authorize("MAIN-APP-INDEPENDENT-TEST", role, calls, cap,
        purposes or ["legacy_intake", "legacy_research", "hanoi_policy_synthesis"],
        (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat())


def grant_for(setup, owner, role):
    # This reservation audit intentionally begins with materialized grants.
    # Query purity and real begin-from-preview have their own R1 regressions.
    setup[3].budget_pool.provision(owner["account_id"], owner["enterprise_id"])
    status = setup[3].status(owner["account_id"], owner["enterprise_id"])
    grants = [g for g in status["grants"] if role in g["roles"]]
    return grants[0]["id"]


async def invoke(setup, owner, grant, *, operation, role="standard", purpose="legacy_intake"):
    return await setup[3].call_once(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"],
        operation_id=operation, task_id="audit", role=role, purpose=purpose,
        context={"question": "Tôi muốn số hóa quản lý kho."}, output_schema=SCHEMA, budget_grant_id=grant)


def test_actual_gateway_last_slot_shared_across_two_owners_while_pending(setup):
    repo, first, second, gateway, calls = setup
    authorize(setup)
    one, two = grant_for(setup, first, "standard"), grant_for(setup, second, "standard")

    async def scenario():
        started, release = asyncio.Event(), asyncio.Event()

        async def pending(model, body, limit):
            calls.append((model, body))
            started.set()
            await release.wait()
            return {"text": '{"answer":"Đã ghi nhận"}', "model": model,
                    "usage": {"input_tokens": 20, "output_tokens": 10}, "stop_reason": "end_turn"}

        gateway.request_fn = pending
        task = asyncio.create_task(invoke(setup, first, one, operation="owner-first"))
        await started.wait()
        try:
            with pytest.raises(CoreError) as error:
                await invoke(setup, second, two, operation="owner-second")
            assert error.value.code == "BUDGET_EXCEEDED"
            second_status = gateway.status(second["account_id"], second["enterprise_id"])
            assert second_status["approved"] is False
            assert second_status["grants"][0]["remaining_calls"] == 0
            assert first["account_id"] not in json.dumps(second_status)
            assert first["enterprise_id"] not in json.dumps(second_status)
            assert len(calls) == 1
        finally:
            release.set()
        await task

    asyncio.run(scenario())
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts WHERE dispatched_at IS NOT NULL").fetchone()[0] == 1


def test_sonnet_and_opus_pools_never_refill_or_fallback_into_each_other(setup):
    _, first, second, gateway, calls = setup
    authorize(setup, role="standard", calls=1, cap=1)
    authorize(setup, role="complex", calls=1, cap=2)
    sonnet_first = grant_for(setup, first, "standard")
    sonnet_second = grant_for(setup, second, "standard")
    opus_second = grant_for(setup, second, "complex")
    asyncio.run(invoke(setup, first, sonnet_first, operation="sonnet-1"))
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, second, sonnet_second, operation="sonnet-2"))
    assert len(calls) == 1 and gateway.status(second["account_id"], second["enterprise_id"])["approved"]
    asyncio.run(invoke(setup, second, opus_second, operation="opus-1", role="complex"))
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, first, sonnet_first, operation="wrong-grant", role="complex"))
    assert [model for model, _ in calls] == ["claude-sonnet-5-5", "claude-opus-5-5"]
    assert gateway.status(first["account_id"], first["enterprise_id"])["approved"] is False


def test_unknown_spend_keeps_global_money_hold_for_other_owner_and_restart(setup):
    _, first, second, gateway, calls = setup
    authorize(setup, calls=10, cap=.075)
    one, two = grant_for(setup, first, "standard"), grant_for(setup, second, "standard")

    async def timeout(model, body, limit):
        calls.append((model, body))
        raise TimeoutError()

    gateway.request_fn = timeout
    with pytest.raises(CoreError) as first_error:
        asyncio.run(invoke(setup, first, one, operation="unknown-first"))
    assert first_error.value.code == "OUTCOME_UNKNOWN" and len(calls) == 1
    gateway.recover_interrupted()
    with pytest.raises(CoreError) as second_error:
        asyncio.run(invoke(setup, second, two, operation="unknown-second"))
    assert second_error.value.code == "BUDGET_EXCEEDED" and len(calls) == 1
    with setup[0].connection() as db:
        assert gateway.budget_pool.status_grant(db, two)["held_usd"] > .04


def test_revoking_common_pool_blocks_other_owners_already_provisioned_grant(setup):
    repo, first, second, gateway, calls = setup
    approved = authorize(setup)
    one, two = grant_for(setup, first, "standard"), grant_for(setup, second, "standard")
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_pools SET state='closed' WHERE id=?", (approved["id"],))
    for owner, child in ((first, one), (second, two)):
        assert gateway.status(owner["account_id"], owner["enterprise_id"])["approved"] is False
        with pytest.raises(CoreError) as error:
            asyncio.run(invoke(setup, owner, child, operation="closed-"+owner["account_id"]))
        assert error.value.code == "BUDGET_NOT_GRANTED"
    assert not calls


def test_denied_purpose_and_disabled_gateway_do_not_consume_common_budget(setup):
    repo, first, _, gateway, calls = setup
    authorize(setup, purposes=["hanoi_policy_synthesis"])
    child = grant_for(setup, first, "standard")
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, first, child, operation="wrong-purpose"))
    gateway.enabled = False
    with pytest.raises(CoreError):
        asyncio.run(invoke(setup, first, child, operation="disabled", purpose="hanoi_policy_synthesis"))
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM core_model_attempts").fetchone()[0] == 0
    assert not calls

