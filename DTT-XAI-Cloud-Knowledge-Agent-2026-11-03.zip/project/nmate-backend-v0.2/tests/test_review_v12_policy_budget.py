"""V12 intent completeness and honest D06 cost projection; no external IO."""
import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from nmate.core_v1.gateway import ModelGateway
from nmate.main.app import make_main_app
from nmate.policy_v1.service import resolve_intent
from nmate.v03.core import CoreRepository, now_iso


@pytest.mark.parametrize("question,expected", [
    ("Chị cần chính sách chuyển đổi số, bảo hộ nhãn hiệu và OCOP.", ["digital_transformation", "trademark_protection", "ocop_program"]),
    ("Có hỗ trợ OCOP và đăng ký nhãn hiệu không?", ["ocop_program", "trademark_protection"]),
    ("Chị muốn nhãn hiệu, xuất khẩu và chuyển đổi số.", ["trademark_protection", "market_development", "digital_transformation"]),
    ("Không chỉ chuyển đổi số mà còn OCOP và nhãn hiệu.", ["digital_transformation", "ocop_program", "trademark_protection"]),
    ("Chị không cần chuyển đổi số, chỉ muốn nhãn hiệu và OCOP.", ["trademark_protection", "ocop_program"]),
    ("Chị cần OCOP, không phải nhãn hiệu.", ["ocop_program"]),
    ("Chị muốn OCOP; không hỏi xuất khẩu và nhãn hiệu.", ["ocop_program"]),
    ("Chị không muốn OCOP nhưng cần nhãn hiệu và xuất khẩu.", ["trademark_protection", "market_development"]),
    ("Chị chưa cần nhãn hiệu, chỉ hỏi chuyển đổi số và OCOP.", ["digital_transformation", "ocop_program"]),
    ("Hỗ trợ bảo hộ thương hiệu và mỗi xã một sản phẩm.", ["trademark_protection", "ocop_program"]),
    ("Không phải nhãn hiệu mà OCOP và chuyển đổi số.", ["ocop_program", "digital_transformation"]),
    ("Chị không xuất khẩu và nhãn hiệu; chỉ OCOP.", ["ocop_program"]),
])
def test_every_positive_bounded_policy_goal_survives_conjunctions_and_negation(question, expected):
    intent = resolve_intent(question)
    assert intent["goals"] == expected
    assert intent["request_scope"] == "in_scope"
    assert intent["provider_used"] is False


def test_new_goals_do_not_borrow_digital_sources_or_rules(tmp_path):
    async def forbidden(*args, **kwargs):
        pytest.fail("Source gaps do not authorize a paid call")
    app = make_main_app(tmp_path / "policy-v12.sqlite3", refresh_sources=False,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("v12-policy-owner", "Synthetic-password-123", "Cơ sở QA")
    service = app.state.core_extension
    a, e = owner["account_id"], owner["enterprise_id"]
    answer = service.prepare(a, e, "Chị cần chính sách chuyển đổi số, bảo hộ nhãn hiệu và OCOP.", "v12-three-policy-goals")["policy_case"]
    coverage = {item["goal"]: item for item in answer["goal_coverage"]}
    assert set(coverage) == {"digital_transformation", "trademark_protection", "ocop_program"}
    assert coverage["digital_transformation"]["source_ids"]
    for goal in ("trademark_protection", "ocop_program"):
        assert coverage[goal]["status"] == "needs_source" and coverage[goal]["source_ids"] == []
    assert answer["provider_calls"] == 0
    assert service.get_case(a, e, answer["id"])["goal_coverage"] == answer["goal_coverage"]


@pytest.fixture
def budgetcase(tmp_path):
    repo = CoreRepository(tmp_path / "budget-v12.sqlite3")
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO v03_accounts(id,username,password_hash,created_at) VALUES('owner','owner','no-login',?)", (now_iso(),))
        db.execute("INSERT INTO v03_enterprises(id,name,created_at) VALUES('enterprise','Synthetic QA',?)", (now_iso(),))
        db.execute("INSERT INTO v03_memberships VALUES('owner','enterprise','owner',1)")
    calls = []

    async def transport(model, body, limit):
        calls.append(True)
        return {"text": '{"answer":"local"}', "model": model, "stop_reason": "end_turn",
                "usage": {"input_tokens": 100, "output_tokens": 50}}
    gateway = ModelGateway(repo, enabled=True, request_fn=transport)
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    grant = gateway.authorize_budget("owner", "enterprise", approval_id="V12-SYNTHETIC-NO-PROVIDER",
        max_calls=5, max_cost_usd=1, purposes=["policy_synthesis"], roles=["standard"], expires_at=expiry)["id"]
    return repo, gateway, grant, expiry, calls


def run_once(case, operation):
    return asyncio.run(case[1].call_once(account_id="owner", enterprise_id="enterprise", operation_id=operation,
        task_id="test", role="standard", purpose="policy_synthesis", context={"question": "Synthetic"},
        output_schema={"type": "object", "properties": {"answer": {"type": "string"}}, "required": ["answer"]},
        budget_grant_id=case[2]))


def test_budget_separates_actual_reserved_and_uncertain_instead_of_calling_holds_spend(budgetcase):
    first, second, third = [run_once(budgetcase, f"synthetic-{i}") for i in range(3)]
    with budgetcase[0].connection(write=True) as db:
        db.execute("UPDATE core_model_attempts SET state='outcome_unknown',actual_microusd=NULL,held_microusd=7000 WHERE id=?", (second["attempt_id"],))
        db.execute("UPDATE core_model_attempts SET state='reserved',dispatched_at=NULL,actual_microusd=NULL,held_microusd=20000 WHERE id=?", (third["attempt_id"],))
    gate = budgetcase[1].status("owner", "enterprise", provision=False)
    assert gate["known_spent_usd"] == pytest.approx(0.0007)
    assert gate["actual_spent_usd"] is None and gate["has_unknown_cost"] is True
    assert gate["reserved_usd"] == pytest.approx(0.02) and gate["uncertain_usd"] == pytest.approx(0.007)
    assert gate["uncertain_calls"] == 1 and gate["encumbered_usd"] == pytest.approx(0.0277)
    grant = gate["grants"][0]
    assert grant["known_spent_usd"] == pytest.approx(0.0007)
    assert grant["remaining_usd"] == pytest.approx(0.9723)
    assert grant["expires_at"] == budgetcase[3] and gate["next_expiry_at"] == budgetcase[3]
    assert gate["reset_at"] is None and gate["reset_policy"] == "manual_D06_approval_only"
    assert gate["cost_basis"] == "ledger_usage_estimate_not_invoice"
    assert len(budgetcase[4]) == 3


def test_expired_grant_keeps_actual_cost_history_and_does_not_invent_reset_date(budgetcase):
    run_once(budgetcase, "settled-before-expiry")
    expiry = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
    with budgetcase[0].connection(write=True) as db:
        db.execute("UPDATE core_budget_grants SET expires_at=? WHERE id=?", (expiry, budgetcase[2]))
    gate = budgetcase[1].status("owner", "enterprise", provision=False)
    assert gate["approved"] is False and gate["grants"] == []
    assert gate["known_spent_usd"] == pytest.approx(0.0007) and gate["actual_spent_usd"] == pytest.approx(0.0007)
    assert gate["expired_grants"][0]["expires_at"] == expiry
    assert gate["expired_grants"][0]["state"] == "expired"
    assert gate["reset_at"] is None and gate["next_expiry_at"] is None


def test_expired_never_used_grant_reports_prior_approval_without_mutation(budgetcase):
    repo, gateway, grant, _, calls = budgetcase
    expiry = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
    with repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_grants SET expires_at=? WHERE id=?", (expiry, grant))
    with repo.connection() as db:
        tables = [row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        before = {table: [tuple(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')] for table in tables}
    gate = gateway.status("owner", "enterprise", provision=False)
    assert "trước đã hết hiệu lực" in gate["reason_vi"]
    assert "Chưa duyệt D06" not in gate["reason_vi"]
    assert gate["approved"] is False and gate["paid_calls"] == 0
    assert gate["grants"] == [] and gate["expired_grants"][0]["expires_at"] == expiry
    assert gate["known_spent_usd"] == 0 and gate["reset_at"] is None and gate["next_expiry_at"] is None
    with repo.connection() as db:
        after = {table: [tuple(row) for row in db.execute(f'SELECT * FROM "{table}" ORDER BY rowid')] for table in tables}
    assert after == before and calls == []


def test_explicit_readonly_budget_query_never_provisions_a_pool_child(budgetcase):
    repo, gateway, _, _, calls = budgetcase
    gateway.budget_pool.authorize("V12-EXISTING-OPERATOR-POOL", "standard", 1, 1, ["policy_synthesis"],
        (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    with repo.connection() as db:
        before = [tuple(row) for row in db.execute("SELECT * FROM core_budget_grants ORDER BY id")]
    gateway.status("owner", "enterprise", provision=False)
    with repo.connection() as db:
        assert [tuple(row) for row in db.execute("SELECT * FROM core_budget_grants ORDER BY id")] == before
        assert db.execute("SELECT COUNT(*) FROM core_budget_pool_links").fetchone()[0] == 0
    assert calls == []


def test_pooled_grant_projects_shared_cost_without_double_counting_owner_spend(budgetcase):
    _, gateway, _, _, _ = budgetcase
    gateway.budget_pool.authorize("V12-POOL-COST-TEST", "standard", 2, 1, ["policy_synthesis"],
        (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    child = gateway.budget_pool.provision("owner", "enterprise")[0]
    run_once((budgetcase[0], gateway, child, budgetcase[3], budgetcase[4]), "pool-settled")
    status = gateway.status("owner", "enterprise", provision=False)
    pooled = next(grant for grant in status["grants"] if grant.get("pooled"))
    assert pooled["known_spent_usd"] == pytest.approx(0.0007) and pooled["remaining_calls"] == 1
    assert pooled["cost_scope"] == "shared_approved_pool" and pooled["reserved_usd"] == 0
    assert status["known_spent_usd"] == pytest.approx(0.0007)


def test_received_answer_without_usage_reports_unknown_cost_instead_of_zero(budgetcase):
    async def no_usage(model, body, limit):
        return {"text": '{"answer":"local answer"}', "model": model, "stop_reason": "end_turn", "usage": {}}
    budgetcase[1].request_fn = no_usage
    run_once(budgetcase, "unknown-usage")
    status = budgetcase[1].status("owner", "enterprise", provision=False)
    assert status["actual_spent_usd"] is None and status["known_spent_usd"] == 0
    assert status["uncertain_calls"] == 1 and status["uncertain_usd"] > 0
    assert status["reserved_usd"] == 0 and status["reset_at"] is None
