"""Bounded export graph READs do not become reviewed policy rules."""
import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository, json_text


@pytest.fixture
def export(tmp_path):
    repo = CoreRepository(tmp_path / "export-graph.sqlite3")
    return repo, DomainCatalog(repo)


def test_export_lookup_never_returns_source_marked_nonpublic(export):
    repo, catalog = export
    reference = catalog.lookup(["food_label"], market_code="US")["records"][0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET rights='enterprise_private' WHERE id=?", (reference["source_id"],))
    result = catalog.lookup(["food_label"], market_code="US")
    assert not any(item["source_id"] == reference["source_id"] for item in result["records"])
    with pytest.raises(CoreError):
        catalog.get_source(reference["source_id"])


@pytest.mark.parametrize("market", ["US", "DE", "JP"])
def test_export_graph_market_scope_pure_rebuild_reference_only(export, market):
    repo, catalog = export
    with repo.connection() as db:
        statements = []
        db.set_trace_callback(statements.append)
        before = db.total_changes
        graph = catalog.domain_graph(market_code=market, as_of_date="2026-10-22", db=db)
        assert db.total_changes == before
        db.set_trace_callback(None)
    assert not any("v03_accounts" in line or "v03_entities" in line or "v03_facts" in line or "v03_domain_metrics" in line or "v03_source_observations" in line for line in statements)
    assert graph == catalog.domain_graph(market_code=market, as_of_date="2026-10-22")
    assert graph["writes"] == graph["provider_calls"] == graph["network_calls"] == 0
    assert graph["domain"] == "export_reference" and not graph["legal_approval"]
    assert graph["nodes"] and graph["dependencies"]
    allowed = {"US"} if market == "US" else {"EU", "DE"} if market == "DE" else {"JP"}
    for node in graph["nodes"]:
        if node["ref"]["kind"] == "export_reference_excerpt":
            scope = node["scope"]["jurisdiction"]
            assert set([scope] if isinstance(scope, str) else scope) <= allowed
            assert node["authority_state"] == "reference_only"
    assert not any(node["ref"]["kind"] in {"rule_version", "claim_version", "policy_version"} for node in graph["nodes"])
    assert "excerpt_vi" not in json_text(graph) and "quote_original" not in json_text(graph)


def test_selected_foreign_scope_is_a_blocker_not_a_valid_claim(export):
    _, catalog = export
    reference = catalog.lookup(["food_label"], market_code="US")["records"][0]
    graph = catalog.domain_graph(market_code="DE", reference_ids=[reference["id"]], as_of_date="2026-10-22")
    assert graph["nodes"] == [] and graph["dependencies"] == []
    assert graph["blocked"] == [{"reference_id": reference["id"], "reason_code": "MARKET_SCOPE_MISMATCH"}]


def test_current_source_change_only_invalidates_its_own_export_dependencies(export):
    repo, catalog = export
    before = catalog.domain_graph(market_code="US", as_of_date="2026-10-22")
    references = {item["reference_id"]: item for item in before["dependencies"]}
    chosen = catalog.lookup(["food_label"], market_code="US")["records"][0]
    source_id = chosen["source_id"]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET version=version+1,freshness_state='needs_revalidation',observed_hash=? WHERE id=?", ("a" * 64, source_id))
        affected = {row[0] for row in db.execute("SELECT id FROM v03_domain_references WHERE source_id=?", (source_id,))}
    after = {item["reference_id"]: item for item in catalog.domain_graph(market_code="US", as_of_date="2026-10-22")["dependencies"]}
    assert references.keys() == after.keys()
    for identity, dependency in references.items():
        if identity in affected:
            assert after[identity]["dependency_hash"] != dependency["dependency_hash"]
            assert after[identity]["status"] == "blocked"
        else:
            assert after[identity] == dependency


def test_explicit_selected_rights_revoke_denies_derived_read_and_omitted_skips(export):
    repo, catalog = export
    reference = catalog.lookup(["food_label"], market_code="US")["records"][0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_sources SET rights='enterprise_private' WHERE id=?", (reference["source_id"],))
    with pytest.raises(CoreError) as denied:
        catalog.domain_graph(market_code="US", reference_ids=[reference["id"]])
    assert denied.value.code == "domain_read_forbidden" and denied.value.status_code == 403
    graph = catalog.domain_graph(market_code="US")
    assert not any(item["reference_id"] == reference["id"] for item in graph["dependencies"])


def test_export_supersession_pack_and_translation_provenance_stays_reference_only(export):
    _, catalog = export
    graph = catalog.domain_graph(market_code="DE", as_of_date="2026-10-22")
    assert any(edge["relation"] == "supersedes_export_excerpt" for edge in graph["edges"])
    assert any(node["ref"]["kind"] == "export_pack_version" for node in graph["nodes"])
    assert any(node["ref"]["kind"] == "export_reference_translation" for node in graph["nodes"])
    for node in graph["nodes"]:
        if node["ref"]["kind"] == "export_reference_translation":
            assert node["review_state"] != "approved"


def test_export_graph_unknown_or_malformed_reference_cannot_become_evidence(export):
    repo, catalog = export
    graph = catalog.domain_graph(market_code="JP", reference_ids=["not-present"], as_of_date="2026-10-22")
    assert graph["blocked"] == [{"reference_id": "not-present", "reason_code": "REFERENCE_NOT_FOUND"}]
    reference = catalog.lookup(["food_label"], market_code="JP")["records"][0]
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_domain_references SET record_json=? WHERE id=?", (json_text({"id": reference["id"], "claim_type": "eligibility"}), reference["id"]))
    graph = catalog.domain_graph(market_code="JP", reference_ids=[reference["id"]])
    assert graph["nodes"] == []
    assert graph["blocked"] == [{"reference_id": reference["id"], "reason_code": "REFERENCE_CONTRACT_INVALID"}]
