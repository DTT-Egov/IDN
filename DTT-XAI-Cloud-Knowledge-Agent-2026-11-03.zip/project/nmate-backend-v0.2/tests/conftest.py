"""Tests must never load a developer's real credentials or .env configuration."""
import os

from nmate.config import Settings


def pytest_configure(config):
    Settings.model_config["env_file"] = None
    for name in list(os.environ):
        if name.startswith("NMATE_") or name in {"OPENAI_API_KEY", "ANTHROPIC_API_KEY"}:
            os.environ.pop(name, None)
