"""One conditional action list, with an assessment that cannot compete with it."""
from __future__ import annotations

from copy import deepcopy
import itertools
import json

from langgraph.checkpoint.memory import InMemorySaver
import pytest

from nmate.agents.shipment.graph import ModelSynthesis, _base_report, _tasks, _unknowns, build_graph
from nmate.agents.shipment.models import (
    NEXT_STEPS_POLICY_VERSION, ShipmentReport, SourceBatch, SourceDocument,
    assessment_summary_error,
)
from nmate.agents.shipment.translations import REFERENCE_CATALOG, excerpt_sha256

TEA_QUESTION = (
    "Chị là chủ cơ sở trà sen ở Tây Hồ, muốn gửi thử 500 hộp trà sen 100 g sang Mỹ qua một nhà nhập khẩu. "
    "Trà ướp hoa sen thì có phải đăng ký gì với FDA không, nhãn hộp cần ghi những gì, "
    "và ba việc đầu tiên chị nên làm là gì? (THỬ NGHIỆM)"
)
TEA_ASSESSMENT = (
    "Với trà sen này, nguồn FDA hiện có chỉ là hướng dẫn nhập thực phẩm chung, chưa đủ để chốt nghĩa vụ đăng ký "
    "cơ sở hay thông báo trước. Kho nguồn chưa có điều khoản nhãn chi tiết, nên chưa thể chốt mục bắt buộc."
)
TEA_EXTENDED_ASSESSMENT = TEA_ASSESSMENT + (
    " Hồ sơ hiện chưa xác định bên đứng tên nhập khẩu, bên phụ trách FSVP và điều kiện giao hàng. "
    "Thành phần, quy trình chế biến, hạn dùng và giấy tờ còn chưa được cung cấp, nên dữ kiện đang có "
    "chưa xác nhận phạm vi áp dụng cho cơ sở hoặc sản phẩm cụ thể."
)


def complete_case():
    return {
        "product": {"sku": "MOCK-SKU", "name": "MOCK miến khô", "family": "dry_food", "origin_country": "VN",
                    "ingredients": ["Tinh bột"], "processing_description": "Sấy khô", "packaging": "Túi 250g", "shelf_life": "12 tháng"},
        "shipment": {"target_market": "US", "route": "importer", "quantity_units": 1000, "carton_count": 50,
                     "gross_weight_kg": 275, "carton_dimensions_cm": "40 × 30 × 20", "pickup_location": "MOCK Hà Nội",
                     "destination": "MOCK Mỹ", "incoterm": "MOCK EXW dự kiến",
                     "importer_of_record": "MOCK IOR tự khai", "fsvp_importer": "MOCK FSVP tự khai"},
        "consent_research": True, "consent_model": True,
    }


def tea_case():
    """Synthetic facts from the reported tea walkthrough; no live database dependency."""
    case = complete_case()
    case["product"].update(sku="TEST-TRASEN-100-001", name="Trà sen Tây Hồ ướp bông, hộp 100 g (THỬ NGHIỆM)",
                           ingredients=None, processing_description=None, shelf_life=None, certifications=None,
                           packaging="Hộp 100g (THỬ NGHIỆM)")
    case["shipment"].update(quantity_units=500, carton_count=10, gross_weight_kg=65,
                            carton_dimensions_cm="50 × 40 × 35 cm/thùng (THỬ NGHIỆM)",
                            pickup_location="Quảng An, Tây Hồ (THỬ NGHIỆM)", destination="New York (THỬ NGHIỆM)",
                            importer_of_record=None, fsvp_importer=None, incoterm=None)
    return case


@pytest.mark.parametrize("missing_ior,missing_fsvp,missing_incoterm", list(itertools.product([False, True], repeat=3)))
def test_role_and_incoterm_combinations_produce_one_bounded_conditional_plan(missing_ior, missing_fsvp, missing_incoterm):
    case = complete_case()
    for missing, field in ((missing_ior, "importer_of_record"), (missing_fsvp, "fsvp_importer"), (missing_incoterm, "incoterm")):
        if missing:
            case["shipment"][field] = None
    steps = _tasks(case, _unknowns(case), [])
    expected = (["clarify_import_roles"] if missing_ior or missing_fsvp else [])
    expected += ["clarify_delivery_terms"] if missing_incoterm else []
    expected += ["expert_preparation_review"]
    assert [step.id for step in steps] == expected
    assert 1 <= len(steps) <= 3 and len({step.id for step in steps}) == len(steps)
    assert all(step.owner_role and step.done_when and step.reason for step in steps)
    if missing_ior or missing_fsvp:
        role = steps[0]
        assert "IOR" in role.done_when and "FSVP" in role.done_when and "riêng" in role.reason
        assert "không tự sao chép" in role.reason


@pytest.mark.parametrize("gap,expected", [
    ("product", ["complete_product_dossier", "expert_preparation_review"]),
    ("quote", ["complete_quote_information", "expert_preparation_review"]),
    ("both", ["complete_product_dossier", "complete_quote_information", "expert_preparation_review"]),
    ("none", ["expert_preparation_review"]),
])
def test_other_missing_information_is_meaningful_and_complete_case_is_not_forced_to_three(gap, expected):
    case = complete_case()
    if gap in {"product", "both"}:
        case["product"]["ingredients"] = None
    if gap in {"quote", "both"}:
        case["shipment"]["gross_weight_kg"] = None
    assert [step.id for step in _tasks(case, _unknowns(case), [])] == expected


def test_tea_case_prioritizes_registration_and_label_question_instead_of_missing_incoterm():
    report = _base_report(tea_case(), SourceBatch(), TEA_QUESTION)
    assert [step.id for step in report.next_steps] == ["clarify_facility_registration", "prepare_food_label", "expert_preparation_review"]
    assert report.next_steps[0].title == "Rà phạm vi đăng ký cơ sở FDA"
    assert "IOR" not in report.next_steps[0].title and "FSVP" not in report.next_steps[0].title
    expert = report.next_steps[-1]
    assert "FDA" in expert.reason and "nhãn" in expert.reason
    assert "đúng đoạn nguồn đã truy xuất" in expert.reason
    assert "chưa mặc định nghĩa vụ hay miễn trừ" in expert.reason
    assert "nhãn" in expert.done_when and "FDA" in expert.done_when
    assert report.summary_kind == "assessment" and report.next_steps_policy_version == "0.2.3"
    assert report.question_topics == ["fda_registration", "labeling"]
    assert [answer.topic for answer in report.topic_answers] == report.question_topics


def test_fda_label_alias_prioritizes_label_and_does_not_invent_registration_intent():
    steps = _tasks(complete_case(), _unknowns(complete_case()), [], "fda_label")
    assert [step.id for step in steps] == ["prepare_food_label", "expert_preparation_review"]
    assert "nhãn" in steps[0].reason
    assert "Chưa xác nhận" in steps[0].reason


@pytest.mark.parametrize("summary", [
    "Ba việc nên làm trước: (1) xác nhận IOR và FSVP; (2) nhờ chuyên gia đăng ký cơ sở; (3) thống nhất Incoterm và kiểm nghiệm.",
    "1. Xác nhận IOR.\n2. Xác nhận FSVP.\n3. Nhờ chuyên gia rà.",
    "Điều còn thiếu:\n- Xác nhận IOR\n- Làm rõ Incoterm",
    "Ưu tiên xác nhận IOR; sau đó làm rõ FSVP; cuối cùng nhờ chuyên gia.",
    "First, identify IOR. Next steps include labeling review.",
    "dữ kiện " * 81,
])
def test_competing_or_oversized_action_summary_is_rejected_by_report_runtime_contract(summary):
    report = _base_report(tea_case(), SourceBatch(), TEA_QUESTION).model_dump(mode="json")
    report["summary"] = summary
    assert assessment_summary_error(summary)
    with pytest.raises(ValueError):
        ShipmentReport.model_validate(report)


def test_assessment_can_state_missing_facts_and_real_quantities_without_becoming_an_action_list():
    assert assessment_summary_error(TEA_ASSESSMENT) is None
    assert assessment_summary_error("Lô 1.000 sản phẩm chưa có IOR, FSVP và điều kiện giao hàng được xác nhận.") is None


def test_generation_has_headroom_with_soft_80_and_hard_160_word_limit():
    assert 40 <= len(TEA_ASSESSMENT.split()) <= 55
    for count in (80, 81, 160):
        assert assessment_summary_error("từ " * count) is None
    error = assessment_summary_error("từ " * 161)
    assert error and "161" in error and "160" in error
    assert assessment_summary_error("x" * 2000) is None
    char_error = assessment_summary_error("x" * 2001)
    assert char_error and "2001" in char_error and "2000" in char_error
    assert "40–55" in ModelSynthesis.model_json_schema()["properties"]["summary"]["description"]


def test_legacy_report_keeps_its_original_summary_and_old_actions_without_migration():
    legacy = _base_report(complete_case(), SourceBatch()).model_dump(mode="json")
    legacy.pop("summary_kind")
    legacy.pop("next_steps_policy_version")
    legacy.pop("summary_origin")
    legacy["summary"] = "Ba việc nên làm trước: (1) IOR; (2) FSVP; (3) chuyên gia."
    legacy["next_steps"] = [{"id": "clarify_importer_of_record", "title": "Mục cũ", "reason": "Nội dung lịch sử.", "evidence_ids": []}]
    before = deepcopy(legacy)
    parsed = ShipmentReport.model_validate(legacy)
    assert legacy == before and parsed.summary == before["summary"]
    assert parsed.summary_kind is None and parsed.next_steps_policy_version is None
    assert parsed.summary_origin is None
    assert parsed.next_steps[0].owner_role is None and parsed.next_steps[0].id == "clarify_importer_of_record"


def test_rule_based_report_cannot_claim_its_assessment_came_from_a_model():
    report = _base_report(tea_case(), SourceBatch(), TEA_QUESTION).model_dump(mode="json")
    assert report["summary_origin"] == "rule_based" and report["llm_used"] is False
    report["summary_origin"] = "model"
    with pytest.raises(ValueError, match="must not claim a model assessment"):
        ShipmentReport.model_validate(report)


def test_new_contract_cannot_omit_requested_topics_or_completion_fields():
    original = _base_report(tea_case(), SourceBatch(), TEA_QUESTION).model_dump(mode="json")
    for mutation in ("registration", "label", "owner", "duplicate"):
        report = deepcopy(original)
        if mutation == "registration":
            report["next_steps"] = [step for step in report["next_steps"] if step["id"] != "clarify_facility_registration"]
        elif mutation == "label":
            report["next_steps"] = [step for step in report["next_steps"] if step["id"] != "prepare_food_label"]
        elif mutation == "owner":
            report["next_steps"][0]["owner_role"] = None
        else:
            report["next_steps"][1] = deepcopy(report["next_steps"][0])
        with pytest.raises(ValueError):
            ShipmentReport.model_validate(report)


class Sources:
    async def fetch_all(self):
        return SourceBatch(sources=[SourceDocument(
            id="fda_import" if "IMPORT_" in ref.reference_id else "fda_fsvp", url=ref.url, title=ref.title,
            publisher=ref.publisher, text=ref.excerpt, content_sha256=excerpt_sha256(ref.excerpt), accessed_at="2026-10-17T10:00:00Z",
        ) for ref in REFERENCE_CATALOG.values()])


@pytest.mark.parametrize("response_mode", ["short", "extended", "competing_list"])
async def test_single_model_call_receives_the_exact_stored_plan_and_cannot_emit_another_action_list(monkeypatch, response_mode):
    calls = []
    answer = TEA_EXTENDED_ASSESSMENT if response_mode == "extended" else TEA_ASSESSMENT
    if response_mode == "extended":
        assert 80 < len(answer.split()) <= 160

    class MockModel:
        def with_structured_output(self, schema, **kwargs):
            assert kwargs == {"method": "json_schema"}
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            payload = json.loads(messages[1][1])
            return {"summary": "Ba việc nên làm trước: (1) IOR; (2) FSVP; (3) chuyên gia." if response_mode == "competing_list" else answer,
                    "ordered_finding_ids": [], "evidence_ids": [], "evidence_translations": [
                        {"evidence_id": item["id"], "original_excerpt_sha256": item["original_excerpt_sha256"],
                         "status": "unavailable", "title_vi": None, "excerpt_vi": None, "publisher_vi": None}
                        for item in payload["evidence_candidates"]]}

    monkeypatch.setattr("nmate.agents.shipment.graph.create_chat_model", lambda *_args: MockModel())
    graph = build_graph(InMemorySaver(), mode="llm", model_provider="anthropic", model_name="claude-sonnet-5-5",
                        api_key="MOCK-NOT-A-LIVE-KEY", source_provider=Sources())
    config = {"configurable": {"thread_id": "MOCK-TEA-CANONICAL"}}
    state = await graph.ainvoke({"case": tea_case(), "question": TEA_QUESTION}, config)
    stored = state["report"]
    if response_mode == "competing_list":
        assert stored["summary"] == _base_report(tea_case(), await Sources().fetch_all(), TEA_QUESTION).summary
        assert stored["summary_origin"] == "rule_based"
        assert any("không phải lời của mô hình" in warning and "Không gọi AI thêm" in warning
                   for warning in stored["warnings"])
        assert assessment_summary_error(stored["summary"]) is None
    else:
        assert stored["summary"] == answer
        assert stored["summary_origin"] == "model"
    assert stored["summary_kind"] == "assessment"
    assert stored["next_steps_policy_version"] == NEXT_STEPS_POLICY_VERSION
    payload = json.loads(calls[0][1][1])
    assert payload["question_untrusted"] == TEA_QUESTION
    assert payload["canonical_next_steps"]["steps"] == stored["next_steps"]
    assert payload["source_coverage"]["detailed_labeling_requirements_available"] is False
    assert payload["source_coverage"]["product_specific_registration_applicability_determined"] is False
    assert json.loads(json.dumps(stored, ensure_ascii=False))["next_steps"] == payload["canonical_next_steps"]["steps"]
    assert "nhãn chi tiết" in calls[0][0][1] and "không tự xác định" in calls[0][0][1].casefold()
    assert "40–55" in calls[0][0][1] and "giới hạn cứng 160" in calls[0][0][1]
    assert len(stored["evidence"]) == 2 and all(item["review_status"] == "candidate" for item in stored["evidence"])
    assert len(calls) == 1


@pytest.mark.parametrize("failure", [None, "legal", "citation", "finding", "translation", "length", "type"])
async def test_first_three_actions_question_creates_one_artifact_but_style_repair_cannot_hide_unsafe_data(
    monkeypatch, tmp_path, failure,
):
    """Run the real graph and durable service; all sources/model I/O are fixtures."""
    from nmate.config import Settings
    from nmate.models import CaseCreate, Principal, StartInput
    from nmate.service import ResearchService
    from nmate.store import Store

    calls = []

    class Model:
        def with_structured_output(self, _schema, **_kwargs):
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            payload = json.loads(messages[1][1])
            result = {
                "summary": "Ba việc đầu tiên: (1) Xác nhận bên nhập khẩu; (2) thống nhất điều kiện giao hàng; (3) nhờ chuyên gia rà hồ sơ.",
                "ordered_finding_ids": [], "evidence_ids": [],
                "evidence_translations": [
                    {"evidence_id": row["id"], "original_excerpt_sha256": row["original_excerpt_sha256"],
                     "status": "unavailable", "title_vi": None, "excerpt_vi": None, "publisher_vi": None}
                    for row in payload["evidence_candidates"]
                ],
            }
            if failure == "legal":
                result["summary"] += " Lô hàng đủ điều kiện thông quan."
            elif failure == "citation":
                result["evidence_ids"] = ["NONEXISTENT-SOURCE"]
            elif failure == "finding":
                result["ordered_finding_ids"] = ["NONEXISTENT-FINDING"]
            elif failure == "translation":
                result["evidence_translations"][0]["original_excerpt_sha256"] = "b" * 64
            elif failure == "length":
                result["summary"] += " dữ kiện" * 81
            elif failure == "type":
                result["summary"] = {"actions": "not a string"}
            return result

    monkeypatch.setattr("nmate.agents.shipment.graph.create_chat_model", lambda *_args: Model())
    settings = Settings(_env_file=None, data_dir=tmp_path, mode="llm", model_provider="anthropic",
                        model_name="claude-sonnet-5-5", OPENAI_API_KEY=None, ANTHROPIC_API_KEY="MOCK-NOT-A-LIVE-KEY")
    store = Store(tmp_path / "mock-report.sqlite")
    principal = Principal("MOCK-TENANT", "MOCK-BUSINESS")
    case = store.create_case(principal, CaseCreate.model_validate(tea_case()).model_dump(mode="json"))

    def graph_factory(checkpointer, **kwargs):
        return build_graph(checkpointer, source_provider=Sources(), **kwargs)

    service = ResearchService(store, settings, InMemorySaver(), graph_factory=graph_factory)
    run = service.start(principal, StartInput(case_id=case["case_id"], expected_case_version=case["version"],
                        idempotency_key="MOCK-ONE-PAID-REQUEST", question=TEA_QUESTION))
    await service.execute_claimed(store.claim(service.owner))
    finished = service.get_run(principal, run["run_id"])
    assert len(calls) == 1
    assert json.loads(calls[0][1][1])["question_untrusted"] == TEA_QUESTION
    if failure:
        assert finished["status"] == "failed" and finished["error"]["code"] == "MODEL_OUTPUT_INVALID"
        assert not finished["artifact_id"]
        return
    assert finished["status"] == "succeeded"
    artifact = store.get_artifact(principal, finished["artifact_id"])
    report = artifact["report"]
    assert report["mode"] == "llm" and report["llm_used"] is True
    assert report["model_provider"] == "anthropic" and report["model_name"] == "claude-sonnet-5-5"
    assert report["summary_origin"] == "rule_based"
    assert assessment_summary_error(report["summary"]) is None
    assert len(report["next_steps"]) == 3
    assert report["next_steps"] == json.loads(calls[0][1][1])["canonical_next_steps"]["steps"]
    assert any("Không gọi AI thêm" in warning for warning in report["warnings"])
