import pytest

from nmate.v03.models import Plan, PlanTask
from nmate.v03.workflow import merge_results


def task(key, depends=None):
    return PlanTask(id=key, title=key, outcome_ids=["label"], capability_id="artifact.food_label_workbook", depends_on=depends or [])


def test_plan_rejects_cycles_unknown_dependencies_and_duplicate_task_ids():
    for tasks in ([task("one", ["two"]), task("two", ["one"])], [task("one", ["missing"])], [task("one"), task("one")]):
        with pytest.raises(ValueError):
            Plan(tasks=tasks, hash="test")


def test_parallel_result_reducer_preserves_both_outcomes():
    assert merge_results({"registration": {"status": "succeeded"}}, {"label": {"status": "succeeded"}}) == {"registration": {"status": "succeeded"}, "label": {"status": "succeeded"}}
