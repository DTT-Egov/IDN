"""Main-app orchestration contracts; injected provider, no paid network calls."""
import asyncio
import json

import pytest
from fastapi.testclient import TestClient

from nmate.main.app import make_main_app, MainMissions, TOOLS
from nmate.main.conversations import MainConversationService, MainIntakeService
from nmate.main.provider import MainProvider
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.missions import MissionService
from test_v03_live_review import TEA, intake as export_intake, research
from test_v04_live_review import result
from test_v04_intake import ASSETS, upload, confirm


class Model:
    def __init__(self):
        self.calls = []
        self.pause = None
        self.fail = False

    async def __call__(self, model, payload, limit):
        self.calls.append((model, payload))
        if self.pause:
            await self.pause.wait()
        if self.fail:
            raise RuntimeError("provider failure")
        inputs = payload["input"]
        if "reference_records" in inputs:
            value = research(payload)
        elif "resolved_market" in inputs:
            value = export_intake()
        else:
            value = result(inputs["current_question"])
        return {"text": json.dumps(value, ensure_ascii=False), "model": model, "request_id": f"unit-{len(self.calls)}",
                "stop_reason": "end_turn", "usage": {"input_tokens": 5, "output_tokens": 5}}


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "main.sqlite3")
    accounts = LocalAccounts(repo)
    owner = accounts.register("owner", "TestPassword12345", "Trà Sen")
    other = accounts.register("other", "TestPassword12345", "Doanh nghiệp khác")
    model = Model()
    provider = MainProvider(repo, request_fn=model, max_attempts=12, budget_scope="global")
    missions = MainMissions(repo, model_call=provider)
    intake = MainIntakeService(repo, provider=provider, missions=missions)
    return repo, owner, other, model, provider, missions, intake, MainConversationService(intake)


def scope(owner):
    return owner["account_id"], owner["enterprise_id"]


async def docs(setup):
    _, owner, _, _, _, _, intake, chat = setup
    conv = await chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [upload(ASSETS / "tra-sen-ho-so.xlsx")], "main-documents-01", paid_consent=True)
    confirm(intake, owner, conv["intake"])
    return chat.get(*scope(owner), conv["id"])


@pytest.mark.asyncio
async def test_three_tasks_one_conversation_ssot_ledger_and_research(setup):
    _, owner, other, model, provider, missions, _, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    inventory = await chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "main-inventory-01", conv["id"], product, paid_consent=True, task_hint="sales_inventory")
    assert inventory["task_hint"] == "sales_inventory"
    planned = await chat.send_async(*scope(owner), TEA, [], "main-export-0001", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    assert len(planned["missions"]) == 1 and planned["id"] == conv["id"]
    mission = planned["missions"][0]
    assert mission["reused_fact_count"] > 0
    missions.start(*scope(owner), mission["id"], "main-start-0001")
    assert await missions.execute_next()
    latest = chat.get(*scope(owner), conv["id"])
    assert latest["missions"][0]["label"]
    assert latest["model_calls"] == provider.summary()["paid_calls"] == 4
    assert model.calls[-1][0] == "claude-opus-5-5"
    assert len(chat.list(*scope(owner))) == 1
    with pytest.raises(CoreError):
        chat.get(*scope(other), conv["id"])
    again = await chat.send_async(*scope(owner), TEA, [], "main-export-0001", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    assert again["id"] == conv["id"] and len(model.calls) == 4
    assert latest["missions"][0]["latest_start_operation_id"] == "main-start-0001"


@pytest.mark.asyncio
async def test_pending_reload_reads_never_redispatch(setup):
    _, owner, _, model, _, _, _, chat = setup
    model.pause = asyncio.Event()
    pending = asyncio.create_task(chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "pending-send-0001", paid_consent=True))
    for _ in range(100):
        if model.calls:
            break
        await asyncio.sleep(.01)
    rows = chat.list(*scope(owner))
    assert len(rows) == 1 and rows[0]["status"] == "preparing"
    assert rows[0]["pending_operation_id"] == "pending-send-0001"
    chat.get(*scope(owner), rows[0]["id"])
    assert len(model.calls) == 1
    with pytest.raises(CoreError, match="Lượt trước đang xử lý"):
        await chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "reload-extra-0001", rows[0]["id"], paid_consent=True)
    assert len(model.calls) == 1
    model.pause.set()
    value = await pending
    assert value["status"] != "preparing" and value["latest_operation_id"] == "pending-send-0001"


@pytest.mark.asyncio
async def test_failed_send_and_restart_never_replay(setup):
    _, owner, _, model, _, _, intake, chat = setup
    model.fail = True
    with pytest.raises(CoreError):
        await chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "failed-send-001", paid_consent=True)
    restarted = MainConversationService(intake)
    rows = restarted.list(*scope(owner))
    assert rows[0]["status"] == "failed" and not rows[0]["pending_operation_id"]
    with pytest.raises(CoreError):
        await restarted.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "failed-send-001", paid_consent=True)
    assert len(model.calls) == 1
    assert restarted.get(*scope(owner), rows[0]["id"])["cost"]["paid_calls"] == 1


@pytest.mark.asyncio
async def test_mission_link_crash_gap_is_recovered_without_model(setup):
    repo, owner, _, model, _, missions, intake, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    original = chat._link_mission
    chat._link_mission = lambda *args: (_ for _ in ()).throw(RuntimeError("crash before link"))
    with pytest.raises(RuntimeError):
        await chat.send_async(*scope(owner), TEA, [], "crash-gap-0001", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    # Recover both handled failures and process death after mission commit.
    chat._link_mission = original
    restored = MainConversationService(intake)
    value = restored.get(*scope(owner), conv["id"])
    assert len(value["missions"]) == 1 and value["latest_operation_id"] == "crash-gap-0001"
    assert len(model.calls) == 2
    assert len(missions.list(*scope(owner))) == 1


@pytest.mark.asyncio
async def test_free_preflight_consent_market_product_and_private_ownership(setup):
    _, owner, other, model, _, _, _, chat = setup
    for options in ({}, {"paid_consent": True, "task_hint": "export_research"},
                    {"paid_consent": True, "task_hint": "export_research", "market_code": "US"}):
        with pytest.raises(CoreError):
            await chat.send_async(*scope(owner), TEA, [], "preflight-0001", **options)
    with pytest.raises(CoreError):
        await chat.send_async(other["account_id"], owner["enterprise_id"], TEA, [], "private-00001", paid_consent=True)
    assert not model.calls


@pytest.mark.asyncio
async def test_upgrade_existing_conversation_without_identity_in_payload(setup):
    repo, owner, _, model, _, _, _, chat = setup
    conv = await docs(setup)
    with repo.connection(write=True) as db:
        row = db.execute("SELECT payload_json FROM v04_conversations WHERE id=?", (conv["id"],)).fetchone()
        old = json.loads(row[0])
        old.pop("owner_id", None)
        old.pop("enterprise_id", None)
        db.execute("UPDATE v04_conversations SET payload_json=? WHERE id=?", (json.dumps(old), conv["id"]))
    updated = await chat.send_async(*scope(owner), "Tôi muốn số hóa bán hàng và tồn kho", [], "legacy-reply-0001", conv["id"], paid_consent=True)
    assert updated["id"] == conv["id"] and updated["latest_operation_id"] == "legacy-reply-0001"
    assert len(model.calls) == 2 and updated.get("operation_error") is None


@pytest.mark.asyncio
async def test_failed_research_is_counted_in_mission_and_conversation(setup):
    _, owner, _, model, _, missions, _, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    planned = await chat.send_async(*scope(owner), TEA, [], "fail-research-p1", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    mission_id = planned["active_mission_id"]
    model.fail = True
    missions.start(*scope(owner), mission_id, "fail-research-s1")
    assert await missions.execute_next()
    mission = missions.get(*scope(owner), mission_id)
    assert mission["status"] == "failed" and mission["cost"]["paid_calls"] == 2
    assert chat.get(*scope(owner), conv["id"])["cost"]["paid_calls"] == 3
    assert not await missions.execute_next() and len(model.calls) == 3


@pytest.mark.asyncio
async def test_owner_daily_budget_is_private_shared_and_survives_restart(setup):
    repo, owner, other, model, _, _, _, _ = setup
    provider = MainProvider(repo, request_fn=model, max_attempts=1)
    payload = {"input": {"current_question": "Tôi muốn số hóa bán hàng và tồn kho"}, "instructions_vi": "test", "response_schema": {}}
    await provider("intake", payload, operation_id="daily-owner-001", account_id=owner["account_id"], enterprise_id=owner["enterprise_id"])
    restarted = MainProvider(repo, request_fn=model, max_attempts=1)
    with pytest.raises(CoreError) as error:
        await restarted("research", payload, operation_id="daily-owner-002", account_id=owner["account_id"], enterprise_id=owner["enterprise_id"])
    assert error.value.code == "LIVE_BUDGET_EXHAUSTED"
    await restarted("intake", payload, operation_id="daily-other-001", account_id=other["account_id"], enterprise_id=other["enterprise_id"])
    assert len(model.calls) == 2
    assert restarted.summary(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"])["remaining_attempts"] == 0
    assert restarted.summary()["remaining_attempts"] is None


@pytest.mark.asyncio
async def test_already_submitted_files_without_new_question_are_rejected_before_paid_dispatch(setup):
    _, owner, _, model, _, _, _, chat = setup
    conv = await docs(setup)
    with pytest.raises(CoreError) as error:
        await chat.send_async(*scope(owner), "", [upload(ASSETS / "tra-sen-ho-so.xlsx")], "duplicate-file-01", conv["id"], paid_consent=True)
    assert error.value.code == "FILES_ALREADY_SENT" and len(model.calls) == 1


@pytest.mark.asyncio
async def test_old_mock_queue_cannot_silently_start_paid_research_after_upgrade(setup):
    _, owner, _, model, _, missions, _, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    planned = await chat.send_async(*scope(owner), TEA, [], "legacy-queue-p1", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    # Legacy queues have no consent ledger, even if a prior mock start receipt
    # exists. Upgrading may never turn that into paid provider permission.
    MissionService.start(missions, *scope(owner), planned["active_mission_id"], "legacy-queue-s1")
    assert await missions.execute_next()
    latest = missions.get(*scope(owner), planned["active_mission_id"])
    assert latest["status"] == "failed" and len(model.calls) == 2


@pytest.mark.asyncio
async def test_failed_report_publishes_only_intact_valid_parts_without_replay_or_completion(setup):
    repo, owner, _, model, provider, missions, _, chat = setup
    conv = await docs(setup)
    product = conv["intake"]["product"]["id"]
    planned = await chat.send_async(*scope(owner), TEA, [], "partial-real-p1", conv["id"], product, paid_consent=True, task_hint="export_research", market_code="US")
    original = provider._request_override

    async def invalid_label(model_name, payload, limit):
        answer = await original(model_name, payload, limit)
        value = json.loads(answer["text"])
        next(a for a in value["answers"] if a["outcome_id"] == "label")["missing_fields"] = ["storage_instructions"]
        answer["text"] = json.dumps(value, ensure_ascii=False)
        return answer

    provider._request_override = invalid_label
    mid = planned["active_mission_id"]
    missions.start(*scope(owner), mid, "partial-real-s1")
    assert await missions.execute_next()
    result = missions.get(*scope(owner), mid)
    assert result["status"] == "failed" and result["label"] is None
    partial = result["strict_partial"]
    assert [a["outcome_id"] for a in partial["validated_answers"]] == ["registration"]
    assert [a["outcome_id"] for a in partial["blocked_outcomes"]] == ["label"]
    assert "audit" not in partial and partial["model_calls"] == 0
    chat.get(*scope(owner), conv["id"])
    assert len(model.calls) == 3 and result["cost"]["paid_calls"] == 2
    entity = repo.get_entity(*scope(owner), product)
    repo.propose_or_apply_facts(*scope(owner), product, [{"field": "net_quantity", "value": "200 g", "source": {"owner_confirmed": True}}], entity["version"], "partial-context-change")
    assert "strict_partial" not in missions.get(*scope(owner), mid)
    assert len(model.calls) == 3


def test_app_main_document_status_and_tool_allowlist(tmp_path):
    web = tmp_path / "web"
    web.mkdir()
    (web / "main.html").write_text("MAIN", encoding="utf-8")
    app = make_main_app(tmp_path / "app.sqlite3", web_dir=web, request_fn=Model(), refresh_sources=False)
    assert "prepare_mission" not in TOOLS
    assert {"start_mission", "send_message", "update_label_progress", "get_supported_markets"} <= TOOLS
    with TestClient(app) as client:
        assert client.get("/web/").text == "MAIN"
        status = client.get("/api/main/status").json()
        assert status["mode"] == "live_claude_main" and len(status["tasks"]) == 4
        assert status["paid_gate"]["approved"] is False
        assert status["remaining_attempts"] is None
        public = client.get("/health").json()
        assert public["paid_calls"] is None and public["provider_attempts"] is None
        assert "estimated_usd" not in public
        assert client.get("/favicon.ico").status_code == 204
