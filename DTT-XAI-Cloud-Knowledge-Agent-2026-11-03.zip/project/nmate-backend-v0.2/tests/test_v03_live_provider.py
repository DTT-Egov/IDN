"""Durable cost/replay guards with fake request functions; no external IO."""
import asyncio
import json

import pytest

from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v03.live_provider import ReviewProvider


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "provider.sqlite3")
    owner = LocalAccounts(repo).register("provider-owner", "FakePassword12345", "QA Sen")
    return repo, owner


def scope(owner, operation="operation-0001"):
    return dict(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"], operation_id=operation)


def payload(outcomes=1):
    return {"input": {"outcomes": [{}] * outcomes}, "response_schema": {"type": "object"}}


@pytest.mark.asyncio
async def test_model_policy_persisted_before_dispatch_idempotency_and_binding(setup):
    repo, owner = setup
    calls = []

    async def request(model, data, limit):
        assert provider.summary()["provider_attempts"] == len(calls) + 1
        calls.append(model)
        return {"text": json.dumps({"safe": True}), "usage": {"input_tokens": 10, "output_tokens": 20}, "request_id": "fake-id"}

    provider = ReviewProvider(repo, request_fn=request)
    first = await provider("intake", payload(2), **scope(owner))
    assert (await provider("intake", payload(2), **scope(owner))) == first
    await provider("research", payload(2), **scope(owner, "operation-0002"), mission_id="mission-fake")
    assert calls == ["claude-sonnet-5-5", "claude-opus-5-5"]
    provider.bind_attempts(owner["account_id"], owner["enterprise_id"], "mission-fake", [first["attempt_id"]])
    costs = provider.summary(account_id=owner["account_id"], enterprise_id=owner["enterprise_id"], mission_id="mission-fake")
    assert costs["provider_attempts"] == 2 and costs["estimated_usd"] > 0
    with pytest.raises(CoreError, match="nội dung khác"):
        await provider("intake", payload(1), **scope(owner))


@pytest.mark.asyncio
@pytest.mark.parametrize("failure", ["json", "timeout", "incomplete"])
async def test_failure_counts_attempt_without_retry_even_after_restart(setup, failure):
    repo, owner = setup
    calls = []

    async def request(*args):
        calls.append(1)
        if failure == "timeout":
            raise TimeoutError("SECRET must not leak")
        return {"text": "bad" if failure == "json" else "{}", "stop_reason": "max_tokens" if failure == "incomplete" else "end_turn"}

    provider = ReviewProvider(repo, request_fn=request)
    with pytest.raises(CoreError) as error:
        await provider("research", payload(), **scope(owner), mission_id="failed-mission")
    assert "SECRET" not in str(error.value)
    restarted = ReviewProvider(repo, request_fn=request)
    restarted.recover()
    with pytest.raises(CoreError) as replay:
        await restarted("research", payload(), **scope(owner), mission_id="failed-mission")
    assert replay.value.code == "LIVE_ATTEMPT_NOT_REPLAYED"
    assert calls == [1] and restarted.summary()["provider_attempts"] == 1
    assert restarted.summary()["completed_provider_calls"] == 0


@pytest.mark.asyncio
async def test_concurrent_duplicate_and_hard_budget_are_durable(setup):
    repo, owner = setup
    started, release = asyncio.Event(), asyncio.Event()

    async def request(*args):
        started.set()
        await release.wait()
        return {"text": "{}"}

    provider = ReviewProvider(repo, request_fn=request, max_attempts=1)
    pending = asyncio.create_task(provider("intake", payload(), **scope(owner)))
    await started.wait()
    with pytest.raises(CoreError) as error:
        await provider("intake", payload(), **scope(owner))
    assert error.value.code == "LIVE_ATTEMPT_NOT_REPLAYED"
    release.set()
    await pending
    provider = ReviewProvider(repo, request_fn=request, max_attempts=1)
    with pytest.raises(CoreError) as error:
        await provider("intake", payload(), **scope(owner, "operation-0002"))
    assert error.value.code == "LIVE_BUDGET_EXHAUSTED"
    assert provider.summary()["remaining_attempts"] == 0
