import pytest

from nmate.v03 import CoreError, CoreRepository, LocalAccounts


def test_password_hash_sessions_csrf_and_revocation(tmp_path):
    repo = CoreRepository(tmp_path / "identity.sqlite")
    accounts = LocalAccounts(repo)
    user = accounts.register("owner", "correct-password", "Sen")
    with repo.connection() as db:
        saved = db.execute("SELECT password_hash FROM v03_accounts").fetchone()[0]
    assert saved != "correct-password" and saved.startswith("pbkdf2_sha256$")
    assert "password_hash" not in user
    browser_a = accounts.create_session(user["account_id"])
    browser_b = accounts.create_session(accounts.login("OWNER", "correct-password")["account_id"])
    assert browser_a["token"] != browser_b["token"]
    assert accounts.get_session(browser_a["token"])["enterprise_id"] == user["enterprise_id"]
    assert accounts.validate_csrf(browser_a["token"], browser_a["csrf_token"])["account_id"] == user["account_id"]
    with pytest.raises(CoreError):
        accounts.validate_csrf(browser_a["token"], browser_b["csrf_token"])
    with repo.connection() as db:
        assert db.execute("SELECT 1 FROM v03_sessions WHERE token_hash=?", (browser_a["token"],)).fetchone() is None
    accounts.logout(browser_a["token"])
    with pytest.raises(CoreError):
        accounts.get_session(browser_a["token"])
    assert accounts.get_session(browser_b["token"])["account_id"] == user["account_id"]


def test_duplicate_wrong_password_expiry_and_no_profile_impersonation(tmp_path):
    repo = CoreRepository(tmp_path / "identity.sqlite")
    accounts = LocalAccounts(repo)
    user = accounts.register("owner", "correct-password", "Sen")
    with pytest.raises(CoreError):
        accounts.register("OWNER", "different-password", "Other")
    for username, password in [("owner", "wrong-password"), ("nonexistent", "correct-password")]:
        with pytest.raises(CoreError) as error:
            accounts.login(username, password)
        assert error.value.code == "invalid_credentials"
    with pytest.raises(CoreError):
        accounts.get_session(user["enterprise_id"])
    with pytest.raises(CoreError):
        accounts.get_session("profile=enterprise-owner")
    session = accounts.create_session(user["account_id"])
    with repo.connection(write=True) as db:
        db.execute("UPDATE v03_sessions SET expires_at='2000-01-01T00:00:00+00:00'")
    with pytest.raises(CoreError):
        accounts.get_session(session["token"])


def test_email_is_only_a_local_username_and_casefold_login_works(tmp_path):
    repo = CoreRepository(tmp_path / "email-local.sqlite")
    accounts = LocalAccounts(repo)
    created = accounts.register(" Trung@DTT.vn ", "local-test-password", "DTT vận hành chính sách")
    assert created["username"] == "trung@dtt.vn"
    logged_in = accounts.login("TRUNG@DTT.VN", "local-test-password")
    assert logged_in["account_id"] == created["account_id"]
    with pytest.raises(CoreError) as error:
        accounts.register("trung@dtt.vn", "other-local-password", "Other")
    assert error.value.code == "username_taken"
