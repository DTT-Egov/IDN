"""Main real-provider routes exercised through HTTP/MCP with no external IO."""
from datetime import datetime, timedelta, timezone
import json
import time

import httpx

from test_core_policy_http import running, register, good
from test_unified_main import Model
from test_v03_live_review import TEA


def test_main_legacy_routes_use_gateway_and_one_shared_pool(tmp_path):
    model = Model()

    async def gateway_transport(model_id, body, limit):
        assert body["input"]["capability"] in {"legacy_intake", "legacy_research"}
        assert body["task_instructions_vi"]
        response = await model(model_id, {"input": body["input"]["input"], "response_schema": body["response_schema"]}, limit)
        # The old test fixture uses a Pydantic input alias; the wire schema
        # requires the canonical field emitted by the real structured model.
        value = json.loads(response["text"])
        for answer in value.get("answers", []):
            for citation in answer.get("citations", []):
                if "quote_en" in citation:
                    citation["quote_original"] = citation.pop("quote_en")
        response["text"] = json.dumps(value, ensure_ascii=False)
        return response

    async def forbidden_native(*args):
        raise AssertionError("Native legacy provider must not dispatch")

    with running(tmp_path, gateway_request_fn=gateway_transport, gateway_enabled=True, request_fn=forbidden_native) as (app, url):
        pool = app.state.gateway.budget_pool
        expiry = (datetime.now(timezone.utc)+timedelta(hours=1)).isoformat()
        for role in ("standard", "complex"):
            pool.authorize("TEST-ONLY-GOVERNED-MAIN", role, 5, 2, ["legacy_intake", "legacy_research"], expiry)
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web:
            session = register(web, url, "main-governed")
            first_status = web.get("/api/main/status").json()
            assert first_status["remaining_attempts"] == 10
            assert first_status["max_attempts"] == 10
            assert first_status["paid_gate"]["approved"]
            gate = good(web, url, session, "core_gateway_status")
            assert gate["legacy_paid_gate"]["approved"] and all(g["pooled"] for g in gate["grants"])
            product = good(web, url, session, "core_create_entity", entity_type="product", name="Trà Sen Tây Hồ", operation_id="main-create-product")
            proposed = good(web, url, session, "core_propose_facts", entity_id=product["id"], expected_version=0,
                facts=[{"field":"name","value":"Trà Sen Tây Hồ"},{"field":"net_quantity","value":"100 g"},
                       {"field":"ingredients","value":"Trà xanh, hoa sen"},{"field":"origin_country","value":"Việt Nam"}],
                operation_id="main-propose-product")
            good(web, url, session, "core_confirm_facts", proposal_id=proposed["proposal_id"], expected_version=0,
                 proposal_hash=proposed["proposal_hash"], operation_id="main-confirm-product")
            chat = good(web, url, session, "send_message", text="Tôi muốn số hóa bán hàng và tồn kho", attachments=[],
                        operation_id="main-governed-send", task_hint="sales_inventory", paid_consent=True)
            assert chat["model_calls"] == 1
            planned = good(web, url, session, "send_message", text=TEA, attachments=[],
                operation_id="main-governed-export", conversation_id=chat["id"], product_entity_id=product["id"],
                task_hint="export_research", market_code="US", paid_consent=True)
            mission = planned["missions"][0]
            good(web, url, session, "start_mission", mission_id=mission["id"], operation_id="main-governed-start", paid_consent=True)
            deadline = time.monotonic()+15
            while True:
                current = good(web, url, session, "get_mission", mission_id=mission["id"])
                if current["status"] not in {"running", "queued"}:
                    break
                assert time.monotonic()<deadline
                time.sleep(.05)
            assert current["status"] in {"completed", "completed_partial"}, current.get("stale_reason")
            assert len(model.calls) == 3
            with app.state.repo.connection() as db:
                assert db.execute("SELECT COUNT(*) FROM core_model_attempts WHERE dispatched_at IS NOT NULL").fetchone()[0] == 3
                assert db.execute("SELECT COUNT(*) FROM v03_live_attempts WHERE state='succeeded'").fetchone()[0] == 3
            good(web, url, session, "get_conversation", conversation_id=chat["id"])
            assert len(model.calls) == 3
