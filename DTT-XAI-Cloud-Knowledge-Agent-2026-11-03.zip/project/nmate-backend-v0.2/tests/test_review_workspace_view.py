"""Pure workspace view gates and temporal separation, using isolated SQL."""
from __future__ import annotations

import copy
import socket

import pytest

from nmate.main.workspace_view import intake_workspace_view
from nmate.v03.core import CoreRepository
from nmate.v03.identity import LocalAccounts
from nmate.v04.intake import IntakeService
from test_review_architecture_acceptance import TEXT, confirm
from test_review_commands_v2 import data_snapshot


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError("Workspace queries cannot call a model or network")
    monkeypatch.setattr(socket.socket, "connect", denied)
    monkeypatch.setattr(socket.socket, "connect_ex", denied)


@pytest.fixture
def setup(tmp_path):
    repo = CoreRepository(tmp_path / "workspace-view.sqlite3")
    owner = LocalAccounts(repo).register("view-owner", "Local-only-review-password", "Trà Sen QA")
    service = IntakeService(repo)
    intake = service.prepare(owner["account_id"], owner["enterprise_id"], TEXT, [], "workspace-view-prepare")
    return repo, owner, service, intake


def project(repo, owner, intake):
    with repo.connection() as db:
        return intake_workspace_view(repo, owner["account_id"], owner["enterprise_id"], intake, db,
            {"id": "private-conversation", "cost": {"paid_calls": 0}})


def test_pending_ready_workspace_offers_review_without_sql_side_effects(setup):
    repo, owner, _service, intake = setup
    original, before = copy.deepcopy(intake), data_snapshot(repo)
    view = project(repo, owner, intake)
    assert view["primary_action"]["kind"] == "review_pending"
    assert set(view["allowed_actions"]) == {"confirm_selected", "dismiss_selected", "review_pending"}
    assert view["review"]["pending_candidate_ids"] == intake["review"]["pending_candidate_ids"]
    assert view["billing"]["local_review_model_calls"] == 0
    assert intake == original and data_snapshot(repo) == before


@pytest.mark.parametrize("overlay", [{"migration_required": True}, {"lifecycle": "review_required"}])
def test_held_workspace_does_not_offer_confirmation_even_with_pending_ids(setup, overlay):
    repo, owner, _service, intake = setup
    held = copy.deepcopy(intake)
    held["review"].update(overlay)
    assert held["review"]["pending_candidate_ids"]
    original, before = copy.deepcopy(held), data_snapshot(repo)
    view = project(repo, owner, held)
    assert view["primary_action"]["kind"] == "review_required"
    assert view["allowed_actions"] == []
    # The query gate does not erase evidence or silently settle the draft.
    assert view["review"]["pending_candidate_ids"] == held["review"]["pending_candidate_ids"]
    assert held == original and data_snapshot(repo) == before


def test_latest_receipt_and_historical_plan_do_not_replace_current_context(setup):
    repo, owner, service, intake = setup
    saved = confirm(service, owner, intake, ["name", "product_code"], "workspace-view-confirm")
    receipt = copy.deepcopy(saved["latest_confirmation_receipt"])
    historical_context = copy.deepcopy(saved["saved_context"])
    product = next(e for e in historical_context["entities"] if e["entity_type"] == "product")
    assert "ingredients" not in product["values"]
    repo.propose_or_apply_facts(owner["account_id"], owner["enterprise_id"], product["id"],
        [{"field": "ingredients", "value": "Trà xanh, hoa sen mới"}], product["version"], "workspace-view-external-change")
    before = data_snapshot(repo)
    view = project(repo, owner, saved)
    current = next(e for e in view["current_context"]["entities"] if e["id"] == product["id"])
    assert current["values"]["ingredients"] == "Trà xanh, hoa sen mới"
    assert view["historical_analysis"] == {"saved_context": historical_context, "is_historical": True}
    assert view["latest_confirmation_receipt"] == receipt
    assert view["revisions"]["context"] > historical_context["context_revision"]
    assert view["revisions"]["workspace"] == saved["review"]["revision"]
    assert data_snapshot(repo) == before
