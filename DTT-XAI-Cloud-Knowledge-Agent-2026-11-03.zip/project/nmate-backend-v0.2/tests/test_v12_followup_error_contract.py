"""Selection recovery is bounded data, never a dump of exception internals."""
import pytest

from nmate.v03.core import CoreError
from nmate.v03.mcp import public_core_error


def hint(code="product_selection_conflict", reason="selection_conflict", name="Bột sen"):
    error = CoreError(code, "Chọn đúng sản phẩm.", 409)
    error.commit_state = "not_committed"
    error.details = {
        "kind": "product_selection_required", "reason": reason, "requested_name": name,
        "matched_entities": [{"id": "entity_owned", "name": "Bột sen", "version": 2,
                              "private_fact": "never-cross"}],
        "raw_document": "never-cross", "intake_id": "not-a-draft-yet",
    }
    return error


@pytest.mark.parametrize("code,reason,name", [
    ("product_selection_conflict", "selection_conflict", "Bột sen"),
    ("ambiguous_product", "multiple_matches", ""),
])
def test_selection_offer_survives_mcp_with_only_bounded_fields(code, reason, name):
    result = public_core_error(hint(code, reason, name))
    assert result["commit_state"] == "not_committed"
    assert result["details"] == {
        "kind": "product_selection_required", "reason": reason, "requested_name": name,
        "matched_entities": [{"id": "entity_owned", "name": "Bột sen", "version": 2}],
    }


@pytest.mark.parametrize("mutation", [
    {"kind": "arbitrary"}, {"reason": "arbitrary"}, {"requested_name": "x" * 251},
    {"matched_entities": []},
    {"matched_entities": [{"id": "e", "name": "N", "version": True}]},
    {"matched_entities": [{"id": "e", "name": "N", "version": -1}]},
    {"matched_entities": [{"id": "e", "name": "N", "version": 0}] * 6},
    {"matched_entities": [{"id": "", "name": "N", "version": 0}]},
    {"matched_entities": [{"id": "e", "name": "", "version": 0}]},
])
def test_malformed_selection_offer_cannot_become_a_target(mutation):
    error = hint()
    error.details.update(mutation)
    assert "details" not in public_core_error(error)


def test_selection_details_are_not_allowed_for_other_errors():
    error = hint(code="invalid_quantity")
    assert "details" not in public_core_error(error)
