"""Query adapters share R1 pure-read projection; private DB and forbidden IO."""
import asyncio
from datetime import datetime, timedelta, timezone
import inspect
import socket

import httpx
import pytest

from nmate.core_v1.integration import CoreIntegration
from nmate.core_v1.ssot import CoreSSOTService
from nmate.main.app import make_main_app
from nmate.v03.core import CoreError
from test_core_policy_http import running, register, good
from test_r1_query_gateway import case as private_case, ledger


@pytest.fixture
def case(tmp_path):
    return private_case.__wrapped__(tmp_path)


class Registry:
    def __init__(self):
        self.tools = {}

    def tool(self, **_options):
        def add(function):
            self.tools[function.__name__] = function
            return function
        return add

    def remove_tool(self, name):
        self.tools.pop(name, None)


def registered(case):
    core = object.__new__(CoreIntegration)
    core.core = CoreSSOTService(case[0])
    # This unit harness bypasses __init__; construct the new registered
    # component before the read-only baseline, as the real factory does.
    from nmate.policy_v05.integration import Policy05Integration
    core.repo, core.policy = case[0], None
    core.policy05 = Policy05Integration(core)
    core.gateway = case[2]
    core.legacy_adapter = None
    registry = Registry()

    async def authorized(operation):
        result = operation(case[1]["account_id"])
        return await result if inspect.isawaitable(result) else result

    core.register_tools(registry, authorized)
    return core, registry


def test_direct_registered_mcp_context_and_budget_query_are_readonly(case):
    _core, registry = registered(case)
    enterprise = case[1]["enterprise_id"]
    before = ledger(case[0])
    for _ in range(3):
        context = asyncio.run(registry.tools["core_get_context"](enterprise, []))
        assert context["entities"] == [] and context["fact_refs"] == []
        assert "context_snapshot_id" not in context
        assert asyncio.run(registry.tools["core_gateway_status"](enterprise))["approved"]
    assert ledger(case[0]) == before and case[4] == []


def test_http_status_mcp_policy_get_list_history_and_context_do_not_activate(tmp_path, monkeypatch):
    calls = []

    async def idle(_self):
        # Source acquisition is an independent background command. Freeze it
        # before server startup so all-table comparison isolates query effects.
        return False

    monkeypatch.setattr(CoreIntegration, "execute_next", idle)
    connect = socket.socket.connect

    def loopback_only(sock, address):
        if isinstance(address, tuple) and address[0] in {"127.0.0.1", "::1"}:
            return connect(sock, address)
        raise AssertionError("R1 query fixtures forbid all external transport")

    monkeypatch.setattr(socket.socket, "connect", loopback_only)

    async def forbidden(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("Query never calls a model")

    with running(tmp_path, request_fn=forbidden, gateway_request_fn=forbidden, gateway_enabled=True) as (app, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web:
            session = register(web, url, "r1-http-owner")
            account = session["account"]["id"]
            gateway, core = app.state.gateway, app.state.core_extension
            gateway.budget_pool.authorize("R1-HTTP-SYNTHETIC", "standard", 2, 1,
                ["legacy_intake", "hanoi_policy_synthesis"],
                (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
            case = good(web, url, session, "policy_prepare", question="Chị cần hỗ trợ số hóa kho.",
                        operation_id="r1-policy-free-prepare")["policy_case"]
            before = ledger(core.repo)
            for _ in range(2):
                status = web.get("/api/main/status").json()
                assert status["paid_gate"]["approved"]
                assert status["legacy_paid_gate"]["purposes"]["legacy_intake"]["approved"]
                gate = good(web, url, session, "core_gateway_status")
                assert gate["approved"] and gate["paid_calls"] == 0
                context = good(web, url, session, "core_get_context", entity_ids=[])
                assert "context_snapshot_id" not in context
                read = good(web, url, session, "policy_get", case_id=case["id"])["policy_case"]
                assert read["id"] == case["id"]
                good(web, url, session, "policy_list")
                good(web, url, session, "list_conversations")
                good(web, url, session, "get_conversation", conversation_id=case["conversation_id"])
            assert ledger(core.repo) == before
            assert account == session["account"]["id"] and calls == []


def test_registered_policy_start_replays_receipt_without_current_budget_or_activation(tmp_path):
    async def forbidden(*_args, **_kwargs):
        pytest.fail("This command-receipt replay must not execute a provider")

    app = make_main_app(tmp_path / "r1-replay.sqlite3", refresh_sources=False, gateway_enabled=True,
                        request_fn=forbidden, gateway_request_fn=forbidden)
    owner = app.state.accounts.register("r1-policy-replay", "Synthetic-password-123", "Cơ sở R1")
    core = app.state.core_extension
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    pool = core.gateway.budget_pool.authorize("R1-REPLAY-APPROVAL", "standard", 1, 1,
        ["hanoi_policy_synthesis"], (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    registry = Registry()

    async def authorized(operation):
        value = operation(account)
        return await value if inspect.isawaitable(value) else value

    core.register_tools(registry, authorized)
    product = core.create_entity(account, enterprise, "product", "Trà Sen R1", "r1-replay-product")["id"]
    case = core.prepare(account, enterprise, "Chị cần hỗ trợ số hóa kho, điều kiện và cần chuẩn bị gì?",
                        "r1-replay-prepare", product_entity_id=product)["policy_case"]
    assert any(e["id"] == product for e in case["context"]["entities"])
    grant = core.gateway_status(account, enterprise)["grants"][0]["id"]
    args = dict(enterprise_id=enterprise, case_id=case["id"], operation_id="r1-replay-start",
                budget_grant_id=grant, model_role="simple", paid_consent=True)
    before_no_consent = ledger(core.repo)
    with pytest.raises(CoreError) as no_consent:
        asyncio.run(registry.tools["policy_start"](**{**args, "paid_consent": False}))
    assert no_consent.value.code == "PAID_CONSENT_REQUIRED"
    assert ledger(core.repo) == before_no_consent
    first = asyncio.run(registry.tools["policy_start"](**args))["policy_case"]
    assert first["status"] == "queued"
    with core.repo.connection(write=True) as db:
        db.execute("UPDATE core_budget_pools SET state='closed' WHERE id=?", (pool["id"],))
    core.gateway.enabled = False
    before = ledger(core.repo)
    for _ in range(2):
        replay = asyncio.run(registry.tools["policy_start"](**args))["policy_case"]
        assert replay["id"] == first["id"]
    with pytest.raises(CoreError) as changed:
        asyncio.run(registry.tools["policy_start"](**{**args, "model_role": "complex"}))
    assert changed.value.code == "idempotency_conflict"
    assert ledger(core.repo) == before
    assert before["core_model_attempts"] == []
    with core.repo.connection(write=True) as db:
        db.execute("UPDATE v03_entities SET acl='revoked' WHERE id=?", (product,))
    before_denied_read = ledger(core.repo)
    with pytest.raises(CoreError) as denied:
        asyncio.run(registry.tools["policy_start"](**args))
    assert denied.value.code in {"RESOURCE_UNAVAILABLE", "resource_unavailable", "FORBIDDEN", "forbidden"}
    assert ledger(core.repo) == before_denied_read
