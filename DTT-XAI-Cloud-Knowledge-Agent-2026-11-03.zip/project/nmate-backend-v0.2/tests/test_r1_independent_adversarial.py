"""Independent R1 counterexamples; temporary DBs and synthetic transport only."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3

import pytest

from nmate.core_v1.operator import administer
from nmate.core_v1.runtime_schema import managed_runtime, verify_runtime_database
from nmate.core_v1.schema_lifecycle import (
    LEDGER, SchemaLifecycleError, apply_plan, backup_database, create_plan, restore_database,
)
from nmate.main.app import make_main_app
from nmate.main.runtime_lock import EnterpriseRuntimeLock
from nmate.v03.core import CoreError
from nmate.v03.identity import LocalAccounts
from test_r1_query_gateway import case as gateway_case, invoke, ledger, query


@pytest.fixture
def case(tmp_path):
    return gateway_case.__wrapped__(tmp_path)


def approve_unrelated(case):
    case[2].budget_pool.authorize("R1-INDEPENDENT-OTHER", "complex", 1, 1,
        ["legacy_research"], (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat())
    return next(item["id"] for item in query(case)["grants"] if item["roles"] == ["complex"])


def test_cancelled_after_dispatch_stays_uncertain_without_activating_new_approval(case):
    original_grant = query(case)["grants"][0]["id"]

    async def cancelled(model, body, limit):
        case[4].append((model, limit))
        raise asyncio.CancelledError()

    case[2].request_fn = cancelled
    with pytest.raises(asyncio.CancelledError):
        invoke(case, original_grant, operation="independent-cancelled")
    other_grant = approve_unrelated(case)
    saved = ledger(case[0])
    with case[0].connection() as db:
        attempt = db.execute("SELECT state,held_microusd FROM core_model_attempts").fetchone()
        assert attempt["state"] == "outcome_unknown" and attempt["held_microusd"] > 0
    for _ in range(3):
        state = query(case)
        assert state["uncertain_calls"] == 1
        with pytest.raises(CoreError) as denied:
            invoke(case, other_grant, operation="independent-cancelled")
        assert denied.value.code == "OUTCOME_UNKNOWN"
    assert ledger(case[0]) == saved and len(case[4]) == 1
    assert len(saved["core_budget_pool_links"]) == len(saved["core_budget_grants"]) == 1


def test_exact_receipt_read_cannot_activate_a_different_selected_budget(case):
    original_grant = query(case)["grants"][0]["id"]
    accepted = invoke(case, original_grant, operation="independent-saved")
    other_grant = approve_unrelated(case)
    case[2].enabled = False
    saved = ledger(case[0])
    replay = invoke(case, other_grant, operation="independent-saved")
    assert replay["cached"] and replay["attempt_id"] == accepted["attempt_id"]
    assert ledger(case[0]) == saved and len(case[4]) == 1


def db_snapshot(path):
    with sqlite3.connect(path) as db:
        return list(db.iterdump())


@pytest.fixture
def schema_fixture(tmp_path):
    path = tmp_path / "schema-private.sqlite3"
    with sqlite3.connect(path) as db:
        db.execute("CREATE TABLE business(id TEXT PRIMARY KEY,value TEXT NOT NULL)")
        db.execute("INSERT INTO business VALUES('one','initial')")
    (tmp_path / "dependency.txt").write_text("synthetic stable dependency\n", encoding="utf8")
    return path


def plan(path, tmp_path, sql):
    return create_plan(path, version="independent-1", statements=[sql], source_root=tmp_path,
                       dependency_files=["dependency.txt"])


def test_schema_apply_keeps_new_business_data_and_backs_up_latest_snapshot(schema_fixture, tmp_path):
    path = schema_fixture
    prepared = plan(path, tmp_path, "CREATE INDEX business_value ON business(value)")
    with sqlite3.connect(path) as db:
        db.execute("UPDATE business SET value='owner-newer-decision'")
    changed = db_snapshot(path)
    backup = tmp_path / "fresh-before-apply.sqlite3"
    receipt = apply_plan(path, prepared, source_root=tmp_path, backup_path=backup)
    assert db_snapshot(backup) == changed
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT value FROM business").fetchone()[0] == "owner-newer-decision"
    assert receipt["business_data_writes"] == receipt["provider_calls"] == 0


def test_constraint_failure_after_dry_run_rolls_back_without_restoring_old_business_data(schema_fixture, tmp_path):
    path = schema_fixture
    prepared = plan(path, tmp_path, "CREATE UNIQUE INDEX business_unique_value ON business(value)")
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO business VALUES('two','initial')")
    before = db_snapshot(path)
    with pytest.raises(sqlite3.IntegrityError):
        apply_plan(path, prepared, source_root=tmp_path)
    assert db_snapshot(path) == before
    with sqlite3.connect(path) as db:
        assert db.execute("SELECT 1 FROM sqlite_master WHERE name=?", (LEDGER,)).fetchone() is None
        assert db.execute("SELECT 1 FROM sqlite_master WHERE name='business_unique_value'").fetchone() is None


def test_restore_sidecar_or_wrong_hash_never_changes_target(schema_fixture, tmp_path):
    path = schema_fixture
    backup = tmp_path / "offline.sqlite3"
    with EnterpriseRuntimeLock(path):
        proof = backup_database(path, backup)
    with sqlite3.connect(path) as db:
        db.execute("UPDATE business SET value='must-remain'")
    before = db_snapshot(path)
    with pytest.raises(SchemaLifecycleError, match="Checksum"):
        restore_database(path, backup, expected_backup_sha256="wrong")
    assert db_snapshot(path) == before
    sidecar = Path(str(backup) + "-shm")
    sidecar.write_bytes(b"synthetic-sidecar-not-private-data")
    try:
        with pytest.raises(SchemaLifecycleError, match="WAL|sidecar"):
            restore_database(path, backup, expected_backup_sha256=proof["sha256"])
        assert db_snapshot(path) == before
    finally:
        sidecar.unlink()


def test_managed_restart_preserves_publicly_narrowed_acl_source_verdict_and_disabled_job(tmp_path):
    def forbidden(*args, **kwargs):
        pytest.fail("Independent startup review forbids every provider transport")

    path = tmp_path / "managed-private.sqlite3"
    # Match the complete actual local-runtime schema, including the authority
    # network-check table. Constructing the refresher never executes HTTP.
    app = make_main_app(path, request_fn=forbidden, gateway_request_fn=forbidden)
    accounts, extension = app.state.accounts, app.state.core_extension
    owner = accounts.register("r1-independent-owner", "Synthetic-password-123", "Synthetic owner")
    staff = LocalAccounts(app.state.repo).register("r1-independent-staff", "Synthetic-password-123", "Synthetic staff")
    account, enterprise = owner["account_id"], owner["enterprise_id"]
    extension.core.add_member(account, enterprise, "r1-independent-staff", operation_id="independent-member")
    product = extension.create_entity(account, enterprise, "product", "Trà Sen Tổng Hợp", "independent-product")["id"]
    extension.core.grant_resource(account, enterprise, product, staff["account_id"], ["read"], ["name", "net_quantity"])
    extension.core.revoke_resource(account, enterprise, product, staff["account_id"], ["read"], ["net_quantity"])
    assert extension.core.can_read(staff["account_id"], enterprise, product, "name")
    assert not extension.core.can_read(staff["account_id"], enterprise, product, "net_quantity")
    # Real operator and curator/reviewer methods on the private fixture,
    # rather than modifying a static field-definition seed arbitrarily.
    for role in ("curator", "reviewer"):
        administer(app.state.repo, "knowledge-grant", approval_id="SYNTHETIC-R1-" + role,
                   username="r1-independent-owner", role=role)
    extension.policy.catalog.record_source_check(account, "HN-NOTICE-2026-14", result="unavailable",
                                                rationale="Synthetic review: no current legal evidence")
    extension.source_jobs.disable(account, "HN-NOTICE-2026-14")
    before = db_snapshot(path)
    assert verify_runtime_database(path)["ready"]
    with managed_runtime():
        restarted = make_main_app(path, request_fn=forbidden, gateway_request_fn=forbidden)
    assert db_snapshot(path) == before
    core = restarted.state.core_extension
    assert core.core.can_read(staff["account_id"], enterprise, product, "name")
    assert not core.core.can_read(staff["account_id"], enterprise, product, "net_quantity")
    assert core.policy.catalog.get_source("HN-NOTICE-2026-14")["availability"] == "unavailable"
    assert next(job for job in core.source_jobs.list(account) if job["source_id"] == "HN-NOTICE-2026-14")["enabled"] == 0
