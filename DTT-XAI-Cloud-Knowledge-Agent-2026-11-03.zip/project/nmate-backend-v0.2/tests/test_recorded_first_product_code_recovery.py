"""Exact historic first-send recovery never has a paid transport capability."""
import copy

import pytest

from nmate.v03.core import CoreError
import nmate.main.provider as provider_module
import nmate.v04.live_review as live
from test_unified_main import setup as setup_fixture, scope
from test_v04_live_review import Stub, result


TEXT="Chị có Trà sen Tây Hồ ướp bông, hộp 100 g, mã TSB01. Hãy trích thành nháp riêng, chưa sửa hồ sơ."


@pytest.fixture(name="workspace")
def workspace_fixture(tmp_path):
    return setup_fixture.__wrapped__(tmp_path)


async def rejected_first_send(workspace, monkeypatch, *, invalid_inventory=False, punctuation=False, contract_version=1):
    repo,owner,_,_,provider,_,_,chat=workspace
    working=[{"key":"product_code","value":"TSB01","quote":"mã TSB01","message_index":0}]
    if punctuation:
        working[0]["quote"]="mã TSB01."
    text=TEXT
    if invalid_inventory:
        text+=" Tồn trên sổ 120 hộp."
        working.append({"key":"book_quantity","value":"120","quote":"120 hộp","message_index":0})
    stub=Stub([result(text,primary="understand_business",working_answers=working,
                      assistant_text="Mình giữ các dữ kiện trong nháp để chị xác nhận.")])
    provider._request_override=stub
    original_validator=live.validate_output
    original_decorator=provider_module._decorate_main_intake
    monkeypatch.setattr(provider_module,"_decorate_main_intake",lambda payload,hint,**kwargs:original_decorator(payload,hint,contract_version=contract_version))

    def old_validator(envelope,request):
        if punctuation:
            raise CoreError("LIVE_ANSWER_UNGROUNDED","Mã sản phẩm phải khớp nguyên văn đầy đủ trong lời người dùng.",502)
        raise CoreError("LIVE_ANSWER_INVALID","Dữ kiện kiểm kê không thuộc công việc đang trao đổi.",502)

    monkeypatch.setattr(live,"validate_output",old_validator)
    request=dict(text=text,attachments=[],conversation_id=None,product_entity_id=None,draft=None,
                 target_intake_id=None,task_hint="profile_intake",market_code=None)
    with pytest.raises(CoreError) as error:
        await chat.send_async(*scope(owner),operation_id="first-product-code-legacy",paid_consent=True,**request)
    assert error.value.code==("LIVE_ANSWER_UNGROUNDED" if punctuation else "LIVE_ANSWER_INVALID") and len(stub.calls)==1
    monkeypatch.setattr(live,"validate_output",original_validator)
    monkeypatch.setattr(provider_module,"_decorate_main_intake",original_decorator)
    with repo.connection() as db:
        row=dict(db.execute("SELECT * FROM main_operations WHERE operation_id='first-product-code-legacy'").fetchone())
        response=db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id='first-product-code-legacy'").fetchone()[0]
        facts=[tuple(row) for row in db.execute("SELECT * FROM v03_fact_assertions ORDER BY id")]
    return request,row,response,facts,stub


@pytest.mark.asyncio
@pytest.mark.parametrize("contract_version", [1, 2])
async def test_first_send_recovers_the_exact_old_contract_and_reserved_conversation_without_dispatch(workspace,monkeypatch,contract_version):
    repo,owner,_,_,provider,_,_,chat=workspace
    request,row,response,facts,stub=await rejected_first_send(workspace,monkeypatch,contract_version=contract_version)
    result=await chat.recover_recorded_send_async(*scope(owner),row["operation_id"],request)
    assert result["id"]==row["conversation_id"] and result["status"]!="failed"
    assert result["intake"]["intent"]["working_answers"]=={"product_code":"TSB01"}
    assert len(stub.calls)==1 and provider.summary()["provider_attempts"]==1
    assert result["model_calls"]==1
    assert result["application_recoveries"][0]["provider_calls"]==0
    assert "Mã sản phẩm có thể" in result["application_recoveries"][0]["capability_correction_vi"]
    assert len([message for message in result["messages"] if message["role"]=="user"])==1
    again=await chat.recover_recorded_send_async(*scope(owner),row["operation_id"],request)
    assert len(again["application_recoveries"])==1 and len(stub.calls)==1
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v04_conversations").fetchone()[0]==1
        assert db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id=?",(row["operation_id"],)).fetchone()[0]==response
        assert [tuple(item) for item in db.execute("SELECT * FROM v03_fact_assertions ORDER BY id")]==facts
        assert db.execute("SELECT request_hash FROM main_operations WHERE operation_id=?",(row["operation_id"],)).fetchone()[0]==row["request_hash"]


@pytest.mark.asyncio
@pytest.mark.parametrize("mutation",["request","context","owner","genuine_inventory_error","later_operation"])
async def test_historic_product_recovery_fails_closed_for_any_drift_or_still_invalid_value(workspace,monkeypatch,mutation):
    repo,owner,other,_,provider,_,_,chat=workspace
    request,row,_,_,stub=await rejected_first_send(workspace,monkeypatch,invalid_inventory=mutation=="genuine_inventory_error")
    who=other if mutation=="owner" else owner
    if mutation=="request":
        request=copy.deepcopy(request)
        request["text"]+=" Changed"
    elif mutation=="context":
        repo.create_entity(*scope(owner),"enterprise","Doanh nghiệp đã thay đổi",operation_id="context-drift-enterprise")
    elif mutation=="later_operation":
        chat.prepare_chat_draft(*scope(owner),"Chị muốn ghi nhớ Trà Sen khác, 200 g.","later-free-draft",row["conversation_id"])
        # A newer free conversation write also changes the model context hash.
    with pytest.raises(CoreError):
        await chat.recover_recorded_send_async(*scope(who),row["operation_id"],request)
    assert len(stub.calls)==1 and provider.summary()["provider_attempts"]==1


@pytest.mark.asyncio
async def test_new_provider_contract_exposes_owner_confirmable_code_without_inventory_only_claim(workspace):
    _,owner,_,model,_,_,_,chat=workspace
    await chat.send_async(*scope(owner),"Chị muốn hiểu hồ sơ doanh nghiệp.",[],"new-code-capability-note",paid_consent=True,task_hint="profile_intake")
    payload=model.calls[0][1]
    capabilities=payload["input"]["available_capabilities"]
    assert "product_code" in capabilities["ssot_fields"]
    assert "trading_name" in capabilities["ssot_fields"]
    assert "legal_name" not in capabilities["ssot_fields"]
    assert "product_code" not in capabilities["inventory_answers_are_working_context_only"]
    assert "chủ doanh nghiệp xác nhận vào SSOT" in payload["instructions_vi"]
    assert "nháp doanh nghiệp riêng" in payload["instructions_vi"]


@pytest.mark.asyncio
async def test_false_sentence_period_rejection_recovers_but_other_ungrounded_error_remains_refused(workspace,monkeypatch):
    repo,owner,_,_,provider,_,_,chat=workspace
    request,row,response,facts,stub=await rejected_first_send(workspace,monkeypatch,punctuation=True)
    with repo.connection(write=True) as db:
        payload=chat._owned(*scope(owner),row["conversation_id"],db)
        payload["operation_error"]["message"]="Số kiểm kê AI chưa đối chiếu được với câu trả lời."
        chat._store(db,payload)
    with pytest.raises(CoreError) as error:
        await chat.recover_recorded_send_async(*scope(owner),row["operation_id"],request)
    assert error.value.code=="RECORDED_RECOVERY_REFUSED" and len(stub.calls)==1
    with repo.connection(write=True) as db:
        payload=chat._owned(*scope(owner),row["conversation_id"],db)
        payload["operation_error"]["message"]="Mã sản phẩm phải khớp nguyên văn đầy đủ trong lời người dùng."
        chat._store(db,payload)
    recovered=await chat.recover_recorded_send_async(*scope(owner),row["operation_id"],request)
    assert recovered["intake"]["intent"]["working_answers"]=={"product_code":"TSB01"}
    assert len(stub.calls)==1 and provider.summary()["provider_attempts"]==1
    with repo.connection() as db:
        assert db.execute("SELECT response_json FROM v03_live_attempts WHERE operation_id=?",(row["operation_id"],)).fetchone()[0]==response
        assert [tuple(item) for item in db.execute("SELECT * FROM v03_fact_assertions ORDER BY id")]==facts
