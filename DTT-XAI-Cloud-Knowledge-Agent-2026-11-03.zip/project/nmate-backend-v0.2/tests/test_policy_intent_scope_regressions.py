"""Question-bound policy routing. Private SQL fixtures, no network/model calls."""
import copy
import json

import pytest

from nmate.main.history import history_metadata
from nmate.policy_v1 import KnowledgeCatalog, PolicyService
from nmate.policy_v1.service import resolve_intent
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.identity import LocalAccounts


@pytest.fixture
def policy(tmp_path):
    repo = CoreRepository(tmp_path / "policy-intent-scope.sqlite")
    accounts = LocalAccounts(repo)
    owner = accounts.register("policy_scope_owner", "fixture-only-password", "Cơ sở mới thử nghiệm")
    catalog = KnowledgeCatalog(repo)
    catalog.bootstrap_official_notice()
    catalog.bootstrap_digital_source_pack()
    service = PolicyService(repo)
    return repo, owner, accounts, service


def prepare(policy, question, operation="prepare"):
    _, owner, _, service = policy
    return service.prepare(owner["account_id"], owner["enterprise_id"], question, operation)


def test_mixed_digital_and_export_preserves_both_goals_without_warehouse_invention(policy):
    result = prepare(policy, "Chị muốn chuyển đổi số và xuất khẩu, Hà Nội có chính sách nào hỗ trợ?")
    assert result["intent"]["goals"] == ["digital_transformation", "market_development"]
    coverage = {item["goal"]: item for item in result["goal_coverage"]}
    assert coverage["digital_transformation"]["source_ids"]
    assert coverage["digital_transformation"]["status"] == "partially_answered"
    assert coverage["market_development"]["status"] == "needs_source"
    assert coverage["market_development"]["source_ids"] == []
    assert "xuất khẩu" in result["lead_vi"].lower()
    assert "kho" not in result["lead_vi"].lower()
    assert result["result_status"] == "partially_answered"
    assert len(result["outcomes"][0]["per_goal"]) == 2
    assert not result["provider_used"] and result["provider_calls"] == 0
    meta = history_metadata({"policy_cases": [result], "active_policy_case_id": result["id"]})
    assert "xuất khẩu" in meta["display_title"].lower() and "kho" not in meta["display_title"].lower()
    assert "Đã có kết quả" not in meta["history_state_vi"]


@pytest.mark.parametrize("question", ["Hôm nay thời tiết Hà Nội thế nào?", "Khi nào Hà Nội có mưa?"])
def test_weather_is_explicitly_unsupported_without_retrieval_or_ssot(policy, monkeypatch, question):
    repo, owner, _, service = policy
    monkeypatch.setattr(service.catalog, "retrieve", lambda *a, **kw: pytest.fail("Weather must not retrieve policy evidence"))
    result = prepare(policy, question)
    assert result["intent"]["request_scope"] == "unsupported"
    assert result["result_status"] == "unsupported" and not result["startable"]
    assert result["outcomes"] == result["sources"] == result["findings"] == []
    assert result["context_fields"] == [] and result["context"]["entities"] == []
    assert "chưa hỗ trợ" in result["lead_vi"].lower()
    assert result["provider_calls"] == 0
    reloaded = service.get(owner["account_id"], owner["enterprise_id"], result["id"])
    assert reloaded["result_status"] == "unsupported" and "source_update" not in reloaded
    meta = history_metadata({"policy_cases": [reloaded], "active_policy_case_id": result["id"]})
    assert meta["history_state_vi"] == "Nhu cầu ngoài phạm vi bản này"
    assert "kho" not in meta["display_title"].lower()
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM pol_members").fetchone()[0] == 0


def test_weather_cannot_reach_gateway_even_with_invented_grant(policy):
    _, owner, _, service = policy
    calls = []

    class Gateway:
        def _grant(self, *args):
            calls.append(args)
            pytest.fail("Unsupported question must be rejected before grant lookup/reservation")

    service.gateway = Gateway()
    result = prepare(policy, "Ngày mai Hà Nội nắng hay mưa?")
    with pytest.raises(CoreError) as blocked:
        service.start(owner["account_id"], owner["enterprise_id"], result["id"], "start", "not-a-real-grant")
    assert blocked.value.code == "policy_scope_not_startable"
    assert calls == []


def test_free_broad_digital_guide_does_not_claim_saved_claude_or_warehouse(policy):
    _, owner, _, service = policy
    result = prepare(policy, "Cơ sở chị muốn chuyển đổi số, có chương trình nào hỗ trợ?")
    update = service.get(owner["account_id"], owner["enterprise_id"], result["id"])["source_update"]
    assert "kết quả Claude đã lưu" not in update["scope_vi"]
    assert "chưa gọi claude" in update["scope_vi"].lower()
    assert "kho" not in json.dumps(update["business_next_action"], ensure_ascii=False).lower()
    assert update["eligibility_state"] == "awaiting_rule_review"
    assert update["application_status"] == "unknown"
    assert all(source["legal_currency"] == "not_verified" for source in update["sources"])


def test_actual_saved_claude_receipt_can_be_truthfully_preserved(policy):
    _, owner, _, service = policy
    from nmate.policy_v1.source_update import build_source_update
    result = prepare(policy, "Số hóa kho có chương trình nào?")
    paid = {**copy.deepcopy(result), "provider_used": True, "provider_calls": 1,
            "provider_receipt": {"attempt_id": "fixture-recorded-not-a-call"}}
    original = copy.deepcopy(paid)
    assert "Giữ nguyên kết quả Claude đã lưu" in build_source_update(service.catalog, paid)["scope_vi"]
    assert paid == original
    failed = {**copy.deepcopy(result), "provider_used": False, "provider_calls": 1,
              "provider_receipt": {"attempt_id": "recorded-failed-attempt"}}
    failed_copy = build_source_update(service.catalog, failed)["scope_vi"]
    assert "kết quả Claude đã lưu" not in failed_copy and "chưa gọi Claude" not in failed_copy
    assert "không gọi thêm Claude" in failed_copy


def test_new_enterprise_cannot_inherit_another_enterprise_or_completed_policy_claim(policy):
    repo, owner, accounts, service = policy
    old = prepare(policy, "Số hóa kho có chương trình nào?", "owner-question")
    newcomer = accounts.register("policy_scope_new_owner", "fixture-only-password", "Cơ sở khác mới")
    result = service.prepare(newcomer["account_id"], newcomer["enterprise_id"],
        "Chị muốn chuyển đổi số và xuất khẩu", "new-question")
    assert result["context"]["enterprise_id"] == newcomer["enterprise_id"]
    assert result["context"]["entities"] == []
    assert result["provider_calls"] == 0 and result["id"] != old["id"]
    with pytest.raises(CoreError):
        service.get(owner["account_id"], owner["enterprise_id"], result["id"])
    with repo.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM v03_entities").fetchone()[0] == 0


def test_unspecified_policy_is_a_question_not_a_completed_result(policy):
    result = prepare(policy, "Hà Nội có chính sách nào cho doanh nghiệp?")
    assert result["intent"]["request_scope"] == "needs_clarification"
    assert result["result_status"] == "needs_clarification" and not result["startable"]
    assert result["sources"] == []
    meta = history_metadata({"policy_cases": [result], "active_policy_case_id": result["id"]})
    assert meta["history_state_vi"] == "Cần làm rõ mục tiêu hỗ trợ"


def test_explicit_warehouse_stays_specific_and_export_only_cannot_borrow_digital_sources(policy):
    assert resolve_intent("Số hóa kho cần gì?")["goal"] == "digital_inventory"
    result = prepare(policy, "Hà Nội có chính sách nào hỗ trợ xuất khẩu?", "export-only")
    assert result["goal_coverage"][0]["goal"] == "market_development"
    assert result["goal_coverage"][0]["status"] == "needs_source"
    assert result["sources"] == [] and not result["startable"]


@pytest.mark.parametrize(("question", "goals"), [
    ("Chị không cần chuyển đổi số, chị muốn hỗ trợ xuất khẩu", ["market_development"]),
    ("Chị muốn chuyển đổi số bán hàng, không cần quản lý kho", ["digital_transformation"]),
])
def test_negated_goal_does_not_supply_an_unrequested_program(question, goals):
    assert resolve_intent(question)["goals"] == goals


def test_broad_digital_must_not_inherit_an_approved_warehouse_only_rule(policy):
    from nmate.v03.core import now_iso
    from test_policy_v1 import member

    repo, owner, _, service = policy
    with repo.connection(write=True) as db:
        db.execute("INSERT INTO pol_knowledge_roles VALUES(?,'admin','hanoi_policy',?,?,NULL)",
                   (owner["account_id"], "fixture-only", now_iso()))
    rule = member((repo, owner, None, service.catalog), goal="digital_inventory")
    service.catalog.release_pack(owner["account_id"], "WAREHOUSE ONLY TEST RULE", [rule["member_id"]])
    warehouse = prepare(policy, "Số hóa kho có chương trình nào phù hợp?", "warehouse")
    broad = prepare(policy, "Chuyển đổi số có chương trình nào phù hợp?", "broad")
    assert any(finding["member_id"] == rule["member_id"] for finding in warehouse["findings"])
    assert not any(finding["member_id"] == rule["member_id"] for finding in broad["findings"])
    assert next(outcome for outcome in broad["outcomes"] if outcome["id"] == "eligibility")["status"] == "awaiting_rule_review"
    # Experts may publish a genuinely broad rule, with its own review/evidence.
    general = member((repo, owner, None, service.catalog), goal="digital_transformation", identity="TEST-SOURCE-B")
    assert general["review_state"] == "draft"  # proposal receipt, not inferred from prepare


@pytest.mark.parametrize("paid", [False, True])
def test_legacy_scope_projection_is_read_only_and_preserves_actual_paid_analysis(policy, paid):
    from nmate.v03.core import json_text

    repo, owner, _, service = policy
    result = prepare(policy, "Chị muốn chuyển đổi số và xuất khẩu, có chương trình nào hỗ trợ?")
    legacy = copy.deepcopy(result)
    legacy["intent"] = {"schema_version": "policy-intent/1", "goal": "digital_inventory",
                        "outcome_types": ["policy_discovery"], "clarification_vi": None}
    legacy.pop("goal_coverage")
    legacy.pop("startable")
    if paid:
        legacy.update(provider_used=True, provider_calls=1,
                      provider_receipt={"attempt_id": "recorded-fixture-never-dispatched"},
                      model_analysis={"recorded_selection": "must-stay-exact"})
    with repo.connection(write=True) as db:
        db.execute("UPDATE pol_missions SET payload_json=? WHERE id=?", (json_text(legacy), result["id"]))
    reloaded = service.get(owner["account_id"], owner["enterprise_id"], result["id"])
    correction = reloaded["scope_update"]
    assert correction["intent"]["goals"] == ["digital_transformation", "market_development"]
    assert correction["provider_calls"] == 0 and correction["ssot_write"] is False
    if paid:
        assert reloaded["model_analysis"] == legacy["model_analysis"]
        assert reloaded["outcomes"] == legacy["outcomes"]
        assert reloaded["provider_receipt"] == legacy["provider_receipt"]
    else:
        assert reloaded["intent"] == correction["intent"]
        assert correction["requires_reprepare"] is True and not reloaded["startable"]
        service.gateway = object()  # Scope check happens before any gateway method.
        with pytest.raises(CoreError) as blocked:
            service.start(owner["account_id"], owner["enterprise_id"], result["id"], "legacy-start", "fake-grant")
        assert blocked.value.code == "policy_plan_refresh_required"
    assert "kho" not in reloaded["source_update"]["business_next_action"]["draft_message_vi"].lower()
    with repo.connection() as db:
        assert json.loads(db.execute("SELECT payload_json FROM pol_missions WHERE id=?", (result["id"],)).fetchone()[0]) == legacy


def test_actual_mcp_new_owner_weather_history_reload_and_gate_are_honest(tmp_path):
    import httpx
    from test_core_policy_http import good, register, running

    calls = []

    async def denied(*args, **kwargs):
        calls.append((args, kwargs))
        pytest.fail("No paid model transport may run")

    with running(tmp_path, request_fn=denied, gateway_request_fn=denied) as (_, url):
        with httpx.Client(base_url=url, trust_env=False, timeout=20) as web:
            session = register(web, url, "policy-routing-new-owner")
            case = good(web, url, session, "policy_prepare", question="Hôm nay Hà Nội có mưa không?", operation_id="weather-case")["policy_case"]
            assert case["result_status"] == "unsupported" and case["cost_gate"]["approved"] is False
            chat = good(web, url, session, "get_conversation", conversation_id=case["conversation_id"])
            assert chat["status"] == "unsupported" and chat["model_calls"] == 0
            assert chat["messages"][-1]["text"] == case["lead_vi"]
            listed = good(web, url, session, "list_conversations")
            item = next(item for item in listed if item["id"] == case["conversation_id"])
            assert item["history_state_vi"] == "Nhu cầu ngoài phạm vi bản này"
            reloaded = good(web, url, session, "policy_get", case_id=case["id"])["policy_case"]
            assert reloaded["result_status"] == "unsupported"
    assert calls == []


@pytest.mark.asyncio
async def test_full_langgraph_contract_keeps_mixed_goal_gap_at_publication_with_fake_gateway(policy):
    from test_policy_v1 import FixtureGateway

    _, owner, _, service = policy
    gateway = FixtureGateway()
    service.gateway = gateway
    result = prepare(policy, "Chị cần chuyển đổi số và xuất khẩu, có chương trình nào hỗ trợ?", "mixed-worker")
    service.start(owner["account_id"], owner["enterprise_id"], result["id"], "fixture-start", "fixture-no-real-grant")
    completed = await service.execute_next()
    assert completed["status"] == "completed_partial", completed.get("error")
    assert gateway.calls == 1  # in-process fixture, not an API transport
    context = gateway.contexts[0]
    assert context["intent"]["goals"] == ["digital_transformation", "market_development"]
    assert "xuất khẩu" in context["question"]
    assert any(task["id"] == "find_goal_specific_program" for task in context["analysis_candidates"]["next_tasks"])
    assert next(item for item in completed["goal_coverage"] if item["goal"] == "market_development")["status"] == "needs_source"
    assert await service.execute_next() is None and gateway.calls == 1
