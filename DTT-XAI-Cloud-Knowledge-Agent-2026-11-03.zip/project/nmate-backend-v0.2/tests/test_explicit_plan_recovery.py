"""Free migration of the exact saved intake; every provider callback is local."""
import json

import pytest

from nmate.main.explicit_plan_recovery import recover_explicit_intake_plan
from nmate.v03 import live_review
from nmate.v03.core import CoreError, json_text
from nmate.v03.models import Outcome
from test_explicit_intake_server_contract import QUESTION, RECORDED
from test_unified_main import setup as shared_setup, docs, scope


@pytest.fixture(name="workspace")
def workspace_fixture(tmp_path):
    return shared_setup.__wrapped__(tmp_path)


class FreeSourceRefresh:
    def __init__(self):
        self.calls = []

    async def refresh(self, account, enterprise, market_code, topics):
        self.calls.append((account, enterprise, market_code, topics))
        return {"network_refresh": True, "sources": [], "http_requests": 0,
                "note_vi": "Injected local source check, never an actual network request."}


async def old_waiting_plan(workspace, monkeypatch):
    repo, owner, _, model, provider, missions, _, chat = workspace
    conv = await docs(workspace)
    product = conv["intake"]["product"]["id"]
    callback = provider.request_fn

    async def recorded_callback(model_name, payload, limit):
        if "resolved_market" in payload["input"] and "reference_records" not in payload["input"]:
            model.calls.append((model_name, payload))
            return {"text": json_text(RECORDED), "model": model_name, "request_id": "local-recorded-intake",
                    "stop_reason": "end_turn", "usage": {"input_tokens": 5, "output_tokens": 5}}
        return await callback(model_name, payload, limit)

    provider.request_fn = recorded_callback
    original_projection = live_review.interpret_validated_intake

    def old_projection(intake, question, market_code=None):
        value, name = original_projection(intake, question, market_code)
        value.outcomes = [Outcome(id="clarification", title="Làm rõ mục tiêu", question_part=RECORDED["outcomes"][0]["question_quote"])]
        value.ambiguities = list(intake.ambiguities)
        value.preliminary_information_gaps = []
        value.server_recovered_outcomes = []
        return value, name

    monkeypatch.setattr(live_review, "interpret_validated_intake", old_projection)
    try:
        planned = await chat.send_async(*scope(owner), QUESTION, [], "explicit-old-intake", conv["id"], product,
                                       paid_consent=True, task_hint="export_research", market_code="US")
    finally:
        monkeypatch.setattr(live_review, "interpret_validated_intake", original_projection)
    mid = planned["active_mission_id"]
    assert missions.get(*scope(owner), mid)["status"] == "waiting_input"
    refresh = FreeSourceRefresh()
    missions.source_refresher = refresh
    return mid, product, refresh


def snapshot(repo):
    with repo.connection() as db:
        return {table: [tuple(row) for row in db.execute("SELECT * FROM " + table)] for table in (
            "v03_live_attempts", "v03_live_review_outputs", "v03_entities", "v03_current_facts", "v03_fact_assertions")}


@pytest.mark.asyncio
async def test_exact_saved_plan_rebinds_tasks_and_source_coverage_without_repeating_paid_intake(workspace, monkeypatch):
    repo, owner, _, model, provider, missions, _, _ = workspace
    mid, _, refresh = await old_waiting_plan(workspace, monkeypatch)
    before, calls, cost = snapshot(repo), len(model.calls), provider.summary()
    result = await recover_explicit_intake_plan(missions, *scope(owner), mid)
    assert result["status"] == "planned" and result["research_scope"]["can_start_research"]
    assert {outcome["id"] for outcome in result["intent"]["outcomes"]} == {"registration", "label"}
    assert result["intent"]["ambiguities"] == []
    assert result["intent"]["preliminary_information_gaps"] == RECORDED["ambiguities"]
    assert result["intent"]["requested_action_count"] == 3
    assert {task["id"] for task in result["plan"]["tasks"]} == {"registration-research", "label-research", "label-workbook"}
    assert result["knowledge"]["source_refs"]
    assert result["knowledge"]["coverage"]["requested"] == ["food_label", "facility_registration"]
    assert result["answers"] == result["artifacts"] == []
    assert result["plan_recovery"]["model_calls"] == result["plan_recovery"]["ssot_writes"] == 0
    assert result["research_provenance"]["synthesis_mode"] == "research_not_started"
    assert snapshot(repo) == before and len(model.calls) == calls and provider.summary() == cost
    assert len(refresh.calls) == 1
    again = await recover_explicit_intake_plan(missions, *scope(owner), mid)
    assert again["version"] == result["version"] and len(refresh.calls) == 1
    with repo.connection() as db:
        audit = db.execute("SELECT original_rows_json FROM main_explicit_intake_recoveries WHERE mission_id=?", (mid,)).fetchone()
        assert json.loads(audit[0])["mission"]["status"] == "waiting_input"
        assert not db.execute("SELECT 1 FROM main_research_authorizations WHERE mission_id=?", (mid,)).fetchone()


@pytest.mark.asyncio
@pytest.mark.parametrize("drift", ["question", "facts", "receipt", "provider_unknown", "server_conflict", "started", "no_source_refresh"])
async def test_recovery_does_not_clear_other_guards_or_replay_uncertain_or_started_work(workspace, monkeypatch, drift):
    repo, owner, _, model, _, missions, _, _ = workspace
    mid, product, refresh = await old_waiting_plan(workspace, monkeypatch)
    if drift == "facts":
        entity = repo.get_entity(*scope(owner), product)
        repo.propose_or_apply_facts(*scope(owner), product, [{"field": "net_quantity", "value": "200 g", "source": {"owner_confirmed": True}}], entity["version"], "explicit-drift")
    elif drift == "no_source_refresh":
        missions.source_refresher = None
    else:
        with repo.connection(write=True) as db:
            if drift in {"question", "server_conflict"}:
                row = db.execute("SELECT payload_json FROM v03_missions WHERE id=?", (mid,)).fetchone()
                value = json.loads(row[0])
                if drift == "question":
                    value["question"] += " Nội dung đã bị đổi."
                else:
                    value["intent"]["ambiguities"].append("Tên sản phẩm khác hồ sơ đang chọn.")
                db.execute("UPDATE v03_missions SET payload_json=? WHERE id=?", (json_text(value), mid))
            elif drift == "receipt":
                db.execute("UPDATE v03_live_attempts SET response_json='{}' WHERE operation_id='explicit-old-intake'")
            elif drift == "provider_unknown":
                db.execute("UPDATE v03_live_attempts SET state='outcome_unknown' WHERE operation_id='explicit-old-intake'")
            else:
                db.execute("UPDATE v03_task_attempts SET state='running' WHERE mission_id=?", (mid,))
    original, calls = snapshot(repo), len(model.calls)
    with pytest.raises(CoreError):
        await recover_explicit_intake_plan(missions, *scope(owner), mid)
    assert snapshot(repo) == original and len(model.calls) == calls and not refresh.calls


@pytest.mark.asyncio
async def test_recovery_authorizes_owner_before_read_or_source_refresh(workspace, monkeypatch):
    _, _, other, model, _, missions, _, _ = workspace
    mid, _, refresh = await old_waiting_plan(workspace, monkeypatch)
    calls = len(model.calls)
    with pytest.raises(CoreError):
        await recover_explicit_intake_plan(missions, *scope(other), mid)
    assert len(model.calls) == calls and not refresh.calls
