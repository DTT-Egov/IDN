from nmate.main.history import history_metadata


def test_history_keeps_export_and_employee_training_as_distinct_topics():
    result = history_metadata({"status": "prepared", "task_hint": "hanoi_policy",
        "active_policy_case_id": "p", "policy_cases": [{"id": "p", "intent": {
            "goals": ["market_development", "workforce_training"], "request_scope": "in_scope"},
            "result_status": "partially_answered"}]})
    assert "Đào tạo nhân viên" in result["topic_title"]
    assert "xuất khẩu" in result["topic_title"].lower()


def test_restocking_history_does_not_claim_count_reconciliation():
    result = history_metadata({"status": "ready", "task_hint": "sales_inventory",
        "intake": {"intent": {"primary": "digitize_operations", "focus": "restocking_planning"}}})
    assert result["topic_title"] == "Lập kế hoạch nhập hàng"
