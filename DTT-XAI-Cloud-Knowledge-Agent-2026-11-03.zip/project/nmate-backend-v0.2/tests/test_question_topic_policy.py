"""Question relevance and fail-closed regulatory coverage without network/model I/O."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json

from langgraph.checkpoint.memory import InMemorySaver
import pytest

from nmate.agents.shipment.graph import _base_report, _ordered_question_topics, build_graph
from nmate.agents.shipment.models import ShipmentReport, SourceBatch, SourceDocument
from nmate.agents.shipment.sources import SOURCE_CATALOG
from nmate.agents.shipment.translations import REFERENCE_CATALOG
from test_canonical_actions import TEA_QUESTION, tea_case


def topic_sources(exclude=()) -> SourceBatch:
    """Synthetic document snapshots assembled from exact known official clauses.

    They exercise source matching, not a live retrieval/freshness claim.
    """
    sources = []
    for spec in SOURCE_CATALOG:
        if spec.id in exclude:
            continue
        refs = [ref for ref in REFERENCE_CATALOG.values() if ref.url == spec.url]
        if not refs:
            continue
        text = "\n".join(ref.excerpt for ref in refs)
        sources.append(SourceDocument(
            id=spec.id, url=spec.url, title=refs[0].title, publisher=spec.publisher,
            text=text, content_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
            accessed_at="2026-10-18T00:00:00Z",
        ))
    return SourceBatch(sources=sources)


@pytest.mark.parametrize("question,topics,actions", [
    (TEA_QUESTION, ["fda_registration", "labeling"],
     ["clarify_facility_registration", "prepare_food_label", "expert_preparation_review"]),
    ("Tôi có Mứt Sen đi Mỹ. Ai nộp thông báo trước lô hàng và nộp khi nào?", ["prior_notice"],
     ["prepare_prior_notice", "clarify_import_roles", "expert_preparation_review"]),
    ("Bột Sen cần chứng nhận nào khi nhập Mỹ?", ["certifications"],
     ["clarify_certification_requirements", "complete_product_dossier", "expert_preparation_review"]),
    ("Tôi muốn hỏi báo giá vận chuyển trà sen sang New York.", ["quote"],
     ["complete_quote_information", "clarify_delivery_terms", "expert_preparation_review"]),
    ("What food labels and facility registration are required?", ["labeling", "fda_registration"],
     ["prepare_food_label", "clarify_facility_registration", "expert_preparation_review"]),
    ("Who can submit prior notice and when?", ["prior_notice"],
     ["prepare_prior_notice", "clarify_import_roles", "expert_preparation_review"]),
])
def test_report_actions_and_answers_follow_the_actual_question(question, topics, actions):
    report = _base_report(tea_case(), topic_sources(), question)
    assert report.question_topics == topics
    assert [item.topic for item in report.topic_answers] == topics
    assert [item.id for item in report.next_steps] == actions
    assert len(report.next_steps) <= 3
    assert all(item.owner_role and item.done_when for item in report.next_steps)
    assert report.next_steps_policy_version == "0.2.3"
    assert ShipmentReport.model_validate(report.model_dump()) == report


def test_generic_question_keeps_conditional_plan_without_unasked_label_or_registration_answer():
    report = _base_report(tea_case(), topic_sources(), "Tôi nên bắt đầu từ đâu?")
    assert report.question_topics == report.topic_answers == []
    assert [item.id for item in report.next_steps] == [
        "clarify_import_roles", "clarify_delivery_terms", "expert_preparation_review",
    ]


def test_all_requested_topics_get_answers_even_when_canonical_plan_is_bounded_to_three():
    question = "Nhãn, thông báo trước, đăng ký cơ sở, chứng nhận và báo giá vận chuyển cần gì?"
    report = _base_report(tea_case(), topic_sources(), question)
    assert report.question_topics == ["labeling", "prior_notice", "fda_registration", "certifications", "quote"]
    assert len(report.topic_answers) == 5 and len(report.next_steps) == 3
    assert [item.id for item in report.next_steps] == [
        "prepare_food_label", "prepare_prior_notice", "clarify_facility_registration",
    ]
    assert len(report.summary.split()) <= 160


def test_tea_answers_registration_condition_and_label_items_without_deciding_case_compliance():
    report = _base_report(tea_case(), topic_sources(), TEA_QUESTION)
    registration, label = report.topic_answers
    assert registration.coverage == label.coverage == "available"
    assert "trừ khi thuộc diện miễn" in registration.answer
    assert "chưa thể chốt riêng" in registration.answer
    assert "đại diện tại Mỹ" in registration.answer
    assert all(term in label.answer for term in ("lượng tịnh", "danh sách thành phần", "địa chỉ", "dinh dưỡng", "tiếng Anh", "vừng"))
    assert "chưa xác nhận nhãn đã đáp ứng" in label.answer
    assert registration.applicability == label.applicability == "requires_expert_confirmation"
    assert set(registration.evidence_ids + label.evidence_ids) <= {item.id for item in report.evidence}


def test_prior_notice_answers_who_when_and_retains_limits_and_exemptions():
    report = _base_report(tea_case(), topic_sources(), "Mứt Sen: ai nộp thông báo trước và khi nào?")
    answer = report.topic_answers[0]
    assert answer.coverage == "available"
    assert all(term in answer.answer for term in (
        "bất kỳ người nào biết đủ thông tin", "2 giờ", "4 giờ", "8 giờ", "trước khi gửi", "30 ngày", "15 ngày",
        "chưa xác nhận lô hàng này được miễn", "chưa chốt hạn nộp cụ thể",
        "cửa khẩu đầu tiên tại Mỹ",
    ))
    assert "cảng đầu tiên" not in answer.answer
    assert any("prior_notice_who" in eid for eid in answer.evidence_ids)
    assert any("prior_notice_when" in eid for eid in answer.evidence_ids)
    assert any("prior_notice_exemptions" in eid for eid in answer.evidence_ids)


@pytest.mark.parametrize("excluded,question,topic,forbidden", [
    (("fda_registration",), "Trà sen có phải đăng ký FDA?", "fda_registration", ("phải đăng ký trước khi", "trang trại")),
    (("fda_prior_notice",), "Ai nộp thông báo trước và khi nào?", "prior_notice", ("2 giờ", "4 giờ", "8 giờ", "bất kỳ người nào")),
    (("fda_labeling", "fda_registration", "fda_ingredients", "fda_allergens"), "Nhãn trà sen ghi gì?", "labeling", ("lượng tịnh", "vừng", "hai thành phần")),
])
def test_missing_detailed_sources_never_activate_cached_regulatory_claims(excluded, question, topic, forbidden):
    report = _base_report(tea_case(), topic_sources(exclude=excluded), question)
    answer = report.topic_answers[0]
    assert answer.topic == topic and answer.coverage == "unavailable"
    assert not answer.evidence_ids
    assert all(term not in answer.answer for term in forbidden)
    assert "chưa" in answer.answer.casefold()


def test_changed_interior_clause_does_not_keep_old_timing_claim_from_matching_boundaries():
    batch = topic_sources()
    document = next(item for item in batch.sources if item.id == "fda_prior_notice")
    changed = document.text.replace("No less than 2 hours", "No less than 3 hours")
    assert changed != document.text
    document.text = changed
    document.content_sha256 = hashlib.sha256(changed.encode("utf-8")).hexdigest()
    report = _base_report(tea_case(), batch, "Ai nộp thông báo trước, nộp khi nào?")
    answer = report.topic_answers[0]
    assert answer.coverage == "partial"
    assert "bất kỳ người nào" in answer.answer
    assert not any(term in answer.answer for term in ("2 giờ", "3 giờ", "4 giờ", "8 giờ"))
    assert "chưa truy xuất được đoạn nguồn đầy đủ về thời hạn" in answer.answer
    assert not any("prior_notice_when" in eid for eid in answer.evidence_ids)


def test_product_name_or_fda_mentions_do_not_invent_unasked_topics():
    assert _ordered_question_topics("FDA: nhãn tiếng Anh cần gì?") == ["labeling"]
    assert _ordered_question_topics("FDA prior notice for lotus jam") == ["prior_notice"]
    assert _ordered_question_topics("FDA là gì trong chuẩn bị lô hàng?") == ["fda_registration"]


def test_certification_question_does_not_invent_mandatory_product_certificates():
    report = _base_report(tea_case(), topic_sources(), "Bột Sen cần chứng nhận gì?")
    answer = report.topic_answers[0]
    assert answer.coverage == "unavailable" and not answer.evidence_ids
    assert "chưa đủ" in answer.answer.casefold()
    assert all(term not in answer.answer for term in ("bắt buộc HACCP", "phải có ISO", "được miễn chứng nhận"))
    assert "clarify_delivery_terms" not in {step.id for step in report.next_steps}


@pytest.mark.parametrize("mutation", ["unknown_action", "duplicate_action", "unknown_evidence", "missing_answer", "duplicate_topic", "false_coverage"])
def test_new_policy_remains_strict_about_actions_provenance_and_question_coverage(mutation):
    raw = _base_report(tea_case(), topic_sources(), TEA_QUESTION).model_dump(mode="json")
    if mutation == "unknown_action":
        raw["next_steps"][0]["id"] = "invented_action"
    elif mutation == "duplicate_action":
        raw["next_steps"][1] = deepcopy(raw["next_steps"][0])
    elif mutation == "unknown_evidence":
        raw["topic_answers"][0]["evidence_ids"] = ["invented_source"]
    elif mutation == "missing_answer":
        raw["topic_answers"].pop()
    elif mutation == "duplicate_topic":
        raw["question_topics"][1] = raw["question_topics"][0]
    else:
        raw["topic_answers"][0]["evidence_ids"] = []
    with pytest.raises(ValueError):
        ShipmentReport.model_validate(raw)


def test_historical_022_contract_keeps_its_original_mandatory_actions_without_migration():
    raw = _base_report(tea_case(), SourceBatch(), "Tôi nên bắt đầu từ đâu?").model_dump(mode="json")
    raw["next_steps_policy_version"] = "0.2.2"
    raw.pop("question_topics")
    raw.pop("topic_answers")
    original = deepcopy(raw)
    parsed = ShipmentReport.model_validate(raw)
    assert raw == original and parsed.next_steps_policy_version == "0.2.2"
    assert parsed.question_topics == parsed.topic_answers == []
    for removed in ("clarify_import_roles", "clarify_delivery_terms", "expert_preparation_review"):
        invalid = deepcopy(original)
        invalid["next_steps"] = [item for item in invalid["next_steps"] if item["id"] != removed]
        with pytest.raises(ValueError):
            ShipmentReport.model_validate(invalid)


async def test_one_mock_model_call_gets_full_topic_context_and_missing_topic_uses_no_retry(monkeypatch):
    calls = []
    batch = topic_sources()

    class Sources:
        async def fetch_all(self):
            return batch

    class Model:
        def with_structured_output(self, _schema, **_kwargs):
            return self

        async def ainvoke(self, messages):
            calls.append(messages)
            payload = json.loads(messages[1][1])
            assert payload["question_topics"] == ["fda_registration", "labeling"]
            assert payload["source_coverage"]["detailed_labeling_requirements_available"] is True
            assert payload["source_coverage"]["registration_rule_and_exemptions_available"] is True
            assert "DATA_TRUNCATED" not in messages[1][1]
            assert all(item["reference_translation_available"] for item in payload["evidence_candidates"])
            assert "KHÔNG dịch lại" in messages[0][1]
            return {"summary": "Đăng ký FDA của cơ sở cần đối chiếu hoạt động và diện miễn; dữ kiện hiện có chưa đủ xác nhận.",
                    "ordered_finding_ids": [], "evidence_ids": [], "evidence_translations": [
                        {"evidence_id": item["id"], "original_excerpt_sha256": item["original_excerpt_sha256"],
                         "status": "unavailable", "title_vi": None, "excerpt_vi": None, "publisher_vi": None}
                        for item in payload["evidence_candidates"]]}

    monkeypatch.setattr("nmate.agents.shipment.graph.create_chat_model", lambda *_args: Model())
    graph = build_graph(InMemorySaver(), mode="llm", model_provider="anthropic", model_name="claude-sonnet-5-5",
                        api_key="MOCK-NOT-A-LIVE-KEY", source_provider=Sources())
    state = await graph.ainvoke({"case": tea_case(), "question": TEA_QUESTION}, {"configurable": {"thread_id": "MOCK-TOPICS"}})
    report = ShipmentReport.model_validate(state["report"])
    assert len(calls) == 1 and report.llm_used is True
    assert report.summary_origin == "rule_based" and "Nhãn" in report.summary
    assert any("chưa nhắc đủ" in item and "Không gọi AI thêm" in item for item in report.warnings)
    assert len(report.evidence) > 3  # old translation bound cannot truncate new sources
    assert report.next_steps == _base_report(tea_case(), batch, TEA_QUESTION).next_steps
    assert all(item.review_status == "candidate" for item in report.evidence)
