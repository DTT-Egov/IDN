"""Vietnamese intent meaning survives accent folding; no network or AI."""
import pytest

from nmate.v03.research_scope import allowed_intake_outcomes, quote_supports_outcome


@pytest.mark.parametrize("question", [
    "Tôi xác nhận dữ kiện", "Đã tiếp nhận hồ sơ", "Nhân viên sẽ xử lý",
    "Tôi chấp nhận kết quả", "Xin ghi nhận ý kiến", "Cho nhận xét về FDA",
    "Toi xac nhan du kien", "Da tiep nhan ho so", "Nhan vien se xu ly",
    "Toi chap nhan ket qua", "Nguyen nhan la gi", "Nhan hang vao ngay mai",
    "Chứng nhận cho sản phẩm", "Chung nhan cho san pham",
])
def test_confirmation_person_receipt_and_certification_are_not_label_requests(question):
    assert "label" not in allowed_intake_outcomes(question, "US")
    assert not quote_supports_outcome("label", question, "US")


@pytest.mark.parametrize("question", [
    "Chuẩn bị nhãn sản phẩm", "Tôi xác nhận, hãy chuẩn bị nhãn",
    "Toi muon chuan bi nhan san pham", "Review food labeling", "Chuẩn bị bao bì",
    "Chuan bi bao bi", "Nhãn FDA", "nhãn đã xong; tôi chỉ muốn sửa tiếp nhãn",
])
def test_real_label_requests_accented_unaccented_and_english_remain_supported(question):
    assert "label" in allowed_intake_outcomes(question, "US")


@pytest.mark.parametrize("question,expected", [
    ("Nhãn FDA", {"label"}), ("FDA Prior Notice", {"prior_notice"}),
    ("FDA priornotice", {"prior_notice"}), ("FDA là gì?", set()),
    ("Đăng ký cơ sở FDA", {"registration"}), ("FDA food facility", {"registration"}),
    ("Yêu cầu nhập khẩu của FDA", {"registration"}),
    ("Chứng nhận FDA", {"certification"}),
    ("Nhãn đã xong; tôi chỉ hỏi ai nộp thông báo trước và khi nào", {"prior_notice"}),
    ("Chị hỏi đăng ký cơ sở FDA và nhãn, ba việc đầu tiên chị cần làm là gì?", {"registration", "label"}),
    ("Nhãn đã xong; chị chỉ hỏi ai nộp thông báo trước và khi nào", {"prior_notice"}),
])
def test_fda_name_alone_does_not_reopen_registration_or_force_multiple_tasks(question, expected):
    assert set(allowed_intake_outcomes(question, "US")) - {"clarification"} == expected
