"""Existing qualified public rights agree across lookup, graph and egress."""
import pytest

from nmate.v03.catalog import DomainCatalog
from nmate.v03.core import CoreError, CoreRepository
from nmate.v03.install_readiness import install_readiness_pack


@pytest.fixture
def catalog(tmp_path):
    repo = CoreRepository(tmp_path / "rights-contract.sqlite3")
    install_readiness_pack(repo)
    return repo, DomainCatalog(repo)


@pytest.mark.parametrize("read", ["lookup", "source", "graph"])
def test_qualified_installed_federal_reference_remains_available(catalog, read):
    repo, domain = catalog
    identity = "US_PN_SUBMITTER_20261022_V1"
    with repo.connection() as db:
        source_id = db.execute("SELECT source_id FROM v03_domain_references WHERE id=?", (identity,)).fetchone()[0]
    if read == "lookup":
        assert identity in {r["id"] for r in domain.lookup(["prior_notice"], market_code="US")["records"]}
    elif read == "source":
        assert domain.get_source(source_id)["id"] == source_id
    else:
        graph = domain.domain_graph(market_code="US", reference_ids=[identity], as_of_date="2026-10-22")
        assert identity in {d["reference_id"] for d in graph["dependencies"]}
        assert graph["writes"] == graph["provider_calls"] == 0 and not graph["legal_approval"]


@pytest.mark.parametrize("url", ["https://example.com/fda", "https://www.fda.gov.evil.example/",
                                  "https://www.fda.gov@evil.example/", "not a URL", "https://[broken"])
def test_federal_rights_label_does_not_bless_an_unqualified_host(catalog, url):
    repo, domain = catalog
    identity = "US_PN_SUBMITTER_20261022_V1"
    with repo.connection(write=True) as db:
        source_id = db.execute("SELECT source_id FROM v03_domain_references WHERE id=?", (identity,)).fetchone()[0]
        db.execute("UPDATE v03_domain_sources SET url=? WHERE id=?", (url, source_id))
    assert identity not in {r["id"] for r in domain.lookup(["prior_notice"], market_code="US")["records"]}
    with pytest.raises(CoreError):
        domain.get_source(source_id)
    with pytest.raises(CoreError) as denied:
        domain.domain_graph(market_code="US", reference_ids=[identity])
    assert denied.value.status_code == 403


@pytest.mark.parametrize("rights,url,expected", [
    ("us_federal_government_public_reference", "https://www.fda.gov/", True),
    ("us_federal_government_public_reference", "https://www.ecfr.gov/", True),
    ("us_federal_government_public_reference", "https://www.govinfo.gov/", True),
    ("us_federal_government_public_reference", "https://example.com/", False),
    ("us_federal_government_public_reference", None, False),
    ("enterprise_private", "https://www.fda.gov/", False),
    ("unknown", "https://www.fda.gov/", False),
    ("public_reference", "https://example.com/", False),
    ("official_reference_quotation_not_full_republication", "https://example.com/", False),
])
def test_versioned_public_rights_policy_preserves_existing_bounded_contract(rights, url, expected):
    from nmate.v03.source_rights import public_source_permitted
    assert public_source_permitted(rights, url) is expected
