const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');

const root=path.resolve(__dirname,'..');
const live=path.resolve(root,'../MVP/v0.4A-live-independent-review-2026-10-19/web');
const html=fs.readFileSync(path.join(live,'v04.html'),'utf8');

test('Live HTML uses external scripts/styles compatible with the local CSP',()=>{
  assert.match(html,/<script src="src\/mission-v04\.js"><\/script>/);
  assert.match(html,/<link rel="stylesheet" href="src\/mission-v04\.css">/);
  assert.doesNotMatch(html,/<style\b|data:font|unsafe-inline|\bnonce\s*=/i);
  const scripts=[...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)];
  assert.equal(scripts.length,1);assert.match(scripts[0][1],/\bsrc\s*=/);assert.equal(scripts[0][2].trim(),'');
});

test('Live CSS, JavaScript and fonts are present as same-origin assets',()=>{
  const css=fs.readFileSync(path.join(live,'src/mission-v04.css'),'utf8');
  assert.doesNotMatch(css,/data:font|https?:\/\//i);
  for(const weight of ['Regular','SemiBold']){
    assert.ok(css.includes(`assets/fonts/IBMPlexSans-${weight}.ttf`));
    assert.ok(fs.statSync(path.join(live,`src/assets/fonts/IBMPlexSans-${weight}.ttf`)).size>0);
  }
  assert.ok(fs.statSync(path.join(live,'src/mission-v04.js')).size>0);
});

test('Only the isolated live document has the live-review flag',()=>{
  assert.match(html,/<div id="v04-app" data-live-review="true">/);
  assert.match(html,/<title>nMate 0\.4A — Review độc lập bằng Claude thật<\/title>/);
  assert.doesNotMatch(fs.readFileSync(path.join(root,'v04.html'),'utf8'),/data-live-review="true"/);
});
