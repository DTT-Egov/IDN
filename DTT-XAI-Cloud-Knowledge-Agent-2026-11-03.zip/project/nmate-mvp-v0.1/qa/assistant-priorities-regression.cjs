/* Review 18/10: user decisions, bound outputs and zero hidden model calls.
 * Reuses local DOM/transport adapters, executes no existing test callbacks,
 * never opens HTTP or constructs a provider. Layout is separate CUA QA. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
function adapter(file,names,marker){
 const filename=path.join(__dirname,file),localRequire=createRequire(filename);
 const sandbox={require:id=>id==='node:test'?{test(){}}:localRequire(id),__dirname,__filename:filename,console:{log(){},error:console.error},URL,Blob,setImmediate};
 let body=fs.readFileSync(filename,'utf8');if(marker){const boundary=body.indexOf(marker);assert.ok(boundary>0);body=body.slice(0,boundary);}
 vm.runInNewContext(body+'\nglobalThis.exportsForPriorities={'+names.join(',')+'};',sandbox,{filename});
 return sandbox.exportsForPriorities;
}
const A=adapter('assistant-regression.cjs',['harness','settle','conversation','savedConversation','openSaved','openReport','Element','copy','visible','emptyDraft']);
const R=adapter('live-research-regression.cjs',['harness','settle','artifactData']);
const S=adapter('assistant-shell-regression.cjs',['harness','input'],"\ntest('Assistant is the default");
const byClass=(root,name)=>root.all().find(node=>node.className.split(/\s+/).includes(name))||null;
const goals=[
 'Tôi có Trà Sen Tây Hồ, muốn gửi New York. Tôi nên bắt đầu từ đâu?',
 'Tôi có Trà Sen Tây Hồ gửi New York, muốn hỏi thông tin để xin báo giá vận chuyển.',
 'Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.',
];
for(const goal of goals)test('Short goal keeps exact request and cannot dispatch before separate consent: '+goal,async()=>{
 assert.ok(goal.length<=120);
 const h=A.harness();h.mount();await A.settle();
 if(goal===goals[0]||goal===goals[2]){await h.click(goal===goals[0]?'Bắt đầu với trà sen':'Tìm hiểu FDA / nhãn');assert.equal(h.get('a-message').value,goal);assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);}
 await h.send(goal);
 assert.equal(h.calls.filter(c=>c.options.method==='POST').length,0);
 assert.equal(h.get('a-storage-consent').checked,false);assert.equal(h.get('a-model-consent').checked,false);
 await h.consent();
 const calls=h.calls.filter(c=>c.url.endsWith('/messages'));
 assert.equal(calls.length,1);assert.equal(calls[0].body.message,goal);
 assert.equal(h.calls.some(c=>c.url.endsWith('/confirm')||c.body?.name==='nmate_shipment_readiness_start'),false);
});
test('Compact confirmation surfaces decision before optional facts without changing unknowns',async()=>{
 const d=A.emptyDraft();d.product.name='Trà Sen Tây Hồ';d.shipment.destination='New York';d.question=goals[0];
 const h=A.harness({conversation:A.conversation({pending_proposal:d})});await A.openSaved(h);
 const card=h.get('a-research-review');assert.ok(card);
 const shown=A.visible(card);assert.match(shown,/Trà Sen Tây Hồ/);assert.match(shown,/có tính phí|có phí/);
 assert.match(shown,/Sẽ đối chiếu đúng câu hỏi với nguồn công khai/);assert.doesNotMatch(shown,/Chưa có nguồn nhãn chi tiết/);
 const buttons=card.all().filter(e=>e.tagName==='BUTTON');assert.ok(buttons.some(e=>e.textContent==='Xác nhận và nghiên cứu'));
 assert.equal(h.current.pending_proposal.product.certifications,null);
 assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
});
test('Mobile fee belongs to send control and exists while asking a saved artifact',async()=>{
 const h=A.harness({conversation:A.savedConversation()});await A.openSaved(h);
 const fee=h.get('a-send-fee');assert.ok(fee);assert.equal(fee.hidden,false);assert.match(fee.textContent,/AI.*phí|phí.*AI/);
 assert.ok(h.get('a-composer').all().includes(fee));
 assert.match(h.get('a-mode').textContent,/Trà sen/);
 assert.equal(h.calls.some(c=>c.url.endsWith('/messages')),false);
});
test('Preparing a canonical step previews a bound draft and saves without any model or network operation',async()=>{
 let saved;const h=A.harness({conversation:A.savedConversation(),saveDraft:v=>(saved=A.copy(v),{id:'LOCAL-BOUND'})});
 await A.openSaved(h);await A.openReport(h);
 const context=h.renders[0].context;assert.equal(typeof context.onPrepareStep,'function');
 const trigger=new A.Element('button');h.get('a-timeline').append(trigger);
 const calls=h.calls.length;context.onPrepareStep('clarify_import_roles',trigger);await A.settle();
 assert.ok(h.get('a-draft-preview'));assert.equal(h.get('a-draft-editor').hidden,true);
 assert.match(A.visible(h.get('a-inline-action')),/chưa gửi|Chưa gửi/);
 assert.match(h.get('a-draft-preview').textContent,/nhập khẩu|xác minh/);
 await h.get('a-draft-save').emit('click');await A.settle();
 assert.ok(saved);assert.equal(saved.artifact.artifact_id,'ART-TEA');assert.equal(saved.product.sku,'TEA-100');
 assert.equal(saved.question,A.savedConversation().research_links[0].question);
 assert.equal(h.calls.length,calls);
});
test('Invalid step and detached prepare callback cannot create a different or newer workspace draft',async()=>{
 let saved=0;const h=A.harness({conversation:A.savedConversation(),saveDraft:()=>{saved++;return{id:'BAD'};}});
 await A.openSaved(h);await A.openReport(h);const context=h.renders[0].context,calls=h.calls.length;
 context.onPrepareStep('unrelated_step',null);await A.settle();assert.equal(h.get('a-draft-preview'),null);assert.equal(saved,0);assert.equal(h.calls.length,calls);
 h.mount('assistant');await A.settle();context.onPrepareStep('clarify_import_roles',null);await A.settle();
 assert.equal(h.get('a-draft-preview'),null);assert.equal(saved,0);
});
test('Generic draft starts with a full preview; editing is explicit and save keeps immutable reference',async()=>{
 let saved;const h=A.harness({conversation:A.savedConversation(),saveDraft:v=>(saved=A.copy(v),{id:'EDITED'})});await A.openSaved(h);await A.openReport(h);
 await h.click('Soạn nội dung để tự gửi');assert.ok(h.get('a-draft-preview'));assert.equal(h.get('a-draft-editor').hidden,true);
 await h.click('Sửa');assert.equal(h.get('a-draft-editor').hidden,false);
 h.get('a-draft-body').value='Nội dung mình đã sửa để tự gửi.';
 await h.get('a-draft-save').emit('click');assert.ok(saved);assert.equal(saved.body,'Nội dung mình đã sửa để tự gửi.');
 assert.equal(saved.artifact.content_sha256,'IMMUTABLE-HASH');assert.equal(saved.artifact.artifact_id,'ART-TEA');
 assert.equal(h.calls.some(c=>c.url.endsWith('/messages')),false);
});
test('Preview receives visible focus; editing and closing return keyboard focus without focusing a hidden field',async()=>{
 const h=A.harness({conversation:A.savedConversation()});await A.openSaved(h);await A.openReport(h);
 const action=h.all().find(node=>node.tagName==='BUTTON'&&node.textContent==='Soạn nội dung để tự gửi');await action.emit('click');
 const card=h.get('a-inline-action'),preview=h.get('a-draft-preview'),editor=h.get('a-draft-editor');
 assert.ok(card.scrollCalls.length>0);assert.equal(editor.hidden,true);assert.ok(preview.focusCalls.length>0||card.focusCalls.length>0);
 assert.equal(h.get('a-draft-title').focusCalls.length,0);assert.equal(h.get('a-draft-body').focusCalls.length,0);
 await h.click('Sửa');assert.equal(editor.hidden,false);assert.ok(h.get('a-draft-body').focusCalls.length>0);
 await h.click('Đóng');assert.equal(h.get('a-inline-action'),null);assert.ok(action.focusCalls.length>0);
});
for(const supplied of [false,true])test('Generated reference is hidden only when not provided by the user: '+supplied,async()=>{
 const c=A.savedConversation(),sku='REF-'+c.conversation_id.slice(0,12).toUpperCase();
 c.research_links[0].product_summary.sku=sku;
 if(supplied){c.draft.product.sku=sku;c.draft.field_sources['product.sku']={source_quote:'Mã sản phẩm của mình là '+sku,certainty:'provided',confirmed:true};}
 let saved;const h=A.harness({conversation:c,saveDraft:v=>(saved=A.copy(v),{id:'SKU-BOUND'})});await A.openSaved(h);await A.openReport(h);
 h.renders[0].context.onPrepareStep('clarify_import_roles',null);await A.settle();
 const preview=h.get('a-draft-preview').textContent;assert.equal(preview.includes(sku),supplied);
 assert.match(h.get('a-inline-action').children[0].textContent,/Chuẩn bị câu hỏi cho bên nhập khẩu/);
 await h.get('a-draft-save').emit('click');assert.equal(saved.product.sku,sku);
});
test('Explicit saved report read anchors the result start and never starts another research run',async()=>{
 const h=A.harness({conversation:A.savedConversation()});await A.openSaved(h);await A.openReport(h);
 const slot=h.all().find(node=>node.dataset.artifactId==='ART-TEA');assert.ok(slot);
 assert.ok(slot.scrollCalls.some(call=>call.block==='start'));
 assert.equal(h.calls.some(call=>call.body?.name==='nmate_shipment_readiness_start'),false);
});
for(const tab of ['journey','documents'])test('New conversation from '+tab+' returns to the assistant without a model or silent thread creation',async()=>{
 const navigations=[],h=A.harness({conversation:A.savedConversation()});h.mount(tab,{go:value=>navigations.push(value)});await A.settle();
 await h.get('a-new').emit('click');await A.settle();assert.deepEqual(navigations,['assistant']);
 assert.equal(h.calls.filter(call=>call.options.method==='POST').length,0);
 assert.equal(h.storage.has('nmate.assistant.last.BROWSER-TEST-001'),false);
});
function canonical(){const a=R.artifactData();Object.assign(a.report,{summary:'Nguồn hiện có chưa đủ để chốt nhãn riêng cho trà sen.',summary_kind:'assessment',summary_origin:'model',next_steps_policy_version:'0.2.2',next_steps:[{id:'clarify_import_roles',title:'Xác nhận bên nhập khẩu',reason:'Vai trò chưa được cung cấp.',done_when:'Có tên và xác nhận vai trò từ các bên.',owner_role:'business',evidence_ids:[]}]});return a;}
test('Actual report renders primary prepare and secondary save; details remain discoverable',async()=>{
 const h=R.harness(),a=canonical(),original=JSON.stringify(a);let prepared,saved;
 const root=h.renderArtifact(a,{onPrepareStep:id=>prepared=id,onSaveTask:id=>saved=id});
 const prepare=byClass(root,'step-prepare-button');assert.ok(prepare);await prepare.emit('click');assert.equal(prepared,'clarify_import_roles');
 const save=byClass(root,'step-save-button');assert.ok(save);await save.emit('click');assert.equal(saved,'clarify_import_roles');
 assert.ok(byClass(root,'step-expected'));assert.ok(byClass(root,'step-explanation'));
 assert.match(byClass(root,'step-explanation').textContent,/Vì sao|cách làm/);
 assert.equal(JSON.stringify(a),original);assert.equal(h.calls.length,0);
});
test('Legacy report never receives new execution actions merely because callback was supplied',()=>{
 const h=R.harness(),a=canonical();delete a.report.next_steps_policy_version;
 const root=h.renderArtifact(a,{onPrepareStep(){throw new Error('MUST NOT RUN');},onSaveTask(){throw new Error('MUST NOT RUN');}});
 assert.equal(byClass(root,'step-prepare-button'),null);assert.equal(byClass(root,'step-save-button'),null);assert.equal(h.calls.length,0);
});
test('Local per-step draft retains selected canonical provenance and rejects an invented step before mutation',()=>{
 const h=S.harness();h.api.setAssistantStorageConsent(true);const source=S.input(),original=JSON.stringify(source);
 const saved=h.api.saveResearchDraft({...source,step_id:'clarify_delivery_terms',body:'Câu hỏi điều kiện giao hàng để mình tự gửi.'});
 assert.equal(saved.sourceStepId,'clarify_delivery_terms');assert.equal(saved.source.artifact_id,source.artifact.artifact_id);
 assert.equal(saved.source.next_steps.length,1);assert.equal(saved.source.next_steps[0].id,'clarify_delivery_terms');
 assert.equal(saved.deliveryStatus,'not_sent');assert.equal(saved.status,'local_draft');assert.equal(JSON.stringify(source),original);
 const before=JSON.stringify(h.state);assert.throws(()=>h.api.saveResearchDraft({...source,step_id:'invented',body:'Invalid'}),/không thuộc/);
 assert.equal(JSON.stringify(h.state),before);
});
