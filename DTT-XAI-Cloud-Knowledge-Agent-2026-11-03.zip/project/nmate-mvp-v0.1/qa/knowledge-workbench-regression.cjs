const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const sourcePath=process.env.KNOWLEDGE_WORKBENCH_JS||path.join(__dirname,'../../nmate-backend-v0.2/src/nmate/knowledge_v1/workbench_web/app.js');
function fixture(){
  const nodes=new Map();
  const node=id=>{if(!nodes.has(id))nodes.set(id,{id,value:'',textContent:'',hidden:false,disabled:false,classList:{toggle(){}},setAttribute(){},replaceChildren(){this.textContent='';},append(){}});return nodes.get(id);};
  let actor='A';let authorized=true;let rpcGate=null;
  const sandbox={document:{getElementById:node,querySelectorAll:()=>[],addEventListener(){}},window:{addEventListener(){}},location:{hash:'',pathname:'/knowledge/'},history:{replaceState(){}},crypto:{randomUUID:()=> 'test-op'},
    fetch:async url=>{if(url!=='session'&&rpcGate)await rpcGate;return {json:async()=>url==='session'?(authorized?{ok:true,account_id:actor,csrf_token:'TEST'}:{ok:false,error:{message:'Phiên đã hết hạn'}}):{ok:true,_scope_actor_id:actor,data:[]}};}};
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(sourcePath,'utf8')+'\nglobalThis.__test={rpc,revalidatePresentation,seed(){view={private:true};sessionActor="A";}};',sandbox);
  return {sandbox,node,setActor:value=>{actor=value;},expire:()=>{authorized=false;},holdRpc:gate=>{rpcGate=gate;}};
}
for(const mode of ['expired','changed'])test(`Workbench removes private DOM after ${mode} session while server draft is untouched`,async()=>{
  const f=fixture();await new Promise(resolve=>setImmediate(resolve));f.sandbox.__test.seed();
  for(const id of ['title','rationale','leftRevision','scopeFrom','scopeUntil'])f.node(id).value='PRIVATE-A';
  for(const id of ['pageTitle','preview','evidence','backlinks','diffText','scopeState'])f.node(id).textContent='PRIVATE-A';
  if(mode==='expired')f.expire();else f.setActor('B');
  await assert.rejects(f.sandbox.__test.rpc('knowledge_wiki_queue'));
  assert.equal(f.node('editor').hidden,true);
  for(const id of ['title','rationale','leftRevision','scopeFrom','scopeUntil'])assert.equal(f.node(id).value,'',id);
  for(const id of ['pageTitle','preview','evidence','backlinks','diffText','scopeState'])assert.equal(f.node(id).textContent,'',id);
});
test('Returning to the tab rechecks its existing session without a mutation or model call',async()=>{
  const f=fixture();await new Promise(resolve=>setImmediate(resolve));f.sandbox.__test.seed();
  f.node('title').value='PRIVATE-A';f.expire();
  await f.sandbox.__test.revalidatePresentation();
  assert.equal(f.node('title').value,'');assert.equal(f.node('editor').hidden,true);
});
test('A response from an earlier scope cannot return after tab revalidation changed identity',async()=>{
  const f=fixture();await new Promise(resolve=>setImmediate(resolve));f.sandbox.__test.seed();
  let release;f.holdRpc(new Promise(resolve=>{release=resolve;}));
  const response=f.sandbox.__test.rpc('knowledge_wiki_workbench');
  await new Promise(resolve=>setImmediate(resolve));f.setActor('B');
  await f.sandbox.__test.revalidatePresentation();release();
  await assert.rejects(response,/kết quả đến muộn/);assert.equal(f.node('editor').hidden,true);
});
