const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const helpers=require('../src/mission-v03.js');
const source=fs.readFileSync(path.join(__dirname,'../src/mission-v03.js'),'utf8');
const clone=value=>JSON.parse(JSON.stringify(value));
const session={authenticated:true,csrf_token:'csrf-qa',account:{id:'account-a',username:'trasen-test'},enterprise:{id:'enterprise-a',name:'Trà Sen Tây Hồ'}};
const labelFields=[['statement_of_identity','Tên thực phẩm tiếng Anh','Statement of identity'],['net_quantity','Lượng tịnh','Net quantity'],['ingredients','Thành phần','Ingredients'],['responsible_business','Đơn vị chịu trách nhiệm','Responsible business'],['nutrition_information','Thông tin dinh dưỡng','Nutrition information'],['allergens','Thông tin dị nguyên','Allergen information']].map(([id,label_vi,label_en])=>({id,label_vi,label_en,value:null}));
const mission={market:{code:'US',name_vi:'Mỹ',label_language:'en'},id:'mission-a',enterprise_id:'enterprise-a',question:helpers.SAMPLE,status:'completed_partial',version:1,product:{entity_id:'product-a',name:'Trà Sen Tây Hồ',version:2},intent:{outcomes:[{id:'registration',title:'Đăng ký cơ sở FDA'},{id:'label',title:'Khung nhãn tiếng Anh'}]},plan:{tasks:[{id:'registration',title:'Đối chiếu đăng ký'}]},answers:[{outcome_id:'registration',title:'Đăng ký cơ sở FDA',text:'Đăng ký cơ sở có điều kiện; chưa đủ dữ kiện để kết luận.',missing_fields:['facility_activity','facility_type']},{outcome_id:'label',title:'Khung nhãn tiếng Anh',text:'Có khung nhãn với các ô trống để điền.',missing_fields:labelFields.map(field=>field.id)}],actions:[{id:'edit-label',title:'Điền và lưu khung nhãn',kind:'edit_label',outcome_ids:['label']}],artifacts:[{id:'label-a',kind:'food_label_workbook',version:1,fields:labelFields}],knowledge:{records:[],metrics:{this_lookup_hits:2}},context:{reused_fact_count:2},created_at:'2026-10-18T00:00:00Z',updated_at:'2026-10-18T00:00:00Z'};
const context={entities:[{id:'product-a',entity_type:'product',name:'Trà Sen Tây Hồ',version:2,values:{name:'Trà Sen Tây Hồ',net_quantity:'100 g',ingredients:'Trà xanh, hương sen'}}]};
async function harness(options={}) {
  const listeners={},calls=[],memory=new Map(options.remember===false?[]:[['nmate.v03.current.enterprise-a','mission-a']]);
  const root={innerHTML:'',addEventListener:(name,handler)=>{listeners[name]=handler;}};
  const elements={};
  const document={activeElement:null,getElementById:id=>id==='v03-app'?root:elements[id] || null};
  let current=clone({...mission,...options.mission}),currentContext=clone(options.context||context);
  for(const field of current.artifacts?.find(artifact=>artifact.kind==='food_label_workbook')?.fields || []){
    elements['v03-memory-choice-'+field.id]={hidden:!String(field.value || '').trim()};
    elements['v03-memory-'+field.id]={textContent:field.value || ''};
  }
  elements['v03-memory-empty']={hidden:Object.keys(elements).some(key=>key.startsWith('v03-memory-choice-') && !elements[key].hidden)};
  const fetch=async(url,config)=>{
    const body=config.body?JSON.parse(config.body):undefined;calls.push({url,config,body});
    let data;
    if(url==='/api/v03/session')data=clone(session);
    else if(url==='/api/v03/mcp/call') {
      assert.equal(config.headers['X-CSRF-Token'],'csrf-qa');
      assert.equal(body.arguments.enterprise_id,'enterprise-a');
      if(body.name==='get_enterprise_context')data=clone(currentContext);
      else if(body.name==='get_mission')data=clone(current);
      else if(body.name==='prepare_mission') {assert.equal(body.arguments.question,undefined);current={...clone(options.preparedMission || mission),id:'mission-b',question:body.arguments.user_text,status:'planned'};await options.onPrepare?.({listeners,elements});data=clone(current);}
      else if(body.name==='start_mission') {assert.equal(current.status,'planned');current.status='completed_partial';data=clone(current);}
      else if(body.name==='update_label_progress') {
        assert.equal(body.arguments.expected_artifact_version,current.artifacts[0].version);assert.equal(body.arguments.expected_entity_version,currentContext.entities[0].version);
        if(options.saveError)return {ok:false,status:409,json:async()=>({ok:false,error:{code:'label_conflict_requires_choice',message:'Hồ sơ đã đổi, vui lòng đối chiếu trước khi lưu.'}})};
        current.artifacts[0].version++;
        for(const field of current.artifacts[0].fields)if(Object.hasOwn(body.arguments.fields,field.id))field.value=body.arguments.fields[field.id] || null;
        let sharedRemembered=false,marketRemembered=false;
        for(const key of body.arguments.remember_fields){
          const value=current.artifacts[0].fields.find(field=>field.id===key).value;
          if(current.market_profile && helpers.MARKET_FACT_FIELDS.includes(key)){assert.equal(body.arguments.expected_market_profile_version,current.market_profile.version);current.market_profile.values[key]=value;marketRemembered=true;}
          else{currentContext.entities[0].values[key]=value;sharedRemembered=true;}
        }
        if(sharedRemembered){currentContext.entities[0].version++;current.product.version=currentContext.entities[0].version;}
        if(marketRemembered){current.market_profile.version++;const entry=currentContext.entities.find(entity=>entity.id===current.market_profile.entity_id);if(entry){entry.version=current.market_profile.version;entry.values=clone(current.market_profile.values);}}

        data=clone(current);
      }
      else if(body.name==='update_enterprise_facts') {assert.equal(body.arguments.expected_version,2);assert.equal(body.arguments.entity_id,undefined);current.status='needs_revalidation';data=clone(current);}
      else if(body.name==='list_missions')data=clone(options.history || [current]);
      else throw new Error('Unexpected tool in QA: '+body.name);
      data={ok:true,data};
    } else throw new Error('Unexpected network in QA: '+url);
    return {ok:true,status:200,json:async()=>data};
  };
  class FakeFormData {
    constructor(form){this.data=form.data || {};}
    entries(){return Object.entries(this.data)[Symbol.iterator]();}
    get(key){return this.data[key] ?? null;}
  }
  const sandbox={document,fetch,console,Intl,Date,URL,JSON,Math,FormData:FakeFormData,setTimeout,clearTimeout,requestAnimationFrame:()=>{},sessionStorage:{getItem:key=>memory.get(key)||null,setItem:(key,value)=>memory.set(key,value),removeItem:key=>memory.delete(key)},window:{crypto:{randomUUID:()=>`op-${calls.length}`}}};
  vm.runInNewContext(source,sandbox,{filename:'mission-v03.js'});
  const settle=async()=>{for(let i=0;i<8;i++)await new Promise(resolve=>setImmediate(resolve));};
  await settle();
  const click=async(action,id)=>{listeners.click({target:{closest:()=>({dataset:{v03:action,id,index:String(id)}})}});await settle();};
  const submit=async(id,data)=>{listeners.submit({preventDefault(){},target:{id,data,matches:()=>true,reportValidity:()=>true}});await settle();};
  const input=(name,value,formId,checked)=>listeners.input({target:{name,value,checked,id:'',closest:selector=>selector==='#'+formId?{}:null}});
  const toggle=target=>listeners.toggle({target});
  return {root,calls,click,submit,input,toggle,settle,elements};
}
test('Lời người dùng và dữ liệu nhãn được escape, URL không chạy JavaScript',()=>{
  assert.equal(helpers.esc('<img src=x onerror="run()">'), '&lt;img src=x onerror=&quot;run()&quot;&gt;');
  assert.equal(helpers.safeURL('javascript:alert(1)'), '');
  assert.equal(helpers.safeURL('https://www.fda.gov/food'), 'https://www.fda.gov/food');
  assert.equal(helpers.dateVi('2026-10-18T00:00:00Z'),'18/10/2026');
});
test('Tải Markdown chỉ lấy đúng artifact nhãn đã lưu, không xuất dữ liệu doanh nghiệp khác',()=>{
  const markdown='# Khung nhãn\n\nStatement of identity: Lotus-scented green tea\n';
  assert.deepEqual(helpers.labelDownload({kind:'food_label_workbook',version:3,markdown,private_context:{secret:'not exported'}}),{filename:'nMate-khung-nhan-v3.md',mime:'text/markdown;charset=utf-8',content:markdown});
  assert.equal(helpers.labelDownload({kind:'enterprise_context',version:1,markdown}),null);
  assert.equal(helpers.labelDownload({kind:'food_label_workbook',version:1,markdown:''}),null);
});
test('Đọc lại sau reload không tự bắt đầu lượt mới; cả hai câu trả lời nằm ngoài phần gấp',async()=>{
  const app=await harness();
  assert.deepEqual(app.calls.filter(call=>call.body?.name).map(call=>call.body.name),['get_enterprise_context','get_mission','get_enterprise_context']);
  const html=app.root.innerHTML;
  assert.ok(html.indexOf('Đăng ký cơ sở có điều kiện')<html.indexOf('<details'));
  assert.ok(html.indexOf('Có khung nhãn với các ô trống')<html.indexOf('<details'));
  assert.match(html,/Giả lập · Không gọi AI có phí/);
  assert.doesNotMatch(html,/tổng hợp bằng Claude|lượt AI mới, có tính phí/);
});
test('Kế hoạch đã lưu chỉ chạy khi bấm bắt đầu; tên sản phẩm giữ đúng hoa thường',async()=>{
  const app=await harness({mission:{status:'planned',answers:[],artifacts:[]}});
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
  assert.match(app.root.innerHTML,/Trà Sen Tây Hồ/);
  await app.click('start');
  const starts=app.calls.filter(call=>call.body?.name==='start_mission');
  assert.equal(starts.length,1);
  assert.deepEqual(Object.keys(starts[0].body.arguments).sort(),['enterprise_id','mission_id','operation_id']);
});
test('Lưu khung nhãn dùng request atomic và phiên bản server, không nhớ hồ sơ mặc định',async()=>{
  const app=await harness();
  await app.submit('v03-label-form',{statement_of_identity:'Lotus-scented green tea',ingredients:''});
  const save=app.calls.find(call=>call.body?.name==='update_label_progress');
  assert.equal(save.body.arguments.artifact_id,'label-a');
  assert.equal(save.body.arguments.fields.statement_of_identity,'Lotus-scented green tea');
  assert.equal(save.body.arguments.fields.ingredients,undefined,'Ô trống chưa đổi không gửi như một lệnh xóa.');
  assert.equal(save.body.arguments.expected_artifact_version,1);
  assert.equal(save.body.arguments.expected_entity_version,2);
  assert.deepEqual(save.body.arguments.remember_fields,[]);
  assert.match(app.root.innerHTML,/Đã lưu khung nhãn và giữ lịch sử phiên bản/);
  assert.match(app.root.innerHTML,/Mở khung nhãn tiếng Anh · bản 2/);
  assert.match(app.root.innerHTML,/Chưa ghi nhớ thêm dữ kiện vào hồ sơ/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
});
test('Câu hỏi mới không tự buộc vào sản phẩm cũ và chỉ lập kế hoạch khi gửi',async()=>{
  const app=await harness();
  await app.click('new');
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
  await app.submit('v03-chat-form',{question:'Tôi có Mứt Sen gửi Mỹ, cần chuẩn bị nhãn.'});
  const prepares=app.calls.filter(call=>call.body?.name==='prepare_mission');
  assert.equal(prepares.length,1);
  assert.equal(prepares[0].body.arguments.product_entity_id,null);
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
});
test('Sửa dữ kiện chỉ gửi trường thay đổi, không xóa ngầm ô trống và không tự nghiên cứu lại',async()=>{
  const app=await harness();
  await app.submit('v03-facts-form',{product_name:'Trà Sen Tây Hồ Đặc Biệt',ingredients:'',net_weight:'100 g',facility_activity:'Đóng gói',facility_type:'Cơ sở sản xuất',fda_registration_status:''});
  const save=app.calls.find(call=>call.body?.name==='update_enterprise_facts');
  assert.equal(save.body.arguments.expected_version,2);
  assert.deepEqual(save.body.arguments.facts,[{field:'product_name',value:'Trà Sen Tây Hồ Đặc Biệt'},{field:'facility_activity',value:'Đóng gói'},{field:'facility_type',value:'Cơ sở sản xuất'}]);
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission' || call.body?.name==='start_mission'),false);
  assert.match(app.root.innerHTML,/Nhận định cần rà/);
  assert.match(app.root.innerHTML,/Nhãn và dữ kiện đã lưu được giữ/);
  assert.match(app.root.innerHTML,/class="v03-button subtle" data-v03="revalidate"[^>]*>Rà lại nhận định · giả lập/);
});
test('Lịch sử mở lại câu trả lời, không hiển thị biểu mẫu chính thay cho trợ lý',async()=>{
  const app=await harness();
  await app.click('history');
  assert.match(app.root.innerHTML,/Các câu hỏi đã lưu/);
  assert.match(app.root.innerHTML,/Có kết quả, còn thiếu dữ kiện/);
  await app.click('open-mission','mission-a');
  assert.match(app.root.innerHTML,/id="v03-result"/);
  assert.match(app.root.innerHTML,/id="v03-chat-form"/);
});
test('Việc xem căn cứ mở đúng phần nguồn, không gọi thêm nghiên cứu',async()=>{
  const app=await harness({mission:{actions:[{id:'review-registration',title:'Rà căn cứ và ngoại lệ',kind:'review_sources',outcome_ids:['registration']}]}});
  assert.match(app.root.innerHTML,/>Xem nguồn</);
  const before=app.calls.length;
  await app.click('mission-action',0);
  assert.match(app.root.innerHTML,/id="v03-sources" open/);
  assert.match(app.root.innerHTML,/chưa gửi yêu cầu cho chuyên gia/);
  assert.equal(app.calls.length,before);
});
test('Cơ sở có missing_fields rõ chỉ mở đúng hai ô thiếu; field khác vẫn có trong hồ sơ',async()=>{
  const app=await harness({mission:{actions:[{id:'supply-facility',title:'Bổ sung hoạt động và loại hình cơ sở',kind:'supply_facts',outcome_ids:['registration']}]}});
  const before=app.calls.length;
  await app.click('mission-action',0);
  const fields=()=>[...app.root.innerHTML.split('id="v03-facts-form"')[1].split('</form>')[0].matchAll(/name="([a-z_]+)"/g)].map(match=>match[1]);
  assert.deepEqual(fields(),['facility_activity','facility_type']);
  assert.match(app.root.innerHTML,/Bổ sung thông tin cơ sở/);
  assert.match(app.root.innerHTML,/Mở hồ sơ doanh nghiệp/);
  assert(!fields().includes('ingredients'));
  assert(!fields().includes('statement_of_identity'));
  assert.equal(app.calls.length,before);
  await app.click('profile');
  for(const key of ['origin_country','facility_name','facility_address','fda_registration_status'])assert(fields().includes(key),'Hồ sơ đầy đủ còn trường '+key);
  assert.equal(app.calls.some(call=>['prepare_mission','start_mission','update_enterprise_facts'].includes(call.body?.name)),false);
});
test('Nhập thông tin cơ sở rồi mở hồ sơ đầy đủ giữ nguyên bản nháp và hoa thường',async()=>{
  const app=await harness();
  await app.click('open-facts');
  app.input('facility_activity','Đóng Gói Trà Sen & Bảo Quản','v03-facts-form');
  app.input('facility_type','Cơ Sở Sản Xuất Tây Hồ','v03-facts-form');
  await app.click('profile');
  const form=app.root.innerHTML.split('id="v03-facts-form"')[1].split('</form>')[0];
  assert.match(form,/Đóng Gói Trà Sen &amp; Bảo Quản/);
  assert.match(form,/value="Cơ Sở Sản Xuất Tây Hồ"/);
  assert.match(form,/value="Trà Sen Tây Hồ"/);
  assert.match(form,/value="100 g"/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
});
test('Căn cứ FDA chỉ mở hai đoạn đăng ký; nguồn nhãn chỉ thêm khi chọn xem tất cả',async()=>{
  const records=[{id:'label-1',title_vi:'Dị nguyên trên nhãn',excerpt_vi:'Nguồn nhãn riêng',topics:['food_label']},{id:'registration-1',title_vi:'Phạm vi đăng ký cơ sở',excerpt_vi:'Căn cứ FDA thứ nhất',topics:['facility_registration']},{id:'registration-2',title_vi:'Ngoại lệ đăng ký',excerpt_vi:'Căn cứ FDA thứ hai',topics:['facility_registration']}];
  const app=await harness({mission:{sources:records,actions:[{id:'review-registration',title:'Rà căn cứ',kind:'review_sources'}]}});
  const before=app.calls.length;
  await app.click('open-sources');
  assert.match(app.root.innerHTML,/Căn cứ đăng ký cơ sở FDA \(2\)/);
  assert.match(app.root.innerHTML,/Căn cứ FDA thứ nhất/);
  assert.match(app.root.innerHTML,/Căn cứ FDA thứ hai/);
  assert.doesNotMatch(app.root.innerHTML,/Dị nguyên trên nhãn/);
  await app.click('all-sources');
  assert.match(app.root.innerHTML,/Dị nguyên trên nhãn/);
  assert.equal(app.calls.length,before);
});
test('Điền ba ô một lần rồi chọn ghi nhớ: một lệnh atomic lưu nhãn và SSOT',async()=>{
  const app=await harness();
  const values={statement_of_identity:'Lotus-scented green tea',net_quantity:'100 g',ingredients:'Green tea, lotus scent'};
  for(const [key,value] of Object.entries(values)){app.input(key,value,'v03-label-form');app.input('remember_'+key,'on','v03-label-form',true);}
  await app.submit('v03-label-form',values);
  const writes=app.calls.filter(call=>call.body?.name==='update_label_progress');
  assert.equal(writes.length,1);
  assert.deepEqual(writes[0].body.arguments.fields,values);
  assert.deepEqual(writes[0].body.arguments.remember_fields,['statement_of_identity','net_quantity','ingredients']);
  assert.equal(app.calls.filter(call=>call.body?.name==='update_enterprise_facts').length,0);
  assert.match(app.root.innerHTML,/Đã lưu nhãn và ghi nhớ 3 dữ kiện/);
  assert.match(app.root.innerHTML,/chưa được kiểm chứng bên ngoài/);
  assert.match(app.root.innerHTML,/3 nội dung đã có · Sửa khi cần/);
  assert.equal((app.root.innerHTML.match(/name="ingredients"/g)||[]).length,1,'Không lặp ô nhãn trong một form SSOT thứ hai.');
});
test('Nội dung đã lưu có thể chọn ghi nhớ mà không gõ lại và không gửi field sửa giả',async()=>{
  const fields=clone(labelFields);fields[0].value='Lotus-scented green tea';fields[1].value='100 g';fields[2].value='Green tea, lotus scent';
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields,parent_artifact_ref:{mission_id:'parent-a',artifact_id:'parent-label',version:2}}]}});
  assert.match(app.root.innerHTML,/Tiếp tục nhãn đã lưu/);
  assert.match(app.root.innerHTML,/Tiếp từ bản đã lưu trước; bản trước vẫn trong lịch sử/);
  assert.doesNotMatch(app.root.innerHTML,/Tiếp tục nhãn đã lưu · bản/);
  for(const key of ['statement_of_identity','net_quantity','ingredients'])app.input('remember_'+key,'on','v03-label-form',true);
  await app.submit('v03-label-form',{});
  const save=app.calls.find(call=>call.body?.name==='update_label_progress');
  assert.deepEqual(save.body.arguments.fields,{});
  assert.equal(save.body.arguments.remember_fields.length,3);
  assert.match(app.root.innerHTML,/Lotus-scented green tea/);
});
test('Action bổ sung nhãn luôn quay vào cùng editor, không mở form cơ sở',async()=>{
  const app=await harness({mission:{intent:{outcomes:[{id:'label',title:'Khung nhãn'}]},actions:[{id:'supply-label',title:'Bổ sung nhãn',kind:'supply_facts',outcome_ids:['label']}]}});
  const before=app.calls.length;
  await app.click('mission-action',0);
  assert.match(app.root.innerHTML,/id="v03-workbook" open/);
  assert.doesNotMatch(app.root.innerHTML,/id="v03-facts-form"/);
  assert.equal((app.root.innerHTML.match(/id="v03-label-form"/g)||[]).length,1);
  assert.equal(app.calls.length,before);
});
test('Câu hỏi tiếp gửi parent mission và product ID, không tự nghiên cứu',async()=>{
  const app=await harness();
  await app.submit('v03-chat-form',{question:'Tiếp tục nhãn đã lưu, không nghiên cứu lại đăng ký cơ sở.'});
  const prepare=app.calls.find(call=>call.body?.name==='prepare_mission');
  assert.equal(prepare.body.arguments.continuation_mission_id,'mission-a');
  assert.equal(prepare.body.arguments.product_entity_id,'product-a');
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
});
test('Nhãn chưa lưu không bị bỏ khi gửi câu hỏi tiếp hoặc bấm câu hỏi mới',async()=>{
  const app=await harness();app.input('statement_of_identity','Lotus tea chưa lưu','v03-label-form');
  await app.submit('v03-chat-form',{question:'Tiếp tục phần khác.'});
  await app.click('new');
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
  assert.match(app.root.innerHTML,/Lotus tea chưa lưu/);
  assert.match(app.root.innerHTML,/Bạn có nội dung nhãn chưa lưu/);
});
test('Xung đột không có lựa chọn thì chặn ghi nhớ; chọn SSOT mới gửi rõ quyết định',async()=>{
  const fields=clone(labelFields);fields[2].value='Green tea, lotus scent';fields[2].conflict={reason:'ssot_changed',draft_value:'Green tea, lotus scent',ssot_value:'Green tea',ssot_fact_version:3};
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields}]}});
  app.input('remember_ingredients','on','v03-label-form',true);
  await app.submit('v03-label-form',{});
  assert.equal(app.calls.some(call=>call.body?.name==='update_label_progress'),false);
  assert.match(app.root.innerHTML,/Bạn chọn nội dung muốn dùng/);
  app.input('conflict_ingredients','ssot','v03-label-form');
  await app.submit('v03-label-form',{});
  const save=app.calls.find(call=>call.body?.name==='update_label_progress');
  assert.equal(save.body.arguments.fields.ingredients,'Green tea');
  assert.deepEqual(save.body.arguments.conflict_choices,{ingredients:'ssot'});
  assert.deepEqual(save.body.arguments.remember_fields,['ingredients']);
});
test('Sửa trực tiếp trường đang xung đột là quyết định edited; không nâng thành verified',async()=>{
  const fields=clone(labelFields);fields[2].value='Old tea';fields[2].conflict={reason:'ssot_changed',draft_value:'Old tea',ssot_value:'Green tea',ssot_fact_version:3};
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields}]}});
  app.input('ingredients','Green tea, lotus petals','v03-label-form');
  await app.submit('v03-label-form',{ingredients:'Green tea, lotus petals'});
  const save=app.calls.find(call=>call.body?.name==='update_label_progress');
  assert.deepEqual(save.body.arguments.conflict_choices,{ingredients:'edited'});
  assert.equal(save.body.arguments.fields.ingredients,'Green tea, lotus petals');
  assert.deepEqual(save.body.arguments.remember_fields,[]);
  assert.equal(save.body.arguments.verified,undefined);
});
test('Giữ nội dung nhãn xử lý xung đột được lưu dù giá trị không đổi và không chọn ghi nhớ',async()=>{
  const fields=clone(labelFields);fields[2].value='Green tea, lotus scent';fields[2].conflict={reason:'ssot_changed',draft_value:'Green tea, lotus scent',ssot_value:'Green tea',ssot_fact_version:3};
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields}]}});
  app.input('conflict_ingredients','draft','v03-label-form');
  await app.click('new');
  assert.match(app.root.innerHTML,/Bạn có nội dung nhãn chưa lưu/);
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
  await app.submit('v03-label-form',{});
  const saves=app.calls.filter(call=>call.body?.name==='update_label_progress');
  assert.equal(saves.length,1);
  assert.deepEqual(saves[0].body.arguments.fields,{ingredients:'Green tea, lotus scent'});
  assert.deepEqual(saves[0].body.arguments.conflict_choices,{ingredients:'draft'});
  assert.deepEqual(saves[0].body.arguments.remember_fields,[]);
  assert.match(app.root.innerHTML,/Đã lưu khung nhãn và giữ lịch sử phiên bản/);
});
test('CAS lỗi giữ nguyên draft và checkbox đã chọn; không tự gửi lại',async()=>{
  const app=await harness({saveError:true});
  app.input('ingredients','Green Tea & Lotus Petals','v03-label-form');app.input('remember_ingredients','on','v03-label-form',true);
  await app.submit('v03-label-form',{ingredients:'Green Tea & Lotus Petals'});
  assert.equal(app.calls.filter(call=>call.body?.name==='update_label_progress').length,1);
  assert.match(app.root.innerHTML,/Hồ sơ đã đổi/);
  assert.match(app.root.innerHTML,/Green Tea &amp; Lotus Petals/);
  assert.match(app.root.innerHTML,/name="remember_ingredients" checked/);
});
test('Mục tiêu cần làm rõ chỉ hỏi lại trong chat, không có nút nghiên cứu',async()=>{
  const app=await harness({mission:{status:'waiting_input',clarification_question:'Bạn muốn kiểm tra đăng ký cơ sở hay làm nhãn?',answers:[],artifacts:[]}});
  assert.match(app.root.innerHTML,/Bạn muốn kiểm tra đăng ký cơ sở hay làm nhãn/);
  assert.doesNotMatch(app.root.innerHTML,/data-v03="start"/);
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
});
test('Action lạ không điều khiển route/script; label-only chỉ mở nguồn nhãn',async()=>{
  const records=[{id:'label',title_vi:'Nguồn nhãn riêng',topics:['food_label']},{id:'registration',title_vi:'Nguồn cơ sở riêng',topics:['facility_registration']}];
  const app=await harness({mission:{sources:records,actions:[{id:'source-label',title:'Rà nhãn',kind:'review_sources',outcome_ids:['label']},{id:'bad',title:'Không thực thi',kind:'javascript:alert(1)',route:'/not-allowed'}]}});
  const before=app.calls.length;
  await app.click('mission-action',0);
  assert.match(app.root.innerHTML,/Nguồn nhãn riêng/);assert.doesNotMatch(app.root.innerHTML,/Nguồn cơ sở riêng/);
  const html=app.root.innerHTML;await app.click('mission-action',1);await app.click('mission-action',999);
  assert.equal(app.root.innerHTML,html);assert.equal(app.calls.length,before);
});
test('Nhiều hồ sơ cùng tên phải chọn rõ, không tự lấy sản phẩm đầu hay kế thừa nhầm parent',async()=>{
  const app=await harness({mission:{status:'waiting_input',product:null,artifacts:[],answers:[],intent:{ambiguities:['Có nhiều hồ sơ trùng tên, bạn chọn đúng hồ sơ.'],outcomes:[]},product_candidates:[{entity_id:'product-a',name:'Trà Sen Tây Hồ',version:2},{entity_id:'product-b',name:'Trà Sen Hồ Tây',version:4}]}});
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
  assert.match(app.root.innerHTML,/Trà Sen Tây Hồ · hồ sơ 1/);assert.match(app.root.innerHTML,/Trà Sen Hồ Tây · hồ sơ 2/);
  await app.click('choose-product',1);
  const prepare=app.calls.find(call=>call.body?.name==='prepare_mission');
  assert.equal(prepare.body.arguments.product_entity_id,'product-b');
  assert.equal(prepare.body.arguments.continuation_mission_id,undefined);
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
});
test('Chip làm rõ chỉ điền chat, không lập kế hoạch hay chạy nghiên cứu ngầm',async()=>{
  const app=await harness({mission:{status:'waiting_input',product:null,answers:[],artifacts:[],intent:{outcomes:[{id:'clarification',title:'Làm rõ mục tiêu'}],ambiguities:['Bạn muốn tìm hiểu điều gì?']}}});
  const before=app.calls.length;await app.click('clarify-choice',1);
  assert.match(app.root.innerHTML,/Tôi muốn chuẩn bị nhãn tiếng Anh\./);
  assert.equal(app.calls.length,before);
  assert.doesNotMatch(app.root.innerHTML,/data-v03="start"/);
});
test('Nội dung đã có nhưng cần rà giữ nguyên giá trị và không gập mất cảnh báo',async()=>{
  const fields=clone(labelFields);fields[2].value='Green Tea, Lotus Scent';fields[2].state='needs_review';
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields,parent_artifact_ref:{mission_id:'parent-a',artifact_id:'parent-label',version:2}}]}});
  assert.match(app.root.innerHTML,/Green Tea, Lotus Scent/);
  assert.match(app.root.innerHTML,/Nội dung đã được giữ lại; phần này cần rà/);
  assert.match(app.root.innerHTML,/bản trước vẫn trong lịch sử/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_label_progress'),false);
});
test('Ghi nhớ chỉ hiện ba giá trị đã có; ô trống không thành ba checkbox dư',async()=>{
  const fields=clone(labelFields);fields[0].value='Lotus tea';fields[1].value='100 g';fields[2].value='Green tea, lotus scent';
  const app=await harness({mission:{artifacts:[{...mission.artifacts[0],fields}]}});
  const rows=[...app.root.innerHTML.matchAll(/<label class="v03-check v03-memory-choice" id="v03-memory-choice-([^"]+)"([^>]*)>/g)];
  assert.deepEqual(rows.filter(row=>!(/\bhidden\b/.test(row[2]))).map(row=>row[1]),['statement_of_identity','net_quantity','ingredients']);
  assert.equal(rows.filter(row=>/\bhidden\b/.test(row[2])).length,3);
  assert.deepEqual(helpers.rememberableFields({fields}).map(field=>field.key),['statement_of_identity','net_quantity','ingredients']);
  assert.match(fs.readFileSync(path.join(__dirname,'../src/mission-v03.css'),'utf8'),/\.v03-memory-choice\[hidden\][^{]*\{display:none\}/);
});
test('Gõ tại editor hiện checkbox ghi nhớ tương ứng ngay, không cần nhập lại hoặc gọi server',async()=>{
  const app=await harness(),before=app.calls.length;
  assert.equal(app.elements['v03-memory-choice-ingredients'].hidden,true);
  app.input('ingredients','Green Tea & Lotus Scent','v03-label-form');
  assert.equal(app.elements['v03-memory-choice-ingredients'].hidden,false);
  assert.equal(app.elements['v03-memory-ingredients'].textContent,'Green Tea & Lotus Scent');
  assert.equal(app.elements['v03-memory-choice-allergens'].hidden,true);
  assert.equal(app.elements['v03-memory-empty'].hidden,true);
  app.input('ingredients','','v03-label-form');
  assert.equal(app.elements['v03-memory-choice-ingredients'].hidden,true);
  assert.equal(app.elements['v03-memory-empty'].hidden,false);
  assert.equal(app.calls.length,before);
});
test('Không có hợp đồng missing_fields thì cơ sở vẫn mở đủ sáu trường để chủ động bổ sung',async()=>{
  const app=await harness({mission:{answers:[{outcome_id:'registration',title:'Đăng ký',text:'Cần bổ sung dữ kiện cơ sở.'}],actions:[{id:'supply-facility',title:'Bổ sung dữ kiện',kind:'supply_facts',outcome_ids:['registration']}]}});
  await app.click('mission-action',0);
  const fields=[...app.root.innerHTML.split('id="v03-facts-form"')[1].split('</form>')[0].matchAll(/name="([a-z_]+)"/g)].map(match=>match[1]);
  assert.deepEqual(fields,['origin_country','facility_name','facility_address','facility_activity','facility_type','fda_registration_status']);
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission' || call.body?.name==='start_mission'),false);
});
test('Từ hồ sơ về trợ lý đóng form hồ sơ, giữ editor và nội dung nhãn chưa lưu',async()=>{
  const app=await harness({mission:{intent:{outcomes:[{id:'label',title:'Khung nhãn'}]}}});
  await app.click('mission-action',0);
  app.input('ingredients','Green Tea, Lotus Scent chưa lưu','v03-label-form');
  await app.click('profile');
  assert.match(app.root.innerHTML,/id="v03-facts-form"/);
  await app.click('back');
  assert.match(app.root.innerHTML,/id="v03-workbook" open/);
  assert.match(app.root.innerHTML,/Green Tea, Lotus Scent chưa lưu/);
  assert.doesNotMatch(app.root.innerHTML,/id="v03-facts-form"/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_label_progress'),false);
});
test('Câu hỏi mới sau lưu hồ sơ xóa notice và mode của hội thoại cũ',async()=>{
  const app=await harness({mission:{intent:{outcomes:[{id:'label',title:'Khung nhãn'}]}}});
  await app.click('profile');await app.click('open-facts');
  app.input('product_name','Trà Sen Hồ Tây','v03-facts-form');
  await app.submit('v03-facts-form',{product_name:'Trà Sen Hồ Tây'});
  assert.match(app.root.innerHTML,/Hồ sơ doanh nghiệp/);
  await app.click('back');assert.match(app.root.innerHTML,/Đã lưu dữ kiện để dùng lại/);
  assert.doesNotMatch(app.root.innerHTML,/id="v03-facts-form"/);
  await app.click('new');
  assert.doesNotMatch(app.root.innerHTML,/Đã lưu dữ kiện để dùng lại|id="v03-facts-form"|id="v03-workbook"/);
  assert.match(app.root.innerHTML,/Bạn muốn chuẩn bị điều gì/);
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
});
test('Nháp facts chưa lưu được giữ khi về chat và chặn mở câu hỏi khác thay vì bỏ thầm',async()=>{
  const app=await harness({mission:{intent:{outcomes:[{id:'label',title:'Khung nhãn'}]}}});
  await app.click('profile');await app.click('open-facts');
  app.input('facility_name','Cơ Sở Sen Tây Hồ Chưa Lưu','v03-facts-form');
  await app.click('back');
  assert.match(app.root.innerHTML,/Đã giữ bản nháp dữ kiện chưa lưu/);
  assert.doesNotMatch(app.root.innerHTML,/id="v03-facts-form"/);
  await app.click('new');
  assert.match(app.root.innerHTML,/Bạn có dữ kiện hồ sơ chưa lưu/);
  assert.match(app.root.innerHTML,/Cơ Sở Sen Tây Hồ Chưa Lưu/);
  assert.match(app.root.innerHTML,/id="v03-facts" open/);
  await app.submit('v03-chat-form',{question:'Câu hỏi mới khi chưa lưu hồ sơ.'});
  assert.equal(app.calls.some(call=>call.body?.name==='prepare_mission'),false);
  assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
});

const marketFixture=code=>{
  const market=clone(helpers.marketOf({market:{code}})),language=market.label_language;
  const fields=clone(labelFields);fields[0].label_vi='Tên thực phẩm trên nhãn';fields[0].label_en=code==='DE'?'Bezeichnung des Lebensmittels':'名称';
  fields[1].value='100 g';fields[2].value='Green tea, Lotus flowers';fields[1].state=fields[2].state='needs_review';
  fields.push({id:'date_marking',label_vi:'Ngày hoặc hạn dùng thể hiện trên nhãn',label_en:code==='DE'?'Mindesthaltbarkeitsdatum / Verbrauchsdatum':'期限表示',state:'needs_input',value:null},{id:'storage_instructions',label_vi:'Hướng dẫn bảo quản trên nhãn',label_en:code==='DE'?'Aufbewahrungshinweise':'保存方法',state:'needs_input',value:null});
  fields.push({id:'ingredients_declaration',label_vi:'Cách ghi thành phần trên nhãn '+(code==='DE'?'tiếng Đức':'tiếng Nhật'),label_en:code==='DE'?'Zutaten (Kennzeichnung)':'原材料名（表示）',state:'needs_input',value:null});
  const profile={entity_id:'market-'+code,market_code:code,version:3,snapshot_version:3,values:{},facts:[]};
  return {market,market_profile:profile,question:'Cùng Trà Sen Tây Hồ, chuẩn bị nhãn cho '+market.name_vi,status:'completed_partial',intent:{outcomes:[{id:'label',title:'Khung nhãn '+language}]},answers:[{outcome_id:'label',title:'Nhãn '+market.name_vi,text:'Cần bổ sung nội dung nhãn riêng cho thị trường này.'}],actions:[{id:'edit-label',title:'Bổ sung nhãn '+market.name_vi,kind:'edit_label',outcome_ids:['label']}],artifacts:[{id:'label-'+code,kind:'food_label_workbook',market_code:code,label_language:language,version:1,fields}],context:{reused_fact_count:4,reused_shared_fact_count:4,reused_market_fact_count:0},sources:[]};
};

test('Ba ví dụ thị trường chỉ điền chat; chưa gửi thì không tạo kế hoạch hoặc lượt giả lập',async()=>{
  const app=await harness({remember:false});
  for(const [index,sample] of helpers.SAMPLES.entries()){
    const before=app.calls.length;await app.click('sample',index);
    assert.match(app.root.innerHTML,new RegExp(helpers.esc(sample.question).replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
    assert.equal(app.calls.length,before);
  }
  assert.match(app.root.innerHTML,/Trà Sen đi Mỹ/);assert.match(app.root.innerHTML,/Trà Sen đi Đức \(EU\)/);assert.match(app.root.innerHTML,/Trà Sen đi Nhật/);
  assert.equal(app.calls.some(call=>['prepare_mission','start_mission'].includes(call.body?.name)),false);
});

test('Chưa biết thị trường không mặc định Mỹ hoặc FDA, chỉ đưa hai mục tiêu thuộc phạm vi hỗ trợ',()=>{
  assert.equal(helpers.marketOf({}).code,'');
  assert.equal(helpers.labelTitle({}),'khung nhãn');
  for(const code of ['DE','JP']){
    const choices=helpers.clarificationChoices({market:{code}});
    assert.equal(choices.length,2);assert.doesNotMatch(JSON.stringify(choices),/FDA|thông báo trước|chứng nhận/i);
  }
});

test('Đức hiện nhãn tiếng Đức, tách reuse chung/thị trường và giữ dữ kiện chưa dịch ở trạng thái cần rà',async()=>{
  const app=await harness({mission:{...marketFixture('DE'),current_context:{values:{ingredients:'Green tea, Lotus flowers'},entities:[]}}});
  const html=app.root.innerHTML;
  assert.match(html,/Thị trường Đức \(EU\)/);assert.match(html,/Mở khung nhãn tiếng Đức/);assert.match(html,/lang="de"/);
  assert.match(html,/4 dữ kiện chung \+ 0 dữ kiện Đức \(EU\) dùng lại/);
  assert.match(html,/nhãn và nhận định thuộc hồ sơ Đức \(EU\)/);
  assert.match(html,/Green tea, Lotus flowers/);assert.match(html,/cần rà cách ghi bằng tiếng Đức/);
  assert.doesNotMatch(html,/FDA|Mở khung nhãn tiếng Anh|Lotus-scented/);
  assert.equal((html.match(/class="v03-action"/g)||[]).length,1,'Chỉ hiện công việc backend trả theo câu hỏi, không ép ba việc.');
  assert.equal((html.match(/name="ingredients"/g)||[]).length,0);assert.match(html,/Thành phần sản phẩm đã khai · dùng chung/);
});

test('Nguyên bản nguồn hiển thị đúng ngôn ngữ thực, giao diện và bản dịch vẫn tiếng Việt',async()=>{
  const data=marketFixture('JP');data.sources=[{id:'jp-ja',title_vi:'Ngôn ngữ trên nhãn tại Nhật',excerpt_vi:'Thông tin bắt buộc được trình bày theo yêu cầu tại Nhật.',excerpt_original:'食品表示は日本語で行う。',original_language:'ja',publisher_vi:'Cơ quan Tiêu dùng Nhật Bản',checked_at:'2026-10-18T00:00:00Z',topics:['food_label']},{id:'jp-en',title_vi:'Thông báo nhập khẩu thực phẩm',excerpt_vi:'Nguồn nhập khẩu bản tiếng Anh.',excerpt_original:'Import notification for food.',language:'en',topics:['facility_registration']}];
  const app=await harness({mission:data});
  assert.match(app.root.innerHTML,/Xem tiếng Nhật gốc/);assert.match(app.root.innerHTML,/lang="ja">食品表示/);
  assert.match(app.root.innerHTML,/Xem tiếng Anh gốc/);assert.match(app.root.innerHTML,/lang="en">Import notification/);
  assert.match(app.root.innerHTML,/18\/10\/2026/);assert.match(app.root.innerHTML,/Thông tin bắt buộc được trình bày/);
  assert.doesNotMatch(app.root.innerHTML,/Nguồn FDA|Mở khung nhãn tiếng Anh/);
  assert.equal(helpers.originalOf({excerpt:'Original',language:'bad" onclick="run()'}).language,'');
});

test('Hồ sơ Đức không hiển thị tên nhãn, nhà nhập khẩu và đăng ký FDA còn sót trên product Mỹ cũ',async()=>{
  const data=marketFixture('DE'),ctx=clone(context);
  Object.assign(ctx.entities[0].values,{statement_of_identity:'US PRIVATE LABEL',responsible_business:'US PRIVATE IMPORTER',fda_registration_status:'FDA ONLY'});
  ctx.entities.push({id:'market-DE',entity_type:'market',version:3,values:{statement_of_identity:'Grüner Tee',responsible_business:'DE Verantwortlicher'}});
  const app=await harness({mission:data,context:ctx});await app.click('profile');
  assert.match(app.root.innerHTML,/Grüner Tee/);assert.match(app.root.innerHTML,/DE Verantwortlicher/);assert.match(app.root.innerHTML,/Green tea|Trà xanh/);
  assert.doesNotMatch(app.root.innerHTML,/US PRIVATE|FDA ONLY|name="fda_registration_status"/);
  assert.match(app.root.innerHTML,/Tên sản phẩm · dùng chung/);assert.match(app.root.innerHTML,/Đơn vị chịu trách nhiệm và địa chỉ \(nếu có\) · Đức \(EU\)/);
});

test('Một lần lưu nhãn Đức gửi cả hai CAS, dữ kiện chung và riêng được phân loại bởi server',async()=>{
  const data=marketFixture('DE'),ctx=clone(context);ctx.entities.push({id:'market-DE',entity_type:'market',version:3,values:{}});
  const app=await harness({mission:data,context:ctx});
  app.input('statement_of_identity','Grüner Tee mit Lotusduft','v03-label-form');
  app.input('remember_statement_of_identity','on','v03-label-form',true);app.input('remember_net_quantity','on','v03-label-form',true);
  await app.submit('v03-label-form',{statement_of_identity:'Grüner Tee mit Lotusduft'});
  const saves=app.calls.filter(call=>call.body?.name==='update_label_progress');assert.equal(saves.length,1);
  const args=saves[0].body.arguments;
  assert.equal(args.expected_entity_version,2);assert.equal(args.expected_market_profile_version,3);assert.equal(args.expected_artifact_version,1);
  assert.deepEqual(args.fields,{statement_of_identity:'Grüner Tee mit Lotusduft'});assert.deepEqual(args.remember_fields,['statement_of_identity','net_quantity']);
  await app.click('profile');assert.match(app.root.innerHTML,/Grüner Tee mit Lotusduft/);assert.match(app.root.innerHTML,/hồ sơ Đức \(EU\) phiên bản 4/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
  assert.deepEqual(helpers.marketVersionArgs({version:0}),{expected_market_profile_version:0});
});

test('Bổ sung dữ kiện nhập khẩu Nhật mở đúng ba phần thiếu gồm đơn vị chịu trách nhiệm riêng thị trường',async()=>{
  const data=marketFixture('JP');data.intent.outcomes=[{id:'registration',title:'Điều kiện nhập khẩu Nhật'}];data.answers=[{outcome_id:'registration',title:'Thông báo nhập khẩu Nhật',text:'Còn thiếu dữ kiện.',missing_fields:['facility_activity','facility_type','responsible_business']}];data.actions=[{id:'facts',title:'Bổ sung dữ kiện nhập khẩu',kind:'supply_facts',outcome_ids:['registration']}];
  const app=await harness({mission:data});await app.click('mission-action',0);
  const form=app.root.innerHTML.split('id="v03-facts-form"')[1].split('</form>')[0];
  const fields=[...form.matchAll(/name="([a-z_]+)"/g)].map(match=>match[1]);
  assert.deepEqual(fields,['responsible_business','facility_activity','facility_type']);
  assert.doesNotMatch(form,/fda_registration_status|name="ingredients"/);
});

test('Đổi từ Mỹ sang Nhật giữ product và parent, lịch sử có nhãn thị trường riêng; tải nhãn kèm mã thị trường',async()=>{
  const data=marketFixture('JP');data.status='planned';data.artifacts=[];
  const app=await harness({preparedMission:{...mission,...data},history:[{...mission},{...mission,...marketFixture('DE')},{...mission,...marketFixture('JP')}]});
  await app.submit('v03-chat-form',{question:'Giờ cùng sản phẩm Trà Sen Tây Hồ, tôi muốn gửi Nhật và làm nhãn tiếng Nhật.'});
  const request=app.calls.find(call=>call.body?.name==='prepare_mission');assert.equal(request.body.arguments.product_entity_id,'product-a');assert.equal(request.body.arguments.continuation_mission_id,'mission-a');
  assert.match(app.root.innerHTML,/Thị trường Nhật Bản/);assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
  await app.click('history');assert.match(app.root.innerHTML,/Thị trường Mỹ/);assert.match(app.root.innerHTML,/Thị trường Đức \(EU\)/);assert.match(app.root.innerHTML,/Thị trường Nhật Bản/);
  assert.equal(helpers.labelDownload({kind:'food_label_workbook',market_code:'JP',version:2,markdown:'# Nhãn Nhật\n'}).filename,'nMate-khung-nhan-JP-v2.md');
  const css=fs.readFileSync(path.join(__dirname,'../src/mission-v03.css'),'utf8');assert.match(css,/\.v03-samples\{[^}]*flex-wrap:wrap/);assert.match(css,/\.v03-samples>\.v03-sample\{[^}]*min-width:0/);
});

test('EU chưa chọn nước chỉ gợi ý Đức, giữ nguyên yêu cầu rồi gửi lựa chọn thị trường rõ ràng',async()=>{
  const question='Cùng Trà Sen Tây Hồ, tôi cần nhãn cho EU; giữ quy cách 100 g.';
  const app=await harness({mission:{market:null,market_profile:null,status:'waiting_input',question,intent:{scope:'unsupported',market_code:null,market_candidates:['EU'],outcomes:[{id:'label',title:'Chuẩn bị nhãn'}],ambiguities:['EU gồm nhiều quốc gia. Bạn muốn xuất sang nước nào?']},artifacts:[],answers:[]}});
  const before=app.calls.length;
  assert.match(app.root.innerHTML,/Chọn thị trường cho lượt này/);assert.match(app.root.innerHTML,/data-v03="choose-market" data-index="0">Đức \(EU\)/);
  assert.doesNotMatch(app.root.innerHTML,/data-v03="choose-market" data-index="1"|data-v03="start"/);
  await app.click('choose-market',0);assert.equal(app.calls.length,before);
  assert.match(app.root.innerHTML,/giữ quy cách 100 g/);assert.match(app.root.innerHTML,/Tôi chọn thị trường Đức \(EU\) cho lượt này/);
  await app.submit('v03-chat-form',{question:question+'\n\nTôi chọn thị trường Đức (EU) cho lượt này.'});
  const prepared=app.calls.find(call=>call.body?.name==='prepare_mission');assert.equal(prepared.body.arguments.market_code,'DE');assert.equal(prepared.body.arguments.product_entity_id,'product-a');
  assert.equal(app.calls.some(call=>call.body?.name==='start_mission'),false);
});

test('Thị trường chưa hỗ trợ không hiện nút chọn thay thế hoặc lén áp Mỹ; chưa nêu đích thì có ba lựa chọn',async()=>{
  const options={market:null,market_profile:null,status:'waiting_input',question:'Tôi có Trà Sen gửi Canada, cần chuẩn bị nhãn.',intent:{scope:'unsupported',market_code:null,market_candidates:['OTHER'],outcomes:[{id:'label',title:'Nhãn'}],ambiguities:['Thị trường vừa nêu chưa có gói nguồn trong 0.3B.']},answers:[],artifacts:[]};
  const app=await harness({mission:options});assert.doesNotMatch(app.root.innerHTML,/data-v03="choose-market"|data-v03="start"|data-v03="clarify-choice"/);
  assert.equal(app.calls.some(call=>['prepare_mission','start_mission'].includes(call.body?.name)),false);
  assert.deepEqual(helpers.marketChoices({intent:{market_candidates:[]}}).map(choice=>choice.code),['US','DE','JP']);
  assert.deepEqual(helpers.marketChoices({intent:{market_candidates:['US','JP']}}).map(choice=>choice.code),['US','JP']);
});

test('Nhãn Đức và Nhật có chín ô, ngày/hạn dùng và bảo quản để trống cho đến khi người dùng khai rõ',async()=>{
  for(const code of ['DE','JP']){
    const data=marketFixture(code),app=await harness({mission:data});
    assert.equal(helpers.labelFields(data.artifacts[0]).length,9);
    assert.match(app.root.innerHTML,/name="date_marking"/);assert.match(app.root.innerHTML,/name="storage_instructions"/);
    assert.match(app.root.innerHTML,/2\/9 trường đã có nội dung/);
    for(const key of ['date_marking','storage_instructions']){
      assert.match(app.root.innerHTML,new RegExp('id="v03-memory-choice-'+key+'" hidden'));
      assert.equal(app.elements['v03-memory-choice-'+key].hidden,true);
    }
    await app.click('profile');assert.match(app.root.innerHTML,/ứng dụng không tự tính hạn dùng/);assert.match(app.root.innerHTML,/name="date_marking" rows="2" maxlength="2000"><\/textarea>/);
  }
  const us=await harness();await us.click('profile');assert.doesNotMatch(us.root.innerHTML,/name="date_marking"|name="storage_instructions"/);
  assert.equal(helpers.labelFields(mission.artifacts[0]).length,6);
});

test('Ngày/hạn dùng và bảo quản chỉ nhớ hồ sơ Nhật bằng một lần lưu atomic, không tự ghi vào SSOT chung',async()=>{
  const data=marketFixture('JP'),ctx=clone(context);ctx.entities.push({id:'market-JP',entity_type:'market',version:3,values:{}});
  const app=await harness({mission:data,context:ctx}),values={date_marking:'Hạn dùng đang chờ doanh nghiệp xác nhận',storage_instructions:'直射日光、高温多湿を避けて保存'};
  for(const [key,value] of Object.entries(values)){app.input(key,value,'v03-label-form');app.input('remember_'+key,'on','v03-label-form',true);}
  await app.submit('v03-label-form',values);
  const saves=app.calls.filter(call=>call.body?.name==='update_label_progress');assert.equal(saves.length,1);
  assert.deepEqual(saves[0].body.arguments.fields,values);assert.deepEqual(saves[0].body.arguments.remember_fields,['date_marking','storage_instructions']);
  assert.equal(saves[0].body.arguments.expected_market_profile_version,3);
  assert.deepEqual(helpers.MARKET_FACT_FIELDS.filter(key=>Object.hasOwn(values,key)),['date_marking','storage_instructions']);
  await app.click('profile');assert.match(app.root.innerHTML,/Hạn dùng đang chờ doanh nghiệp xác nhận/);assert.match(app.root.innerHTML,/直射日光、高温多湿を避けて保存/);
  assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
});

test('Thành phần gốc chỉ đọc, các ô cần rà và bổ sung cùng giới hạn ba ô mở; năm ô còn lại gập',async()=>{
  const data=marketFixture('DE'),label=data.artifacts[0],sections=helpers.labelEditorSections(label);
  assert.deepEqual(sections.visible.map(field=>field.key),['net_quantity','statement_of_identity','responsible_business']);
  assert.equal(sections.later.length,5);assert.equal(sections.known.length,0);assert.equal(sections.readonly.length,1);
  const app=await harness({mission:data}),form=app.root.innerHTML.split('id="v03-label-form"')[1].split('</form>')[0],openPart=form.split('<details class="v03-details">')[0];
  assert.equal((openPart.match(/<textarea /g)||[]).length,3,'Cả phần cần rà và phần thiếu cùng chia một giới hạn ba ô.');
  assert.equal((form.match(/<textarea /g)||[]).length,8);assert.match(form,/Thêm 5 phần cần bổ sung hoặc rà/);
  assert.match(form,/100 g/);assert.match(form,/Green tea, Lotus flowers/);
  assert.equal((form.match(/Dữ kiện chung được giữ nguyên;/g)||[]).length,1,'Một lời nhắc ngôn ngữ chung, không lặp cảnh báo dài ở mỗi trường.');
  assert.doesNotMatch(openPart,/Dữ kiện sản phẩm dùng chung được giữ nguyên, chưa dịch/);
  const conflicting=clone(label);conflicting.fields[7].conflict={draft_value:'Old storage',ssot_value:'New storage'};
  assert.equal(helpers.labelEditorSections(conflicting).visible[0].key,'storage_instructions','Mâu thuẫn được ưu tiên trước các ô thiếu hoặc chỉ cần rà.');
  const css=fs.readFileSync(path.join(__dirname,'../src/mission-v03.css'),'utf8');assert.match(css,/\.v03-label-field \.v03-en\{[^}]*overflow-wrap:anywhere/);
});

test('Bản diễn đạt thành phần Đức/Nhật chỉ sửa nhãn thị trường; thao tác raw giả không đổi công thức dùng chung',async()=>{
  for(const code of ['DE','JP']){
    const data=marketFixture(code),ctx=clone(context);ctx.entities.push({id:'market-'+code,entity_type:'market',version:3,values:{}});
    const app=await harness({mission:data,context:ctx}),decl=code==='DE'?'Grüner Tee, Lotusblüten':'緑茶、蓮の花';
    assert.doesNotMatch(app.root.innerHTML,/textarea name="ingredients"|name="remember_ingredients"/);
    assert.match(app.root.innerHTML,/textarea name="ingredients_declaration"/);
    app.input('ingredients','TRANSLATION MUST NOT OVERWRITE RECIPE','v03-label-form');app.input('remember_ingredients','on','v03-label-form',true);
    app.input('ingredients_declaration',decl,'v03-label-form');app.input('remember_ingredients_declaration','on','v03-label-form',true);
    await app.submit('v03-label-form',{ingredients:'TRANSLATION MUST NOT OVERWRITE RECIPE',ingredients_declaration:decl});
    const saves=app.calls.filter(call=>call.body?.name==='update_label_progress');assert.equal(saves.length,1);
    assert.deepEqual(saves[0].body.arguments.fields,{ingredients_declaration:decl});assert.deepEqual(saves[0].body.arguments.remember_fields,['ingredients_declaration']);
    assert.equal(saves[0].body.arguments.expected_entity_version,2);assert.equal(saves[0].body.arguments.expected_market_profile_version,3);
    await app.click('profile');assert.match(app.root.innerHTML,/Trà xanh, hương sen/);assert.match(app.root.innerHTML,new RegExp(decl));assert.doesNotMatch(app.root.innerHTML,/TRANSLATION MUST NOT/);
    assert.match(app.root.innerHTML,/textarea name="ingredients"/,'Công thức gốc vẫn sửa được ở Hồ sơ bằng thao tác chủ động.');
    assert.equal(app.calls.some(call=>call.body?.name==='update_enterprise_facts'),false);
  }
});

test('Preview nhãn ưu tiên bản diễn đạt đã lưu, nguyên liệu gốc chỉ xuất hiện với nhãn tham chiếu chưa dịch khi chưa có bản diễn đạt',()=>{
  for(const code of ['DE','JP']){
    const data=marketFixture(code),label=data.artifacts[0];
    assert.match(helpers.labelPreview(label),/Thành phần sản phẩm dùng chung — tham chiếu chưa dịch: Green tea, Lotus flowers/);
    const field=label.fields.find(field=>field.id==='ingredients_declaration');field.value=code==='DE'?'Grüner Tee, Lotusblüten':'緑茶、蓮の花';
    assert.match(helpers.labelPreview(label),new RegExp(field.value));assert.doesNotMatch(helpers.labelPreview(label),/Green tea, Lotus flowers|tham chiếu chưa dịch/);
    assert.equal(helpers.rememberableFields(label).some(field=>field.key==='ingredients'),false);assert.equal(helpers.rememberableFields(label).some(field=>field.key==='ingredients_declaration'),true);
  }
  assert.equal(helpers.rememberableFields({fields:[{id:'ingredients',value:'Green tea'}]}).length,1,'US/legacy không đổi cách dùng trường thành phần.');
});

test('Toggle nguồn cũ trong lúc lập kế hoạch hoặc từ DOM đã thay không mở nguồn của hồ sơ thị trường mới',async()=>{
  let duringPrepare=0;
  const app=await harness({preparedMission:{...mission,...marketFixture('DE')},onPrepare:({listeners,elements})=>{duringPrepare++;listeners.toggle({target:elements['v03-sources']});}});
  const oldSource={id:'v03-sources',isConnected:true,open:true};app.elements['v03-sources']=oldSource;
  app.toggle(oldSource);await app.click('open-label');assert.match(app.root.innerHTML,/id="v03-sources" open/,'Toggle hiện tại vẫn ghi nhận lựa chọn mở nguồn.');
  await app.submit('v03-chat-form',{question:'Giờ cùng sản phẩm Trà Sen Tây Hồ, chỉ chuẩn bị nhãn cho Đức.'});assert.equal(duringPrepare,1);
  oldSource.isConnected=false;
  const currentSource={id:'v03-sources',isConnected:true,open:false};app.elements['v03-sources']=currentSource;
  app.toggle(oldSource);await app.click('start');
  assert.match(app.root.innerHTML,/Thị trường Đức \(EU\)/);assert.doesNotMatch(app.root.innerHTML,/id="v03-sources" open/,'Nguồn hồ sơ mới mặc định gập sau sự kiện cũ phát trễ.');
  currentSource.open=true;app.toggle(currentSource);await app.click('open-label');assert.match(app.root.innerHTML,/id="v03-sources" open/,'Người dùng vẫn mở được nguồn hiện tại.');
  app.toggle({id:'v03-sources',isConnected:true,open:false});await app.click('open-label');assert.match(app.root.innerHTML,/id="v03-sources" open/,'Node khác cùng ID không thay trạng thái hiện tại.');
  assert.equal(app.calls.filter(call=>call.body?.name==='start_mission').length,1);
});
