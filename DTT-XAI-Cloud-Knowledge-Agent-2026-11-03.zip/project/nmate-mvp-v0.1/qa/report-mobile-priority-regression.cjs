/* New mobile report contract. DOM/transport adapters only; no browser, HTTP or AI.
 * Geometry is verified separately in the real mobile walkthrough. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
const fixtureFile=path.join(__dirname,'live-research-regression.cjs');
const sandbox={require:id=>id==='node:test'?{test(){}}:createRequire(fixtureFile)(id),__dirname,__filename:fixtureFile,console:{log(){},error:console.error},URL,setImmediate};
vm.runInNewContext(fs.readFileSync(fixtureFile,'utf8')+'\nglobalThis.reportAdapter={harness,artifactData,settle};',sandbox,{filename:fixtureFile});
const R=sandbox.reportAdapter;
const byClass=(root,name)=>root.all().find(node=>node.className.split(/\s+/).includes(name))||null;
function canonical(summary='Nguồn hiện có chưa đủ để chốt điều kiện của lô hàng. Cần đối chiếu hồ sơ riêng trước khi quyết định.'){
 const a=R.artifactData();a.content_sha256='IMMUTABLE-REPORT';Object.assign(a.report,{summary,summary_kind:'assessment',summary_origin:'model',next_steps_policy_version:'0.2.2',readiness_status:'evidence_incomplete',next_steps:[
  {id:'clarify_import_roles',title:'Xác nhận bên nhập khẩu và bên xác minh nhà cung cấp',reason:'Xác nhận riêng IOR và FSVP.',done_when:'Có hai mục xác nhận riêng cho các bên, kèm điều chưa rõ để chuyên gia kiểm lại.',evidence_ids:[]},
  {id:'clarify_delivery_terms',title:'Làm rõ điều kiện giao hàng (Incoterm)',reason:'Ghi rõ chi phí và rủi ro dự kiến.',done_when:'Có phạm vi giao hàng để hỏi báo cước.',evidence_ids:[]},
  {id:'expert_preparation_review',title:'Nhờ chuyên gia rà đúng câu hỏi và hồ sơ',reason:'Giữ các điều kiện chưa xác định.',done_when:'Có bộ câu hỏi và hồ sơ nhờ chuyên gia rà.',evidence_ids:[]}
 ]});return a;
}
function render(a=canonical(),context={}){const h=R.harness();const root=h.renderArtifact(a,{onPrepareStep(){},onSaveTask(){},...context});return{h,root};}
function childIndex(parent,node){return parent.children.indexOf(node);}
function hasClosedAncestor(node){for(let n=node.parentNode;n;n=n.parentNode)if(n.tagName==='DETAILS'&&!n.open)return true;return false;}
test('Embedded report leads with one stored sentence and visible evidence limit before all three actions',()=>{
 const a=canonical(),{h}=render(a),result=h.get('result');
 assert.equal(h.get('summary-brief').textContent,'Nguồn hiện có chưa đủ để chốt điều kiện của lô hàng.');
 assert.equal(h.get('summary').textContent,a.report.summary);assert.equal(h.get('summary').parentNode.open,false);
 assert.match(h.get('report-brief-limit').textContent,/Nguồn chưa đủ.*chưa xác nhận tuân thủ/);
 assert.equal(h.get('report-brief-limit').hidden,false);assert.equal(hasClosedAncestor(h.get('report-brief-limit')),false);
 assert.ok(childIndex(result,h.get('summary-brief'))<childIndex(result,h.get('source-coverage')));
 assert.ok(childIndex(result,h.get('source-coverage'))<childIndex(result,h.get('report-brief-limit')));
 assert.ok(childIndex(result,h.get('report-brief-limit'))<childIndex(result,h.get('panel-next')));
 assert.deepEqual(Array.from(h.get('panel-next').children,node=>node.dataset.stepId),a.report.next_steps.map(step=>step.id));
 assert.equal(h.calls.length,0);
});
test('Long first sentence is an exact word boundary excerpt; complete stored assessment remains available',()=>{
 const full=('Dữ kiện cần được chuyên gia đối chiếu trước khi quyết định '.repeat(7)).trim()+'. Giới hạn bổ sung cần được đọc đầy đủ.';
 const {h}=render(canonical(full)),preview=h.get('summary-brief').textContent,prefix=preview.slice(0,-1);
 assert.ok(preview.length<=151);assert.match(preview,/…$/);assert.equal(full.slice(0,prefix.length),prefix);assert.equal(full[prefix.length],' ');
 assert.equal(h.get('summary').textContent,full);assert.equal(h.get('summary').parentNode.open,false);assert.equal(h.calls.length,0);
});
test('Mobile evidence limit survives a positive opening sentence and every stored readiness status',()=>{
 for(const status of ['preparation_only','needs_information','needs_specialist','evidence_incomplete','unsupported_scope','unrecognised_status']){
  const a=canonical('Có thể bắt đầu chuẩn bị. Tuy vậy, điều kiện riêng chưa được xác minh.');a.report.readiness_status=status;
  const {h}=render(a);assert.equal(h.get('summary-brief').textContent,'Có thể bắt đầu chuẩn bị.');assert.match(h.get('report-brief-limit').textContent,/chưa xác nhận tuân thủ/);
  assert.equal(h.get('readiness-status').textContent,status==='unrecognised_status'?'Cần đối chiếu trạng thái':({preparation_only:'Chỉ hỗ trợ chuẩn bị',needs_information:'Cần bổ sung thông tin',needs_specialist:'Cần chuyên gia xác định',evidence_incomplete:'Nguồn bằng chứng chưa đầy đủ',unsupported_scope:'Ngoài phạm vi đang hỗ trợ'})[status]);
  assert.equal(h.calls.length,0);
 }
});
test('Glossary and provenance are discoverable after actions with complete definitions inside closed details',()=>{
 const {h}=render(),result=h.get('result'),glossary=h.get('report-terms'),badges=h.get('result-badges');
 assert.ok(childIndex(result,h.get('panel-next'))<childIndex(result,glossary));assert.equal(glossary.open,false);
 assert.equal(glossary.children[0].textContent,'Giải nghĩa IOR, FSVP, Incoterm');assert.match(glossary.textContent,/Đơn vị đứng tên nhập khẩu/);assert.match(glossary.textContent,/phụ trách xác minh/);assert.match(glossary.textContent,/ai chịu chi phí và rủi ro/);
 assert.equal(hasClosedAncestor(badges),true);assert.equal(badges.parentNode,h.get('artifact-meta').parentNode);
 assert.match(badges.textContent,/Bản nháp.*chuyên gia/);assert.match(h.get('artifact-meta').textContent,/MOCK-ART-A/);assert.equal(h.calls.length,0);
});
test('First action precedes its full expected outcome; callbacks retain canonical step IDs and immutable report',async()=>{
 const a=canonical(),original=JSON.stringify(a),prepared=[],saved=[],{h}=render(a,{onPrepareStep:id=>prepared.push(id),onSaveTask:id=>saved.push(id)});
 for(const [index,card] of h.get('panel-next').children.entries()){
  const content=byClass(card,'step-content'),prepare=byClass(card,'step-prepare-button'),expected=byClass(card,'step-expected');
  assert.ok(childIndex(content,prepare)<childIndex(content,expected));assert.equal(expected.textContent,'Kết quả: '+a.report.next_steps[index].done_when);
  await prepare.emit('click');await byClass(card,'step-save-button').emit('click');
 }
 assert.deepEqual(prepared,a.report.next_steps.map(step=>step.id));assert.deepEqual(saved,a.report.next_steps.map(step=>step.id));
 assert.equal(JSON.stringify(a),original);assert.equal(h.calls.length,0);
});
test('Legacy reports keep full content and receive no invented mobile execution actions',()=>{
 const a=canonical();delete a.report.next_steps_policy_version;const {h,root}=render(a);
 assert.match(h.get('summary-brief').textContent,/Bản cũ được giữ nguyên/);assert.equal(h.get('summary').textContent,a.report.summary);
 assert.equal(h.get('legacy-label').hidden,false);assert.equal(byClass(root,'step-prepare-button'),null);assert.equal(byClass(root,'step-save-button'),null);assert.equal(h.calls.length,0);
});
