/* Real renderers/templates, synthetic evidence and controlled DOM/transports.
 * No HTTP, provider SDK, credentials, browser automation or paid model calls. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
function load(file,names){const filename=path.join(__dirname,file),localRequire=createRequire(filename),sandbox={require:id=>id==='node:test'?{test(){}}:localRequire(id),__dirname,__filename:filename,console:{log(){},error:console.error},URL,Blob,setImmediate};vm.runInNewContext(fs.readFileSync(filename,'utf8')+'\nglobalThis.helpers={'+names.join(',')+'};',sandbox,{filename});return sandbox.helpers;}
const R=load('live-research-regression.cjs',['harness','artifactData','runData','settle']);
const A=load('assistant-regression.cjs',['harness','savedConversation','openSaved','openReport','settle','Element']);
const plain=value=>JSON.parse(JSON.stringify(value));
const byClass=(root,name)=>root.all().find(node=>node.className.split(/\s+/).includes(name))||null;
function visible(node){if(node.hidden)return '';if(node.tagName==='DETAILS'&&!node.open)return visible(node.children.find(child=>child.tagName==='SUMMARY'));return(node._text||'')+' '+node.children.map(visible).join(' ');}
const actionCases=[
 ['clarify_facility_registration','Rà thông tin đăng ký cơ sở','Rà thông tin của cơ sở thực phẩm',/sản xuất\/chế biến\/đóng gói\/lưu giữ/],
 ['prepare_food_label','Chuẩn bị nội dung nhãn','Chuẩn bị nội dung nhãn để rà',/tên thực phẩm, lượng tịnh, thành phần/],
 ['prepare_prior_notice','Chuẩn bị thông báo trước','Phiếu chuẩn bị thông báo trước',/người dự kiến nộp, phương thức vận chuyển, lịch đến/],
 ['clarify_certification_requirements','Làm rõ chứng nhận cần hỏi','Làm rõ chứng nhận cần đối chiếu',/tên chứng nhận, bên yêu cầu/],
];
function topicArtifact(){const a=R.artifactData();a.run_id='MOCK-RUN-A';a.content_sha256='IMMUTABLE-TOPIC-REPORT';Object.assign(a.report,{summary:'Bản giả lập đối chiếu riêng câu hỏi. FSVP và Incoterm được giải nghĩa dưới phần trả lời.',summary_kind:'assessment',summary_origin:'model',next_steps_policy_version:'0.2.3',next_steps:actionCases.slice(0,3).map(([id,title])=>({id,title,reason:'Lý do giả lập riêng của '+id,done_when:'Ghi nhận điều đã có căn cứ và phần còn thiếu.',evidence_ids:['TEST-EV-A']})),topic_answers:[
 {topic:'facility_registration',title:'Đăng ký cơ sở — dữ liệu kiểm thử',answer:'CÂU TRẢ LỜI ĐẦY ĐỦ GIẢ LẬP A. '+('Mỗi điều kiện cần được đối chiếu riêng với hoạt động cơ sở. '.repeat(12))+'KẾT THÚC A.',coverage:'available',evidence_ids:['TEST-EV-A']},
 {topic:'label',title:'Nhãn — dữ liệu kiểm thử',answer:'CÂU TRẢ LỜI GIẢ LẬP B. Nguồn mới bao phủ một phần; còn thiếu thông tin áp dụng.',coverage:'partial',evidence_ids:['TEST-EV-B']},
 {topic:'prior_notice',title:'Thông báo trước — dữ liệu kiểm thử',answer:'CÂU TRẢ LỜI GIẢ LẬP C. Chưa có đoạn nguồn phù hợp nên chưa kết luận.',coverage:'unavailable',evidence_ids:[]},
 ],evidence:['A','B'].map(id=>({id:'TEST-EV-'+id,url:'https://www.fda.gov/TEST-'+id,title:'Original test title '+id,publisher:'Original test publisher',excerpt:'Synthetic English excerpt '+id,source_date:'Content current as of: January 2, 2025',accessed_at:'2026-10-18T00:00:00Z',content_sha256:'TEST-EV-HASH-'+id,locator:'TEST-'+id,title_vi:'Tiêu đề giả lập '+id,publisher_vi:'Đơn vị giả lập',excerpt_vi:'Trích đoạn tiếng Việt giả lập '+id,translation:{status:'draft_reference',language:'vi',method:'reference_catalog',original_excerpt_sha256:'TEST-EXCERPT-'+id,note:'Bản dịch giả lập để kiểm thử.'}}))});return a;}

test('Topic disclosure retains every full answer, coverage and source reference without replacing the stored assessment',()=>{
 const a=topicArtifact(),before=JSON.stringify(a),h=R.harness();h.renderArtifact(a);const section=h.get('topic-answers');assert.equal(section.hidden,false);assert.equal(section.open,false);assert.equal(section.children[0].textContent,'Trả lời từng ý trong câu hỏi · 3');assert.equal(h.get('result-title').textContent,'Mình trả lời theo câu hỏi của bạn.');
 const answers=section.all().filter(node=>node.className==='topic-answer');assert.equal(answers.length,3);section.open=true;
 for(const [index,row]of answers.entries()){assert.equal(row.dataset.topic,a.report.topic_answers[index].topic);assert.equal(byClass(row,'topic-answer-text').textContent,a.report.topic_answers[index].answer);assert.match(visible(row),new RegExp(a.report.topic_answers[index].title));}
 assert.equal(byClass(answers[0],'topic-coverage').textContent,'Có nguồn về nguyên tắc');assert.equal(byClass(answers[1],'topic-coverage').textContent,'Nguồn mới trả lời một phần');assert.equal(byClass(answers[2],'topic-coverage').textContent,'Chưa đủ nguồn');assert.equal(answers[2].all().filter(node=>node.tagName==='BUTTON').length,0);
 assert.equal(h.get('summary').textContent,a.report.summary);assert.equal(JSON.stringify(a),before);assert.equal(h.calls.length,0);
});

test('Topic source buttons open and anchor their exact stored evidence without a new request',async()=>{
 const h=R.harness();h.renderArtifact(topicArtifact());h.get('topic-answers').open=true;
 const answers=h.get('topic-answers').all().filter(node=>node.className==='topic-answer');for(const [index,id]of ['A','B'].entries()){const button=answers[index].all().find(node=>node.tagName==='BUTTON');assert.equal(button.textContent,'Xem căn cứ 1');await button.emit('click');assert.equal(h.get('detail-sources').open,true);assert.ok(h.get('evidence-TEST-EV-'+id).scrollCalls.some(call=>call.block==='start'));}
 assert.equal(h.calls.length,0);
});

test('No topic answers means no invented topic or coverage claims in an older report',()=>{
 const a=topicArtifact();delete a.report.topic_answers;const h=R.harness();h.renderArtifact(a);assert.equal(h.get('topic-answers').hidden,true);assert.equal(h.get('topic-answers').all().filter(node=>node.className==='topic-answer').length,0);assert.equal(h.get('summary').textContent,a.report.summary);assert.equal(h.calls.length,0);
});

test('Untrusted topic title and answer remain literal text and cannot create active HTML',()=>{
 const a=topicArtifact(),attack='<img src=x onerror="TEST_ATTACK()"><script>TEST_ATTACK()</script>';a.report.topic_answers[0].title=attack;a.report.topic_answers[0].answer=attack;const h=R.harness();h.renderArtifact(a);const section=h.get('topic-answers');section.open=true;assert.match(visible(section),/<img src=x onerror=/);assert.match(visible(section),/<script>TEST_ATTACK/);assert.equal(section.all().some(node=>node.tagName==='IMG'||node.tagName==='SCRIPT'),false);assert.equal(h.calls.length,0);
});

test('Glossary follows the summary and actions in embedded mode instead of impersonating the opening answer',()=>{
 const h=R.harness();h.renderArtifact(topicArtifact());const result=h.get('result'),guide=h.get('report-terms');assert.equal(guide.hidden,false);assert.equal(guide.open,false);assert.ok(result.children.indexOf(h.get('summary-brief'))<result.children.indexOf(guide));assert.ok(result.children.indexOf(h.get('panel-next'))<result.children.indexOf(guide));assert.ok(result.children.indexOf(h.get('topic-answers'))<result.children.indexOf(guide));assert.match(guide.textContent,/FSVP/);assert.equal(h.calls.length,0);
});

test('Glossary also follows the summary in the standalone report using only controlled mock transport',async()=>{
 const a=topicArtifact(),h=R.harness((url,opts,normal)=>{if(url==='/api/mcp/call'&&JSON.parse(opts.body).name==='nmate_artifact_get')return{ok:true,data:a};return normal(url,opts);});h.setRun(R.runData('succeeded'));h.mount();await R.settle();await h.submit();await R.settle();const result=h.get('result'),guide=h.get('report-terms');assert.equal(guide.hidden,false);assert.equal(guide.open,false);assert.ok(result.children.indexOf(h.get('summary-brief'))<result.children.indexOf(guide));assert.ok(result.children.indexOf(h.get('topic-answers'))<result.children.indexOf(guide));assert.equal(h.calls.filter(call=>call.body?.name==='nmate_shipment_readiness_start').length,1);
});

test('English FDA date prefixes become Vietnamese day/month/year outside the preserved original',()=>{
 const a=topicArtifact(),h=R.harness();h.renderArtifact(a);h.get('detail-sources').open=true;const card=h.get('evidence-TEST-EV-A'),audit=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Thông tin đối chiếu nguồn'),original=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Xem nguyên văn tiếng Anh');assert.ok(audit&&original);audit.open=true;assert.match(visible(card),/Ngày nguồn: 02\/01\/2025/);assert.doesNotMatch(visible(card),/Content current as of|January/);assert.equal(original.open,false);original.open=true;assert.match(visible(card),/Content current as of: January 2, 2025/);assert.equal(a.report.evidence[0].source_date,'Content current as of: January 2, 2025');assert.equal(h.calls.length,0);
});

test('An unparseable source date gets a Vietnamese fallback while exact English stays inside original details',()=>{
 const a=topicArtifact();a.report.evidence[0].source_date='TEST Unparseable English Source Date';const h=R.harness();h.renderArtifact(a);h.get('detail-sources').open=true;const card=h.get('evidence-TEST-EV-A');const audit=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Thông tin đối chiếu nguồn'),original=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Xem nguyên văn tiếng Anh');audit.open=true;assert.match(visible(card),/Ngày nguồn: Chưa xác định ngày/);assert.doesNotMatch(visible(card),/TEST Unparseable English Source Date/);original.open=true;assert.match(visible(card),/TEST Unparseable English Source Date/);assert.equal(h.calls.length,0);
});

test('Observed FDA Drupal weekday and US numeric source date becomes 05/11/2018 with exact original preserved',()=>{
 const a=topicArtifact(),raw='Mon, 11/05/2018 - 00:00';a.report.evidence[0].source_date=raw;const h=R.harness();h.renderArtifact(a);h.get('detail-sources').open=true;const card=h.get('evidence-TEST-EV-A'),audit=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Thông tin đối chiếu nguồn'),original=card.children.find(node=>node.tagName==='DETAILS'&&node.children[0]?.textContent==='Xem nguyên văn tiếng Anh');audit.open=true;assert.match(visible(card),/Ngày nguồn: 05\/11\/2018/);assert.doesNotMatch(visible(card),/Mon,|Chưa xác định ngày/);assert.equal(original.open,false);original.open=true;assert.match(visible(card),/Mon, 11\/05\/2018 - 00:00/);assert.equal(a.report.evidence[0].source_date,raw);assert.equal(h.calls.length,0);
});

test('Coverage distinguishes fourteen evidence excerpts from eight unique source pages',()=>{
 const a=topicArtifact(),base=a.report.evidence[0];a.report.evidence=Array.from({length:14},(_,index)=>({...plain(base),id:index===0?'TEST-EV-A':index===1?'TEST-EV-B':'TEST-CHUNK-'+index,url:'https://www.fda.gov/TEST-PAGE-'+(index%8)}));a.report.source_failures=[{source_id:'TEST-BLOCKED',code:'HTTP_403',detail:'TEST unavailable',url:'https://www.cbp.gov/TEST'}];
 const h=R.harness();h.renderArtifact(a);assert.equal(h.get('source-coverage').textContent,'14 đoạn căn cứ · 8 trang nguồn · 1 nguồn chưa đọc');assert.match(h.get('report-status').textContent,/14 đoạn căn cứ được lấy/);assert.doesNotMatch(h.get('source-coverage').textContent,/14 nguồn/);assert.equal(h.calls.length,0);
});

for(const supplied of [false,true])test('A legacy compact UUID reference is hidden unless grounded as the actual user SKU: '+supplied,async()=>{
 const c=A.savedConversation();c.conversation_id='a1b2c3d4-e5f6-4789-9012-aabbccddeeff';const compact='REF-'+c.conversation_id.replaceAll('-','').slice(0,12).toUpperCase();assert.notEqual(compact,'REF-'+c.conversation_id.slice(0,12).toUpperCase());c.research_links[0].product_summary.sku=compact;
 if(supplied){c.draft.product.sku=compact;c.draft.field_sources['product.sku']={source_quote:'SKU tôi cung cấp là '+compact,certainty:'provided',confirmed:true};}
 let saved;const h=A.harness({conversation:c,saveDraft:value=>(saved=plain(value),{id:'LOCAL-COMPACT-SKU'}),fetch(url,opts,normal){if(url==='/api/conversations/'+c.conversation_id&&!opts.method)return plain(c);return normal(url,opts);}});await A.openSaved(h);await A.openReport(h);const before=h.calls.length;h.renders[0].context.onPrepareStep('clarify_import_roles',null);await A.settle();assert.equal(h.get('a-draft-preview').textContent.includes(compact),supplied);assert.match(h.get('a-inline-action').textContent,new RegExp(supplied?'Mã sản phẩm trong hồ sơ:':'Mã tham chiếu nội bộ, tự tạo:'));await h.get('a-draft-save').emit('click');assert.equal(saved.product.sku,compact);assert.equal(saved.artifact.artifact_id,'ART-TEA');assert.equal(h.calls.length,before);
});

for(const [id,label,title,bodyPattern]of actionCases)test('Question-specific action keeps its canonical ID and exact draft/reference: '+id,async()=>{
 const report=topicArtifact();report.report.next_steps=[{id,title:'Việc giả lập '+id,reason:'Lý do và nguồn đúng việc '+id,done_when:'Ghi điều đã có nguồn và còn thiếu.',evidence_ids:['TEST-EV-A']}];const prepared=[],saved=[],renderer=R.harness();renderer.renderArtifact(report,{onPrepareStep:step=>prepared.push(step),onSaveTask:step=>saved.push(step)});const action=byClass(renderer.element,'step-prepare-button');assert.equal(action.textContent,label);await action.emit('click');assert.deepEqual(prepared,[id]);assert.equal(renderer.calls.length,0);
 const c=A.savedConversation();c.draft.product.name='DỮ KIỆN MỚI CHƯA NGHIÊN CỨU';let draft;const h=A.harness({conversation:c,saveDraft:value=>(draft=plain(value),{id:'LOCAL-DRAFT'}),fetch(url,opts,normal){if(url==='/api/mcp/call'&&JSON.parse(opts.body).name==='nmate_artifact_get'){const a=plain(report);Object.assign(a,{artifact_id:'ART-TEA',case_id:'CASE-TEA',run_id:'RUN-TEA',profile_version:1});return{ok:true,data:a};}return normal(url,opts);}});await A.openSaved(h);await A.openReport(h);const context=h.renders[0].context,trigger=new A.Element('button');h.get('a-timeline').append(trigger);const before=h.calls.length;context.onPrepareStep(id,trigger);await A.settle();assert.equal(h.get('a-inline-action').dataset.stepId,id);assert.match(h.get('a-draft-preview').textContent,new RegExp(title));assert.match(h.get('a-draft-preview').textContent,bodyPattern);assert.match(h.get('a-draft-preview').textContent,/Trà sen 100 g/);assert.doesNotMatch(h.get('a-draft-preview').textContent,/DỮ KIỆN MỚI CHƯA NGHIÊN CỨU/);assert.match(h.get('a-inline-action').textContent,/Lý do và nguồn đúng việc/);await h.get('a-draft-save').emit('click');assert.equal(draft.step_id,id);assert.equal(draft.artifact.artifact_id,'ART-TEA');assert.equal(draft.artifact.content_sha256,'IMMUTABLE-TOPIC-REPORT');assert.deepEqual(draft.artifact.report.next_steps[0].evidence_ids,['TEST-EV-A']);assert.equal(draft.product.name,'Trà sen 100 g');assert.equal(draft.question,c.research_links[0].question);assert.equal(h.calls.length,before);
});
