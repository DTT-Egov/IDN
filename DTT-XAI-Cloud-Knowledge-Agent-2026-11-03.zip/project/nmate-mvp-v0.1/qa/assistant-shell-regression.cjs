'use strict';
// Executes the real application in the existing in-memory DOM harness.
// Checks persistence, routing and local artifact actions; no browser or API calls.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {createHash}=require('node:crypto');
const root=path.resolve(__dirname,'..');
const original=fs.readFileSync(path.join(__dirname,'regression-tests.mjs'),'utf8');
const start=original.indexOf('const files = '),end=original.indexOf('\nfunction test(',start);
assert.ok(start>=0&&end>start,'Review the harness adapter boundary.');
const loader={fs,path,vm,createHash,root,console,URL,Blob};
const harnessSource=original.slice(start,end).replace('function harness() {',"function harness(initialHash = '') {").replace("location: { hash: '' }",'location: { hash: initialHash }');
vm.runInNewContext(harnessSource+'\nglobalThis.makeHarness=harness;',loader,{timeout:5000});
function harness(...args){const h=loader.makeHarness(...args);h.api.setAssistantIdentity('BROWSER-TEST-001');return h;}
const plain=value=>JSON.parse(JSON.stringify(value));
let count=0;
function test(name,fn){fn();count++;console.log('PASS '+name);}
function input(){return {artifact:{artifact_id:'11111111-1111-4111-8111-111111111111',run_id:'22222222-2222-4222-8222-222222222222',case_id:'33333333-3333-4333-8333-333333333333',profile_version:1,content_sha256:'a'.repeat(64),report:{summary:'TEST: nguồn hiện có chưa đủ cho kết luận nhãn.',next_steps:[{id:'clarify_import_roles',title:'Xác nhận riêng vai trò nhập khẩu và FSVP',reason:'TEST: hai vai riêng.'},{id:'clarify_delivery_terms',title:'Làm rõ điều kiện giao hàng (Incoterm)',reason:'TEST: cần điểm giao và trách nhiệm.'},{id:'expert_preparation_review',title:'Nhờ chuyên gia rà đúng câu hỏi và hồ sơ',reason:'TEST: cần rà nguồn cho ca cụ thể.'}]}},question:'TEST: trà sen cần FDA và nhãn thế nào?',product:{sku:'REF-TEST',name:'Trà sen THỬ NGHIỆM'}};}

test('Assistant is the default and owns exactly three primary destinations',()=>{
 const h=harness();assert.equal(h.api.view,'assistant');assert.match(h.html,/id="assistant-root"/);
 assert.equal((h.html.match(/data-go="assistant(?:-journey|-documents)?"/g)||[]).length,3);
 assert.doesNotMatch(h.html,/Trợ lý mô phỏng|role-select|demo-strip|quick-chat/);
});
test('Old primary entry links reach the real assistant',()=>{
 const h=harness();for(const route of ['dashboard','advisor','research-live']){h.go(route);assert.equal(h.api.view,'assistant');assert.doesNotMatch(h.html,/research-form|quick-chat/);}
 h.go('assistant-journey');assert.equal(h.api.view,'assistant-journey');h.go('assistant-documents');assert.equal(h.api.view,'assistant-documents');
});
test('Mount receives the selected tab and local actions never remount a pending turn',()=>{
 const h=harness();let mounts=0,tab='';h.context.NMateAssistant={unmount(){},mount(_root,opts){mounts++;tab=opts.tab;}};
 h.go('assistant-journey');assert.equal(tab,'journey');const before=mounts;
 h.api.setAssistantStorageConsent(true);h.api.saveResearchTask({...input(),step_id:'clarify_delivery_terms',owner:'Chủ cơ sở TEST',due_date:'2026-10-19'});
 h.api.saveResearchDraft({...input(),body:'TEST bản nháp tự gửi, chưa liên hệ ai.'});assert.equal(mounts,before);
});
test('Storage withdrawal blocks every local artifact write without granting consent',()=>{
 const h=harness();h.api.setAssistantStorageConsent(false);const before=JSON.stringify(h.state);
 assert.throws(()=>h.api.saveResearchTask({...input(),step_id:'clarify_delivery_terms',owner:'TEST',due_date:'2026-10-19'}),/lưu dữ liệu/);
 assert.throws(()=>h.api.saveResearchDraft({...input(),body:'TEST'}),/lưu dữ liệu/);assert.equal(JSON.stringify(h.state),before);
});
test('Only canonical steps can create a local task; duplicates and completion stay unchanged',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);const source=input(),originalInput=JSON.stringify(source),done=h.state.tasks.filter(x=>x.status==='done').length;
 const args={...source,step_id:'clarify_delivery_terms',title:'UNTRUSTED alternative',owner:'Chủ cơ sở TEST',due_date:'2026-10-19'};
 const first=h.api.saveResearchTask(args),second=h.api.saveResearchTask(args);
 assert.equal(first.id,second.id);assert.equal(first.title,source.artifact.report.next_steps[1].title);assert.equal(first.status,'todo');assert.equal(first.deliveryStatus,'not_sent');assert.equal(first.localOnly,true);
 assert.equal(h.api.getLocalResearchItems().tasks.length,1);assert.equal(h.state.tasks.filter(x=>x.status==='done').length,done);assert.equal(JSON.stringify(source),originalInput);
 assert.throws(()=>h.api.saveResearchTask({...args,step_id:'unknown'}),/không thuộc/);
});
test('Malformed and stale artifact inputs fail before changing browser state',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);const source=input(),before=JSON.stringify(h.state);
 for(const patch of [{artifact_id:'fake'},{content_sha256:''},{stale:true},{profile_version:0}])assert.throws(()=>h.api.saveResearchDraft({...source,artifact:{...source.artifact,...patch},body:'TEST'}));
 assert.equal(JSON.stringify(h.state),before);
});
test('Invalid calendar dates and overlong owner cannot create a misleading task',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);const before=JSON.stringify(h.state);
 for(const [owner,due_date] of [['TEST','2026-02-30'],['TEST','2026-13-01'],['x'.repeat(201),'2026-10-19']])assert.throws(()=>h.api.saveResearchTask({...input(),step_id:'clarify_delivery_terms',owner,due_date}));
 assert.equal(JSON.stringify(h.state),before);
});

test('Saving a canonical task for myself needs no owner or due date and still deduplicates',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);
 const first=h.api.saveResearchTask({...input(),step_id:'clarify_delivery_terms'});
 assert.equal(first.owner,'Mình');assert.equal(first.due,'');assert.equal(first.status,'todo');assert.equal(first.deliveryStatus,'not_sent');
 const again=h.api.saveResearchTask({...input(),step_id:'clarify_delivery_terms',owner:'Tôi',due_date:''});
 assert.equal(again.id,first.id);assert.equal(h.api.getLocalResearchItems().tasks.length,1);
});
test('Draft keeps user text and immutable research reference with truthful unsent status',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);const source=input(),body='TEST: ghi chú do chủ cơ sở sửa.\nTôi tự chọn người nhận.';
 const draft=h.api.saveResearchDraft({...source,body,title:'Nhờ rà trà sen TEST'});
 assert.equal(draft.body,body);assert.equal(draft.recipient,'');assert.equal(draft.deliveryStatus,'not_sent');assert.equal(draft.status,'local_draft');assert.equal(draft.consent,false);
 assert.deepEqual(plain(draft.source.next_steps),source.artifact.report.next_steps);assert.equal(draft.source.question,source.question);
 const exported=h.api.getExpertDraftText(draft.id);assert.match(exported,/CHƯA GỬI/);assert.ok(exported.includes(body));assert.ok(exported.includes(source.artifact.artifact_id));
});
test('Returned local records are copies and cannot silently alter stored facts',()=>{
 const h=harness();h.api.setAssistantStorageConsent(true);h.api.saveResearchDraft({...input(),body:'TEST'});const items=h.api.getLocalResearchItems();items.drafts[0].source.next_steps[0].title='changed';
 assert.notEqual(h.api.getLocalResearchItems().drafts[0].source.next_steps[0].title,'changed');assert.throws(()=>h.api.setAssistantStorageConsent('true'),/chưa hợp lệ/);
});

test('Every retired direct route resolves only to the assistant, including reload and unknown hashes',()=>{const h=harness();for(const route of ['profile','checklist','logistics','experts','research-legacy','settings','welcome','cases','unknown']){h.go(route);assert.equal(h.api.view,'assistant',route);assert.match(h.html,/id="assistant-root"/);assert.doesNotMatch(h.html,/profile-form|checklist-form|logistics-form|role-select/);}});
test('Local items cannot be read across browser identities and legacy state is never imported',()=>{const h=harness();h.api.setAssistantStorageConsent(true);h.api.saveResearchDraft({...input(),body:'PRIVATE BROWSER ONE'});assert.equal(h.api.getLocalResearchItems().drafts.length,1);h.api.setAssistantIdentity('BROWSER-OTHER-002');assert.equal(h.api.getLocalResearchItems().drafts.length,0);h.api.setAssistantStorageConsent(true);h.api.saveResearchDraft({...input(),body:'PRIVATE BROWSER TWO'});assert.equal(h.api.getLocalResearchItems().drafts[0].body,'PRIVATE BROWSER TWO');h.api.setAssistantIdentity('BROWSER-TEST-001');assert.equal(h.api.getLocalResearchItems().drafts.length,1);assert.equal(h.api.getLocalResearchItems().drafts[0].body,'PRIVATE BROWSER ONE');});
test('Initial URLs and a fresh reload of retired routes normalize before any old screen can mount',()=>{for(const route of ['profile','checklist','logistics','experts','expert-case','cases','research-legacy']){const first=harness('#'+route),reloaded=harness('#'+route);for(const h of [first,reloaded]){assert.equal(h.api.view,'assistant',route);assert.match(h.html,/id="assistant-root"/);assert.doesNotMatch(h.html,/profile-form|logistics-form|checklist-form|role-select/);}}});
console.log(count+'/'+count+' assistant shell and local action groups passed.');
