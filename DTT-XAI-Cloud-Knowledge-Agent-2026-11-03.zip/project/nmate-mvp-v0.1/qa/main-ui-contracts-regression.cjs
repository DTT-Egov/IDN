const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ui=require('../src/main-ui-contracts.js');
const owner={account_id:'owner-a',enterprise_id:'enterprise-a'};
const clone=value=>JSON.parse(JSON.stringify(value));
const workspace={id:'intake-a',workspace_contract:{schema_version:'workspace-contract/1',projection_only:true,
  scope:{account_id:'owner-a',enterprise_id:'enterprise-a',workspace_id:'intake-a',resource_kind:'intake'}}};

test('HTML loads the shared components before the main application',()=>{
  const html=fs.readFileSync(path.join(__dirname,'../main.html'),'utf8');
  assert.ok(html.indexOf('src/main-ui-contracts.js')>=0);
  assert.ok(html.indexOf('src/main-ui-contracts.js')<html.indexOf('src/main-app.js'));
});

for(const [key,value] of [['account_id','other-owner'],['enterprise_id','other-enterprise'],['workspace_id','other-intake'],['resource_kind','policy']]){
  test('Rejects contract for another '+key,()=>{
    const wrong=clone(workspace);wrong.workspace_contract.scope[key]=value;
    assert.equal(ui.workspaceContract(wrong,owner,'intake'),null);
    assert.equal(ui.workspaceContract(workspace,owner,'intake'),workspace.workspace_contract);
  });
}

test('A projection flag cannot become mutation authority',()=>{
  const wrong=clone(workspace);wrong.workspace_contract.projection_only=false;
  assert.equal(ui.workspaceContract(wrong,owner,'intake'),null);
  assert.equal(ui.workspaceContract({id:'old-no-contract'},owner,'intake'),null);
});

const plan={schema_version:'intent-plan/1',intent:{goals:[{id:'label',title_vi:'Nhãn cho Mỹ',requirement_ids:['label']}],exclusions:['prior_notice']},
  requirements:[{id:'label',source_status:'needs_source',missing_inputs:['ingredients']}],
  first_actions:[{title_vi:'Gom công thức và dữ kiện nhãn',deliverable_vi:'Một bản nháp nhãn chưa duyệt để in',acceptance_vi:'Đối chiếu công thức và lượng tịnh thực tế'}]};

test('Plan is collapsed, names the actual goal and has a concrete deliverable/acceptance',()=>{
  const markup=ui.planView({intent_plan:plan},{id:'plan-a',current:true});
  assert.match(markup,/Mục tiêu &amp; việc cần làm/);
  assert.match(markup,/Nhãn cho Mỹ/);
  assert.match(markup,/Còn thiếu căn cứ/);
  assert.match(markup,/Đầu ra: Một bản nháp nhãn/);
  assert.match(markup,/Xong khi: Đối chiếu công thức/);
  assert.match(markup,/Thông báo trước lô hàng/);
  assert.doesNotMatch(markup,/<details[^>]+\bopen(?:\s|>)/);
  assert.doesNotMatch(markup,/data-v04=|prior_notice|Bắt đầu nghiên cứu/);
});

test('Product names, source titles and action text never inject HTML',()=>{
  const malicious=clone(plan);malicious.intent.goals[0].title_vi='<img src=x onerror=alert(1)>';
  malicious.first_actions[0].deliverable_vi='</p><script>alert(1)</script>';
  const markup=ui.planView({intent_plan:malicious},{id:'bad" onfocus="x'});
  assert.doesNotMatch(markup,/<img|<script|id="bad" onfocus/);
  assert.match(markup,/&lt;img/);assert.match(markup,/&lt;script/);
});

test('Unsupported/empty intent asks for clarification and does not invent tasks',()=>{
  const empty=clone(plan);empty.intent.goals=[];empty.first_actions=[];
  assert.match(ui.planView({intent_plan:empty}),/Chưa đủ thông tin/);
  assert.doesNotMatch(ui.planView({intent_plan:empty}),/Xong khi/);
  assert.equal(ui.planView({intent_plan:{schema_version:'unknown'}}),'');
});

test('Action plan rendering does not mutate current or historical data',()=>{
  const value={intent_plan:clone(plan)},before=clone(value);
  ui.planView(value);ui.planView(value);assert.deepEqual(value,before);
});

test('A short action list explains the unmet count outside the collapsed plan',()=>{
  const partial=clone(plan);partial.delivery={schema_version:'plan-delivery/1',requested_count:3,prepared_count:1,missing_count:2,status:'partial',reason_vi:'Chị yêu cầu 3 việc; hiện mới chuẩn bị được 1 việc cụ thể, còn thiếu 2.'};
  const before=clone(partial),markup=ui.planView({intent_plan:partial});
  assert.match(markup,/<p[^>]*role="status"[^>]*>Chị yêu cầu 3 việc/);
  assert.ok(markup.indexOf('còn thiếu 2')<markup.indexOf('<details'));
  assert.doesNotMatch(markup,/data-v04=|Bắt đầu nghiên cứu/);
  assert.equal((markup.match(/<li><strong>/g)||[]).length,2); // one goal, one actual action
  assert.deepEqual(partial,before);
});

test('Delivery guidance is escaped and cannot add executable actions',()=>{
  const partial=clone(plan);partial.delivery={schema_version:'plan-delivery/1',requested_count:3,prepared_count:1,missing_count:2,status:'partial',reason_vi:'<script>send()</script>'};
  const markup=ui.planView({intent_plan:partial});
  assert.match(markup,/&lt;script&gt;send/);assert.doesNotMatch(markup,/<script/);
});

test('Inconsistent delivery counters cannot claim a count or completion',()=>{
  for(const mutation of [{prepared_count:2},{missing_count:0},{requested_count:'3'},{schema_version:'unknown'},{status:'ready'}]){
    const partial=clone(plan);partial.delivery={schema_version:'plan-delivery/1',requested_count:3,prepared_count:1,missing_count:2,status:'partial',reason_vi:'COUNT_NOTICE',...mutation};
    assert.doesNotMatch(ui.planView({intent_plan:partial}),/COUNT_NOTICE/);
  }
});

test('A current complete count clears the old shortfall without claiming research finished',()=>{
  const complete=clone(plan);complete.first_actions=[...complete.first_actions,...clone(complete.first_actions),...clone(complete.first_actions)];
  complete.delivery={schema_version:'plan-delivery/1',requested_count:3,prepared_count:3,missing_count:0,status:'ready',reason_vi:'COUNT_NOTICE'};
  const markup=ui.planView({intent_plan:complete});assert.doesNotMatch(markup,/COUNT_NOTICE/);
  assert.match(markup,/Đây là kế hoạch chuẩn bị; chưa tự thực hiện/);
});

test('Reversed resource replies cannot roll back revisions or labels',()=>{
  const current={id:'mission-a',version:3,label:{id:'label-a',version:4}};
  const event={expectedScope:'actor|enterprise|work',currentScope:'actor|enterprise|work',requestEpoch:2,currentEpoch:2};
  for(const incoming of [{id:'mission-a',version:2},{id:'mission-a',version:3,label:{id:'label-a',version:3}}]){
    assert.equal(ui.resourceSnapshotReducer(current,{...event,value:incoming}),current);
  }
  assert.equal(ui.resourceSnapshotReducer(current,{...event,requestEpoch:1,value:{id:'mission-b'}}),current);
});

test('Review snapshot and current context use independent monotonic revisions',()=>{
  const current={id:'intake-a',review:{schema_version:'workspace-review/2',workspace_id:'intake-a',revision:5,proposal_hashes:{}}};
  const event={type:'WorkspaceLoaded',expectedScope:'scope-a',currentScope:'scope-a',requestEpoch:2,currentEpoch:2,intake:{id:'intake-a',review:{...current.review,revision:4}}};
  assert.equal(ui.reviewSnapshotReducer(current,event),current);
  const context={context_revision:10,entities:[{id:'product-a',version:4}]};
  assert.equal(ui.currentContextReducer(context,{context_revision:11,entities:[{id:'product-a',version:3}]}),context);
});
