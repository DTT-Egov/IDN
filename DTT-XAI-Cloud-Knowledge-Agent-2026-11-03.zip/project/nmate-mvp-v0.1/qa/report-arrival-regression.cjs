/* Arrival position across cached rendering and restored runs. Offline only. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
const filename=path.join(__dirname,'assistant-regression.cjs');
const sandbox={require:id=>id==='node:test'?{test(){}}:createRequire(filename)(id),__dirname,__filename:filename,console:{log(){},error:console.error},URL,Blob,setImmediate};
vm.runInNewContext(fs.readFileSync(filename,'utf8')+'\nglobalThis.arrival={harness,settle,newTea,savedConversation};',sandbox,{filename});
const {harness,settle,newTea,savedConversation}=sandbox.arrival;
const slot=h=>h.all().find(n=>n.className==='a-report-slot');
async function complete(h){h.setRun({status:'succeeded',stage:'completed',artifact_id:'ART-TEA'});await h.tick();await settle();}
test('First completion anchors the already-rendered result once instead of falling through to the report footer',async()=>{
 const h=harness();await newTea(h);await h.click('Xác nhận và nghiên cứu');await settle();
 const scroll=h.get('a-scroll');Object.assign(scroll,{scrollHeight:2000,clientHeight:500,scrollTop:1500});
 await complete(h);assert.equal(h.renders.length,1);assert.ok(slot(h).scrollCalls.some(v=>v.block==='start'));
 assert.equal(h.get('a-new-response').hidden,true);assert.equal(h.get('a-run-card'),null);
 assert.equal(h.calls.filter(v=>v.body?.name==='nmate_shipment_readiness_start').length,1);
});
test('Completion preserves an older reading position until the user asks to see the new result',async()=>{
 const h=harness();await newTea(h);await h.click('Xác nhận và nghiên cứu');await settle();
 const scroll=h.get('a-scroll');Object.assign(scroll,{scrollHeight:2000,clientHeight:500,scrollTop:100});
 await complete(h);assert.equal(scroll.scrollTop,100);assert.equal(slot(h).scrollCalls.length,0);
 const cue=h.get('a-new-response');assert.equal(cue.hidden,false);assert.equal(cue.textContent,'Xem kết quả mới ↓');
 const count=h.calls.length;await cue.emit('click');assert.ok(slot(h).scrollCalls.some(v=>v.block==='start'));
 assert.equal(cue.hidden,true);assert.equal(h.calls.length,count);
});
test('Restoring an in-flight conversation reads the same run and anchors completion without starting or paying again',async()=>{
 const c=savedConversation();Object.assign(c,{artifact_id:null,research_links:[],activity_state:{status:'researching',run_id:c.run_id}});
 const h=harness({conversation:c});h.storage.set('nmate.assistant.last.BROWSER-TEST-001',c.conversation_id);h.mount();await settle();
 Object.assign(h.get('a-scroll'),{scrollHeight:1200,clientHeight:500,scrollTop:700});
 await complete(h);assert.ok(slot(h).scrollCalls.some(v=>v.block==='start'));
 assert.equal(h.calls.filter(v=>v.body?.name==='nmate_shipment_readiness_start').length,0);
 assert.equal(h.calls.filter(v=>v.url.endsWith('/messages')||v.url.endsWith('/confirm')||v.url==='/api/cases').length,0);
});
