/**
 * Run: node qa/mobile-owner-regression.mjs
 * Executes real app.js through the existing regression harness, loaded read-only.
 * The test-only adapter adds SubmitEvent.submitter, a validity verdict and access
 * to the harness's in-memory storage. It does not edit the original test suite.
 * No browser, API, model, filesystem storage or application source is mutated.
 * Numeric min/step contracts are evaluated by a small test adapter; native browser
 * validation, layout, hit boxes and live consent invalidation need their own QA.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const qaDir=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(qaDir);
const oldFile=path.join(qaDir,'regression-tests.mjs');
const oldSource=fs.readFileSync(oldFile,'utf8');
const start=oldSource.indexOf('const files = ');
const end=oldSource.indexOf('\nfunction test(',start);
assert.ok(start>=0&&end>start,'Existing harness extraction boundary changed; review adapter before running.');
let adapter=oldSource.slice(start,end);
function adaptOnce(before,after){assert.equal(adapter.split(before).length-1,1,'Harness adapter marker changed: '+before);adapter=adapter.replace(before,after);}
adaptOnce('fn({ target, preventDefault() {} });','fn({ target, submitter: target.submitter, preventDefault() {} });');
adaptOnce("submit(id, values = {}, dataset = {}) { dispatch('submit', { id, values, dataset, reportValidity: () => true }); },", "submit(id, values = {}, dataset = {}, nextView = '', valid = true) { dispatch('submit', { id, values, dataset, submitter: { dataset: { next: nextView } }, reportValidity: () => valid }); },");
adaptOnce('get state() { return api.state; },',"get state() { return api.state; }, get persisted() { const text=storage.get('nmate.mvp.0.2.state.BROWSER-TEST-001');return text?JSON.parse(text):null; },");
adaptOnce('function harness() {','function harness(initialState = null) {');
adaptOnce('const storage = new Map();',"const storage = new Map(initialState ? [['nmate.mvp.0.1.state',JSON.stringify(initialState)]] : []);");
const loader={fs,path,vm,createHash,root,console,URL,Blob};
vm.runInNewContext(adapter+'\nglobalThis.makeHarness=harness;',loader,{filename:'mobile-owner-test-adapter',timeout:5000});
function harness(...args){const h=loader.makeHarness(...args);h.api.setAssistantIdentity('BROWSER-TEST-001');return h;}
const results=[];
const clone=value=>JSON.parse(JSON.stringify(value));
const retiredScreenTests=new Set(['MO03 Numeric constraints block invalid save; gross and chargeable weight stay separate','MO04 Save legacy logistics before opening the assistant without silently importing a different product','MO09 Old saved custom SKU is migrated once and cannot inherit seed confirmation']);
function retiredUI(name,fn){results.push({name,passed:null,skipped:true,reason:'User retired legacy forms/routes and quarantined old shared cache; active coverage is in assistant and assistant-shell regression tests.'});console.log('SKIP '+name);}
function test(name,fn){if(retiredScreenTests.has(name)){retiredUI(name,fn);return;}try{fn();results.push({name,passed:true});console.log('PASS '+name);}catch(error){results.push({name,passed:false,error:error.message});console.error('FAIL '+name+'\n  '+error.stack);}}

const product={name:'HTX kiểm thử',owner:'Chủ cơ sở',product:'Miến dong 250 g',sku:'MIEN-250',processingDescription:'Sấy khô; bảo quản ở nhiệt độ thường.',ingredients:'Tinh bột dong, nước',packSize:'250 g/gói',certifications:''};
const shipment={quantity:'1000',cartonCount:'40',grossWeight:'282.5',weight:'350 kg tính cước',origin:'Hà Nội',destination:'Chưa xác định'};
function inputContract(html,name){const escaped=name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');const tag=html.match(new RegExp('<input\\b[^>]*\\bname="'+escaped+'"[^>]*>'))?.[0];assert.ok(tag,'Missing rendered input '+name);const attrs={};for(const hit of tag.matchAll(/\b([\w-]+)="([^"]*)"/g))attrs[hit[1]]=hit[2];attrs.required=/\brequired(?:\s|>)/.test(tag);return attrs;}
// This is a constraint-contract adapter, not a replacement for browser QA.
function numberVerdict(attrs,value){if(String(value).trim()==='')return !attrs.required;if(attrs.type!=='number')return true;const number=Number(value);if(!Number.isFinite(number))return false;if(attrs.min!==undefined&&number<Number(attrs.min))return false;if(attrs.max!==undefined&&number>Number(attrs.max))return false;if(attrs.step!=='any'){const step=Number(attrs.step||1),base=Number(attrs.min||0),position=(number-base)/step;if(Math.abs(position-Math.round(position))>1e-8)return false;}return true;}

test('MO01 Save-only persists one SKU and processing facts without changing route',()=>{
 const h=harness();h.go('profile');const route=h.state.activeRoute;
 h.submit('profile-form',product);
 retiredUI('Retired profile form route',()=>assert.equal(h.api.view,'profile'));assert.equal(h.state.activeRoute,route);
 assert.equal(h.state.profile.sku,product.sku);assert.equal(h.state.profile.processingDescription,product.processingDescription);
 assert.equal(h.persisted.profile.sku,product.sku);assert.equal(h.persisted.profile.product,product.product);
 h.submit('profile-form',{...product,sku:'MIEN-500',product:'Miến dong 500 g'});
 assert.equal(h.state.profile.sku,'MIEN-500');assert.equal(h.persisted.profile.sku,'MIEN-500');
 assert.ok(!Array.isArray(h.state.profile),'The active case owns one product profile.');
});

test('MO02 Save-and-next writes profile before opening market and channel choices',()=>{
 const h=harness();h.go('profile');h.submit('profile-form',product,{},'routes');
 retiredUI('Retired route-selection destination',()=>assert.equal(h.api.view,'routes'));assert.equal(h.state.role,'business');
 assert.equal(h.state.profile.sku,product.sku);assert.equal(h.persisted.profile.processingDescription,product.processingDescription);
 assert.equal(h.state.cases.find(c=>c.id==='HN-001').product,product.product);
});

test('MO03 Numeric constraints block invalid save; gross and chargeable weight stay separate',()=>{
 const h=harness();h.go('logistics');const cartons=inputContract(h.html,'cartonCount'),gross=inputContract(h.html,'grossWeight');
 assert.equal(cartons.type,'number');assert.equal(cartons.min,'1');assert.equal(cartons.step,'1');
 assert.equal(gross.type,'number');assert.equal(gross.min,'0.001');assert.equal(gross.step,'any');
 for(const [field,attrs,value,want] of [['cartonCount',cartons,'0',false],['cartonCount',cartons,'-1',false],['cartonCount',cartons,'1.5',false],['cartonCount',cartons,'40',true],['grossWeight',gross,'0',false],['grossWeight',gross,'0.0009',false],['grossWeight',gross,'282.5',true]]){
  const valid=numberVerdict(attrs,value);assert.equal(valid,want,field+' '+value);
  if(!valid){const before=JSON.stringify(h.state);h.submit('logistics-form',{...shipment,[field]:value},{},'research-live',valid);assert.equal(JSON.stringify(h.state),before);assert.equal(h.api.view,'logistics');}
 }
 h.submit('logistics-form',shipment);
 assert.equal(h.api.view,'logistics');assert.equal(h.persisted.logistics.cartonCount,'40');
 assert.equal(h.persisted.logistics.grossWeight,'282.5');assert.equal(h.persisted.logistics.weight,'350 kg tính cước');
 assert.notEqual(h.persisted.logistics.grossWeight,h.persisted.logistics.weight);
 assert.equal(numberVerdict(cartons,''),true);assert.equal(numberVerdict(gross,''),true);
});

test('MO04 Save legacy logistics before opening the assistant without silently importing a different product',()=>{
 const h=harness();h.go('profile');h.submit('profile-form',product);h.go('logistics');let captured=null;
 h.context.NMateAssistant={unmount(){},mount(_element,context){captured={context,saved:clone(h.persisted),view:h.api.view};}};
 h.submit('logistics-form',shipment,{},'research-live');
 assert.equal(h.api.view,'assistant');assert.ok(captured,'Assistant mounts after legacy save.');
 assert.equal(captured.view,'assistant');assert.equal(captured.context.tab,'assistant');
 assert.equal(captured.saved.profile.sku,product.sku);assert.equal(captured.saved.profile.processingDescription,product.processingDescription);
 assert.equal(captured.saved.logistics.grossWeight,'282.5');assert.equal(captured.saved.logistics.cartonCount,'40');
 assert.equal(captured.saved.logistics.weight,'350 kg tính cước');assert.equal(Object.hasOwn(captured.context,'profile'),false);
});

test('MO05 Cancelling route or expert dialogs never saves a decision or grants consent',()=>{
 const h=harness();h.go('routes');const before=clone(h.state),saved=clone(h.persisted);
 const other=h.data.routes.find(r=>r.id!==h.state.activeRoute);assert.ok(other);
 h.click('route-select',other.id);assert.ok(h.modal);h.click('close-modal');
 assert.deepEqual(clone(h.state),before);assert.deepEqual(clone(h.persisted),saved);
 h.click('handoff');assert.ok(h.modal);h.click('close-modal');
 assert.deepEqual(clone(h.state.consents),before.consents);assert.equal(h.state.handoffs.length,before.handoffs.length);
 assert.deepEqual(clone(h.persisted),saved);
 // Navigating away is not a submit and must not turn an unsubmitted draft into facts.
 h.go('profile');const profileBefore=clone(h.state.profile);h.go('research-live');
 assert.deepEqual(clone(h.state.profile),profileBefore);assert.deepEqual(clone(h.persisted),saved);
});

test('MO06 Invalid forms and unapproved next targets cannot change saved facts or role',()=>{
 const h=harness();h.go('profile');const before=JSON.stringify(h.state);
 h.submit('profile-form',{...product,owner:''},{},'routes',false);
 assert.equal(JSON.stringify(h.state),before);retiredUI('Retired profile form route',()=>assert.equal(h.api.view,'profile'));assert.equal(h.persisted,null);
 h.submit('profile-form',product,{},'audit');retiredUI('Retired profile form route',()=>assert.equal(h.api.view,'profile'));assert.equal(h.state.role,'business');
 assert.equal(h.persisted.profile.sku,product.sku);
});

test('MO07 Changing product facts invalidates old decisions while retaining evidence and history',()=>{
 const h=harness();h.go('profile');const [empty,evidenced,na]=h.state.checklist;
 empty.status='verified';empty.note='';empty.evidenceId=null;
 evidenced.status='verified';evidenced.note='Phiếu sản phẩm cũ cần đối chiếu.';evidenced.evidenceId='DOC-OLD';evidenced.verifiedBy='Chuyên gia mẫu';evidenced.expertApproval={decision:'verified',itemId:evidenced.id};
 na.status='na';na.naReason='Lý do cũ cần kiểm theo SKU.';na.naApproved=true;
 h.submit('profile-form',product);
 assert.equal(empty.status,'progress');assert.equal(evidenced.status,'evidence');assert.equal(na.status,'progress');
 assert.equal(evidenced.evidenceId,'DOC-OLD');assert.equal(evidenced.note,'Phiếu sản phẩm cũ cần đối chiếu.');assert.equal(na.naReason,'Lý do cũ cần kiểm theo SKU.');
 assert.equal(evidenced.verifiedBy,null);assert.equal(evidenced.expertApproval,null);assert.equal(evidenced.reviewHistory[0].expertApproval.decision,'verified');assert.equal(na.naApproved,false);
 assert.ok(empty.reviewRequired&&evidenced.reviewRequired&&na.reviewRequired);
 h.go('checklist');retiredUI('Retired checklist decision markup',()=>{assert.ok(h.html.includes('Xác nhận cũ cần được rà lại'));assert.ok(!h.html.includes('>Chuyên gia đã xác nhận<'));});
 assert.equal(h.persisted.checklist[1].evidenceId,'DOC-OLD');
});

test('MO08 Contact-only edits keep current product decisions; relevant fact edits invalidate them',()=>{
 const h=harness();h.go('profile');const facts=clone(h.state.profile);h.state.checklist[0].status='verified';
 h.submit('profile-form',{...facts,owner:'Người phụ trách mới',email:'new@example.com',certifications:Array.isArray(facts.certifications)?facts.certifications.join(', '):facts.certifications});
 assert.equal(h.state.checklist[0].status,'verified');
 for(const field of ['sku','ingredients','packSize','processingDescription','shelfLife']){h.state.checklist[0].status='verified';h.submit('profile-form',{...clone(h.state.profile),[field]:'Dữ kiện mới '+field,certifications:Array.isArray(h.state.profile.certifications)?h.state.profile.certifications.join(', '):h.state.profile.certifications});assert.equal(h.state.checklist[0].status,'progress',field);}
});

test('MO09 Old saved custom SKU is migrated once and cannot inherit seed confirmation',()=>{
 const seed=harness().data.seed();seed.profile.sku='LEGACY-NEW';seed.profile.product='Sản phẩm đã đổi trước bản sửa';
 const first=harness(seed);assert.equal(first.state.checklist[0].status,'progress');assert.ok(first.state.checklistProductContext);assert.ok(first.persisted.checklist[0].reviewRequired);
 const historyCount=first.state.checklist[0].reviewHistory.length;const second=harness(first.persisted);assert.equal(second.state.checklist[0].reviewHistory.length,historyCount);
 // A subsequent explicit review of the current product is not invalidated again on reload.
 const reviewed=clone(first.persisted);reviewed.checklist[0].status='verified';reviewed.checklist[0].verifiedBy='Chuyên gia rà lại';
 const third=harness(reviewed);assert.equal(third.state.checklist[0].status,'verified');
});


test('MO10 Shared legacy browser cache is quarantined rather than silently imported into a private identity',()=>{const seed=harness().data.seed();seed.profile.product='PRIVATE LEGACY PRODUCT';seed.profile.sku='PRIVATE-LEGACY';const h=harness(seed);assert.notEqual(h.state.profile.product,'PRIVATE LEGACY PRODUCT');assert.equal(h.api.getLocalResearchItems().tasks.length,0);assert.equal(h.api.getLocalResearchItems().drafts.length,0);assert.equal(h.persisted,null);});
assert.equal(fs.readFileSync(oldFile,'utf8'),oldSource,'Original regression suite must remain unchanged.');
const failed=results.filter(r=>r.passed===false),skipped=results.filter(r=>r.skipped);
console.log('\n'+results.filter(r=>r.passed===true).length+'/'+results.length+' mobile owner behavior groups passed; '+failed.length+' failed; '+skipped.length+' explicitly skipped retired UI assertions.');
console.log('Scope: real app state/event transitions and native numeric contracts in Node VM; no browser/layout/native-validation or live model/API claim.');
process.exitCode=failed.length?1:0;