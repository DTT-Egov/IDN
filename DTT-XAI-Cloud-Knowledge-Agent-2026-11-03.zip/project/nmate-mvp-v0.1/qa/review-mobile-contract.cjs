const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const css=fs.readFileSync(path.join(__dirname,'../src/main-app.css'),'utf8');
const js=fs.readFileSync(path.join(__dirname,'../src/main-app.js'),'utf8');

// This gate catches competing component declarations. It supplements, rather
// than replaces, browser measurements of effective label targets and overlap.
function undersizedActions(source){
  const violations=[];
  for(const match of source.matchAll(/([^{}]+)\{([^{}]*)\}/g)){
    const selector=match[1].trim(),body=match[2];
    const action=/(?:\bbutton\b|\bsummary\b|\.source-button\b|\.button\b|\.send\b|\.attach-toggle\b|\.task-current\b)/.test(selector);
    if(!action||/(?:svg|:before|:after|\binput\b)/.test(selector))continue;
    for(const size of body.matchAll(/(?:^|;)\s*(min-height|min-width|height|width)\s*:\s*(\d+(?:\.\d+)?)px/g))if(Number(size[2])<44)violations.push({selector,property:size[1],px:Number(size[2])});
  }
  return violations;
}
function topLevelBlockHeaders(source){
  source=source.replace(/\/\*[\s\S]*?\*\//g,'');
  const headers=[];let depth=0,start=0,quote='';
  for(let i=0;i<source.length;i++){
    const char=source[i];if(quote){if(char==='\\')i++;else if(char===quote)quote='';continue;}
    if(char==='"'||char==="'"){quote=char;continue;}
    if(char==='{'&&depth++===0)headers.push(source.slice(start,i).trim());
    else if(char==='}'){depth--;if(depth===0)start=i+1;}
    else if(char===';'&&depth===0)start=i+1;
  }
  return headers;
}

test('Mobile action contract has one explicit layer owner and no undersized component requests',()=>{
  assert.match(css,/@layer tokens, components, primitives, utilities;/);
  assert.match(css,/@layer tokens\s*\{\s*:root\s*\{\s*--interaction-min-size:44px/);
  assert.match(css,/@layer primitives\s*\{/);
  assert.match(css,/:where\(button,summary,a\[href\]/);
  assert.match(css,/:where\(\.check,\.live-consent\)\{min-height:var\(--interaction-min-size\);min-width:var\(--interaction-min-size\)/);
  assert.deepEqual(undersizedActions(css),[]);
  assert.ok(topLevelBlockHeaders(css).every(header=>/^@layer\b/.test(header)),'A new unlayered rule would override all layered interaction primitives.');
  assert.doesNotMatch(js,/<(?:button|summary|a)\b[^>]*style=/);
});

test('The static gate catches both a compact disclosure and a small source button introduced later',()=>{
  assert.deepEqual(undersizedActions('.edit-details>summary{min-height:32px}.source-button{height:40px}').map(item=>item.px),[32,40]);
  assert.deepEqual(undersizedActions('.check input{width:24px;height:24px}.mark{width:32px;height:32px}'),[]);
  assert.ok(topLevelBlockHeaders(css+'\nsummary{height:30px}').some(header=>!/^@layer\b/.test(header)));
});

test('Mobile contract retains visible keyboard focus and does not shrink compact targets with transforms',()=>{
  assert.match(css,/:focus-visible\{outline:2px solid/);
  for(const match of css.matchAll(/([^{}]+)\{([^{}]*)\}/g))if(/(?:button|summary|\.send|\.attach-toggle)/.test(match[1]))assert.doesNotMatch(match[2],/transform\s*:\s*scale\s*\(/);
});

module.exports={undersizedActions};
