/* Synthetic HTTP seam only; no endpoint reaches an actual server/provider. */
window.costFixture={actor:'TEST-A',calls:[],delayed:null,pendingRelease:null,failPreview:false};
window.fetch=async function(url,options={}){
  const fixture=window.costFixture,actor=fixture.actor;
  fixture.calls.push({url,method:options.method||'GET'});
  if(!String(url).startsWith('/api/main/policy-cost/'))throw Error('Unexpected URL in test');
  const kind=String(url).split('/').pop();
  const response={ok:true,status:200,json:async()=>({ok:true,_scope_actor_id:actor,data:kind==='status'?(actor==='TEST-A'?{enabled:true,account_id:actor,username:'TEST ONLY A',can_approve:true,expires_at:new Date(Date.now()+3600000).toISOString(),model:'claude-opus-5-5',cap_microusd:500000,known_estimated_microusd:217632,continuation_recorded:false}:{enabled:false}):{schema_version:'knowledge-independent-continuation/2',decision_id:'TEST-O2',inputs:[{task_id:'S3'},{task_id:'S4'}]}})};
  if(kind==='approve')throw Error('No decision mutation permitted in these UI probes');
  if(kind==='preview'&&fixture.failPreview)return {ok:false,status:409,json:async()=>({ok:false,error:{message:'TEST: nguồn đã đổi; xem lại quyết định.'}})};
  if(kind===fixture.delayed){fixture.delayed=null;await new Promise(resolve=>{fixture.pendingRelease=resolve;});}
  return response;
};
