/* Browser-side behavior under a synthetic DOM and transport. No server, HTTP,
 * provider SDK, credentials or paid calls. Backend SQL races are tested in Python. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
const filename=path.join(__dirname,'assistant-regression.cjs'),localRequire=createRequire(filename);
const adapter={require:id=>id==='node:test'?{test(){}}:localRequire(id),__dirname,__filename:filename,console:{log(){},error:console.error},URL,Blob,setImmediate};
vm.runInNewContext(fs.readFileSync(filename,'utf8')+'\nglobalThis.helpers={harness,settle,conversation,savedConversation,openSaved,openReport,visible,tea};',adapter,{filename});
const A=adapter.helpers,plain=value=>JSON.parse(JSON.stringify(value));
const preferenceKey='nmate.assistant.preferences.BROWSER-TEST-001';
const paid=h=>h.calls.filter(c=>c.url.endsWith('/messages')||c.body?.name==='nmate_shipment_readiness_start');
const obsolete=h=>h.calls.filter(c=>c.url==='/api/cases'||c.url.endsWith('/link'));
async function firstConsent(h){h.mount();await A.settle();await h.send('Tôi có Trà Sen Tây Hồ gửi New York, cần tìm hiểu nhãn?');await h.consent();}
async function newConversation(h){await h.get('a-new').emit('click');await A.settle();}

test('A new profile grants nothing by default and never sends automatically on mount or timer',async()=>{
 const h=A.harness();h.mount();await A.settle();await h.tick();assert.equal(paid(h).length,0);
 await h.send('Tôi cần nghiên cứu nhãn.');assert.equal(paid(h).length,0);
 assert.equal(h.get('a-storage-consent').checked,false);assert.equal(h.get('a-model-consent').checked,false);
 assert.equal(h.storage.has(preferenceKey),false);
});

test('One explicit two-part consent is remembered only for this profile and provider, while fees remain visible',async()=>{
 const h=A.harness();await firstConsent(h);
 const preferences=JSON.parse(h.storage.get(preferenceKey));assert.equal(preferences.scope,'browser-conversations-v1');assert.equal(preferences.provider,'anthropic');assert.equal(preferences.storage,true);assert.equal(preferences.model,true);
 await newConversation(h);const before=paid(h).length;await h.tick();assert.equal(paid(h).length,before);
 assert.equal(h.get('a-send-fee').hidden,false);assert.match(h.get('a-send-fee').textContent,/AI có phí/);
 await h.send('Tôi có Trà Sen Tây Hồ, câu hỏi mới về thông báo trước.');assert.equal(h.get('a-chat-consent'),null);
 assert.equal(paid(h).length,before+1);assert.equal(h.calls.filter(c=>c.url==='/api/conversations'&&c.options.method==='POST').length,2);
 assert.equal(h.get('a-send-fee').hidden,false);
});

test('A remembered grant survives a reload without any automatic send or thread creation',async()=>{
 const h=A.harness();await firstConsent(h);await newConversation(h);
 const reloaded=A.harness({storage:h.storage});reloaded.mount();await A.settle();await reloaded.tick();
 assert.equal(reloaded.calls.filter(c=>c.options.method==='POST').length,0);
 await reloaded.send('Tôi cần nghiên cứu đăng ký cơ sở cho Trà Sen.');assert.equal(reloaded.get('a-chat-consent'),null);assert.equal(paid(reloaded).length,1);
});

for(const scenario of ['another-profile','another-provider','old-scope','partial-grant','invalid-json'])test('Consent is not inherited for '+scenario,async()=>{
 const h=A.harness();await firstConsent(h);await newConversation(h);
 const session={};if(scenario==='another-profile')session.workspace_id='BROWSER-SECOND-002';if(scenario==='another-provider')session.model_provider='openai';
 if(scenario==='old-scope'||scenario==='partial-grant'){const p=JSON.parse(h.storage.get(preferenceKey));if(scenario==='old-scope')p.scope='old-permission';else p.model=false;h.storage.set(preferenceKey,JSON.stringify(p));}
 if(scenario==='invalid-json')h.storage.set(preferenceKey,'{broken preferences');
 const next=A.harness({storage:h.storage,session});next.mount();await A.settle();await next.send('Tôi cần tìm hiểu nhãn thực phẩm.');
 assert.equal(paid(next).length,0);assert.equal(next.get('a-storage-consent').checked,false);assert.equal(next.get('a-model-consent').checked,false);
});

test('Forgetting remembered rights affects future conversations without silently granting or dispatching them',async()=>{
 const h=A.harness();await firstConsent(h);await h.get('a-history-toggle').emit('click');await h.get('a-forget-consent').emit('click');
 const p=JSON.parse(h.storage.get(preferenceKey));assert.equal(p.scope,undefined);assert.equal(p.model,undefined);
 await newConversation(h);const before=paid(h).length;await h.send('Tôi muốn hỏi đăng ký cơ sở.');assert.equal(paid(h).length,before);assert.equal(h.get('a-model-consent').checked,false);
});

test('Processing level survives reload for the same conversation without leaking to another conversation',async()=>{
 const c=A.savedConversation(),h=A.harness({conversation:c});await A.openSaved(h);h.get('a-processing').value='complex';await h.get('a-processing').emit('change');
 assert.equal(JSON.parse(h.storage.get(preferenceKey)).processing[c.conversation_id],'complex');
 const reloaded=A.harness({storage:h.storage,conversation:h.current});reloaded.mount();await A.settle();assert.equal(reloaded.get('a-processing').value,'complex');assert.equal(paid(reloaded).length,0);
 const different=A.savedConversation();different.conversation_id='CONVERSATION-DIFFERENT';const other=A.harness({storage:h.storage,conversation:different,fetch(url,opts,normal){if(url==='/api/conversations/CONVERSATION-DIFFERENT')return different;return normal(url,opts);}});other.mount();await A.settle();await other.get('a-history').children[2].emit('click');await A.settle();assert.equal(other.get('a-processing').value,'auto');assert.equal(paid(other).length,0);
});

test('A chosen processing level reaches atomic preparation and the server-bound MCP arguments unchanged',async()=>{
 const h=A.harness();await firstConsent(h);h.get('a-processing').value='complex';await h.get('a-processing').emit('change');await h.click('Xác nhận và nghiên cứu');await A.settle();
 const prepared=h.calls.find(c=>c.url.endsWith('/research-case')),start=h.calls.find(c=>c.body?.name==='nmate_shipment_readiness_start');
 assert.equal(prepared.body.processing_level,'complex');assert.deepEqual(Object.keys(prepared.body).sort(),['expected_version','idempotency_key','processing_level']);
 assert.equal(start.body.arguments.processing_level,'complex');assert.equal(start.body.arguments.question,h.current.draft.question);assert.match(start.body.arguments.idempotency_key,/^SERVER-LAUNCH-/);assert.equal(obsolete(h).length,0);
});

test('Finishing and reading back an atomic run uses server links with one start and zero browser link writes',async()=>{
 const h=A.harness();await firstConsent(h);await h.click('Xác nhận và nghiên cứu');await A.settle();
 h.setRun({status:'succeeded',stage:'completed',artifact_id:'ART-TEA'});await h.tick();await h.tick();
 assert.equal(h.current.artifact_id,'ART-TEA');assert.equal(h.current.research_links.length,1);assert.equal(h.current.research_links[0].artifact_id,'ART-TEA');
 assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);assert.equal(h.calls.filter(c=>c.url.endsWith('/research-case')).length,1);assert.equal(obsolete(h).length,0);
 const fee=h.all().find(n=>n.className==='a-research-fee');assert.ok(fee);assert.match(fee.textContent,/đã có kết quả.*lượt AI mới.*phí/);assert.doesNotMatch(fee.textContent,/Bấm để xác nhận/);
 assert.equal(h.all().some(n=>n.className==='a-source-warning'),false);assert.equal(h.get('a-send-fee').hidden,false);
});

test('Lost atomic preparation response survives reload as an attached pending launch and never starts automatically',async()=>{
 const h=A.harness({fetch(url,opts,normal){const value=normal(url,opts);if(url.endsWith('/research-case'))throw new Error('TEST response lost after commit');return value;}});
 await firstConsent(h);await h.click('Xác nhận và nghiên cứu');await A.settle();assert.ok(h.current.pending_research_launch);assert.equal(h.current.research_links.length,1);assert.equal(h.calls.some(c=>c.body?.name==='nmate_shipment_readiness_start'),false);
 const restored=A.harness({storage:h.storage,conversation:h.current});restored.mount();await A.settle();await restored.tick();assert.equal(paid(restored).length,0);assert.ok(restored.all().some(n=>n.tagName==='BUTTON'&&n.textContent==='Tiếp tục nghiên cứu · 1 lượt AI có phí'));assert.equal(obsolete(restored).length,0);
});

test('Lost MCP acknowledgement after server dispatch reconciles by read only and never calls start twice',async()=>{
 let lost=true;const h=A.harness({fetch(url,opts,normal){const value=normal(url,opts),body=opts.body?JSON.parse(opts.body):null;if(lost&&body?.name==='nmate_shipment_readiness_start')throw new Error('TEST acknowledgement lost after run commit');return value;}});
 await firstConsent(h);await h.click('Xác nhận và nghiên cứu');await A.settle();assert.equal(h.current.pending_research_launch,null);assert.equal(h.current.run_id,'RUN-TEA');lost=false;
 const before=paid(h).length;await h.click('Đối chiếu lượt đã gửi · không gọi AI mới');await A.settle();await h.tick();assert.equal(paid(h).length,before);
 assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);assert.equal(h.calls.filter(c=>c.url.endsWith('/research-case')).length,1);assert.equal(obsolete(h).length,0);assert.ok(h.get('a-run-card'));
});

for(const [first,owner] of [['Tôi làm Trà Sen.','Tôi'],['Em có Trà Sen.','Em'],['Anh có Trà Sen.','Anh'],['Chị làm Trà Sen.','Chị'],['Chúng tôi làm Trà Sen.','Chúng tôi'],['Mình làm Trà Sen.','Mình'],['Lô Trà Sen cần chuẩn bị gì?','Doanh nghiệp']])test('Task owner follows the actual first user self-address without rewriting it: '+owner,async()=>{
 const c=A.savedConversation();c.messages[0].content=first;let saved;const h=A.harness({conversation:c,saveTask:v=>(saved=plain(v),{id:'LOCAL-TASK'})});await A.openSaved(h);await A.openReport(h);await h.click('Lưu việc');assert.equal(h.get('a-task-owner').value,owner);await h.click('Lưu trên thiết bị');assert.equal(saved.owner,owner);assert.equal(h.current.messages[0].content,first);assert.equal(paid(h).length,0);
});

test('Malformed stored processing never selects a different model or grants consent',async()=>{
 const c=A.savedConversation(),storage=new Map([[preferenceKey,JSON.stringify({processing:{[c.conversation_id]:'SUPER-EXPENSIVE-UNTRUSTED'}})]]),h=A.harness({storage,conversation:c});await A.openSaved(h);assert.equal(h.get('a-processing').value,'auto');assert.equal(paid(h).length,0);await newConversation(h);await h.send('Tôi cần hỏi nhãn.');assert.equal(h.get('a-model-consent').checked,false);assert.equal(paid(h).length,0);
});
