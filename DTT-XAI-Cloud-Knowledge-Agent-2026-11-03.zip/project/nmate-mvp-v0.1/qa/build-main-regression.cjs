const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const builder=path.join(root,'scripts/build-main.mjs');

test('The real build includes every script and stylesheet referenced by both entrypoints',()=>{
  const target=fs.mkdtempSync(path.join(os.tmpdir(),'nmate-build-check-'));
  const run=spawnSync(process.execPath,[builder,'--output',target],{cwd:root,encoding:'utf8'});
  assert.equal(run.status,0,run.stderr);
  const html=fs.readFileSync(path.join(root,'main.html'),'utf8');
  assert.equal(fs.readFileSync(path.join(target,'main.html'),'utf8'),html);
  assert.equal(fs.readFileSync(path.join(target,'index.html'),'utf8'),html);
  const refs=[...html.matchAll(/<script\b[^>]*src=["']([^"']+)["']/gi)].map(match=>match[1]);
  for(const tag of html.matchAll(/<link\b[^>]+>/gi))if(/rel=["']stylesheet["']/i.test(tag[0]))refs.push(tag[0].match(/href=["']([^"']+)["']/i)[1]);
  assert.ok(refs.includes('src/main-ui-contracts.js'));
  for(const ref of refs){const file=ref.split(/[?#]/)[0];assert.deepEqual(fs.readFileSync(path.join(target,file)),fs.readFileSync(path.join(root,file)));}
});

for(const [name,script] of [['remote','<script src="https://example.invalid/a.js"></script>'],['parent traversal','<script src="src/../../unexpected.js"></script>'],['inline','<script>alert(1)</script>']]){
  test('Build rejects '+name+' scripts before creating an output',()=>{
    const fixture=fs.mkdtempSync(path.join(os.tmpdir(),'nmate-build-reject-'));
    fs.mkdirSync(path.join(fixture,'scripts'));
    fs.copyFileSync(builder,path.join(fixture,'scripts/build-main.mjs'));
    fs.writeFileSync(path.join(fixture,'main.html'),'<html><body><div id="main-app"></div>'+script+'</body></html>');
    const target=path.join(fixture,'out');
    const run=spawnSync(process.execPath,[path.join(fixture,'scripts/build-main.mjs'),'--output',target],{encoding:'utf8'});
    assert.notEqual(run.status,0);assert.equal(fs.existsSync(target),false);
  });
}
