/* Run: node qa/live-chat-regression.cjs
 * Loads the original live harness without registering or modifying its tests.
 * All network/timers/models are controlled mocks. These are behavior/data tests,
 * not screenshots, browser constraint validation or proof of paid model use.
 */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {createRequire}=require('node:module');const {test}=require('node:test');
const oldPath=path.join(__dirname,'live-research-regression.cjs'),original=fs.readFileSync(oldPath,'utf8');
const boundary=original.indexOf("\ntest('Rejected initial session");assert.ok(boundary>0,'Original harness boundary changed; review adapter.');
const loader={require:createRequire(oldPath),__dirname,__filename:oldPath,console:{log(){},error:console.error},URL,setImmediate};
vm.runInNewContext(original.slice(0,boundary)+'\nglobalThis.chatTools={harness,settle,baseContext,runData,artifactData,copy};',loader,{filename:'live-chat-test-adapter'});
const {harness,settle,baseContext,runData,artifactData,copy}=loader.chatTools;
function visibleText(element){if(element.hidden)return '';if(element.tagName==='DETAILS'&&!element.open){const summary=element.children.find(n=>n.tagName==='SUMMARY');return summary?visibleText(summary):'';}return (element._text||'')+' '+element.children.map(visibleText).join(' ');}
function sourceReport(options={}){const artifact=artifactData();artifact.content_sha256='MOCK-IMMUTABLE-REPORT-HASH';artifact.report.summary='Nguồn hiện có hỗ trợ chuẩn bị, còn cần làm rõ dữ kiện trước khi quyết định.';artifact.report.summary_kind='assessment';artifact.report.next_steps_policy_version='0.2.2';artifact.report.evidence=[{id:'SRC-1',url:'https://www.fda.gov/food/example?view=original',title:'Original English title',publisher:'Original English publisher',excerpt:'Original English evidence wording.',accessed_at:'2026-10-17T10:00:00Z',content_sha256:'MOCK-SOURCE-HASH',locator:'Paragraph 2',review_status:'candidate',...options}];return artifact;}
function withArtifact(artifact,extra){return harness((url,options,normal)=>{if(url==='/api/mcp/call'&&JSON.parse(options.body).name==='nmate_artifact_get')return {ok:true,data:artifact};return extra?extra(url,options,normal):normal(url,options);});}
async function completed(h){h.setRun(runData('succeeded'));h.mount();await settle();await h.submit();await settle();}
const translate={title_vi:'Tiêu đề bằng tiếng Việt',excerpt_vi:'Trích đoạn tiếng Việt để tham khảo và đối chiếu.',publisher_vi:'Cơ quan công bố bằng tiếng Việt',translation:{language:'vi',status:'draft_reference',method:'reference_catalog',original_excerpt_sha256:'MOCK-EXCERPT-HASH',note:'Bản dịch tham khảo, chưa được rà.'}};

test('Chat starts with a compact case and progressive controls; mounting never starts research',async()=>{
 const h=harness();h.mount();await settle();assert.equal(h.get('product-card-title').textContent,'MOCK Miến A');
 assert.equal(h.get('edit-profile-details').open,false);assert.equal(h.element.querySelectorAll('[data-panel]').length,0);
 const parent=h.get('processing_level').parentNode.parentNode.parentNode;assert.equal(parent.tagName,'DETAILS');assert.equal(parent.open,false);
 assert.equal(h.get('research-status-card').hidden,true);assert.doesNotMatch(visibleText(h.element),/claude-sonnet-5-5|MOCK-RUN-A/);
 assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
});

test('The entered question is sent exactly and shown only after server acceptance',async()=>{
 const h=harness();h.mount();await settle();const question='Cần hỏi đơn vị vận chuyển những dữ kiện nào cho lô miến này?';h.get('research-question').value=question;
 assert.equal(h.get('user-sent-message').hidden,true);await h.submit();
 const call=h.calls.find(c=>c.body?.name==='nmate_shipment_readiness_start');assert.equal(call.body.arguments.question,question);
 assert.equal(h.get('submitted-question').textContent,question);assert.equal(h.get('user-sent-message').hidden,false);
 assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);
});

test('A changed question flags the prior result and gets a distinct explicit request key',async()=>{
 const h=harness();await completed(h);const first=h.calls.find(c=>c.body?.name==='nmate_shipment_readiness_start').body.arguments;
 const changed='Hãy so sánh dữ kiện cần có khi hỏi báo cước cho hai điểm giao.';h.get('research-question').value=changed;await h.get('research-question').emit('input');
 assert.equal(h.get('result-context').hidden,false);assert.equal(h.get('confirm-profile').checked,false);
 assert.notEqual(h.get('submitted-question').textContent,changed);await h.submit();
 const last=h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').at(-1).body.arguments;
 assert.equal(last.question,changed);assert.notEqual(last.idempotency_key,first.idempotency_key);
});

test('History preserves the actual saved question rather than the draft currently being edited',async()=>{
 const h=harness();h.setRun({...runData('succeeded'),question:'Câu hỏi gốc của lượt đã lưu.'});h.mount();await settle();h.get('research-question').value='Bản nháp chưa gửi của hôm nay.';
 await h.get('history').children[0].emit('click');await settle();assert.equal(h.get('submitted-question').textContent,'Câu hỏi gốc của lượt đã lưu.');assert.equal(h.get('research-status-title').textContent,'Mình đã lưu bản nghiên cứu');
 assert.equal(h.calls.some(c=>c.body?.name==='nmate_shipment_readiness_start'),false);
});

test('Vietnamese source text is default; exact English wording and URL remain in optional original',async()=>{
 const artifact=sourceReport(translate),before=JSON.stringify(artifact);const h=withArtifact(artifact);await completed(h);h.get('detail-sources').open=true;
 const card=h.get('evidence-SRC-1');assert.match(visibleText(card),/Trích đoạn tiếng Việt/);assert.doesNotMatch(visibleText(card),/Original English evidence wording/);
 const original=card.children.find(n=>n.tagName==='DETAILS'&&n.children[0]?.textContent==='Xem nguyên văn tiếng Anh');assert.ok(original);assert.equal(original.open,false);original.open=true;
 assert.match(visibleText(original),/Original English evidence wording/);const links=card.all().filter(n=>n.tagName==='A');assert.ok(links.length);assert.ok(links.every(n=>n.href===artifact.report.evidence[0].url));
 assert.equal(JSON.stringify(artifact),before);assert.equal(h.calls.some(c=>/\/translations$/.test(c.url)),false);
});

test('An exact report sidecar enriches display only and never restarts paid research',async()=>{
 const artifact=sourceReport(),before=JSON.stringify(artifact);let reads=0;const h=withArtifact(artifact,(url,options,normal)=>{if(url.endsWith('/translations')){reads++;return {artifact_id:artifact.artifact_id,content_sha256:artifact.content_sha256,evidence_translations:[{evidence_id:'SRC-1',...translate},{evidence_id:'UNKNOWN-SOURCE',...translate}]};}return normal(url,options);});
 await completed(h);assert.match(h.get('evidence-SRC-1').textContent,/Trích đoạn tiếng Việt/);assert.equal(JSON.stringify(artifact),before);assert.equal(reads,1);
 assert.equal(h.get('evidence-UNKNOWN-SOURCE'),null);assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);
});

test('Mismatched artifact ID or hash never supplies a translation to the current report',async()=>{
 for(const mismatch of ['artifact_id','content_sha256']){const artifact=sourceReport();const h=withArtifact(artifact,(url,options,normal)=>url.endsWith('/translations')?{artifact_id:artifact.artifact_id,content_sha256:artifact.content_sha256,[mismatch]:'WRONG',evidence_translations:[{evidence_id:'SRC-1',...translate}]}:normal(url,options));await completed(h);const text=visibleText(h.get('evidence-SRC-1'));assert.match(text,/Chưa có bản dịch tiếng Việt/);assert.doesNotMatch(text,/Trích đoạn tiếng Việt/);assert.doesNotMatch(text,/Original English evidence wording/);}
});

test('Source failures show Vietnamese first and keep raw English/code in closed audit details',async()=>{
 const artifact=sourceReport(translate);artifact.report.source_failures=[{source_id:'CBP',code:'HTTP_403',detail:'English access forbidden detail.',url:'https://www.cbp.gov/example'}];const h=withArtifact(artifact);await completed(h);
 const panel=h.get('panel-sources');assert.match(visibleText(panel),/CBP — Hải quan Hoa Kỳ · chưa đọc được/);assert.match(visibleText(panel),/Nguồn từ chối truy cập/);assert.doesNotMatch(visibleText(panel),/HTTP_403|English access forbidden detail/);
 const audit=panel.all().find(n=>n.tagName==='DETAILS'&&n.children[0]?.textContent==='Thông tin đối chiếu lỗi nguồn');assert.ok(audit);audit.open=true;assert.match(visibleText(audit),/HTTP_403.*English access forbidden detail/s);
});

test('Missing confirmation or invalid numeric facts produce Vietnamese errors and zero writes',async()=>{
 const h=harness();h.mount();await settle();await h.get('research-form').emit('submit');assert.equal(h.get('error-code').textContent,'PROFILE_CONFIRMATION_REQUIRED');
 assert.match(visibleText(h.get('error-box')),/Cần xác nhận hồ sơ/);assert.doesNotMatch(visibleText(h.get('error-box')),/PROFILE_CONFIRMATION_REQUIRED/);
 h.get('confirm-profile').checked=true;h.get('consent-research').checked=true;h.get('consent-model').checked=true;h.get('carton_count').value='1.5';await h.get('research-form').emit('submit');
 assert.equal(h.get('error-code').textContent,'INVALID_NUMBER');assert.equal(h.get('edit-profile-details').open,true);assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
});

test('Native invalid controls receive Vietnamese validity messages that clear on input',async()=>{
 const h=harness();h.mount();await settle();const field=h.get('consent-research');let custom='';field.validity={valueMissing:true};field.setCustomValidity=value=>{custom=value};
 const invalid=h.get('research-form').listeners.get('invalid');assert.ok(invalid?.length);invalid[0]({target:field});assert.match(custom,/Bạn cần đánh dấu/);assert.equal(h.get('before-send').open,true);
 await field.emit('input');assert.equal(custom,'');assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
});

test('The conversational answer leads with the actual stored model summary, not a canned readiness sentence',async()=>{
 const artifact=artifactData();artifact.report.summary_kind='assessment';artifact.report.next_steps_policy_version='0.2.2';artifact.report.summary='Với lô miến 250 g này, điểm cần chốt trước là điểm giao và bên dự kiến đứng tên nhập khẩu. Anh/chị nên gom quy cách kiện để hỏi báo cước có cùng phạm vi.';artifact.report.readiness_status='needs_information';artifact.report.unknowns=[{field:'shipment.destination',question:'Điểm giao ở đâu?'}];
 const h=withArtifact(artifact);await completed(h);assert.equal(h.get('research-status-title').textContent,'Mình đã lưu bản nghiên cứu');assert.equal(h.get('summary-brief').textContent,artifact.report.summary);assert.equal(h.get('summary').textContent,artifact.report.summary);
 assert.doesNotMatch(h.get('summary-brief').textContent,/Mình còn một số dữ kiện/);assert.match(visibleText(h.get('result')),/Bản nháp · cần chuyên gia rà/);assert.match(visibleText(h.get('result')),/Chưa xác nhận tuân thủ/);
 assert.equal(h.get('next-steps-heading').textContent,'Việc tiếp theo cần làm rõ');
});

test('Legacy long answers are clearly labelled and kept intact rather than semantically clipped',async()=>{
 const artifact=artifactData();artifact.report.summary='Đây là câu đầu có nội dung riêng của sản phẩm. Đây là câu thứ hai nêu giới hạn cần rà. '+('Nội dung chi tiết của báo cáo cần đối chiếu. '.repeat(60));const original=artifact.report.summary;
 const h=withArtifact(artifact);await completed(h);assert.match(h.get('summary-brief').textContent,/Bản nghiên cứu cũ được giữ nguyên/);assert.equal(h.get('legacy-label').hidden,false);assert.doesNotMatch(h.get('summary-brief').textContent,/Đây là câu đầu/);assert.equal(h.get('summary').textContent,original);assert.equal(artifact.report.summary,original);
 assert.equal(h.get('summary').parentNode.open,false);
});

test('Source links use report order numbers, preserve their true target, and count only actual proposed steps',async()=>{
 const artifact=sourceReport(translate);artifact.report.evidence[0].id='technical-first';artifact.report.evidence.push({...copy(artifact.report.evidence[0]),id:'technical-second',url:'https://www.fda.gov/second'});
 artifact.report.next_steps=[{id:'NEXT-1',title:'Chốt điểm giao',reason:'Để hỏi cùng phạm vi báo cước.',evidence_ids:['technical-second','technical-first']}];
 const h=withArtifact(artifact);await completed(h);const links=h.get('panel-next').all().filter(n=>n.className==='evidence-link');assert.deepEqual(Array.from(links,n=>n.textContent),['Nguồn 2','Nguồn 1']);assert.equal(h.get('next-steps-heading').textContent,'Việc đề xuất để bắt đầu');
 assert.doesNotMatch(visibleText(h.get('panel-next')),/technical-first|technical-second/);await links[0].emit('click');assert.equal(h.get('detail-sources').open,true);assert.equal(h.get('evidence-technical-second').scrollCalls.length,1);
});

test('Compose to review is display-only, keeps separate unticked consent gates, and going back clears them',async()=>{
 const h=harness();h.mount();await settle();assert.equal(h.get('compose-details').open,true);assert.equal(h.get('before-send').hidden,true);
 assert.match(visibleText(h.get('research-form')),/Bạn muốn làm rõ điều gì/);assert.doesNotMatch(visibleText(h.get('research-form')),/Tôi đồng ý gửi câu hỏi/);
 await h.get('review-request').emit('click');assert.equal(h.get('before-send').hidden,false);assert.equal(h.get('before-send').open,true);assert.equal(h.get('review-request').hidden,true);
 for(const id of ['confirm-profile','consent-research','consent-model'])assert.equal(h.get(id).checked,false,id+' is never preselected');
 assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
 h.get('confirm-profile').checked=true;h.get('consent-research').checked=true;await h.get('research-form').emit('submit');assert.equal(h.get('error-code').textContent,'MODEL_CONSENT_REQUIRED');assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
 await h.get('review-back').emit('click');assert.equal(h.get('before-send').hidden,true);assert.equal(h.get('review-request').hidden,false);
 for(const id of ['confirm-profile','consent-research','consent-model'])assert.equal(h.get(id).checked,false);
 assert.equal(h.get('research-question').focusCalls.length,1);assert.equal(h.calls.some(c=>c.options.method==='POST'),false);
});

test('Completed canonical report shows the whole assessment and all three titles while details and completed progress stay closed',async()=>{
 const artifact=sourceReport(translate);artifact.report.evidence.push({...copy(artifact.report.evidence[0]),id:'SRC-2',url:'https://www.fda.gov/second'});artifact.report.source_failures=[{code:'HTTP_403',detail:'Unreachable source.'}];
 artifact.report.next_steps=[
  {id:'clarify_import_roles',title:'Làm rõ riêng vai nhập khẩu và xác minh nhà cung cấp',reason:'Xác nhận riêng vai IOR và FSVP, không tự đồng nhất hai vai.',owner_role:'business_and_expert',done_when:'Ghi rõ bên dự kiến đảm nhiệm từng vai và điều còn cần rà.',evidence_ids:['SRC-1']},
  {id:'clarify_delivery_terms',title:'Chốt điều kiện và điểm giao dự kiến',reason:'Ghi cùng phạm vi khi hỏi báo cước.',evidence_ids:['SRC-2']},
  {id:'expert_preparation_review',title:'Nhờ chuyên gia rà hồ sơ nhãn và đăng ký',reason:'Gửi hồ sơ hiện có cùng câu hỏi FDA để rà riêng từng điều kiện.',evidence_ids:['SRC-1']},
 ];
 const before=JSON.stringify(artifact),h=withArtifact(artifact);await completed(h);const panel=h.get('panel-next'),steps=panel.children;
 assert.equal(h.get('summary-brief').textContent,artifact.report.summary);assert.equal(h.get('source-coverage').textContent,'2 đoạn căn cứ · 2 trang nguồn · 1 nguồn chưa đọc');assert.equal(h.get('legacy-label').hidden,true);
 assert.equal(steps.length,3);assert.deepEqual(Array.from(steps,s=>s.dataset.stepId),artifact.report.next_steps.map(s=>s.id));
 for(let i=0;i<steps.length;i++){assert.equal(steps[i].tagName,'DETAILS');assert.equal(steps[i].open,false);assert.match(visibleText(steps[i]),new RegExp(artifact.report.next_steps[i].title));assert.doesNotMatch(visibleText(steps[i]),new RegExp(artifact.report.next_steps[i].reason));}
 steps[0].open=true;assert.match(visibleText(steps[0]),/Doanh nghiệp và chuyên gia/);assert.match(visibleText(steps[0]),/Ghi rõ bên dự kiến đảm nhiệm từng vai/);
 assert.equal(h.get('compose-details').open,false);assert.equal(h.get('submitted-details').open,false);assert.equal(h.get('progress-details').open,false);assert.equal(h.get('before-send').hidden,true);assert.equal(h.get('result').scrollCalls.length,1);
 assert.equal(JSON.stringify(artifact),before);assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);
});

test('Legacy action lists and every additional stored step remain readable with an explicit old-plan label',async()=>{
 const artifact=sourceReport(translate);delete artifact.report.summary_kind;delete artifact.report.next_steps_policy_version;artifact.report.summary='Nhận định cũ.\n1. Giữ nguyên việc trong toàn văn.\n2. Không tự đổi thành kế hoạch mới.';artifact.report.next_steps=Array.from({length:5},(_,i)=>({id:'OLD-'+(i+1),title:'Việc cũ số '+(i+1),reason:'Lý do đầy đủ số '+(i+1),evidence_ids:[]}));
 const before=JSON.stringify(artifact),h=withArtifact(artifact);await completed(h);assert.equal(h.get('summary').textContent,artifact.report.summary);assert.equal(h.get('summary').parentNode.open,false);assert.equal(h.get('legacy-label').hidden,false);assert.match(visibleText(h.get('legacy-label')),/Bản cũ.*Giữ nguyên để đối chiếu/);
 const more=h.get('panel-next').children[3];assert.equal(more.open,false);assert.match(visibleText(more),/còn 2 việc khác/);assert.doesNotMatch(visibleText(more),/Việc cũ số 4/);more.open=true;
 for(const step of artifact.report.next_steps.slice(3)){assert.match(visibleText(more),new RegExp(step.title));const detail=more.children.find(n=>n.dataset.stepId===step.id);detail.open=true;assert.match(visibleText(detail),new RegExp(step.reason));}
 h.get('summary').parentNode.open=true;assert.match(visibleText(h.get('summary').parentNode),/1\. Giữ nguyên việc/);assert.equal(JSON.stringify(artifact),before);
});

test('Source preview is compact without replacing or losing the full Vietnamese translation and original evidence',async()=>{
 const full='Bản dịch chính xác theo trích đoạn nguồn với đầy đủ nội dung để người dùng chủ động đọc đối chiếu khi cần. '+('Nội dung tham khảo còn nguyên vẹn. '.repeat(15));
 const artifact=sourceReport({...translate,excerpt_vi:full});artifact.report.next_steps=[{id:'expert_preparation_review',title:'Rà câu hỏi về nhãn',reason:'Đối chiếu hồ sơ nhãn với nguồn.',evidence_ids:['SRC-1']}];artifact.report.warnings=['Cần rà giới hạn của nguồn cho đúng sản phẩm.'];
 const before=JSON.stringify(artifact),h=withArtifact(artifact);await completed(h);const card=h.get('evidence-SRC-1'),preview=card.children.find(n=>n.className==='excerpt source-preview'),vietnamese=card.children.find(n=>n.className==='source-vietnamese');
 assert.ok(preview.textContent.length<full.length);assert.match(preview.textContent,/…$/);assert.match(visibleText(card),/Dẫn cho: Rà câu hỏi về nhãn/);assert.equal(vietnamese.open,false);assert.doesNotMatch(visibleText(card),/Nội dung tham khảo còn nguyên vẹn/);vietnamese.open=true;
 assert.equal(vietnamese.children[1].textContent,full);assert.match(visibleText(vietnamese),/Nội dung tham khảo còn nguyên vẹn/);const original=card.children.find(n=>n.className==='source-original'&&n.children[0]?.textContent==='Xem nguyên văn tiếng Anh');assert.equal(original.open,false);original.open=true;assert.match(visibleText(original),/Original English evidence wording\./);
 const warnings=h.get('panel-sources').children.find(n=>n.className==='source-warnings');assert.equal(warnings.open,false);assert.doesNotMatch(visibleText(warnings),/Cần rà giới hạn/);warnings.open=true;assert.match(visibleText(warnings),/Cần rà giới hạn/);assert.equal(JSON.stringify(artifact),before);
});

test('History shows the actual question and local export uses immutable saved product and canonical steps after draft edits',async()=>{
 const artifact=sourceReport(translate);artifact.report.next_steps=[{id:'clarify_import_roles',title:'Làm rõ các vai nhập khẩu',reason:'Đối chiếu riêng từng vai.',evidence_ids:['SRC-1']}];
 const h=withArtifact(artifact);const originalQuestion='Lô trà sen này cần chuẩn bị nhãn và đăng ký FDA như thế nào?';h.setRun({...runData('succeeded'),question:originalQuestion,case_summary:{sku:'TEST-TRASEN-100-001',name:'Trà sen 100 g'}});let captured;h.setApp({prepareExpertDraft(value){captured=value;return true;}});h.mount();await settle();
 assert.match(visibleText(h.get('history').children[0]),/Lô trà sen này cần chuẩn bị nhãn/);await h.get('history').children[0].emit('click');await settle();
 h.get('sku').value='UNSENT-OTHER-SKU';h.get('name').value='Bản nhập sản phẩm khác';h.get('research-question').value='Câu hỏi đang soạn khác.';await h.get('research-question').emit('input');await h.get('prepare-local-draft').emit('click');
 assert.equal(captured.question,originalQuestion);assert.equal(captured.product.sku,'TEST-TRASEN-100-001');assert.equal(captured.product.name,'Trà sen 100 g');assert.equal(captured.artifact.artifact_id,artifact.artifact_id);assert.equal(captured.artifact.content_sha256,artifact.content_sha256);assert.deepEqual(JSON.parse(JSON.stringify(captured.artifact.report.next_steps)),artifact.report.next_steps);assert.notEqual(captured.artifact,artifact);
 assert.equal(h.get('context-details').open,false);assert.equal(h.get('result-context').hidden,false);assert.equal(h.calls.some(c=>c.url==='/api/cases'||c.body?.name==='nmate_shipment_readiness_start'),false);assert.equal(h.get('error-box').hidden,true);
});

test('A long valid assessment shows complete opening sentences and preserves all 120 words and the same three canonical actions',async()=>{
 const artifact=sourceReport(translate);const opening='Lô trà sen này còn thiếu dữ kiện để xác định yêu cầu đăng ký và nhãn. Nguồn hiện có chỉ hỗ trợ chuẩn bị trao đổi với chuyên gia.';const filler='Phần nhận định bổ sung giữ nguyên ngữ cảnh và giới hạn đối chiếu của lô hàng';const openingWords=opening.split(/\s+/).length;artifact.report.summary=opening+' '+Array.from({length:120-openingWords},(_,i)=>filler.split(' ')[i%filler.split(' ').length]).join(' ')+'.';
 assert.equal(artifact.report.summary.split(/\s+/).length,120);assert.ok(artifact.report.summary.length<2000);artifact.report.next_steps=[{id:'clarify_import_roles',title:'Làm rõ vai IOR và FSVP',reason:'Xác nhận riêng từng vai.',evidence_ids:[]},{id:'clarify_delivery_terms',title:'Chốt điều kiện và điểm giao',reason:'Ghi rõ phạm vi báo cước.',evidence_ids:[]},{id:'expert_preparation_review',title:'Rà hồ sơ đăng ký và nhãn FDA',reason:'Đối chiếu hồ sơ sản phẩm.',evidence_ids:['SRC-1']}];
 const before=JSON.stringify(artifact),h=withArtifact(artifact);await completed(h);assert.equal(h.get('summary-brief').textContent,opening);assert.ok(artifact.report.summary.startsWith(h.get('summary-brief').textContent));assert.equal(h.get('legacy-label').hidden,true);const full=h.get('summary');assert.equal(full.textContent,artifact.report.summary);assert.equal(full.parentNode.open,false);assert.equal(full.parentNode.children[0].textContent,'Đọc đầy đủ nhận định AI');
 const steps=h.get('panel-next').children;assert.equal(steps.length,3);assert.deepEqual(Array.from(steps,s=>s.dataset.stepId),artifact.report.next_steps.map(s=>s.id));for(const step of artifact.report.next_steps)assert.match(visibleText(h.get('panel-next')),new RegExp(step.title));full.parentNode.open=true;assert.match(visibleText(full.parentNode),/Phần nhận định bổ sung/);assert.equal(JSON.stringify(artifact),before);
});

test('A single long assessment sentence gets an explicit word-boundary preview with unchanged full text',async()=>{
 const artifact=sourceReport(translate);artifact.report.summary=('Dữ kiện riêng của lô trà cần đối chiếu cùng chuyên gia và nguồn đã đọc '.repeat(7)).trim()+'.';assert.ok(artifact.report.summary.split(/\s+/).length<=160);const h=withArtifact(artifact);await completed(h);const preview=h.get('summary-brief').textContent;assert.match(preview,/…$/);const exactPrefix=preview.slice(0,-1);assert.ok(artifact.report.summary.startsWith(exactPrefix));assert.equal(artifact.report.summary[exactPrefix.length],' ');assert.ok(preview.length<=281);assert.equal(h.get('summary').textContent,artifact.report.summary);assert.equal(h.get('summary').parentNode.open,false);assert.equal(h.get('legacy-label').hidden,true);
});

test('Invalid model output has a Vietnamese validation explanation and never triggers a hidden paid retry',async()=>{
 const h=harness();h.setRun({...runData('failed'),error:{code:'MODEL_OUTPUT_INVALID',message:'Internal model output gate detail.'}});h.mount();await settle();await h.submit();assert.equal(h.get('error-title').textContent,'Câu trả lời AI chưa đạt kiểm tra');assert.match(visibleText(h.get('error-box')),/đã kết thúc/);assert.match(visibleText(h.get('error-box')),/lượt AI mới có thể phát sinh phí/);assert.doesNotMatch(visibleText(h.get('error-box')),/cấu hình|Internal model output gate detail|MODEL_OUTPUT_INVALID/);assert.doesNotMatch(h.get('stage-label').textContent,/đang xử lý/i);assert.equal(h.get('result').hidden,true);assert.equal(h.get('research-question').value,'Lô hàng này cần chuẩn bị gì để gửi sang Mỹ?');await h.tick();assert.equal(h.calls.filter(c=>c.body?.name==='nmate_shipment_readiness_start').length,1);assert.equal(h.get('error-original').textContent,'Internal model output gate detail.');
});

test('Source timestamps have the same explicit Vietnamese date order and UTC+7 time on every locale',async()=>{
 const a=sourceReport({...translate,source_date:'2026-10-16'}),before=JSON.stringify(a),h=withArtifact(a);h.renderArtifact(a);await settle();
 const content=h.get('evidence-SRC-1').textContent;assert.match(content,/Đọc nguồn lúc 17\/10\/2026 17:00/);assert.match(content,/Ngày nguồn: 16\/10\/2026/);
 assert.equal(JSON.stringify(a),before);assert.equal(h.calls.length,0);
});

test('Repaired priority-only output labels the rule-based assessment and keeps three canonical actions without an AI quote or extra call',async()=>{
 const a=sourceReport(translate);Object.assign(a.report,{mode:'llm',llm_used:true,model_provider:'anthropic',summary_origin:'rule_based'});
 a.report.next_steps=Array.from({length:3},(_,i)=>({id:'step-'+i,title:'Việc chuẩn đã lưu '+(i+1),reason:'Đối chiếu dữ kiện của cùng bản nghiên cứu.',evidence_ids:[]}));
 const before=JSON.stringify(a),h=withArtifact(a);h.renderArtifact(a);await settle();
 assert.equal(h.get('answer-author').textContent,'nMate · nhận định theo quy tắc');assert.equal(h.get('summary-origin-note').hidden,false);
 assert.match(visibleText(h.get('result')),/Phần AI có danh sách ưu tiên nên chưa được dùng/);assert.match(visibleText(h.get('result')),/không gọi AI thêm/);
 assert.doesNotMatch(h.get('answer-author').textContent,/tổng hợp bằng Claude/);assert.equal(h.get('summary').textContent,a.report.summary);
 for(const step of a.report.next_steps)assert.ok(h.get('panel-next').textContent.includes(step.title));
 assert.equal(JSON.stringify(a),before);assert.equal(h.calls.length,0);
});

test('Embedded report adapter reuses the real Vietnamese renderer without mounting intake, reading sessions or starting a model',async()=>{
 const a=sourceReport(translate),before=JSON.stringify(a),h=withArtifact(a);h.renderArtifact(a,{question:'Câu hỏi của đúng bản đã lưu',product:{sku:'SAVED-TEA',name:'Trà sen'}});await settle();assert.equal(h.element.children.length,1);assert.equal(h.element.children[0].id,'result');assert.equal(h.get('research-form'),null);assert.equal(h.get('summary-brief').textContent,a.report.summary);assert.match(h.get('evidence-SRC-1').textContent,/Trích đoạn tiếng Việt/);assert.equal(h.calls.length,0);assert.equal(JSON.stringify(a),before);
});

test('Each embedded canonical action opens its own task with the clicked control as return anchor and no model call',async()=>{
 const a=sourceReport(translate);a.report.next_steps=[{id:'clarify_import_roles',title:'Rà hai vai nhập khẩu',reason:'Ghi riêng IOR và FSVP.',evidence_ids:[]},{id:'expert_preparation_review',title:'Rà câu hỏi nhãn',reason:'Giữ phần thiếu căn cứ.',evidence_ids:['SRC-1']}];const before=JSON.stringify(a),h=withArtifact(a),clicked=[];
 h.renderArtifact(a,{onSaveTask:(id,trigger)=>clicked.push({id,trigger})});await settle();
 const cards=h.get('panel-next').children;assert.equal(cards.length,Math.min(a.report.next_steps.length,3));
 for(let i=0;i<cards.length;i++){
  const save=cards[i].children[1];assert.equal(save.textContent,'Lưu việc');await save.emit('click');
  assert.equal(clicked[i].id,a.report.next_steps[i].id);assert.equal(clicked[i].trigger,save);
 }
 assert.equal(h.calls.length,0);assert.equal(JSON.stringify(a),before);
});

test('Legacy action lists remain readable without advertising unsupported per-step task saving',async()=>{
 const a=sourceReport(translate);a.report.next_steps=Array.from({length:5},(_,i)=>({id:'OLD-'+i,title:'Việc cũ '+i,reason:'Giữ nội dung bản cũ.',evidence_ids:[]}));
 const before=JSON.stringify(a),h=withArtifact(a);h.renderArtifact(a,{onSaveTask:()=>assert.fail('Legacy task dispatch is unsupported')});await settle();
 const panel=h.get('panel-next');assert.equal(panel.children[0].tagName,'DETAILS');assert.ok(h.get('panel-next').textContent.includes('Việc cũ 4'));
 assert.equal(panel.all().filter(x=>x.className==='step-save-button').length,0);assert.equal(JSON.stringify(a),before);assert.equal(h.calls.length,0);
});
