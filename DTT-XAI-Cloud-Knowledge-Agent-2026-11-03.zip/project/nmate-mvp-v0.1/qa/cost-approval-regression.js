/* Native DOM regression probes; can be opened with a localhost static server. */
(async()=>{
  const results=[],fixture=window.costFixture,host=document.getElementById('policy-cost-approval');
  const assert=(ok,message)=>{if(!ok)throw Error(message);};
  const until=async predicate=>{const end=Date.now()+3000;while(!predicate()){if(Date.now()>end)throw Error('Timed out waiting for DOM state');await new Promise(resolve=>setTimeout(resolve,0));}};
  const owner=actor=>{fixture.actor=actor;window.dispatchEvent(new CustomEvent('nmate:render',{detail:{authenticated:true,account_id:actor,enterprise_id:actor+'-enterprise',view:'chat',csrf:'TEST-CSRF'}}));};
  const click=kind=>{const node=host.querySelector('[data-cost="'+kind+'"]');assert(node&&!node.disabled,'Missing/enabled action '+kind);node.click();};
  const test=async(name,run)=>{try{await run();results.push({name,status:'pass'});}catch(error){results.push({name,status:'fail',message:error.message});}};
  owner('TEST-A');await until(()=>host.querySelector('details'));
  await test('Initial card identifies S3/S4 and estimates are not an invoice',async()=>{
    assert(host.textContent.includes('S3/S4'),'Inputs must be named before preview');
    assert(host.textContent.includes('chưa phải hóa đơn'),'Missing billing disclaimer');
  });
  await test('Expanded terms survive preview, including all four finance fields',async()=>{
    host.querySelector('details').open=true;click('preview');await until(()=>host.querySelector('[data-cost="consent"]'));
    assert(host.querySelector('details').open,'Preview collapsed the previously open terms');
    const text=host.querySelector('details').textContent;
    for(const term of ['Opus 5.5','0,5 USD','0,217632 USD','Hiệu lực đến'])assert(text.includes(term),'Missing '+term);
  });
  await test('Checking and unchecking retains focus/node and announces button state',async()=>{
    let checkbox=host.querySelector('[data-cost="consent"]');checkbox.focus();
    const live=host.querySelector('[data-cost-live]');assert(live&&live.getAttribute('aria-live')==='polite','Stable live region missing');
    checkbox.checked=true;checkbox.dispatchEvent(new Event('change',{bubbles:true}));
    assert(checkbox===host.querySelector('[data-cost="consent"]')&&document.activeElement===checkbox,'Consent rerender removed checkbox/focus');
    assert(!host.querySelector('[data-cost="approve"]').disabled&&live.textContent.includes('đã mở'),'No enabled announcement');
    checkbox.checked=false;checkbox.dispatchEvent(new Event('change',{bubbles:true}));
    assert(host.querySelector('[data-cost="approve"]').disabled&&live.textContent.includes('đã khóa'),'No disabled announcement');
    assert(host.querySelector('details').open,'Consent collapsed terms');
  });
  await test('Reading status retains expansion and stable live node; never approves',async()=>{
    const live=host.querySelector('[data-cost-live]');click('refresh');await until(()=>host.querySelector('[data-cost="preview"]')?.disabled===false);
    assert(host.querySelector('details').open,'Status refresh collapsed terms');
    assert(host.querySelector('[data-cost-live]')===live,'Live region replaced during async render');
    assert(!fixture.calls.some(call=>call.url.endsWith('/approve')),'Unexpected approval command');
  });
  await test('Preview error preserves terms and presents one error',async()=>{
    fixture.failPreview=true;click('preview');await until(()=>host.querySelector('[role="alert"]'));
    assert(host.querySelector('details').open,'Error collapsed terms');
    assert(host.querySelectorAll('[role="alert"]').length===1,'Duplicate error');fixture.failPreview=false;
  });
  await test('Old preview cannot cross an account change; private announcements cleared',async()=>{
    fixture.delayed='preview';click('preview');await until(()=>fixture.pendingRelease);
    owner('TEST-B');fixture.pendingRelease();fixture.pendingRelease=null;
    await until(()=>!host.textContent.includes('TEST ONLY A'));await new Promise(resolve=>setTimeout(resolve,0));
    assert(!host.querySelector('[data-cost="consent"]')&&!host.querySelector('[data-cost-live]'),'Old preview/live region survived account switch');
    owner('TEST-A');await until(()=>host.querySelector('[data-cost="preview"]'));
    assert(!host.querySelector('details').open,'Disclosure from previous actor scope survived');
  });
  const summary={tests:results.length,passed:results.filter(item=>item.status==='pass').length,failed:results.filter(item=>item.status==='fail').length,paid_calls:0,approve_requests:fixture.calls.filter(call=>call.url.endsWith('/approve')).length,results};
  const output=document.getElementById('test-results');output.textContent=JSON.stringify(summary,null,2);output.className=summary.failed?'fail':'pass';output.dataset.complete='true';
})();
