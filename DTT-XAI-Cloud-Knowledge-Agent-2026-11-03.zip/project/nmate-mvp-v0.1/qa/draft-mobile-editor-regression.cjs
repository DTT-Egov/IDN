/* Mobile draft user behavior through the actual assistant implementation.
 * Controlled local DOM/fetch adapters only: no HTTP, browser or paid provider.
 * Real viewport geometry, scrolling and keyboard layout require the CUA flow. */
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {test}=require('node:test'),{createRequire}=require('node:module');
const filename=path.join(__dirname,'assistant-regression.cjs');
const sandbox={require:id=>id==='node:test'?{test(){}}:createRequire(filename)(id),__dirname,__filename:filename,console:{log(){},error:console.error},URL,Blob,setImmediate};
vm.runInNewContext(fs.readFileSync(filename,'utf8')+'\nglobalThis.mobileParts={harness,settle,savedConversation,openSaved,openReport,Element,copy};',sandbox,{filename});
const A=sandbox.mobileParts;
/* The shared small adapter predates portal restoration. Model the browser's
 * native sibling lookup so the placement check exercises the same contract. */
Object.defineProperty(A.Element.prototype,'nextSibling',{configurable:true,get(){if(!this.parentNode)return null;return this.parentNode.children[this.parentNode.children.indexOf(this)+1]||null;}});
const hasClass=(node,name)=>node.className.split(/\s+/).includes(name);
async function draft(options={}){
 const h=A.harness({conversation:A.savedConversation(),...options});
 await A.openSaved(h);await A.openReport(h);
 await h.click('Soạn nội dung để tự gửi');
 return h;
}

test('Draft opens as a preview; explicit editing focuses one separate task and returns to its exact report position',async()=>{
 const h=await draft(),card=h.get('a-inline-action'),parent=card.parentNode,after=new A.Element('p');
 after.textContent='Đoạn báo cáo sau bản nháp';parent.append(after);
 assert.equal(h.get('a-draft-editor').hidden,true);
 assert.equal(hasClass(h.root,'a-draft-editing'),false);
 const calls=h.calls.length;
 await h.click('Sửa');
 assert.ok(card.parentNode===h.root,'The editor must leave the nested report, not retain a second scroll surface.');
 assert.equal(hasClass(h.root,'a-draft-editing'),true);
 assert.equal(hasClass(card,'a-draft-focused'),true);
 assert.equal(h.get('a-draft-editor').hidden,false);
 assert.equal(h.get('a-draft-preview').hidden,true);
 assert.ok(h.get('a-draft-body').focusCalls.length>0);
 await h.click('Xong, xem lại');
 assert.ok(card.parentNode===parent,'Review must return to the original report parent.');
 assert.equal(parent.children.indexOf(card)+1,parent.children.indexOf(after));
 assert.equal(hasClass(h.root,'a-draft-editing'),false);
 assert.equal(hasClass(card,'a-draft-focused'),false);
 assert.equal(h.get('a-draft-preview').hidden,false);
 assert.equal(h.calls.length,calls,'Opening and reviewing an editor must never issue another request.');
});

test('Long Vietnamese subject and body expand with input, then shrink after deletion instead of introducing field scrolling',async()=>{
 const h=await draft(),title=h.get('a-draft-title'),body=h.get('a-draft-body');
 assert.equal(title.tagName,'TEXTAREA','A long subject needs multiple visible lines.');
 for(const field of [title,body])Object.defineProperty(field,'scrollHeight',{configurable:true,get(){return 52+Math.ceil(this.value.length/28)*26;}});
 await h.click('Sửa');
 const calls=h.calls.length;
 for(const [field,value]of [[title,'Nhờ kiểm tra trà sen Tây Hồ gửi New York — chủ đề dài cần đọc trọn vẹn '.repeat(5)],[body,'Mình muốn xác nhận thông tin lô trà sen.\n'.repeat(32)]]){
  field.value=value;await field.emit('input');
  const expanded=Number.parseFloat(field.style.height);
  assert.ok(expanded>=field.scrollHeight,'The whole field content must have vertical room.');
  field.value='Đã rút gọn';await field.emit('input');
  assert.ok(Number.parseFloat(field.style.height)<expanded,'Deleting content should give the editor space back.');
 }
 assert.equal(h.calls.length,calls);
});

test('A field that rewraps when the editor scrollbar appears is fully fitted before typing resumes',async()=>{
 const h=await draft(),title=h.get('a-draft-title'),body=h.get('a-draft-body'),calls=h.calls.length;
 /* Controlled geometry models an engine without stable scrollbar gutters:
  * growing the body introduces the editor scrollbar and wraps one more line.
  * This is not a browser layout test; CUA must verify the actual 320/390 flow. */
 const narrowed=()=>Number.parseFloat(body.style.height)>=498;
 Object.defineProperty(body,'scrollHeight',{configurable:true,get(){return narrowed()?522:496;}});
 Object.defineProperty(title,'scrollHeight',{configurable:true,get(){return narrowed()?116:90;}});
 await h.click('Sửa');
 assert.ok(Number.parseFloat(body.style.height)>=body.scrollHeight+2,'The newly wrapped final body line must have room.');
 assert.ok(Number.parseFloat(title.style.height)>=title.scrollHeight+2,'The subject must also fit after editor width changes.');
 assert.equal(h.calls.length,calls);
});

test('Saving while focused keeps the edited text and immutable source, then review shows both fields literally',async()=>{
 let saved;
 const h=await draft({saveDraft:value=>(saved=A.copy(value),{id:'LOCAL-FOCUSED'})});
 await h.click('Sửa');
 const calls=h.calls.length,title='Trà sen Tây Hồ — chủ đề đã sửa',body='Mình cần xác nhận tên bên nhập khẩu.\n<script>chỉ là văn bản</script>\nMình tự gửi khi đã kiểm tra.';
 h.get('a-draft-title').value=title;await h.get('a-draft-title').emit('input');
 h.get('a-draft-body').value=body;await h.get('a-draft-body').emit('input');
 await h.get('a-draft-save').emit('click');
 assert.ok(saved);assert.equal(saved.title,title);assert.equal(saved.body,body);
 assert.equal(saved.artifact.artifact_id,'ART-TEA');assert.equal(saved.artifact.content_sha256,'IMMUTABLE-HASH');
 assert.equal(hasClass(h.root,'a-draft-editing'),true,'Saving must not discard the active editor.');
 assert.match(h.get('a-draft-status').textContent,/Đã lưu.*chưa gửi/);
 await h.click('Xong, xem lại');
 assert.ok(h.get('a-draft-preview').textContent.includes(title));assert.ok(h.get('a-draft-preview').textContent.includes(body));
 assert.equal(h.all().some(node=>node.tagName==='SCRIPT'),false);
 assert.equal(h.calls.length,calls,'Local save must not call the model or server.');
});

test('Closing a focused editor restores the assistant and action focus without dispatching or changing the report',async()=>{
 const h=await draft(),source=JSON.stringify(h.renders[0].artifact),calls=h.calls.length;
 const trigger=h.all().find(node=>node.tagName==='BUTTON'&&node.textContent==='Soạn nội dung để tự gửi');
 await h.click('Sửa');
 const close=h.all().find(node=>node.tagName==='BUTTON'&&node.textContent==='Đóng');
 assert.ok(close);assert.ok(h.get('a-draft-save').parentNode.children.includes(close),'Close belongs to the persistent action row.');
 await close.emit('click');
 assert.equal(h.get('a-inline-action'),null);
 assert.equal(hasClass(h.root,'a-draft-editing'),false);
 assert.ok(trigger.focusCalls.length>0);
 assert.equal(JSON.stringify(h.renders[0].artifact),source);
 assert.equal(h.calls.length,calls);
});

test('A navigation unmount removes focused-editor state; detached old buttons cannot save into the new screen',async()=>{
 let saves=0;const h=await draft({saveDraft:()=>{saves++;return{id:'LOCAL'};}});
 await h.click('Sửa');const oldRoot=h.root,oldSave=h.get('a-draft-save');
 h.mount('documents');await A.settle();
 assert.equal(hasClass(oldRoot,'a-draft-editing'),false);
 assert.equal(hasClass(h.root,'a-draft-editing'),false);
 assert.equal(h.get('a-draft-editor'),null);
 await oldSave.emit('click');
 assert.equal(saves,0);
});

test('Escape returns to a focusable preview with the current unsaved content intact',async()=>{
 const h=await draft();await h.click('Sửa');
 h.get('a-draft-body').value='Mình vừa sửa và muốn xem lại trước khi lưu.';
 const calls=h.calls.length,card=h.get('a-inline-action');let prevented=false;
 for(const listener of card.listeners.get('keydown')||[])await listener({key:'Escape',preventDefault(){prevented=true;}});
 assert.equal(prevented,true);assert.equal(hasClass(h.root,'a-draft-editing'),false);
 const preview=h.get('a-draft-preview');
 assert.equal(preview.hidden,false);assert.equal(preview.tabIndex,-1,'The preview section must accept real browser focus.');
 assert.ok(preview.focusCalls.length>0);assert.match(preview.textContent,/Mình vừa sửa/);
 assert.equal(h.calls.length,calls);
});
