/* Run: node qa/live-research-regression.cjs
 * Executes the real integration script in Node VM with controlled fetch/timers
 * and a small DOM adapter. No HTTP, credentials, browser or paid model calls.
 * Covers state/async/data regressions; does not verify layout/native validation.
 */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createHash } = require('node:crypto');
const { test } = require('node:test');

const source = fs.readFileSync(path.join(__dirname, '../src/live-research.js'), 'utf8');
const sourceHash = createHash('sha256').update(source).digest('hex');
console.log('Source SHA-256: ' + sourceHash);
const copy = value => JSON.parse(JSON.stringify(value));
const baseContext = () => ({
  profile: { name: 'MOCK DN A', sku: 'MOCK-SKU-A', product: 'MOCK Miến A', ingredients: 'Tinh bột, nước',
    processingDescription: 'Sấy khô', packSize: '250 g', shelfLife: '12 tháng', certifications: [], location: 'Hà Nội' },
  logistics: { quantity: '1.000 gói', cartonCount: '20', grossWeight: '255,5 kg', weight: '999 kg tính cước',
    origin: 'Hà Nội', destination: 'MOCK Mỹ', dimensions: '40 × 30 × 20', importer: 'Chưa rõ', fsvp: 'Chưa rõ' },
  market: 'us', route: 'importer',
});
const sessionData = { csrf_token: 'MOCK-CSRF', mode: 'llm', model_configured: true, model_provider: 'anthropic' };
const report = () => ({ summary: 'MOCK toàn văn tổng hợp. '.repeat(100), mode: 'llm', llm_used: true,
  model_provider: 'anthropic', model_name: 'claude-sonnet-5-5', readiness_status: 'needs_information',
  findings: [], unknowns: [], responsibilities: [], quote_information: [], next_steps: [], evidence: [], source_failures: [], warnings: [] });
const runData = (status = 'queued') => ({ run_id: 'MOCK-RUN-A', case_id: 'MOCK-CASE-A', profile_version: 1,
  status, stage: status === 'succeeded' ? 'completed' : status, artifact_id: status === 'succeeded' ? 'MOCK-ART-A' : null,
  created_at: '2026-10-17T10:00:00Z', cancel_requested: false });
const artifactData = () => ({ artifact_id: 'MOCK-ART-A', case_id: 'MOCK-CASE-A', profile_version: 1,
  report: report(), stale: false, model_routing: { requested_level: 'auto', selected_level: 'standard', reason: 'MOCK ca thông thường' } });

class Element {
  constructor(tag = 'div') {
    this.tagName = tag.toUpperCase(); this.children = []; this.parentNode = null; this.attributes = {};
    this.dataset = {}; this.style = {}; this.listeners = new Map(); this.id = ''; this.className = '';
    this.value = ''; this.type = ''; this.checked = false; this.disabled = false; this.hidden = false; this.open = false;
    this.focusCalls = []; this.scrollCalls = [];
    this._text = ''; this._html = '';
    this.classList = {
      add: (...names) => { this.className = [...new Set([...this.className.split(/\s+/), ...names])].filter(Boolean).join(' '); },
      remove: (...names) => { this.className = this.className.split(/\s+/).filter(n => !names.includes(n)).join(' '); },
      toggle: (name, enabled) => { const has = this.className.split(/\s+/).includes(name); const use = enabled === undefined ? !has : enabled; this.classList[use ? 'add' : 'remove'](name); return use; },
    };
  }
  append(...nodes) { for (const child of nodes) { if (child.parentNode) child.parentNode.children = child.parentNode.children.filter(n => n !== child); child.parentNode = this; this.children.push(child); } }
  insertBefore(child, before) { assert.equal(before.parentNode, this); if (child.parentNode) child.parentNode.children = child.parentNode.children.filter(n => n !== child); child.parentNode = this; this.children.splice(this.children.indexOf(before), 0, child); }
  replaceChildren(...nodes) { for (const old of this.children) old.parentNode = null; this.children = []; this._text = ''; this.append(...nodes); }
  set textContent(value) { this.replaceChildren(); this._text = String(value); }
  get textContent() { return this._text + this.children.map(n => n.textContent).join(' '); }
  set innerHTML(value) {
    this.replaceChildren(); this._html = value; const stack = [this];
    for (const token of value.matchAll(/<\/?([a-z][\w-]*)([^>]*)>|([^<]+)/gi)) {
      if (token[3]) { const text = new Element('#text'); text._text = token[3]; stack.at(-1).append(text); continue; }
      if (token[0].startsWith('</')) { if (stack.length > 1) stack.pop(); continue; }
      const node = new Element(token[1]);
      for (const match of token[2].matchAll(/([\w-]+)(?:="([^"]*)")?/g)) node.setAttribute(match[1], match[2] ?? '');
      stack.at(-1).append(node);
      if (!/^(?:input|br|hr|img|meta|link)$/i.test(token[1])) stack.push(node);
    }
  }
  get innerHTML() { return this._html; }
  setAttribute(key, value) { this.attributes[key] = String(value); if (key === 'id') this.id = value; else if (key === 'class') this.className = value; else if (key === 'value') this.value = value; else if (key === 'type') this.type = value; else if (key === 'checked') this.checked = true; else if (key === 'open') this.open = true; else if (key === 'hidden') this.hidden = true; else if (key === 'disabled') this.disabled = true; else if (key.startsWith('data-')) this.dataset[key.slice(5)] = value; }
  addEventListener(type, fn) { const list = this.listeners.get(type) || []; list.push(fn); this.listeners.set(type, list); }
  async emit(type) { await Promise.all((this.listeners.get(type) || []).map(fn => fn({ target: this, preventDefault() {} }))); }
  reportValidity() { return true; }
  scrollIntoView(options) { this.scrollCalls.push(copy(options)); }
  focus(options) { this.focusCalls.push(copy(options)); }
  all() { return this.children.flatMap(n => [n, ...n.all()]); }
  querySelector(selector) { if (selector.startsWith('#')) return this.all().find(n => n.id === selector.slice(1)) || null; const id = selector.match(/^\[id="([^"]+)"\]$/); return id ? this.all().find(n => n.id === id[1]) || null : null; }
  querySelectorAll(selector) {
    const all = this.all();
    if (selector === '[data-panel]') return all.filter(n => n.dataset.panel);
    if (selector === '.report-panel') return all.filter(n => n.className.split(/\s+/).includes('report-panel'));
    if (selector.startsWith('#research-form')) return all.filter(n => {
      if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(n.tagName)) return false;
      let parent = n.parentNode; while (parent && parent.id !== 'research-form') parent = parent.parentNode;
      if (!parent) return false;
      return !selector.includes(':not(') || n.tagName === 'TEXTAREA' || n.tagName === 'INPUT' && n.type !== 'checkbox' && !('readonly' in n.attributes);
    });
    return [];
  }
}

function deferred() { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }
async function settle() { for (let i = 0; i < 8; i++) await new Promise(resolve => setImmediate(resolve)); }
function harness(custom = null) {
  const calls = [], timers = new Map(); let timerId = 0, uuid = 0, run = runData();
  const normal = (url, options = {}) => {
    if (url === '/api/session') return copy(sessionData);
    if (url === '/api/runs') return [copy(run)];
    if (url === '/api/cases') return { ...JSON.parse(options.body), case_id: 'MOCK-CASE-A', version: 1 };
    if (url === '/api/mcp/call') {
      const tool = JSON.parse(options.body);
      if (tool.name === 'nmate_shipment_readiness_start') return { ok: true, data: copy(run) };
      if (tool.name === 'nmate_research_get') return { ok: true, data: copy(run) };
      if (tool.name === 'nmate_artifact_get') return { ok: true, data: artifactData() };
      throw new Error('Unexpected tool ' + tool.name);
    }
    throw new Error('Unexpected mock URL ' + url);
  };
  const sandbox = {
    console, Date, Math, JSON, Set, URL, location: { protocol: 'http:' },
    document: { createElement: tag => new Element(tag) },
    crypto: { randomUUID: () => 'MOCK-UUID-' + ++uuid },
    fetch: async (url, options = {}) => { calls.push({ url, options, body: options.body ? JSON.parse(options.body) : null }); const data = await (custom ? custom(url, options, normal) : normal(url, options)); return data && typeof data.json === 'function' ? data : { ok: true, json: async () => data }; },
    setTimeout: fn => { const id = ++timerId; timers.set(id, fn); return id; },
    clearTimeout: id => timers.delete(id), addEventListener() {}, removeEventListener() {},
  };
  sandbox.window = sandbox; vm.runInNewContext(source, sandbox, { filename: 'live-research.js', timeout: 3000 });
  let container;
  return {
    calls, timers, setRun(value) { run = copy(value); }, setApp(api) { sandbox.NMateApp = api; },
    mount(context = baseContext()) { container = new Element(); sandbox.NMateLive.mount(container, copy(context)); return container; },
    renderArtifact(artifact, context = {}) { container = new Element(); sandbox.NMateLive.renderArtifact(container, copy(artifact), context); return container; },
    unmount() { sandbox.NMateLive.unmount(); },
    get element() { return container; },
    get(id) { return container.querySelector('#' + id); },
    async submit() { for (const id of ['confirm-profile', 'consent-research', 'consent-model']) this.get(id).checked = true; return this.get('research-form').emit('submit'); },
    async tick() { const pending = [...timers]; timers.clear(); for (const [, fn] of pending) await fn(); await settle(); },
  };
}

test('Rejected initial session can reconnect without reload and preserves the draft', async () => {
  let sessions = 0;
  const h = harness((url, options, normal) => { if (url === '/api/session' && ++sessions === 1) throw new Error('MOCK offline'); return normal(url, options); });
  h.mount(); await settle();
  assert.equal(h.get('start-button').disabled, true);
  assert.equal(h.get('reconnect-session').hidden, false);
  h.get('name').value = 'MOCK bản nhập cần giữ';
  await h.get('reconnect-session').emit('click'); await settle();
  assert.equal(sessions, 2); assert.equal(h.get('name').value, 'MOCK bản nhập cần giữ');
  assert.equal(h.get('start-button').disabled, false); assert.equal(h.get('error-box').hidden, true);
  assert.equal(h.calls.some(c => c.url === '/api/cases'), false);
});

test('Rejected session is not retained across unmount/remount', async () => {
  let sessions = 0;
  const h = harness((url, options, normal) => { if (url === '/api/session' && ++sessions === 1) throw new Error('MOCK offline'); return normal(url, options); });
  h.mount(); await settle(); h.unmount(); h.mount(); await settle();
  assert.equal(sessions, 2); assert.equal(h.get('start-button').disabled, false);
});

test('Missing model consent prevents case creation and all research writes', async () => {
  const h = harness(); h.mount(); await settle();
  h.get('confirm-profile').checked = true; h.get('consent-research').checked = true;
  h.get('consent-model').checked = false; await h.get('research-form').emit('submit');
  assert.equal(h.get('error-code').textContent, 'MODEL_CONSENT_REQUIRED');
  assert.equal(h.get('run-status').textContent, 'Chưa bắt đầu');
  assert.equal(h.calls.some(c => c.options.method === 'POST'), false);
});

test('Consent error is revealed, focused and scrolled into view without losing entered fields', async () => {
  const h = harness(); h.mount(); await settle();
  h.get('name').value = 'MOCK tên vừa nhập trên mobile';
  h.get('quantity_units').value = '1234'; h.get('gross_weight_kg').value = '321.5';
  h.get('confirm-profile').checked = true; h.get('consent-research').checked = true;
  h.get('consent-model').checked = false;
  const before = h.element.querySelectorAll('#research-form input,#research-form textarea,#research-form select')
    .map(el => ({ id: el.id, value: el.value, checked: el.checked }));
  await h.get('research-form').emit('submit');
  const box = h.get('error-box');
  assert.equal(box.hidden, false); assert.equal(box.attributes.tabindex, '-1');
  assert.equal(h.get('error-code').textContent, 'MODEL_CONSENT_REQUIRED');
  assert.deepEqual(box.focusCalls, [{ preventScroll: true }]);
  assert.deepEqual(box.scrollCalls, [{ behavior: 'smooth', block: 'center' }]);
  assert.deepEqual(h.element.querySelectorAll('#research-form input,#research-form textarea,#research-form select')
    .map(el => ({ id: el.id, value: el.value, checked: el.checked })), before);
  assert.equal(h.calls.some(c => c.url === '/api/cases'), false);
  assert.equal(h.calls.some(c => c.body?.name === 'nmate_shipment_readiness_start'), false);
});

test('Expired session reconnects and reads the existing run without repeating a paid start', async () => {
  let sessions = 0, reads = 0;
  const h = harness((url, options, normal) => {
    if (url === '/api/session') return { ...sessionData, csrf_token: 'MOCK-CSRF-' + ++sessions };
    if (url === '/api/mcp/call' && JSON.parse(options.body).name === 'nmate_research_get' && ++reads === 1)
      return { ok: false, json: async () => ({ ok: false, error: { code: 'SESSION_REQUIRED', message: 'MOCK hết phiên' } }) };
    return normal(url, options);
  });
  h.mount(); await settle(); await h.submit();
  assert.equal(h.get('error-code').textContent, 'SESSION_REQUIRED');
  assert.equal(h.get('reconnect-session').hidden, false);
  h.setRun(runData('succeeded')); await h.get('reconnect-session').emit('click'); await settle();
  assert.equal(sessions, 2); assert.equal(h.get('result').hidden, false);
  assert.equal(h.calls.filter(c => c.url === '/api/cases').length, 1);
  assert.equal(h.calls.filter(c => c.body?.name === 'nmate_shipment_readiness_start').length, 1);
  const lastRead = h.calls.filter(c => c.body?.name === 'nmate_research_get').at(-1);
  assert.equal(lastRead.options.headers['X-CSRF-Token'], 'MOCK-CSRF-2');
});

test('An ambiguous network error at MCP start is honest, preserves the prior report and never auto-restarts', async () => {
  let startCount = 0, offline = false;
  const h = harness((url, options, normal) => {
    if (url === '/api/mcp/call' && JSON.parse(options.body).name === 'nmate_shipment_readiness_start') {
      startCount++;
      if (offline) throw new Error('MOCK response lost after dispatch; server acceptance unknown');
    }
    return normal(url, options);
  });
  h.setRun(runData('succeeded')); h.mount(); await settle(); await h.submit();
  const priorSummary = h.get('summary').textContent, priorMeta = h.get('artifact-meta').textContent;
  offline = true; await h.submit();
  assert.equal(h.get('error-code').textContent, 'NETWORK_ERROR');
  assert.equal(h.get('run-status').textContent, 'Chưa nhận xác nhận từ máy chủ');
  assert.match(h.get('stage-label').textContent, /có thể đang xử lý/);
  assert.equal(h.get('reconnect-session').hidden, false);
  assert.equal(h.get('result').hidden, false); assert.equal(h.get('summary').textContent, priorSummary);
  assert.equal(h.get('artifact-meta').textContent, priorMeta);
  assert.equal(h.get('name').value, 'MOCK Miến A'); assert.equal(startCount, 2);
  await h.get('reconnect-session').emit('click'); await settle();
  assert.equal(startCount, 2, 'Reconnect may read status/history but must not dispatch paid research');
  const lostRequest = h.calls.filter(c => c.body?.name === 'nmate_shipment_readiness_start').at(-1).body.arguments;
  offline = false; await h.submit();
  const explicitRetry = h.calls.filter(c => c.body?.name === 'nmate_shipment_readiness_start').at(-1).body.arguments;
  assert.equal(explicitRetry.idempotency_key, lostRequest.idempotency_key, 'An explicit retry of an unconfirmed start must reuse its request key');
});

test('A disposed submission awaiting history cannot replace the new mount watcher', async () => {
  let histories = 0;
  const slowHistory = deferred();
  const h = harness((url, options, normal) => { if (url === '/api/runs' && ++histories === 2) return slowHistory.promise; return normal(url, options); });
  const old = h.mount(); await settle();
  const pendingSubmit = h.submit(); await settle();
  assert.equal(histories, 2);
  h.unmount(); h.mount(); await settle();
  const getCalls = () => h.calls.filter(c => c.body?.name === 'nmate_research_get').length;
  assert.equal(getCalls(), 1); assert.equal(h.timers.size, 1);
  const oldHistory = old.querySelector('#history').textContent;
  slowHistory.resolve([runData()]); await pendingSubmit; await settle();
  assert.equal(getCalls(), 1); assert.equal(h.timers.size, 1);
  assert.equal(old.querySelector('#history').textContent, oldHistory);
  h.setRun(runData('succeeded')); await h.tick();
  assert.equal(h.get('result').hidden, false); assert.equal(h.get('run-status').textContent, 'Đã có bản nghiên cứu');
});

test('An in-flight poll resolved after unmount cannot overwrite the new result', async () => {
  const slowPoll = deferred(); let reads = 0;
  const h = harness((url, options, normal) => {
    if (url === '/api/mcp/call' && JSON.parse(options.body).name === 'nmate_research_get' && ++reads === 1) return slowPoll.promise;
    return normal(url, options);
  });
  h.mount(); await settle(); const submit = h.submit(); await settle();
  h.unmount(); h.setRun(runData('succeeded')); h.mount(); await settle();
  assert.equal(h.get('result').hidden, false);
  slowPoll.resolve({ ok: true, data: runData('failed') }); await submit; await settle();
  assert.equal(h.get('run-status').textContent, 'Đã có bản nghiên cứu'); assert.equal(h.get('error-box').hidden, true);
});

test('Result and history identify the saved case/SKU and flag a changed source profile', async () => {
  const h = harness(); h.setRun(runData('succeeded')); h.mount(); await settle(); await h.submit();
  assert.match(h.get('artifact-meta').textContent, /MOCK-CASE-A.*SKU MOCK-SKU-A.*MOCK Miến A/);
  assert.match(h.get('history').textContent, /MOCK-CASE-A.*MOCK-SKU-A/);
  assert.equal(h.get('result-context').hidden, true);
  h.unmount(); const changed = baseContext(); changed.profile.name = 'MOCK DN B'; changed.profile.product = 'MOCK Sản phẩm B'; changed.profile.sku = 'MOCK-SKU-B';
  h.mount(changed); await settle();
  assert.match(h.get('profile-origin').textContent, /Hồ sơ 0.1 đã thay đổi/);
  assert.equal(h.get('confirm-profile').checked, false); assert.equal(h.get('consent-model').checked, false);
  assert.equal(h.get('result-context').hidden, false);
  assert.match(h.get('result-context').textContent, /không phải kết quả mới/);
  assert.match(h.get('artifact-meta').textContent, /MOCK-SKU-A/); assert.doesNotMatch(h.get('artifact-meta').textContent, /MOCK-SKU-B/);
  h.unmount(); h.mount(changed); await settle();
  assert.match(h.get('profile-origin').textContent, /Hồ sơ 0.1 đã thay đổi/);
});

test('Editing the current draft leaves the immutable result visibly tied to prior facts', async () => {
  const h = harness(); h.setRun(runData('succeeded')); h.mount(); await settle(); await h.submit();
  h.get('name').value = 'MOCK tên vừa sửa'; await h.get('name').emit('input');
  assert.equal(h.get('result-context').hidden, false); assert.equal(h.get('confirm-profile').checked, false);
  assert.doesNotMatch(h.get('artifact-meta').textContent, /tên vừa sửa/);
});

test('A historical result without local SKU context remains identified by case/version', async () => {
  const h = harness(); h.setRun(runData('succeeded')); h.mount(); await settle();
  const historyButton = h.get('history').children[0]; await historyButton.emit('click'); await settle();
  assert.match(h.get('artifact-meta').textContent, /Ca MOCK-CASE-A · Hồ sơ v1/);
  assert.doesNotMatch(h.get('artifact-meta').textContent, /SKU MOCK-SKU-A/);
  assert.equal(h.get('result-context').hidden, false);
});

test('A fresh page uses immutable run summaries for exact historical SKU/version without extra case reads', async () => {
  const historical = { ...runData('succeeded'), case_summary: { sku: 'MOCK-SKU-OLD', name: 'MOCK Miến tại lúc chạy', private: 'MOCK-DO-NOT-SHOW' } };
  const newer = { ...runData('queued'), run_id: 'MOCK-RUN-V2', profile_version: 2,
    case_summary: { sku: 'MOCK-SKU-NEW', name: 'MOCK Miến đã đổi phiên bản' } };
  const h = harness((url, options, normal) => url === '/api/runs' ? [copy(historical), copy(newer)] : normal(url, options));
  h.setRun(historical);
  const current = baseContext(); current.profile.sku = 'MOCK-CURRENT-UNRELATED'; current.profile.product = 'MOCK hồ sơ hiện tại khác';
  h.mount(current); await settle();
  const buttons = h.get('history').children;
  assert.match(buttons[0].textContent, /Hồ sơ v1.*SKU MOCK-SKU-OLD.*Miến tại lúc chạy/);
  assert.doesNotMatch(buttons[0].textContent, /MOCK-SKU-NEW|MOCK-CURRENT/);
  assert.match(buttons[1].textContent, /Hồ sơ v2.*SKU MOCK-SKU-NEW/);
  await buttons[0].emit('click'); await settle();
  assert.match(h.get('artifact-meta').textContent, /Hồ sơ v1.*SKU MOCK-SKU-OLD.*Miến tại lúc chạy/);
  assert.doesNotMatch(h.get('artifact-meta').textContent, /MOCK-SKU-NEW|MOCK-CURRENT/);
  assert.equal(h.get('result-context').hidden, false);
  assert.doesNotMatch(h.element.textContent, /MOCK-DO-NOT-SHOW/);
  assert.equal(h.calls.some(c => /^\/api\/cases(?:\/|$)/.test(c.url) || c.body?.name === 'nmate_case_get'), false);
  assert.equal(h.calls.some(c => c.body?.name === 'nmate_shipment_readiness_start'), false);
});

test('Prefill uses explicit gross weight, grouped retail quantities and additional profile fields', async () => {
  const h = harness(); h.mount(); await settle();
  assert.equal(h.get('quantity_units').value, '1000'); assert.equal(h.get('carton_count').value, '20');
  assert.equal(h.get('gross_weight_kg').value, '255.5'); assert.equal(h.get('processing_description').value, 'Sấy khô');
  assert.equal(h.get('sku').value, 'MOCK-SKU-A');
  await h.submit(); const body = h.calls.find(c => c.url === '/api/cases').body;
  assert.equal(body.shipment.quantity_units, 1000); assert.equal(body.shipment.gross_weight_kg, 255.5);
  assert.notEqual(body.shipment.gross_weight_kg, 999);
});

test('Chargeable weight or incompatible units never become gross kg or retail counts', async () => {
  const context = baseContext(); context.logistics.grossWeight = ''; context.logistics.quantity = '500 kg'; context.logistics.cartonCount = '2.5 kiện';
  const h = harness(); h.mount(context); await settle();
  assert.equal(h.get('quantity_units').value, ''); assert.equal(h.get('carton_count').value, ''); assert.equal(h.get('gross_weight_kg').value, '');
});

test('AI summary stays intact and closed; continuation opens a local draft without remote writes', async () => {
  const h = harness(); h.setRun(runData('succeeded')); h.mount(); await settle(); await h.submit();
  const details = h.get('summary').parentNode;
  assert.equal(details.tagName, 'DETAILS'); assert.equal(details.open, false);
  assert.equal(details.children[0].textContent, 'Đọc toàn văn bản nghiên cứu đã lưu');
  assert.equal(h.get('summary').textContent, report().summary);
  const links = h.element.all().filter(n => n.tagName === 'A' && n.dataset.go === 'plan');
  assert.equal(links.length, 1); assert.equal(links[0].href, '#plan');
  let draft = null; h.setApp({prepareExpertDraft(value) { draft = value; return true; }});
  await h.get('prepare-local-draft').emit('click'); assert.equal(draft.artifact.artifact_id, 'MOCK-ART-A');
  assert.equal(draft.product.sku, 'MOCK-SKU-A'); assert.match(links[0].parentNode.parentNode.textContent, /bản nháp.*không tạo hàng đợi/i);
  assert.equal(h.calls.some(c => /tasks_confirm|brief_review|source_review/.test(c.body?.name || '')), false);
});
