'use strict';

// Logic and HTML-string checks only. This does not launch a browser or verify layout.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const fields = {};
const messages = [];
const context = {
  window: {}, URL,
  document: { querySelector(selector) {
    const hit = selector.match(/data-field="([^"]+)"/);
    return hit && Object.hasOwn(fields, hit[1]) ? fields[hit[1]] : null;
  } }
};
vm.createContext(context);
['data.js', 'flowmap.js', 'ops.js'].forEach(file => vm.runInContext(fs.readFileSync(path.join(root, 'src', file), 'utf8'), context, { filename: file }));
const D = context.window.NMateData;
const F = context.window.NMateFlow;
const O = context.window.NMateOps;
const results = [];
const run = (id, name, fn) => {
  try { fn(); results.push({ id, name, status: 'pass_unit' }); }
  catch (error) { results.push({ id, name, status: 'fail_unit', error: error.message }); }
};
const clone = value => JSON.parse(JSON.stringify(value));
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const makeCtx = () => {
  const ctx = { state: D.seed(), modal: '', renders: 0, lastAction: '' };
  Object.assign(ctx, {
    esc, icon: () => '', badge: text => '<span>' + esc(text) + '</span>',
    button: (label, action, id) => '<button data-action="' + esc(action) + '" data-id="' + esc(id) + '">' + esc(label) + '</button>',
    go: target => { ctx.target = target; },
    toast: text => messages.push(text),
    mutate: (fn, action, detail) => { fn(ctx.state); ctx.lastAction = action; ctx.state.audit.unshift({ action, detail, time: new Date().toISOString() }); },
    render: () => { ctx.renders++; },
    openModal: (title, html) => { ctx.modalTitle = title; ctx.modal = html; },
    closeModal: () => { ctx.modal = ''; }
  });
  return ctx;
};
const action = (ctx, name, id) => O.handle(name, { dataset: { id: id || '' } }, ctx);
const fill = values => { Object.keys(fields).forEach(key => delete fields[key]); Object.entries(values).forEach(([key, value]) => { fields[key] = typeof value === 'boolean' ? { checked: value } : { value: String(value) }; }); };

run('VM01', '26 unique screens and 7 flows have valid targets', () => {
  assert.equal(F.screens.length, 26); assert.equal(new Set(F.screens.map(s => s.id)).size, 26); assert.equal(F.flows.length, 7);
  const ids = new Set(F.screens.map(s => s.id));
  F.flows.forEach(flow => { assert.ok(flow.steps.length > 1); flow.steps.forEach(id => assert.ok(ids.has(id), id)); });
});
run('VM02', 'App route registry covers the entire flow contract', () => {
  const source = fs.readFileSync(path.join(root, 'src', 'app.js'), 'utf8');
  const literal = source.match(/const viewNames=(\{[^\r\n]+\});/);
  assert.ok(literal, 'Cannot locate route registry');
  const names = vm.runInNewContext('(' + literal[1] + ')');
  F.screens.forEach(screen => assert.equal(typeof names[screen.id], 'string', screen.id));
});
run('VM03', 'Seed state is isolated between sessions', () => {
  const a = D.seed(), b = D.seed(); a.profile.product = 'Thay đổi thử'; a.tasks.length = 0;
  assert.notEqual(a.profile.product, b.profile.product); assert.ok(b.tasks.length > 0);
});
run('VM04', 'Readiness has 12 questions and a deterministic 0–7 score', () => {
  assert.equal(D.questions.length, 12);
  const a = { q1: 'a', q2: 'd', q3: 'a', q4: 'd', q5: ['b', 'c', 'e'], q6: 'c', q8: 'c', q9: 'b' };
  const x = D.computeReadiness(a), y = D.computeReadiness(clone(a));
  assert.equal(x.score, 7); assert.equal(x.max, 7); assert.equal(x.stage, 2);
  assert.equal(JSON.stringify(x), JSON.stringify(y)); assert.ok(x.strengths.length <= 3); assert.ok(x.gaps.length <= 3);
});
run('VM05', 'Export history overrides intention; an intermediary sale does not become self-export', () => {
  assert.equal(D.computeReadiness({ q3: 'c', q4: 'a' }).stage, 4);
  assert.equal(D.computeReadiness({ q3: 'd', q4: 'a' }).stage, 4);
  assert.equal(D.computeReadiness({ q3: 'b', q4: 'b' }).stage, 1);
  assert.equal(D.computeReadiness({ q3: 'a', q4: 'a' }).stage, 0);
});
run('VM06', 'Readiness threshold is 3 and duplicate paper options do not inflate score', () => {
  assert.equal(D.computeReadiness({ q4: 'c', q5: ['b', 'c'], q6: 'b' }).stage, 1);
  assert.equal(D.computeReadiness({ q4: 'c', q5: ['b', 'c'], q6: 'c' }).stage, 2);
  assert.equal(D.computeReadiness({ q5: ['b', 'b', 'c', 'c', 'e'] }).score, 3);
  assert.equal(D.computeReadiness({ answers: { q4: 'a' } }).stage, 0);
});
run('VM07', 'Source IDs in seeded content and checklist resolve to primary-source records', () => {
  const s = D.seed(), ids = new Set(D.sources.map(x => x.id));
  [...s.contentQueue, ...s.checklist].filter(x => x.sourceId).forEach(x => assert.ok(ids.has(x.sourceId), x.sourceId));
  D.sources.forEach(source => assert.equal(new URL(source.url).protocol, 'https:'));
});
const operations = ['intake', 'cases', 'expert-queue', 'expert-case', 'content', 'labels', 'metrics', 'audit'];
run('VM08', 'Eight operation views render one h1 without missing values in seeded HTML strings', () => {
  operations.forEach(view => {
    const ctx = makeCtx(); ctx.state.role = F.screens.find(s => s.id === view).role;
    const html = O.render(view, ctx);
    assert.equal((html.match(/<h1>/g) || []).length, 1, view);
    assert.ok(!/>undefined</.test(html), view); assert.ok(!/>NaN</.test(html), view);
  });
});
run('VM09', 'Empty operation lists have explicit empty text rather than an exception', () => {
  const checks = [['cases', 'cases', 'Không có hồ sơ phù hợp'], ['expert-queue', 'handoffs', 'Chưa có'], ['content', 'contentQueue', 'Không có mục'], ['labels', 'labels', 'Chưa có yêu cầu rà nhãn'], ['audit', 'audit', 'Không tìm thấy sự kiện']];
  checks.forEach(([view, key, text]) => { const ctx = makeCtx(); ctx.state[key] = []; const html = O.render(view, ctx); assert.ok(html.includes(text), view); assert.ok(html.includes('<h1>'), view); });
});
run('VM10', 'Content approval is blocked for a non-reviewer', () => {
  const ctx = makeCtx(); ctx.state.role = 'expert'; const item = ctx.state.contentQueue.find(x => x.status === 'pending');
  fill({ 'content-url': 'https://www.fda.gov/', 'content-note': 'Đã đối chiếu phạm vi thực phẩm.', 'content-confirm': true });
  action(ctx, 'ops-content-approve', item.id); assert.equal(item.status, 'pending');
});
run('VM11', 'Content needs a reason, safe URL and explicit review confirmation', () => {
  const ctx = makeCtx(); ctx.state.role = 'reviewer'; const item = ctx.state.contentQueue.find(x => x.status === 'pending');
  fill({ 'content-url': 'https://www.fda.gov/', 'content-note': '', 'content-confirm': true }); action(ctx, 'ops-content-approve', item.id); assert.equal(item.status, 'pending');
  fill({ 'content-url': 'javascript:alert(1)', 'content-note': 'Đã đối chiếu phạm vi thực phẩm.', 'content-confirm': true }); action(ctx, 'ops-content-approve', item.id); assert.equal(item.status, 'pending');
  fill({ 'content-url': 'https://www.fda.gov/', 'content-note': 'Đã đối chiếu phạm vi thực phẩm.', 'content-confirm': false }); action(ctx, 'ops-content-approve', item.id); assert.equal(item.status, 'pending');
});
run('VM12', 'Reviewer can approve or return a content item with a recorded reason', () => {
  const ctx = makeCtx(); ctx.state.role = 'reviewer'; const item = ctx.state.contentQueue.find(x => x.status === 'pending');
  fill({ 'content-url': 'https://www.fda.gov/', 'content-note': 'Đã đối chiếu phạm vi thực phẩm.', 'content-confirm': true });
  action(ctx, 'ops-content-approve', item.id); assert.equal(item.status, 'approved'); assert.ok(item.reviewedBy); assert.ok(item.reviewNote);
  fill({ 'content-note': 'Cần bổ sung điều khoản và ngày áp dụng.', 'content-url': '' });
  action(ctx, 'ops-content-reject', item.id); assert.equal(item.status, 'rejected');
});
run('VM13', 'Label signatures reject the wrong role and incomplete clauses', () => {
  const ctx = makeCtx(); const label = ctx.state.labels[0]; ctx.state.role = 'expert';
  action(ctx, 'ops-label-sign-reviewer', label.id); assert.ok(!label.reviewerApproval);
  action(ctx, 'ops-label-sign-expert', label.id); assert.ok(!label.expertApproval);
});
run('VM14', 'Two different roles approve one reviewed label version, then a revision invalidates both', () => {
  const ctx = makeCtx(); const label = ctx.state.labels[0]; ctx.state.role = 'expert';
  const inputs = { 'label-note': 'Đã rà thủ công theo hồ sơ và nguồn của ca minh họa.' };
  label.clauses.forEach((_, i) => { inputs['clause-' + i] = 'verified'; }); fill(inputs);
  action(ctx, 'ops-label-save', label.id); assert.equal(label.version, 2);
  ctx.state.role = 'reviewer'; action(ctx, 'ops-label-sign-reviewer', label.id); assert.ok(label.reviewerApproval); assert.ok(!label.expertApproval); assert.notEqual(label.status, 'approved');
  ctx.state.role = 'expert'; action(ctx, 'ops-label-sign-expert', label.id); assert.equal(label.status, 'approved'); assert.equal(label.reviewerApproval.hash, label.expertApproval.hash);
  const count = ctx.state.audit.length; action(ctx, 'ops-label-sign-expert', label.id); assert.equal(ctx.state.audit.length, count);
  action(ctx, 'ops-label-revise', label.id); assert.equal(label.version, 3); assert.equal(label.reviewerApproval, null); assert.equal(label.expertApproval, null); assert.equal(label.clauses[0].status, 'progress');
});
run('VM15', 'Non-applicable label clauses require a written rationale', () => {
  const ctx = makeCtx(); const label = ctx.state.labels[0]; ctx.state.role = 'expert'; const version = label.version;
  const inputs = { 'label-note': '' }; label.clauses.forEach((_, i) => { inputs['clause-' + i] = 'na'; }); fill(inputs);
  action(ctx, 'ops-label-save', label.id); assert.equal(label.version, version);
});
run('VM16', 'Metrics distinguish completed tasks from completed tasks with evidence', () => {
  const ctx = makeCtx(); ctx.state.tasks = [{ id: 'A', status: 'done', evidence: [] }, { id: 'B', status: 'done', evidence: [{ note: 'Bản mẫu đã kiểm' }] }, { id: 'C', status: 'todo', evidence: [] }];
  const html = O.render('metrics', ctx);
  assert.ok(/Việc được đánh dấu xong<\/div><div class="ops-count">2<\/div>/.test(html));
  assert.ok(/Việc xong có ghi bằng chứng<\/div><div class="ops-count">1<\/div>/.test(html));
  assert.ok(html.includes('chưa thể kết luận đạt D14'));
});

const output = {
  reviewedOn: '2026-10-17', method: 'Node VM with stubbed DOM fields; no browser, no real network, no layout assertions',
  summary: { pass: results.filter(x => x.status === 'pass_unit').length, fail: results.filter(x => x.status === 'fail_unit').length },
  results,
  uiStatus: 'not_run_by_this_agent; CUA inventory returned no browsers',
  limitations: ['No verification of browser event binding, console, actual download, visual overflow, viewport or offline reload by this 16-test suite.', 'Source approval linkage is covered separately by qa/regression-tests.mjs and root UI evidence; see review-notes.txt.']
};
fs.writeFileSync(path.join(__dirname, 'vm-result.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(output, null, 2));
process.exitCode = output.summary.fail ? 1 : 0;
