const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const ui=require('../src/main-ui-contracts.js');
const owner={account_id:'owner-a',enterprise_id:'enterprise-a',conversation_id:'conversation-a',policy_case_id:'policy-a'};
const draft={schema_version:'policy-draft/1',id:'draft-a',draft_id:'draft-a',enterprise_id:'enterprise-a',conversation_id:'conversation-a',policy_case_id:'policy-a',kind:'request_guidance',requested_kind:'participation_request',version:1,content_hash:'hash-1',status:'draft',question:'Chị muốn hỗ trợ xuất khẩu và đào tạo kế toán.',needs:[{need_id:'market',label_vi:'Xúc tiến xuất khẩu',status:'needs_source',reason_vi:'Chưa đủ nguồn hiện hành.'},{need_id:'training',label_vi:'Đào tạo nhân viên kế toán',status:'needs_source',reason_vi:'Cần xác minh lớp đang nhận.'}],body:{subject:'Đề nghị hướng dẫn chương trình hỗ trợ',enterprise_summary:'Trà Sen Tây Hồ · hồ sơ chủ đã xác nhận',requested_support:'Xuất khẩu và đào tạo kế toán',situation:'Cơ sở muốn được hướng dẫn.',impact:'',request:'Xin hướng dẫn điều kiện và đợt phù hợp.'},checklist:[{label_vi:'Xác minh đợt tiếp nhận',status:'missing'}],context_manifest:{reused_fact_count:2},approval:null,submission:{status:'not_submitted',channel_status:'not_configured',message_vi:'Chưa có kết nối nghiệp vụ iHanoi.'}};

test('Workbench validates identity, workspace and revision before projection',()=>{
  assert.equal(ui.policy05DraftFor(draft,owner),draft);
  for(const change of [{enterprise_id:'other'},{conversation_id:'other',policy_case_id:'other'},{version:0},{version:'1'},{draft_id:'',id:''}])assert.equal(ui.policy05DraftFor({...draft,...change},owner),null);
});
test('Two needs remain visible; draft never becomes an eligibility or registration verdict',()=>{
  const markup=ui.policy05DraftView(draft,{owner:true});
  assert.match(markup,/Xúc tiến xuất khẩu/);assert.match(markup,/Đào tạo nhân viên kế toán/);
  assert.match(markup,/hướng dẫn/);assert.match(markup,/Chưa gửi/);assert.match(markup,/Bản 1/);
  assert.doesNotMatch(markup,/Đã đăng ký|Đủ điều kiện nhận|Đang chờ chuyên gia|Claude đã lưu/);
});
test('Owner approval is explicit and exact-version; unknown iHanoi cannot expose send button',()=>{
  const markup=ui.policy05DraftView(draft,{owner:true});
  assert.match(markup,/data-v04="policy05-approve"/);assert.match(markup,/data-revision="1"/);
  assert.match(markup,/đồng ý chia sẻ riêng/);assert.match(markup,/công khai/);
  assert.match(markup,/chưa gửi/i);assert.match(markup,/iHanoi/);
  assert.doesNotMatch(markup,/data-v04="policy05-submit"/);
  assert.doesNotMatch(markup,/<input[^>]+type="checkbox"[^>]+checked/);
  assert.doesNotMatch(ui.policy05DraftView(draft,{owner:false}),/data-v04="policy05-approve"/);
});
test('Approval of an older revision is never rendered as approval for the current draft',()=>{
  const stale={...draft,version:2,status:'approved',approval:{version:1,content_hash:'old-hash'}};
  assert.match(ui.policy05DraftView(stale,{owner:true}),/Cần duyệt bản hiện tại/);
  assert.doesNotMatch(ui.policy05DraftView(stale,{owner:true}),/Chủ đã duyệt bản 2/);
});
test('All persisted user content and IDs are escaped, PDF binds exact revision and enterprise',()=>{
  const markup=ui.policy05DraftView({...draft,title:'<img onerror=send()>',body:{...draft.body,request:'</textarea><script>send()</script>'}},{owner:true});
  assert.doesNotMatch(markup,/<img|<script/);assert.match(markup,/&lt;img/);
  assert.match(markup,/policy05\/drafts\/draft-a\/pdf\?e=enterprise-a&amp;revision=1/);
});
test('Out-of-order or cross-workspace callbacks cannot replace a policy draft',()=>{
  const current={...draft,version:3};
  assert.equal(ui.policy05DraftReducer(current,{...draft,version:2},owner),current);
  assert.equal(ui.policy05DraftReducer(current,{...draft,version:4,conversation_id:'other',policy_case_id:'other'},owner),current);
  assert.equal(ui.policy05DraftReducer(current,{...draft,version:4},{...owner,account_id:''}),current);
  assert.equal(ui.policy05DraftReducer(current,{...draft,version:4},owner).version,4);
});
test('New journey controls are in the main chat with accessible touch targets and no paid transport',()=>{
  const src=fs.readFileSync(path.join(__dirname,'../src/main-app.js'),'utf8');
  assert.ok(src.includes('policy05_create_draft'));assert.ok(src.includes('policy05_list_drafts'));
  assert.ok(src.includes('policy05DraftView'));assert.ok(src.includes('policy05-approve'));
  const css=fs.readFileSync(path.join(__dirname,'../src/main-app.css'),'utf8');
  assert.match(css,/\.policy05[^}]+min-height:\s*44px/s);
});
test('Historical context remains readable and exportable but cannot look current or acquire approval',()=>{
  const markup=ui.policy05DraftView({...draft,is_historical:true,current_warnings_vi:['Tên cơ sở đã thay đổi sau khi chuẩn bị bản này.']},{owner:true});
  assert.match(markup,/hồ sơ trước/);assert.match(markup,/Tên cơ sở đã thay đổi/);assert.match(markup,/PDF/);
  assert.doesNotMatch(markup,/data-v04="policy05-approve"/);
});
test('Private staff drafts disclose that owner handoff is not implemented and never imply automatic sharing',()=>{
  const markup=ui.policy05DraftView(draft,{owner:false});
  assert.match(markup,/riêng tư trong tài khoản người soạn/);
  assert.match(markup,/chưa hỗ trợ chuyển nháp của nhân viên/);
  assert.doesNotMatch(markup,/data-v04="policy05-approve"|chủ doanh nghiệp duyệt trước khi bàn giao/);
});
test('V17 historical unapproved drafts never claim a retained approval and cannot save against old context',()=>{
  const editor={base_version:1,title:draft.title||'',body:{...draft.body,request:'Đề nghị lớp buổi tối.'}};
  const markup=ui.policy05DraftView({...draft,is_historical:true},{owner:true,editing:true,editor,dirty:true});
  assert.doesNotMatch(markup,/Giữ nguyên nội dung và lần duyệt đã lưu/);
  assert.match(markup,/Bản này chưa được duyệt/);
  assert.match(markup,/<button[^>]+type="submit"[^>]+disabled/);
  assert.match(markup,/Có thay đổi chưa lưu/);
});
test('V17 editor dirty projection is content based and does not count an unopened editor as modified',()=>{
  assert.equal(ui.policy05EditorDirty(draft,null),false);
  assert.equal(ui.policy05EditorDirty(draft,{title:draft.title||'',body:{...draft.body}}),false);
  assert.equal(ui.policy05EditorDirty(draft,{title:'Đề nghị mới',body:{...draft.body}}),true);
  assert.equal(ui.policy05EditorDirty(draft,{title:draft.title||'',body:{...draft.body,request:'Lớp buổi tối'}}),true);
  assert.match(ui.policy05DraftView(draft,{owner:true,dirty:true}),/Có thay đổi chưa lưu/);
});
test('V17 navigation state is a bounded scope projection without private draft or consent data',()=>{
  const scope={account_id:'a',enterprise_id:'e',workspace_key:'conversation:c'};
  const route=ui.mainRouteFor({...scope,view:'profile',text:'private',consent:true},scope);
  assert.deepEqual(route,{schema_version:'main-route/1',...scope,view:'profile'});
  for(const patch of [{account_id:'b'},{enterprise_id:'x'},{workspace_key:'conversation:x'},{view:'admin'}])assert.equal(ui.mainRouteFor({...route,...patch},scope),null);
});
