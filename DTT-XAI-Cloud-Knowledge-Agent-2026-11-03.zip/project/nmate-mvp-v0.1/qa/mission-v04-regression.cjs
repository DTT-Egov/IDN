const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const helpers=require('../src/mission-v04.js');
const source=fs.readFileSync(path.join(__dirname,'../src/mission-v04.js'),'utf8');
const clone=value=>JSON.parse(JSON.stringify(value));
const session={authenticated:true,csrf_token:'csrf-a',account:{id:'account-a',username:'trasen'},enterprise:{id:'enterprise-a',name:'Trà Sen An Nhiên'}};
const locator=(cell='C2')=>({attachment_id:'attachment-a',filename:'tra-sen-ho-so.xlsx',kind:'spreadsheet',sheet:'Hồ sơ',cell});
const intake={id:'intake-a',status:'awaiting_confirmation',text:'Tôi muốn số hóa bán hàng và tồn kho.',created_at:'2026-10-19T00:00:00Z',intent:{primary:'digitize_operations',primary_label:'Số hóa bán hàng và tồn kho',objectives:[]},summary:'Đã tìm thấy dữ kiện, chưa ghi vào hồ sơ.',plan:[{id:'read',title:'Đọc tài liệu',status:'completed'}],business_plan:[{id:'baseline',title:'Đối chiếu quy trình bán hàng',basis:'Đã xác nhận dùng Excel cho bán hàng',status:'proposed'}],candidates:[{id:'name',label_vi:'Tên sản phẩm',field:'name',entity_id:'product-a',value:'Trà Sen Tây Hồ',status:'candidate',source:locator()},{id:'revenue',label_vi:'Doanh thu theo kỳ',field:'revenue.2025',value_type:'object',value:{amount:1200000000,currency:'VND',period:'2025'},entity_id:'enterprise-entity-a',status:'candidate',source:locator('C8')},{id:'sales',label_vi:'Quản lý bán hàng',field:'sales_management',value:'Excel',status:'candidate',entity_id:'enterprise-entity-a',source:locator('C5')}],attachments:[{id:'attachment-a',filename:'tra-sen-ho-so.xlsx',media_type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',warnings:[]}],enterprise_entity:{id:'enterprise-entity-a',version:1},product:{id:'product-a',version:2},expected_entity_versions:{'enterprise-entity-a':1,'product-a':2},model_calls:0,provider_attempts:0};
const context={entities:[{id:'product-a',entity_type:'product',name:'Trà Sen Tây Hồ',version:2,values:{name:'Trà Sen Tây Hồ'}},{id:'enterprise-entity-a',entity_type:'enterprise',name:'Trà Sen An Nhiên',version:1,values:{'revenue.2025':{amount:1200000000,currency:'VND',period:'2025'}}}]};
const asConversation=(id,item)=>({id,title:item.text,status:item.status,active_intake_id:item.id,intake_ids:[item.id],intake:clone(item),drafts:{},messages:[{id:id+'-user',role:'user',text:item.text,intake_id:item.id,attachments:item.attachments},{id:id+'-assistant',role:'assistant',text:'Mình đang giúp kiểm tra hồ sơ Trà Sen.',intake_id:item.id}],created_at:item.created_at,updated_at:item.created_at});
async function harness(options={}) {
  const listeners={},calls=[],memory=options.memory||new Map([['nmate.v04.enterprise-a.conversation','conversation-a'],['nmate.v04.enterprise-a.current','intake-a']]);
  const elements={'v04-confirm-button':{disabled:false,textContent:''}};
  let markup='';const frames=[],scrollEvents=[];
  const root={dataset:options.liveMode?{liveReview:'true'}:{},addEventListener:(name,handler)=>listeners[name]=handler,get innerHTML(){return markup;},set innerHTML(value){markup=value;const key=value.match(/data-workspace-key="([^"]+)"/)?.[1];elements.main={id:'main',dataset:key?{workspaceKey:key}:{},scrollTop:0};const question=value.match(/<textarea id="v04-question"[^>]*>([\s\S]*?)<\/textarea>/);if(question)elements['v04-question']={value:question[1],style:{},scrollHeight:options.composerScrollHeight||40,focus(){},setSelectionRange(){}};else delete elements['v04-question'];if(value.includes('id="v04-result"'))elements['v04-result']={scrollIntoView:config=>{scrollEvents.push(config);elements.main.scrollTop=900;}};else delete elements['v04-result'];}};
  const document={activeElement:null,getElementById:id=>id==='v04-app'?root:elements[id]||null};
  let current=clone(options.intake||intake),operation=0;
  const thread=(item,id='conversation-a')=>({id,title:item.text,status:item.status,active_intake_id:item.id,intake_ids:[item.id],intake:item,drafts:{},created_at:item.created_at,updated_at:item.created_at,messages:[{id:'message-u-'+item.id,role:'user',text:item.text,intake_id:item.id,attachments:item.attachments},{id:'message-a-'+item.id,role:'assistant',text:'Mình hiểu bạn muốn '+String(item.intent?.primary_label||'chuẩn bị hồ sơ').toLowerCase()+'.',intake_id:item.id}]});
  let conversation=clone(options.conversation||thread(current));
  const conversations=options.conversations?clone(options.conversations):[conversation];
  const workIntakes=new Map([current,...conversations.map(item=>item.intake),...(options.workIntakes||[])].map(item=>[item.id,item]));
  const fetch=async(url,config={})=>{
    const body=config.body?JSON.parse(config.body):undefined;calls.push({url,config,body});
    let value;
    if(url==='/api/v04/qa-status'){
      if(options.runtimeError)return {ok:false,status:503,json:async()=>({detail:'Status unavailable'})};
      const sent=calls.filter(call=>call.body?.name==='send_message').length;
      const base={mode:'live_claude_review_v04',model_policy:{simple:'claude-sonnet-review',complex:'claude-opus-review'},paid_calls:0,provider_attempts:0,remaining_attempts:6,max_attempts:6,...options.runtime};
      value={...base,provider_attempts:base.provider_attempts+sent,paid_calls:base.paid_calls+(options.prepareError?0:sent),remaining_attempts:Math.max(0,base.remaining_attempts-sent)};
    }
    else if(url==='/api/v03/session')value=session;
    else if(url==='/api/v03/mcp/call') {
      assert.equal(config.headers['X-CSRF-Token'],'csrf-a');assert.equal(body.arguments.enterprise_id,'enterprise-a');
      if(body.name==='get_enterprise_context')value=context;
      else if(body.name==='list_conversations')value=options.history?[]:conversations.map(item=>({...item,intake:undefined,messages:undefined}));
      else if(body.name==='list_intakes')value=options.history||options.legacy||[current];
      else if(body.name==='get_intake')value=options.history?options.history.find(intake=>intake.id===body.arguments.intake_id):workIntakes.get(body.arguments.intake_id)||current;
      else if(body.name==='get_conversation'){conversation=conversations.find(item=>item.id===body.arguments.conversation_id)||conversation;current=conversation.intake;value=conversation;}
      else if(body.name==='save_conversation_draft'){conversation.drafts[body.arguments.intake_id]=body.arguments.draft;value=conversation;}
      else if(body.name==='send_message'){
        if(options.prepareError)return {ok:false,status:422,json:async()=>({ok:false,error:{message:'Excel chưa đúng cấu trúc.'}})};
        const previous=conversation;if(body.arguments.target_intake_id)current=workIntakes.get(body.arguments.target_intake_id)||current;
        if(options.prepared)current=clone(options.prepared);
        else if(current.status==='confirmed')current=clone({...intake,id:'intake-b',status:'ready',text:body.arguments.text,candidates:[],attachments:[],reused_context:{fact_count:2},next_steps:['Bạn muốn giảm sai lệch tồn kho hay tổng hợp bán hàng nhanh hơn?']});
        else {current.text=body.arguments.text;current.intent={primary:'digitize_operations',primary_label:'Số hóa bán hàng và tồn kho'};current.questions=[];}
        if(body.arguments.draft)previous.drafts[body.arguments.draft.intake_id]=body.arguments.draft;
        if(!body.arguments.conversation_id){conversation=thread(current,'conversation-new');conversation.messages=[];conversations.push(conversation);}else conversation=previous;
        conversation.intake=current;conversation.active_intake_id=current.id;workIntakes.set(current.id,current);
        conversation.messages.push({id:'user-'+operation,role:'user',text:body.arguments.text,intake_id:current.id,attachments:body.arguments.attachments});
        conversation.messages.push({id:'assistant-'+operation,role:'assistant',text:'Mình hiểu bạn muốn '+String(current.intent?.primary_label||'chuẩn bị hồ sơ').toLowerCase()+'.',intake_id:current.id});value=conversation;
      }
      else if(body.name==='prepare_intake'){
        if(options.prepareError)return {ok:false,status:422,json:async()=>({ok:false,error:{message:'Excel chưa đúng cấu trúc.'}})};
        current=clone(options.prepared||{...intake,id:'intake-b',status:'ready',text:body.arguments.text,candidates:[],attachments:[],reused_context:{fact_count:2},next_steps:['Bạn muốn giảm sai lệch tồn kho hay tổng hợp bán hàng nhanh hơn?']});value=current;
      }
      else if(body.name==='clarify_intake') {current.text=body.arguments.text;current.intent={primary:'digitize_operations',primary_label:'Số hóa bán hàng và tồn kho'};current.questions=[];value=current;}
      else if(body.name==='confirm_intake') {
        if(options.confirmError)return {ok:false,status:409,json:async()=>({ok:false,error:{message:'Hồ sơ đã đổi. Đối chiếu lại trước khi lưu.'}})};
        const item=workIntakes.get(body.arguments.intake_id)||current;item.status='confirmed';item.candidates=item.candidates.map(fact=>({...fact,status:body.arguments.selected_fact_ids.includes(fact.id)?'confirmed':'skipped',confirmed_value:body.arguments.edits[fact.id]??fact.value}));if(conversation.active_intake_id===item.id)conversation.intake=item;conversation.messages.push({id:'confirmation-'+operation,role:'assistant',kind:'confirmation',text:'Đã lưu '+body.arguments.selected_fact_ids.length+' dữ kiện bạn xác nhận.',intake_id:item.id});value=item;
      }
      else if(body.name==='get_attachment')value={id:'attachment-a',filename:'tra-sen-ho-so.xlsx',media_type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',data_base64:'dGVzdA=='};
      else throw new Error('Unexpected MCP call '+body.name);
      value={ok:true,data:clone(value)};
    }else throw new Error('Unexpected network '+url);
    return {ok:true,status:200,json:async()=>clone(value)};
  };
  class FakeFormData {constructor(form){this.data=form.data||{};}entries(){return Object.entries(this.data)[Symbol.iterator]();}}
  class FakeFileReader {readAsDataURL(){this.result='data:image/png;base64,dGVzdA==';this.onload();}}
  const sandbox={document,fetch,Intl,Date,JSON,Math,console,FormData:FakeFormData,FileReader:FakeFileReader,Uint8Array,atob,Blob,URL:{createObjectURL:()=> 'blob:test',revokeObjectURL(){}},setTimeout,clearTimeout,requestAnimationFrame:fn=>frames.push(fn),sessionStorage:{getItem:key=>memory.get(key)||null,setItem:(key,value)=>memory.set(key,value),removeItem:key=>memory.delete(key)},window:{crypto:{randomUUID:()=>`op-${++operation}`},getComputedStyle:()=>({lineHeight:'22.4px',paddingTop:'9px',paddingBottom:'9px',borderTopWidth:'0px',borderBottomWidth:'0px'})}};
  vm.runInNewContext(source,sandbox,{filename:'mission-v04.js'});
  const settle=async()=>{for(let i=0;i<10;i++){await new Promise(resolve=>setImmediate(resolve));while(frames.length)frames.shift()();}};
  await settle();
  const click=async(action,data={})=>{listeners.click({target:{closest:()=>({dataset:{v04:action,...data}})}});await settle();};
  const submit=async(id,data={})=>{listeners.submit({preventDefault(){},target:{id,data,reportValidity:()=>true}});await settle();};
  const change=data=>listeners.change({target:{dataset:{},...data}});
  const input=(value,data={})=>listeners.input({target:{id:'',dataset:{},style:{},closest:()=>null,value,...data}});
  const scroll=value=>{elements.main.scrollTop=value;listeners.scroll({target:elements.main});};
  return {root,calls,memory,click,submit,change,input,elements,settle,scroll,scrollEvents,server:{conversations,workIntakes}};
}

test('Tài liệu và tên người dùng được escape, nguồn giữ đúng ô Excel',()=>{
  assert.equal(helpers.esc('<script>"'), '&lt;script&gt;&quot;');
  assert.equal(helpers.sourceText(locator('C8')), 'tra-sen-ho-so.xlsx · Trang “Hồ sơ” · ô C8');
  assert.equal(helpers.dateVi('2026-10-19T00:00:00Z'),'19/10/2026');
});

test('Số doanh thu được trình bày tiếng Việt; sửa số tiền giữ nguyên kỳ và tiền tệ',()=>{
  const fact=intake.candidates[1];
  assert.equal(helpers.valueText(fact.value),'1.200.000.000 VND · 2025');
  assert.deepEqual(helpers.changedValue(fact,'1250000000'),{amount:1250000000,currency:'VND',period:'2025'});
  assert.throws(()=>helpers.changedValue(fact,'1.250.000.000'),/không dùng dấu/);
});

test('Nội dung xung đột và đã biết không tự được chọn ghi đè',()=>{
  assert.deepEqual(helpers.initialSelection([{id:'new',status:'candidate'},{id:'old',status:'already_known'},{id:'conflict',status:'conflict'}]),{new:true,old:false,conflict:false});
});

test('Reload chỉ đọc trạng thái đã lưu, không tự prepare hoặc confirm',async()=>{
  const app=await harness();
  assert.deepEqual(app.calls.filter(call=>call.body).map(call=>call.body.name),['get_enterprise_context','list_conversations','list_intakes','get_conversation','get_enterprise_context']);
  assert.match(app.root.innerHTML,/tra-sen-ho-so.xlsx · Trang “Hồ sơ” · ô C8/);
  assert.match(app.root.innerHTML,/1.200.000.000 VND · 2025/);
  assert.ok(app.root.innerHTML.indexOf('preview-revenue')<app.root.innerHTML.indexOf('id="v04-confirm-button"'));
});

test('Chỉ dữ kiện được chọn được gửi xác nhận, sửa doanh thu được lưu kiểu object',async()=>{
  const app=await harness();
  app.change({name:'select_fact',value:'sales',checked:false});
  app.input('1250000000',{dataset:{edit:'revenue'}});
  await app.submit('v04-confirm-form');
  const call=app.calls.find(call=>call.body?.name==='confirm_intake');
  assert.deepEqual(call.body.arguments.selected_fact_ids,['name','revenue']);
  assert.deepEqual(call.body.arguments.edits.revenue,{amount:1250000000,currency:'VND',period:'2025'});
  assert.deepEqual(call.body.arguments.expected_entity_versions,{'enterprise-entity-a':1,'product-a':2});
  assert.match(app.root.innerHTML,/Đã lưu 2 dữ kiện/);
  assert.match(app.root.innerHTML,/1.250.000.000 VND · 2025/);
});

test('Lỗi lưu giữ bản sửa và lựa chọn, không tự retry',async()=>{
  const app=await harness({confirmError:true});
  app.change({name:'select_fact',value:'sales',checked:false});app.input('1250000000',{dataset:{edit:'revenue'}});
  await app.submit('v04-confirm-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='confirm_intake').length,1);
  assert.match(app.root.innerHTML,/value="1250000000"/);
  assert.match(app.root.innerHTML,/Hồ sơ đã đổi/);
  const restored=await harness({memory:app.memory});
  assert.match(restored.root.innerHTML,/value="1250000000"/);
  await restored.submit('v04-confirm-form');
  assert.deepEqual(restored.calls.find(call=>call.body?.name==='confirm_intake').body.arguments.selected_fact_ids,['name','revenue']);
});

test('Xung đột bắt chọn; incoming tự chọn dữ kiện và giữ tên viết hoa',async()=>{
  const current=clone(intake);current.candidates=[{...current.candidates[0],status:'conflict',current_value:'Trà Sen cũ',conflict:{kind:'ssot_value',current_value:'Trà Sen cũ'}}];
  const app=await harness({intake:current});
  app.change({name:'select_fact',value:'name',checked:true});await app.submit('v04-confirm-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='confirm_intake').length,0);
  app.change({dataset:{choice:'name'},value:'incoming'});await app.submit('v04-confirm-form');
  const call=app.calls.find(call=>call.body?.name==='confirm_intake');assert.equal(call.body.arguments.conflict_choices.name,'incoming');assert.deepEqual(call.body.arguments.selected_fact_ids,['name']);assert.match(app.root.innerHTML,/Trà Sen Tây Hồ/);
});

test('Hai tài liệu mâu thuẫn chưa có SSOT không hiện tùy chọn giữ dữ kiện không tồn tại',async()=>{
  const current=clone(intake);current.candidates=[{...current.candidates[0],status:'conflict',conflict:{kind:'document_disagreement'}}];
  const app=await harness({intake:current});
  assert.match(app.root.innerHTML,/Các tài liệu cung cấp nội dung khác nhau/);
  assert.doesNotMatch(app.root.innerHTML,/option value="current"/);
});

test('Mở nguồn của doanh thu trỏ đúng ô C8 thay vì ô đầu tiên của tệp',async()=>{
  const app=await harness();await app.click('attachment',{id:'attachment-a',factId:'revenue'});
  assert.match(app.root.innerHTML,/role="dialog"/);assert.match(app.root.innerHTML,/<p class="notice">tra-sen-ho-so.xlsx · Trang “Hồ sơ” · ô C8<\/p>/);
});

test('Câu hỏi tiếp không upload lại, hiển thị dùng lại SSOT và bước tiếp theo',async()=>{
  const current={...clone(intake),status:'confirmed',candidates:[]};const app=await harness({intake:current});await app.click('follow-digital');await app.submit('v04-chat-form');
  const call=app.calls.find(call=>call.body?.name==='send_message');assert.deepEqual(call.body.arguments.attachments,[]);assert.equal(call.body.arguments.product_entity_id,undefined);assert.equal(call.body.arguments.conversation_id,'conversation-a');
  assert.match(app.root.innerHTML,/Đã dùng lại 2 dữ kiện/);assert.match(app.root.innerHTML,/giảm sai lệch tồn kho/);assert.match(app.root.innerHTML,/Đối chiếu quy trình bán hàng/);
  assert.doesNotMatch(app.root.innerHTML,/id="v04-confirm-form"/);
});

test('Lỗi đọc giữ nguyên câu hỏi để người dùng sửa, không tự gửi thêm lượt',async()=>{
  const app=await harness({prepareError:true});await app.click('follow-digital');await app.submit('v04-chat-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,1);
  assert.match(app.root.innerHTML,/Excel chưa đúng cấu trúc/);assert.match(app.root.innerHTML,/Tôi muốn số hóa việc bán hàng và tồn kho/);
});

test('Hồ sơ không lộ tên trường kỹ thuật cho doanh thu từng kỳ',async()=>{
  const app=await harness();await app.click('profile');assert.match(app.root.innerHTML,/Doanh thu · 2025/);assert.doesNotMatch(app.root.innerHTML,/>revenue\.2025</);
});

test('Hiểu intent xuất hiện trước dữ kiện; các số tài chính đều hiện trước nút xác nhận',async()=>{
  const app=await harness();
  assert.ok(app.root.innerHTML.indexOf('Mình hiểu bạn muốn')<app.root.innerHTML.indexOf('id="v04-confirm-form"'));
  assert.ok(app.root.innerHTML.indexOf('Số liệu theo kỳ')<app.root.innerHTML.indexOf('id="v04-confirm-button"'));
  assert.ok(app.root.innerHTML.indexOf('1.200.000.000 VND · 2025')<app.root.innerHTML.indexOf('id="v04-confirm-button"'));
});

test('Excel excerpt dùng giá trị gốc sau khi sửa, giữ đúng ô kỳ và đơn vị',async()=>{
  const current=clone(intake);current.candidates[1].source={...locator('C8'),unit_cell:'D8',period_cell:'E8'};
  const app=await harness({intake:current});app.input('1250000000',{dataset:{edit:'revenue'}});await app.click('attachment',{id:'attachment-a',factId:'revenue'});
  const modal=app.root.innerHTML.slice(app.root.innerHTML.indexOf('role="dialog"'));
  assert.match(modal,/1.200.000.000 VND · 2025/);assert.doesNotMatch(modal,/1.250.000.000/);assert.match(modal,/ô đơn vị D8/);assert.match(modal,/ô kỳ E8/);
});

test('Chỉ gửi ảnh không bị chặn hoặc bịa lời người dùng',async()=>{
  const prepared={...clone(intake),text:'',intent:{primary:'needs_clarification',primary_label:'Cần làm rõ mục tiêu'},questions:['Bạn muốn được hỗ trợ việc gì?']};
  const app=await harness({prepared});
  app.change({id:'v04-image',files:[{name:'bao-bi.png',type:'image/png',size:4}]});await app.settle();await app.submit('v04-chat-form');
  const call=app.calls.find(call=>call.body?.name==='send_message');assert.equal(call.body.arguments.text,'');assert.equal(call.body.arguments.attachments.length,1);
  assert.equal(call.body.arguments.product_entity_id,undefined,'Tệp mới phải được nhận diện sản phẩm từ nội dung, không ép vào sản phẩm cũ đang mở.');
  const user=app.root.innerHTML.slice(app.root.innerHTML.lastIndexOf('<section class="message user">'),app.root.innerHTML.indexOf('id="v04-result"'));
  assert.doesNotMatch(user,/class="bubble"/);
});

test('Làm rõ mục tiêu dùng cùng intake, không tải lại ảnh hoặc mất dữ kiện đang chọn',async()=>{
  const current={...clone(intake),text:'',intent:{primary:'needs_clarification',primary_label:'Cần làm rõ mục tiêu'}};
  const app=await harness({intake:current});app.change({name:'select_fact',value:'sales',checked:false});app.input('1250000000',{dataset:{edit:'revenue'}});
  await app.click('goal-digital');await app.submit('v04-chat-form');
  const call=app.calls.find(call=>call.body?.name==='send_message');assert.equal(call.body.arguments.draft.intake_id,'intake-a');assert.equal(call.body.arguments.conversation_id,'conversation-a');
  assert.equal(app.calls.filter(call=>['prepare_intake','get_attachment'].includes(call.body?.name)).length,0);
  await app.submit('v04-confirm-form');const confirm=app.calls.find(call=>call.body?.name==='confirm_intake');assert.deepEqual(confirm.body.arguments.selected_fact_ids,['name','revenue']);assert.equal(confirm.body.arguments.edits.revenue.amount,1250000000);
});

test('Reload sau server commit ưu tiên đúng operation mới thay vì hội thoại cũ đang nhớ',async()=>{
  const old={...clone(intake),id:'intake-old',text:'Hồ sơ cũ đang mở.'};
  const committed={...clone(intake),id:'intake-committed',text:'Tôi muốn kiểm tra bao bì vừa gửi.',prepare_operation_id:'pending-uuid',latest_intake_operation_id:'pending-uuid'};
  const memory=new Map([['nmate.v04.enterprise-a.current','intake-old'],['nmate.v04.enterprise-a.pending-prepare','pending-uuid'],['nmate.v04.enterprise-a.pending-text',committed.text],['nmate.v04.enterprise-a.draft',committed.text]]);
  const app=await harness({history:[committed,old],memory});
  assert.equal(app.calls.find(call=>call.body?.name==='get_intake').body.arguments.intake_id,'intake-committed');
  assert.equal(memory.get('nmate.v04.enterprise-a.current'),'intake-committed');
  assert.equal(memory.has('nmate.v04.enterprise-a.pending-prepare'),false);
  assert.equal(memory.get('nmate.v04.enterprise-a.draft'),'');
  assert.match(app.root.innerHTML,/Đã khôi phục đúng lượt bạn vừa gửi/);
  assert.equal(app.calls.filter(call=>['prepare_intake','clarify_intake','confirm_intake'].includes(call.body?.name)).length,0);
});

test('Khôi phục operation giữ nguyên bản nháp mới khác câu hỏi đã gửi',async()=>{
  const committed={...clone(intake),id:'intake-committed',text:'Câu hỏi đã gửi.',prepare_operation_id:'op-initial',latest_intake_operation_id:'op-clarify'};
  const memory=new Map([['nmate.v04.enterprise-a.current','intake-old'],['nmate.v04.enterprise-a.pending-prepare','op-clarify'],['nmate.v04.enterprise-a.pending-text',committed.text],['nmate.v04.enterprise-a.draft','Bản nháp tiếp theo chưa gửi.']]);
  const app=await harness({history:[committed],memory});
  assert.equal(app.calls.find(call=>call.body?.name==='get_intake').body.arguments.intake_id,'intake-committed');
  assert.equal(memory.get('nmate.v04.enterprise-a.draft'),'Bản nháp tiếp theo chưa gửi.');
  assert.match(app.root.innerHTML,/Bản nháp mới của bạn vẫn được giữ/);
  assert.match(app.root.innerHTML,/>Bản nháp tiếp theo chưa gửi\.<\/textarea>/);
});

test('Pending chưa khớp không chọn hồ sơ mới nhất tùy ý và không tự retry',async()=>{
  const unrelated={...clone(intake),id:'intake-unrelated',prepare_operation_id:'unrelated-uuid'};
  const old={...clone(intake),id:'intake-old'};
  const memory=new Map([['nmate.v04.enterprise-a.current','intake-old'],['nmate.v04.enterprise-a.pending-prepare','missing-uuid'],['nmate.v04.enterprise-a.draft','Câu hỏi đang chờ.']]);
  const app=await harness({history:[unrelated,old],memory});
  assert.equal(app.calls.find(call=>call.body?.name==='get_intake').body.arguments.intake_id,'intake-old');
  assert.equal(memory.get('nmate.v04.enterprise-a.pending-prepare'),'missing-uuid');
  assert.match(app.root.innerHTML,/Chưa tìm thấy kết quả khớp/);
  assert.equal(app.calls.filter(call=>['prepare_intake','clarify_intake','confirm_intake'].includes(call.body?.name)).length,0);
});

test('Kỳ quý và tháng hiển thị bằng tiếng Việt trong cả số tiền và nhãn hồ sơ',()=>{
  assert.equal(helpers.valueText({amount:330000000,currency:'VND',period:'2026-Q1'}),'330.000.000 VND · Quý 1/2026');
  assert.equal(helpers.periodVi('2026-03'),'Tháng 03/2026');
});

test('Bỏ chọn xung đột A không gửi choices/edits A khi chỉ xác nhận B',async()=>{
  const current=clone(intake);current.candidates[0]={...current.candidates[0],status:'conflict',current_value:'Trà Sen cũ'};
  const app=await harness({intake:current});
  app.change({dataset:{choice:'name'},value:'incoming'});app.input('Trà Sen Đã Sửa',{dataset:{edit:'name'}});
  app.change({name:'select_fact',value:'name',checked:false});app.change({name:'select_fact',value:'revenue',checked:false});
  await app.submit('v04-confirm-form');
  const payload=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;
  assert.deepEqual(payload.selected_fact_ids,['sales']);assert.deepEqual(payload.conflict_choices,{});assert.deepEqual(payload.edits,{});
});

test('Giữ giá trị hiện tại không buộc kiểm tra một bản sửa mới không hợp lệ',()=>{
  const current=clone(intake);current.candidates=[{...current.candidates[1],status:'conflict',current_value:{amount:1200000000,currency:'VND',period:'2025'}}];
  const payload=helpers.confirmationPayload(current,{revenue:true},{revenue:'không là số'},{revenue:'current'});
  assert.deepEqual(payload.edits,{});assert.deepEqual(payload.conflict_choices,{revenue:'current'});
});

test('Đổi mục tiêu, chuyển lịch sử rồi quay về giữ cả bỏ chọn và sửa theo intake ID',async()=>{
  const a=asConversation('conversation-a',intake),b=asConversation('conversation-b',{...clone(intake),id:'intake-b',text:'Hồ sơ thứ hai.'});
  const app=await harness({conversations:[a,b]});
  app.change({name:'select_fact',value:'sales',checked:false});app.input('Trà Sen Đổi Tên',{dataset:{edit:'name'}});
  app.input('Khoan lưu, tôi muốn xem lại bao bì từ tệp vừa gửi.',{id:'v04-question'});await app.submit('v04-chat-form');
  const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;
  assert.equal(sent.conversation_id,'conversation-a');assert.equal(sent.draft.selected.sales,false);assert.equal(sent.draft.edits.name,'Trà Sen Đổi Tên');
  await app.click('history');assert.equal(app.calls.filter(call=>call.body?.name==='save_conversation_draft').length,1);
  await app.click('open-conversation',{id:'conversation-b'});app.input('Trà Sen Hồ Sơ B',{dataset:{edit:'name'}});
  await app.click('history');await app.click('open-conversation',{id:'conversation-a'});
  assert.match(app.root.innerHTML,/value="Trà Sen Đổi Tên"/);assert.doesNotMatch(app.root.innerHTML,/value="Trà Sen Hồ Sơ B"/);
  await app.submit('v04-confirm-form');const payload=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;
  assert.deepEqual(payload.selected_fact_ids,['name','revenue']);assert.equal(payload.edits.name,'Trà Sen Đổi Tên');
  assert.match(app.root.innerHTML,/Khoan lưu, tôi muốn xem lại bao bì/);assert.match(app.root.innerHTML,/Tôi muốn số hóa bán hàng và tồn kho\./);
});

test('Reload phục hồi bản nháp đã lưu trên server khi không còn bản nháp trình duyệt',async()=>{
  const conversation=asConversation('conversation-a',intake);conversation.drafts['intake-a']={selected:{name:true,revenue:true,sales:false},edits:{name:'Trà Sen Từ Server'},choices:{}};
  const app=await harness({conversation});assert.match(app.root.innerHTML,/value="Trà Sen Từ Server"/);
  await app.submit('v04-confirm-form');const payload=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;
  assert.deepEqual(payload.selected_fact_ids,['name','revenue']);assert.equal(payload.edits.name,'Trà Sen Từ Server');
});

test('Các lượt hỏi tiếp giữ một conversation và giữ toàn bộ lời người dùng trong chat',async()=>{
  const app=await harness();
  for(const text of ['Tôi muốn kiểm tra tồn kho.','Tồn sổ 120 hộp, kiểm đếm 110 hộp.']){app.input(text,{id:'v04-question'});await app.submit('v04-chat-form');}
  const sent=app.calls.filter(call=>call.body?.name==='send_message');assert.equal(sent.length,2);assert.ok(sent.every(call=>call.body.arguments.conversation_id==='conversation-a'));
  assert.match(app.root.innerHTML,/Tôi muốn số hóa bán hàng và tồn kho\./);assert.match(app.root.innerHTML,/Tôi muốn kiểm tra tồn kho\./);assert.match(app.root.innerHTML,/Tồn sổ 120 hộp, kiểm đếm 110 hộp\./);
});

test('Bắt đầu chat mới là thao tác chủ động, lưu draft cũ rồi gửi không có conversation_id',async()=>{
  const app=await harness();app.input('Trà Sen Nháp Cũ',{dataset:{edit:'name'}});await app.click('new');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
  assert.equal(app.memory.get('nmate.v04.enterprise-a.new-chat'),'true');assert.ok(app.memory.get('nmate.v04.enterprise-a.candidate-draft.intake-a').includes('Trà Sen Nháp Cũ'));
  app.input('Tôi muốn cập nhật hồ sơ khác.',{id:'v04-question'});await app.submit('v04-chat-form');
  const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;assert.equal(sent.conversation_id,undefined);assert.equal(sent.draft,undefined);
});

test('Pending operation khớp conversation khôi phục đúng chuỗi chat, không gửi lại',async()=>{
  const old=asConversation('conversation-old',intake),committed=asConversation('conversation-committed',{...clone(intake),id:'intake-new',text:'Yêu cầu vừa gửi.'});committed.operation_ids=['pending-send'];
  const memory=new Map([['nmate.v04.enterprise-a.conversation','conversation-old'],['nmate.v04.enterprise-a.pending-prepare','pending-send'],['nmate.v04.enterprise-a.pending-text','Yêu cầu vừa gửi.'],['nmate.v04.enterprise-a.draft','Yêu cầu vừa gửi.']]);
  const app=await harness({conversations:[committed,old],memory});assert.equal(app.calls.find(call=>call.body?.name==='get_conversation').body.arguments.conversation_id,'conversation-committed');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);assert.equal(memory.get('nmate.v04.enterprise-a.draft'),'');
});

test('Ảnh chưa đọc được báo ngay trong chat, ngoài phần details thu gọn',async()=>{
  const current=clone(intake);current.attachments[0].warnings=['Chưa đọc nội dung ảnh này; bạn có thể nhập thông tin hoặc gửi Excel.'];
  const app=await harness({intake:current});const warning=app.root.innerHTML.indexOf('Chưa đọc nội dung ảnh này');
  assert.ok(warning>0&&warning<app.root.innerHTML.indexOf('id="v04-confirm-form"'));assert.match(app.root.innerHTML,/class="warning" role="status"/);
});

test('Nguồn bổ sung của cùng dữ kiện không mất khi gộp ảnh và Excel',()=>{
  const fact={source:locator(),sources:[locator(),{...locator('C3'),attachment_id:'attachment-b'}],additional_locators:[{...locator('C3'),attachment_id:'attachment-b'}]};
  assert.equal(helpers.factSources(fact).length,2);assert.equal(helpers.factSources(fact)[1].attachment_id,'attachment-b');
});

test('Lịch sử giữ hồ sơ cũ chưa gắn thread và không lặp intake đã nằm trong thread',async()=>{
  const a=asConversation('conversation-a',intake);a.intake_ids=['intake-a','intake-linked'];
  const linked={...clone(intake),id:'intake-linked',text:'Hồ sơ đã nằm trong thread.'},legacy={...clone(intake),id:'intake-legacy',text:'Hồ sơ cũ còn bản nháp.'};
  const app=await harness({conversations:[a],legacy:[intake,linked,legacy]});await app.click('history');
  assert.match(app.root.innerHTML,/data-v04="open-conversation" data-id="conversation-a"/);assert.match(app.root.innerHTML,/data-v04="open-intake" data-id="intake-legacy"/);
  assert.doesNotMatch(app.root.innerHTML,/data-v04="open-intake" data-id="intake-linked"/);assert.doesNotMatch(app.root.innerHTML,/data-v04="open-intake" data-id="intake-a"/);
});

function twoWorkThread(){const a=clone(intake),b={...clone(intake),id:'intake-b',text:'Tôi vừa gửi thêm tệp Excel B.',candidates:clone(intake.candidates).map(fact=>({...fact,id:'b-'+fact.id}))},conversation=asConversation('conversation-a',a);conversation.active_intake_id=b.id;conversation.intake=b;conversation.intake_ids=[a.id,b.id];conversation.messages.push(...asConversation('work-b',b).messages);return {a,b,conversation};}

test('Mở lại phần rà A trong thread có B, hỏi tiếp gửi đúng target A và giữ draft A',async()=>{
  const {a,b,conversation}=twoWorkThread(),memory=new Map([['nmate.v04.enterprise-a.conversation',conversation.id],['nmate.v04.enterprise-a.candidate-draft.intake-a',JSON.stringify({id:a.id,selected:{name:true,revenue:true,sales:false},edits:{name:'Trà Sen Nháp A'},choices:{}})]]);
  const app=await harness({conversation,workIntakes:[a,b],memory});assert.match(app.root.innerHTML,/data-v04="open-work"[^>]*data-id="intake-a"/);
  await app.click('open-work',{id:a.id});assert.match(app.root.innerHTML,/value="Trà Sen Nháp A"/);assert.match(app.root.innerHTML,/Đang xem lại phần trao đổi này/);
  assert.ok(app.root.innerHTML.indexOf('id="v04-confirm-form"')<app.root.innerHTML.indexOf('Tôi vừa gửi thêm tệp Excel B.'));
  app.input('Tôi muốn xem lại bao bì của phần A.',{id:'v04-question'});await app.submit('v04-chat-form');
  const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;assert.equal(sent.target_intake_id,a.id);assert.equal(sent.conversation_id,conversation.id);assert.equal(sent.draft.edits.name,'Trà Sen Nháp A');assert.equal(sent.draft.selected.sales,false);
});

test('Reload và xác nhận phần A không nhảy sang B đang active ở server',async()=>{
  const {a,b,conversation}=twoWorkThread(),memory=new Map([['nmate.v04.enterprise-a.conversation',conversation.id],['nmate.v04.enterprise-a.work.conversation-a',a.id],['nmate.v04.enterprise-a.candidate-draft.intake-a',JSON.stringify({id:a.id,selected:{name:true,revenue:true,sales:false},edits:{name:'Trà Sen Giữ A'},choices:{}})]]);
  const app=await harness({conversation,workIntakes:[a,b],memory});assert.equal(app.calls.find(call=>call.body?.name==='get_intake').body.arguments.intake_id,a.id);assert.match(app.root.innerHTML,/value="Trà Sen Giữ A"/);
  await app.submit('v04-confirm-form');const sent=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;
  assert.equal(sent.intake_id,a.id);assert.deepEqual(sent.selected_fact_ids,['name','revenue']);assert.equal(memory.get('nmate.v04.enterprise-a.work.conversation-a'),a.id);
  assert.match(app.root.innerHTML,/Trà Sen Giữ A/);assert.match(app.root.innerHTML,/Đang xem lại phần trao đổi này/);assert.doesNotMatch(app.root.innerHTML,/id="v04-confirm-form"/);
});

test('Hỏi tiếp legacy đã xác nhận vẫn gửi intake gốc để nhập vào thread có ngữ cảnh',async()=>{
  const current={...clone(intake),status:'confirmed',candidates:clone(intake.candidates).map(fact=>({...fact,status:'confirmed'}))},memory=new Map([['nmate.v04.enterprise-a.current',current.id]]);
  const app=await harness({intake:current,history:[current],memory});await app.click('follow-digital');await app.submit('v04-chat-form');
  const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;assert.equal(sent.conversation_id,undefined);assert.equal(sent.draft.intake_id,current.id);assert.deepEqual(sent.attachments,[]);assert.equal(sent.product_entity_id,'product-a');
});

test('Hỏi sản phẩm khác trong cùng thread không bị frontend ép product A đang mở',async()=>{
  const app=await harness();app.input('Còn Trà Hoa Cúc thì cải thiện bao bì thế nào?',{id:'v04-question'});await app.submit('v04-chat-form');
  const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;
  assert.equal(sent.text,'Còn Trà Hoa Cúc thì cải thiện bao bì thế nào?');assert.equal(sent.conversation_id,'conversation-a');assert.equal(sent.target_intake_id,'intake-a');assert.equal(sent.product_entity_id,undefined,'Server cần tự nhận sản phẩm được nhắc hoặc kế thừa phần trước; frontend không ép ID A.');
});

test('Select ngay sau native details mở, trước queued toggle, vẫn giữ phần chỉnh mở và bản sửa',async()=>{
  const current=clone(intake);current.candidates[0]={...current.candidates[0],status:'conflict',current_value:'Trà Sen cũ'};
  const app=await harness({intake:current});app.input('Trà Sen Giữ Nháp',{dataset:{edit:'name'}});
  app.elements['v04-confirm-form']={dataset:{intakeId:current.id}};app.elements['v04-candidates']={open:true};
  app.change({dataset:{choice:'name'},value:'incoming'});
  assert.match(app.root.innerHTML,/id="v04-candidates" open>/);assert.match(app.root.innerHTML,/value="Trà Sen Giữ Nháp"/);
  assert.equal(JSON.parse(app.memory.get('nmate.v04.enterprise-a.candidate-draft.'+current.id)).open,true);
});

test('Render phần việc B không lấy trạng thái details đang mở của DOM phần A',async()=>{
  const a=asConversation('conversation-a',intake),b=asConversation('conversation-b',{...clone(intake),id:'intake-b',text:'Hồ sơ B.'});
  const app=await harness({conversations:[a,b]});app.elements['v04-confirm-form']={dataset:{intakeId:'intake-a'}};app.elements['v04-candidates']={open:true};
  await app.click('open-conversation',{id:'conversation-b'});
  assert.match(app.root.innerHTML,/id="v04-candidates" >/);assert.doesNotMatch(app.root.innerHTML,/id="v04-candidates" open>/);
});

test('Phiên trình duyệt mới mở lại phần A từ thread B vẫn phục hồi server draft A',async()=>{
  const {a,b,conversation}=twoWorkThread();conversation.drafts[a.id]={selected:{name:true,revenue:true,sales:false},edits:{name:'Trà Sen Nháp A Trên Server'},choices:{}};
  const memory=new Map([['nmate.v04.enterprise-a.conversation',conversation.id]]),app=await harness({conversation,workIntakes:[a,b],memory});
  assert.equal(memory.has('nmate.v04.enterprise-a.candidate-draft.'+a.id),false);
  await app.click('open-work',{id:a.id});assert.match(app.root.innerHTML,/value="Trà Sen Nháp A Trên Server"/);
  const restored=JSON.parse(memory.get('nmate.v04.enterprise-a.candidate-draft.'+a.id));assert.equal(restored.selected.sales,false);assert.equal(restored.edits.name,'Trà Sen Nháp A Trên Server');
  await app.submit('v04-confirm-form');const sent=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;assert.deepEqual(sent.selected_fact_ids,['name','revenue']);assert.equal(sent.edits.name,'Trà Sen Nháp A Trên Server');
});

test('Bản mock mặc định không đọc runtime Claude hoặc hiện đồng ý có phí',async()=>{
  const app=await harness();assert.equal(app.calls.filter(call=>call.url==='/api/v04/qa-status').length,0);assert.doesNotMatch(app.root.innerHTML,/v04-paid-consent|Claude thật · Có phí/);assert.match(app.root.innerHTML,/0 phí AI/);
});

test('Bản live chỉ đọc runtime khi reload, hiện mô hình/bộ đếm thật và không tự gọi AI',async()=>{
  const app=await harness({liveMode:true,runtime:{paid_calls:2,provider_attempts:3,remaining_attempts:3}});
  assert.equal(app.calls.filter(call=>call.url==='/api/v04/qa-status').length,1);assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
  assert.match(app.root.innerHTML,/Claude thật · Có phí · 3\/6 lần gọi/);assert.match(app.root.innerHTML,/claude-sonnet-review/);assert.match(app.root.innerHTML,/claude-opus-review/);assert.match(app.root.innerHTML,/Lượt AI 2 · Còn 3 lượt thử/);
  assert.doesNotMatch(app.root.innerHTML,/0 phí AI|Giả lập đọc ảnh|Phân tích nhu cầu giả lập, không gọi mô hình/);assert.match(app.root.innerHTML,/Dữ kiện chỉ được ghi nhớ khi bạn xác nhận/);
});

test('Live chưa đồng ý thì kể cả submit trực tiếp cũng không gửi câu hỏi cho Claude',async()=>{
  const app=await harness({liveMode:true});app.input('Hãy đọc hồ sơ Trà Sen.',{id:'v04-question'});await app.submit('v04-chat-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);assert.match(app.root.innerHTML,/cần đồng ý gửi câu hỏi và tệp cho Claude/);assert.match(app.root.innerHTML,/>Hãy đọc hồ sơ Trà Sen\.<\/textarea>/);
});

test('Live đồng ý mới gửi paid_consent, kiểm runtime trước và cập nhật bộ đếm sau gửi',async()=>{
  const app=await harness({liveMode:true});app.change({id:'v04-paid-consent',checked:true});app.input('Tôi muốn đối chiếu hồ sơ.',{id:'v04-question'});await app.submit('v04-chat-form');
  const sent=app.calls.filter(call=>call.body?.name==='send_message');assert.equal(sent.length,1);assert.equal(sent[0].body.arguments.paid_consent,true);
  assert.equal(app.calls.filter(call=>call.url==='/api/v04/qa-status').length,3);assert.match(app.root.innerHTML,/Claude thật · Có phí · 1\/6 lần gọi/);assert.match(app.root.innerHTML,/Lượt AI 1 · Còn 5 lượt thử/);
  assert.equal(app.memory.get('nmate.v04.enterprise-a.paid-consent.claude.account-a'),'true');
});

test('Live lỗi một lượt giữ câu hỏi, cập nhật số lần thử và không tự retry',async()=>{
  const app=await harness({liveMode:true,prepareError:true});app.change({id:'v04-paid-consent',checked:true});app.input('Tôi muốn đọc Excel vừa gửi.',{id:'v04-question'});await app.submit('v04-chat-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,1);assert.match(app.root.innerHTML,/Claude thật · Có phí · 1\/6 lần gọi/);assert.match(app.root.innerHTML,/Lượt AI 0 · Còn 5 lượt thử/);assert.match(app.root.innerHTML,/>Tôi muốn đọc Excel vừa gửi\.<\/textarea>/);assert.match(app.root.innerHTML,/Không tự gửi lại yêu cầu/);
});

test('Runtime không đúng live mode thì chặn gửi dù người dùng đã đồng ý',async()=>{
  const app=await harness({liveMode:true,runtime:{mode:'fake_v04'}});app.change({id:'v04-paid-consent',checked:true});app.input('Hãy đọc ảnh.',{id:'v04-question'});await app.submit('v04-chat-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);assert.match(app.root.innerHTML,/Chưa xác minh được kết nối Claude/);assert.match(app.root.innerHTML,/Kiểm tra kết nối · miễn phí/);
});

test('Runtime không truy cập được thì fail closed, còn mở Hồ sơ vẫn miễn phí',async()=>{
  const app=await harness({liveMode:true,runtimeError:true});app.change({id:'v04-paid-consent',checked:true});app.input('Hãy phân tích Trà Sen.',{id:'v04-question'});await app.submit('v04-chat-form');await app.click('profile');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);assert.match(app.root.innerHTML,/Hồ sơ đã ghi nhớ/);assert.match(app.root.innerHTML,/Chưa xác minh được kết nối Claude/);
});

test('Hết quota live không gửi thêm AI, free confirmation không làm tăng lượt thử',async()=>{
  const app=await harness({liveMode:true,runtime:{provider_attempts:6,paid_calls:5,remaining_attempts:0}});app.change({id:'v04-paid-consent',checked:true});app.input('Hãy phân tích thêm.',{id:'v04-question'});await app.submit('v04-chat-form');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);assert.match(app.root.innerHTML,/Đã hết giới hạn lượt gọi/);
  await app.submit('v04-confirm-form');assert.equal(app.calls.filter(call=>call.body?.name==='confirm_intake').length,1);assert.match(app.root.innerHTML,/Claude thật · Có phí · 6\/6 lần gọi/);assert.match(app.root.innerHTML,/Lượt AI 5 · Còn 0 lượt thử/);
});

test('Đồng ý live được giữ theo tài khoản qua reload nhưng không tự phát sinh lượt AI',async()=>{
  const app=await harness({liveMode:true});app.change({id:'v04-paid-consent',checked:true});const reloaded=await harness({liveMode:true,memory:app.memory});
  assert.match(reloaded.root.innerHTML,/id="v04-paid-consent" type="checkbox" checked/);assert.equal(reloaded.calls.filter(call=>call.body?.name==='send_message').length,0);
  reloaded.change({id:'v04-paid-consent',checked:false});assert.equal(reloaded.memory.has('nmate.v04.enterprise-a.paid-consent.claude.account-a'),false);
});

test('Nguồn đọc ảnh thật ghi đúng Claude, không gắn nhãn ảnh giả lập',()=>{
  const source={filename:'tra-sen.jpg',kind:'claude_vision',locator:'Dòng tên trên hộp'};assert.equal(helpers.sourceText(source),'tra-sen.jpg · Dòng tên trên hộp · đọc ảnh bằng Claude');assert.doesNotMatch(helpers.sourceText(source),/giả lập/);
});

test('Tên mô hình rút gọn theo đúng ID, câu trả lời hiện mô hình thực tế của lượt đó',async()=>{
  assert.equal(helpers.shortModel('claude-sonnet-5-5'),'Sonnet 5.5');assert.equal(helpers.shortModel('claude-opus-4-6'),'Opus 4.6');
  const conversation=asConversation('conversation-a',intake);conversation.messages[1].provider_model='claude-opus-5-5';
  const app=await harness({liveMode:true,conversation,runtime:{model_policy:{simple:'claude-sonnet-5-5',complex:'claude-opus-5-5'}}});assert.match(app.root.innerHTML,/<span class="message-model">· Opus 5\.5<\/span>/);assert.match(app.root.innerHTML,/Sonnet 5\.5 \/ Opus 5\.5 · Chi tiết/);
});

test('Kế hoạch Claude trước xác nhận được ghi nhãn cũ, không giả một lượt AI mới sau lưu',async()=>{
  const current={...clone(intake),status:'confirmed',plan_context_state:'recorded_before_owner_confirmation',origins:{business_plan:'claude_recorded_before_owner_confirmation'}};
  const app=await harness({liveMode:true,intake:current});assert.match(app.root.innerHTML,/Kế hoạch Claude từ trước khi bạn lưu/);assert.match(app.root.innerHTML,/Xác nhận hồ sơ không gọi thêm AI/);assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Bản live giữ nguyên lời bước tiếp theo của Claude, không thay bằng hướng dẫn ảnh mẫu giả lập',async()=>{
  const current={...clone(intake),next_steps:['Mình chưa đọc được nội dung ảnh này; bạn chụp rõ dòng khối lượng giúp mình.']},app=await harness({liveMode:true,intake:current});
  assert.match(app.root.innerHTML,/Mình chưa đọc được nội dung ảnh này; bạn chụp rõ dòng khối lượng giúp mình\./);assert.doesNotMatch(app.root.innerHTML,/Bạn có thể gửi ảnh mẫu hoặc Excel theo mẫu để tiếp tục/);
});

test('Kết quả commit muộn mở từ Lịch sử xóa đúng câu đã gửi, Send không còn cho gửi trùng',async()=>{
  const sent='Tôi muốn đối chiếu tồn kho.',memory=new Map([['nmate.v04.enterprise-a.conversation','conversation-a'],['nmate.v04.enterprise-a.pending-prepare','pending-late'],['nmate.v04.enterprise-a.pending-text',sent],['nmate.v04.enterprise-a.draft',sent]]);
  const app=await harness({memory});assert.match(app.root.innerHTML,/id="v04-send" aria-label="Gửi cho trợ lý" disabled/);
  await app.submit('v04-chat-form');assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
  app.server.conversations[0].operation_ids=['pending-late'];
  await app.click('history');await app.click('open-conversation',{id:'conversation-a'});
  assert.equal(memory.has('nmate.v04.enterprise-a.pending-prepare'),false);assert.equal(memory.get('nmate.v04.enterprise-a.draft'),'');
  assert.match(app.root.innerHTML,/Đã khôi phục đúng lượt bạn vừa gửi/);assert.match(app.root.innerHTML,/id="v04-send" aria-label="Gửi cho trợ lý" disabled/);
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Kiểm tra chỉ đọc sau commit muộn giữ câu nháp mới và tệp mới, không gửi lại AI',async()=>{
  const memory=new Map([['nmate.v04.enterprise-a.conversation','conversation-a'],['nmate.v04.enterprise-a.pending-prepare','pending-late'],['nmate.v04.enterprise-a.pending-text','Câu đã gửi.'],['nmate.v04.enterprise-a.draft','Câu đã gửi.']]),app=await harness({memory});
  app.input('Bản nháp mới để làm sau.',{id:'v04-question'});app.change({id:'v04-image',files:[{name:'tep-moi.png',type:'image/png',size:4}]});await app.settle();
  app.server.conversations[0].operation_ids=['pending-late'];await app.click('check-pending');
  assert.equal(memory.get('nmate.v04.enterprise-a.draft'),'Bản nháp mới để làm sau.');assert.match(app.root.innerHTML,/Tệp sắp gửi/);assert.match(app.root.innerHTML,/tep-moi\.png/);assert.match(app.root.innerHTML,/Bản nháp mới của bạn vẫn được giữ/);
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
  await app.submit('v04-chat-form');const sent=app.calls.find(call=>call.body?.name==='send_message').body.arguments;assert.equal(sent.text,'Bản nháp mới để làm sau.');assert.equal(sent.attachments[0].filename,'tep-moi.png');
});

test('Cùng câu cũ nhưng thêm tệp mới vẫn là nháp đang sửa, khôi phục không xóa nhầm',async()=>{
  const sent='Đọc hồ sơ giúp tôi.',memory=new Map([['nmate.v04.enterprise-a.conversation','conversation-a'],['nmate.v04.enterprise-a.pending-prepare','pending-late'],['nmate.v04.enterprise-a.pending-text',sent],['nmate.v04.enterprise-a.draft',sent]]),app=await harness({memory});
  app.change({id:'v04-image',files:[{name:'ban-chup-moi.png',type:'image/png',size:4}]});await app.settle();app.server.conversations[0].operation_ids=['pending-late'];await app.click('check-pending');
  assert.equal(memory.get('nmate.v04.enterprise-a.draft'),sent);assert.match(app.root.innerHTML,/ban-chup-moi\.png/);assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Lượt lỗi chỉ được kiểm tra miễn phí; đóng theo dõi không tự gửi và không để nguyên câu cũ',async()=>{
  const app=await harness({liveMode:true,prepareError:true});app.change({id:'v04-paid-consent',checked:true});app.input('Hãy đọc hồ sơ.',{id:'v04-question'});await app.submit('v04-chat-form');await app.submit('v04-chat-form');await app.click('check-pending');
  assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,1);assert.match(app.root.innerHTML,/lượt AI riêng, có tính phí/);
  await app.click('close-pending');assert.equal(app.memory.has('nmate.v04.enterprise-a.pending-prepare'),false);assert.equal(app.memory.get('nmate.v04.enterprise-a.draft'),'');assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,1);
});

test('Câu trả lời dài giữ nguyên toàn văn trong mở rộng, câu hỏi hiện tại và cảnh báo vẫn hiện ngay',async()=>{
  const text='Đã đối chiếu số tồn: sổ 120 hộp, thực tế 110 hộp, chênh lệch −10 hộp. '+('Chi tiết nguồn và cách đối chiếu cần giữ đầy đủ. '.repeat(9)),current={...clone(intake),questions:['Ngày kiểm kê và mã sản phẩm là gì?']},conversation=asConversation('conversation-a',current);conversation.messages[1].text=text;current.attachments[0].warnings=['Ảnh chưa đọc được; chưa dùng làm dữ kiện.'];
  conversation.intake=current;const app=await harness({conversation});
  assert.match(app.root.innerHTML,/<div class="bubble assistant-lead">Đã đối chiếu số tồn/);assert.ok(app.root.innerHTML.includes('<div class="bubble">'+helpers.esc(text)+'</div>'));
  assert.match(app.root.innerHTML,/<details class="details full-reply">/);assert.match(app.root.innerHTML,/<p class="current-question">Ngày kiểm kê và mã sản phẩm là gì\?<\/p>/);assert.match(app.root.innerHTML,/<details class="details plan-details">/);
  assert.ok(app.root.innerHTML.indexOf('class="warning" role="status"')<app.root.innerHTML.indexOf('id="v04-confirm-form"'));
});

test('Nội dung dài không có ranh giới câu an toàn phải hiện đầy đủ, không biến thành tóm tắt cắt ý',()=>{
  const text='Một nội dung cần giữ nguyên '.repeat(20);assert.deepEqual(helpers.compactReply(text),{lead:text,full:''});
});

test('Hai nguồn cùng trường dùng một nhóm chọn, đổi nguồn chỉ gửi một giá trị và giữ nguồn gốc',async()=>{
  const current=clone(intake);current.candidates=[{id:'qty-120',label_vi:'Khối lượng tịnh',field:'net_quantity',entity_id:'product-a',value:'120 g',status:'conflict',conflict:{kind:'document_disagreement'},source:{attachment_id:'photo-a',filename:'nhan.png',kind:'claude_vision',locator:'Dòng lượng tịnh'}},{id:'qty-100',label_vi:'Khối lượng tịnh',field:'net_quantity',entity_id:'product-a',value:'100 g',status:'conflict',conflict:{kind:'document_disagreement'},source:locator('C3')}];
  const app=await harness({intake:current});assert.match(app.root.innerHTML,/1 nội dung cần đối chiếu/);assert.equal((app.root.innerHTML.match(/class="candidate conflict-group"/g)||[]).length,1);
  assert.match(app.root.innerHTML,/data-source-choice="qty-100"/);assert.match(app.root.innerHTML,/nhan\.png/);assert.match(app.root.innerHTML,/ô C3/);assert.doesNotMatch(app.root.innerHTML,/Dùng nội dung mới phía trên/);
  app.change({dataset:{sourceChoice:'qty-120'},checked:true});app.change({dataset:{sourceChoice:'qty-100'},checked:true});await app.submit('v04-confirm-form');
  const payload=app.calls.find(call=>call.body?.name==='confirm_intake').body.arguments;assert.deepEqual(payload.selected_fact_ids,['qty-100']);assert.deepEqual(payload.conflict_choices,{'qty-100':'incoming'});
});

test('Tải lại chat giữ vị trí đang xem; chưa có vị trí thì về phần việc mới nhất',async()=>{
  const app=await harness();assert.equal(app.elements.main.scrollTop,900,'Lần đầu mở phải đến kết quả, không quay về đầu chat.');
  app.scroll(426);assert.equal(app.memory.get('nmate.v04.enterprise-a.scroll.conversation-a'),'426');
  const reloaded=await harness({memory:app.memory});assert.equal(reloaded.elements.main.scrollTop,426);assert.equal(reloaded.scrollEvents.length,0);assert.equal(reloaded.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Đã lưu thì câu hỏi cũ không thành câu hỏi hiện tại, toàn văn cũ vẫn mở được trong lịch sử',async()=>{
  const current={...clone(intake),status:'confirmed',questions:['Bạn chọn lượng tịnh 100 g hay 120 g?']},conversation=asConversation('conversation-a',current);conversation.messages[1].text='Tài liệu đang khác nhau: bạn chọn lượng tịnh 100 g hay 120 g?';conversation.messages.push({id:'save-a',role:'assistant',kind:'confirmation',intake_id:current.id,text:'Đã lưu 3 dữ kiện bạn xác nhận.'});
  const app=await harness({conversation});assert.match(app.root.innerHTML,/<details class="details full-reply recorded-reply"><summary>Trao đổi trước khi bạn xác nhận hồ sơ<\/summary>/);assert.match(app.root.innerHTML,/Tài liệu đang khác nhau: bạn chọn lượng tịnh 100 g hay 120 g\?/);assert.doesNotMatch(app.root.innerHTML,/<p class="current-question">/);assert.match(app.root.innerHTML,/Đã lưu 3 dữ kiện bạn xác nhận/);
});

test('Nhóm mâu thuẫn doanh thu không gộp nhầm hai kỳ cùng base_field',()=>{
  const facts=['2025','2026'].flatMap(period=>[1,2].map(index=>({id:period+'-'+index,entity_id:'enterprise-a',field:'revenue.'+period,base_field:'revenue',status:'conflict'})));
  assert.equal(helpers.conflictGroups(facts).length,2);assert.equal(helpers.conflictGroups(facts)[0].length,2);
});

test('Khôi phục nháp dài tự giãn ô nhập theo dòng ngay sau render, không cần gõ thêm',async()=>{
  const text='Tôi đang viết câu hỏi tiếp theo khá dài để đối chiếu phiếu nhập, xuất và ngày kiểm kê sản phẩm.',memory=new Map([['nmate.v04.enterprise-a.conversation','conversation-a'],['nmate.v04.enterprise-a.draft',text]]),app=await harness({memory,composerScrollHeight:130});
  assert.equal(app.elements['v04-question'].value,text);assert.equal(app.elements['v04-question'].style.height,'86px');assert.equal(app.elements['v04-question'].style.overflowY,'auto');
  await app.click('profile');await app.click('back');assert.equal(app.elements['v04-question'].style.height,'86px');assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Tiêu đề kế hoạch có khối chữ riêng để xuống dòng, thông tin dùng lại không ép cuộn ngang',async()=>{
  const app=await harness({intake:{...clone(intake),reused_context:{fact_count:8}}});
  assert.match(app.root.innerHTML,/<summary><span class="plan-label">Kế hoạch & căn cứ<span class="small plan-meta">Đã dùng lại 8 dữ kiện<\/span><\/span><\/summary>/);
  const css=fs.readFileSync(path.join(__dirname,'../src/mission-v04.css'),'utf8');assert.match(css,/\.plan-details>summary\{display:grid;grid-template-columns:12px minmax\(0,1fr\)/);
});

test('Phát lại kết quả Claude đã lưu: dữ kiện làm việc và hành động tiếp hiện ngay, không cần mở kế hoạch',async()=>{
  const recorded=JSON.parse(fs.readFileSync(path.join(__dirname,'../../MVP/v0.4A-real-acceptance-2026-10-19/raw-model-outputs.json'),'utf8')).at(-1).data;
  const working={book_quantity:120,physical_quantity:110,quantity_unit:'hộp',count_date:'2026-10-18',product_code:'TS01'},current={...clone(intake),status:'ready',candidates:[],attachments:[],intent:{primary:recorded.primary,focus:recorded.focus,working_answers:working},pending_question:recorded.pending_question,questions:[],next_steps:recorded.next_steps},conversation=asConversation('conversation-a',current);conversation.messages[1].text=recorded.assistant_text;
  const app=await harness({liveMode:true,conversation});const html=app.root.innerHTML,plan=html.indexOf('<details class="details plan-details">');
  assert.ok(html.indexOf('Dữ kiện làm việc · Chưa lưu vào hồ sơ')<plan);assert.ok(html.indexOf('<p class="current-question">'+helpers.esc(recorded.next_steps[0])+'</p>')<plan);assert.match(html,/Mã sản phẩm và số kiểm kê hiện được giữ trong chat; chưa có thao tác lưu các mục này vào hồ sơ/);
  assert.ok(html.includes('<div class="bubble">'+helpers.esc(recorded.assistant_text)+'</div>'),'Giữ nguyên toàn văn Claude, gồm lời chỉ dẫn còn sai về lưu riêng.');assert.ok(html.includes(helpers.esc(recorded.next_steps[1])));assert.doesNotMatch(html,/id="v04-confirm-form"/);assert.equal(app.calls.filter(call=>call.body?.name==='send_message').length,0);
});

test('Hồ sơ đã xác nhận không mời sang bán hàng hoặc Nhật khi đang xử lý sai lệch kho',async()=>{
  const current={...clone(intake),status:'confirmed',intent:{primary:'digitize_operations',focus:'inventory_accuracy'}};const app=await harness({intake:current});
  assert.match(app.root.innerHTML,/Bạn có thể hỏi tiếp dựa trên hồ sơ này/);assert.doesNotMatch(app.root.innerHTML,/data-v04="follow-export"|data-v04="follow-digital"|Chuẩn bị xuất khẩu Trà Sen đi Nhật/);
});

test('Chỉ đưa một bước tiếp hiện tại: ưu tiên câu hỏi còn thiếu, không lặp lại lead đang nhìn thấy',()=>{
  assert.equal(helpers.currentStep({status:'ready',pending_question:'Mã sản phẩm là gì?',next_steps:['Đối chiếu phiếu nhập/xuất.']},'Đã nhận 120 và 110 hộp.'),'Mã sản phẩm là gì?');
  assert.equal(helpers.currentStep({status:'ready',pending_question:'Mã sản phẩm là gì?',next_steps:['Đối chiếu phiếu nhập/xuất.']},'Mã sản phẩm là gì?'),'');
  assert.equal(helpers.currentStep({status:'ready',pending_question:null,next_steps:['Đối chiếu phiếu nhập/xuất.','Một bước khác.']},'Đã nhận 120 và 110 hộp.'),'Đối chiếu phiếu nhập/xuất.');
  assert.equal(helpers.currentStep({status:'confirmed',next_steps:['Chọn lại 100 g hay 120 g.']},''),'');
});

test('Mở Excel của lượt A khi đang ở lượt B lấy trích xuất gốc từ A, không làm đổi phần việc hay nháp',async()=>{
  const a={...clone(intake),status:'confirmed'},b={...clone(intake),id:'intake-b',text:'Ngày 18/10/2026, mã TS01.',status:'ready',candidates:[],attachments:[]};a.candidates[1].confirmed_value={amount:1250000000,currency:'VND',period:'2025'};
  const conversation=asConversation('conversation-a',a);conversation.intake=b;conversation.active_intake_id=b.id;conversation.intake_ids=[a.id,b.id];conversation.messages.push(...asConversation('work-b',b).messages);
  const app=await harness({conversation,workIntakes:[a,b]});app.input('Câu hỏi tiếp theo chưa gửi.',{id:'v04-question'});await app.click('attachment',{id:'attachment-a'});
  const modal=app.root.innerHTML.slice(app.root.innerHTML.indexOf('role="dialog"'));assert.match(modal,/1.200.000.000 VND · 2025/);assert.doesNotMatch(modal,/1.250.000.000/);assert.match(modal,/ô C8/);
  const read=app.calls.filter(call=>call.body?.name==='get_intake');assert.equal(read.at(-1).body.arguments.intake_id,'intake-a');assert.equal(app.memory.get('nmate.v04.enterprise-a.current'),'intake-b');assert.equal(app.memory.get('nmate.v04.enterprise-a.draft'),'Câu hỏi tiếp theo chưa gửi.');assert.equal(app.calls.filter(call=>['send_message','confirm_intake'].includes(call.body?.name)).length,0);
});
