# Hồ sơ Trà Sen mẫu

Đây là dữ liệu doanh nghiệp minh họa để kiểm thử. Bao bì là hình minh họa, không phải nhãn thương mại hay ảnh sản phẩm đã kiểm chứng. App chính chỉ đính kèm ảnh khi tác vụ đọc ảnh được mở; không tự gán dữ kiện từ ảnh mẫu cho ảnh khác. Đính kèm chưa gửi Claude. Nút Gửi có phí gọi mô hình thật theo hạn mức được duyệt.

Mẫu mặc định `tra-sen-ho-so-nghiep-vu.xlsx` có sáu dữ kiện: tên, khối lượng, bao bì, thành phần và cách quản lý bán hàng/tồn kho. Không có doanh thu, chỉ tiêu tiền hoặc số lao động đang thuộc nhóm dữ liệu hạn chế. Excel được đọc tại server, sau đó chỉ dữ kiện nghiệp vụ có cấu trúc được phép mới gửi cho Claude.

Bảng gồm năm cột: **Đối tượng | Trường | Giá trị | Đơn vị | Kỳ**. `Đối tượng` là `sản phẩm` hoặc `doanh nghiệp`. Chỉ dữ kiện được chọn và chủ doanh nghiệp xác nhận mới vào hồ sơ chuẩn.

Mẫu cũ `tra-sen-ho-so.xlsx` có doanh thu hai kỳ, chỉ giữ để thử đọc tài chính tại server. Mẫu này không còn được đính kèm tự động và không dùng với Gửi có phí của hội thoại hiện tại. D05 yêu cầu quyền riêng cho đúng các chỉ tiêu tối thiểu; không gửi tệp tài chính gốc.

Nếu khác dữ kiện đã có, cần chọn giữ dữ kiện hiện tại hoặc dùng dữ kiện mới. Xem lại tài liệu và xác nhận hồ sơ không tự gọi AI có phí hoặc nộp hồ sơ ra bên ngoài.
