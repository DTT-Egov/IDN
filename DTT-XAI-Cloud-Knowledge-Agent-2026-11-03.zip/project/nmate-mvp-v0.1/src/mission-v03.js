(function () {
  'use strict';
  const SAMPLES = [
    {code:'US',label:'Trà Sen đi Mỹ',question:'Tôi có Trà Sen Tây Hồ gửi Mỹ, cần tìm hiểu đăng ký cơ sở FDA và chuẩn bị nhãn tiếng Anh.'},
    {code:'DE',label:'Trà Sen đi Đức (EU)',question:'Tôi có Trà Sen Tây Hồ gửi Đức, cần tìm hiểu yêu cầu nhập khẩu và chuẩn bị nhãn tiếng Đức.'},
    {code:'JP',label:'Trà Sen đi Nhật',question:'Tôi có Trà Sen Tây Hồ gửi Nhật, cần tìm hiểu yêu cầu nhập khẩu và chuẩn bị nhãn tiếng Nhật.'}
  ];
  const SAMPLE = SAMPLES[0].question;
  const MARKETS = {US:{code:'US',name_vi:'Mỹ',label_language:'en'},DE:{code:'DE',name_vi:'Đức (EU)',label_language:'de'},JP:{code:'JP',name_vi:'Nhật Bản',label_language:'ja'}};
  const LANGUAGE_NAMES = {en:'tiếng Anh',de:'tiếng Đức',ja:'tiếng Nhật',vi:'tiếng Việt'};
  const MARKET_FACT_FIELDS = ['statement_of_identity','responsible_business','nutrition_information','allergens','fda_registration_status','date_marking','storage_instructions','ingredients_declaration'];
  const marketOf = mission => {
    const code=mission?.market?.code || mission?.market_profile?.market_code || mission?.intent?.market_code;
    return {...(MARKETS[code] || {code:code || '',name_vi:'Thị trường chưa xác định',label_language:''}),...(mission?.market || {})};
  };
  const labelLanguage = mission => {const value=labelOf(mission)?.language || labelOf(mission)?.label_language || marketOf(mission).label_language;return Object.hasOwn(LANGUAGE_NAMES,value)?value:'';};
  const labelTitle = mission => 'khung nhãn'+(LANGUAGE_NAMES[labelLanguage(mission)]?' '+LANGUAGE_NAMES[labelLanguage(mission)]:'');
  const originalOf = record => {
    const language=record.original_language || record.language || (record.excerpt_en?'en':'');
    return {language:Object.hasOwn(LANGUAGE_NAMES,language)?language:'',text:record.excerpt_original || record.excerpt || record.original_text || record.excerpt_en || record.text_en || record.original || record.claim_en || ''};
  };
  const marketVersionArgs = profile => profile && Number.isSafeInteger(profile.version)?{expected_market_profile_version:profile.version}:{};
  const marketChoices = mission => {
    if(marketOf(mission).code)return [];
    const candidates=asArray(mission?.intent?.market_candidates);
    if(candidates.includes('OTHER'))return [];
    const codes=candidates.includes('EU')?['DE']:candidates.length?candidates.filter(code=>Object.hasOwn(MARKETS,code)):['US','DE','JP'];
    return codes.map(code=>({code,label:MARKETS[code].name_vi,question:String(mission?.question || '').trim()+'\n\nTôi chọn thị trường '+MARKETS[code].name_vi+' cho lượt này.'}));
  };
  const clarificationChoices = mission => !marketOf(mission).code?[]:marketOf(mission).code==='US' ? [{label:'Đăng ký cơ sở FDA',question:'Tôi muốn tìm hiểu đăng ký cơ sở FDA.'},{label:'Chuẩn bị nhãn tiếng Anh',question:'Tôi muốn chuẩn bị nhãn tiếng Anh.'}] : [{label:'Điều kiện nhập khẩu',question:'Tôi muốn tìm hiểu điều kiện nhập khẩu thực phẩm.'},{label:'Chuẩn bị '+labelTitle(mission).replace('khung ',''),question:'Tôi muốn chuẩn bị '+labelTitle(mission).replace('khung ','')+'.'}];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const asArray = value => Array.isArray(value) ? value : [];
  const textValue = value => Array.isArray(value) ? value.join(', ') : value == null ? '' : String(value);
  const dateVi = value => {
    if (!value) return '';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : new Intl.DateTimeFormat('vi-VN', {day:'2-digit',month:'2-digit',year:'numeric',timeZone:'Asia/Bangkok'}).format(date);
  };
  const statusName = value => ({planned:'Chờ bắt đầu',queued:'Đã xếp lượt giả lập',running:'Đang đối chiếu',completed:'Đã có kết quả',completed_partial:'Có kết quả, còn thiếu dữ kiện',needs_revalidation:'Nhận định cần rà',waiting_input:'Cần làm rõ câu hỏi',failed:'Chưa hoàn tất'})[value] || 'Bản nháp';
  const isBusyMission = mission => ['queued','running'].includes(mission?.status);
  const safeURL = value => {try { const url = new URL(value); return ['https:','http:'].includes(url.protocol) ? url.href : ''; } catch { return ''; }};
  const normalizeMission = value => value?.mission || value;
  const answersOf = mission => asArray(mission?.answers?.length ? mission.answers : mission?.outcomes).map(answer => ({...answer,title:answer.title || 'Kết quả',text:answer.text || answer.answer || ''}));
  const labelOf = mission => mission?.label || asArray(mission?.artifacts).find(artifact => artifact.kind === 'food_label_workbook');
  const labelFields = artifact => asArray(artifact?.fields).map(field => ({...field,key:field.id || field.key,label_vi:field.label_vi || field.label || field.label_en || field.id,help_vi:field.help_vi || field.hint || ''}));
  const sourceRecords = mission => asArray(mission?.sources?.length ? mission.sources : mission?.knowledge?.records);
  const labelDownload = artifact => artifact?.kind==='food_label_workbook' && typeof artifact.markdown==='string' && artifact.markdown.trim() ? {filename:'nMate-khung-nhan-'+(MARKETS[artifact.market_code]?artifact.market_code+'-':'')+'v'+(Number.isSafeInteger(artifact.version)&&artifact.version>0?artifact.version:1)+'.md',mime:'text/markdown;charset=utf-8',content:artifact.markdown} : null;
  const FACT_FIELDS = [
    ['product_name','Tên sản phẩm','Giữ đúng tên và cách viết của doanh nghiệp.'],
    ['statement_of_identity','Tên thực phẩm trên nhãn (nếu có)','Dùng lại cho khung nhãn; chưa biết thì để trống, không tự dịch tên thương hiệu.'],
    ['ingredients','Thành phần sản phẩm dùng chung','Ghi đúng công thức gốc của sản phẩm; sửa ở đây là sửa dữ kiện chung cho các thị trường. Không dùng ô này để dịch nhãn.'],
    ['ingredients_declaration','Cách ghi thành phần trên nhãn','Bản diễn đạt riêng theo ngôn ngữ và yêu cầu thị trường; giữ nguyên công thức sản phẩm dùng chung.'],
    ['net_weight','Khối lượng tịnh / quy cách','Ví dụ: 100 g. Đây là dữ kiện do bạn khai báo.'],
    ['responsible_business','Đơn vị chịu trách nhiệm và địa chỉ (nếu có)','Ghi đúng tên, địa chỉ và vai trò; chưa tự dịch tên pháp nhân.'],
    ['allergens','Thông tin dị nguyên','Xác nhận từ công thức và quy trình; để trống không có nghĩa là không có dị nguyên.'],
    ['nutrition_information','Thông tin dinh dưỡng / căn cứ ngoại lệ','Ghi số liệu có căn cứ hoặc tình trạng đang xác minh; không tự suy ra được miễn.'],
    ['date_marking','Ngày hoặc hạn dùng thể hiện trên nhãn','Điền nội dung có căn cứ cho thị trường này. Chưa có thì để trống; ứng dụng không tự tính hạn dùng.'],
    ['storage_instructions','Hướng dẫn bảo quản trên nhãn','Ghi điều kiện bảo quản đã xác nhận và nội dung phù hợp ngôn ngữ thị trường; không tự suy ra.'],
    ['packaging','Quy cách bao gói','Ghi đúng bao gói thực tế của sản phẩm.'],
    ['origin_country','Quốc gia xuất xứ','Ghi đúng xuất xứ sản phẩm. Nếu cơ sở ở quốc gia khác, nêu rõ trong địa chỉ cơ sở.'],
    ['facility_name','Tên cơ sở','Ghi đúng tên cơ sở thực hiện hoạt động với thực phẩm, không mặc định trùng tên thương hiệu.'],
    ['facility_address','Địa chỉ và quốc gia của cơ sở','Ghi địa chỉ đầy đủ, gồm quốc gia nơi cơ sở hoạt động.'],
    ['facility_activity','Hoạt động của cơ sở','Ví dụ: sản xuất, chế biến, đóng gói hoặc lưu giữ thực phẩm.'],
    ['facility_type','Loại hình cơ sở','Ví dụ: cơ sở sản xuất, trang trại, nhà hàng hoặc bán lẻ.'],
    ['processing_description','Mô tả quy trình chế biến','Ghi các bước thực tế; không suy ra quy trình chỉ từ tên sản phẩm.'],
    ['fda_registration_status','Tình trạng đăng ký cơ sở FDA','Chưa rõ cũng có thể để trống. Chưa đồng nghĩa đã kiểm chứng.']
  ];
  const FACT_SCOPES = {
    label:['product_name','statement_of_identity','ingredients','net_weight','responsible_business','allergens','nutrition_information','date_marking','storage_instructions','ingredients_declaration','packaging','origin_country'],
    facility:['facility_name','facility_address','origin_country','facility_activity','facility_type','processing_description','fda_registration_status']
  };
  const FACT_ESSENTIALS = {
    label:['statement_of_identity','net_weight','ingredients','responsible_business','nutrition_information','allergens'],
    facility:['facility_name','facility_address','origin_country','facility_activity','facility_type','fda_registration_status']
  };
  const factUIKey = key => ({name:'product_name',net_quantity:'net_weight'})[key] || key;
  function factSelection(mission,action) {
    const ids=asArray(action?.outcome_ids).filter(id=>['registration','label','prior_notice','certification'].includes(id));
    const scope=ids.length===1 && ids[0]==='label'?'label':ids.length===1 && ids[0]==='registration'?'facility':'relevant';
    const allowed=scope==='facility' && marketOf(mission).code!=='US'?[...FACT_SCOPES.facility,'responsible_business']:FACT_SCOPES[scope] || FACT_FIELDS.map(([key])=>key);
    const missing=answersOf(mission).filter(answer=>ids.includes(answer.outcome_id || answer.id)).flatMap(answer=>asArray(answer.missing_fields)).map(factUIKey);
    const selected=Array.from(new Set(missing.filter(key=>allowed.includes(key))));
    return {scope,keys:selected.length?selected:(FACT_ESSENTIALS[scope] || allowed).slice()};
  }
  const LABEL_MEMORY_FIELDS = ['statement_of_identity','net_quantity','ingredients','responsible_business','nutrition_information','allergens','date_marking','storage_instructions','ingredients_declaration'];
  const productCandidates = mission => asArray(mission?.product_candidates).filter(candidate=>typeof candidate?.entity_id==='string' && typeof candidate.name==='string');
  const fieldConflict = (label,field) => field.conflict || asArray(label?.conflicts).find(conflict=>conflict.field===field.key) || null;
  const labelSections = (label,draft={}) => {
    const fields=labelFields(label);
    return {missing:fields.filter(field=>!textValue(draft[field.key] ?? field.value).trim()),known:fields.filter(field=>textValue(draft[field.key] ?? field.value).trim())};
  };
  const isRawIngredients = (label,field,marketCode=label?.market_code) => ['DE','JP'].includes(marketCode) && (field?.key || field?.id)==='ingredients';
  const labelEditorSections = (label,draft={},limit=3,marketCode=label?.market_code) => {
    const fields=labelFields(label),sections=labelSections(label,draft),editable=fields.filter(field=>!isRawIngredients(label,field,marketCode)),conflicts=editable.filter(field=>fieldConflict(label,field)),review=editable.filter(field=>!fieldConflict(label,field) && field.state==='needs_review');
    const attentionKeys=new Set([...conflicts,...review].map(field=>field.key)),queue=[...conflicts,...review,...sections.missing.filter(field=>!attentionKeys.has(field.key) && !isRawIngredients(label,field,marketCode))];
    return {visible:queue.slice(0,limit),later:queue.slice(limit),known:sections.known.filter(field=>!attentionKeys.has(field.key) && !isRawIngredients(label,field,marketCode)),readonly:fields.filter(field=>isRawIngredients(label,field,marketCode)),attention:[...conflicts,...review],filled:sections.known.length};
  };
  const labelPreview = (label,marketCode=label?.market_code) => {
    const fields=labelFields(label),hasDeclaration=fields.some(field=>field.key==='ingredients_declaration' && textValue(field.value).trim());
    return fields.filter(field=>textValue(field.value).trim() && !(hasDeclaration && isRawIngredients(label,field,marketCode))).map(field=>(isRawIngredients(label,field,marketCode)?'Thành phần sản phẩm dùng chung — tham chiếu chưa dịch':field.label_original || field.label_en || field.label_vi)+': '+textValue(field.value)).join('\n\n') || 'Chưa có nội dung đã lưu.';
  };
  const needsLanguageReview = (mission,field) => field.state==='needs_review' && ['DE','JP'].includes(marketOf(mission).code) && ['ingredients','net_quantity'].includes(field.key);
  const rememberableFields = (label,draft={}) => labelFields(label).filter(field=>LABEL_MEMORY_FIELDS.includes(field.key) && !isRawIngredients(label,field) && textValue(draft[field.key] ?? field.value).trim());
  const publicHelpers = {esc,dateVi,statusName,safeURL,answersOf,labelOf,labelFields,textValue,labelDownload,factSelection,FACT_FIELDS,labelSections,labelEditorSections,labelPreview,isRawIngredients,LABEL_MEMORY_FIELDS,rememberableFields,productCandidates,SAMPLE,SAMPLES,marketOf,labelLanguage,labelTitle,originalOf,marketVersionArgs,clarificationChoices,marketChoices,MARKET_FACT_FIELDS};
  if (typeof module !== 'undefined' && module.exports) module.exports = publicHelpers;
  if (typeof document === 'undefined') return;

  const root = document.getElementById('v03-app');
  if (!root) return;
  const state = {session:null,csrf:'',view:'chat',authMode:'register',busy:false,error:'',notice:'',mission:null,history:[],context:null,question:'',pendingMarket:null,labelDraft:{},labelDraftKey:'',labelRemember:{},labelConflictChoices:{},labelVisibleMissing:3,labelSaved:false,openLabel:false,openFacts:false,openSources:false,sourceTopic:null,factScope:'full',factKeys:[],factDraft:{},factDraftKey:'',authDraft:{},toast:'',pollTimer:null};
  let toastTimer,pollEpoch=0;
  const operationId = () => window.crypto?.randomUUID?.() || ('op-' + Date.now() + '-' + Math.random().toString(36).slice(2));
  const enterprise = () => state.session?.enterprise || {id:state.session?.enterprise_id,name:state.session?.enterprise_name};
  const account = () => state.session?.account || {};
  const enterpriseId = () => enterprise()?.id;
  const isAuthenticated = () => state.session?.authenticated === true || !!(account().id && enterpriseId());
  const memoryKey = () => 'nmate.v03.current.' + enterpriseId();
  const rememberMission = mission => {try {if (mission?.id) sessionStorage.setItem(memoryKey(),mission.id);} catch { /* The server remains canonical without browser storage. */ }};
  const rememberedMission = () => {try {return sessionStorage.getItem(memoryKey());} catch {return null;}};
  function announce(message) {state.toast=message;renderToast();clearTimeout(toastTimer);toastTimer=setTimeout(()=>{state.toast='';renderToast();},4000);}
  function renderToast() {const element=document.getElementById('v03-toast');if(element) {element.hidden=!state.toast;element.textContent=state.toast;}}
  function setSession(value) {state.session=value;state.csrf=value.csrf_token || value.csrf || state.csrf;}
  function resetPrivateState() {pollEpoch++;clearTimeout(state.pollTimer);state.mission=null;state.context=null;state.history=[];state.question='';state.pendingMarket=null;state.labelDraft={};state.labelDraftKey='';state.openLabel=false;state.openFacts=false;state.openSources=false;state.sourceTopic=null;state.factScope='full';state.factKeys=[];state.factDraft={};state.factDraftKey='';state.view='chat';}
  async function request(path,body) {
    const response=await fetch('/api/v03/'+path,{method:body === undefined?'GET':'POST',credentials:'same-origin',headers:body === undefined?{}:{'Content-Type':'application/json','X-CSRF-Token':state.csrf},...(body === undefined?{}:{body:JSON.stringify(body)})});
    let payload;try {payload=await response.json();} catch {throw new Error('Máy chủ chưa trả được kết quả. Bạn có thể tải lại trang; ứng dụng không tự chạy thêm lượt.');}
    if (!response.ok || payload.ok === false) {
      if (response.status===401 && path!=='login') {resetPrivateState();state.session={authenticated:false};}
      throw new Error(payload.error?.message || payload.detail?.message || (typeof payload.detail==='string'?payload.detail:'Chưa thực hiện được. Vui lòng kiểm tra và thử lại thao tác này.'));
    }
    return payload.ok === true ? payload.data : payload;
  }
  const call = (name,args={}) => request('mcp/call',{name,arguments:{enterprise_id:enterpriseId(),...args}});
  function receiveMission(value) {
    const mission=normalizeMission(value);
    if (!mission?.id) throw new Error('Kết quả chưa có mã hồ sơ để lưu. Chưa bắt đầu thêm lượt nào.');
    state.mission=mission;rememberMission(mission);
    const label=labelOf(mission),draftKey=label ? label.id+':'+label.version : '';
    if (draftKey!==state.labelDraftKey) {state.labelDraft=Object.fromEntries(labelFields(label).map(field=>[field.key,textValue(field.value)]));state.labelDraftKey=draftKey;state.labelRemember={};state.labelConflictChoices={};state.labelVisibleMissing=3;}
    return mission;
  }
  async function loadContext() {state.context=await call('get_enterprise_context');}
  function productEntity() {
    const entities=asArray(state.context?.entities);
    return entities.find(entity=>(entity.id||entity.entity_id)===state.mission?.product?.entity_id) || entities.find(entity=>entity.entity_type==='product');
  }
  function marketProfile() {
    const profile=state.mission?.market_profile;if(!profile)return null;
    return asArray(state.context?.entities).find(entity=>(entity.id || entity.entity_id)===profile?.entity_id) || profile || null;
  }
  function factValue(field) {
    const canonical=({product_name:'name',net_weight:'net_quantity'})[field] || field,entity=MARKET_FACT_FIELDS.includes(canonical)?marketProfile():productEntity();
    return entity?.values?.[canonical] ?? entity?.values?.[field] ?? asArray(entity?.facts).find(fact=>fact.field===canonical || fact.field===field)?.value ?? (field==='product_name'?state.mission?.product?.name:'');
  }
  const marketBadge = mission => `<span class="v03-market" aria-label="Thị trường ${esc(marketOf(mission).name_vi)}">${esc(marketOf(mission).name_vi)}</span>`;
  const scopeNote = mission => marketOf(mission).code?`<p class="v03-scope">Dữ kiện sản phẩm dùng chung; nhãn và nhận định thuộc hồ sơ ${esc(marketOf(mission).name_vi)}.</p>`:'';
  function factReuse(mission) {
    const context=mission.context || mission.current_context || {};
    if(Number.isSafeInteger(context.reused_shared_fact_count) || Number.isSafeInteger(context.reused_market_fact_count))return Number(context.reused_shared_fact_count || 0)+' dữ kiện chung + '+Number(context.reused_market_fact_count || 0)+' dữ kiện '+marketOf(mission).name_vi+' dùng lại';
    return Number(context.reused_fact_count || mission.context?.reused_fact_count || 0)+' dữ kiện doanh nghiệp dùng lại';
  }
  function focusResult() {requestAnimationFrame(()=>{const element=document.getElementById('v03-result') || document.getElementById('v03-plan') || document.getElementById('v03-main');element?.scrollIntoView({block:'start',behavior:'instant'});element?.focus({preventScroll:true});});}
  async function runAction(action,focus=false) {
    if (state.busy) return;
    state.busy=true;state.error='';state.notice='';render();
    try {await action();} catch(error) {state.error=error.message || 'Chưa thực hiện được thao tác này.';}
    finally {state.busy=false;render();if(focus)focusResult();}
  }
  async function pollMission() {
    clearTimeout(state.pollTimer);
    if (!isBusyMission(state.mission) || !isAuthenticated()) return;
    const epoch=pollEpoch,id=state.mission.id;
    state.pollTimer=setTimeout(async()=>{
      try {const value=await call('get_mission',{mission_id:id});if(epoch!==pollEpoch || state.mission?.id!==id)return;receiveMission(value);state.error='';render();if(isBusyMission(state.mission))pollMission();else {await loadContext();if(epoch===pollEpoch && state.mission?.id===id){render();focusResult();}}}
      catch(error) {if(epoch===pollEpoch){state.error='Chưa đọc được trạng thái mới. '+error.message;render();}}
    },700);
  }
  async function prepare(question,options={}) {
    const input=String(question || '').trim();if (!input) return;
    if(hasUnsavedLabel()){state.openLabel=true;throw new Error('Bạn có nội dung nhãn chưa lưu. Lưu nhãn trước để mình tiếp tục đúng phần bạn đã làm.');}
    if(hasUnsavedFacts()){state.view='profile';state.openFacts=true;state.factScope='full';state.factKeys=[];throw new Error('Bạn có dữ kiện hồ sơ chưa lưu. Lưu dữ kiện trước để mình dùng đúng hồ sơ khi tiếp tục.');}
    pollEpoch++;clearTimeout(state.pollTimer);state.openLabel=false;state.openFacts=false;state.openSources=false;state.sourceTopic=null;state.factScope='full';state.factKeys=[];state.factDraft={};state.factDraftKey='';state.labelSaved=false;
    receiveMission(await call('prepare_mission',{user_text:input,product_entity_id:Object.hasOwn(options,'product_entity_id')?options.product_entity_id:state.mission?.product?.entity_id || null,...(options.continue!==false && state.mission?.id?{continuation_mission_id:state.mission.id}:{}),...(options.market_code || state.pendingMarket?{market_code:options.market_code || state.pendingMarket}:{}),operation_id:operationId()}));
    state.question='';state.pendingMarket=null;await loadContext();
    state.openLabel=false;state.openFacts=false;state.openSources=false;state.sourceTopic=null;
  }
  async function start() {
    if (state.mission?.status!=='planned') return;
    receiveMission(await call('start_mission',{mission_id:state.mission.id,operation_id:operationId()}));pollMission();
  }
  const button = (text,action,kind='') => `<button type="button" class="v03-button ${kind}" data-v03="${esc(action)}" ${state.busy?'disabled':''}>${esc(text)}</button>`;
  const actionButton = (action,index) => {
    const title=action.kind==='edit_label'?'Tiếp tục khung nhãn':action.kind==='review_sources'?'Xem nguồn':action.kind==='supply_facts'?(factSelection(state.mission,action).scope==='label'?'Bổ sung vào khung nhãn':factSelection(state.mission,action).scope==='facility'?'Bổ sung dữ kiện cơ sở':'Bổ sung dữ kiện'):'';
    return title?`<button type="button" class="v03-button subtle" data-v03="mission-action" data-index="${index}" ${state.busy?'disabled':''}>${esc(title)}</button>`:'';
  };
  const spinner = text => `<div class="v03-status" role="status"><i class="v03-spinner" aria-hidden="true"></i><span>${esc(text)}</span></div>`;
  function header() {return `<header class="v03-header"><span class="v03-mark" aria-hidden="true">n<i>·</i></span><div class="v03-title"><h1>nMate <span class="v03-small">0.3B</span></h1><p>${esc(isAuthenticated()?enterprise()?.name || 'Doanh nghiệp của bạn':'Trợ lý doanh nghiệp')}</p></div>${isAuthenticated()?`<button type="button" class="v03-top-button" data-v03="history" aria-label="Mở lịch sử">Lịch sử</button><button type="button" class="v03-top-button" data-v03="profile" aria-label="Mở hồ sơ doanh nghiệp">Hồ sơ</button>`:''}</header><div class="v03-qa">Giả lập · Không gọi AI có phí</div>`;}
  function errorNotice() {return state.error?`<div class="v03-error" role="alert">${esc(state.error)}<p class="v03-small">Không có lượt nghiên cứu nào tự chạy lại.</p>${button('Đóng thông báo','dismiss-error','subtle')}</div>`:'';}
  function authView() {
    const registration=state.authMode==='register';
    return `<div class="v03-auth"><div class="v03-message"><span class="v03-who">Trợ lý nMate</span><div class="v03-bubble">Mình sẽ nhớ hồ sơ doanh nghiệp để lần sau hỗ trợ sát hơn.</div><p class="v03-muted">${registration?'Tạo tài khoản thử trên máy này để bắt đầu.':'Đăng nhập để dùng lại hồ sơ và kết quả đã lưu.'}</p></div>${errorNotice()}<form id="v03-auth-form"><h2>${registration?'Bắt đầu với doanh nghiệp của bạn':'Chào mừng bạn trở lại'}</h2>${registration?`<label class="v03-field"><span>Tên doanh nghiệp</span><input name="enterprise_name" autocomplete="organization" required maxlength="160" value="${esc(state.authDraft.enterprise_name||'')}" placeholder="Ví dụ: Trà Sen Tây Hồ"></label>`:''}<label class="v03-field"><span>Tên tài khoản</span><input name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required minlength="3" maxlength="80" value="${esc(state.authDraft.username||'')}" placeholder="Ví dụ: trasen-test"></label><label class="v03-field"><span>Mật khẩu thử</span><input type="password" name="password" autocomplete="${registration?'new-password':'current-password'}" required minlength="10" maxlength="200" placeholder="Ít nhất 10 ký tự"></label><p class="v03-auth-password">Tài khoản chỉ dùng cho bản local. Không nhập mật khẩu đang dùng ở dịch vụ khác.</p><button class="v03-button primary" ${state.busy?'disabled':''}>${state.busy?'Đang mở hồ sơ…':registration?'Tạo hồ sơ & vào trợ lý':'Đăng nhập'}</button></form><button type="button" class="v03-auth-toggle" data-v03="toggle-auth">${registration?'Đã có tài khoản? Đăng nhập':'Tạo tài khoản doanh nghiệp khác'}</button><p class="v03-small">Cùng tài khoản có thể mở lại hồ sơ ở trình duyệt khác. Mỗi tài khoản thử mới có không gian doanh nghiệp riêng.</p></div>`;
  }
  function welcome() {return `<div class="v03-message"><span class="v03-who">Trợ lý nMate</span><div class="v03-bubble">Bạn muốn chuẩn bị điều gì cho sản phẩm của mình? Mình sẽ dùng hồ sơ đã lưu, lập kế hoạch rồi đưa ra kết quả để bạn làm tiếp.</div><div class="v03-samples" aria-label="Ví dụ theo thị trường">${SAMPLES.map((sample,index)=>`<button type="button" class="v03-sample" data-v03="sample" data-index="${index}">${esc(sample.label)} →</button>`).join('')}</div><p class="v03-small">Chọn ví dụ để điền vào chat, rồi gửi khi đúng ý bạn. Bản 0.3B thử thực phẩm đi Mỹ, Đức (EU) và Nhật bằng nguồn đã lưu; thị trường khác cần làm rõ trước.</p></div>`;}
  function planView(mission) {
    const outcomes=asArray(mission.intent?.outcomes),tasks=asArray(mission.plan?.tasks || mission.plan?.steps);
    return `<section class="v03-message" id="v03-plan" tabindex="-1"><span class="v03-who">Trợ lý nMate</span><div class="v03-card">${marketBadge(mission)}<h2>Mình sẽ giúp bạn làm rõ${outcomes.length>1?' '+outcomes.length+' việc':''}</h2>${outcomes.length?`<ol class="v03-plan-tasks">${outcomes.map(outcome=>`<li>${esc(outcome.title)}</li>`).join('')}</ol>`:`<p>${esc(mission.plan?.summary || 'Cần xác định mục tiêu trước khi nghiên cứu.')}</p>`}<p class="v03-muted">${esc(factReuse(mission))}. Phần chưa rõ được để trống.</p>${scopeNote(mission)}${mission.status==='planned'?button('Bắt đầu nghiên cứu giả lập','start','primary'):''}${tasks.length?`<details class="v03-details"><summary>Xem cách thực hiện</summary><ol class="v03-plan-tasks v03-details-content">${tasks.map(task=>`<li>${esc(task.title)}</li>`).join('')}</ol></details>`:''}<p class="v03-small">Dùng nguồn tham khảo đã lưu. Không gọi mô hình, không phát sinh phí.</p></div></section>`;
  }
  function reuseInfo(mission) {
    const reuse=mission.knowledge?.reuse || mission.knowledge || {},records=sourceRecords(mission),count=Number(mission.knowledge?.metrics?.this_lookup_hits ?? reuse.reused_count ?? reuse.reused_records ?? reuse.cache_hits ?? mission.knowledge?.reused_count ?? 0);
    return `<p class="v03-counter">${esc(factReuse(mission))} · ${count>0?count+' đoạn tri thức dùng lại':records.length+' đoạn nguồn đã lưu'} · 0 lượt AI có phí</p>`;
  }
  function sourcesView(mission) {
    const allRecords=sourceRecords(mission),records=state.sourceTopic?allRecords.filter(record=>asArray(record.topics).includes(state.sourceTopic)):allRecords;
    return `<details class="v03-details" id="v03-sources" ${state.openSources?'open':''}><summary>${state.sourceTopic==='facility_registration'?(marketOf(mission).code==='US'?'Căn cứ đăng ký cơ sở FDA':'Căn cứ điều kiện nhập khẩu'):state.sourceTopic==='food_label'?'Căn cứ chuẩn bị nhãn thực phẩm':'Nguồn và cách dùng lại tri thức'} (${records.length})</summary><div class="v03-details-content"><p class="v03-small">Bản lưu phục vụ kiểm thử. Các trích đoạn và bản dịch là tham khảo, chưa phải kết luận đã được chuyên gia duyệt.</p>${records.map(record=>{
      const url=safeURL(record.url || record.source_url),title=record.title_vi || record.title || record.source_title || record.topic || 'Nguồn tham khảo';
      const vi=record.excerpt_vi || record.text_vi || record.vi || record.translation_vi || record.claim_vi || record.statement_vi || '';
      const original=originalOf(record);
      return `<article class="v03-source"><h3>${esc(title)}</h3>${vi?`<p>${esc(vi)}</p>`:''}<p class="v03-small">${esc(record.publisher_vi || record.organization || 'Cơ quan công bố nguồn')} · ${esc(dateVi(record.checked_at || record.fetched_at || record.observed_at || record.retrieved_at))}${(record.review_status || record.review_state)==='reference_unreviewed'?' · Chưa duyệt chuyên môn':''}</p>${original.text?`<details class="v03-details"><summary>Xem ${esc(LANGUAGE_NAMES[original.language] || 'nguyên bản')}${original.language?' gốc':''}</summary><p class="v03-original" ${original.language?`lang="${esc(original.language)}"`:''}>${esc(original.text)}</p></details>`:''}${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">Mở nguồn gốc ↗</a>`:''}</article>`;
    }).join('') || '<p class="v03-muted">Chưa có trích đoạn phù hợp để đưa ra kết luận cho câu hỏi này.</p>'}${state.sourceTopic?button('Xem tất cả '+allRecords.length+' đoạn nguồn','all-sources','subtle'):''}</div></details>`;
  }
  function factsEditor() {
    const entity=productEntity(),version=entity?.version || state.mission?.product?.version || 0;
    const draftKey=(entity?.id || entity?.entity_id || state.mission?.product?.entity_id || '')+':'+version+':'+(marketProfile()?.entity_id || marketProfile()?.id || '')+':'+(marketProfile()?.version || 0);if(state.factDraftKey!==draftKey){state.factDraftKey=draftKey;state.factDraft={};}
    const fieldValue=key=>state.factDraft[key] ?? textValue(factValue(key));
    if(!state.mission?.product?.entity_id)return `<p class="v03-muted">${entity?'Mở một câu hỏi đã lưu để xem và sửa đúng hồ sơ sản phẩm.':'Chưa có sản phẩm trong hồ sơ. Trao đổi với trợ lý để tạo kế hoạch đầu tiên.'}</p>`;
    const effectiveScope=state.view==='chat' && state.factScope==='full' && labelOf(state.mission)?'facility':state.factScope;
    const allowed=FACT_SCOPES[effectiveScope] || FACT_FIELDS.map(([key])=>key),keys=state.factKeys.length?state.factKeys:allowed;
    const fields=FACT_FIELDS.filter(([key])=>keys.includes(key) && (key!=='fda_registration_status' || marketOf(state.mission).code==='US') && (!['date_marking','storage_instructions','ingredients_declaration'].includes(key) || ['DE','JP'].includes(marketOf(state.mission).code))),scoped=effectiveScope!=='full',scopeTitle=({label:'Bổ sung dữ kiện để làm nhãn',facility:'Bổ sung thông tin cơ sở',relevant:'Bổ sung dữ kiện theo câu hỏi'})[effectiveScope] || 'Thông tin sản phẩm để dùng lại';
    return `<details class="v03-details v03-facts" id="v03-facts" ${state.openFacts?'open':''}><summary>${esc(scopeTitle)}</summary><form class="v03-details-content" id="v03-facts-form"><p class="v03-profile-meta">Dữ kiện do doanh nghiệp cung cấp · phiên bản ${esc(version)}${marketProfile()?' · hồ sơ '+esc(marketOf(state.mission).name_vi)+' phiên bản '+esc(marketProfile().version):''}. Thay đổi sẽ đánh dấu kết quả liên quan cần cập nhật.</p><div class="v03-fields">${fields.map(([key,title,hint])=>`<label class="v03-field"><span>${esc(title)}${MARKET_FACT_FIELDS.includes(key)?' · '+esc(marketOf(state.mission).name_vi):' · dùng chung'}</span>${['ingredients','ingredients_declaration','facility_activity','facility_address','processing_description','allergens','nutrition_information','date_marking','storage_instructions','ingredients_declaration','packaging','responsible_business'].includes(key)?`<textarea name="${key}" rows="2" maxlength="2000">${esc(fieldValue(key))}</textarea>`:`<input name="${key}" value="${esc(fieldValue(key))}" maxlength="2000">`}<small>${esc(hint)}</small></label>`).join('')}</div><button class="v03-button primary" ${state.busy?'disabled':''}>Lưu vào hồ sơ doanh nghiệp</button><p class="v03-small">Lưu ở đây cập nhật hồ sơ doanh nghiệp để dùng lại; không tự sửa khung nhãn đã lưu. Ô trống không xóa dữ kiện đã có.</p>${scoped?button('Mở hồ sơ doanh nghiệp','profile','subtle'):''}</form></details>`;
  }
  function hasUnsavedLabel() {
    const label=labelOf(state.mission);
    return !!label && (labelFields(label).some(field=>textValue(state.labelDraft[field.key] ?? field.value).trim()!==textValue(field.value).trim() || (fieldConflict(label,field) && ['draft','ssot','edited'].includes(state.labelConflictChoices[field.key]))) || Object.entries(state.labelRemember).some(([key,selected])=>selected && textValue(state.labelDraft[key]).trim()));
  }
  function hasUnsavedFacts() {return Object.entries(state.factDraft).some(([field,value])=>textValue(value).trim()!==textValue(factValue(field)).trim());}
  function renderLabelField(label,field) {
    if(isRawIngredients(label,field,marketOf(state.mission).code))return `<div class="v03-label-field v03-raw-ingredients"><p class="v03-original">${esc(textValue(field.value) || 'Chưa khai thành phần sản phẩm.')}</p><small class="v03-small">Dữ kiện tham chiếu chưa dịch. Điền cách ghi thành phần trong ô nhãn riêng cho ${esc(marketOf(state.mission).name_vi)}; sửa công thức gốc trong Hồ sơ.</small></div>`;
    const conflict=fieldConflict(label,field),choice=state.labelConflictChoices[field.key] || '',sharedReview=needsLanguageReview(state.mission,field),hint=sharedReview?(field.key==='ingredients'?'Chưa có bản dịch thành phần được duyệt.':'Kiểm tra cách ghi lượng tịnh và đơn vị.'):field.help_vi;
    return `<div class="v03-label-field"><label class="v03-field"><span>${esc(field.label_vi)} <span class="v03-en" ${labelLanguage(state.mission)?`lang="${esc(labelLanguage(state.mission))}"`:''}>${esc(field.label_original || field.label_en || '')}</span></span><textarea name="${esc(field.key)}" rows="2" maxlength="2000" ${labelLanguage(state.mission)?`lang="${esc(labelLanguage(state.mission))}"`:''} placeholder="Chưa có dữ kiện — để trống">${esc(state.labelDraft[field.key] ?? textValue(field.value))}</textarea>${hint?`<small>${esc(hint)}</small>`:''}</label>${!conflict && !sharedReview && field.state==='needs_review'?'<p class="v03-warning">Nội dung đã được giữ lại; phần này cần rà theo dữ kiện hoặc nguồn mới.</p>':''}${conflict?`<div class="v03-warning v03-conflict"><p><strong>Nội dung nhãn và hồ sơ đang khác nhau.</strong></p><p>Hồ sơ: ${esc(textValue(conflict.ssot_value) || 'Chưa có dữ kiện')}<br>Nhãn đã lưu: ${esc(textValue(conflict.draft_value))}</p><label class="v03-field"><span>Bạn muốn dùng nội dung nào?</span><select id="v03-conflict-${esc(field.key)}" name="conflict_${esc(field.key)}"><option value="">Chọn trước khi sửa hoặc ghi nhớ trường này</option><option value="draft" ${choice==='draft'?'selected':''}>Giữ nội dung nhãn đã lưu</option><option value="ssot" ${choice==='ssot'?'selected':''}>Dùng dữ kiện trong hồ sơ</option><option value="edited" ${choice==='edited'?'selected':''}>Dùng nội dung tôi vừa sửa ở trên</option></select></label></div>`:''}</div>`;
  }
  function labelEditor(mission) {
    const label=labelOf(mission);if(!label) return '';
    const fields=labelFields(label),{visible,later,known,readonly,attention,filled}=labelEditorSections(label,state.labelDraft,state.labelVisibleMissing,marketOf(mission).code),memory=fields.filter(field=>LABEL_MEMORY_FIELDS.includes(field.key) && !isRawIngredients(label,field,marketOf(mission).code)),sharedReview=fields.some(field=>needsLanguageReview(mission,field));
    const remembered=Object.keys(state.labelRemember).filter(key=>state.labelRemember[key]).length,continued=!!label.parent_artifact_ref;
    return `<details class="v03-details v03-workbook" id="v03-workbook" ${state.openLabel?'open':''}><summary>${continued?'Tiếp tục nhãn đã lưu':'Mở '+labelTitle(mission)+' · bản '+esc(label.version || 1)}</summary><form class="v03-details-content" id="v03-label-form"><div class="v03-bubble v03-label-prompt">${continued?'Tiếp từ bản đã lưu trước; bản trước vẫn trong lịch sử. ':''}${filled?'Mình đã giữ '+filled+' nội dung có sẵn. Bạn chỉ cần bổ sung hoặc rà phần dưới.':'Mình chưa có nội dung nhãn. Bạn điền phần nào đã biết; phần chưa rõ cứ để trống.'}</div><p class="v03-readiness" id="v03-label-readiness">${filled}/${fields.length} trường đã có nội dung. ${state.labelSaved?'Đã lưu trên máy chủ.':hasUnsavedLabel()?'Có thay đổi chưa lưu.':'Đây là bản đang được lưu trên máy chủ.'}</p>${sharedReview?`<p class="v03-small v03-language-review">Dữ kiện chung được giữ nguyên; cần rà cách ghi bằng ${esc(LANGUAGE_NAMES[labelLanguage(mission)] || 'ngôn ngữ nhãn')}. Chưa tự dịch hoặc duyệt để in.</p>`:''}${visible.length?`<div class="v03-fields">${visible.map(field=>renderLabelField(label,field)).join('')}</div>`:''}${later.length?`<details class="v03-details"><summary>Thêm ${later.length} phần ${attention.length?'cần bổ sung hoặc rà':'còn thiếu khi đã có dữ kiện'}</summary><div class="v03-details-content v03-fields">${later.map(field=>renderLabelField(label,field)).join('')}</div></details>`:''}${readonly.length?`<details class="v03-details v03-shared-recipe"><summary>Thành phần sản phẩm đã khai · dùng chung</summary><div class="v03-details-content">${readonly.map(field=>renderLabelField(label,field)).join('')}</div></details>`:''}${known.length?`<details class="v03-details"><summary>${known.length} nội dung đã có · Sửa khi cần</summary><div class="v03-details-content v03-fields">${known.map(field=>renderLabelField(label,field)).join('')}</div></details>`:''}${memory.length?`<details class="v03-details v03-memory"><summary>Nhớ dữ kiện vào hồ sơ (tùy chọn)</summary><div class="v03-details-content"><p class="v03-small">Chọn đúng nội dung bạn xác nhận để lần sau dùng lại. Thành phần và lượng tịnh dùng chung cho sản phẩm; nội dung nhãn còn lại chỉ nhớ vào hồ sơ ${esc(marketOf(mission).name_vi)}. Dữ kiện do bạn cung cấp, chưa được kiểm chứng bên ngoài. Không chọn thì chỉ lưu bản nhãn.</p><p class="v03-small" id="v03-memory-empty" ${rememberableFields(label,state.labelDraft).length?'hidden':''}>Điền nội dung nhãn ở trên; chỉ những ô đã có nội dung mới xuất hiện để chọn ghi nhớ.</p>${memory.map(field=>`<label class="v03-check v03-memory-choice" id="v03-memory-choice-${esc(field.key)}" ${textValue(state.labelDraft[field.key] ?? field.value).trim()?'':'hidden'}><input type="checkbox" name="remember_${esc(field.key)}" ${state.labelRemember[field.key]?'checked':''}><span><strong>${esc(field.label_vi)} · ${MARKET_FACT_FIELDS.includes(field.key)?esc(marketOf(mission).name_vi):'dùng chung'}</strong><span class="v03-memory-value" id="v03-memory-${esc(field.key)}">${esc(textValue(state.labelDraft[field.key] ?? field.value) || 'Chưa có nội dung; sẽ không ghi nhớ ô trống.')}</span></span></label>`).join('')}</div></details>`:''}<button id="v03-label-save" class="v03-button primary" ${state.busy?'disabled':''}>${remembered?'Lưu nhãn & nhớ '+remembered+' dữ kiện':'Lưu bản nhãn'}</button>${state.labelSaved?'<p class="v03-save-state" role="status">Đã lưu khung nhãn và giữ lịch sử phiên bản.</p>':''}<p class="v03-small">Khung nhãn chưa được duyệt để in. Lưu và ghi nhớ không gọi AI, không phát sinh phí.</p><details class="v03-details"><summary>Xem bản nhãn đã lưu</summary><p class="v03-label-preview" ${labelLanguage(mission)?`lang="${esc(labelLanguage(mission))}"`:''}>${esc(labelPreview(label,marketOf(mission).code))}</p>${labelDownload(label)?button('Tải khung nhãn (.md)','download-label','subtle'):''}<p class="v03-small">Tệp chứa đúng bản đã lưu trên máy chủ; các sửa đổi chưa lưu chưa có trong tệp.</p></details></form></details>`;
  }
  function resultView(mission) {
    const answers=answersOf(mission),actions=asArray(mission.actions),stale=mission.status==='needs_revalidation' || mission.needs_revalidation;
    return `<section class="v03-message v03-mission-result" id="v03-result" tabindex="-1"><span class="v03-who">Trợ lý nMate</span><div class="v03-card">${marketBadge(mission)}<div class="v03-card-title"><h2>Kết quả cho ${esc(mission.product?.name || 'sản phẩm của bạn')}</h2><span class="v03-chip ${stale?'warn':''}">${esc(stale?'Nhận định cần rà':'Đã lưu')}</span></div>${stale?`<div class="v03-warning">Nhãn và dữ kiện đã lưu được giữ. Nhận định bên dưới dùng dữ kiện trước khi thay đổi; bạn có thể rà lại nhận định khi cần.${mission.stale_reason?`<details class="v03-details"><summary>Vì sao cần rà?</summary><p class="v03-small">${esc(mission.stale_reason)}</p></details>`:''}<div class="v03-row" style="margin-top:10px">${button('Rà lại nhận định · giả lập','revalidate','subtle')}</div></div>`:''}${answers.map(answer=>`<article class="v03-answer"><h3>${esc(answer.title)}</h3><p>${esc(answer.text)}</p>${answer.status==='insufficient_evidence'?'<p class="v03-small">Chưa đủ căn cứ phù hợp để kết luận.</p>':''}</article>`).join('')}${answers.some(answer=>answer.details_vi)?`<details class="v03-details"><summary>Giải thích thêm và điều kiện áp dụng</summary><div class="v03-details-content">${answers.filter(answer=>answer.details_vi).map(answer=>`<div><h3>${esc(answer.title)}</h3><p class="v03-muted">${esc(textValue(answer.details_vi))}</p></div>`).join('')}</div></details>`:''}${reuseInfo(mission)}${scopeNote(mission)}${actions.length?`<div><h3>Việc tiếp theo theo câu hỏi của bạn</h3><div style="margin-top:10px">${actions.map((action,index)=>`<article class="v03-action"><h3>${esc(action.title)}</h3>${action.reason?`<p class="v03-muted">${esc(action.reason)}</p>`:''}${actionButton(action,index)}${action.kind==='review_sources'?'<p class="v03-small">Đây là gợi ý để bạn tự thực hiện; ứng dụng chỉ mở nguồn, chưa gửi yêu cầu cho chuyên gia.</p>':''}</article>`).join('')}</div></div>`:''}${labelEditor(mission)}${state.openFacts || asArray(mission.intent?.outcomes).some(outcome=>outcome.id==='registration')?factsEditor():''}${sourcesView(mission)}<p class="v03-small">${esc(dateVi(mission.updated_at || mission.created_at))} · ${esc(statusName(mission.status))}. Kết quả tham khảo theo dữ kiện đã chọn.</p></div></section>`;
  }
  function missionView(mission) {
    let content='';
    if (mission.status==='planned') content=planView(mission);
    else if(isBusyMission(mission)) content=`<section class="v03-message"><span class="v03-who">Trợ lý nMate</span><div class="v03-card">${marketBadge(mission)}${spinner('Đang đối chiếu theo kế hoạch giả lập…')}<p class="v03-muted">Bạn có thể tải lại trang. Kế hoạch và tiến độ được lưu ở máy chủ; đọc lại không tạo lượt mới.</p><details class="v03-details"><summary>Xem tiến độ công việc</summary><ol class="v03-plan-tasks v03-details-content">${asArray(mission.plan?.tasks).map(task=>`<li>${esc(task.title)} · ${esc(({planned:'Chưa chạy',running:'Đang làm',completed:'Xong',done:'Xong',failed:'Chưa hoàn tất'})[task.status] || task.status)}</li>`).join('')}</ol></details></div></section>`;
    else if(mission.status==='waiting_input') content=`<section class="v03-message"><span class="v03-who">Trợ lý nMate</span><div class="v03-bubble">${esc(mission.clarification_question || mission.intent?.clarification_question || mission.clarification || mission.message || asArray(mission.intent?.ambiguities).join('\n') || 'Bạn muốn làm rõ phần nào cho sản phẩm của mình?')}</div>${productCandidates(mission).length?`<div class="v03-options" aria-label="Chọn hồ sơ sản phẩm">${productCandidates(mission).map((candidate,index)=>`<button type="button" class="v03-button subtle" data-v03="choose-product" data-index="${index}">${esc(candidate.name)} · hồ sơ ${index+1}</button>`).join('')}</div>`:marketChoices(mission).length?`<div class="v03-options" aria-label="Chọn thị trường cho lượt này">${marketChoices(mission).map((choice,index)=>`<button type="button" class="v03-button subtle" data-v03="choose-market" data-index="${index}">${esc(choice.label)}</button>`).join('')}</div><p class="v03-small">Chọn để điền lựa chọn vào chat, rồi gửi. Mỗi hồ sơ chỉ áp dụng một thị trường.</p>`:asArray(mission.intent?.outcomes).some(outcome=>outcome.id==='clarification')?`<div class="v03-options" aria-label="Gợi ý làm rõ mục tiêu">${clarificationChoices(mission).map((choice,index)=>`<button type="button" class="v03-button subtle" data-v03="clarify-choice" data-index="${index}">${esc(choice.label)}</button>`).join('')}</div><p class="v03-small">Chọn để điền vào ô chat, rồi gửi khi đúng ý bạn.</p>`:''}</section>`;
    else if(mission.status==='failed') content=`<section class="v03-message"><span class="v03-who">Trợ lý nMate</span><div class="v03-error">Chưa hoàn tất kế hoạch này. ${esc(mission.stale_reason || mission.error?.message || (typeof mission.error==='string'?mission.error:''))}<p>Tiến trình đã dừng; không có lượt nào tự chạy lại.</p></div></section>`;
    else content=resultView(mission);
    return `<section class="v03-message v03-user"><span class="v03-who">${esc(account().username || 'Bạn')}</span><div class="v03-bubble">${esc(mission.question)}</div></section>${content}`;
  }
  function chatView() {return `<div class="v03-chat">${errorNotice()}${state.notice?`<div class="v03-notice" role="status">${esc(state.notice)}</div>`:''}${state.mission?missionView(state.mission):welcome()}${state.busy?spinner('Đang lưu và đọc kết quả…'):''}${state.mission?`<div class="v03-row">${button('Câu hỏi mới','new','subtle')}</div>`:''}</div>`;}
  function historyView() {return `<div class="v03-page-head"><h2>Các câu hỏi đã lưu</h2>${button('Về trợ lý','back','subtle')}</div>${errorNotice()}<p class="v03-muted" style="margin-bottom:16px">Chỉ hồ sơ của ${esc(enterprise()?.name || 'doanh nghiệp của bạn')}.</p><div class="v03-history">${state.history.length?state.history.map(item=>`<button type="button" class="v03-history-item" data-v03="open-mission" data-id="${esc(item.id)}"><strong>${esc(item.product?.name || item.product_name || item.title || 'Câu hỏi đã lưu')}</strong>${marketBadge(item)}<span>${esc(item.question || item.user_text)}</span><span class="v03-small">${esc(dateVi(item.updated_at || item.created_at))} · ${esc(statusName(item.status))}</span></button>`).join(''):'<p class="v03-empty">Chưa có câu hỏi nào. Bắt đầu trao đổi với trợ lý để lưu kế hoạch đầu tiên.</p>'}</div>`;}
  function profileView() {return `<div class="v03-page-head"><h2>Hồ sơ doanh nghiệp</h2>${button('Về trợ lý','back','subtle')}</div>${errorNotice()}<div class="v03-chat"><div class="v03-card">${state.mission?marketBadge(state.mission):''}<h3>${esc(enterprise()?.name || 'Doanh nghiệp')}</h3><p class="v03-profile-meta">Đang dùng tài khoản ${esc(account().username)}.</p><p class="v03-muted">Hồ sơ được lưu ở máy chủ. Đăng nhập cùng tài khoản ở trình duyệt khác để dùng lại; dữ kiện doanh nghiệp không đi vào kho tri thức chung.</p>${factsEditor()}</div><div class="v03-card"><h3>Phiên đăng nhập</h3><p class="v03-muted">Đăng xuất sẽ đóng hồ sơ trên màn hình này.</p>${button('Đăng xuất','logout','subtle')}</div></div>`;}
  function composer() {return `<footer class="v03-footer"><form class="v03-composer" id="v03-chat-form"><label class="v03-composer-label" for="v03-question">Câu hỏi cho trợ lý</label><textarea id="v03-question" name="question" rows="1" maxlength="4000" placeholder="Bạn muốn làm rõ điều gì?" ${state.busy || isBusyMission(state.mission)?'disabled':''}>${esc(state.question)}</textarea><button class="v03-send" aria-label="Gửi câu hỏi" ${state.busy || isBusyMission(state.mission)?'disabled':''}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V5m-6 6 6-6 6 6"/></svg></button></form></footer>`;}
  function render() {
    const oldFocus=document.activeElement,focusId=oldFocus?.id,selection=focusId==='v03-question'?oldFocus.selectionStart:null;
    root.innerHTML=`<div class="v03-shell">${header()}<main id="v03-main" class="v03-main" tabindex="-1">${isAuthenticated()?(state.view==='history'?historyView():state.view==='profile'?profileView():chatView()):authView()}</main>${isAuthenticated() && state.view==='chat'?composer():''}</div><div class="v03-toast" id="v03-toast" role="status" aria-live="polite" ${state.toast?'':'hidden'}>${esc(state.toast)}</div>`;
    if(focusId==='v03-question' && !state.busy) {const field=document.getElementById(focusId);field?.focus({preventScroll:true});if(selection!=null)field?.setSelectionRange(selection,selection);}
  }
  async function openMission(id) {pollEpoch++;clearTimeout(state.pollTimer);state.openLabel=false;state.openFacts=false;state.openSources=false;state.sourceTopic=null;state.factScope='full';state.factKeys=[];state.factDraft={};state.factDraftKey='';state.labelSaved=false;receiveMission(await call('get_mission',{mission_id:id}));await loadContext();state.view='chat';pollMission();}
  root.addEventListener('click',event=>{
    const target=event.target.closest('[data-v03]');if(!target) return;
    const action=target.dataset.v03;
    if(action==='dismiss-error'){state.error='';render();return;}
    if(action==='toggle-auth'){state.authMode=state.authMode==='register'?'login':'register';state.error='';render();return;}
    if(action==='sample'){const index=Number(target.dataset.index),sample=Number.isSafeInteger(index) && index>=0?SAMPLES[index]:null;if(!sample)return;state.question=sample.question;state.pendingMarket=null;render();document.getElementById('v03-question')?.focus();return;}
    if(action==='choose-market'){const index=Number(target.dataset.index),choice=Number.isSafeInteger(index) && index>=0?marketChoices(state.mission)[index]:null;if(!choice)return;state.question=choice.question;state.pendingMarket=choice.code;render();document.getElementById('v03-question')?.focus();return;}
    if(action==='choose-product'){const index=Number(target.dataset.index),candidate=Number.isSafeInteger(index) && index>=0?productCandidates(state.mission)[index]:null;if(candidate)void runAction(()=>prepare(state.mission.question,{product_entity_id:candidate.entity_id,continue:false}),true);return;}
    if(action==='clarify-choice'){const index=Number(target.dataset.index),choice=Number.isSafeInteger(index) && index>=0?clarificationChoices(state.mission)[index]:null;if(!choice)return;state.question=choice.question;state.pendingMarket=null;render();document.getElementById('v03-question')?.focus();return;}
    if(action==='start'){void runAction(start,true);return;}
    if(action==='back'){const pendingFacts=hasUnsavedFacts();state.view='chat';state.error='';state.openFacts=false;state.factScope='full';state.factKeys=[];if(pendingFacts)state.notice='Đã giữ bản nháp dữ kiện chưa lưu. Mở Hồ sơ doanh nghiệp để tiếp tục; bản nhãn vẫn được giữ.';render();focusResult();return;}
    if(action==='new'){
      if(hasUnsavedLabel()){state.openLabel=true;state.error='Bạn có nội dung nhãn chưa lưu. Lưu nhãn trước khi mở câu hỏi mới để không mất phần vừa nhập.';render();return;}
      if(hasUnsavedFacts()){state.view='profile';state.openFacts=true;state.factScope='full';state.factKeys=[];state.error='Bạn có dữ kiện hồ sơ chưa lưu. Lưu dữ kiện trước khi mở câu hỏi mới để không mất phần vừa nhập.';render();return;}
      pollEpoch++;clearTimeout(state.pollTimer);state.mission=null;state.labelDraft={};state.labelDraftKey='';state.labelRemember={};state.labelConflictChoices={};state.labelVisibleMissing=3;state.labelSaved=false;state.openLabel=false;state.openFacts=false;state.openSources=false;state.sourceTopic=null;state.factScope='full';state.factKeys=[];state.factDraft={};state.factDraftKey='';state.question='';state.pendingMarket=null;state.error='';state.notice='';try {sessionStorage.removeItem(memoryKey());} catch {}render();document.getElementById('v03-question')?.focus();return;
    }
    if(action==='mission-action'){
      const index=Number(target.dataset.index),item=Number.isSafeInteger(index) && index>=0?asArray(state.mission?.actions)[index]:null;
      if(!item || !['edit_label','supply_facts','review_sources'].includes(item.kind))return;
      let destination;
      if(item.kind==='edit_label'){state.openLabel=true;destination='v03-workbook';}
      else if(item.kind==='supply_facts'){const selected=factSelection(state.mission,item);if(selected.scope==='label' && labelOf(state.mission)){state.openLabel=true;state.openFacts=false;destination='v03-workbook';}else{state.factScope=selected.scope;state.factKeys=selected.keys;state.openFacts=true;destination='v03-facts';}}
      else {const ids=asArray(item.outcome_ids);state.sourceTopic=ids.length===1 && ids[0]==='registration'?'facility_registration':ids.length===1 && ids[0]==='label'?'food_label':null;state.openSources=true;destination='v03-sources';}
      render();requestAnimationFrame(()=>document.getElementById(destination)?.scrollIntoView({block:'start',behavior:'instant'}));return;
    }
    if(action==='open-label'||action==='open-facts'){state.openLabel=action==='open-label';state.openFacts=action==='open-facts';state.factScope='full';state.factKeys=[];render();requestAnimationFrame(()=>document.getElementById(action==='open-label'?'v03-workbook':'v03-facts')?.scrollIntoView({block:'start',behavior:'instant'}));return;}
    if(action==='open-full-facts'){state.factScope='full';state.factKeys=[];state.openFacts=true;render();requestAnimationFrame(()=>document.getElementById('v03-facts')?.scrollIntoView({block:'start',behavior:'instant'}));return;}
    if(action==='open-sources'){state.openSources=true;state.sourceTopic='facility_registration';render();requestAnimationFrame(()=>document.getElementById('v03-sources')?.scrollIntoView({block:'start',behavior:'instant'}));return;}
    if(action==='all-sources'){state.sourceTopic=null;state.openSources=true;render();requestAnimationFrame(()=>document.getElementById('v03-sources')?.scrollIntoView({block:'start',behavior:'instant'}));return;}
    if(action==='download-label'){const file=labelDownload(labelOf(state.mission));if(!file){announce('Chưa có khung nhãn đã lưu để tải.');return;}const url=URL.createObjectURL(new Blob([file.content],{type:file.mime})),link=document.createElement('a');link.href=url;link.download=file.filename;link.click();setTimeout(()=>URL.revokeObjectURL(url),5000);announce('Đã tải đúng bản khung nhãn đã lưu.');return;}
    if(action==='history'){void runAction(async()=>{const value=await call('list_missions');state.history=asArray(value?.missions || value?.items || value);state.view='history';});return;}
    if(action==='profile'){void runAction(async()=>{await loadContext();state.openFacts=false;state.factScope='full';state.factKeys=[];state.view='profile';});return;}
    if(action==='open-mission'){void runAction(()=>openMission(target.dataset.id),true);return;}
    if(action==='revalidate'){const question=state.mission?.question;void runAction(async()=>{await prepare(question);if(state.mission?.status==='planned')await start();},true);return;}
    if(action==='logout'){void runAction(async()=>{await request('logout',{});resetPrivateState();setSession(await request('session'));state.authMode='login';});}
  });
  root.addEventListener('input',event=>{
    const element=event.target;
    if(element.id==='v03-question'){state.question=element.value;state.pendingMarket=null;element.style.height='44px';element.style.height=Math.min(element.scrollHeight,100)+'px';}
    if(element.closest('#v03-label-form')){
      const label=labelOf(state.mission),fields=labelFields(label),memoryKey=element.name?.startsWith('remember_')?element.name.slice(9):null,conflictKey=element.name?.startsWith('conflict_')?element.name.slice(9):null;
      if(memoryKey && LABEL_MEMORY_FIELDS.includes(memoryKey) && fields.some(field=>field.key===memoryKey && !isRawIngredients(label,field,marketOf(state.mission).code)))state.labelRemember[memoryKey]=element.checked === true;
      else if(conflictKey && fields.some(field=>field.key===conflictKey) && ['draft','ssot','edited',''].includes(element.value)){
        state.labelConflictChoices[conflictKey]=element.value;const field=fields.find(item=>item.key===conflictKey),conflict=fieldConflict(label,field);
        if(conflict && ['draft','ssot'].includes(element.value)){state.labelDraft[conflictKey]=textValue(element.value==='draft'?conflict.draft_value:conflict.ssot_value);render();}
      }else if(fields.some(field=>field.key===element.name && !isRawIngredients(label,field,marketOf(state.mission).code))){
        state.labelDraft[element.name]=element.value;
        if(fieldConflict(label,fields.find(field=>field.key===element.name))){state.labelConflictChoices[element.name]='edited';const choice=document.getElementById('v03-conflict-'+element.name);if(choice)choice.value='edited';}
      }
      state.labelSaved=false;
      const filled=fields.filter(field=>textValue(state.labelDraft[field.key] ?? field.value).trim()).length,remembered=Object.keys(state.labelRemember).filter(key=>state.labelRemember[key] && textValue(state.labelDraft[key]).trim()).length;
      const readiness=document.getElementById('v03-label-readiness'),save=document.getElementById('v03-label-save');if(readiness)readiness.textContent=filled+'/'+fields.length+' trường đã có nội dung. Có thay đổi chưa lưu.';if(save)save.textContent=remembered?'Lưu nhãn & nhớ '+remembered+' dữ kiện':'Lưu bản nhãn';
      for(const field of fields){const value=textValue(state.labelDraft[field.key] ?? field.value),preview=document.getElementById('v03-memory-'+field.key),row=document.getElementById('v03-memory-choice-'+field.key);if(preview)preview.textContent=value;if(row)row.hidden=!value.trim();}
      const emptyMemory=document.getElementById('v03-memory-empty');if(emptyMemory)emptyMemory.hidden=rememberableFields(label,state.labelDraft).length>0;
    }
    if(element.closest('#v03-facts-form'))state.factDraft[element.name]=element.value;
    if(element.closest('#v03-auth-form') && element.name!=='password')state.authDraft[element.name]=element.value;
  });
  root.addEventListener('toggle',event=>{
    const target=event.target;
    if(!target?.isConnected || document.getElementById(target.id)!==target)return;
    if(target.id==='v03-workbook')state.openLabel=target.open;
    if(target.id==='v03-facts')state.openFacts=target.open;
    if(target.id==='v03-sources')state.openSources=target.open;
  },true);
  root.addEventListener('submit',event=>{
    const form=event.target;if(!form.matches('#v03-auth-form,#v03-chat-form,#v03-label-form,#v03-facts-form'))return;event.preventDefault();if(state.busy || !form.reportValidity())return;
    const data=new FormData(form);
    if(form.id==='v03-auth-form'){const payload=Object.fromEntries(data.entries());void runAction(async()=>{setSession(await request(state.authMode,payload));state.authDraft={};await loadContext();});return;}
    if(form.id==='v03-chat-form'){void runAction(()=>prepare(data.get('question')),true);return;}
    if(form.id==='v03-label-form'){
      const mission=state.mission,label=labelOf(mission),all=labelFields(label),values=Object.fromEntries(all.map(field=>[field.key,textValue(data.get(field.key) ?? state.labelDraft[field.key] ?? field.value).trim()]));
      const changed=Object.fromEntries(all.filter(field=>!isRawIngredients(label,field,marketOf(mission).code)).filter(field=>values[field.key]!==textValue(field.value).trim() || (fieldConflict(label,field) && ['draft','ssot','edited'].includes(state.labelConflictChoices[field.key]))).map(field=>[field.key,values[field.key]]));
      const remember=all.filter(field=>LABEL_MEMORY_FIELDS.includes(field.key) && !isRawIngredients(label,field,marketOf(mission).code) && state.labelRemember[field.key] && values[field.key]).map(field=>field.key);
      const choices=Object.fromEntries(all.filter(field=>fieldConflict(label,field) && (Object.hasOwn(changed,field.key) || remember.includes(field.key))).map(field=>[field.key,state.labelConflictChoices[field.key] || '']));
      if(Object.values(choices).some(choice=>!['draft','ssot','edited'].includes(choice))){state.error='Nhãn và hồ sơ có nội dung khác nhau. Bạn chọn nội dung muốn dùng ở trường được đánh dấu trước khi lưu.';state.openLabel=true;render();return;}
      if(!Object.keys(changed).length && !remember.length){announce('Nhãn đang là bản đã lưu; không có nội dung mới để lưu.');return;}
      void runAction(async()=>{receiveMission(await call('update_label_progress',{mission_id:mission.id,artifact_id:label.id,fields:changed,remember_fields:remember,expected_artifact_version:label.version,expected_entity_version:productEntity()?.version ?? mission.product?.latest_entity_version ?? mission.product?.version ?? 0,...marketVersionArgs(marketProfile()),conflict_choices:choices,operation_id:operationId()}));state.openLabel=true;state.labelSaved=true;await loadContext();state.notice=remember.length?'Đã lưu nhãn và ghi nhớ '+remember.length+' dữ kiện bạn chọn vào hồ sơ. Dữ kiện do bạn cung cấp, chưa được kiểm chứng bên ngoài.':'Đã lưu bản nhãn. Chưa ghi nhớ thêm dữ kiện vào hồ sơ.';announce(remember.length?'Đã lưu nhãn và ghi nhớ dữ kiện được chọn.':'Đã lưu khung nhãn trên máy chủ.');});return;
    }
    if(form.id==='v03-facts-form'){const entity=productEntity();const facts=Object.entries(Object.fromEntries(data.entries())).filter(([key,value])=>value.trim()!=='' && value.trim()!==textValue(factValue(key))).map(([field,value])=>({field,value:value.trim()}));if(!facts.length){announce('Không có dữ kiện thay đổi.');return;}void runAction(async()=>{
      const value=await call('update_enterprise_facts',{mission_id:state.mission?.id || null,facts,expected_version:entity?.version || state.mission?.product?.version || 0,...marketVersionArgs(marketProfile()),operation_id:operationId()});
      if(value?.id || value?.mission?.id)receiveMission(value);state.factDraft={};state.factDraftKey='';await loadContext();if(state.mission)receiveMission(await call('get_mission',{mission_id:state.mission.id}));state.openFacts=true;state.notice='Đã lưu dữ kiện để dùng lại. Kết quả liên quan cần được cập nhật theo hồ sơ mới.';announce('Đã lưu hồ sơ doanh nghiệp.');
    });}
  });
  root.addEventListener('keydown',event=>{if(event.target.id==='v03-question' && event.key==='Enter' && !event.shiftKey && (event.ctrlKey || event.metaKey)){event.preventDefault();event.target.form.requestSubmit();}});
  async function boot() {
    try {setSession(await request('session'));if(isAuthenticated()) {await loadContext();const id=rememberedMission();if(id)await openMission(id);}state.error='';}
    catch(error) {state.error=error.message;}
    render();pollMission();
  }
  window.NMateV03={version:'0.3B',helpers:publicHelpers};
  void boot();
})();
