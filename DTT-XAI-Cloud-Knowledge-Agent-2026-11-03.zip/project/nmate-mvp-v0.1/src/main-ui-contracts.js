(function () {
  'use strict';
  const list=value=>Array.isArray(value)?value:[];
  const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  function reviewContract(intake){const review=intake?.review;return review?.schema_version==='workspace-review/2'&&review.workspace_id===intake.id&&Number.isInteger(review.revision)&&review.revision>=0&&review.proposal_hashes&&typeof review.proposal_hashes==='object'?review:null;}
  function reviewSnapshotReducer(current,event){
    if(event.type!=='WorkspaceLoaded'||event.expectedScope!==event.currentScope||event.requestEpoch!==event.currentEpoch)return current;
    const incoming=event.intake;if(!incoming?.id||event.expectedWorkspace&&event.expectedWorkspace!==incoming.id)return current;
    if(incoming.review&&!reviewContract(incoming))return current;
    const next=reviewContract(incoming),prior=reviewContract(current);
    if(current?.id===incoming.id&&prior&&(!next||next.revision<prior.revision))return current;
    return incoming;
  }
  function currentContextReducer(current,incoming){
    if(!incoming||!Array.isArray(incoming.entities))return current;
    const before=current?.context_revision??current?.revision,after=incoming.context_revision??incoming.revision;
    if(Number.isInteger(before)&&Number.isInteger(after)&&after<before)return current;
    const known=new Map(list(current?.entities).map(entity=>[entity.id||entity.entity_id,entity.version]));
    if(list(incoming.entities).some(entity=>Number.isInteger(known.get(entity.id||entity.entity_id))&&Number.isInteger(entity.version)&&entity.version<known.get(entity.id||entity.entity_id)))return current;
    return incoming;
  }
  function resourceSnapshotReducer(current,event){
    const incoming=event.value;
    if(event.expectedScope!==event.currentScope||event.requestEpoch!==event.currentEpoch||!incoming?.id||event.expectedId&&incoming.id!==event.expectedId)return current;
    if(current?.id!==incoming.id)return incoming;
    for(const field of ['revision','version','plan_revision'])if(Number.isInteger(current[field])&&(!Number.isInteger(incoming[field])||incoming[field]<current[field]))return current;
    const oldLabel=current.label||current.artifacts?.find?.(item=>item.kind==='food_label_workbook'),newLabel=incoming.label||incoming.artifacts?.find?.(item=>item.kind==='food_label_workbook');
    if(oldLabel?.id&&oldLabel.id===newLabel?.id&&Number.isInteger(oldLabel.version)&&(!Number.isInteger(newLabel.version)||newLabel.version<oldLabel.version))return current;
    return incoming;
  }
  function workspaceContract(value,owner,kind){
    const contract=value?.workspace_contract,scope=contract?.scope;
    if(contract?.schema_version!=='workspace-contract/1'||contract.projection_only!==true||scope?.workspace_id!==value?.id||
      scope.account_id!==owner?.account_id||scope.enterprise_id!==owner?.enterprise_id||kind&&scope.resource_kind!==kind)return null;
    return contract;
  }
  function confirmationReceiptFor(intake,pending,owner){
    const review=reviewContract(intake),request=pending?.request,ids=list(request?.selected_fact_ids);
    if(!review||!pending?.operation_id||request?.operation_id!==pending.operation_id||request.intake_id!==intake.id||!Number.isInteger(request.expected_review_revision)||!ids.length||new Set(ids).size!==ids.length||!Array.isArray(review.pending_candidate_ids)||ids.some(id=>review.pending_candidate_ids.includes(id)))return null;
    return [intake.confirmation_receipt,intake.latest_confirmation_receipt].find(receipt=>receipt?.schema_version==='review-receipt/2'&&receipt.command_kind==='confirm_selected'&&receipt.operation_id===pending.operation_id&&receipt.workspace_id===intake.id&&receipt.actor_id===owner?.account_id&&Number.isInteger(receipt.workspace_revision_after)&&receipt.workspace_revision_after>request.expected_review_revision&&review.revision>=receipt.workspace_revision_after&&ids.every(id=>list(receipt.decisions).some(decision=>decision.candidate_id===id&&['committed','kept_current'].includes(decision.action))))||null;
  }
  function settleConfirmedReviewDraft(intake,draft,pending,owner){
    // A receipt settles only the editor content submitted by that command.
    // An unrelated revision or a later local edit remains comparison material.
    const receipt=confirmationReceiptFor(intake,pending,owner),request=pending?.request;
    if(!receipt||draft?.id!==intake.id||draft.base_review_revision!==request.expected_review_revision)return draft;
    const submitted=pending.editor_snapshot||{selected:Object.fromEntries(request.selected_fact_ids.map(id=>[id,true])),edits:request.edits||{},choices:request.conflict_choices||{}},settled=[];
    const stable=value=>Array.isArray(value)?value.map(stable):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])])):value;
    const same=(left,right)=>JSON.stringify(stable(left))===JSON.stringify(stable(right));
    for(const id of request.selected_fact_ids)if(draft.selected?.[id]===true&&submitted.selected?.[id]===true&&same(draft.edits?.[id],submitted.edits?.[id])&&same(draft.choices?.[id],submitted.choices?.[id]))settled.push(id);
    if(!settled.length)return draft;
    const without=values=>Object.fromEntries(Object.entries(values||{}).filter(([id])=>!settled.includes(id)));
    return {...draft,selected:without(draft.selected),edits:without(draft.edits),choices:without(draft.choices)};
  }
  function planContract(value){
    const plan=value?.intent_plan||value?.research_scope?.intent_plan||value?.workspace_contract?.intent_plan;
    return plan?.schema_version==='intent-plan/1'&&Array.isArray(plan.intent?.goals)&&Array.isArray(plan.requirements)&&Array.isArray(plan.first_actions)?plan:null;
  }
  function disclosure(id,label,body,{open=false,classes=''}={}){
    // body is generated only by the escaped component renderers in this module.
    return `<details class="details ${esc(classes)}" id="${esc(id)}"${open?' open':''}><summary>${esc(label)}</summary><div class="details-content">${body}</div></details>`;
  }
  function planView(value,{id='work-plan',current=false}={}){
    const plan=planContract(value);if(!plan)return '';
    const goals=plan.intent.goals,requirements=plan.requirements,actions=plan.first_actions;
    const goalRows=goals.map(goal=>{
      const refs=requirements.filter(item=>list(goal.requirement_ids).includes(item.id));
      const state=refs.some(item=>item.source_status==='needs_source')?'Còn thiếu căn cứ':refs.some(item=>list(item.missing_inputs).length)?'Cần bổ sung dữ kiện':'Đã xác định phần cần chuẩn bị';
      return `<li><strong>${esc(goal.title_vi)}</strong><small>${esc(state)}</small></li>`;
    }).join('');
    const actionRows=actions.map(action=>`<li><strong>${esc(action.title_vi)}</strong>${action.deliverable_vi?`<p>Đầu ra: ${esc(action.deliverable_vi)}</p>`:''}${action.acceptance_vi?`<p class="small">Xong khi: ${esc(action.acceptance_vi)}</p>`:''}</li>`).join('');
    const exclusions=list(plan.intent.exclusions),labels={registration:'Đăng ký cơ sở',facility_registration:'Đăng ký cơ sở',label:'Nhãn sản phẩm',food_label:'Nhãn sản phẩm',prior_notice:'Thông báo trước lô hàng',fsvp_importer:'Trách nhiệm bên nhập khẩu',certification:'Chứng nhận',origin_marking:'Ghi xuất xứ'};
    const delivery=plan.delivery,validDelivery=delivery?.schema_version==='plan-delivery/1'&&Number.isInteger(delivery.requested_count)&&delivery.requested_count>0&&Number.isInteger(delivery.prepared_count)&&delivery.prepared_count===actions.length&&Number.isInteger(delivery.missing_count)&&delivery.missing_count===Math.max(0,delivery.requested_count-delivery.prepared_count);
    const shortfall=validDelivery&&delivery.status==='partial'&&delivery.missing_count>0&&typeof delivery.reason_vi==='string'?`<p class="small plan-delivery" role="status">${esc(delivery.reason_vi)}</p>`:'';
    const body=`${current?'<p class="small">Kế hoạch chuẩn bị theo hồ sơ hiện hành; giữ riêng phân tích và căn cứ của lượt đã lưu.</p>':''}${goals.length?`<h3>Mục tiêu đang hỗ trợ</h3><ul class="plan">${goalRows}</ul>`:'<p>Chưa đủ thông tin để lập việc cụ thể. Trợ lý cần làm rõ nhu cầu trước.</p>'}${actionRows?`<h3>Việc cần làm</h3><ol class="plan action-briefs">${actionRows}</ol>`:''}${exclusions.length?`<p class="small">Đã loại khỏi phạm vi: ${exclusions.map(key=>esc(labels[key]||'Phần đã yêu cầu bỏ qua')).join(', ')}.</p>`:''}<p class="small">Đây là kế hoạch chuẩn bị; chưa tự thực hiện, ghi hồ sơ hoặc tạo lượt AI mới.</p>`;
    return shortfall+disclosure(id,'Mục tiêu & việc cần làm',body,{classes:'plan-details intent-plan'});
  }
  function policy05DraftFor(value,scope){
    if(!scope?.account_id||!scope.enterprise_id||value?.enterprise_id!==scope.enterprise_id||!value?.id&&!value?.draft_id||!Number.isInteger(value.version)||value.version<1||typeof value.content_hash!=='string'||!value.content_hash)return null;
    if(scope.conversation_id&&value.conversation_id!==scope.conversation_id)return null;
    if(!scope.conversation_id&&scope.policy_case_id&&value.policy_case_id!==scope.policy_case_id)return null;
    if(!scope.conversation_id&&!scope.policy_case_id)return null;
    return value;
  }
  function policy05DraftReducer(current,incoming,scope){
    if(!policy05DraftFor(incoming,scope))return current;
    const id=value=>value?.draft_id||value?.id;
    return id(current)===id(incoming)&&current.version>incoming.version?current:incoming;
  }
  const policy05Fields=Object.freeze({enterprise_summary:'Cơ sở và dữ kiện đã dùng',requested_support:'Nhu cầu hỗ trợ',situation:'Sự việc / tình hình',impact:'Ảnh hưởng tới cơ sở',request:'Điều mong được hướng dẫn / kiến nghị'});
  function policy05EditorDirty(draft,editor){return !!editor&&(String(editor.title??'')!==String(draft.title??'')||Object.keys(policy05Fields).some(field=>String(editor.body?.[field]??'')!==String(draft.body?.[field]??'')));}
  function policy05ApprovalMatches(draft){return !!draft&&draft.status==='approved'&&!!draft.approval&&(draft.approval.approved_version??draft.approval.version??draft.approval.draft_version)===draft.version&&draft.approval.content_hash===draft.content_hash;}
  function mainRouteFor(value,scope){
    if(!scope?.account_id||!scope.enterprise_id||!scope.workspace_key||!value||value.account_id!==scope.account_id||value.enterprise_id!==scope.enterprise_id||value.workspace_key!==scope.workspace_key||!['chat','profile','history'].includes(value.view))return null;
    return {schema_version:'main-route/1',account_id:scope.account_id,enterprise_id:scope.enterprise_id,workspace_key:scope.workspace_key,view:value.view};
  }
  function policy05DraftView(draft,{owner=false,busy=false,editing=false,editor=null,dirty=false,consent=false,currentVerified=true,sharingScope='recipient_only'}={}){
    const id=draft.draft_id||draft.id,version=draft.version,attrs=`data-id="${esc(id)}" data-revision="${version}"`,disabled=busy?' disabled':'',approved=policy05ApprovalMatches(draft);
    const state=approved?'Chủ đã duyệt bản '+version:draft.status==='approved'?'Cần duyệt bản hiện tại':'Bản nháp · Chưa gửi';
    const title=draft.title||(draft.kind==='business_petition'?'Bản kiến nghị của cơ sở':'Đề nghị hướng dẫn tham gia');
    const fieldRows=Object.entries(policy05Fields).filter(([field])=>String(draft.body?.[field]||'').trim()).map(([field,label])=>`<div><h4>${esc(label)}</h4><p class="original">${esc(draft.body[field])}</p></div>`).join('');
    const needs=list(draft.needs).map(item=>`<li><strong>${esc(item.label_vi||item.label||'Nhu cầu cần làm rõ')}</strong><p class="small">${esc(item.reason_vi||item.reason||({needs_source:'Còn thiếu căn cứ hiện hành',needs_input:'Cần bổ sung dữ kiện'})[item.status]||'Chưa kết luận điều kiện hưởng hỗ trợ')}</p></li>`).join('');
    const fields=Object.entries(policy05Fields).map(([field,label])=>`<label class="field"><span>${esc(label)}</span><textarea name="${field}" rows="${field==='enterprise_summary'?2:3}" maxlength="6000" ${disabled}>${esc(editor?.body?.[field]??draft.body?.[field]??'')}</textarea></label>`).join('');
    const historical=draft.is_historical===true;
    const staleEditor=editing&&editor&&editor.base_version!==version,saveBlocked=staleEditor||historical||!currentVerified;
    const dirtyNotice=`<p id="policy05-dirty-${esc(id)}" class="small policy05-dirty" role="status" ${dirty?'':'hidden'}>Có thay đổi chưa lưu · chưa thay đổi bản đã lưu.</p>`;
    const edit=editing?`<form id="main-policy05-edit-form" ${attrs}><label class="field"><span>Tiêu đề hồ sơ</span><input id="policy05-title-${esc(id)}" name="title" maxlength="240" required value="${esc(editor?.title??title)}"${disabled}></label>${fields}${staleEditor?'<p class="warning" role="status">Bản trên máy chủ đã thay đổi. Nội dung chị đang sửa vẫn được giữ; đối chiếu bản mới trước khi lưu.</p>':''}<div class="row"><button type="submit" class="button primary" ${attrs}${disabled}${saveBlocked?' disabled':''}>Lưu bản sửa · giữ hồ sơ chuẩn</button><button type="button" class="button subtle" data-v04="policy05-close-editor" ${attrs}${disabled}>Giữ nháp, đóng sửa</button></div></form>`:`<details class="details policy05-preview"><summary>Xem nội dung bản ${version}</summary><div class="details-content">${fieldRows||'<p>Chưa có nội dung. Sửa bản nháp để bổ sung.</p>'}${list(draft.checklist).length?`<h4>Cần chuẩn bị / xác minh</h4><ul>${list(draft.checklist).map(item=>`<li>${esc(item.label_vi||item.label||'Mục cần bổ sung')}</li>`).join('')}</ul>`:''}</div></details>`;
    const historicalNotice=historical?`<aside class="warning policy05-historical" role="status"><strong>Bản nháp theo hồ sơ trước · cần đối chiếu</strong>${list(draft.current_warnings_vi).map(value=>`<p>${esc(value)}</p>`).join('')}<p class="small">${approved?'Giữ nguyên nội dung và lần duyệt đã lưu.':'Bản này chưa được duyệt; nội dung cũ vẫn được giữ.'} Chuẩn bị bản nháp mới từ hồ sơ hiện hành trước khi lưu, duyệt hoặc gửi; bản PDF này vẫn phản ánh phiên bản cũ. Nội dung chị đang sửa được giữ để đối chiếu.</p></aside>`:'';
    const currentNotice=!currentVerified?'<aside class="warning" role="status"><strong>Chưa xác minh trạng thái hiện hành</strong><p>Giữ bản đã lưu và nội dung đang sửa. Cần đọc lại bản nháp theo hồ sơ hiện hành trước khi duyệt; chưa gửi yêu cầu mới.</p></aside>':'';
    const approval=owner&&!editing&&!approved&&!historical&&currentVerified?`<details class="details policy05-owner-review"><summary>Duyệt nội dung bản nháp</summary><div class="details-content"><p>Kiểm tra bản ${version}, dữ kiện và phần còn thiếu. Duyệt bản nháp chưa gửi cho cơ quan; hồ sơ chuẩn không thay đổi.</p><p class="small">Nơi nhận dự kiến: iHanoi · Doanh nghiệp kiến nghị. Người nhận và chế độ công khai chưa được xác minh qua API. Cần chủ doanh nghiệp đồng ý chia sẻ riêng trước khi gửi; lần duyệt này chỉ duyệt nội dung bản nháp.</p><label class="policy05-consent"><input type="checkbox" id="main-policy05-consent" ${attrs}${consent?' checked':''}${disabled}><span>Tôi đã xem bản ${version} và đồng ý duyệt đúng nội dung bản nháp này. Tôi chưa cho phép gửi ra ngoài.</span></label><button type="button" id="policy05-approve-${esc(id)}" class="button primary" data-v04="policy05-approve" ${attrs}${disabled}${consent?'':' disabled'}>Duyệt bản ${version} · chưa gửi</button></div></details>`:'';
    const pdf='/api/main/policy05/drafts/'+encodeURIComponent(id)+'/pdf?e='+encodeURIComponent(draft.enterprise_id)+'&revision='+version;
    return `<section class="policy05 policy05-draft" id="policy05-draft-${esc(id)}" tabindex="-1"><h3>${esc(title)}</h3><p class="answer-status" role="status">${esc(state)} · Bản ${version}</p>${dirtyNotice}${historicalNotice}${currentNotice}${draft.kind==='request_guidance'?'<p class="small">Chưa xác minh được đợt đang nhận. Đây là đề nghị hướng dẫn, chưa phải đăng ký chương trình.</p>':''}${needs?`<ul class="plan policy05-needs">${needs}</ul>`:''}${edit}${!editing?`<div class="row"><button type="button" class="button subtle" data-v04="policy05-edit" ${attrs}${disabled}>${historical?'Đối chiếu nội dung đang giữ':'Sửa nội dung'}</button><a class="button subtle" href="${esc(pdf)}" target="_blank" rel="noopener">Xem / in PDF bản ${version}</a></div>`:''}${approval}${!owner?'<p class="small">Bản nháp này riêng tư trong tài khoản người soạn. Bản hiện tại chưa hỗ trợ chuyển nháp của nhân viên cho chủ doanh nghiệp duyệt; chưa gửi cho cơ quan.</p>':''}<p class="policy05-handoff small">${esc(draft.submission?.message_vi||'Chưa gửi iHanoi. Chưa có kết nối nghiệp vụ và biên nhận từ cơ quan.')}</p><p class="small">Tạo, sửa, mở lại và xuất bản nháp không gọi AI có phí.</p></section>`;
  }
  const api=Object.freeze({version:'main-ui-contracts/1',reviewContract,reviewSnapshotReducer,currentContextReducer,resourceSnapshotReducer,workspaceContract,confirmationReceiptFor,settleConfirmedReviewDraft,planContract,planView,disclosure,policy05DraftFor,policy05DraftReducer,policy05DraftView,policy05EditorDirty,policy05ApprovalMatches,mainRouteFor,policy05Fields});
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
  else (typeof window!=='undefined'?window:globalThis).NMateUIContracts=api;
})();
