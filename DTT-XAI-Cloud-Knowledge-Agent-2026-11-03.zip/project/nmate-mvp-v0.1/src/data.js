(function () {
  "use strict";

  // Local prototype data only. All enterprises, people, files and activity below
  // are fictional. Public links are reading references, not a compliance verdict.
  const stageNames = [
    "Chưa nghĩ tới xuất khẩu",
    "Đang tìm hiểu",
    "Đang chuẩn bị",
    "Đang tiếp cận khách hàng",
    "Đã có kinh nghiệm xuất khẩu"
  ];

  const questions = [
    {
      id: "q1", title: "Anh/chị bán sản phẩm gì là chính?",
      hint: "Đợt thử này làm sâu với thực phẩm khô. Nhóm khác cần chuyên gia xem trước.",
      options: [
        { value: "a", label: "Thực phẩm, nông sản hoặc sản phẩm OCOP" },
        { value: "b", label: "Thủ công mỹ nghệ" },
        { value: "c", label: "Gỗ, nội thất" },
        { value: "d", label: "Mỹ phẩm, hàng tiêu dùng" },
        { value: "e", label: "Cơ khí, linh kiện" },
        { value: "f", label: "Nhóm sản phẩm khác" }
      ]
    },
    {
      id: "q2", title: "Sản phẩm đã được chứng nhận OCOP chưa?",
      hint: "Chọn theo thông tin đang có; chuyên gia sẽ xem bằng chứng nếu cần.",
      options: [
        { value: "a", label: "Chưa có" },
        { value: "b", label: "3 sao" },
        { value: "c", label: "4 sao" },
        { value: "d", label: "5 sao" },
        { value: "e", label: "Chưa biết hoặc cần kiểm tra lại" }
      ]
    },
    {
      id: "q3", title: "Hàng đã từng đi ra nước ngoài chưa?",
      hint: "Bán qua người trung gian được ghi riêng với việc tự xuất khẩu.",
      options: [
        { value: "a", label: "Chưa bao giờ" },
        { value: "b", label: "Có, qua người trung gian hoặc công ty thương mại" },
        { value: "c", label: "Từng tự bán ra nước ngoài nhưng đã dừng" },
        { value: "d", label: "Đang tự bán ra nước ngoài" }
      ]
    },
    {
      id: "q4", title: "Hiện anh/chị nghĩ tới xuất khẩu ở mức nào?",
      hint: "Câu trả lời giúp chọn việc vừa sức, không quyết định sản phẩm có được xuất khẩu hay không.",
      options: [
        { value: "a", label: "Chưa nghĩ tới" },
        { value: "b", label: "Có nghĩ nhưng chưa bắt đầu" },
        { value: "c", label: "Đang tìm hiểu cách làm" },
        { value: "d", label: "Đang chuẩn bị và đã làm một số việc" }
      ]
    },
    {
      id: "q5", type: "multi", title: "Hiện cơ sở có những giấy tờ nào?",
      hint: "Có thể chọn nhiều. Đây là thông tin tự khai; chưa thay việc kiểm tra hạn và phạm vi áp dụng.",
      options: [
        { value: "a", label: "Đăng ký kinh doanh" },
        { value: "b", label: "Giấy chứng nhận cơ sở đủ điều kiện an toàn thực phẩm" },
        { value: "c", label: "ISO 22000 hoặc HACCP" },
        { value: "d", label: "Halal" },
        { value: "e", label: "Phiếu kiểm nghiệm sản phẩm" },
        { value: "f", label: "Chưa rõ, cần tìm lại" }
      ]
    },
    {
      id: "q6", title: "Nhãn sản phẩm hiện có tiếng Anh không?",
      hint: "Nhãn có tiếng Anh chưa có nghĩa là đã đáp ứng yêu cầu của một thị trường.",
      options: [
        { value: "a", label: "Chưa có" },
        { value: "b", label: "Có một phần" },
        { value: "c", label: "Có đầy đủ nội dung bằng tiếng Anh" }
      ]
    },
    {
      id: "q7", type: "text", title: "Mỗi tháng cơ sở làm ra khoảng bao nhiêu?",
      hint: "Ghi số và đơn vị, ví dụ 500 kg/tháng. Có thể ghi “chưa muốn cung cấp”. Câu này không cộng điểm.",
      options: []
    },
    {
      id: "q8", title: "Có ai hỗ trợ đọc hoặc viết email tiếng Anh không?",
      hint: "Có thể là người trong cơ sở hoặc đầu mối hỗ trợ được phân công.",
      options: [
        { value: "a", label: "Chưa có người hỗ trợ" },
        { value: "b", label: "Có, ở mức cơ bản" },
        { value: "c", label: "Có, sử dụng tốt" }
      ]
    },
    {
      id: "q9", title: "Cơ sở đã bán hàng online chưa?",
      hint: "Tính cả website, Facebook hoặc sàn trong nước; chưa cần có tài khoản sàn quốc tế.",
      options: [
        { value: "a", label: "Chưa bán online" },
        { value: "b", label: "Đã bán online trong nước" }
      ]
    },
    {
      id: "q10", title: "Anh/chị muốn bắt đầu theo cách nào?",
      hint: "Đây là mong muốn ban đầu. Chuyên gia sẽ cùng rà sản phẩm, thị trường và vận chuyển.",
      options: [
        { value: "a", label: "Bán cho công ty thương mại trong nước để họ lo xuất khẩu" },
        { value: "b", label: "Tìm nhà nhập khẩu ở nước ngoài" },
        { value: "c", label: "Tự bán qua sàn hoặc kênh trực tiếp phù hợp" },
        { value: "d", label: "Chưa biết, muốn được giải thích thêm" }
      ]
    },
    {
      id: "q11", title: "Trong 6 tháng tới, cơ sở dự kiến dành mức nào để thử?",
      hint: "Các khoảng chỉ giúp trao đổi về nguồn lực, không phải báo giá hay dự toán xuất khẩu.",
      options: [
        { value: "a", label: "Chưa xác định" },
        { value: "b", label: "Dưới 20 triệu đồng" },
        { value: "c", label: "Từ 20 đến 100 triệu đồng" },
        { value: "d", label: "Trên 100 triệu đồng" }
      ]
    },
    {
      id: "q12", title: "Anh/chị có muốn được liên hệ khi có hỗ trợ phù hợp?",
      hint: "Lựa chọn này sửa được. Gửi hồ sơ ra ngoài hoặc dùng dữ liệu cho mục đích khác cần quyết định riêng.",
      options: [
        { value: "a", label: "Có, theo phạm vi tôi đã đồng ý" },
        { value: "b", label: "Chưa cần nhận liên hệ" }
      ]
    }
  ];

  const routes = [
    {
      id: "trader", name: "Công ty thương mại", title: "Bán qua công ty thương mại trong nước",
      tag: "Cùng người có kinh nghiệm", effort: "Cần làm rõ điều kiện mua và phần việc mỗi bên",
      fit: "Cơ sở muốn tập trung sản xuất, cần đối tác nhận phần việc xuất khẩu.",
      description: "Cơ sở bán cho một doanh nghiệp trong nước. Đối tác lo phần xuất khẩu theo thỏa thuận; cần kiểm ai mua, ai chịu trách nhiệm và giá giao hàng.",
      advantages: ["Trao đổi và chuẩn bị ban đầu bằng tiếng Việt", "Có thể phối hợp với đối tác đã có kênh nhập khẩu", "Tập trung vào quy cách, mẫu và khả năng cung ứng"],
      requirements: ["Có đối tác cụ thể và điều kiện mua được xác nhận", "Thống nhất chất lượng, quy cách, giá và thanh toán", "Ghi rõ bên lo hồ sơ và nghĩa vụ theo từng khâu"]
    },
    {
      id: "importer", name: "Nhà nhập khẩu", title: "Bán cho nhà nhập khẩu ở nước ngoài",
      tag: "Ca chuyên sâu của bản mẫu", effort: "Cần chuyên gia rà hồ sơ và tuyến giao hàng",
      fit: "Cơ sở đã muốn xuất khẩu, có một sản phẩm trọng tâm và sẵn sàng cùng chuyên gia chuẩn bị.",
      description: "Chuẩn bị hồ sơ cho một nhóm người mua cụ thể. Bản mẫu dùng thực phẩm khô tại Mỹ để minh họa; chưa có người mua, báo giá hoặc nhu cầu được xác nhận.",
      advantages: ["Làm rõ yêu cầu của một nhóm người mua", "Có cơ hội trao đổi quy cách và lô hàng cụ thể", "Xác định vai nhập khẩu trước khi thử giao hàng"],
      requirements: ["Dữ liệu sản phẩm và giấy tờ được xác nhận", "Làm rõ bên đứng tên nhập khẩu (IOR) và bên phụ trách xác minh nhà cung cấp nước ngoài (FSVP), nếu áp dụng", "Có thông tin lô, điểm giao và báo giá còn hạn trước tính chi phí"]
    },
    {
      id: "marketplace", name: "Kênh bán trực tiếp", title: "Tự bán qua sàn hoặc kênh phù hợp",
      tag: "Khảo sát trước khi tích hợp", effort: "Nhiều phần việc bán hàng, nhập hàng và vận hành",
      fit: "Cơ sở có người vận hành, nguồn lực và đối tác nhập/giao hàng; cần kiểm tính khả thi trước.",
      description: "Sàn là một kênh bán. Việc mở tài khoản hoặc có trang sản phẩm không thay cho xử lý nhập khẩu, kho, giao hàng và đổi trả. Bản thử chưa kết nối hay đăng tự động.",
      advantages: ["Có thể chủ động nội dung giới thiệu sản phẩm", "Quan sát được hoạt động bán khi có tài khoản và dữ liệu hợp lệ", "Có thể thử một kênh sau khi đủ điều kiện"],
      requirements: ["Tài khoản, quyền và công cụ được nền tảng cho phép", "Kiểm nhập khẩu, phí kênh, giao hàng và hàng trả", "Người có quyền tự duyệt và thao tác ngoài ứng dụng trong bản thử"]
    }
  ];

  const sources = [
    {
      id: "fda-import", title: "Nhập khẩu thực phẩm vào Hoa Kỳ", organization: "Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)",
      url: "https://www.fda.gov/food/food-imports-exports/importing-food-products-united-states",
      checked: "17/10/2026 · nguồn tham chiếu; cần rà ca cụ thể",
      scope: "Thông tin nền về trách nhiệm nhập khẩu và thủ tục liên quan. Không xác nhận sản phẩm, nhãn hay lô hàng cụ thể được chấp thuận."
    },
    {
      id: "fsvp", title: "Chương trình xác minh nhà cung cấp nước ngoài (FSVP)", organization: "Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)",
      url: "https://www.fda.gov/food/food-safety-modernization-act-fsma/fsma-final-rule-foreign-supplier-verification-programs-fsvp-importers-food-humans-and-animals",
      checked: "17/10/2026 · cần chuyên gia xác định phạm vi áp dụng",
      scope: "Định nghĩa và trách nhiệm bên phụ trách xác minh nhà cung cấp nước ngoài (FSVP), các trường hợp miễn hoặc điều chỉnh. Không đồng nhất vai này với mọi bên nhận hàng."
    },
    {
      id: "fda-label", title: "Nguồn tra cứu nhãn và dinh dưỡng thực phẩm", organization: "Cục Quản lý Thực phẩm và Dược phẩm Hoa Kỳ (FDA)",
      url: "https://www.fda.gov/food/food-labeling-nutrition",
      checked: "Nguồn để chuyên gia kiểm lại trước ca thật",
      scope: "Điểm vào tài liệu về nhãn. F3-min do chuyên gia đối chiếu; bản mẫu không đọc ảnh hoặc kết luận nhãn đạt."
    },
    {
      id: "amazon-auth", title: "Người bán ủy quyền ứng dụng Selling Partner API", organization: "Amazon Selling Partner API",
      url: "https://developer-docs.amazon.com/sp-api/docs/authorizing-selling-partner-api-applications",
      checked: "Nguồn để kiểm lại khi có quyết định tích hợp",
      scope: "Tham khảo cơ chế cấp quyền ứng dụng. Chưa chứng minh DTT được cấp quyền; bản mẫu không giữ tài khoản seller hay gọi API sàn."
    },
    {
      id: "cbp-import", title: "Thông tin cho người mới nhập khẩu và xuất khẩu", organization: "Cơ quan Hải quan và Bảo vệ Biên giới Hoa Kỳ (CBP)",
      url: "https://www.cbp.gov/trade/basic-import-export/importer-exporter-tips",
      checked: "Cần mở lại cùng chuyên gia cho ca thật",
      scope: "Tra cứu trách nhiệm và thủ tục hải quan. Không phải biểu thuế, báo cước hay xác nhận thông quan cho sản phẩm mẫu."
    },
    {
      id: "vietrade", title: "Thông tin xúc tiến thương mại và đầu mối hỗ trợ", organization: "Cục Xúc tiến thương mại – Bộ Công Thương",
      url: "https://vietrade.gov.vn/",
      checked: "Cần kiểm điều kiện từng chương trình trước giới thiệu",
      scope: "Điểm vào thông tin chương trình và đầu mối. Chưa xác nhận doanh nghiệp đủ điều kiện nhận hỗ trợ hoặc đã có đối tác mua."
    }
  ];

  // The questionnaire is a transparent, deterministic orientation rule.
  // The published source called it 0–8, but its components sum to seven.
  function computeReadiness(answers) {
    const a = answers && answers.answers ? answers.answers : (answers || {});
    const papers = Array.isArray(a.q5) ? a.q5 : (a.q5 ? [a.q5] : []);
    const hasPaper = function (value) { return papers.indexOf(value) !== -1; };
    let score = 0;
    ["b", "c", "e"].forEach(function (value) { if (hasPaper(value)) score += 1; });
    if (["b", "c", "d"].indexOf(a.q2) !== -1) score += 1;
    if (a.q6 === "b") score += 0.5;
    if (a.q6 === "c") score += 1;
    if (a.q8 === "b") score += 0.5;
    if (a.q8 === "c") score += 1;
    if (a.q9 === "b") score += 1;

    let stage = 1;
    if (a.q3 === "d" || a.q3 === "c") stage = 4;
    else if (a.q4 === "a") stage = 0;
    else if ((a.q4 === "c" || a.q4 === "d") && score >= 3) stage = 2;

    const strengths = [];
    if (["b", "c", "d"].indexOf(a.q2) !== -1) strengths.push("Đã khai có sản phẩm OCOP; cần đối chiếu giấy chứng nhận.");
    if (hasPaper("b")) strengths.push("Đã khai có giấy tờ an toàn thực phẩm để chuyên gia rà.");
    if (hasPaper("c")) strengths.push("Đã khai có ISO 22000 hoặc HACCP; cần xem phạm vi và thời hạn.");
    if (hasPaper("e")) strengths.push("Đã khai có phiếu kiểm nghiệm sản phẩm.");
    if (a.q6 === "c") strengths.push("Có nội dung nhãn tiếng Anh để bắt đầu đối chiếu.");
    else if (a.q6 === "b") strengths.push("Đã có một phần nhãn tiếng Anh để tiếp tục hoàn thiện.");
    if (a.q9 === "b") strengths.push("Đã có kinh nghiệm bán online trong nước.");
    if (a.q8 === "b" || a.q8 === "c") strengths.push("Có đầu mối hỗ trợ email tiếng Anh.");
    if (a.q3 === "b") strengths.push("Đã có kinh nghiệm bán qua trung gian; cần làm rõ phần việc trước đây.");
    if (!strengths.length) strengths.push("Chưa đủ thông tin để ghi nhận điểm mạnh; có thể cùng chuyên gia bổ sung.");

    const gaps = [];
    if (a.q1 === "a" && !hasPaper("b")) gaps.push("Cùng chuyên gia rà giấy tờ an toàn thực phẩm áp dụng cho cơ sở.");
    if (!hasPaper("e")) gaps.push("Tìm lại hoặc làm rõ phiếu kiểm nghiệm gần nhất của sản phẩm.");
    if (a.q10 !== "a" && a.q8 !== "b" && a.q8 !== "c") gaps.push("Chọn người hỗ trợ trao đổi và đọc email tiếng Anh.");
    if (a.q10 !== "a" && a.q6 !== "c") gaps.push("Gom nhãn hiện tại để chuyên gia rà phần cần bổ sung cho hướng đã chọn.");
    if (a.q9 !== "b") gaps.push("Xác định cách giới thiệu sản phẩm và đầu mối tiếp nhận câu hỏi người mua.");
    if (!a.q10 || a.q10 === "d") gaps.push("Chọn một cách đi cùng chuyên gia trước khi chuẩn bị chi tiết.");
    if (gaps.length < 3) gaps.push("Làm rõ bên nhập khẩu và trách nhiệm vận chuyển; chưa mặc định đối tác đã có.");
    if (gaps.length < 3) gaps.push("Chuẩn bị thông tin lô dự kiến để xin báo giá thật; chưa dùng số cước ước đoán.");

    const nextByStage = {
      0: "Xem ba cách bắt đầu trong khoảng 5 phút và chọn điều anh/chị muốn hỏi thêm.",
      1: "Chọn một cách đi, hoặc tạo yêu cầu để chuyên gia cùng chọn với anh/chị.",
      2: "Gom nhãn hiện tại, thông tin một sản phẩm và giấy tờ đang có vào hồ sơ để chuyên gia rà.",
      4: "Ghi lại thị trường hoặc kênh muốn mở thêm và chuyển chuyên gia; đây là ca tham chiếu ngoài nhóm thử nghiệm chính."
    };
    return { stage: stage, score: score, max: 7, strengths: strengths.slice(0, 3), gaps: gaps.slice(0, 3), next: nextByStage[stage] };
  }

  const initialState = {
    version: "0.1", role: "business", caseStarted: "2026-10-17", caseDeadline: "2026-10-30",
    profile: {
      name: "HTX Miến dong Hương Việt", owner: "Nguyễn Minh Anh (nhân vật mẫu)",
      email: "huongviet@example.com", phone: "Chưa cung cấp trong bản mẫu",
      location: "Hoài Đức, Hà Nội (địa điểm minh họa)", product: "Miến dong khô 250 g",
      description: "DỮ LIỆU GIẢ LẬP để thử giao diện: cơ sở muốn tìm hiểu cách bán một sản phẩm thực phẩm khô cho nhà nhập khẩu tại Mỹ. Chưa có người mua, đơn hàng hay tuyến nhập được xác nhận.",
      ingredients: "Tinh bột dong riềng, nước (tự khai trong hồ sơ mẫu; cần DN xác nhận)",
      shelfLife: "12 tháng (giả lập; chưa kiểm bằng chứng)", packSize: "250 g/gói (mẫu)",
      capacity: "500 kg/tháng (giả lập; chưa xác minh)",
      certifications: "Đã khai có OCOP 3 sao, giấy ATTP và phiếu kiểm nghiệm; tất cả là dữ liệu mẫu, chưa xác minh."
    },
    consents: { service: true, expert: true, reminders: false, report: true },
    onboarding: {
      complete: true, step: 0,
      answers: { q1: "a", q2: "b", q3: "b", q4: "d", q5: ["a", "b", "e"], q6: "b", q7: "500 kg/tháng (dữ liệu giả lập)", q8: "b", q9: "b", q10: "b", q11: "a", q12: "a" }
    },
    activeRoute: "importer", market: "us",
    tasks: [
      { id: "T-HN001-01", title: "Xác nhận sản phẩm đầu tiên", detail: "Chốt một SKU, quy cách và thành phần. Nội dung mẫu phải được thay bằng dữ liệu DN thật khi thử thực tế.", owner: "Người phụ trách DN", due: "2026-10-18", status: "done", priority: "high", category: "Hồ sơ sản phẩm", evidence: ["Phiếu thông tin sản phẩm – DỮ LIỆU MẪU.pdf"] },
      { id: "T-HN001-02", title: "Gom giấy tờ đang có", detail: "Tập hợp nhãn, giấy ATTP và phiếu kiểm nghiệm để chuyên gia kiểm phạm vi, hạn và phần còn thiếu.", owner: "Người phụ trách DN", due: "2026-10-20", status: "doing", priority: "high", category: "Bằng chứng", evidence: [] },
      { id: "T-HN001-03", title: "Làm rõ nhóm người mua muốn tiếp cận", detail: "Cùng chuyên gia mô tả một nhóm người mua và cách kiểm nhu cầu. Chưa có dữ liệu để khẳng định có khách hoặc có đơn.", owner: "DN và chuyên gia xuất khẩu", due: "2026-10-22", status: "todo", priority: "medium", category: "Cách đi", evidence: [] },
      { id: "T-HN001-04", title: "Hoàn thiện phiếu thông tin xin báo cước", detail: "Bổ sung số lượng, khối lượng, kích thước kiện, điểm nhận và điểm giao; chuyên gia rà trước khi người được quyền gửi ngoài ứng dụng.", owner: "Điều phối và đầu mối vận chuyển", due: "2026-10-24", status: "todo", priority: "high", category: "Vận chuyển", evidence: [] },
      { id: "T-HN001-05", title: "Làm rõ vai nhập khẩu và an toàn thực phẩm", detail: "Hỏi chuyên gia ai sẽ là bên đứng tên nhập khẩu (IOR) và bên phụ trách xác minh nhà cung cấp nước ngoài (FSVP), nếu áp dụng. Không tự điền tên DTT hoặc sàn vào các vai này.", owner: "Chuyên gia xuất khẩu DTT", due: "2026-10-25", status: "todo", priority: "high", category: "Chuyên gia", evidence: [] },
      { id: "T-HN001-06", title: "Chuyên gia đối chiếu nhãn theo điều khoản", detail: "Đối chiếu tay theo kho đã duyệt; ghi mục cần sửa/chưa rõ. Chưa cho in khi thiếu người duyệt nghiệp vụ và chuyên gia ký đúng phiên bản.", owner: "Chuyên gia nhãn DTT", due: "2026-10-26", status: "todo", priority: "high", category: "Nhãn F3-min", evidence: [] },
      { id: "T-HN001-07", title: "Rà bộ quyết định một trang", detail: "DN xác nhận dữ kiện; chuyên gia rà nguồn, phần vận chuyển còn thiếu và ba việc tiếp. Bản nháp chưa phải kết luận đủ điều kiện xuất khẩu.", owner: "DN và chuyên gia xuất khẩu", due: "2026-10-28", status: "todo", priority: "medium", category: "Kết quả D14", evidence: [] },
      { id: "T-HN001-08", title: "Đối chiếu kết quả 14 ngày", detail: "Kiểm bộ quyết định đã được rà và ít nhất một việc hoàn thành có bằng chứng; ghi công hỗ trợ và ca đang chờ đúng thực tế.", owner: "Điều phối thí điểm", due: "2026-10-30", status: "todo", priority: "medium", category: "Kết quả D14", evidence: [] }
    ],
    checklist: [
      { id: "CL-01", title: "Một sản phẩm và quy cách được xác nhận", description: "Có tên SKU, thành phần, khối lượng gói và đầu mối cung cấp dữ liệu. Trạng thái trong bản trải nghiệm chỉ là minh họa.", status: "verified", critical: true, sourceId: "fda-import", naReason: "" },
      { id: "CL-02", title: "Giấy tờ cơ sở và kiểm nghiệm có bằng chứng", description: "Đã gom bản mẫu để chuyên gia xem; chưa xác nhận hiệu lực hoặc áp dụng cho thị trường Mỹ.", status: "evidence", critical: true, sourceId: "fda-import", naReason: "" },
      { id: "CL-03", title: "Nhãn được chuyên gia đối chiếu", description: "Rà tay theo điều khoản; lưu phiên bản và phần chưa kiểm được. Không có AI kết luận nhãn đạt.", status: "progress", critical: true, sourceId: "fda-label", naReason: "" },
      { id: "CL-04", title: "Bên chịu trách nhiệm nhập khẩu được làm rõ", description: "Ghi vai trò bên đứng tên nhập khẩu (IOR) và bên được ủy quyền theo ca cụ thể; chưa có tên hay thỏa thuận được xác nhận.", status: "missing", critical: true, sourceId: "cbp-import", naReason: "" },
      { id: "CL-05", title: "Phạm vi FSVP được chuyên gia xác định", description: "Xác định có áp dụng, có trường hợp miễn/điều chỉnh hay không và ai chịu vai trò xác minh nhà cung cấp nước ngoài (FSVP); không tự chọn không áp dụng.", status: "missing", critical: true, sourceId: "fsvp", naReason: "" },
      { id: "CL-06", title: "Thông tin lô và điểm giao đủ để xin báo giá", description: "Cần số lượng, trọng lượng tính cước, kích thước và điểm giao thống nhất; chưa có cước hay thuế thực tế trong bản mẫu.", status: "progress", critical: false, sourceId: "cbp-import", naReason: "" },
      { id: "CL-07", title: "Hạn dùng và điều kiện bảo quản được kiểm", description: "Chuyên gia xem thông tin và tài liệu của SKU, không lấy số tự khai làm bằng chứng hoàn tất.", status: "missing", critical: true, sourceId: "fda-label", naReason: "" },
      { id: "CL-08", title: "Kết luận ca và việc tiếp được ghi nhận", description: "Lưu phần đủ/chưa đủ cơ sở, nguồn và người duyệt. Không dùng mức tiến độ như chứng nhận xuất khẩu.", status: "missing", critical: false, sourceId: "fda-import", naReason: "" }
    ],
    documents: [
      { id: "DOC-HN001-01", name: "Phiếu thông tin sản phẩm – DỮ LIỆU MẪU.pdf", kind: "Hồ sơ sản phẩm", date: "2026-10-17", size: "124 KB · giả lập" },
      { id: "DOC-HN001-02", name: "Nhãn miến dong v1 – DỮ LIỆU MẪU.png", kind: "Ảnh nhãn", date: "2026-10-17", size: "850 KB · giả lập" },
      { id: "DOC-HN001-03", name: "Danh mục giấy tờ – DỮ LIỆU MẪU.pdf", kind: "Giấy tờ cần rà", date: "2026-10-17", size: "96 KB · giả lập" }
    ],
    handoffs: [
      { id: "CA-HN001-01", simulation: true, orgId: "HN-001", title: "Rà cách đi qua nhà nhập khẩu Mỹ", question: "Cần làm rõ vai nhập khẩu, dữ liệu sản phẩm và bước vận chuyển nào trước khi xin báo giá?", summary: "Ca giả lập HN-001: miến dong khô 250 g, đang chuẩn bị. DN tự khai có giấy tờ và nhãn một phần tiếng Anh. Chưa có người mua, nhà nhập khẩu, báo cước hoặc nhu cầu được xác nhận.", status: "accepted", expert: "Chuyên gia xuất khẩu DTT", created: "2026-10-17", note: "Ca mẫu đã được nhận để minh họa hàng đợi; chưa có kết luận nghiệp vụ thật.", consent: true },
      { id: "CA-HN001-02", simulation: true, orgId: "HN-001", title: "Đề nghị đối chiếu nhãn bằng chuyên gia", question: "Những mục nào cần bổ sung hoặc kiểm lại trước khi sửa nhãn cho ca Mỹ?", summary: "DN xem và đồng ý chia sẻ nhãn mẫu, thành phần tự khai và thông tin SKU với chuyên gia nhãn DTT trong ca này.", status: "draft", expert: "Chuyên gia nhãn DTT", created: "2026-10-17", note: "Bản nháp; chỉ chuyển trong phạm vi đã đồng ý. Chưa có AI đọc ảnh nhãn.", consent: true }
    ],
    brief: { id: "BR-HN001", version: 1, status: "draft", reviewer: "", updated: "17/10/2026" },
    logistics: {
      origin: "Hoài Đức, Hà Nội (minh họa)", destination: "Chưa thống nhất điểm giao tại Mỹ",
      quantity: "Chưa xác nhận số lượng lô thử", weight: "Chưa cân lô và kiện", dimensions: "Chưa có kích thước kiện",
      incoterm: "Chưa thỏa thuận", importer: "Chưa xác định bên chịu vai nhập khẩu",
      fsvp: "Cần chuyên gia xác định phạm vi và bên chịu trách nhiệm", quote: "Chưa có báo giá thực tế",
      currency: "USD (đơn vị dự kiến; chưa có báo giá)",
      notes: "DỮ LIỆU MẪU. Cần thống nhất lô, điểm giao và vai của các bên trước khi xin báo giá; không có số cước, thuế hay lợi nhuận được suy đoán."
    },
    messages: [
      { role: "assistant", text: "Chào anh/chị! Đây là hồ sơ GIẢ LẬP của HTX Miến dong Hương Việt để thử giao diện. Tôi đã có thông tin một sản phẩm và kế hoạch mẫu. Trong 14 ngày, mình cùng chuẩn bị bộ quyết định một trang và hoàn thành một việc có bằng chứng; chưa có đơn hàng hay báo cước thật. Bước tiếp: xem lại thông tin sản phẩm và sửa những chỗ chưa đúng.", sourceIds: [] },
      { role: "assistant", text: "Với hướng nhà nhập khẩu tại Mỹ, cần chuyên gia làm rõ trách nhiệm nhập khẩu và FSVP nếu áp dụng. Một tài khoản sàn hay nhãn tiếng Anh chưa thay cho việc kiểm điều kiện của ca cụ thể. Bước tiếp: mở phiếu chuyển ca để xem chính xác phần thông tin sẽ chia sẻ.", sourceIds: ["fda-import", "fsvp"] }
    ],
    audit: [
      { id: "EV-HN001-01", actor: "Điều phối mẫu", action: "Bắt đầu ca hỗ trợ", detail: "support_case_started · HN-001 · 17–30/10/2026 · dữ liệu giả lập; mốc không tự đặt lại khi mở app.", time: "2026-10-17T09:00:00+07:00" },
      { id: "EV-HN001-02", actor: "Người phụ trách DN (mẫu)", action: "Xác nhận phạm vi đồng ý", detail: "Tư vấn và chuyên gia nội bộ: đồng ý. Nhắc email: chưa đồng ý. Báo cáo dùng số liệu mẫu tổng hợp.", time: "2026-10-17T09:05:00+07:00" },
      { id: "EV-HN001-03", actor: "Hệ thống luật", action: "Hoàn thành tự kiểm mẫu", detail: "Luật L4; nấc ban đầu 2, điểm nền 5/7. Đây là định hướng từ tự khai, không là kết luận đủ điều kiện xuất khẩu.", time: "2026-10-17T09:10:00+07:00" },
      { id: "EV-HN001-04", actor: "Chuyên gia DTT (mẫu)", action: "Nhận ca tư vấn", detail: "CA-HN001-01 ở trạng thái accepted. Chưa có kết luận hoặc hành động gửi hồ sơ ra ngoài.", time: "2026-10-17T09:15:00+07:00" }
    ],
    cases: [
      { id: "HN-001", name: "HTX Miến dong Hương Việt", product: "Miến dong khô 250 g", owner: "Nguyễn Minh Anh (mẫu)", stage: 2, progress: 25, route: "importer", started: "2026-10-17", status: "Đang hỗ trợ", expert: "Chuyên gia xuất khẩu DTT" },
      { id: "HN-002", name: "HTX Mì gạo Hương Đồng (mẫu)", product: "Mì gạo khô 500 g", owner: "Lâm Thu Hà (mẫu)", stage: 1, progress: 10, route: "importer", started: "2026-10-17", status: "Chờ xác nhận hồ sơ", expert: "Chuyên gia xuất khẩu DTT" },
      { id: "HN-003", name: "HTX Bún khô Làng Việt (mẫu)", product: "Bún gạo khô 400 g", owner: "Nguyễn Quang Huy (mẫu)", stage: 2, progress: 38, route: "importer", started: "2026-10-17", status: "Đang rà giấy tờ", expert: "Chuyên gia xuất khẩu DTT" },
      { id: "HN-004", name: "Cơ sở Bánh đa Đông Hà (mẫu)", product: "Bánh đa khô 300 g", owner: "Trần Ngọc Mai (mẫu)", stage: 1, progress: 0, route: "importer", started: "2026-10-17", status: "Cần bổ sung dữ liệu", expert: "Chuyên gia xuất khẩu DTT" },
      { id: "HN-005", name: "HTX Miến sợi Sen Việt (mẫu)", product: "Miến khô 200 g", owner: "Phạm Minh Tâm (mẫu)", stage: 2, progress: 20, route: "importer", started: "2026-10-17", status: "Đang chuẩn bị", expert: "Chuyên gia xuất khẩu DTT" }
    ],
    contentQueue: [
      { id: "KB-01", title: "Ba cách bắt đầu và phần việc từng bên", sourceId: "vietrade", status: "approved", market: "all", updated: "2026-10-17" },
      { id: "KB-02", title: "Danh mục chuẩn bị nền cho ca thực phẩm khô tại Mỹ", sourceId: "fda-import", status: "approved", market: "us", updated: "2026-10-17" },
      { id: "KB-03", title: "Cần làm rõ bên phụ trách FSVP theo từng ca", sourceId: "fsvp", status: "pending", market: "us", updated: "2026-10-17" },
      { id: "KB-04", title: "Mục nhãn cần chuyên gia đối chiếu thủ công", sourceId: "fda-label", status: "pending", market: "us", updated: "2026-10-17" },
      { id: "KB-05", title: "Quyền ứng dụng khi khảo sát kênh sàn", sourceId: "amazon-auth", status: "pending", market: "us", updated: "2026-10-17" }
    ],
    labels: [
      { id: "NH-HN001-01", orgId: "HN-001", product: "Miến dong khô 250 g – NHÃN MẪU", version: 1, status: "pending", clauses: [
        { title: "Tên hàng và khối lượng: cần đối chiếu điều khoản áp dụng", status: "progress" },
        { title: "Thành phần và dị ứng: cần dữ liệu DN xác nhận", status: "missing" },
        { title: "Thông tin dinh dưỡng: chưa có căn cứ để tự điền", status: "missing" },
        { title: "Bên chịu trách nhiệm trên nhãn: cần chuyên gia làm rõ", status: "missing" }
      ], reviewerSigned: false, expertSigned: false },
      { id: "NH-HN003-01", orgId: "HN-003", product: "Bún gạo khô 400 g – NHÃN MẪU", version: 1, status: "reviewed", clauses: [
        { title: "Bản thông tin SKU đã được đối chiếu trong ca giả lập", status: "verified" },
        { title: "Thành phần: còn yêu cầu bổ sung dữ liệu", status: "progress" },
        { title: "Thông tin bên chịu trách nhiệm: chưa rõ", status: "missing" }
      ], reviewerSigned: false, expertSigned: false }
    ]
  };

  function seed() {
    return JSON.parse(JSON.stringify(initialState));
  }

  window.NMateData = {
    seed: seed,
    questions: questions,
    routes: routes,
    sources: sources,
    stageNames: stageNames,
    computeReadiness: computeReadiness
  };
})();
