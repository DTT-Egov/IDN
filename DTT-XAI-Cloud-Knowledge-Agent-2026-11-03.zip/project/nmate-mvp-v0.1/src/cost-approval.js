/* Account-scoped public-corpus control. No SDK, paid call or grant issuance. */
(function(){
  'use strict';
  let owner=null,view=null,preview=null,pending=null,busy=false,epoch=0,loaded=false,error='',consent=false,detailsOpen=false,announcement='';
  const el=()=>document.getElementById('policy-cost-approval');
  const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const scopeOf=o=>JSON.stringify([o?.account_id||'',o?.enterprise_id||'']);
  const money=micro=>(Number(micro||0)/1e6).toLocaleString('vi-VN',{maximumFractionDigits:6})+' USD';
  const memoryKey=()=> 'nmate.policy-cost.'+scopeOf(owner);
  function remember(){try{pending?sessionStorage.setItem(memoryKey(),JSON.stringify(pending)):sessionStorage.removeItem(memoryKey());}catch{/* SQL receipt remains authoritative. */}}
  function reset(){epoch++;view=null;preview=null;pending=null;busy=false;loaded=false;error='';consent=false;detailsOpen=false;announcement='';el()?.replaceChildren();}
  function announce(message){announcement=message;const live=el()?.querySelector('[data-cost-live]');if(live&&live.textContent!==message)live.textContent=message;}
  async function request(path,body){
    const identity=scopeOf(owner),generation=epoch;
    const response=await fetch('/api/main/policy-cost/'+path,{method:body?'POST':'GET',credentials:'same-origin',cache:'no-store',headers:body?{'Content-Type':'application/json','X-CSRF-Token':owner.csrf||''}:{},...(body?{body:JSON.stringify(body)}:{})});
    if(generation!==epoch||identity!==scopeOf(owner))throw Error('Phiên làm việc đã đổi.');
    if(response.status===404&&path==='status')return {enabled:false};
    const payload=await response.json();
    if(generation!==epoch||identity!==scopeOf(owner))throw Error('Phản hồi thuộc phiên trước; giữ nguyên màn hiện tại.');
    if(!response.ok||!payload.ok){if(response.status===401||response.status===403){view=null;preview=null;consent=false;}throw Error(payload.error?.message||'Chưa đối chiếu được quyết định; không gửi AI.');}
    if(payload._scope_actor_id!==owner.account_id){reset();throw Error('Phản hồi không khớp tài khoản hiện tại.');}
    return payload.data;
  }
  function render(){
    const host=el();if(!host||!owner?.authenticated||owner.view!=='chat')return;
    if(!view?.enabled&&!error){host.replaceChildren();return;}
    const previous=host.querySelector('.policy-cost-card'),disclosure=previous?.querySelector('details');
    if(disclosure)detailsOpen=disclosure.open;
    let live=host.querySelector('[data-cost-live]');
    if(!live){live=document.createElement('p');live.id='policy-cost-status';live.className='small';live.setAttribute('data-cost-live','');live.setAttribute('role','status');live.setAttribute('aria-live','polite');live.setAttribute('aria-atomic','true');host.append(live);}
    const card=document.createElement('section');card.className='card policy-cost-card';card.setAttribute('aria-label','Quyết định ngân sách kho chính sách');
    const expired=view?.expires_at&&Date.parse(view.expires_at)<=Date.now();
    const recorded=view?.continuation_recorded;
    const heading=recorded?'Đã ghi quyết định tiếp tục riêng O2':expired?'Hạn mức xây kho đã hết hiệu lực':'Kho chính sách: một nhánh cần quyết định';
    card.innerHTML=`<h3>${escape(heading)}</h3><p class="small">Chỉ tài khoản được giao duyệt chi phí · ${escape(view?.username||owner.account_id)}</p>${view?`<p>O1 giữ nguyên lỗi và chi phí. O2 rà bản wiki/FAQ và checklist từ hai bản nháp S3/S4, không chạy lại O1.</p><details ${detailsOpen?'open':''}><summary>Phạm vi và chi phí</summary><p>Opus 5.5 · tối đa ${escape(money(view.cap_microusd))} cho O2.</p><p>Đã dùng trong ngân sách xây kho: ${escape(money(view.known_estimated_microusd))} (ước tính theo token, chưa phải hóa đơn).</p><p>Hiệu lực đến ${escape(new Date(view.expires_at).toLocaleString('vi-VN'))}.</p></details>`:''}${error?`<p class="warning" role="alert">${escape(error)}</p>`:''}${recorded?'<p>Quyết định đã lưu. Chưa gọi Claude từ thao tác này; lượt nghiên cứu vẫn cần được chạy riêng theo hạn mức.</p>':expired?'<p>Cần phê duyệt hạn mức mới trước khi tiếp tục. Không tự gia hạn hoặc gọi lại AI.</p>':''}${preview?`<p>Đã đối chiếu đúng hai bản nháp S3/S4 và phiên bản nguồn.</p><label class="policy-cost-consent"><input type="checkbox" data-cost="consent" aria-describedby="policy-cost-status" ${consent?'checked':''} ${busy?'disabled':''}><span>Tôi xác nhận chỉ cho phép tiếp tục riêng O2 trong hạn mức hiện có. Việc này chỉ ghi quyết định, chưa gọi Claude.</span></label>`:''}<div class="row">${view?.can_approve&&!preview?'<button type="button" class="button subtle" data-cost="preview">Xem quyết định O2 · miễn phí</button>':''}${preview?`<button type="button" class="button primary" data-cost="approve" aria-describedby="policy-cost-status" ${busy||!consent?'disabled':''}>Cho phép tiếp tục riêng O2</button>`:''}${pending?`<button type="button" class="button subtle" data-cost="receipt" ${busy?'disabled':''}>Đối chiếu quyết định trước · không gọi AI</button>`:''}<button type="button" class="button subtle" data-cost="refresh" ${busy?'disabled':''}>Đọc lại trạng thái</button></div><p class="small">Ngân sách xây kho chính sách riêng; thao tác này không cấp thêm tiền, không phát hành chính sách và không ghi hồ sơ doanh nghiệp.</p>`;
    card.querySelectorAll('button').forEach(button=>{button.style.minHeight='44px';button.disabled=button.disabled||busy;});
    if(previous)previous.replaceWith(card);else host.append(card);
    const details=card.querySelector('details');details?.addEventListener('toggle',()=>{if(details.isConnected)detailsOpen=details.open;});
    announce(announcement);
    card.querySelector('[data-cost="consent"]')?.addEventListener('change',event=>{
      if(busy)return;consent=event.target.checked===true;
      const button=card.querySelector('[data-cost="approve"]');if(button)button.disabled=!consent;
      announce(consent?'Đã đồng ý. Nút cho phép tiếp tục riêng O2 đã mở. Chưa ghi quyết định hoặc gọi Claude.':'Đã bỏ đồng ý. Nút cho phép tiếp tục riêng O2 đã khóa. Chưa ghi quyết định hoặc gọi Claude.');
    });
    card.addEventListener('click',event=>{const button=event.target.closest('button[data-cost]');if(button&&!button.disabled)void action(button.dataset.cost);});
  }
  async function load(){view=await request('status');if(view.enabled&&view.account_id!==owner.account_id)throw Error('Sai tài khoản duyệt chi phí.');loaded=true;announce(view.continuation_recorded?'Đã đọc quyết định đã lưu. Đọc lại không gọi Claude.':view.enabled?'Đã đọc trạng thái kho chính sách. Chưa ghi quyết định tiếp tục; không gọi Claude.':'');}
  async function action(kind){
    if(busy)return;const generation=epoch;busy=true;error='';announce(kind==='preview'?'Đang đối chiếu quyết định O2, không gọi AI.':kind==='refresh'?'Đang đọc lại trạng thái, không gọi AI.':'Đang đối chiếu biên nhận quyết định, không gọi AI.');render();
    try{
      if(kind==='refresh'){preview=null;consent=false;await load();}
      if(kind==='preview'){
        const command_id=pending?.decision?.decision_id||'cost-'+crypto.randomUUID();
        preview=await request('preview',{command_id});consent=false;announce('Đã xem trước quyết định O2. Chưa đồng ý; nút cho phép tiếp tục riêng O2 đang khóa. Không gọi Claude.');
      }
      if(kind==='approve'||kind==='receipt'){
        if(kind==='approve'&&(!preview||!consent))throw Error('Xem đúng quyết định và xác nhận trước khi ghi.');
        const decision=kind==='receipt'?pending?.decision:preview;
        if(!decision)throw Error('Chưa có quyết định cần đối chiếu.');
        pending={account_id:owner.account_id,enterprise_id:owner.enterprise_id,decision};remember();
        const receipt=await request('approve',{decision});
        if(receipt.decision.decision_id!==decision.decision_id)throw Error('Biên nhận chưa khớp quyết định.');
        pending=null;remember();preview=null;consent=false;await load();
      }
    }catch(e){if(generation===epoch){error=e.message;announce('');}}
    finally{if(generation===epoch){busy=false;render();if(kind==='preview'&&preview)el()?.querySelector('[data-cost="consent"]')?.focus({preventScroll:true});}}
  }
  window.addEventListener('nmate:render',event=>{
    const next=event.detail||{};
    if(!next.authenticated){reset();owner=next;return;}
    if(scopeOf(owner)!==scopeOf(next)){
      reset();owner=next;
      try{const record=JSON.parse(sessionStorage.getItem(memoryKey())||'null');if(record?.account_id===next.account_id&&record?.enterprise_id===next.enterprise_id&&record?.decision?.schema_version==='knowledge-independent-continuation/2')pending=record;}catch{/* No mutation on recovery. */}
    }else owner=next;
    render();
    if(!loaded&&!busy){const generation=epoch;busy=true;load().catch(e=>{if(generation===epoch)error=e.message;}).finally(()=>{if(generation===epoch){busy=false;render();}});}
  });
})();
