# Historical/local references not bundled

This index replaces unavailable local links in exported documents. It does not replace their evidence or imply access. No linked database, credential or production receipt was copied. Reference source text is retained as historical context; these items are not required to inspect the included implementation.

## ref-0001

- Exported document: `project/nmate-backend-v0.2/src/nmate/policy_v1/README.md`
- Label: walkthrough app chính
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/MVP/real-claude-main-2026-10-19/Walkthrough_Tra_Sen_Claude_app_chinh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0002

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/02_Du_lieu_pipeline_va_truy_xuat.md`
- Label: schema V17 đóng gói
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/core_v1/data/runtime_schema_20261026_v17.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0003

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/02_Du_lieu_pipeline_va_truy_xuat.md`
- Label: catalog Hà Nội
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0004

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/02_Du_lieu_pipeline_va_truy_xuat.md`
- Label: scheduler hiện có
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/refresh_jobs.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0005

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/02_Du_lieu_pipeline_va_truy_xuat.md`
- Label: catalog xuất khẩu
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/v03/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0006

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/03_Quan_tri_API_trai_nghiem_va_nghiem_thu.md`
- Label: Hồ sơ Phụ lục 03, mục Quyền
- Original reference: `MVP/real-claude-main-2026-10-19/Chinh_sach_Ha_Noi_03_Ho_so_cho_duyet.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0007

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/04_Review_doc_lap.md`
- Label: snapshot baseline
- Original reference: `output/policy-knowledge-design-2026-10-26/baseline-before-P06-approval/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0008

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md`
- Label: baseline-before-P06-approval/manifest.json
- Original reference: `output/policy-knowledge-design-2026-10-26/baseline-before-P06-approval/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0009

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/06_Quyet_dinh_P06_va_cap_nhat_thiet_ke.md`
- Label: Biên bản kiểm tĩnh lúc chốt bản 1.1/P06
- Original reference: `output/policy-knowledge-design-2026-10-26/P06-approved-document-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0010

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/07_Ke_hoach_trien_khai_va_moc_kiem_tra.md`
- Label: Baseline trước kế hoạch
- Original reference: `output/policy-knowledge-design-2026-10-26/baseline-before-milestone-plan/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0011

- Exported document: `project/MVP/policy-knowledge-design-2026-10-26/07_Ke_hoach_trien_khai_va_moc_kiem_tra.md`
- Label: kiểm tĩnh kế hoạch
- Original reference: `output/policy-knowledge-design-2026-10-26/milestone-plan-document-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0012

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: bản triển khai
- Original reference: `MVP/core-policy-implementation-2026-10-19/01_Ban_trien_khai_va_gioi_han.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0013

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: walkthrough
- Original reference: `MVP/core-policy-implementation-2026-10-19/Walkthrough_Tra_Sen_core_policy.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0014

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: hiện trạng 0.4
- Original reference: `MVP/system-architecture-2026-10-19/Kien_truc_tong_the_nMate_0_4.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0015

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: kế hoạch đã chốt phạm vi
- Original reference: `MVP/system-architecture-2026-10-19/Ke_hoach_hoan_thien_thiet_ke_loi_va_chinh_sach_Ha_Noi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0016

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: review/walkthrough mới nhất
- Original reference: `MVP/v0.4-reviewfix-2026-10-19/Review_doc_lap_sau_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0017

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/00_Tong_quan_thiet_ke_chi_tiet.md`
- Label: kết quả kiểm cấu trúc tài liệu
- Original reference: `MVP/core-policy-detailed-design-2026-10-19/Kiem_tra_thiet_ke.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0018

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/01_Hop_dong_loi_va_dieu_phoi.md`
- Label: kiến trúc 0.4
- Original reference: `MVP/system-architecture-2026-10-19/Kien_truc_tong_the_nMate_0_4.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0019

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/02_SSOT_va_SQL_Knowledge_Graph.md`
- Label: hiện trạng 0.4
- Original reference: `MVP/system-architecture-2026-10-19/Kien_truc_tong_the_nMate_0_4.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0020

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/02_SSOT_va_SQL_Knowledge_Graph.md`
- Label: kế hoạch T03/T05/T11
- Original reference: `MVP/system-architecture-2026-10-19/Ke_hoach_hoan_thien_thiet_ke_loi_va_chinh_sach_Ha_Noi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0021

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: config.py
- Original reference: `nmate-backend-v0.2/src/nmate/config.py:16`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0022

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: main/local.py
- Original reference: `nmate-backend-v0.2/src/nmate/main/local.py:73`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0023

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: main/provider.py
- Original reference: `nmate-backend-v0.2/src/nmate/main/provider.py:14`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0024

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: v03/live_provider.py
- Original reference: `nmate-backend-v0.2/src/nmate/v03/live_provider.py:14`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0025

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: v04/live_review.py
- Original reference: `nmate-backend-v0.2/src/nmate/v04/live_review.py:175`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0026

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: main/conversations.py
- Original reference: `nmate-backend-v0.2/src/nmate/main/conversations.py:202`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0027

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/04_Model_Gateway_va_van_hanh.md`
- Label: runtime_lock.py
- Original reference: `nmate-backend-v0.2/src/nmate/main/runtime_lock.py:17`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0028

- Exported document: `project/MVP/core-policy-detailed-design-2026-10-19/08_Quyet_dinh_can_chot.md`
- Label: Phạm vi, phê duyệt và đối soát
- Original reference: `MVP/core-policy-implementation-2026-10-19/D06_De_nghi_vong_thu_Claude.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0029

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: bằng chứng tổng hợp nguồn công khai
- Original reference: `output/source-pipeline-audit-2026-10-26/public-domain-state.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0030

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: schema kho nguồn
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0031

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: HTTP refresh và giới hạn PDF
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0032

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: snapshot/hash/index
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0033

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: retrieval local
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0034

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: gate pháp lý
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0035

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: lịch refresh bền vững
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/refresh_jobs.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0036

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: worker
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/core_v1/integration.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0037

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: phân tích Claude có giới hạn
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/service.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0038

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: đọc lại và cảnh báo
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/policy_v1/service.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0039

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: gói nguồn và lookup local
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/v03/catalog.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0040

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: refresh ở chat chính
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/main/conversations.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0041

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: prepare trực tiếp
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/v03/live_review.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0042

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/01_Hien_trang_va_huong_hoan_thien.md`
- Label: kiểm exact excerpts và lưu observation riêng
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/release-final-v2/backend-src/nmate/v03/source_refresh.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0043

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/02_Kiem_thu_Claude_that_va_han_muc.md`
- Label: Approval
- Original reference: `nmate-backend-v0.2/output/d06-local-testers-20usd-2026-10-26/approval.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0044

- Exported document: `project/MVP/source-pipeline-audit-2026-10-26/02_Kiem_thu_Claude_that_va_han_muc.md`
- Label: Biên nhận và đối soát
- Original reference: `nmate-backend-v0.2/output/d06-local-testers-20usd-2026-10-26/grant-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0045

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/01_Ban_giao_M1.md`
- Label: Frozen candidate3/manifest
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/frozen-candidate-3/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0046

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/01_Ban_giao_M1.md`
- Label: Author cuối44/44
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/candidate3-head-final-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0047

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/01_Ban_giao_M1.md`
- Label: Review độc lập47/47
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M1/01_REVIEW_M1.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0048

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/01_Ban_giao_M1.md`
- Label: signoff
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M1/M1-independent-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0049

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/01_Ban_giao_M1.md`
- Label: Rehearsal
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/rehearsal-candidate3/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0050

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/03_Walkthrough_M2.md`
- Label: Manifest149files
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/frozen-candidate-2/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0051

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/03_Walkthrough_M2.md`
- Label: Bằng chứng toàn flow
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/rehearsal-candidate2/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0052

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/03_Walkthrough_M2.md`
- Label: Verification
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/rehearsal-candidate2/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0053

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/03_Walkthrough_M2.md`
- Label: Operator receipt
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/rehearsal-candidate2/operator-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0054

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md`
- Label: Hồi quy author trên M2 frozen2
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/author-candidate2-broad.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0055

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md`
- Label: Review M2 độc lập
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/01_REVIEW_M2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0056

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md`
- Label: Signoff M2
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/M2-independent-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0057

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md`
- Label: Rehearsal cuối
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/rehearsal-candidate2/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0058

- Exported document: `project/MVP/policy-knowledge-M1-M2-2026-10-26/04_Ban_giao_M1_M2.md`
- Label: Kiểm artifact
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/handoff-artifact-check.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0059

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/00_Pham_vi_M3_va_AI_xay_kho.md`
- Label: D06 batch cụ thể
- Original reference: `MVP/policy-knowledge-M3-2026-10-27/D06_De_nghi_AI_xay_kho.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0060

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/01_Thiet_ke_implementation_M3.md`
- Label: review candidate1
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/02_Review_candidate1.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0061

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/01_Thiet_ke_implementation_M3.md`
- Label: D06
- Original reference: `MVP/policy-knowledge-M3-2026-10-27/D06_De_nghi_AI_xay_kho.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0062

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/01_Thiet_ke_implementation_M3.md`
- Label: Review
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/04_Review_candidate3_SIGNOFF.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0063

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Editor mobile320px — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/01-editor-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0064

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Nháp trở lại sau tải lại — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/02-buffer-after-reload-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0065

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Đã duyệt nhưng chưa phát hành — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/03-approved-not-published-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0066

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Phát hành riêng — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/04-published-synthetic-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0067

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Ngừng phát hành sau tải lại — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/05-withdrawn-synthetic-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0068

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Lỗi xác nhận — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/10-validation-error-live-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0069

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Báo cáo mobile
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/05_Independent_mobile_320.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0070

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: biên nhận phục hồi
- Original reference: `output/policy-knowledge-M3-2026-10-27/public-batch-final3/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0071

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Cảnh báo diễn giải trên frozen5,320px — dữ liệu thử
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/output/playwright/12-admission-warnings-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0072

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/02_Walkthrough_M3.md`
- Label: Đối soát S1 sau phục hồi độc lập
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/S1-post-recovery-independent-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0073

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: frozen5
- Original reference: `output/policy-knowledge-M3-2026-10-27/candidate5/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0074

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: review candidate3
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/04_Review_candidate3_SIGNOFF.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0075

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: review mobile
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/05_Independent_mobile_320.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0076

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: RCA S1
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/06_S1_saved_output_RCA_va_admission_v2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0077

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: Log hồi quy cuối
- Original reference: `output/policy-knowledge-M3-2026-10-27/candidate5-author.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0078

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: biên nhận đúng build/testlist
- Original reference: `output/policy-knowledge-M3-2026-10-27/candidate5-author-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0079

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: Báo cáo cuối frozen5
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/07_Review_candidate5_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0080

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: signoff
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/M3-independent-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0081

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: Stop receipt
- Original reference: `output/policy-knowledge-M3-2026-10-27/public-batch-final3/stop-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0082

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: Biên nhận
- Original reference: `output/policy-knowledge-M3-2026-10-27/public-batch-final3/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0083

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/03_Ban_giao_M3.md`
- Label: Reviewer đối soát sau phục hồi bằng kết nối chỉ đọc
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/S1-post-recovery-independent-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0084

- Exported document: `project/MVP/policy-knowledge-M3-2026-10-27/04_Nhap_AI_S1_cho_chuyen_gia.md`
- Label: Biên nhận phục hồi
- Original reference: `output/policy-knowledge-M3-2026-10-27/public-batch-final3/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0085

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/00_Pham_vi_va_gate.md`
- Label: Tái gate M3
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/08_Re_gate_M3_va_dieu_kien_M4_M6.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0086

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: RED
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-upstream-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0087

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: RED request constraints
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-request-constraints-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0088

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: Review độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/01_Review_M4_candidate1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0089

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: RED2
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-private-DOM-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0090

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: GREEN4gồmfocusepoch
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-private-DOM-focus-epoch-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0091

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: receiptđínhchính
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate1-identity-correction.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0092

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: F03 của reviewer
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/02_Review_M4_candidate2_F03_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0093

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/01_RCA_va_hop_dong_M4.md`
- Label: 7ca mới đạt
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-causal-source-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0094

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: review cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/03_Review_M4_candidate4_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0095

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: Candidate2 review
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/02_Review_M4_candidate2_F03_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0096

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: candidate3
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate3/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0097

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: review candidate1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/01_Review_M4_candidate1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0098

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: candidate2
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate2/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0099

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: manifest
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate1/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0100

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: Chat hai nhu cầu ở320px
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-mobile-320-two-needs.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0101

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: Tải lại vẫn giữ câu hỏi và hai nhu cầu
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-mobile-320-reload.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0102

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/02_Walkthrough_M4.md`
- Label: log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate1-backend-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0103

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/03_Ban_giao_M4.md`
- Label: Reviewer độc lập xác nhận SCOPED PASS
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/03_Review_M4_candidate4_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0104

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/03_Ban_giao_M4.md`
- Label: 76/76
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate4-affected-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0105

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/03_Ban_giao_M4.md`
- Label: 1/1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-candidate4-runtime-contract.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0106

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/04_M5_Ke_hoach_trien_khai.md`
- Label: Diễn tập2
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-rehearsal2/rehearsal.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0107

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md`
- Label: Identity operator
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-operator-manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0108

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md`
- Label: Review M5a
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M5/01_Review_M5a_PRE_CUTOVER.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0109

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md`
- Label: Cutover thật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-live-20261027-104316/cutover.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0110

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md`
- Label: HTTP/schema audit
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-live-20261027-104316/http-readonly-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0111

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/07_Ban_giao_M5.md`
- Label: Review M5b cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M5/02_Review_M5b_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0112

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/08_M6_Thiet_ke_worker_va_danh_gia.md`
- Label: C1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/01_Review_M6_candidate1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0113

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/08_M6_Thiet_ke_worker_va_danh_gia.md`
- Label: đồng ý tiếp tục năm slot
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_batch_da_duyet.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0114

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/08_M6_Thiet_ke_worker_va_danh_gia.md`
- Label: quyết định tiếp tục bốn slot
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_4_slot_sau_phuc_hoi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0115

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Diễn tập nâng cấp và phục hồi lần4
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-schema-rehearsal4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0116

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Đã áp dụng vào kho thật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-live-schema-c4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0117

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: review độc lập cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/05_Review_M6_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0118

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Diagnostic C4
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-diagnostic4/retrieval-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0119

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Kiểm HTTP app chính
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-main-http-readonly-check.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0120

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Audit chỉ đọc
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-original-batch-status.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0121

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Đề nghị tiếp tục5slot
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_batch_da_duyet.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0122

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: Câu hỏi đóng băng
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-candidate1/tests/data/knowledge_m6_questions.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0123

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/09_Walkthrough_M6.md`
- Label: số liệu kỹ thuật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-diagnostic1/retrieval-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0124

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Review cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/05_Review_M6_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0125

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Review C1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/01_Review_M6_candidate1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0126

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Review C3
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/03_Review_M6_candidate3_TERMINAL_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0127

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Diễn tập4
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-schema-rehearsal4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0128

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: migration-plan
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-schema-rehearsal4/migration-plan.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0129

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: preoperator pass
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/04_Review_M6_candidate4_PRE_OPERATOR.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0130

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Kết quả thật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-live-schema-c4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0131

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: Audit
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/M6b-independent-postoperator-readonly.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0132

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/10_M6_Sua_thiet_ke_va_gate_operator.md`
- Label: D06
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_batch_da_duyet.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0133

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Review cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/05_Review_M6_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0134

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: biên bản
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/M6-independent-final-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0135

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Kiểm HTTP
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-main-http-readonly-check.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0136

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Review trước operator
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/04_Review_M6_candidate4_PRE_OPERATOR.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0137

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: biên bản
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/M6a-independent-preoperator-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0138

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Diễn tập nâng và phục hồi
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-schema-rehearsal4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0139

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Operator trên kho thật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-live-schema-c4/operator-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0140

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: biên nhận
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-live-schema-c4/migration-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0141

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Đối soát độc lập sau operator
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/M6b-independent-postoperator-readonly.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0142

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Đề nghị năm slot
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_batch_da_duyet.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0143

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: đề nghị bốn slot
- Original reference: `MVP/policy-knowledge-M4-M6-2026-10-27/D06_M6_Tiep_tuc_4_slot_sau_phuc_hoi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0144

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/11_Ban_giao_M6.md`
- Label: Diagnostic
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-diagnostic4/retrieval-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0145

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: quyết định người dùng
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/human-approval-record.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0146

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: biên nhận tiếp tục
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/resume-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0147

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Review độc lập đợt thật
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/06_Review_Claude_that_S2_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0148

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Audit dữ liệu đã lưu
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/saved-evidence-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0149

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Ca RED đầu tiên
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-DF060-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0150

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Gate trước phục hồi
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/08_Review_C6_PRE_FREE_RECOVERY.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0151

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Biên nhận phục hồi miễn phí
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0152

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Đối soát độc lập sau phục hồi
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate6-post-free-recovery-readonly.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0153

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/12_M6_Claude_that_va_sua_trich_dan.md`
- Label: Review cuối C6
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/09_Review_C6_FREE_RECOVERY_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0154

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: Phê duyệt
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/human-approval-record.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0155

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: receipt tiếp tục
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/resume-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0156

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: Chẩn đoán chỉ đọc
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/O1-output-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0157

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: Tổng hợp chỉ đọc
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/run-summary.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0158

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: Review độc lập cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/10_Review_M6_O1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0159

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/13_M6_Ket_qua_4_slot_Claude.md`
- Label: Audit
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/M6-last4-saved-independent-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0160

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: Status read-only
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-next-original-status-readonly.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0161

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: RED trước triển khai
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-next-contracts-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0162

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: ma trận review độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/01_Preimplementation_review_matrix.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0163

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: audit UI sandbox
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/mobile-sandbox-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0164

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: Log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-next-frozen-author.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0165

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: Log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-next-c2-affected.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0166

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: Log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-next-complex-integration.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0167

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/16_Trien_khai_va_ban_giao_review_mo_phong.md`
- Label: receipt
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/C2-independent-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0168

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: tệp riêng trên máy
- Original reference: `outside-workspace local/private reference`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0169

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-approval-composition.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0170

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Review
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-cost-approval/02_Working_tree_independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0171

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Biên bản
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-rehearsal2/rehearsal.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0172

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Biên bản
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-assignment-predeploy-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0173

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Hồi quy app chính
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-main-regression.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0174

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Biên nhận chuyển bản
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-live-20261027-230125/cutover.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0175

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: xác minh sau khởi động
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-live-20261027-230125/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0176

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/17_Phan_quyen_duyet_chi_phi_trung.md`
- Label: Đối soát thật sau triển khai
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/cost-assignment-postdeploy-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0177

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/19_Doi_soat_dang_nhap_trung_2026-10-28.md`
- Label: Log đã làm sạch
- Original reference: `output/login-investigation-2026-10-28/actual-login-probe.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0178

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/19_Doi_soat_dang_nhap_trung_2026-10-28.md`
- Label: Phép kiểm một lượt
- Original reference: `output/login-investigation-2026-10-28/probe_actual_login.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0179

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: RED trên DOM thật
- Original reference: `output/cost-card-fix-2026-10-28/red-dom.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0180

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: So sánh C1→C2
- Original reference: `output/cost-card-fix-2026-10-28/candidate-diff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0181

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: Log
- Original reference: `output/cost-card-fix-2026-10-28/green-dom-working.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0182

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: Log
- Original reference: `output/cost-card-fix-2026-10-28/frontend-frozen-c2.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0183

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: Biên bản
- Original reference: `output/cost-card-fix-2026-10-28/predeploy-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0184

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: receipt
- Original reference: `output/cost-card-fix-2026-10-28/review/C2-independent-signoff.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0185

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: Cutover
- Original reference: `output/cost-card-fix-2026-10-28/cost-live-20261028-142641/cutover.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0186

- Exported document: `project/MVP/policy-knowledge-M4-M6-2026-10-27/20_Sua_the_duyet_O2_mobile_va_thong_bao_2026-10-28.md`
- Label: xác minh sau khởi động
- Original reference: `output/cost-card-fix-2026-10-28/cost-live-20261028-142641/verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0187

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: historical red
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-historical-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0188

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: PDF red
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/pdf-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0189

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: service green
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-final-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0190

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: HTTP/PDF green
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/http-pdf-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0191

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: QA05-02 trước tải lại
- Original reference: `output/mvp-0.5-independent-2026-10-24/11-stale-after-profile-save-before-refresh-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0192

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: sau tải lại
- Original reference: `output/mvp-0.5-independent-2026-10-24/12-stale-after-reload-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0193

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: cảnh báo xuất hiện ngay
- Original reference: `output/mvp-0.5-independent-2026-10-24/16-stale-immediate-fixed-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0194

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: editor chưa lưu còn nguyên
- Original reference: `output/mvp-0.5-independent-2026-10-24/17-stale-editor-preserved-320.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0195

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: ID/version/hash không đổi
- Original reference: `output/mvp-0.5-independent-2026-10-24/hash-projection-proof.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0196

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED đúng harness trên v2
- Original reference: `nmate-mvp-v0.1/output/mvp-0.5-2026-10-24/qa05-02-corrected-v2-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0197

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 638 UI cuối
- Original reference: `nmate-mvp-v0.1/output/mvp-0.5-2026-10-24/frontend-full-suite-final.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0198

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: bốn câu baseline
- Original reference: `output/mvp-0.5-independent-2026-10-24/baseline-intent-evidence.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0199

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: TDD red
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/root-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0200

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: PDF TDD red
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/pdf-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0201

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: structured red
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-structured-document-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0202

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Structured green
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-structured-document-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0203

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: PDF order red
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/pdf-order-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0204

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: green
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/pdf-order-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0205

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: test độc lập
- Original reference: `output/mvp-0.5-independent-2026-10-24/test_workbench_independent.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0206

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: thống kê nguồn công khai
- Original reference: `output/source-pipeline-audit-2026-10-26/public-domain-state.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0207

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Binding red đã sửa fixture
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-binding-red-corrected-fixture.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0208

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: binding green
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-binding-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0209

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: identity wording red/green
- Original reference: `output/mvp-0.5-2026-10-24/policy-workbench-identity-wording-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0210

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Trước
- Original reference: `output/mvp-0.5-independent-2026-10-24/05-approval-before-390.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0211

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: sau
- Original reference: `output/mvp-0.5-independent-2026-10-24/06-approval-after-390.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0212

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: full frontend green
- Original reference: `nmate-mvp-v0.1/output/mvp-0.5-2026-10-24/frontend-full-suite-green.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0213

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED DOM thật
- Original reference: `output/cost-card-fix-2026-10-28/red-dom.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0214

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Diff đã làm sạch
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/release-v2-pycache-guard.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0215

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Addendum độc lập
- Original reference: `output/mvp-0.5-independent-2026-10-24/REVIEW-INDEPENDENT.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0216

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: báo cáo SSOT
- Original reference: `MVP/design-hardening-2026-10-22/ssot-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0217

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: báo cáo SSOT
- Original reference: `MVP/design-hardening-2026-10-22/ssot-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0218

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: đối soát sau migration
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/migration-runtime-red.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0219

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: TDD red
- Original reference: `output/mvp-0.5-2026-10-24/migration-runtime-ledger-red-corrected-fixture.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0220

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 81 ca schema/startup/operator/adversarial/process lock
- Original reference: `output/mvp-0.5-2026-10-24/migration-runtime-ledger-green-broad.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0221

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Đối soát MAIN bằng đọc
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/migration-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0222

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED tính năng/liên kết
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/enterprise-profile-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0223

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: thiết kế V17
- Original reference: `MVP/review-v17-2026-10-26/00_RCA_va_kien_truc.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0224

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: log V17
- Original reference: `nmate-mvp-v0.1/output/v17-2026-10-26/frontend-full-prebinding.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0225

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: full211author
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/author-candidate2-broad.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0226

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: độc lập39ca+4ca riêng
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/01_REVIEW_M2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0227

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: independent deep-r2
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/candidate1-deep-r2.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0228

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED typed candidate
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2/red-typed-candidate.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0229

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: r1
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/candidate1-independent-r1.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0230

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED M2
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M2-boundaries-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0231

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi và bằng chứng
- Original reference: `MVP/r2-r3-core-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0232

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA dữ liệu và mobile 22/10
- Original reference: `MVP/data-integrity-workspace-2026-10-22/00_RCA_va_ban_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0233

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough cuối 22/10
- Original reference: `MVP/data-integrity-workspace-2026-10-22/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0234

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Thiết kế củng cố và RCA nháp 21/10
- Original reference: `MVP/architecture-hardening-2026-10-21/00_Phuong_an_sua_kien_truc.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0235

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Triển khai review/confirmation 21/10
- Original reference: `MVP/review-hardening-implementation-2026-10-21/00_Ban_trien_khai.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0236

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA tên cơ sở/nháp tồn kho 21/10
- Original reference: `MVP/draft-review-fixes-2026-10-21/RCA_va_ghi_nho_ky_thuat.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0237

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA consent và phạm vi hạn mức 22/10
- Original reference: `MVP/research-consent-v7-2026-10-22/00_RCA_va_ban_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0238

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA đủ mục tiêu nghiên cứu 22/10
- Original reference: `MVP/research-completeness-2026-10-22/00_RCA_va_ban_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0239

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA và walkthrough lượt có phí 20/10
- Original reference: `MVP/paid-flow-repair-2026-10-20/Walkthrough_sau_sua_luot_Claude.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0240

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập luồng có phí 20/10
- Original reference: `MVP/paid-flow-repair-2026-10-20/Review_doc_lap.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0241

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough và RCA B1–B6
- Original reference: `MVP/bugfix-b1-b6-2026-10-20/Walkthrough_sua_B1_B6.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0242

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA provenance/task/market 20/10
- Original reference: `MVP/bugfix-b1-b6-2026-10-20/RCA_sua_3_diem_8025.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0243

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA ngữ cảnh và composer 19/10
- Original reference: `MVP/v0.4A-live-independent-review-2026-10-19/RCA_ngu_canh_va_trang_thai.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0244

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA Claude/schema/validation 17/10
- Original reference: `MVP/simplified-assistant-walkthrough/RCA_Claude.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0245

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Chứng cứ backend và hợp đồng schema
- Original reference: `MVP/simplified-assistant-walkthrough/RCA_backend_evidence.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0246

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review null/no-op và guard giữ nguyên
- Original reference: `MVP/certifications-null-fix/Independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0247

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA trích dẫn/ID excerpt 18/10
- Original reference: `MVP/live-claude-review-v03A-2026-10-18/RCA_trich_dan_Claude.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0248

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập callback/reconcile/ACL 17/10
- Original reference: `MVP/review-fixes/Independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0249

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA cách ly profile và bản sửa 17/10
- Original reference: `MVP/review-fixes/Review_va_sua_loi_17_10.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0250

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review kiến trúc 0.3A: ACL, freshness, market
- Original reference: `MVP/v0.3A-implementation/Review_kien_truc_doc_lap.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0251

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Kiểm chứng phát hành, manifest và giới hạn test 22/10
- Original reference: `MVP/data-integrity-workspace-2026-10-22/02_Kiem_chung_va_deploy.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0252

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập policy/quyền/PDF 22/10
- Original reference: `MVP/data-integrity-workspace-2026-10-22/03_Review_doc_lap_chinh_sach_va_du_lieu.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0253

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review migration và các writer 21/10
- Original reference: `MVP/architecture-hardening-2026-10-21/review_migration_quality.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0254

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Actionlog 18/10 và giới hạn chứng cứ reload
- Original reference: `MVP/question-relevance-2026-10-18/Actionlog.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0255

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Triển khai củng cố field, SSOT, Gateway, intent và mobile
- Original reference: `MVP/design-hardening-2026-10-22/01_Trien_khai_va_kiem_chung.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0256

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập và phạm vi xử lý thiết kế
- Original reference: `MVP/design-hardening-2026-10-22/04_Review_doc_lap_va_pham_vi_dong.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0257

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough mobile bản củng cố
- Original reference: `MVP/design-hardening-2026-10-22/03_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0258

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi và RCA vòng kiểm thử v12
- Original reference: `MVP/review-v12-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0259

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Backend v12: parser, alias, binding và phạm vi PDF
- Original reference: `MVP/review-v12-2026-10-22/backend-intake-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0260

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Frontend v12: nháp, lỗi transport và bằng chứng bản cuối
- Original reference: `MVP/review-v12-2026-10-22/frontend-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0261

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review chéo v12: alias lịch sử, transport và giới hạn
- Original reference: `MVP/review-v12-2026-10-22/independent-review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0262

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Policy và hạn mức v12: phủ định, coverage và cost DTO
- Original reference: `MVP/review-v12-2026-10-22/policy-budget-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0263

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough mobile v12, PDF/nháp/SSOT và giới hạn
- Original reference: `MVP/review-v12-2026-10-22/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0264

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Full test và đối soát phát hành v12 trên 8025
- Original reference: `MVP/review-v12-2026-10-22/02_Kiem_chung_va_deploy.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0265

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA vòng tiếp v12: đích sản phẩm, rollback, feedback và đủ nhu cầu
- Original reference: `MVP/review-v12-followup-2026-10-22/00_RCA_va_pham_vi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0266

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Nghiệm thu mobile vòng tiếp v12 và các parser debt còn mở
- Original reference: `MVP/review-v12-followup-2026-10-22/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0267

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Kiểm chứng, đối soát full/file hợp đồng và phát hành vòng tiếp v12
- Original reference: `MVP/review-v12-followup-2026-10-22/02_Kiem_chung_va_deploy.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0268

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA sửa tiếp các lỗi parser và policy adapter
- Original reference: `MVP/parser-closure-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0269

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough parser, nối tiếp nháp và mobile
- Original reference: `MVP/parser-closure-2026-10-22/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0270

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Kiểm chứng và đối soát phát hành parser closure
- Original reference: `MVP/parser-closure-2026-10-22/02_Kiem_chung_va_deploy.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0271

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập và các hồi quy được bắt trong đợt sửa
- Original reference: `MVP/parser-closure-2026-10-22/independent-review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0272

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phân vai product/reference, lịch sử và literal edit
- Original reference: `MVP/parser-closure-2026-10-22/product-parser-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0273

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Policy prepare: rollback, context pin và READ khi replay
- Original reference: `MVP/parser-closure-2026-10-22/policy-boundary-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0274

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Nháp rỗng và bảo toàn bản đối chiếu thật
- Original reference: `MVP/parser-closure-2026-10-22/frontend-empty-review-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0275

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Intent bao bì và dữ kiện thực tế
- Original reference: `MVP/parser-closure-2026-10-22/intent-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0276

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA sáu lỗi còn sót: đơn vị, PDF, lượng bán và disclosure
- Original reference: `MVP/residual-six-2026-10-22/00_RCA_va_pham_vi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0277

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough sáu lỗi trên mobile, PDF chậm và tải lại
- Original reference: `MVP/residual-six-2026-10-22/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0278

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Full suite và đối soát phát hành residual-six trên 8025
- Original reference: `MVP/residual-six-2026-10-22/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0279

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập IR-01–08 và giới hạn
- Original reference: `MVP/residual-six-2026-10-22/independent-review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0280

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Bán hàng: tuple đơn vị/kỳ, focus và exact contract cũ
- Original reference: `MVP/residual-six-2026-10-22/sales-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0281

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: PDF: phân loại lỗi worker và authority loại tệp nháp
- Original reference: `MVP/residual-six-2026-10-22/pdf-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0282

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi R0–R1 và RCA query, READ lineage, startup, runner và các vòng đỏ
- Original reference: `MVP/r0-r1-core-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0283

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Inventory nguồn đầu/cuối, đường thực thi và 48 lớp DF
- Original reference: `MVP/r0-r1-core-2026-10-22/00_R0_inventory.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0284

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Query/preview, Gateway begin/replay và consent: nguồn/test cuối
- Original reference: `MVP/r0-r1-core-2026-10-22/gateway-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0285

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Managed startup, schema lifecycle, crash/resume/backup/restore
- Original reference: `MVP/r0-r1-core-2026-10-22/migration-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0286

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập archive READ và adversarial runtime
- Original reference: `MVP/r0-r1-core-2026-10-22/R1_Independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0287

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough mobile R0–R1, SSOT và chính sách hai mục tiêu
- Original reference: `MVP/r0-r1-core-2026-10-22/02_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0288

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Bộ tổng 2.421 backend/581 frontend và phát hành 8025
- Original reference: `MVP/r0-r1-core-2026-10-22/03_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0289

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Vận hành schema và giới hạn operator/legacy
- Original reference: `MVP/r0-r1-core-2026-10-22/04_Van_hanh_schema.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0290

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Review độc lập bundle backend, child PDF và boundary import
- Original reference: `MVP/r0-r1-core-2026-10-22/R1_Bundle_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0291

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: R2 Field Registry: type/scope/qualifier, schema và cách ly legacy sai
- Original reference: `MVP/r2-r3-core-2026-10-22/field-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0292

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Workspace/SSOT, provenance và reducer settle đúng receipt
- Original reference: `MVP/r2-r3-core-2026-10-22/frontend-receipt-followup.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0293

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Intent → requirement → task → outcome → ActionBrief
- Original reference: `MVP/r2-r3-core-2026-10-22/intent-plan-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0294

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Graph tri thức SQL có kiểu, dependency và quyền nguồn
- Original reference: `MVP/r2-r3-core-2026-10-22/domain-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0295

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Exact cache phiên bản hữu hạn, lineage archive và ranh giới DTO
- Original reference: `MVP/r2-r3-core-2026-10-22/export-intake-cache-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0296

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough mobile R2–R3: candidate lỗi và kết quả sửa tách riêng
- Original reference: `MVP/r2-r3-core-2026-10-22/03_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0297

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Nghiệm thu R2–R3: kiểm tổng nhiều lượt, bundle và cutover
- Original reference: `MVP/r2-r3-core-2026-10-22/04_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0298

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi, an toàn dữ liệu và tiến độ
- Original reference: `MVP/design-hardening-2026-10-22/00_Pham_vi_va_tien_do.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0299

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: danh sách còn mở
- Original reference: `MVP/design-hardening-2026-10-22/02_Diem_con_mo_va_quyet_dinh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0300

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi và RCA của vòng v12
- Original reference: `MVP/review-v12-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0301

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Bằng chứng và 17 ca hồi quy
- Original reference: `MVP/review-v12-2026-10-22/browser-identity-fixture-report.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0302

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA và phạm vi
- Original reference: `MVP/residual-six-2026-10-22/00_RCA_va_pham_vi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0303

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phạm vi và RCA
- Original reference: `MVP/r0-r1-core-2026-10-22/00_Pham_vi_va_RCA.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0304

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RCA V16
- Original reference: `MVP/review-v16-2026-10-23/00_RCA_va_pham_vi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0305

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough V16
- Original reference: `MVP/review-v16-2026-10-23/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0306

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: nghiệm thu
- Original reference: `MVP/review-v16-2026-10-23/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0307

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Phát hành và giới hạn
- Original reference: `MVP/mvp-0.5-policy-2026-10-24/04_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0308

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: walkthrough mobile
- Original reference: `MVP/mvp-0.5-policy-2026-10-24/02_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0309

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review độc lập
- Original reference: `output/mvp-0.5-independent-2026-10-24/REVIEW-INDEPENDENT.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0310

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: probe cuối
- Original reference: `output/mvp-0.5-2026-10-24/frozen-bundle-probe-v4/probe-result.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0311

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: HTTP sau launch
- Original reference: `nmate-backend-v0.2/output/mvp-0.5-2026-10-24/deployment-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0312

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Thiết kế V17
- Original reference: `MVP/review-v17-2026-10-26/00_RCA_va_kien_truc.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0313

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review kiến trúc độc lập
- Original reference: `output/v17-design-review-2026-10-26/REVIEW-INDEPENDENT-ARCHITECTURE.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0314

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED ba phân loại
- Original reference: `nmate-backend-v0.2/output/v17-2026-10-26/metadata-read-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0315

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Bằng chứng synthetic
- Original reference: `output/v17-design-review-2026-10-26/operator-ledger-accounting-red.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0316

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Walkthrough mobile
- Original reference: `MVP/review-v17-2026-10-26/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0317

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: kiểm thử/phát hành
- Original reference: `MVP/review-v17-2026-10-26/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0318

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: kịch bản test
- Original reference: `MVP/review-v17-2026-10-26/03_Kich_ban_test.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0319

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Approval/biên nhận
- Original reference: `nmate-backend-v0.2/output/d06-local-testers-20usd-2026-10-26/grant-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0320

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: manifest kiểm tài liệu
- Original reference: `output/policy-knowledge-design-2026-10-26/document-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0321

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Snapshot trước sửa
- Original reference: `output/policy-knowledge-design-2026-10-26/baseline-before-P06-approval/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0322

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Kiểm tĩnh bản1.1
- Original reference: `output/policy-knowledge-design-2026-10-26/P06-approved-document-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0323

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Baseline trước kế hoạch
- Original reference: `output/policy-knowledge-design-2026-10-26/baseline-before-milestone-plan/manifest.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0324

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: kiểm tài liệu
- Original reference: `output/policy-knowledge-design-2026-10-26/milestone-plan-document-verification.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0325

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED contract boundaries
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/red-contract-boundaries.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0326

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: read/receipt integrity
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/red-read-receipt-integrity.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0327

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED aggregate head
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/red-aggregate-event-head.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0328

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review M1 candidate1 mở rộng
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M1/candidate1-independent-r2.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0329

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: independent-r3
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M1/candidate2-independent-r3.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0330

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: head-proof r4
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M1/candidate2-head-proof-red-r4.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0331

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: author rewind RED
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/M1/red-causal-head-rewind.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0332

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review M2, IR-M2-F03
- Original reference: `output/policy-knowledge-M1-M2-2026-10-26/review-M2/01_REVIEW_M2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0333

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review M3 candidate1
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/02_Review_candidate1.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0334

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED cross-DB candidate2
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/candidate2-independent-r2-cross-db-red.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0335

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review saved S1
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/06_S1_saved_output_RCA_va_admission_v2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0336

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED admission
- Original reference: `output/policy-knowledge-M3-2026-10-27/admission-v2-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0337

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED occurrence
- Original reference: `output/policy-knowledge-M3-2026-10-27/proposal-occurrence-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0338

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: receipt
- Original reference: `output/policy-knowledge-M3-2026-10-27/public-batch-final3/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0339

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Signoff độc lập cuối
- Original reference: `output/policy-knowledge-M3-2026-10-27/review-M3/07_Review_candidate5_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0340

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: SCOPED PASS candidate4
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/03_Review_M4_candidate4_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0341

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review candidate2 F03
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/02_Review_M4_candidate2_F03_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0342

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 33ca gateway/policy đạt
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-dispatch-proof-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0343

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED2ca DOM
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-private-DOM-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0344

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review candidate1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/01_Review_M4_candidate1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0345

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Ảnh
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M4/output/playwright/07-workbench-host-401.png`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0346

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 30ca tác động đạt
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M4-route-fix-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0347

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED2ca
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-upstream-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0348

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: GREEN
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-upstream-first.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0349

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED trait
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-request-constraints-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0350

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: vòng79pass/1fail
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27-M4-pre-freeze.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0351

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: M5a
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M5/01_Review_M5a_PRE_CUTOVER.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0352

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: M5b
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M5/02_Review_M5b_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0353

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: probe độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M5/launcher-coherent-identity-probe.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0354

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-runtime-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0355

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 14ca runtime/host
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-candidate2-runtime-host.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0356

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: HTTP/readiness MAIN
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M5-live-20261027-104316/http-readonly-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0357

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/10_Review_M6_O1_BLOCKED.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0358

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Bằng chứng
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/01_Preimplementation_review_matrix.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0359

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Ca âm độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/test_next_artifact_boundaries.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0360

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: O1 chẩn đoán từ dữ liệu đã lưu
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/O1-output-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0361

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Ca độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/test_next_provider_envelope.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0362

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Audit O1
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-four-slots-20261027/O1-output-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0363

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review cuối
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/09_Review_C6_FREE_RECOVERY_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0364

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: receipt phục hồi miễn phí
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/free-recovery-receipt.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0365

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: hai ca root
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-C5-downgrade-red.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0366

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Hai ca độc lập dùng forged INSERT vào fixture
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate5-downgrade-red.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0367

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Hai ca metadata
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate5-outerflags.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0368

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Audit miễn phí
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-paid-continuation-20261027/saved-evidence-audit.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0369

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: đối chiếu độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/S2-saved-evidence-diagnostic.json`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0370

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: review cuối độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/05_Review_M6_FINAL.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0371

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: ca độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/test_m6_terminal_overrun.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0372

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate3-overrun.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0373

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Ba RED bổ sung
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate3-terminal-evidence.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0374

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: test độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/test_m6_adversarial_r1.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0375

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate1-r1.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0376

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate1-r2.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0377

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: test
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/test_m6_adversarial_r2.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0378

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: Test
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/test_m6_legacy_pause_anchor.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0379

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: log
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6/candidate2-legacy.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0380

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: vòng đầu
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-worker-first.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0381

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 13ca M6
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-worker-evaluation-second.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0382

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: 41ca frozen liên quan
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/M6-candidate1-affected-tests.txt`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0383

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/simulation-boundaries-initial.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0384

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: ca độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/test_next_simulation_boundaries.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0385

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: RED độc lập
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/branch-source-current-initial.log`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0386

- Exported document: `project/MVP/architecture/DESIGN_FLAWS.md`
- Label: test
- Original reference: `output/policy-knowledge-M4-M6-2026-10-27/review-M6-next/test_next_branch_authority.py`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0387

- Exported document: `project/MVP/architecture/KE_HOACH_DONG_LOI_THIET_KE_2026-10-22.md`
- Label: nghiệm thu gần nhất
- Original reference: `MVP/residual-six-2026-10-22/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0388

- Exported document: `project/MVP/architecture/KE_HOACH_DONG_LOI_THIET_KE_2026-10-22.md`
- Label: báo cáo riêng
- Original reference: `MVP/r0-r1-core-2026-10-22/03_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0389

- Exported document: `project/MVP/architecture/KE_HOACH_DONG_LOI_THIET_KE_2026-10-22.md`
- Label: nghiệm thu có phạm vi
- Original reference: `MVP/r2-r3-core-2026-10-22/04_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0390

- Exported document: `project/MVP/architecture/README.md`
- Label: V17 đã phát hành trên 8025: RCA và kiến trúc
- Original reference: `MVP/review-v17-2026-10-26/00_RCA_va_kien_truc.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0391

- Exported document: `project/MVP/architecture/README.md`
- Label: walkthrough mobile
- Original reference: `MVP/review-v17-2026-10-26/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0392

- Exported document: `project/MVP/architecture/README.md`
- Label: nghiệm thu và giới hạn
- Original reference: `MVP/review-v17-2026-10-26/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0393

- Exported document: `project/MVP/architecture/README.md`
- Label: V16 — mốc phát hành 23/10: RCA và phạm vi
- Original reference: `MVP/review-v16-2026-10-23/00_RCA_va_pham_vi.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0394

- Exported document: `project/MVP/architecture/README.md`
- Label: walkthrough mobile
- Original reference: `MVP/review-v16-2026-10-23/01_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0395

- Exported document: `project/MVP/architecture/README.md`
- Label: nghiệm thu và giới hạn
- Original reference: `MVP/review-v16-2026-10-23/02_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0396

- Exported document: `project/MVP/architecture/README.md`
- Label: Lõi R2–R3: kiến trúc và bất biến
- Original reference: `MVP/r2-r3-core-2026-10-22/02_Kien_truc_va_bat_bien_R2_R3.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0397

- Exported document: `project/MVP/architecture/README.md`
- Label: walkthrough lịch sử
- Original reference: `MVP/r2-r3-core-2026-10-22/03_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0398

- Exported document: `project/MVP/architecture/README.md`
- Label: nghiệm thu R2–R3
- Original reference: `MVP/r2-r3-core-2026-10-22/04_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0399

- Exported document: `project/MVP/architecture/README.md`
- Label: R0–R1 đã phát hành trên 8025: kiểm thử, bundle và audit dữ liệu
- Original reference: `MVP/r0-r1-core-2026-10-22/03_Kiem_thu_va_phat_hanh.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0400

- Exported document: `project/MVP/architecture/README.md`
- Label: walkthrough mobile
- Original reference: `MVP/r0-r1-core-2026-10-22/02_Walkthrough_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0401

- Exported document: `project/MVP/architecture/README.md`
- Label: Kiến trúc tổng thể, mốc 19/10/2026
- Original reference: `MVP/system-architecture-2026-10-19/Kien_truc_tong_the_nMate_0_4.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0402

- Exported document: `project/MVP/architecture/README.md`
- Label: Thiết kế củng cố nháp, giao dịch và phép chiếu
- Original reference: `MVP/architecture-hardening-2026-10-21/00_Phuong_an_sua_kien_truc.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0403

- Exported document: `project/MVP/architecture/README.md`
- Label: RCA toàn vẹn dữ liệu và mobile, mốc 22/10/2026
- Original reference: `MVP/data-integrity-workspace-2026-10-22/00_RCA_va_ban_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0404

- Exported document: `project/MVP/architecture/README.md`
- Label: Bản củng cố field, SSOT, Gateway, quyền và workspace, 22/10/2026
- Original reference: `MVP/design-hardening-2026-10-22/01_Trien_khai_va_kiem_chung.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0405

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/01_Thiet_ke_kien_truc_Agent.md`
- Label: review độc lập ba flow
- Original reference: `MVP/independent-mobile-review-2026-10-18/Review_doc_lap_3_flow.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0406

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/01_Thiet_ke_kien_truc_Agent.md`
- Label: review chủ doanh nghiệp
- Original reference: `MVP/owner-mobile-audit-2026-10-18/Review_chu_doanh_nghiep_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0407

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/01_Thiet_ke_kien_truc_Agent.md`
- Label: review UX nghiêm khắc
- Original reference: `MVP/independent-ux-review-2026-10-18/Review_nghiem_khac_walkthrough.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0408

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/01_Thiet_ke_kien_truc_Agent.md`
- Label: walkthrough mới nhất
- Original reference: `MVP/question-relevance-2026-10-18/Walkthrough_cau_hoi_va_nguon.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0409

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: graph.py:366
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:366`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0410

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S01 — ShipmentState và graph thực thi
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:48`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0411

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S02 — NextStep
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/models.py:94`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0412

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S03 — registry
- Original reference: `nmate-backend-v0.2/src/nmate/agents/registry.py:14`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0413

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S04 — schema intake
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/models.py:171`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0414

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S05 — proposal grounding
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/service.py:343`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0415

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S06 — readiness server
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/store.py:40`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0416

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S07 — atomic launch intent
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/store.py:354`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0417

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S08 — đúng artifact và phân biệt căn cứ
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/service.py:444`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0418

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S09 — worker và checkpoint
- Original reference: `nmate-backend-v0.2/src/nmate/service.py:77`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0419

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S10 — startup/checkpointer
- Original reference: `nmate-backend-v0.2/src/nmate/app.py:47`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0420

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S11 — topic regex và action policy
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:205`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0421

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S12 — policy version và report guards
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/models.py:13`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0422

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S13 — model synthesis không tạo plan mới
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:736`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0423

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S14 — source policy
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/sources.py:195`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0424

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S15 — hashes và dịch
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/models.py:145`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0425

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S16 — source-gated topic answers
- Original reference: `nmate-backend-v0.2/src/nmate/agents/shipment/graph.py:346`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0426

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S17 — transaction và start
- Original reference: `nmate-backend-v0.2/src/nmate/store.py:59`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0427

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S18 — atomic publish và stale
- Original reference: `nmate-backend-v0.2/src/nmate/store.py:343`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0428

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S19 — chat reservation/replay/commit
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/store.py:182`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0429

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S20 — owner isolation
- Original reference: `nmate-backend-v0.2/src/nmate/conversations/store.py:74`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0430

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S21 — local task/draft
- Original reference: `nmate-mvp-v0.1/src/app.js:99`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0431

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S22 — current case replace
- Original reference: `nmate-backend-v0.2/src/nmate/store.py:203`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0432

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S23 — năm MCP tools
- Original reference: `nmate-backend-v0.2/src/nmate/mcp_server.py:12`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0433

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S24 — tài liệu policy live cũ
- Original reference: `nmate-backend-v0.2/FRONTEND.md:80`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0434

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/current-state.md`
- Label: S25 — mô tả kiến trúc và giới hạn được công bố
- Original reference: `nmate-backend-v0.2/ARCHITECTURE.txt:47`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0435

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: review mobile trước sửa
- Original reference: `MVP/mobile-walkthrough/Review_UX_doc_lap_nghiem_khac.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0436

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: review sau sửa
- Original reference: `MVP/mobile-walkthrough/Review_UX_sau_sua.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0437

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: phương án frontend
- Original reference: `MVP/frontend-ai-native-proposal/Phuong_an_frontend_AI_native.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0438

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: independent review 17/10
- Original reference: `MVP/independent-ux-review/Review_doc_lap_UX_va_walkthrough.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0439

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: review-fixes
- Original reference: `MVP/review-fixes/Independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0440

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: null semantics
- Original reference: `MVP/certifications-null-fix/Independent_review.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0441

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: strict review 18/10
- Original reference: `MVP/independent-ux-review-2026-10-18/Review_nghiem_khac_walkthrough.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0442

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: owner audit
- Original reference: `MVP/owner-mobile-audit-2026-10-18/Review_chu_doanh_nghiep_mobile.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0443

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: walkthrough ba câu hỏi
- Original reference: `MVP/question-relevance-2026-10-18/Walkthrough_cau_hoi_va_nguon.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0444

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: review độc lập ba flow
- Original reference: `MVP/independent-mobile-review-2026-10-18/Review_doc_lap_3_flow.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0445

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: Kiến trúc g2
- Original reference: `_research/nmate/g2/kien-truc-v1.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0446

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: ADR g2
- Original reference: `_research/nmate/g2/adr.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0447

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: Kiến trúc g3
- Original reference: `_research/nmate/g3/kien-truc-v2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0448

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: nhu cầu g3
- Original reference: `_research/nmate/g3/nhu-cau-v2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled

## ref-0449

- Exported document: `project/MVP/agent-architecture-v0.3-proposal/research/lessons-and-scenarios.md`
- Label: đặc tả g4
- Original reference: `_research/nmate/g4/dac-ta-nac-0-2.md`
- Status: not_required_for_bootstrap; historical_or_local_only; not_bundled
