# Independent review — narrow cost-card C2

28/10/2026. **SCOPED TECHNICAL PASS**, no confirmed new blocking finding. Candidate `M5-cost-candidate2`, 468 files, raw manifest SHA256 `05e9d632ba23dd0e0a440ae9ce4f3ce8f957e1adb6b40b4bc4f06f27a8fd3840`.

## Independently obtained evidence

- `verify_c2.py` checked exact full file set, all file sizes/content hashes and raw manifest pin. `c2-file-audit.json` confirms exactly six changed/added files relative to C1: release identity, main HTML cache tag, cost-card JS and three QA fixture/probe files. Backend business logic, budget/branch authority, schemas and all other files are byte-identical. No source-role or D06 change.
- One frozen invocation of existing `qa/main-app-regression.cjs` plus `qa/main-ui-contracts-regression.cjs`: **357 tests passed**, duration5611.2926ms; `independent-frozen-c2-regressions.log`. These are independently rerun author/legacy regressions, not 357 newly authored reviewer tests.
- `independent-cost-card-vm.cjs`: **five independently authored VM edge probes passed** in one invocation, duration95.9087ms; `independent-cost-card-vm.log`. Executes frozen real cost-card source with a test-only in-memory seam; no release writes. Delayed fetch after account switch, delayed JSON after enterprise switch, foreign actor response, forbidden response and stable text-only/repeated announcement behavior pass. This is a VM/request/announcement guard check, **not native DOM/layout/audio verification**.

## Source-level assessment

Disclosure state is captured from the connected current details before replacing the card and restored on its replacement. Old detached toggle events cannot overwrite current state. State resets on account+enterprise change. Checkbox change updates the existing button and live region without rebuilding DOM, so the original node/focus can survive. The async preview completion explicitly focuses the current checkbox after render; existing request generation and actor checks prevent old responses from doing that in another scope.

The live status node is a sibling retained across card replacement and uses polite/atomic text content. Checkbox and action reference it; consent messages distinguish unlocked/locked action from recorded decision or model execution. Error uses the existing alert path once. Estimate copy says it is not an invoice; S3/S4 purpose is visible before preview. No new provider, grant, approval endpoint or automatic command path was added.

Broader component design remains open: other card actions still rerender, a full app shell rerender can recreate the host, and speech behavior requires actual assistive-technology testing. These are not claims of newly confirmed defects or of global DF-036/037 closure.

## Browser and operator limits

Reviewer CUA discovery returned no browsers; creating an IAB tab returned browser unavailable. Consequently reviewer **did not independently run C2 mobile/native DOM**. Root separately reports six native DOM probes and full synthetic8036 mobile320/390 checks including focus/announcements/disclosure/account switch/empty console; those must remain labeled root evidence. The old first RED account-switch timeout is not attributed to a proven privacy or generation-guard failure. Root's transient fixed-time PDF test and baseline rerun are separate historical evidence, not rewritten as product root cause here.

Static reread of `launch_approved_cost_card.py` and `cutover.py` found no blocker for the root's verified quiescent local replacement: exact C2 release/assignment pins, old process identity, active-work guards, runtime lock, private backup/table signatures, no migration/grant/branch/provider action. Reviewer did not execute scripts, open original DB/assignment, call a provider, record a real continuation or interact with8025. Deployment and post-start unchanged-data/HTTP checks remain root responsibility.

DF trace: **DF-036/037** are the confirmed presentation-state/accessibility recurrence already logged by root. This scoped patch has source/VM/regression evidence; native-browser evidence is root-owned and actual NVDA/VoiceOver audio, shared component/disclosure contracts and other interactions remain open. No new DF root cause found; no D2 class closure or real Claude/content/legal acceptance follows from this review.
