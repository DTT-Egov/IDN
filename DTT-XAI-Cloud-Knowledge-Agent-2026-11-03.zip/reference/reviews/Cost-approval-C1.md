# Final independent review — main cost approval C1

**SCOPED TECHNICAL PASS** for `M5-cost-candidate1`: 465 exact files, raw manifest SHA256 `a896231b65ec09f1f24aa0963583ffe6ca3a96aac518666433fb152f13b44cf0`.

Reviewer independently verified full file set, file sizes/hashes and manifest pin; `candidate1-file-verification.json`. One frozen invocation of `test_cost_approval_independent.py` passed **17 tests in 108.65 s**; `candidate1-independent.log`. Working-tree evidence and two reviewer harness corrections remain in report02. Do not sum those historical runs as additional candidate tests.

## Mobile full-main sandbox independently exercised

Only disposable `http://127.0.0.1:8033/web/`, created from frozen C1 with synthetic main/public DBs, fake five-call O1-failure setup and forbidden HTTP provider. No `.env`, API key, 8025 or original batch database was accessed by reviewer.

At **320×740**: logged in synthetic chosen subject `trung@dtt.vn`, opened inline chat card, previewed O2, expanded budget/scope, checked consent, recorded synthetic continuation. Before consent primary action disabled. After record, heading reads “Đã ghi quyết định tiếp tục riêng O2”, live status explicitly says Claude has not been called. No paid/provider or new grant action exists on this card. Previewed costs and expiry are synthetic fixture values, not actual batch finance.

Measured cost-card summary, input and buttons approximately **44.0000 px** high. Consent label **136 px** high. Page width320, document scrollWidth305; no horizontal overflow. Screenshots emitted in reviewer tool stream, **no local screenshot files saved**.

At **390×844**: reloaded, authenticated chat restored recorded status without a new decision/confirmation; read-status button preserved state. Page width390, scrollWidth375. Logged out through real settings/profile UI, logged in `kb_author` (synthetic other account with expert fixture scope); cost card text empty and no prior decision shown. Console warning/error log empty across the flow. Temporary viewport override reset.

## Authority and safety evidence

Exact main account ID+username; separate expert and cost roles; session+CSRF+origin/body validation; v1 operator impersonation rejected; typed flag/head/input/source tamper denied without changes. Preview/status read-only. Recording changes only existing causal-control/head, grant-state projection and model-event ledger; O1 attempt/raw/usage/validation and budget terms unchanged.

Exact committed replay survives assignment removal while current source READ remains. READ revoke blocks receipt. Assignment removed specifically between reserve and dispatch fence causes O2 reserved attempt to become cancelled_before_dispatch with held budget zero and fake provider count unchanged. Browser approval itself neither reserves nor calls O2. No refund/retry/publication authority added.

## Local cutover script review

Static review of `launch_approved_cost.py` and `cutover_cost.py` found no blocker for the planned root-operated local swap: release/assignment pins before startup; exact old PID+command+creation identity; active-work checks; BEGIN IMMEDIATE while stopping old listener; runtime lock; private backup and all-table signatures; no migration, grant issuance, continuation command, paid worker or retry. Stop/error leaves reconciliation report rather than silently resuming. **Reviewer did not execute these scripts, read actual assignment or inspect original DB.** Root's dry run, clone rehearsal, unchanged-live-data audit and post-start HTTP/data verification are separate evidence; do not attribute them to reviewer.

Existing paid worker C6 pin is intentionally unchanged. Real O2 dispatch requires separately reviewed compatible worker pin and a separate actual continuation decision; this C1 pass does not authorize either, issue pilot funds or validate Claude content/legal policy quality.

## Limits and DF status

Pass covers tested local adapter, shared fence and mobile flow. Not a high-volume/concurrent browser benchmark, multi-host security qualification, real financial dispatch or D07 legal acceptance. No confirmed new product RCA found. DF-029/033/048/052/053/056/057 remain traceable design classes with scoped evidence, not wholesale D2 closure. Real O1 remains a retained failed result; no reviewer original-state mutations were performed.
