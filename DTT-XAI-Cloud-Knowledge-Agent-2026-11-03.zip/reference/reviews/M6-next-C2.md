# Independent review — M6 next candidate 2

**SCOPED TECHNICAL PASS — live model quality and production release remain unqualified.**

Date: 2026-10-27. Candidate: `M6-next-candidate2`, 458 files, exact raw manifest SHA256 `24ec0a253b4a3c3d7306cee3949543785ab019fc37487bd9178014662b8c8c87`.

## What was independently verified

The reviewer read AGENTS.md, relevant DESIGN_FLAWS entries, designs 14/15, shared Gateway and source/governance code. All code reproduction used synthetic isolated pytest databases and fake providers. No environment/API key, production database, real grant/approval, real O1/O2 response, paid provider or deployment was read or changed by this reviewer.

- `candidate2-pin-verification.json`: every listed file's bytes/hash and exact file set match the externally supplied manifest hash. C2 differs from C1 only in Gateway/domain profile pricing, execution profile compiler and one author test. Mobile UI bytes are unchanged.
- `frozen-candidate2-author-independent.log`: **38 tests passed in one invocation**, comprising the three author test modules rerun independently plus the 26 independent tests present at collection time.
- `frozen-candidate2-one-package-extra.log`: **one additional independent test passed** after collection of that invocation. It checks a complete typed demo package generated in one fake producer call, admitted and handed to a simulated reviewer without production authority.
- Therefore **27 distinct reviewer-authored tests** have passed on frozen C2, alongside the independently rerun author modules. This is not represented as a single 39-test invocation. Earlier C1/working-tree runs are retained as history and not added to inflate the final count.

## Initial blockers and resolution

1. Unhashable provider metadata formerly raised TypeError during receipt persistence. Dict/list metadata now keeps raw/known usage and produces controlled rejection; three independent cases pass. DF-062/013.
2. Empty or foreign critic coverage formerly claimed goal completion. Tests now supply complete `assessed_target_ids` schema and verify exact original target partition; foreign IDs fail and a real explicit-unassessed partition remains reviewable. DF-025/026/043.
3. A v2 recipe formerly dispatched under a legacy grant by omitting execution tier. New recipes now require the corresponding typed schema and explicitly authorized profile; the old grant cannot provide the new capability. Legacy contracts remain separate. DF-061/034/044.
4. Simulation target hash formerly ignored a new current source revision. Shared current source bindings now invalidate new review/release identity while historical receipts remain readable. DF-033/048/053.
5. O2 permit formerly remained dispatchable after its source changed. Source snapshots are now bound and checked at continuation, reservation and dispatch fence. A direct Gateway test mutating source version at the final fence causes cancellation before fake SDK, with zero hold and no new provider call. DF-048/053/056.
6. New-profile output formerly accepted an absent reported model by legacy fallback. The new contract now rejects missing model identity while preserving received evidence.

Additional positive/negative coverage includes high/medium/low token capacity versus wire/manifest/hold; strict typed decision mutation; atomic rollback after decision writes; retained terminal stop; exact historical replay after source export/WRITE restriction; duplicate/foreign/missing review items; cross-sandbox denial; MCP actor supplied by host; no production review/publication writes; a one-call full package; namespaced evidence-to-ref mapping by source inspection.

## Actual mobile check

The reviewer used Cua on the isolated loopback sandbox **8032**, authenticated with its synthetic testing account, at **320×740** and **390×844**. This server prepared exactly two fake model fixtures and disabled its provider afterward. The tested flow was login → open assigned proposals → download agent handoff → invalid JSON rejected in Vietnamese → submit a review acknowledging all eleven synthetic gaps → simulation release.

The visible result explicitly says **“Đã phát hành mô phỏng · không dùng cho tư vấn thật”**. There was no horizontal overflow (document widths 305/375 within 320/390), visible buttons measured 44.74 px, and browser warning/error logs were empty. Two screenshots were captured in the browser tool stream; no local screenshot file is claimed. The handoff actually downloaded to `C:/Users/Admin/Downloads/goi-review-mo-phong.json`.

`mobile-sandbox-audit.json` records the independent read-only postcheck: two original fake provider attempts, one simulation review, one simulation release, **zero production reviews, releases or wiki pages**. This was all-gap synthetic data, not a semantic review of Hanoi policy. Mobile runtime was C1; C2 UI bytes match exactly, and C2 backend contracts were tested separately above. No full mobile C2 server restart is claimed. Viewport was reset and temporary browser tab closed afterward.

## Scope limits and remaining gates

- This pass qualifies the tested artifact/profile/receipt/continuation/simulation boundaries. It does not prove complete source coverage, current legal validity, useful real-model answers or every future transport/source/consumer.
- Simulation approval/release does not satisfy real D07 expert approval or make a policy eligible for production advice.
- No continuation was recorded for the real batch, no real O2 was dispatched, and no original O1 error or cost was changed by this review. No new pilot D06 grant was issued. The proposed live pilot needs its own later approval after its exact inputs and feasibility are fixed.
- MAIN 8025 deployment and its managed database were outside this review. The real approval/dispatch operator and chat continuation card were not exercised in the main app.
- The browser file input still uses English native browser chrome in this browser locale; its surrounding app label is Vietnamese. This is a minor presentation limitation, not a permission bypass.
- The initial pin verifier mistakenly excluded every file named `manifest.json`, including nested legitimate files; its first file-set assertion was a reviewer harness issue. It was corrected to exclude only the root manifest and rerun successfully. No candidate source was changed to satisfy that assertion.

All scoped blockers above are resolved by the frozen evidence. Related design classes remain **D1** until broader criteria and real content qualification are met; no whole-class D2 or real legal/publication acceptance is granted.
