"""Verify this handoff's complete file set/hashes; standard library only."""
from pathlib import Path, PurePosixPath
import hashlib,json,sys

root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
expected={}
for entry in manifest['files']:
    name=entry['path'];part=PurePosixPath(name)
    if part.is_absolute() or '..' in part.parts or '\\' in name or name.casefold() in {p.casefold() for p in expected}:
        raise SystemExit('Unsafe/duplicate manifest path')
    expected[name]=entry
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
if actual!={'MANIFEST.json',*expected}:raise SystemExit('File set differs from manifest')
for name,entry in expected.items():
    path=root/name
    if path.is_symlink() or not path.is_file() or path.stat().st_size!=entry['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
        raise SystemExit('Integrity failure: '+name)
print(json.dumps({'verified':True,'files':len(expected)+1,'manifest_sha256':hashlib.sha256((root/'MANIFEST.json').read_bytes()).hexdigest(),'model_calls':0}))
